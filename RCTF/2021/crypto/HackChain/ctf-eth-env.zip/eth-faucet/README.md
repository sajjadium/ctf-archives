# eth-faucet

## Quick Start
```bash
$ docker compose up -d
```
