import App from './App.svelte';
import 'bulma/css/bulma.min.css';

const app = new App({
  target: document.body,
});

export default app;
