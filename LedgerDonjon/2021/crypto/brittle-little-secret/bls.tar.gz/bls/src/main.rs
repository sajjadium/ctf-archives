use ark_bls12_381::{Fq, Fq2, Fr, G1Affine, G2Affine};
use ark_ec::{AffineCurve, ProjectiveCurve};
use ark_ff::bytes::{FromBytes, ToBytes};
use std::{
    env,
    io::Cursor,
    process::exit,
    str::{from_utf8, FromStr},
};

const ENCRYPTED_DATA: &'static str = "beiLPpGUsefnBjahYgx8MKNl1Bd59EwQPUfYLXBRg8J7p6b3UhxDKQqtQG2XAUEEHleWprEKGZxW/0uPv4HcZ19jGre+1GW38tqxfWdmNrk5wu/s+t2waB0lBlCxA0QG4RcWc4yqAqEapkFp5eoReESZGcu/gPzWXLCBMuO4HCv2uz0S9nirCKGJZkUKxaAHnoWw2HN3CaZp7Dv5MrqOzROmZwtla3gttGqpgZ5hPyov6rYeL5IpmUFgkQSHtsoYNJGEaj4pTq3rslaUWT0wHluGcnQ0EFJWGjcTHgOzmEcFpNGPQEmual0cZnmTDF4XgJDCMcWzd4GwhruhTbdGGsmFAKB8R0VILMOKJhA0MHYmzaej0mlHhgpjmTZLQqoB1UQk7gO8MTYAozmchcRo667xAeZ2THs5G5FiczIq2Ej0EmijbuUHJfqszlPNvrQBrjtS5Rc2SJUTgCQTVij9d7vEcmTFgLibdcG/Ym8dFiiTjO58H74erbYaUQCLn5MU/ypBlEzhHKmqfYSQmhQuE0fhljz+F0kDduq0OhfcIr2QyL8vFnSiYFvXXXB9WTgUGvWCKNG2UMH9oeAZOZjDfsfTHWO7Iw+xscihEfYnGush7p85KDg6kOPzw+YGgXUOETFbhIHskl7irHtmoZgNfhxJ/oCr4OTaCzT7CeESaFbXOdSLX9rSGRFsxq2SyrwK6ybq2ZEIR0wBdPEP+UY0oNUDnXyVvE0Xgx/AwIYJK9t+GF4Fc3oW0UJBzXslHW0Qx4Dn7XlGWEozkgOHj3SAtMcofSd4hHNqII3ze9lJNTGBB2HwwtMfdL4IWzgJKyQQUTq5zwJd3S6xrka1TsRQx6aVNYLhmHUOFC7uzT3aMjtjWED6dJTlCcaJO4wMf4sW";

#[derive(Clone, Debug)]
struct EncryptedData {
    pub g1: G1Affine,
    pub commited_1: G1Affine,
    pub g2: G2Affine,
    pub commited_2: G2Affine,
    pub encrypted_pt: G1Affine,
}

fn get_encrypted_data() -> EncryptedData {
    let encdata_bin = base64::decode(ENCRYPTED_DATA).unwrap();
    let mut encdata_reader = Cursor::new(&encdata_bin);
    let data = EncryptedData {
        g1: G1Affine::new(
            Fq::read(&mut encdata_reader).unwrap(),
            Fq::read(&mut encdata_reader).unwrap(),
            false,
        ),
        commited_1: G1Affine::new(
            Fq::read(&mut encdata_reader).unwrap(),
            Fq::read(&mut encdata_reader).unwrap(),
            false,
        ),
        g2: G2Affine::new(
            Fq2::read(&mut encdata_reader).unwrap(),
            Fq2::read(&mut encdata_reader).unwrap(),
            false,
        ),
        commited_2: G2Affine::new(
            Fq2::read(&mut encdata_reader).unwrap(),
            Fq2::read(&mut encdata_reader).unwrap(),
            false,
        ),
        encrypted_pt: G1Affine::new(
            Fq::read(&mut encdata_reader).unwrap(),
            Fq::read(&mut encdata_reader).unwrap(),
            false,
        ),
    };
    assert_eq!(encdata_reader.position(), encdata_bin.len() as u64);
    data
}

fn main_result() -> Result<(), String> {
    let encdata = get_encrypted_data();

    let mut args = env::args();
    args.next();
    let first_arg = args.next().ok_or("No key provided")?;
    if first_arg.len() >= 40 {
        return Err("invalid key".into());
    }
    let key = Fr::from_str(&first_arg).map_err(|()| "invalid key")?;

    // Verify the commitments
    if encdata.g1.mul(key) != encdata.commited_1 {
        return Err("invalid key".into());
    }
    if encdata.g2.mul(key) != encdata.commited_2 {
        return Err("invalid key".into());
    }
    println!("The key is correct, proceeding to decryption...");

    let decrypted_pt = encdata.encrypted_pt.mul(key).into_affine();
    let mut decrypted_raw: Vec<u8> = Vec::new();
    decrypted_pt
        .x
        .write(&mut Cursor::new(&mut decrypted_raw))
        .unwrap();
    let decrypted = from_utf8(&decrypted_raw).map_err(|_| "invalid key")?;
    println!("Message: {}", decrypted.trim_end_matches(char::from(0)));
    Ok(())
}

fn main() {
    if let Err(msg) = main_result() {
        eprintln!("Error: {}", msg);
        exit(1);
    }
}
