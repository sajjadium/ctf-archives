disk_index = [
  {
    "filename": "json/disks/audit.json",
    "name": "Apple II Audit",
    "category": "Utility"
  },
  {
    "filename": "json/disks/dos33master.json",
    "name": "DOS 3.3 Master",
    "category": "System"
  },
  {
    "filename": "json/disks/prodos.json",
    "name": "ProDOS",
    "category": "System"
  }
];
