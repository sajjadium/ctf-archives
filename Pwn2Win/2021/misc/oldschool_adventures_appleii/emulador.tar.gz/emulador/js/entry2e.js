import { apple2 } from './main2e';
import * as UI from './ui/apple2';

export const Apple2 = { ...UI, apple2 };
