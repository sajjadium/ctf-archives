#include <unistd.h>

int usleep(useconds_t usec) {
  return 0;
}

