#include "api.h"
#ifdef SUPERCOP
    #include "crypto_sign.h"
#endif
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <NTL/ZZ.h>
#include <NTL/GF2X.h>
#include <NTL/GF2.h>
#ifdef SUPERCOP
    #include "randombytes.h"
#else
    #include "rng.h"
#endif
#include "fips202.h"

using namespace NTL;


/*
 * A function that uses SHAKE256
 * to map an arbitrary input message to a two-dimensional power index.
 * Each component of the power index is in the range 0 .. 2^((NN - 1)/2) - 2
 *
 * The message with a length of mlen bytes is "hashed" with SHAKE256
 * to e = (e[0], e[1])

 */
void hash_to_2D_power_index(ZZ *e,
                            const unsigned char *message,
                            unsigned long long mlen, const ZZ two_to_nm1half_m1) {

    unsigned char md_value_shake256[CRYPTO_SECRETKEYBYTES];

    shake256(md_value_shake256, CRYPTO_SECRETKEYBYTES, message, mlen);
    ZZFromBytes(e[0], md_value_shake256, CRYPTO_SECRETKEYBYTES_HALF);
    /* ensure that the value is in the range 0 .. 2^((NN-1)/2) - 2  */
    rem(e[0], e[0], two_to_nm1half_m1);

    ZZFromBytes(e[1], &md_value_shake256[CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);
    /* ensure that the value is in the range 0 .. 2^((NN-1)/2) - 2  */
    rem(e[1], e[1], two_to_nm1half_m1);
}


/*
 * These two bytes contain the first 11 bits of the binary expansion of Pi.
 * They serve for definition of the generator g.
 */
unsigned char bufPi[] = {36, 4};


/*
 * The operation of multiplication of two two-dimensional power indices
 */
void mul_powers(ZZ X[2], const ZZ A[2], const ZZ B[2], const ZZ two_to_nm1half_m1) {
    ZZ temp1, temp2;

    MulMod(temp1, A[0], B[0], two_to_nm1half_m1);
    MulMod(temp2, A[1], B[1], two_to_nm1half_m1);
    AddMod(X[0], temp1, temp2, two_to_nm1half_m1);

    MulMod(temp1, A[0], B[1], two_to_nm1half_m1);
    MulMod(temp2, A[1], B[0], two_to_nm1half_m1);
    AddMod(X[1], temp1, temp2, two_to_nm1half_m1);
}

/*
 * An operation of transposition of a circulant matrix.
 * It is the crucial Outer Automorphism that bootstraps the Discrete Logarithm Problem to
 * the problem of solving Exponential Congruences - A hard problem for which
 * there is no polynomial quantum algorithm.
 */
GF2X transpose(GF2X& x, const GF2X& a, long nn){
    GF2 temp;
    temp = a[0];
    reverse(x, a, nn-1);
    LeftShift(x, x, 1);
    trunc(x, x, nn);
    x[0] = temp;

    return x;
}

/*
 * Exponentiation with entropic two-dimensional power indices which are
 * equivalent to Exponential Congruences in an Entropoid Algebraic structure
 */
GF2X raise_to_2D_power(const GF2X& g, const ZZ A[2], const GF2XModulus& F) {
    GF2X res1, res2, res3;
    PowerMod(res1, g, A[0], F);
    PowerMod(res2, g, A[1], F);
    transpose(res3, res2, NN);
    MulMod(res2, res1, res3, F);

    return res2;
}


/*************************************************
* Name:        crypto_sign_keypair
*
* Description: Generates public and private key.
*
* Arguments:
*            unsigned char *pk: pointer to output public key (allocated
*                               array of CRYPTO_PUBLICKEYBYTES bytes)
*            unsigned char *sk: pointer to output private key (allocated
*                               array of CRYPTO_SECRETKEYBYTES bytes)
*
* Returns 0 (success)
**************************************************/
int crypto_sign_keypair(unsigned char *pk, unsigned char *sk) {

    /* the private key sk is just a sequence of randombytes */
    randombytes(sk, CRYPTO_SECRETKEYBYTES);

    /* but we will need to interpret those randombytes as elements */
    /* of the ring of non-singular circulant matrices of size NN x NN */
    /* NTL comes handy here with ready-made routines */
    GF2XModulus F;
    ZZ PrivateKey[2];

    /* We need to compute the value two_to_nm1half_m1 = 2^((NN-1)/2) - 1 */
    /* The arithmetic of two-dimensional power indices is performed modulus two_to_nm1half_m1 */
    ZZ two_to_nm1half_m1;
    ZZ one = ZZ(1);

    two_to_nm1half_m1 = ZZ(1);
    LeftShift(two_to_nm1half_m1, two_to_nm1half_m1, (NN-1)/2);
    sub(two_to_nm1half_m1, two_to_nm1half_m1, one);

    ZZFromBytes(PrivateKey[0], sk, CRYPTO_SECRETKEYBYTES_HALF);
    ZZFromBytes(PrivateKey[1], &sk[CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);

    /* ensure that the values of the PrivateKey sk are in the range 0 .. 2^((NN-1)/2) - 2  */
    rem(PrivateKey[0], PrivateKey[0], two_to_nm1half_m1);
    rem(PrivateKey[1], PrivateKey[1], two_to_nm1half_m1);

    BytesFromZZ(sk, PrivateKey[0], CRYPTO_SECRETKEYBYTES_HALF);
    BytesFromZZ(&sk[CRYPTO_SECRETKEYBYTES_HALF], PrivateKey[1], CRYPTO_SECRETKEYBYTES_HALF);

    /* Construct the generator GF2X g.
     * It was checked with external code in SageMath that this g is a generator for the
     * entropoid structures with NN = 103, 167, 263, 359, 479, 647, 863, 887, ...
    */
    GF2X g = GF2XFromBytes(bufPi, sizeof(bufPi)/sizeof(bufPi[0]));

    /*
     * Build GF2XModulus F == X^NN - 1, that we will use to perform a
     * "Modular Arithmetic with Pre-Conditioning" i.e. to work with
     * the circulant matrices but in an equivalent algebraic structure
     * of the quotient Ring ℤ[𝑥]/(𝑥^𝑛−1)
     *
    */
    GF2X f = GF2X((long)1);
    f = LeftShift(f, NN) + GF2X((long)1);
    build(F, f);

    /* compute the variable PublicKey and its byte array pk */
    GF2X PublicKey = raise_to_2D_power(g, PrivateKey, F);
    BytesFromGF2X(pk, PublicKey, CRYPTO_PUBLICKEYBYTES);

    return 0;
}

/*************************************************
* Name:        crypto_sign
*
* Description: Computes signed message
*
* Arguments:
*            unsigned char *sm:            pointer to output signed message (allocated
*                                          array with CRYPTO_BYTES + mlen bytes),
*            unsigned long long *smlen:    pointer to output length of signed message
*            const unsigned char *m:       pointer to input message to be signed
*            unsigned long long mlen:      length of input message
*            const unsigned char *sk:      pointer to the secret key
*
* Returns 0 (success)
**************************************************/
int crypto_sign(unsigned char *sm, unsigned long long *smlen,
                const unsigned char *m, unsigned long long mlen,
                const unsigned char *sk) {

    unsigned char *r_and_PublicKey_and_message;
    unsigned char *random_bytes_and_sk_and_message;
    unsigned char temp[CRYPTO_SECRETKEYBYTES_HALF];

    ZZ k[2], e[2], s[2], PrivateKey[2], tt[2];
    GF2X r;
    unsigned char r_in_bytes[CRYPTO_PUBLICKEYBYTES];
    unsigned char pk_local_re_computed[CRYPTO_PUBLICKEYBYTES];

    GF2XModulus F;

    /* compute the variable two_to_nm1half_m1 = 2^((NN - 1)/2) - 1 */
    /* The arithmetic of two-dimensional power indices is performed modulus two_to_nm1half_m1 */
    ZZ one = ZZ(1);
    ZZ two_to_nm1half_m1;

    two_to_nm1half_m1 = ZZ(1);
    LeftShift(two_to_nm1half_m1, two_to_nm1half_m1, (NN-1)/2);
    sub(two_to_nm1half_m1, two_to_nm1half_m1, one);

    ZZFromBytes(PrivateKey[0], sk, CRYPTO_SECRETKEYBYTES_HALF);
    ZZFromBytes(PrivateKey[1], &sk[CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);

    rem(PrivateKey[0], PrivateKey[0], two_to_nm1half_m1);
    rem(PrivateKey[1], PrivateKey[1], two_to_nm1half_m1);

    /* Construct the generator GF2X g.
     * It was checked with external code in SageMath that this g is a generator for the
     * entropoid structures with NN = 103, 167, 263, 359, 479, 647, 863, 887, ...
    */
    GF2X g = GF2XFromBytes(bufPi, sizeof(bufPi)/sizeof(bufPi[0]));

    /*
      * Build GF2XModulus F == X^NN - 1, that we will use to perform a
      * "Modular Arithmetic with Pre-Conditioning" i.e. to work with
      * the circulant matrices but in an equivalent algebraic structure
      * of the quotient Ring ℤ[𝑥]/(𝑥^𝑛−1)
      *
     */
    GF2X f = GF2X((long)1);
    f = LeftShift(f, NN) + GF2X((long)1);
    build(F, f);

    /* re-compute the variable PublicKey and its byte array pk_local_re_computed */
    GF2X PublicKey = raise_to_2D_power(g, PrivateKey, F);
    BytesFromGF2X(pk_local_re_computed, PublicKey, CRYPTO_PUBLICKEYBYTES);

    random_bytes_and_sk_and_message = (unsigned char *)malloc(2 * CRYPTO_SECRETKEYBYTES + mlen);
    randombytes(random_bytes_and_sk_and_message, CRYPTO_SECRETKEYBYTES);
    memcpy(&random_bytes_and_sk_and_message[CRYPTO_SECRETKEYBYTES], sk, CRYPTO_SECRETKEYBYTES);
    memcpy(&random_bytes_and_sk_and_message[2 * CRYPTO_SECRETKEYBYTES], m, mlen);
    hash_to_2D_power_index(k, random_bytes_and_sk_and_message, 2 * CRYPTO_SECRETKEYBYTES + mlen, two_to_nm1half_m1);

    r = raise_to_2D_power(g, k, F);
    BytesFromGF2X(r_in_bytes, r, CRYPTO_PUBLICKEYBYTES);

    r_and_PublicKey_and_message = (unsigned char *)malloc(2 * CRYPTO_PUBLICKEYBYTES + mlen);
    memcpy(r_and_PublicKey_and_message, r_in_bytes, CRYPTO_PUBLICKEYBYTES);
    memcpy(&r_and_PublicKey_and_message[CRYPTO_PUBLICKEYBYTES], &pk_local_re_computed, CRYPTO_PUBLICKEYBYTES);
    memcpy(&r_and_PublicKey_and_message[2 * CRYPTO_PUBLICKEYBYTES], m, mlen);

    hash_to_2D_power_index(e, r_and_PublicKey_and_message, 2 * CRYPTO_PUBLICKEYBYTES + mlen, two_to_nm1half_m1);

    mul_powers(tt, PrivateKey, e, two_to_nm1half_m1);
    SubMod(s[0], k[0], tt[0], two_to_nm1half_m1);
    SubMod(s[1], k[1], tt[1], two_to_nm1half_m1);

    /* Finally produce the signed message sm */
    memcpy(sm, m, mlen);
    (*smlen) = mlen;
    BytesFromZZ(temp, s[0], CRYPTO_SECRETKEYBYTES_HALF);
    memcpy(&sm[(*smlen)], temp, CRYPTO_SECRETKEYBYTES_HALF);
    (*smlen) += CRYPTO_SECRETKEYBYTES_HALF;
    BytesFromZZ(temp, s[1], CRYPTO_SECRETKEYBYTES_HALF);
    memcpy(&sm[(*smlen)], temp, CRYPTO_SECRETKEYBYTES_HALF);
    (*smlen) += CRYPTO_SECRETKEYBYTES_HALF;
    BytesFromZZ(temp, e[0], CRYPTO_SECRETKEYBYTES_HALF);
    memcpy(&sm[(*smlen)], temp, CRYPTO_SECRETKEYBYTES_HALF);
    (*smlen) += CRYPTO_SECRETKEYBYTES_HALF;
    BytesFromZZ(temp, e[1], CRYPTO_SECRETKEYBYTES_HALF);
    memcpy(&sm[(*smlen)], temp, CRYPTO_SECRETKEYBYTES_HALF);
    (*smlen) += CRYPTO_SECRETKEYBYTES_HALF;

    free(r_and_PublicKey_and_message);
    return 0;
}

/*************************************************
* Name:        crypto_sign_open
*
* Description: Verify a message signature
*
* Arguments:
*              - unsigned char *m:         pointer to original  message
*              - unsigned long long *mlen: pointer to length of original message
*              - const unsigned char *sm:  pointer to signed message
*              - unsigned long long smlen: length of signed message
*              - const unsigned char *pk: pointer to public key
*
* Returns 0 if signed message could be verified correctly and -1 otherwise
**************************************************/
int crypto_sign_open(unsigned char *m, unsigned long long *mlen,
                     const unsigned char *sm, unsigned long long smlen,
                     const unsigned char *pk) {

    unsigned char *r_verif_and_PublicKey_and_message;
    unsigned char pk_local_bytes[CRYPTO_PUBLICKEYBYTES];

    ZZ e[2], s[2], e_verification[2];
    GF2X r1, r2, PublicKey, r_verification;
    PublicKey = GF2XFromBytes(pk, CRYPTO_PUBLICKEYBYTES);
    memcpy(&pk_local_bytes, pk, CRYPTO_PUBLICKEYBYTES);

    memcpy(m, sm, smlen - CRYPTO_BYTES);
    (*mlen) = smlen - CRYPTO_BYTES;

    unsigned char r_verification_in_bytes[CRYPTO_PUBLICKEYBYTES];

    GF2XModulus F;

    /* re-compute the variable two_to_nm1half_m1 = 2^((NN - 1)/2) - 1 */
    ZZ one = ZZ(1);
    ZZ two_to_nm1half_m1;

    two_to_nm1half_m1 = ZZ(1);
    LeftShift(two_to_nm1half_m1, two_to_nm1half_m1, (NN-1)/2);
    sub(two_to_nm1half_m1, two_to_nm1half_m1, one);

    /* Re-Construct the generator GF2X g */
    GF2X g = GF2XFromBytes(bufPi, sizeof(bufPi)/sizeof(bufPi[0]));

    /* re-compute GF2XModulus F == X^NN - 1 */
    GF2X f = GF2X((long)1);
    f = LeftShift(f, NN) + GF2X((long)1);
    build(F, f);

    ZZFromBytes(s[0], &sm[(*mlen)], CRYPTO_SECRETKEYBYTES_HALF);
    /* check that the received signature components are exclusively in range 0 - 2^((NN - 1)/2) - 2 */
    if(compare(s[0], two_to_nm1half_m1) >= 0) return -1;

    ZZFromBytes(s[1], &sm[(*mlen) + CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);
    /* check that the received signature components are exclusively in range 0 - 2^((NN - 1)/2) - 2 */
    if(compare(s[1], two_to_nm1half_m1) >= 0) return -1;

    ZZFromBytes(e[0], &sm[(*mlen) + 2 * CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);
    /* check that the received signature components are exclusively in range 0 - 2^((NN - 1)/2) - 2 */
    if(compare(e[0], two_to_nm1half_m1) >= 0) return -1;

    ZZFromBytes(e[1], &sm[(*mlen) + 3 * CRYPTO_SECRETKEYBYTES_HALF], CRYPTO_SECRETKEYBYTES_HALF);
    /* check that the received signature components are exclusively in range 0 - 2^((NN - 1)/2) - 2 */
    if(compare(e[1], two_to_nm1half_m1) >= 0) return -1;

    r1 = raise_to_2D_power(g, s, F);
    r2 = raise_to_2D_power(PublicKey, e, F);
    MulMod(r_verification, r1, r2, F);
    BytesFromGF2X(r_verification_in_bytes, r_verification, CRYPTO_PUBLICKEYBYTES);

    r_verif_and_PublicKey_and_message = (unsigned char *)malloc(2 * CRYPTO_PUBLICKEYBYTES + (*mlen));
    memcpy(r_verif_and_PublicKey_and_message, r_verification_in_bytes, CRYPTO_PUBLICKEYBYTES);
    memcpy(&r_verif_and_PublicKey_and_message[CRYPTO_PUBLICKEYBYTES], pk_local_bytes, CRYPTO_PUBLICKEYBYTES);
    memcpy(&r_verif_and_PublicKey_and_message[2 * CRYPTO_PUBLICKEYBYTES], m, (*mlen));

    hash_to_2D_power_index(e_verification, r_verif_and_PublicKey_and_message, 2 * CRYPTO_PUBLICKEYBYTES + (*mlen), two_to_nm1half_m1);

    if (e[0] != e_verification[0]) return -1;
    if (e[1] != e_verification[1]) return -1;

    free(r_verif_and_PublicKey_and_message);
    return 0;
}

