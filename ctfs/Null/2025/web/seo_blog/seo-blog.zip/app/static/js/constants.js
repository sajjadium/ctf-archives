const CONSTANTS = {
    href: `${location.protocol}//${location.hostname}:${location.port}`,
}