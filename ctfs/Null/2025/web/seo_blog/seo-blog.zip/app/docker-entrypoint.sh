#!/bin/bash

/geckodriver --port=4444 &

/app/backend
