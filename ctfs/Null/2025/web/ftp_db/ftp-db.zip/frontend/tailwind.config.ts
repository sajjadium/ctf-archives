import type { Config } from "tailwindcss";

const config = {
  darkMode: "class",
} satisfies Config;

export default config;
