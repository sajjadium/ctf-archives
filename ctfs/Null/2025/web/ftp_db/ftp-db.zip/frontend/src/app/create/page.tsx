import DashboardFragment from "@/fragments/dashboard";

export default function SearchPage() {
  return <DashboardFragment initialTab="create" />;
}
