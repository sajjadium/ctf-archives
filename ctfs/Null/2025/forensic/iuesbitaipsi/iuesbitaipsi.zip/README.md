name: iuesbitaipsi

category: Forensics

dificulty: easy

description: ayay uat is iuor taip for iuesbi?