The verdict existed before your answer did.
