const express = require("express");
const puppeteer = require("puppeteer");
const app = express();

// Read admin password from environment (fallback to admin123)
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";

app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.post("/visit", async (req, res) => {
  const userid = req.body.userid;

  if (!userid) {
    return res.send("userid is required");
  }

  const browser = await puppeteer.launch({
    headless: "new",
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-features=StrictOriginIsolation",
      "--ignore-certificate-errors",
      "--allow-running-insecure-content",
    ],
    ignoreHTTPSErrors: true,
    acceptInsecureCerts: true,
  });

  try {
    const page = await browser.newPage();

    // Login first
    await page.goto("http://web:8080/login", {
      waitUntil: "domcontentloaded",
      timeout: 10000,
    });

    // Fill login form
    await page.type('input[name="username"]', "admin");
    await page.type('input[name="password"]', ADMIN_PASSWORD);

    // Submit and wait redirect
    await Promise.all([
      page.click('button[type="submit"]'),
      page.waitForNavigation({ waitUntil: "networkidle0" }),
    ]);

    // Visit target page
    await page.goto(`http://web:8080/user/${userid}`, {
      waitUntil: "networkidle0",
      timeout: 5000,
    });

    await page.waitForTimeout(3000);

    await browser.close();
    res.send("Bot visited the page successfully");
  } catch (err) {
    await browser.close();
    res.send("Error: " + err.message);
  }
});

app.listen(3000, () => {
  console.log("Bot server running on port 3000");
});
