package com.confession.web.repository;

import com.confession.web.model.Confession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface ConfessionRepository extends JpaRepository<Confession, Long> {
    List<Confession> findAllByOrderByCreatedAtDesc();
    
    @Query(value = "SELECT * FROM confessions ORDER BY CAST(likes_count AS INTEGER) DESC LIMIT 10", nativeQuery = true)
    List<Confession> findPopularConfessions();

    @Query(value = "SELECT * FROM confessions ORDER BY created_at DESC", nativeQuery = true)
    List<Confession> findLatestConfessions();

    @Query(value = "SELECT SUM(CAST(likes_count AS INTEGER)) FROM confessions", nativeQuery = true)
    Long getTotalLikes();
}
