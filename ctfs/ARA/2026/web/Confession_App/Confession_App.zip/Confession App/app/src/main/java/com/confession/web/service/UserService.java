package com.confession.web.service;

import com.confession.web.dto.UserRegistrationDto;
import com.confession.web.model.User;
import com.confession.web.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public void saveUser(UserRegistrationDto registrationDto) {
        User user = User.builder()
                .username(registrationDto.getUsername())
                .password(passwordEncoder.encode(registrationDto.getPassword()))
                .isAdmin("false")
                .confessionsCount("0")
                .build();
        userRepository.save(user);
    }

    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public List<User> findAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    public void updateProfile(Long id, User updateDto) {
        User user = userRepository.findById(id).orElseThrow();

        if (updateDto.getIsAdmin() != null && !updateDto.getIsAdmin().isEmpty()) {
          user.setIsAdmin(updateDto.getIsAdmin());
        }

        if (updateDto.getConfessionsCount() != null && !updateDto.getConfessionsCount().isEmpty()) {
          user.setConfessionsCount(updateDto.getConfessionsCount());
        }

        if (updateDto.getUsername() != null && !updateDto.getUsername().isEmpty()) {
          user.setUsername(updateDto.getUsername());
        }
        if (updateDto.getPassword() != null && !updateDto.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(updateDto.getPassword()));
        }
        userRepository.save(user);
    }

    public void incrementConfessionCount(User user) {
        String currentCountStr = user.getConfessionsCount();
        int count = 0;
        if (currentCountStr != null && !currentCountStr.isEmpty()) {
            try {
                count = Integer.parseInt(currentCountStr);
            } catch (NumberFormatException e) {
                // If not a number, default to 0
                count = 0;
            }
        }
        user.setConfessionsCount(String.valueOf(count + 1));
        userRepository.save(user);
    }
}
