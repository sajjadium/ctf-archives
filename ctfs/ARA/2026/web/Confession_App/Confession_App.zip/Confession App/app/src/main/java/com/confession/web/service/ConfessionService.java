package com.confession.web.service;

import com.confession.web.dto.ConfessionDto;
import com.confession.web.model.Confession;
import com.confession.web.model.User;
import com.confession.web.repository.ConfessionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ConfessionService {

    private final ConfessionRepository confessionRepository;
    private final UserService userService;

    @Transactional
    public void createConfession(ConfessionDto confessionDto, User author) {
        Confession confession = Confession.builder()
                .content(confessionDto.getContent())
                .author(author)
                .build();
        confessionRepository.save(confession);
        userService.incrementConfessionCount(author);
    }

    public List<Confession> getAllConfessions() {
        return confessionRepository.findAllByOrderByCreatedAtDesc();
    }

    public List<Confession> getPopularConfessions() {
        return confessionRepository.findPopularConfessions();
    }

    public List<Confession> getLatestConfessions() {
        return confessionRepository.findLatestConfessions();
    }

    @Transactional
    public void likeConfession(Long confessionId) {
        Confession confession = confessionRepository.findById(confessionId).orElseThrow();
        int currentLikes = (confession.getLikesCount() == null) ? 0 : Integer.parseInt(confession.getLikesCount());
        confession.setLikesCount(String.valueOf(currentLikes + 1));
        confessionRepository.save(confession);
    }

    public long getTotalConfessions() {
        return confessionRepository.count();
    }

    public long getTotalLikes() {
        Long sum = confessionRepository.getTotalLikes();
        return sum != null ? sum : 0;
    }
}
