package com.confession.web.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(name = "is_admin", length = 600, nullable = false)
    private String isAdmin; // "true" or "false"

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "confessions_count", length = 20)
    private String confessionsCount; 

    @PrePersist
    public void prePersist() {
        if (confessionsCount == null) {
            confessionsCount = "0";
        }
        if (isAdmin == null) {
            isAdmin = "false";
        }
    }
}
