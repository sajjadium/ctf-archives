package com.confession.web.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class ConfessionDto {
    @NotEmpty(message = "Confession content should not be empty")
    private String content;
}
