package com.confession.web.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Data
public class UserProfileUpdateDto {
    private Long id;
    
    @NotEmpty(message = "Username should not be empty")
    private String username;
    
    private String password; // Optional update
}
