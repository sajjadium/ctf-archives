package com.confession.web.controller;

import com.confession.web.dto.ConfessionDto;
import com.confession.web.model.Confession;
import com.confession.web.model.User;
import com.confession.web.service.ConfessionService;
import com.confession.web.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
@RequiredArgsConstructor
public class ConfessionController {

    private final ConfessionService confessionService;
    private final UserService userService;

    @GetMapping("/")
    public String index(Model model) {
        List<Confession> popular = confessionService.getPopularConfessions();
        List<Confession> latest = confessionService.getLatestConfessions();
        model.addAttribute("popular", popular);
        model.addAttribute("latest", latest);
        model.addAttribute("confessionDto", new ConfessionDto());
        return "confession/list";
    }

    @PostMapping("/confession/like/{id}")
    public String likeConfession(@PathVariable Long id) {
        confessionService.likeConfession(id);
        return "redirect:/";
    }

    @PostMapping("/confession/create")
    public String createConfession(@Valid @ModelAttribute("confessionDto") ConfessionDto confessionDto,
                                   BindingResult result,
                                   @AuthenticationPrincipal UserDetails userDetails,
                                   Model model) {
        if (result.hasErrors()) {
            List<Confession> confessions = confessionService.getAllConfessions();
            model.addAttribute("confessions", confessions);
            return "confession/list";
        }

        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        confessionService.createConfession(confessionDto, user);
        return "redirect:/?success";
    }
}
