package com.confession.web.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.confession.web.model.User;
import com.confession.web.service.ConfessionService;
import com.confession.web.service.UserService;
import com.lowagie.text.DocumentException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.dialect.SpringStandardDialect;
import org.thymeleaf.templateresolver.StringTemplateResolver;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Controller
public class AdminReportController {

    private final UserService userService;
    private final ConfessionService confessionService;
    private final TemplateEngine templateEngine;

    public AdminReportController(UserService userService, ConfessionService confessionService, TemplateEngine templateEngine) {
        this.userService = userService;
        this.confessionService = confessionService;
        this.templateEngine = templateEngine;
    }

    @GetMapping("/admin/report")
    public String showReportForm() {
        return "user/report_form";
    }

    @PostMapping(value = "/admin/report/generate")
    public ResponseEntity<byte[]> generateReport(@RequestBody String body) throws IOException, DocumentException {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> payload;

        payload = mapper.readValue(body, new TypeReference<Map<String, String>>() {});

        String title = payload.get("title");
        List<User> users = userService.findAllUsers();
        long totalConfessions = confessionService.getTotalConfessions();
        long totalLikes = confessionService.getTotalLikes();
        
        String htmlContent = "<html><body>" +
                "<h1>Report Title: " + title + "</h1>" +
                "<h2>Total Users: " + users.size() + "</h2>" +
                "<h2>Total Confessions: " + totalConfessions + "</h2>" +
                "<h2>Total Likes: " + totalLikes + "</h2>" +
                "<h3>User Summary</h3>" +
                "<table><tr><th>Username</th><th>Confessions Count</th></tr>";
        
        for (User u : users) {
            htmlContent += "<tr><td>" + u.getUsername() + "</td><td>" + u.getConfessionsCount() + "</td></tr>";
        }
        
        htmlContent += "</table></body></html>";

        TemplateEngine stringEngine = new TemplateEngine();
        stringEngine.setDialects(java.util.Collections.singleton(new SpringStandardDialect()));
        StringTemplateResolver resolver = new StringTemplateResolver();
        stringEngine.setTemplateResolver(resolver);

        Context context = new Context();
        context.setVariable("users", users);
        String processedHtml = stringEngine.process(htmlContent, context);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ITextRenderer renderer = new ITextRenderer();
        renderer.setDocumentFromString(processedHtml);
        renderer.layout();
        renderer.createPDF(baos);

        byte[] pdfBytes = baos.toByteArray();

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=report.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
