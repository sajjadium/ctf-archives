package com.confession.web.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "confessions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Confession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(columnDefinition = "TEXT", nullable = false)
    private String content;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id")
    private User author; // To track who created it, but can be displayed anonymously

    @Column(name = "likes_count")
    private String likesCount = "0";

    @PrePersist
    public void prePersist() {
        if (likesCount == null) {
            likesCount = "0";
        }
    }
}
