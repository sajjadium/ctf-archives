package com.confession.web.controller;

import com.confession.web.model.User;
import com.confession.web.service.UserService;
import com.confession.web.dto.UserProfileUpdateDto;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.util.Base64;
import java.security.SecureRandom;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;


import java.util.List;

@Controller
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private static final SecureRandom RANDOM = new SecureRandom();

    @InitBinder({"user"})
      public void initBinder(WebDataBinder binder) {
          binder.setDisallowedFields(new String[]{"username", "id", "isAdmin"});
    }

    @GetMapping("/profile")
    public String showProfileForm(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        UserProfileUpdateDto updateDto = new UserProfileUpdateDto();
        updateDto.setId(user.getId());
        updateDto.setUsername(user.getUsername());
        model.addAttribute("user", updateDto);
        return "user/profile";
    }

    @PostMapping("/profile/update")
    public String updateProfile(@ModelAttribute("user") User updateDto,
                                BindingResult result,
                                @AuthenticationPrincipal UserDetails userDetails,
                                Model model) {
       
        if (result.hasErrors()) {
            model.addAttribute("user", updateDto);
            return "user/profile";
        }

        User user = userService.findByUsername(userDetails.getUsername()).orElseThrow();


        userService.updateProfile(user.getId(), updateDto);
        return "redirect:/profile?success";
    }

    @GetMapping("/admin/users")
    public String listUsers(Model model) {
        List<User> users = userService.findAllUsers();
        model.addAttribute("users", users);
        return "user/list";
    }

    @GetMapping("/user/{id}")
    public String userDetail(@PathVariable Long id, @AuthenticationPrincipal UserDetails userDetails, Model model, HttpServletResponse response) {
        User loggedInUser = userService.findByUsername(userDetails.getUsername()).orElseThrow();
        User targetUser = userService.findById(id).orElseThrow();

        if (!loggedInUser.getId().equals(id) && loggedInUser.getId() != 1) {
            return "redirect:/"; // Access denied
        }

        byte[] nonceBytes = new byte[16];
            RANDOM.nextBytes(nonceBytes);
            String nonce = Base64.getEncoder().encodeToString(nonceBytes);
            response.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self' 'nonce-" + nonce + "'; style-src 'self' 'nonce-" + nonce + "'; connect-src *; ");
            model.addAttribute("cspNonce", nonce);

        model.addAttribute("user", targetUser);
        return "user/detail";
    }
}
