// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "./IERC20.sol";

contract BridgeMint {
    IERC20 public usdc;
    address public relayer;
    
    mapping(uint256 => bool) public usedNonces;
    
    event WithdrawalExecuted(
        uint256 indexed withdrawalId,
        uint256 amount,
        address indexed recipient
    );
    
    constructor(address _usdc, address _relayer) {
        usdc = IERC20(_usdc);
        relayer = _relayer;
    }
    
    function executeWithdrawal(
        uint256 withdrawalId,
        uint256 amount,
        address recipient,
        bytes memory signature
    ) external {
        require(!usedNonces[withdrawalId], "Already used");
        
        bytes32 hash = keccak256(abi.encodePacked(
            "\x19Ethereum Signed Message:\n32",
            keccak256(abi.encodePacked(amount, recipient))
        ));
        
        (uint8 v, bytes32 r, bytes32 s) = splitSignature(signature);
        address signer = recoverSigner(hash, v, r, s);
        require(signer == relayer, "Invalid signer");
        
        usedNonces[withdrawalId] = true;
        usdc.transfer(recipient, amount);
        
        emit WithdrawalExecuted(withdrawalId, amount, recipient);
    }
    
    function splitSignature(bytes memory sig) 
        internal pure returns (uint8 v, bytes32 r, bytes32 s) 
    {
        require(sig.length == 65, "Invalid signature length");
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
    }
    
    function recoverSigner(bytes32 hash, uint8 v, bytes32 r, bytes32 s)
        internal pure returns (address)
    {
        require(v >= 27 && v <= 28, "Invalid v");
        return ecrecover(hash, v, r, s);
    }
    
    function getBalance() external view returns (uint256) {
        return usdc.balanceOf(address(this));
    }
}
