// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

import "./IERC20.sol";

contract BridgeLock {
    IERC20 public usdc;
    address public relayer;
    uint256 public withdrawalCounter;
    
    event WithdrawalApproved(
        uint256 indexed withdrawalId,
        uint256 amount,
        address indexed recipient,
        bytes signature
    );
    
    constructor(address _usdc, address _relayer) {
        usdc = IERC20(_usdc);
        relayer = _relayer;
        withdrawalCounter = 0;
    }
    
    function deposit(uint256 amount, address recipient, bytes memory signature) external {
        usdc.transferFrom(msg.sender, address(this), amount);
        withdrawalCounter++;
        
        emit WithdrawalApproved(
            withdrawalCounter,
            amount,
            recipient,
            signature
        );
    }
    
    function getWithdrawalCount() external view returns (uint256) {
        return withdrawalCounter;
    }
}
