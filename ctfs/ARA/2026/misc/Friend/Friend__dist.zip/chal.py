from typing import Dict, Optional, Tuple
import json
import os
import subprocess
import sys
from web3 import Web3
from eth_account.messages import encode_defunct


def log_debug(msg: str):
    print(msg, file=sys.stderr)


DEPLOYER_PRIVATE_KEY = os.environ["DEPLOYER_PRIVATE_KEY"]
ANVIL_ENDPOINTS = json.loads(os.environ["ANVIL_ENDPOINTS"])
CHAIN_A_ENDPOINT = ANVIL_ENDPOINTS[0]
CHAIN_B_ENDPOINT = ANVIL_ENDPOINTS[1]

INITIAL_BRIDGE_LIQUIDITY = 10000 * 10**6
PLAYER_STARTING_ETH = 1 * 10**18
DECOY_AMOUNT = 500 * 10**6


def get_relayer_account(w3: Web3):
    return w3.eth.account.from_key(DEPLOYER_PRIVATE_KEY)


def sign_withdrawal_message(w3: Web3, amount: int, recipient: str) -> bytes:
    encoded_data = Web3.solidity_keccak(["uint256", "address"], [amount, recipient])
    message = encode_defunct(encoded_data)
    relayer = get_relayer_account(w3)
    signed = relayer.sign_message(message)
    return signed.signature


def deploy_contract(w3: Web3, account, contract_name: str, constructor_args=None):
    subprocess.run(
        ["/home/ctf/.foundry/bin/forge", "build"],
        check=True,
        capture_output=True,
        cwd=os.path.dirname(os.path.abspath(__file__)),
    )

    artifact_path = f"out/{contract_name}.sol/{contract_name}.json"
    with open(artifact_path, "r") as f:
        artifact = json.load(f)

    bytecode = artifact["bytecode"]["object"]
    abi = artifact["abi"]

    contract_factory = w3.eth.contract(abi=abi, bytecode=bytecode)

    if constructor_args:
        tx = contract_factory.constructor(*constructor_args).build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )
    else:
        tx = contract_factory.constructor().build_transaction(
            {
                "from": account.address,
                "nonce": w3.eth.get_transaction_count(account.address),
            }
        )

    signed = account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

    return w3.eth.contract(address=receipt["contractAddress"], abi=abi)


def fund_account(w3: Web3, from_account, to_address: str, amount: int):
    tx = {
        "from": from_account.address,
        "to": to_address,
        "value": amount,
        "nonce": w3.eth.get_transaction_count(from_account.address),
        "gas": 21000,
        "gasPrice": w3.eth.gas_price,
    }
    signed = from_account.sign_transaction(tx)
    tx_hash = w3.eth.send_raw_transaction(signed.raw_transaction)
    w3.eth.wait_for_transaction_receipt(tx_hash)


def start() -> Dict:
    player_private_key = os.environ["PLAYER_PRIVATE_KEY"]
    setup_address = os.environ["SETUP_ADDRESS"]

    w3_a = Web3(Web3.HTTPProvider(CHAIN_A_ENDPOINT))
    w3_b = Web3(Web3.HTTPProvider(CHAIN_B_ENDPOINT))

    player_account_a = w3_a.eth.account.from_key(player_private_key)
    player_account_b = w3_b.eth.account.from_key(player_private_key)

    deployer_a = w3_a.eth.account.from_key(DEPLOYER_PRIVATE_KEY)
    deployer_b = w3_b.eth.account.from_key(DEPLOYER_PRIVATE_KEY)

    log_debug(f"Deploying to Chain A: {CHAIN_A_ENDPOINT}")
    log_debug(f"Deploying to Chain B: {CHAIN_B_ENDPOINT}")
    log_debug(f"Player address: {player_account_a.address}")

    log_debug("Deploying USDC on Chain A...")
    usdc_a = deploy_contract(w3_a, deployer_a, "USDC")

    log_debug("Deploying BridgeLock on Chain A...")
    relayer_a = get_relayer_account(w3_a)
    bridge_lock = deploy_contract(
        w3_a, deployer_a, "BridgeLock", [usdc_a.address, relayer_a.address]
    )

    log_debug("Deploying USDC on Chain B...")
    usdc_b = deploy_contract(w3_b, deployer_b, "USDC")

    log_debug("Deploying BridgeMint on Chain B...")
    relayer_b = get_relayer_account(w3_b)
    bridge_mint = deploy_contract(
        w3_b, deployer_b, "BridgeMint", [usdc_b.address, relayer_b.address]
    )

    log_debug("Funding player with ETH on both chains...")
    fund_account(w3_a, deployer_a, player_account_a.address, PLAYER_STARTING_ETH)
    fund_account(w3_b, deployer_b, player_account_b.address, PLAYER_STARTING_ETH)

    log_debug(
        f"Funding BridgeMint with {INITIAL_BRIDGE_LIQUIDITY / 10**6} USDC on Chain B..."
    )
    mint_tx = usdc_b.functions.mint(
        bridge_mint.address, INITIAL_BRIDGE_LIQUIDITY
    ).build_transaction(
        {
            "from": deployer_b.address,
            "nonce": w3_b.eth.get_transaction_count(deployer_b.address),
            "gas": 100000,
        }
    )
    signed_mint = deployer_b.sign_transaction(mint_tx)
    mint_tx_hash = w3_b.eth.send_raw_transaction(signed_mint.raw_transaction)
    w3_b.eth.wait_for_transaction_receipt(mint_tx_hash)

    log_debug(
        f"Minting {DECOY_AMOUNT / 10**6} USDC to deployer on Chain A for deposit..."
    )
    usdc_mint_tx = usdc_a.functions.mint(
        deployer_a.address, DECOY_AMOUNT
    ).build_transaction(
        {
            "from": deployer_a.address,
            "nonce": w3_a.eth.get_transaction_count(deployer_a.address),
            "gas": 100000,
        }
    )
    signed_usdc_mint = deployer_a.sign_transaction(usdc_mint_tx)
    usdc_mint_tx_hash = w3_a.eth.send_raw_transaction(signed_usdc_mint.raw_transaction)
    w3_a.eth.wait_for_transaction_receipt(usdc_mint_tx_hash)

    signature = sign_withdrawal_message(w3_a, DECOY_AMOUNT, player_account_a.address)

    log_debug(
        "Creating withdrawal event on Chain A (signature sent to player address)..."
    )
    deposit_tx = bridge_lock.functions.deposit(
        DECOY_AMOUNT, player_account_a.address, signature
    ).build_transaction(
        {
            "from": deployer_a.address,
            "nonce": w3_a.eth.get_transaction_count(deployer_a.address),
            "gas": 200000,
        }
    )
    signed_deposit = deployer_a.sign_transaction(deposit_tx)
    deposit_tx_hash = w3_a.eth.send_raw_transaction(signed_deposit.raw_transaction)
    w3_a.eth.wait_for_transaction_receipt(deposit_tx_hash)

    log_debug(
        f"Withdrawal signature created: amount={DECOY_AMOUNT}, recipient={player_account_a.address}"
    )
    log_debug(
        "Player can now replay this signature on Chain B with different withdrawalId values"
    )

    result = {
        "anvilconfig": {
            "setup_address": setup_address,
            "player_private_key": player_private_key,
            "chains": [
                {
                    "chainId": 1,
                    "name": "Chain A",
                    "rpc": CHAIN_A_ENDPOINT,
                    "setup_address": bridge_lock.address,
                    "usdc_address": usdc_a.address,
                },
                {
                    "chainId": 2,
                    "name": "Chain B",
                    "rpc": CHAIN_B_ENDPOINT,
                    "setup_address": bridge_mint.address,
                    "usdc_address": usdc_b.address,
                },
            ],
            "chain_a_usdc": usdc_a.address,
            "chain_b_usdc": usdc_b.address,
            "chain_a_bridge_lock": bridge_lock.address,
            "chain_b_bridge_mint": bridge_mint.address,
        },
        "challenge_info": {
            "target_balance": 10000,
            "target_token": "USDC on Chain B",
            "initial_bridge_liquidity": INITIAL_BRIDGE_LIQUIDITY,
        },
    }

    print(json.dumps(result, indent=2))
    return result


def precompile() -> Dict:
    return dict()


def genesis() -> Optional[Dict]:
    return None


def on_new_block():
    pass


def on_incoming_tx() -> Tuple[int, str]:
    return 200, ""


def on_tx():
    pass


def is_solved(instance) -> bool:
    try:
        w3_b = Web3(Web3.HTTPProvider(instance.anvil_endpoints[1]))

        player_account = w3_b.eth.account.from_key(instance.player_private_key)

        anvil_config = instance.anvil_config
        chains = anvil_config.get("chains", [])
        if len(chains) < 2:
            return False

        chain_b_usdc = chains[1].get(
            "usdc_address", anvil_config.get("chain_b_usdc", "")
        )
        chain_b_bridge_mint = chains[1].get(
            "setup_address", anvil_config.get("chain_b_bridge_mint", "")
        )

        if not chain_b_bridge_mint or not chain_b_usdc:
            return False

        with open("out/USDC.sol/USDC.json", "r") as f:
            usdc_artifact = json.load(f)

        usdc_contract = w3_b.eth.contract(
            address=chain_b_usdc, abi=usdc_artifact["abi"]
        )

        player_balance = usdc_contract.functions.balanceOf(
            player_account.address
        ).call()

        return player_balance >= INITIAL_BRIDGE_LIQUIDITY

    except Exception as e:
        log_debug(f"Error checking solve state: {e}")
        return False


if __name__ == "__main__":
    start()
