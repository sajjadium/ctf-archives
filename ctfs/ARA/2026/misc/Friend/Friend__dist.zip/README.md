## Friend

You have friend. He sent you 500 USDC.
But you know he has ten thousand more, somewhere.