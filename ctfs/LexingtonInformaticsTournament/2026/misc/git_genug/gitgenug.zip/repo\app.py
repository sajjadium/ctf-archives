def main():
    print("Hello, world!")

if __name__ == "__main__":
    main()

def greet(name):
    print(f"Hello, {name}!")
