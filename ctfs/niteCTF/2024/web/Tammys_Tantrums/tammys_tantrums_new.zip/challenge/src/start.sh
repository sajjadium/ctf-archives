#!/bin/bash
mongod --fork --logpath /var/log/mongodb.log
node initDb.js &
npm run start
