# Setup

1. Build dockerfile `docker build -t nite-chall`
2. Run `docker run -p 5002:5002 -t nite-chall`

Note: It takes a while to build the docker image because rust is slow to compile

Good luck :)
