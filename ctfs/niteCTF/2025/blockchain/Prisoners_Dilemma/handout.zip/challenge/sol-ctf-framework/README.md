# Solana CTF Framework

## Usage

To get started, just add the following line to the `dependencies` section in your `Cargo.toml`:
```toml
[dependencies]
sol-ctf-framework = "0.1.0"
```

## What is this for?

This crate is meant to be used to create an environment for capture the flag players to solve challenges related to solana.

