

To test locally : 

- Build network


```bash
docker network create carseat-network
```

- build bots 

```bash
docker build -t web ./app
docker build -t bot ./bot
```

- Run containers

**Web Container:**
```bash
docker run -d \
  --name web \
  --network carseat-network \
  -p 3000:3000 \
  -e PORT=3000 \
  -e FLAG="nite{test_flag}" \
  -e BOT_SECRET="supersecret" \
  -e BOT_URL="http://bot:4000" \
  web
```

**Bot Container:**
```bash
docker run -d \
  --name bot \
  --network carseat-network \
  -p 4000:4000 \
  -e PORT=4000 \
  -e PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true \
  -e PUPPETEER_EXECUTABLE_PATH="/app/chrome-linux/chrome" \
  -e VICTIM_URL="http://web:3000" \
  -e BOT_SECRET="supersecret" \
  bot
```


 http://localhost:3000

