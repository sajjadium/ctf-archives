import crypto from 'crypto';
import _wasm from "./secret.wasm" with { loader: "file" };
import { embeddedFiles, Glob } from 'bun';
import init, { get_key, get_cid, get_flags } from './secret';
await init({ module_or_path: await embeddedFiles[0].arrayBuffer() });

const ENC_ALGO = 'aes-256-gcm';
const ENC_SEC = crypto.randomBytes(32);
const JWT_EXP = 60 * 5;
const FLAGS = {};
export const IMPOSSIBLE = 69;
export const TOTAL_TO_SOLVE = 100;
export const ALL_FLAGS = Array.from(new Glob('*').scanSync('flags')).map(f => f.substring(0, 2)).sort();

export function get_flag(jti, index) {
    if (!FLAGS[jti]) return null;
    if (index < 0 || index >= FLAGS[jti].length) return null;
    return FLAGS[jti][index];
}

export function get_jwt(KEY, solved, progress, sub) {
    if (!KEY) {
        KEY = get_key();
        solved = [];
        progress = 0;
        sub = crypto.randomUUID();
    }

    if (progress >= TOTAL_TO_SOLVE) return {
        progress,
        solved: true
    }

    let [cid, salt] = get_cid(KEY);
    while (solved.includes(cid)) [cid, salt] = get_cid(KEY);
    const flags = get_flags(KEY, progress);
    const nonce = crypto.randomBytes(16);
    const iv = crypto.randomBytes(12);
    const h = crypto.createHash('sha256');
    for (const fi of flags) {
        h.update(fi.toString() + ";");
    }
    h.update(cid + ';');
    h.update(salt + ';')
    h.update(nonce);
    const checksum = h.digest('base64');
    const jti = crypto.randomUUID();
    const exp = Math.floor(Date.now() / 1000) + JWT_EXP;
    FLAGS[jti] = flags;

    const secret = crypto.createCipheriv(ENC_ALGO, ENC_SEC, iv);
    const info = JSON.stringify({
        key: KEY,
        solved: Array.from(solved),
        cid,
        salt,
    });
    const enc = Buffer.concat([secret.update(info), secret.final()]);

    const payload = {
        sub,
        progress,
        iv: iv.toString('base64'),
        nonce: nonce.toString('base64'),
        enc: enc.toString('base64'),
        checksum: checksum,
        jti,
        exp,
        tag: secret.getAuthTag().toString('base64'),
        imp: progress >= IMPOSSIBLE ? 1 : 0,
    };
    return payload
}

export function submit_answer(player_resp, payload) {
    if (!FLAGS[payload.jti]) return false;
    const encrypted = Buffer.from(payload.enc, 'base64');
    const nonce = Buffer.from(payload.nonce, 'base64');
    const iv = Buffer.from(payload.iv, 'base64');
    const decipher = crypto.createDecipheriv(ENC_ALGO, ENC_SEC, iv);
    decipher.setAuthTag(Buffer.from(payload.tag, 'base64'));
    const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
    const info = JSON.parse(decrypted.toString());
    const { key, solved, cid, salt } = info;

    const h = crypto.createHash('sha256');
    for (const fi of player_resp) h.update(fi.toString() + ";");
    h.update(cid + ';');
    h.update(salt + ';')
    h.update(nonce);
    const checksum = h.digest('base64');

    if (checksum !== payload.checksum) {
        log(payload.ip, 'fail checksum', `prog=${payload.progress}/${TOTAL_TO_SOLVE}`, `truth=${Array.from(FLAGS[payload.jti]).map(f => ALL_FLAGS[f])}`, `ans=${player_resp.map(f => ALL_FLAGS[f])}`);
        return false;
    }
    log(payload.ip, 'success checksum', `prog=${payload.progress + 1}/${TOTAL_TO_SOLVE}`, `truth=${Array.from(FLAGS[payload.jti]).map(f => ALL_FLAGS[f])}`);

    delete FLAGS[payload.jti];
    solved.push(cid);
    return get_jwt(key, solved, payload.progress + 1, payload.sub);
}

export function log(...args) {
    console.log(`[${new Date().toISOString()}]`, ...args);
}