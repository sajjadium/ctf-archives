import { Hono } from "hono";
import { sign, verify } from "hono/jwt";
import { getCookie, setCookie } from "hono/cookie";
import { serveStatic } from "hono/bun";
import { randomBytes } from "crypto";
import sharp from "sharp";
import { rateLimiter } from "hono-rate-limiter";
import { getConnInfo } from "hono/bun";
import {
  get_jwt,
  get_flag,
  submit_answer,
  TOTAL_TO_SOLVE,
  IMPOSSIBLE,
  ALL_FLAGS,
} from "./enc.js";

const app = new Hono();
const SECRET = randomBytes(128).toString("hex");
const COOKIE_OPTIONS = {
  path: "/",
  httpOnly: true,
  maxAge: 60 * 60,
};

async function getImage(idx, level = 0) {
  let path = ALL_FLAGS[idx];
  let image = sharp("flags/" + path + ".png");
  if (level < 5) return image;
  image = image.blur(5);
  if (level < 10) return image;
  const scale = Math.atan((level - 10) / 20) / Math.PI / Math.E;
  const transform = [
    1 + Math.random() * scale - scale / 2,
    Math.random() * scale - scale / 2,
    Math.random() * scale - scale / 2,
    1 + Math.random() * scale - scale / 2,
  ];
  image = image.affine(transform);
  if (level < 20) return image;

  const { data, info } = await image
    .png()
    .toBuffer({ resolveWithObject: true });
  const { width, height } = info;

  if (level < 30)
    return sharp({
      create: {
        width,
        height,
        channels: 3,
        noise: {
          type: "gaussian",
          mean: 50,
          sigma: 30,
        },
      },
    })
      .png()
      .composite([{ input: data, blend: "add" }]);
  if (level < IMPOSSIBLE)
    return sharp({
      create: {
        width,
        height,
        channels: 3,
        noise: {
          type: "gaussian",
          mean: 128,
          sigma: 30,
        },
      },
    })
      .png()
      .composite([{ input: data, blend: "add" }]);
  // HAHAHA YOU THOUGHT YOU COULD SOLVE THIS???
  return sharp({
    create: {
      width: 200,
      height: 200,
      channels: 3,
      noise: {
        type: "gaussian",
        mean: 128,
        sigma: 30,
      },
    },
  }).png();
}
const serveFlag = serveStatic({ path: "./flag.gif" });
async function serveImage(c) {
  let jti = c.get("user").jti;
  if (!jti) return c.json({ message: "Unauthorized" }, 401);
  let index = c.req.param("idx");
  if (!index) return c.json({ message: "Invalid index" }, 400);
  index = parseInt(index);
  if (isNaN(index) || index < 0 || index >= 4)
    return c.json({ message: "Invalid index" }, 400);
  let idx = get_flag(jti, index);
  if (isNaN(idx)) return c.json({ message: "Invalid index" }, 400);
  let progress = c.get("user").progress;
  let image = await (await getImage(idx, progress)).toBuffer();
  return c.body(image, 200, {
    "Content-Type": "image/png",
  });
}
const IP_LIMIT = rateLimiter({
  windowMs: 60 * 1000,
  limit: 1000,
  standardHeaders: "draft-6",
  keyGenerator: (c) => getConnInfo(c).remote.address,
});
app.use("*", IP_LIMIT);
app.use("*", async (c, next) => {
  const token = getCookie(c, "token");
  try {
    if (token) {
      const user = await verify(token, SECRET);
      if (user) {
        c.set("user", user);
        await next();
        return;
      }
    }
  } catch (e) {}
  const payload = get_jwt();
  payload.ip = getConnInfo(c).remote.address;
  setCookie(c, "token", await sign(payload, SECRET), COOKIE_OPTIONS);
  c.set("user", payload);
  await next();
});
const limiter = rateLimiter({
  windowMs: 60 * 1000,
  limit: 200,
  standardHeaders: "draft-6",
  keyGenerator: (c) => c.get("user").sub + c.get("user").progress,
});
app.get("/progress", async (c) => {
  const user = c.get("user");
  return c.json({
    solves: user.progress,
    total: TOTAL_TO_SOLVE,
    imp: user.imp,
  });
});
app.get("/flag/:idx", limiter, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);
  if (user.progress && user.progress >= TOTAL_TO_SOLVE) {
    return serveFlag(c);
  } else {
    return serveImage(c);
  }
});
app.post("/solve", limiter, async (c) => {
  const user = c.get("user");
  if (!user) return c.json({ message: "Unauthorized" }, 401);
  if (user.progress && user.progress >= TOTAL_TO_SOLVE) {
    return c.json({ message: "already solved all!" });
  } else {
    if (!user.checksum) return c.json({ message: "Get a flag first" }, 400);
    const body = await c.req.parseBody();
    if (!body || !body["ans[]"])
      return c.json({ message: "At least guess something!" }, 400);
    let ans = body["ans[]"];
    if (!Array.isArray(ans)) return c.json({ message: "Invalid answer" }, 400);
    ans = ans.map((a) => ALL_FLAGS.indexOf(a));
    try {
      const payload = submit_answer(ans, user);
      if (!payload) return c.json({ message: "Invalid answer" }, 400);
      payload.ip = getConnInfo(c).remote.address;
      setCookie(c, "token", await sign(payload, SECRET), COOKIE_OPTIONS);
      return c.json({
        message: "Correct!",
        solves: payload.progress,
        total: TOTAL_TO_SOLVE,
        imp: payload.imp,
      });
    } catch (e) {
      return c.json({ message: "Invalid answer" }, 400);
    }
  }
});
app.get("*", serveStatic({ root: "./public" }));
export default {
  fetch: app.fetch,
  port: 1337,
  development: false,
};
