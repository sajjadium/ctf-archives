import { sleep } from "bun";
import puppeteer, { Browser } from "puppeteer-core";
import { ADMIN_TOKEN } from "./secrets";

const CHROME_PATH = "/usr/bin/chromium";

let browser: Browser;

async function startBrowser() {
    if (!browser || !browser.connected) {
        browser = await puppeteer.launch({
            executablePath: CHROME_PATH,
            args: [
                "--incognito",
                "--headless",
                "--no-sandbox",
                "--disable-gpu",
                '--no-gpu',
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu-sandbox",
                "--disable-software-rasterizer",
                "--disable-vulkan",
                '--disable-default-apps',
                '--disable-translate',
                '--disable-device-discovery-notifications',
                '--disable-xss-auditor',
                "--js-flags=\"--max_old_space_size=128\"",
                "--disable-sync",
                '--webrtc-ip-handling-policy=disable_non_proxied_udp',
                '--force-webrtc-ip-handling-policy'
            ]
        });
    }
    return browser;
}

export async function visit(
    url: string
): Promise<string> {
    const browser = await startBrowser();
    const context = await browser.createBrowserContext();
    try {
        const page = await context.newPage();
        await page.evaluateOnNewDocument(`navigator.mediaDevices.getUserMedia = navigator.webkitGetUserMedia = navigator.mozGetUserMedia = navigator.getUserMedia = webkitRTCPeerConnection = RTCPeerConnection = MediaStreamTrack = undefined;`);
        page.setRequestInterception(true);
        page.on('request', (request) => {
            const url = request.url();
            console.log(url);
            const parsed = new URL(url);
            if (parsed.origin === 'http://web:8000' ||
                parsed.origin === 'https://cdnjs.cloudflare.com') {
                request.continue();
            } else {
                request.abort();
            }
        });
        const token = await fetch("http://web:8000/get_admin_token", {
            method: "POST",
            headers: {
                "Authorization": ADMIN_TOKEN
            },
        }).then(r => r.json()).then((r: any) => r.token) as string;
        await context.setCookie({
            name: "token",
            value: token,
            domain: "web",
            httpOnly: true,
        });
        await page.goto(url, {
            waitUntil: "networkidle2",
            timeout: 10000,
        });
        await sleep(1000);
        await page.close();
        return `OK!`
    } catch (err) {
        throw err;
    } finally {
        await context.close();
    }
}