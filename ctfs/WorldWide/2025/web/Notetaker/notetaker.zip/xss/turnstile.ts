import { TURNSTILE_SECRET } from "./secrets";
export type TurnstileResponse = {
    "success": true,
    "challenge_ts": string,
    "hostname": string,
    "error-codes": string[] | null,
    "action": string,
    "cdata": string,
    "metadata": {
        "ephemeral_id": string,
    }
} | {
    "success": false,
    "error-codes": string[]
}

export async function verify(token?: string, ip?: string) {
    if (!token || !ip) return false;
    let formData = new FormData();
    formData.append("secret", TURNSTILE_SECRET);
    formData.append("response", token);
    formData.append("remoteip", ip);

    const url = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
    const result = await fetch(url, {
        body: formData,
        method: "POST",
    });

    return (await result.json() as TurnstileResponse)?.success;
}