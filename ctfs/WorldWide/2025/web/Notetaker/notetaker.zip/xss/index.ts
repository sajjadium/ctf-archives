import index from "./index.html" with { type: "text" };
import { verify } from "./turnstile";
import { visit } from "./xss";

const PREFIX = "http://web:8000/";
const server = Bun.serve({
    port: 8080,
    routes: {
        "/": new Response(index),
        "/api/report": async (req: Bun.BunRequest<"/api/report">) => {
            if (req.method !== "POST") return new Response("Method Not Allowed", { status: 405 });
            const { url, turnstile } = await req.json() as { url: string, turnstile?: string };

            if (!url || typeof url !== "string" || !url.startsWith(PREFIX)) return Response.json({ ok: false, message: "Invalid URL format or pattern." }, { status: 400 });
            if (!turnstile || typeof turnstile !== "string") return Response.json({ ok: false, message: "Invalid or missing Turnstile token.", }, { status: 400 });

            const ip = req.headers.get("x-forwarded-for") || req.headers.get('x-real-ip') || req.headers.get("cf-connecting-ip") || (server.requestIP(req)?.address);
            console.log(`[${new Date().toISOString()}] ${ip} - '${url}'`);
            if (!await verify(turnstile, ip)) return Response.json({ ok: false, message: "Invalid or missing Turnstile token.", }, { status: 400 });
            try {
                const message = await visit(url);
                return Response.json({
                    ok: true,
                    message
                });
            } catch (error) {
                return Response.json({
                    ok: false,
                    message: `Error: ${error instanceof Error ? error.message : String(error)}`,
                }, { status: 500 });
            }
        },
    },
    fetch(req) {
        return new Response("Not Found", { status: 404 });
    },
    error(error) {
        console.error(error);
        return new Response(`Internal Error`, { status: 500 });
    },
});