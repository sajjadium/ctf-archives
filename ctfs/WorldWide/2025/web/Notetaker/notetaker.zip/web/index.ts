import { mkdirSync } from "fs";
import INDEX from "./index.html" with { type: "text" };
import REGISTER from "./register.html" with { type: "text" };
import NOTE from "./note.html" with { type: "text" };
import USER from "./user.html" with { type: "text" };
import CSS from "./index.css" with { type: "text" };
import { serve, type BunRequest } from "bun";
import crypto from 'crypto';
import { serialize, deserialize } from "bun:jsc";
import { FLAG, ADMIN_TOKEN } from "./secrets";
import { appendFile } from "node:fs/promises";
const SECRET = crypto.randomBytes(16).toString('hex');
const DIR_NAME = "/tmp/uploads";

try {
    mkdirSync(DIR_NAME, { recursive: true });
} catch (err) {
    console.error("Failed to create upload directory:", err);
    throw new Error("Upload directory creation failed");
}

const CSP = "default-src 'none'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com/ajax/libs/dompurify/3.2.6/purify.min.js; connect-src 'none'; img-src 'self' data:; style-src 'self'; font-src 'self'; object-src 'none'; frame-src 'self'; base-uri 'none'; form-action 'self';"
const DOPTS = {
    headers: {
        "Content-Type": "text/html",
        "Content-Security-Policy": CSP
    }
};
type User = {
    uid: string;
    user: string;
    timestamp: number;
};

type Note = {
    title: string;
    content: string;
    user: string;
    created: string;
};

function getToken(user: string): string {
    const payload = JSON.stringify({ uid: crypto.randomUUID(), user, timestamp: Date.now() } satisfies User);
    const payloadBase64 = Buffer.from(payload).toString('base64url');
    const signature = crypto.createHmac('sha256', SECRET)
        .update(payloadBase64)
        .digest('base64url');
    return `${payloadBase64}.${signature}`;
}

function getUser(token: string): User | undefined {
    const [payloadBase64, signature] = token.split('.');
    if (!payloadBase64 || !signature) return;
    const expectedSig = crypto
        .createHmac('sha256', SECRET)
        .update(payloadBase64)
        .digest('base64url');
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSig))) return;
    const user = JSON.parse(Buffer.from(payloadBase64, 'base64url').toString()) as User;
    if (Date.now() - user.timestamp > 10 * 60 * 1000) return;
    return user;
}

async function authMiddleware(req: BunRequest, next: (user: User) => Response | Promise<Response>): Promise<Response> {
    const token = req.cookies.get("token");
    if (!token) return Response.redirect("/register");
    const user = getUser(token);
    if (!user) return Response.redirect("/register");
    return next(user);
}

const E404 = () => new Response("Not Found", {
    status: 404
});

const server = serve({
    port: 8000,
    maxRequestBodySize: 1024 * 1024,
    routes: {
        "/index.css": new Response(CSS, {
            headers: {
                "Content-Type": "text/css",
                "Content-Security-Policy": CSP
            }
        }),
        "/": req => authMiddleware(req, async user => {
            if (req.method === "GET") return new Response(INDEX, DOPTS);
            else if (req.method === "POST") {
                const formData = await req.formData();
                const title = formData.get("title")?.toString().trim();
                const content = formData.get("content")?.toString().trim();
                if (!title || !content) return new Response("Title and content are required", { status: 400 });
                if (title.length > 50) return new Response("Title must be between 1 and 50 characters", { status: 400 });
                if (content.length > 1000) return new Response("Content must be between 1 and 1000 characters", { status: 400 });
                const id = crypto.randomUUID();
                await Bun.write(`${DIR_NAME}/${id}`, serialize({
                    title,
                    content,
                    user: user.user,
                    created: new Date().toISOString()
                } satisfies Note));
                await appendFile(`${DIR_NAME}/${user.uid}.log`, `<a href="/note/${id}">${title.replace('\n', '').substring(0, 50)}</a>: ${content.replace('\n', '').substring(0, 50)}\n`);
                const ip = req.headers.get("x-forwarded-for") || req.headers.get('x-real-ip') || req.headers.get("cf-connecting-ip") || (server.requestIP(req)?.address);
                console.log(`[${new Date().toISOString()}] ${ip} - /${id} ${JSON.stringify({ title, content, user: user.user })}`);
                return Response.redirect("/note/" + id);
            } else {
                return new Response("Method Not Allowed", { status: 405 });
            }
        }),
        "/register": async req => {
            if (req.method === "POST") {
                const formData = await req.formData();
                const user = formData.get("name")?.toString().trim();
                if (!user) return new Response("User name is required", { status: 400 });
                if (user.length < 3 || user.length > 20) return new Response("User name must be between 3 and 20 characters", { status: 400 });
                if (user === "admin") return new Response("Username 'admin' is not allowed", { status: 400 });
                const token = getToken(user);
                req.cookies.set("token", token, {
                    httpOnly: true,
                    sameSite: "strict"
                });
                return Response.redirect("/");
            }
            return new Response(REGISTER, DOPTS);
        },
        '/me': req => authMiddleware(req, async user => Response.redirect(`/user/${user.uid}`)),
        '/user/:user': async (req) => {
            const user = req.params.user;
            if (req.method === "GET") {
                try {
                    if (!user || !/^[a-zA-Z0-9-]+$/.test(user)) return E404();
                    const data = await Bun.file(`${DIR_NAME}/${user}.log`).text();
                    return new Response(USER
                        .replace('UID', user)
                        .replace(/USER_DATA/g, btoa(data)), DOPTS);
                } catch (err) {
                    console.error("Error reading user notes:", err);
                    return E404();
                }
            }
            return E404();
        },
        "/note/:id": async (req) => {
            const id = req.params.id;
            if (req.method === "GET") {
                try {
                    if (!id || !/^[a-zA-Z0-9-]+$/.test(id)) return E404();
                    const data = deserialize(await Bun.file(`${DIR_NAME}/${id}`).bytes()) as Note;
                    return new Response(NOTE.replace(/NOTE_DATA/g, btoa(JSON.stringify(data))), DOPTS);
                } catch (err) {
                    console.error("Error reading note:", err);
                    return E404();
                }
            }
            return E404();
        },
        "/get_admin_token": async (req) => {
            // This endpoint is for the admin to get a token
            // It is not related to the challenge
            if (req.method === "POST") {
                if (req.headers.get("Authorization") !== ADMIN_TOKEN) return new Response("Forbidden", {
                    status: 403
                });
                return Response.json({
                    token: getToken("admin")
                });
            }
            return E404();
        },
        "/flag": req => authMiddleware(req, async user => {
            if (user.user === "admin") return new Response(FLAG);
            else return E404();
        }),
    },
    fetch(req) {
        return E404();
    },
    error(err) {
        console.error("Error:", err);
        return new Response("Internal Server Error", {
            status: 500
        });
    }
});