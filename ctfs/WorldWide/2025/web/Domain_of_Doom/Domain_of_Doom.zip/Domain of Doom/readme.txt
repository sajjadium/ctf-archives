sudo docker build -t command-injection-test .
sudo docker run -p 5000:5000 command-injection-test
[no files provided]

Name: Domain of Doom
Description: You're querying domains, but some lead to dangerous places
difficultly: medium