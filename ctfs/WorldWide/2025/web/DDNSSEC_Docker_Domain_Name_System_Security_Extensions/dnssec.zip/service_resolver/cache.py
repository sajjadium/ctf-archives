import time

server_ret_cache = {}
CACHE_TTL = 60

def get_cached_server_ret(resolver):
    now = time.time()

    if resolver in server_ret_cache:
        server_ret, timestamp = server_ret_cache[resolver]
        if now - timestamp < CACHE_TTL:
            return server_ret
        else:
            del server_ret_cache[resolver]

    return None

def cache_server_ret(resolver, server_ret):
    server_ret_cache[resolver] = (server_ret, time.time())

