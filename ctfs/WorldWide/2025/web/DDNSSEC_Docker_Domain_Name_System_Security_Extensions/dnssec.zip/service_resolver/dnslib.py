import dns.name
import dns.query
import dns.dnssec
import dns.message
import dns.rdatatype

PORT = 53
TIMEOUT = 3

def is_rrsig_field(answer):
    return answer.rdtype == dns.rdatatype.RRSIG

def fetch_dnskey(domain, resolver):
    request = dns.message.make_query(domain, dns.rdatatype.DNSKEY, want_dnssec=True)
    response = dns.query.udp(request, resolver, port=PORT, timeout=TIMEOUT)

    if response.rcode() != 0:
        raise RuntimeError(f"DNSKEY query failed with rcode: {response.rcode()}")

    dnskey_rrset = None
    dnskey_rrsig = None

    for rrset in response.answer:
        if rrset.rdtype == dns.rdatatype.DNSKEY:
            dnskey_rrset = rrset
        elif rrset.rdtype == dns.rdatatype.RRSIG and rrset.covers == dns.rdatatype.DNSKEY:
            dnskey_rrsig = rrset

    if not dnskey_rrset or not dnskey_rrsig:
        raise RuntimeError("Missing DNSKEY or RRSIG(DNSKEY) in answer.")

    return dnskey_rrset, dnskey_rrsig

def validate_dnskeys(domain, dnskey_rrset, dnskey_rrsig):
    keys = {dns.name.from_text(domain): dnskey_rrset}
    dns.dnssec.validate(dnskey_rrset, dnskey_rrsig, keys)
    return keys

def fetch_a_record(subdomain, resolver):
    request = dns.message.make_query(subdomain, dns.rdatatype.A, want_dnssec=True)
    response = dns.query.udp(request, resolver, port=PORT, timeout=TIMEOUT)

    if response.rcode() != 0:
        raise RuntimeError(f"A record query failed with rcode: {response.rcode()}")

    return response.answer

def validate_response(answer_section, subdomain, keys):
    status = "SECURE"
    did_validate = False

    for rrset in answer_section:
        if is_rrsig_field(rrset):
            continue

        rrsig = None
        for possible_rrsig in answer_section:
            if (possible_rrsig.rdtype == dns.rdatatype.RRSIG and
                possible_rrsig.covers == rrset.rdtype and
                possible_rrsig.name == rrset.name):
                rrsig = possible_rrsig
                break

        if rrsig:
            try:
                assert str(rrset.name) == subdomain
                dns.dnssec.validate(rrset, rrsig, keys)
                did_validate = True
            except:
                status = "BOGUS"
    
    if not did_validate:
        return False
    
    return status
