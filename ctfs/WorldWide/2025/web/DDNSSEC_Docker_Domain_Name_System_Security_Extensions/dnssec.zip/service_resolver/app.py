import requests
import ipaddress

from cache import cache_server_ret, get_cached_server_ret
from dnslib import fetch_a_record, fetch_dnskey, is_rrsig_field, validate_dnskeys, validate_response
from urllib.parse import urlparse

from flask import Flask, render_template, request

app = Flask(__name__)

def get_domain_answer(answers):
    entry = None
    for answer in answers:
        if is_rrsig_field(answer):
            continue
        entry = answer
        break
    if not entry:
        return None
    return entry

def lookup_ip(domain, subdomain, resolver):

    dnskey_rrset, dnskey_rrsig = fetch_dnskey(domain, resolver)
    keys = validate_dnskeys(domain, dnskey_rrset, dnskey_rrsig)

    answer_section = fetch_a_record(subdomain, resolver)
    status = validate_response(answer_section, subdomain, keys)

    if status == 'SECURE':
        entry = get_domain_answer(answer_section)
        if not entry:
            return None
        
        data = entry.to_text().split() # dns entry like `ctf.graa.nl.            13741   IN      A       172.28.1.12`

        domain_answer = data[0]
        if domain_answer != subdomain:
            return None
        
        ip_answer = data[4]
        return ip_answer
    else:
        return None

def is_valid_local_ip(ip):
    try:
        ip_obj = ipaddress.ip_address(ip)
        network = ipaddress.ip_network("172.28.1.0/24")
        return ip_obj in network

    except:
        return False

@app.route("/", methods=["GET", "POST"])
def index():
    server_ret = None

    if request.method == "POST":
        server_ret = "Something went wrong"
        try:
            resolver = request.form.get("resolver", "8.8.8.8")
            resolver = str(ipaddress.ip_address(resolver))

            domain = "graa.nl."
            subdomain = "ctf.graa.nl."
            
            cached = get_cached_server_ret(resolver)
            if cached is not None:
                return render_template("check.html", server_ret=cached)
            
            ip = lookup_ip(domain, subdomain, resolver)
            if ip:
                url = f"http://{ip}:5000/status"

                if is_valid_local_ip(urlparse(url).hostname):
                    res = requests.get(url)
                    server_ret = res.text

            if 'flag' not in server_ret:
                cache_server_ret(resolver, server_ret)

        except:
            pass

    return render_template("check.html", server_ret=server_ret)
