from flask import Flask
import os

FLAG=os.getenv("FLAG")

app = Flask(__name__)

@app.route("/flag")
def flag():
    return f"The flag is {FLAG}"
