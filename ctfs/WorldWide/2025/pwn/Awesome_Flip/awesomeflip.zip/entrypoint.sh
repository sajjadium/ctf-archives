#!/bin/sh
cd /challenge
./chall
