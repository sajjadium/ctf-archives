#!/bin/bash
qemu-aarch64-static chal
