from flask import Flask, request, jsonify, render_template
import time, uuid
import hashlib
app = Flask(__name__, template_folder='templates')
with open('flag.txt') as f:
    FLAG = f.read().strip()
available_tickets = 1

purchases = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/acquire', methods=['GET'])
def acquire():
    global available_tickets
    user = request.args.get('user')
    if not user:
        return "Missing user", 400

    #all tickets are sold out
    if available_tickets < 1:
        return jsonify(status="sold_out")

    #encrypt user data for security
    hashlib.pbkdf2_hmac(
        'sha256',
        user.encode('utf-8'),
        b'galactic-shuttle',
        100_000
    )

    available_tickets -= 1
    ticket_id = uuid.uuid4().hex
    purchases.setdefault(user, []).append(ticket_id)
    return jsonify(status="ok", ticket=ticket_id)

@app.route('/flag', methods=['GET'])
def flag():
    user = request.args.get('user')
    if not user:
        return "Missing user", 400
    if len(purchases.get(user, [])) > 1:
        return jsonify(flag=FLAG)
    return jsonify(status="not_enough_tickets", got=len(purchases.get(user, [])))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, threaded=True)