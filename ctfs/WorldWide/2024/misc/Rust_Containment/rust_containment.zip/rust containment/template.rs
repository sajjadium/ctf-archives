
fn safe_function() {
    /// *** YOUR CODE *** ///;
}

fn main() {
    let flag = "/// *** MY FLAG *** ///";

    safe_function();
}
