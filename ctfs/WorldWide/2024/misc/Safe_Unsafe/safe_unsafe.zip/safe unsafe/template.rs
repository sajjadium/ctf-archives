
fn print_flag(flag: *const u8) {
    /// *** YOUR CODE *** ///
}

fn main() {
    let flag = env!("FLAG");

    print_flag(flag.as_ptr());
}
