#!/bin/sh

# run this to test locally

docker build . -t rust_jail_lv1 && docker run -it rust_jail_lv1 kctf_drop_privs nsjail --config /home/user/nsjail.cfg -- /usr/local/bin/python3 runner.py