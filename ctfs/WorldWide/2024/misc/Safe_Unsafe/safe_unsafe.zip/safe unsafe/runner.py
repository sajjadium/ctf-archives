import subprocess
import string


print("Input your code to insert into template.rs.")
print("End with 3 blank lines!")

lines = []
while len(lines) == 0 or any(x.strip() != "" for x in lines[-3:]):
    lines.append(input())
code = "\n".join(lines)


if "use" in code:
    print("Imports? Really? Write your own code!")
    exit(1)

if "::" in code:
    print("Using other modules? Really? Write your own code!")
    exit(1)

if "env" in code:
    print("Environment variables are my property!")
    exit(1)

ALLOWED_CHARACTERS = string.ascii_letters + string.digits + " .():;|-<>&',_*=\n\t"
if any(c not in ALLOWED_CHARACTERS for c in code):
    disallowed = set(c for c in code if c not in ALLOWED_CHARACTERS)
    yapping = {
        "\"": "String literals are forbidden, you already have enough strings: the flag.",
        "[]": "Don't use slices, what if one somehow contains my flag?",
        "{}": "One function and builtin types is all you need.",
        "#": "Attributes are not even code, why are you using them?",
        "?": "Question marks mark a question. Why are you asking a mindless computer?",
        "!": "...As we figured out earlier, macros are too useful."
    }
    for chars, message in yapping.items():
        if set(chars) & disallowed:
            print(message)
        disallowed -= set(chars)
    if disallowed:
        print(f"What even is '{''.join(disallowed)}'?")
    
    exit(1)


with open("./template.rs") as f:
    template = f.read()

template = template.replace("/// *** YOUR CODE *** ///", code)

with open(f"/tmp/main.rs", "w") as f:
    f.write(template)

p = subprocess.Popen(["rustc", f"/tmp/main.rs", "-o", f"/tmp/main"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
p.wait()
assert p.returncode == 0, "compilation failed"

p = subprocess.Popen(f"/tmp/main", env={})
p.wait()
