const express = require('express');
const cheerio = require('cheerio');
const cors = require('cors');
const crypto = require('node:crypto');
const puppeteer = require("puppeteer");

const app = express();
const PORT = process.env.PORT || 3001;
const DIFFICULTY = process.env.DIFFICULTY || 4;
const FLAG = process.env.FLAG;
const CHALL_DOMAIN = process.env.CHALL_DOMAIN || "sass.wwctf.com";
const ACCESSKEY = crypto.randomBytes(20).toString('hex');
const HTTPS = Number(process.env.HTTPS) || 0;
const protocol = HTTPS ? "https" : "http"
let TIMEOUT = 5000;
let fails = 50;
const browser = puppeteer.launch({
    headless: true,
    args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor',
        "--start-maximized",
        '--metrics-recording-only',
        '--disable-sync',
        '--no-first-run',
        '--disable-extensions',
        '--disable-background-networking',
    ],
});


app.use(express.json());

app.use(cors(
    {
        origin: `${protocol}://${CHALL_DOMAIN}`
    }
))

const blacklist = "a abbr acronym address applet area article aside audio b base bdi bdo big blink blockquote br button canvas caption center cite code col colgroup command content data datalist dd del details dfn dialog dir div dl dt element em embed fieldset figcaption figure font footer form frame frameset head header hgroup hr html iframe image img input ins kbd keygen label legend li link listing main map mark marquee menu menuitem meta meter multicol nav nextid nobr noembed noframes noscript object ol optgroup p output p param picture plaintext pre progress s samp script section select shadow slot small source spacer span strike strong sub summary sup svg table tbody td template textarea tfoot th thead time tr track tt u ul var video".split(" ")

const attrs = "onafterprint onafterscriptexecute onanimationcancel onanimationend onanimationiteration onanimationstart onauxclick onbeforecopy autofocus onbeforecut onbeforeinput onbeforeprint onbeforescriptexecute onbeforetoggle onbeforeunload onbegin onblur oncanplay oncanplaythrough onchange onclick onclose oncontextmenu oncopy oncuechange oncut ondblclick ondrag ondragend ondragenter ondragexit ondragleave ondragover ondragstart ondrop ondurationchange onend onended onerror onfocus onfocus onfocusin onfocusout onformdata onfullscreenchange onhashchange oninput oninvalid onkeydown onkeypress onkeyup onload onloadeddata onloadedmetadata onloadstart onmessage onmousedown onmouseenter onmouseleave onmousemove onmouseout onmouseover onmouseup onmousewheel onmozfullscreenchange onpagehide onpageshow onpaste onpause onplay onplaying onpointercancel onpointerdown onpointerenter onpointerleave onpointermove onpointerout onpointerover onpointerrawupdate onpointerup onpopstate onprogress onratechange onrepeat onreset onresize onscroll onscrollend onsearch onseeked onseeking onselect onselectionchange onselectstart onshow onsubmit onsuspend ontimeupdate ontoggle ontoggle(popover) ontouchend ontouchmove ontouchstart ontransitioncancel ontransitionend ontransitionrun ontransitionstart onunhandledrejection onunload onvolumechange onwebkitanimationend onwebkitanimationiteration onwebkitanimationstart onwebkitmouseforcechanged onwebkitmouseforcedown onwebkitmouseforceup onwebkitmouseforcewillbegin onwebkitplaybacktargetavailabilitychanged onwebkittransitionend onwebkitwillrevealbottom onwheel".split(" ")

const generateChallenge = () => {
    const data = crypto.randomBytes(16).toString('hex');
    script = `
<pre>
import hashlib
import time
from multiprocessing import Pool, cpu_count
import sys
def find_nonce(args):
    message, nonce_start, nonce_end, prefix = args
    for nonce in range(nonce_start, nonce_end):
        combined = f'{message}{nonce}'.encode()
        hash_result = hashlib.sha256(combined).hexdigest()
        if hash_result.startswith(prefix):
            return nonce
    return None

def proof_of_work(message):
    prefix = '0'*${DIFFICULTY}
    nonce = 0
    num_processes = 1
    chunk_size = 1000000
    start_time = time.time()
    
    with Pool(processes=num_processes) as pool:
        while True:
            tasks = [
                (message, nonce + i * chunk_size, nonce + (i + 1) * chunk_size, prefix)
                for i in range(num_processes)
            ]
            results = pool.map(find_nonce, tasks)
            
            for result in results:
                if result is not None:
                    end_time = time.time()
                    nonce = result
                    print(f'Time taken: {end_time - start_time} seconds')
                    return nonce

            nonce += num_processes * chunk_size

if  __name__ == "__main__":
    print("Working....")
    data = "${data}"
    nonce = proof_of_work(data)
    print(nonce)
</pre>
`
    return { script, data, difficulty: DIFFICULTY };
};

const validateSolution = (data, nonce, difficulty) => {
    const hash = crypto.createHash('sha256').update(data + nonce).digest('hex');
    const target = '0'.repeat(difficulty);
    return hash.startsWith(target);
};
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

const activeChallenges = new Map();

const sanitize = (html) => {
    const unsafe = cheerio.load(html);
    for (const tag of blacklist) {
        unsafe(tag, "body").remove();
    }
    unsafe('*').each((_, el) => {
        for (const attr of attrs) {
            unsafe(el).removeAttr(attr);
        }
    });
    return unsafe("body").html();

}

app.post('/api/sanitize', async (req, res) => {
    try {
        const { html } = req.body;
        if (html) {
            const sanitizedHTML = sanitize(html);
            res.json({ html: sanitizedHTML });
        } else {
            res.status(400).json({ error: 'No HTML provided' });
        }
    } catch (err) {
        console.log(err)
        res.status(500).json({ error: 'Something went wrong' });
    }

});

app.get('/api/report', (req, res) => {
    const challenge = generateChallenge();
    activeChallenges.set(challenge.data, challenge.difficulty);
    res.contentType("text/html");
    res.send(challenge.script);
});


app.post('/api/report', async (req, res) => {
    const { data, nonce, urlToVisit, secretKey } = req.body;
    console.log("REPORT_LOG_DFD: ",data, nonce, urlToVisit, secretKey);
    if (!data || nonce === undefined || urlToVisit === undefined || secretKey === undefined) {
        return res.status(400).json({ success: false, error: 'Invalid request format.' });
    }

    const difficulty = activeChallenges.get(data);
    if (!difficulty) {
        return res.status(400).json({ success: false, error: 'Challenge not found or expired.' });
    }

    const isValid = validateSolution(data, nonce, difficulty);
    if (isValid) {
        activeChallenges.delete(data);
        try {

            const context = await (await browser).createBrowserContext();
            const page = await context.newPage();
            await page.setCookie({
                name: "flag",
                httpOnly: false,
                value: FLAG,
                url: `${protocol}://${CHALL_DOMAIN}`
            })
            if (urlToVisit.includes(CHALL_DOMAIN)) {
                if (secretKey !== ACCESSKEY) {
                    return res.status(403).json({ success: false, error: 'secretKey is invalid you can not report' });
                }
            }
            const url = new URL(urlToVisit)
            if (url.host !== CHALL_DOMAIN) {
                return res.status(400).json({ success: false, error: 'Given URL is out of scope' });
            }
            try {
                await page.goto(urlToVisit, {
                    waitUntil: 'networkidle0',
                    timeout: TIMEOUT
                });
                await sleep(1000);
                await page.close();
                await context.close();
                return res.json({ success: true, message: 'Admin verified your report.' });
            } catch (error) {
                if (error.message.includes('Navigation timeout')) {
                    fails -= 1
                    if (fails === 0){
                        TIMEOUT += 2000
                        fails = 50
                    }
			console.error(`Navigation timeout Given URL: ${urlToVisit}`);
                } else {
                    console.error(`An error occurred: ${error.message}`);
                }
                await context.close();
                return res.status(200).json({ success: false, error: 'URL took too much time to load' });
            }
        } catch (error) {
            await context.close();
            console.error(`An error occurred: ${error.message}`);
            return res.status(500).json({ success: false, error: 'Server Error' });
        }

    }
    return res.status(400).json({ success: false, error: 'Invalid solution.' });
});


app.listen(PORT, async () => {
    console.log(`SaAS running at http://localhost:${PORT}`);
});
