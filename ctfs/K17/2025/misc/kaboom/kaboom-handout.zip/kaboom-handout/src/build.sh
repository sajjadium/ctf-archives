#!/bin/sh
gcc kaboom.c zip/zip.c -O2 -o kaboom
