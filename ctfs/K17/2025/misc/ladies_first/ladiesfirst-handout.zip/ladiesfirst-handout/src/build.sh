#!/bin/sh
gcc -o processor processor.c
gcc -o calculator calculator.c
