const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// set up EJS for SSR templating
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// serve static files (including pdf.js)
app.use(express.static(path.join(__dirname, 'public')));

// viewer route with url args
app.get('/', (req, res) => {
    const { url, name, extra } = req.query;

    if (!url && !name && !extra) {
        res.redirect(encodeURI("/?url=https://www.amsi.org.au/teacher_modules/pdfs/Maths_delivers/Encryption5.pdf&name=Cryptography&extra=An analysis of RSA"));
        return;
    }

    res.render('viewer', {
        pdfUrl: url || 'https://www.amsi.org.au/teacher_modules/pdfs/Maths_delivers/Encryption5.pdf',
        pdfName: name || 'Document',
        extra: extra || ''
    });
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
