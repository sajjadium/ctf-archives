#include <unistd.h>

int main(int argc, char** argv)
{
    (void)argc;
    argv[0] = (char*)"sh";
    execv("/bin/busybox", argv);
    return 1;
}
