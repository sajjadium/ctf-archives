#!/bin/sh

export TMPDIR=/tmp

cp /app/flag.txt /tmp/flag.txt
chmod 0600 /tmp/flag.txt

GDB_ARGS=""
if [ "${QEMU_GDB:-0}" = "1" ]; then
    GDB_ARGS="-gdb tcp:0.0.0.0:1234"
fi

if [ ! -r /dev/kvm ] || [ ! -w /dev/kvm ]; then
    echo "KVM is required: expose /dev/kvm to the container" >&2
    exit 1
fi

MEMORY="${QEMU_MEMORY:-1024M}"
CPUS="${QEMU_CPUS:-4}"

exec qemu-system-x86_64 \
    -kernel /app/bzImage \
    -drive file=/app/rootfs.qcow2,format=qcow2,if=ide,index=0,media=disk,snapshot=on \
    -drive file=/tmp/flag.txt,format=raw,if=ide,index=1,media=disk \
    -accel kvm \
    -cpu qemu64 \
    -m "${MEMORY}" \
    -smp "${CPUS}" \
    -net nic \
    -net user,hostfwd=tcp:0.0.0.0:1337-:1337 \
    -nographic \
    -no-reboot \
    ${GDB_ARGS} \
    -append "root=/dev/sda console=ttyS0"
