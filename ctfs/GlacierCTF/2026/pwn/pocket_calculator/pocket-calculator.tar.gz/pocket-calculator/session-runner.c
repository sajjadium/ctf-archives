#define _GNU_SOURCE

#include <errno.h>
#include <grp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static volatile sig_atomic_t child_pid = -1;

static void expire_session(int sig)
{
    (void)sig;
    if (child_pid > 0)
        kill(-child_pid, SIGKILL);
}

static int set_limit(int resource, rlim_t value)
{
    struct rlimit limit = { value, value };
    return setrlimit(resource, &limit);
}

int main(void)
{
    char directory[64];
    uid_t uid = 2000 + ((unsigned)getpid() % 60000);
    int status = 1;

    snprintf(directory, sizeof(directory), "/tmp/session.%ld", (long)getpid());
    if (mkdir(directory, 0700) != 0 || chown(directory, uid, uid) != 0 ||
        chdir(directory) != 0)
        return 1;

    signal(SIGALRM, expire_session);
    child_pid = fork();
    if (child_pid == 0) {
        setpgid(0, 0);
        if (set_limit(RLIMIT_CPU, 35) != 0 ||
            set_limit(RLIMIT_AS, 128 * 1024 * 1024) != 0 ||
            set_limit(RLIMIT_NPROC, 8) != 0 ||
            set_limit(RLIMIT_FSIZE, 0) != 0 ||
            setgroups(0, NULL) != 0 || setgid(uid) != 0 || setuid(uid) != 0 ||
            prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0)
            _exit(1);
        execl("/app/challenge", "challenge", NULL);
        _exit(1);
    }

    if (child_pid > 0) {
        setpgid(child_pid, child_pid);
        alarm(30);
        while (waitpid(child_pid, &status, 0) < 0 && errno == EINTR)
            ;
        alarm(0);
        kill(-child_pid, SIGKILL);
    }

    chdir("/");
    rmdir(directory);
    if (WIFEXITED(status))
        return WEXITSTATUS(status);
    return 1;
}
