# Pinned KVM runtime

The distributed container boots the included Linux 6.10.2 kernel and rootfs.
One persistent guest accepts up to 400 concurrent connections and starts a
separate restricted process for each connection. Linux KVM and `/dev/kvm` are
mandatory; there is intentionally no TCG fallback.
