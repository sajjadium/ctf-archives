#!/usr/bin/env sh
set -e

HERE="$(cd "$(dirname "$0")" && pwd)"
PROG="${1:?usage: run.sh <program_file>}"

[ -f "$HERE/brainrot.vmdk" ] || gunzip -k "$HERE/brainrot.vmdk.gz"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cp "$HERE/brainrot.vmdk" "$TMP/img.vmdk"
"$HERE/exe2minixfs" "$TMP/img.vmdk" 10321920 "$PROG" prog >/dev/null 2>&1

exec qemu-system-x86_64 \
  -m 8M \
  -drive file="$TMP/img.vmdk",format=raw,index=0,media=disk \
  -debugcon stdio -no-reboot -cpu qemu64,+smep -display none
