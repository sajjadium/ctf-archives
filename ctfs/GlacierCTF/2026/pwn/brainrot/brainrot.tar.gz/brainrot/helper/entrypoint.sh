#!/usr/bin/env bash
set -u

BASE="${BASE:-/app/chal.vmdk}"
E2M="${E2M:-/app/exe2minixfs}"
USERSPACE_PART=10321920      # minixfs /usr offset (exe2minixfs)
MAX_B64=200000

if [ -f /app/pow ]; then
  python3 /app/pow || exit 1
fi

TMP="$(mktemp -d --suffix=--brainrot)"
trap 'rm -rf "$TMP"' EXIT
cp "$BASE" "$TMP/img.vmdk"

echo "=== brainrot ==="
echo "Send your Brainfuck program as ONE base64 line:"
echo "  line 1 = Brainfuck code, line 2 = fake stdin (base64 the whole file)."
echo -n "program> "

IFS= read -r B64 || exit 0
[ "${#B64}" -gt "$MAX_B64" ] && { echo "[!] program too large"; exit 1; }
printf '%s' "$B64" | base64 -d > "$TMP/prog" 2>/dev/null || { echo "[!] invalid base64"; exit 1; }
"$E2M" "$TMP/img.vmdk" "$USERSPACE_PART" "$TMP/prog" prog >/dev/null 2>&1 \
  || { echo "[!] injection failed"; exit 1; }

echo "[*] booting SWEB (debug console follows; grep for the flag)..."
echo
exec qemu-system-x86_64 \
  -m 8M \
  -drive file="$TMP/img.vmdk",format=raw,index=0,media=disk \
  -debugcon stdio -no-reboot -cpu qemu64,+smep -display none
