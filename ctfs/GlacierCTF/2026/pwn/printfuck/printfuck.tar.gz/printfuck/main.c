#include <printf.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define SOURCE_CAPACITY (80ul << 20)

static unsigned char tape[65536 * 256], bytes[257], scratch[2];
enum { argument_pad = 4 };
struct block {
    char *format, *arguments;
    size_t length, size;
    FILE *out, *args;
};
static struct block *program;
static int depth;
static uint16_t head;
static FILE *sink;
static unsigned char *source;
static size_t source_length, source_position;
static struct {
    struct block *block;
    size_t shift;
} frames[512];

static void fail(const char *message)
{
    fprintf(stderr, "bfprintf: %s\n", message);
    exit(1);
}

static void read_source(size_t capacity)
{
    int c;
    while ((c = getchar()) != EOF && c != '\n') {
        if (source_length == capacity) fail("source too long");
        source[source_length++] = (unsigned char)c;
    }
    if (ferror(stdin)) fail("could not read source");
}

static int source_char(void)
{
    return source_position < source_length ? source[source_position++] : EOF;
}

static struct block *new_block(void)
{
    static const unsigned char pad[argument_pad];
    struct block *b = calloc(1, sizeof(*b));
    if (!b) fail("out of memory");
    b->out = open_memstream(&b->format, &b->length);
    b->args = open_memstream(&b->arguments, &b->size);
    if (!b->out || !b->args) fail("out of memory");
    fwrite(pad, sizeof(pad), 1, b->args);
    return b;
}

static void finish(struct block *b)
{
    int error = fclose(b->out);
    error |= fclose(b->args);
    if (error || b->size < argument_pad) fail("could not generate format");
    size_t raw_size = b->size;
    b->size = (raw_size - argument_pad) & ~(sizeof(void *) - 1);
    memmove(b->arguments, b->arguments + argument_pad, b->size);
    memset(b->arguments + b->size, 0, raw_size - b->size);
}

#define emit(b, format, ...) do { \
    const void *arguments[] = { __VA_ARGS__ }; \
    fputs(format, (b)->out); \
    fwrite(arguments, sizeof(arguments), 1, (b)->args); \
} while (0)

static void ramp(struct block *b, unsigned char *cell)
{
    for (unsigned i = 0; i < 256; ++i)
        emit(b, "%hhn ", cell + i);
    emit(b, "%s", cell);
}

static void compile(struct block *start, int nesting)
{
    if (nesting == 512) fail("brackets too deeply nested");
    struct block *b = start;
    uint16_t offset = 0;
    int c;
    while ((c = source_char()) != EOF && c != ']') {
        if (c == '>' || c == '<') {
            offset = (uint16_t)(offset + (c == '>' ? 1 : -1));
            continue;
        }
        if (!c || !strchr("+-.,[", c)) continue;
        unsigned char *cell = tape + 256 * offset;
        switch (c) {
        case '+': case '-':
            emit(b, c == '+' ? "%s%255s" : "%s%1s", cell, "");
            ramp(b, cell); /* Store -(value+delta). */
            emit(b, "%s%256s", cell, "");
            ramp(b, cell); /* Negate again. */
            break;
        case '.':
            emit(b, "%c%.1s%c%252s%c%.0s%hhn%s%.0s",
                 NULL, cell, NULL, "", (void *)1, "", scratch, scratch, "");
            break;
        case ',': emit(b, "%256s%R", "", cell); break;
        case '[': {
            struct block *loop = new_block(), *rest = new_block();
            compile(loop, nesting + 1);
            emit(b, "%256s%J", "", cell, loop, rest);
            finish(b);
            b = rest;
            offset = 0;
            break;
        }
        }
    }
    if (c == ']' && !nesting) fail("unmatched ']'");
    if (c != ']' && nesting) fail("unmatched '['");
    if (nesting) emit(b, "%256s%J", "", tape + 256 * offset, start, NULL);
    finish(b);
}

static void move_arguments(struct block *b, size_t shift)
{
    void **values = (void **)b->arguments;
    for (size_t i = 0; i < b->size / sizeof(*values); ++i) {
        uintptr_t value = (uintptr_t)values[i], start = (uintptr_t)tape;
        if (value >= start && value < start + sizeof(tape))
            value = start + (value - start + shift) % sizeof(tape);
        values[i] = (void *)value;
    }
}

static int render(struct block *b)
{
    if (depth++ == 512) fail("printf recursion limit reached");
    int level = depth - 1;
    size_t shift = 256 * (size_t)head;
    move_arguments(b, shift);
    frames[level].block = b;
    frames[level].shift = shift;
    void *values = b->arguments;
    va_list args = {{48, 176, values, NULL}};
    int result = vfprintf(sink, b->format, args);
    if (frames[level].block) move_arguments(b, sizeof(tape) - shift);
    frames[level].block = NULL;
    --depth;
    return result < 0 ? -1 : 0;
}

static int arginfo(const struct printf_info *info, size_t n, int *types, int *sizes)
{
    (void)sizes;
    int count = info->spec == 'J' ? 3 : 1;
    for (size_t i = 0; i < n && i < (size_t)count; ++i) types[i] = PA_POINTER;
    return count;
}

static int operation(FILE *stream, const struct printf_info *info, const void *const *args)
{
    (void)stream;
    unsigned char *cell = *(void *const *)args[0];
    if (info->spec == 'J') {
        struct block *current = frames[depth - 1].block;
        if (current) {
            move_arguments(current, sizeof(tape) - frames[depth - 1].shift);
            frames[depth - 1].block = NULL;
        }
        head = (uint16_t)((cell - tape) / 256);
        struct block *body = *(void *const *)args[1], *rest = *(void *const *)args[2];
        if (*cell && render(body) < 0) return -1;
        return rest ? render(rest) : 0;
    }
    int c = getchar();
    if (ferror(stdin)) fail("input error");
    sprintf((char *)cell, "%s", (char *)bytes + (c == EOF ? 0 : c));
    return 0;
}

static ssize_t write_output(void *cookie, const char *data, size_t length)
{
    static int byte = -1;
    for (size_t i = 0; i < length; ++i) {
        unsigned char c = (unsigned char)data[i];
        if (!c) {
            if (byte >= 0 && fputc(byte, cookie) == EOF) return -1;
            byte = byte < 0 ? 0 : -1;
        } else if (byte >= 0) byte = c;
    }
    return (ssize_t)length;
}

int main(void)
{
    for (unsigned i = 0; i < 256; ++i) bytes[i] = (unsigned char)i;

    source = mmap(NULL, SOURCE_CAPACITY, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    program = new_block();
    read_source(SOURCE_CAPACITY);
    compile(program, 0);
    munmap(source, SOURCE_CAPACITY);

    if (register_printf_specifier('J', operation, arginfo) < 0 ||
        register_printf_specifier('R', operation, arginfo) < 0)
        fail("could not register printf specifiers");

    sink = fopencookie(stdout, "w", (cookie_io_functions_t){ .write = write_output });
    if (!sink || setvbuf(stdout, NULL, _IONBF, 0) || setvbuf(sink, NULL, _IONBF, 0))
        fail("could not set up output");

    int result = render(program);

    if (fclose(sink) == EOF || fflush(stdout) == EOF) result = -1;
    if (result < 0) fail("printf I/O error");

    return 0;
}
