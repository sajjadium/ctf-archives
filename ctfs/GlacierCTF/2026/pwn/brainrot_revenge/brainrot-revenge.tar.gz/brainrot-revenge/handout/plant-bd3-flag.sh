#!/usr/bin/env sh
set -e

IMG="${1:?usage: plant-bd3-flag.sh <brainrot.vmdk> [flag]}"
FLAG="${2:-gctf{local_test_revenge}}"
BD3_SECTOR=109872
OFF=$((BD3_SECTOR * 512))

[ -f "$IMG" ] || { echo "image not found: $IMG"; exit 1; }
dd if=/dev/zero of="$IMG" bs=512 seek="$BD3_SECTOR" count=8 conv=notrunc status=none
printf '%s' "$FLAG" | dd of="$IMG" bs=1 seek="$OFF" conv=notrunc status=none
echo "[+] planted '$FLAG' on bd3 of $IMG -- now boot it with brainrot's run.sh"
