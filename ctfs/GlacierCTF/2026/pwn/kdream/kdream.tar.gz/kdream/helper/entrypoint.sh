#!/usr/bin/env bash

echo -e "Press [ENTER] to start the instance"
read -n1

# Generate temporary directory per connection
DIR=$(mktemp -d --suffix=--gctf-qemu)
QEMU_PID=

cleanup() {
	if [ -n "${QEMU_PID}" ] && kill -0 "${QEMU_PID}" 2>/dev/null; then
		kill -9 "${QEMU_PID}" 2>/dev/null
		wait "${QEMU_PID}" 2>/dev/null
	fi
	rm -rf "${DIR}"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM

cd "${DIR}"

echo -e "\e[1;34m[+] Generating personal access key...\e[0m"
echo ""

ssh-keygen -t ed25519 -C "player@gctf" -q -N "" -f key
cat key

echo ""
echo -e "\e[1;34m[+] 1. Paste the key to a file 'key'\e[0m"
echo -e "\e[1;34m[+] 2. Fix key permissions with 'chmod 600 key'\e[0m"

# Copy the rootfs and kernel
cp /app/rootfs.qcow2 .
cp /app/bzImage .
cp /app/flag.txt .
cp /app/module.ko .

#PORT=$(ruby -e 'require "socket"; puts Addrinfo.tcp("", 0).bind {|s| s.local_address.ip_port }')
if ! exec 100>/tmp/port.lock; then
	echo "Could not spawn instance, please contact an administrator!"
	exit 1
fi
if ! flock -x -w 10 100; then
	echo "Could not reserve an instance port, please try again!"
	exit 1
fi
CURRENT_PORT=$(cat /tmp/port)
PORT_COUNT=$((PUBPORTEND - PUBPORTSTART))
case "${CURRENT_PORT}" in
	''|*[!0-9]*)
		flock -u 100
		echo "Invalid instance port state, please contact an administrator!"
		exit 1
		;;
esac
if [ "${CURRENT_PORT}" -ge "${PORT_COUNT}" ]; then
	flock -u 100
	echo "Invalid instance port state, please contact an administrator!"
	exit 1
fi
printf '%s\n' "$(((CURRENT_PORT + 1) % PORT_COUNT))" > /tmp/port
flock -u 100

PORT=$((CURRENT_PORT + PUBPORTSTART))

qemu-system-x86_64 -kernel "${DIR}/bzImage" \
	-enable-kvm \
	-cpu qemu64,+smep,+smap,-svm,-vmx \
	-nodefaults \
	-no-user-config \
	-display none \
	-serial none \
	-parallel none \
	-monitor none \
	-no-reboot \
	-sandbox on,obsolete=deny,elevateprivileges=deny,spawn=deny,resourcecontrol=deny \
	-drive file="${DIR}/rootfs.qcow2",format=qcow2 \
	-drive file="${DIR}/key.pub",format=raw \
	-drive file="${DIR}/flag.txt",format=raw \
	-drive file="${DIR}/module.ko",format=raw \
	-net nic -net user,hostfwd=tcp::${PORT}-:22 \
	-pidfile qemupid \
	-m 256M \
	-smp 4 >/dev/null 2>&1 &
QEMU_PID=$!
echo "${QEMU_PID}" > qemupid

sleep 1
if ! kill -0 "${QEMU_PID}" 2>/dev/null; then
	wait "${QEMU_PID}"
	echo -e "\e[1;31m[-] QEMU failed to start.\e[0m"
	exit 1
fi

echo -e "\e[1;34m[+] 3. Wait 10-30 seconds for the system to boot\e[0m"
echo -e "\e[1;34m[+] 4. Clean known_hosts with ssh-keygen -R \"[${DOMAIN}]:${PORT}\"\e[0m"
echo -e "\e[1;34m[+] 5. Connect with 'ssh -p${PORT} -i key user@${DOMAIN}'\e[0m"
echo -e "\e[1;34m[+] 6. Copy exploit files with 'scp -P ${PORT} -i key ./LOCALEXPLOIT user@${DOMAIN}:~/'\e[0m"

echo ""

echo -e "\e[1;34m[+] You have ${TIMEOUT} seconds to solve it. Avoid timeouts by running it locally.\e[0m"

echo ""
echo -e "Press [ENTER] to stop the instance"
read -n1

echo -e "Instance stopped"
