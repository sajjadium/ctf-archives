const std = @import("std");
const mr_gpu = @import("mr_gpu");
const zignal = @import("zignal");
const shader_ir = @import("shader_ir");
const shared = @import("shared.zig");
const Source = shared.Source;
const Uniform = shared.Uniform;

const VkBackend = @import("VkBackend");
const vk = VkBackend.vk;
pub const gpu_options: mr_gpu.Options = .{ .Backend = VkBackend };

const frame_limit = 32;
const pixel_limit = 0x100000;
const buffer_step = 0x10000;
const buffer_limit = pixel_limit * 4;

const pfnGetInstanceProcAddr = @extern(vk.PfnGetInstanceProcAddr, .{ .name = "vkGetInstanceProcAddr" });
fn createSurface(instance: vk.Instance, _: ?*anyopaque, alloc: ?*const vk.AllocationCallbacks) vk.SurfaceKHR {
    var info: vk.HeadlessSurfaceCreateInfoEXT = .{ .flags = .{}, .p_next = null };
    const iw = vk.InstanceWrapper.load(instance, pfnGetInstanceProcAddr);
    return iw.createHeadlessSurfaceEXT(instance, &info, alloc) catch .null;
}

const Config = struct {
    frames: u32 = 12,
    frame_duration_ms: u32 = 100,
    offset: u32 = 0,
};

const Renderer = struct {
    gx: mr_gpu.Gx,
    layout: mr_gpu.Pipeline.Layout,
    layout_opts: mr_gpu.Pipeline.Layout.Options,
    module: mr_gpu.ShaderModule,
    pipeline: mr_gpu.Pipeline,

    desc_set: mr_gpu.DescSet,
    desc_pool: mr_gpu.DescPool,
    cmd: *mr_gpu.CmdBuf,

    buffers: struct {
        uniform: mr_gpu.UploadBuf(.{ .uniform = true }),
        src: mr_gpu.UploadBuf(.{ .storage = true }),
        out: mr_gpu.ReadbackBuf(.{ .storage = true }),
    },

    fn init(alloc: std.mem.Allocator) Renderer {
        const options: mr_gpu.Gx.Options = .{
            .app_name = "glacier_holo",
            .engine_name = "glacier_holo",
            .frames_in_flight = 1,
            .timestamp_queries = false,
            .validation = .none,
            .surface_format = &.{mr_gpu.SurfaceFormatQuery.linearSrgb(0)},
            .surface_extent = .{ .width = 64, .height = 64 },
            .window = @fromBackingInt(@intCast(0)),
            .backend = .{
                .instance_extensions = &.{
                    vk.instance_extensions.khr_surface.name,
                    vk.instance_extensions.ext_headless_surface.name,
                },
                .getInstanceProcAddress = pfnGetInstanceProcAddr,
                .surface_context = null,
                .createSurface = createSurface,
            },
            .arena_capacity_log2 = 20,
        };
        var gx = mr_gpu.Gx.init(alloc, options);

        const layout_opts: mr_gpu.Pipeline.Layout.Options = .{
            .name = .{ .str = "holo" },
            .descs = &.{
                .{
                    .name = "uni",
                    .kind = .{
                        .uniform_buffer = .{ .size = @sizeOf(Uniform) },
                    },
                    .stages = .{ .compute = true },
                    .partially_bound = false,
                },
                .{ .name = "src", .kind = .storage_buffer, .stages = .{ .compute = true }, .partially_bound = false },
                .{ .name = "out", .kind = .storage_buffer, .stages = .{ .compute = true }, .partially_bound = false },
            },
        };
        const layout = mr_gpu.Pipeline.Layout.init(&gx, .{ .layout = layout_opts, .immutable_samplers = &.{} });
        const module = mr_gpu.ShaderModule.init(&gx, .{
            .name = .{ .str = "holo" },
            .ir = std.mem.bytesAsSlice(u32, &shader_ir.bytes),
        });

        var pipeline: mr_gpu.Pipeline = undefined;
        mr_gpu.Pipeline.initCompute(&gx, &.{
            .{
                .name = .{ .str = "holo" },
                .layout = layout,
                .result = &pipeline,
                .shader_module = module,
                .entry_point = "main",
            },
        });

        var uniform_buffer = mr_gpu.UploadBuf(.{ .uniform = true }).init(&gx, .{
            .name = .{ .str = "uni" },
            .size = @sizeOf(Uniform),
            .prefer_device_local = false,
        });

        const src_buffer = mr_gpu.UploadBuf(.{ .storage = true }).init(&gx, .{
            .name = .{ .str = "src" },
            .size = buffer_step,
            .prefer_device_local = false,
        });

        const out_buffer = mr_gpu.ReadbackBuf(.{ .storage = true }).init(&gx, .{
            .name = .{ .str = "out" },
            .size = buffer_step,
        });

        var set: mr_gpu.DescSet = undefined;
        const pool = mr_gpu.DescPool.init(&gx, .{
            .name = .{ .str = "holo_pool" },
            .cmds = &.{.{
                .name = .{ .str = "holo_pool" },
                .layout = layout.desc_set,
                .layout_options = &layout_opts,
                .result = &set,
            }},
        });

        gx.updateDescSets(&.{
            .{ .set = set, .binding = 0, .value = .{ .uniform_buf = uniform_buffer.asBuf(.{ .uniform = true }).view() } },
            .{ .set = set, .binding = 1, .value = .{ .storage_buf = src_buffer.asBuf(.{ .storage = true }).view() } },
        });

        var cbs: [1]*mr_gpu.CmdBuf = undefined;
        gx.cmd_pools[gx.frame].alloc(&gx, &cbs, .{ .str = "holo_cmd" });

        return .{
            .gx = gx,
            .layout = layout,
            .layout_opts = layout_opts,
            .module = module,
            .pipeline = pipeline,
            .desc_set = set,
            .desc_pool = pool,
            .cmd = cbs[0],
            .buffers = .{
                .uniform = uniform_buffer,
                .src = src_buffer,
                .out = out_buffer,
            },
        };
    }

    fn deinit(self: *Renderer, alloc: std.mem.Allocator) void {
        self.pipeline.deinit(&self.gx);
        self.module.deinit(&self.gx);
        self.layout.deinit(&self.gx);
        self.desc_pool.deinit(&self.gx);
        self.buffers.uniform.deinit(&self.gx);
        self.buffers.src.deinit(&self.gx);
        self.buffers.out.deinit(&self.gx);
        self.gx.deinit(alloc);
    }

    fn load(self: *Renderer, io: std.Io, alloc: std.mem.Allocator, r: *std.Io.Reader) !Source {
        var image = try zignal.png.read(zignal.Rgba(u8), io, alloc, r, .default);
        defer image.deinit(alloc);
        if (image.cols == 0 or image.rows == 0) return error.BadPng;

        const raw = image.asBytes();
        if (raw.len > buffer_limit) return error.ImageTooLarge;

        const aligned = std.mem.alignForward(usize, raw.len, buffer_step);
        if (self.buffers.out.data.len != aligned) {
            self.buffers.src.deinit(&self.gx);
            self.buffers.out.deinit(&self.gx);

            self.buffers.src = mr_gpu.UploadBuf(.{ .storage = true }).init(&self.gx, .{
                .name = .{ .str = "src" },
                .size = aligned,
                .prefer_device_local = false,
            });

            self.buffers.out = mr_gpu.ReadbackBuf(.{ .storage = true }).init(&self.gx, .{
                .name = .{ .str = "out" },
                .size = aligned,
            });
        }

        self.gx.updateDescSets(&.{
            .{ .set = self.desc_set, .binding = 1, .value = .{ .storage_buf = self.buffers.src.asBuf(.{ .storage = true }).view() } },
        });

        var image_writer = self.buffers.src.view().writer(&.{});
        image_writer.writeAllUnbuffered(raw);

        return .{
            .width = image.cols,
            .height = image.rows,
        };
    }

    fn run(self: *Renderer, io: std.Io, alloc: std.mem.Allocator, image: Source, output: *OutputAnimation, config: Config) !void {
        const pixel_count = std.math.mulWide(u32, image.width, image.height);
        if (pixel_count == 0 or pixel_count > pixel_limit) return error.ImageTooLarge;

        var out_view = self.buffers.out.asBuf(.{ .storage = true }).view();
        out_view.offset = config.offset;
        self.gx.updateDescSets(&.{
            .{ .set = self.desc_set, .binding = 2, .value = .{ .storage_buf = out_view } },
        });

        for (0..config.frames) |f| {
            var params_writer = self.buffers.uniform.view().writer(&.{});
            params_writer.writeStructUnbuffered(Uniform{
                .time = @as(f32, @floatFromInt(f)) * (std.math.tau / @as(f32, @floatFromInt(config.frames))),
                .noise_seed = @truncate(@intFromPtr(self.buffers.uniform.data.ptr) -% @intFromPtr(self.buffers.out.data.ptr)),
                .source = image,
            });

            self.gx.beginFrame(io);
            const cmd = self.cmd;

            cmd.begin(&self.gx, .{ .src = @src(), .name = "holo" });
            cmd.bindPipeline(&self.gx, .{
                .bind_point = .compute,
                .pipeline = self.pipeline,
            });
            cmd.bindDescSet(&self.gx, .{
                .bind_points = .{ .compute = true },
                .layout = self.layout.handle,
                .set = self.desc_set,
            });
            cmd.dispatch(&self.gx, .{
                .width = (image.width + 7) / 8,
                .height = (image.height + 7) / 8,
                .depth = 1,
            });
            cmd.end(&self.gx);

            self.gx.submit(&.{cmd});
            self.gx.endFrame(.{ .io = io, .present = null });
            self.gx.waitIdle();

            try output.feed(alloc, image, self.buffers.out.data.ptr[0..buffer_limit][0 .. pixel_count * 4], config.frame_duration_ms);
        }
    }
};

const OutputAnimation = struct {
    const Format = enum { gif, jxl };

    builder: zignal.Animation(zignal.Rgba(u8)).Builder = .{},

    fn reset(self: *OutputAnimation, alloc: std.mem.Allocator) void {
        for (self.builder.frames.items) |*image| image.deinit(alloc);
        self.builder.frames.clearRetainingCapacity();
        self.builder.durations_ms.clearRetainingCapacity();
    }

    fn feed(self: *OutputAnimation, alloc: std.mem.Allocator, input_image: Source, pixels: []const u8, frame_duration: u32) !void {
        const image: zignal.Image(zignal.Rgba(u8)) = .initFromBytes(input_image.height, input_image.width, @constCast(pixels));
        try self.builder.append(alloc, try image.dupe(alloc), frame_duration);
    }

    fn writeAnimated(self: *const OutputAnimation, io: std.Io, alloc: std.mem.Allocator, format: Format,  writer: *std.Io.Writer) !void {
        const animation: zignal.Animation(zignal.Rgba(u8)) = .{
            .frames = self.builder.frames.items,
            .durations_ms = self.builder.durations_ms.items,
            .loop_count = 0,
        };
        switch (format) {
            .jxl => try zignal.jxl.writeAnimated(zignal.Rgba(u8), io, alloc, writer, animation, .{ .quality = 100, .effort = 10 }),
            .gif => try zignal.gif.writeAnimated(zignal.Rgba(u8), io, alloc, writer, animation, .default),
        }
    }
};

const Holo = struct {
    io: std.Io,
    alloc: std.mem.Allocator,
    stdin: std.Io.File.Reader,
    stdout: std.Io.File.Writer,
    renderer: Renderer,

    input: ?Source = null,

    output: OutputAnimation = .{},
    config: Config = .{},

    fn deinit(self: *Holo) void {
        self.renderer.deinit(self.alloc);
        self.output.builder.deinit(self.alloc);
    }

    fn loadImage(self: *Holo) !void {
        const image = try self.renderer.load(self.io, self.alloc, &self.stdin.interface);

        if (std.math.mulWide(u32, image.width, image.height) > pixel_limit) {
            try self.stdout.interface.writeAll("image too large\n");
            return;
        }

        self.input = image;
        try self.stdout.interface.print("loaded {d}x{d}\n", .{ image.width, image.height });
    }

    fn renderImage(self: *Holo) !void {
        const image = self.input orelse return error.NoImage;

        self.output.reset(self.alloc);
        try self.renderer.run(self.io, self.alloc, image, &self.output, self.config);
        try self.stdout.interface.print("rendered {d}x{d}\n", .{ image.width, image.height });
    }

    fn exportImage(self: *Holo, format: OutputAnimation.Format) !void {
        if (self.output.builder.frames.items.len == 0) return error.NothingToExport;

        try self.stdout.interface.writeAll("EXPORT\n");
        try self.output.writeAnimated(self.io, self.alloc, format, &self.stdout.interface);
        try self.stdout.interface.writeAll("EXPORTEOF\n");
    }

    fn menu(self: *Holo) !void {
        try self.stdout.interface.writeAll(
            \\| glacier holo |
            \\1 load image
            \\2 render hologram
            \\3 export gif
            \\4 export jxl
            \\0 quit
            \\> 
        );
        try self.stdout.flush();
    }

    fn run(self: *Holo) !void {
        while (true) {
            try self.menu();
            const line = while (true) break try self.stdin.interface.takeDelimiter('\n') orelse continue;
            const choice = std.mem.trim(u8, line, " \t");
            if (choice.len == 0) continue;
            switch (choice[0]) {
                '1' => self.loadImage() catch |err| self.stdout.interface.print("loadImage error: {s}\n", .{@errorName(err)}) catch {},
                '2' => self.renderImage() catch |err| self.stdout.interface.print("renderImage error: {s}\n", .{@errorName(err)}) catch {},
                '3' => self.exportImage(.gif) catch |err| self.stdout.interface.print("exportImage(.gif) error: {s}\n", .{@errorName(err)}) catch {},
                '4' => self.exportImage(.jxl) catch |err| self.stdout.interface.print("exportImage(.jxl) error: {s}\n", .{@errorName(err)}) catch {},
                '_' => {
                    self.config.frames = @min(frame_limit, try self.stdin.interface.takeInt(u32, .little));
                    self.config.frame_duration_ms = try self.stdin.interface.takeInt(u32, .little);
                    self.config.offset = try self.stdin.interface.takeInt(u32, .little);
                },
                '0' => break,
                else => try self.stdout.interface.print("No such option: {s}\n", .{line}),
            }

            try self.stdout.flush();
        }
    }
};

pub fn main(init: std.process.Init) !void {
    const stdin_buffer = try init.gpa.alloc(u8, 0x1000);
    const stdout_buffer = try init.gpa.alloc(u8, 0x1000);
    defer init.gpa.free(stdin_buffer);
    defer init.gpa.free(stdout_buffer);
    var holo: Holo = .{
        .io = init.io,
        .alloc = init.gpa,
        .stdin = std.Io.File.stdin().readerStreaming(init.io, stdin_buffer),
        .stdout = std.Io.File.stdout().writerStreaming(init.io, stdout_buffer),
        .renderer = Renderer.init(init.gpa),
    };
    defer holo.deinit();
    try holo.run();
}
