const std = @import("std");
const shared = @import("shared.zig");
const Source = shared.Source;
const Uniform = shared.Uniform;
const spirv = std.spirv;

const Vec2 = @Vector(2, f32);
const Vec3 = @Vector(3, f32);
const Vec4 = @Vector(4, f32);
const U32x4 = @Vector(4, u32);
const I32x2 = @Vector(2, i32);

const Pixels = extern struct { data: @SpirvType(.{ .runtime_array = u32 }) };

const uni = @extern(*addrspace(.uniform) Uniform, .{
    .name = "holo_uni",
    .decoration = .{ .descriptor = .{ .set = 0, .binding = 0 } },
});
const src = @extern(*addrspace(.storage_buffer) Pixels, .{
    .name = "holo_src",
    .decoration = .{ .descriptor = .{ .set = 0, .binding = 1 } },
});
const out = @extern(*addrspace(.storage_buffer) Pixels, .{
    .name = "holo_out",
    .decoration = .{ .descriptor = .{ .set = 0, .binding = 2 } },
});

const luma = Vec3{ 0.299, 0.587, 0.114 };

fn uv(x: u32, y: u32) Vec2 {
    const wf: f32 = @floatFromInt(uni.source.width);
    const hf: f32 = @floatFromInt(uni.source.height);
    return .{
        (@as(f32, @floatFromInt(x)) + 0.5) / wf - 0.5,
        (@as(f32, @floatFromInt(y)) + 0.5) / hf - 0.5,
    };
}

fn hash(seed: u32, x: i32, y: i32) u32 {
    const cx: u32 = @bitCast(x);
    const cy: u32 = @bitCast(y);
    const cell = cx ^ std.math.rotl(u32, cy, 16);
    return std.hash.Murmur3_32.hashUint32WithSeed(cell, seed);
}

fn rand(seed: u32, x: i32, y: i32) f32 {
    const bits = hash(seed, x, y) >> 8;
    return @as(f32, @floatFromInt(bits)) * (1.0 / 16777215.0);
}

fn smootherstep(t: f32) f32 {
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

fn noise(x: u32, y: u32, offset: Vec2) f32 {
    const p: Vec2 = .{ @floatFromInt(x), @floatFromInt(y) };
    const cell = @floor(p + offset);
    const t = p - cell;
    const ix: i32 = @intFromFloat(cell[0]);
    const iy: i32 = @intFromFloat(cell[1]);
    const seed = uni.noise_seed;

    const s00 = rand(seed, ix, iy);
    const s10 = rand(seed, ix + 1, iy);
    const s01 = rand(seed, ix, iy + 1);
    const s11 = rand(seed, ix + 1, iy + 1);

    const tx = smootherstep(t[0]);
    const ty = smootherstep(t[1]);
    const x0 = s00 + (s10 - s00) * tx;
    const x1 = s01 + (s11 - s01) * tx;
    return x0 + (x1 - x0) * ty;
}

fn sample(x: i32, y: i32) Vec4 {
    const maxx: i32 = @intCast(uni.source.width - 1);
    const maxy: i32 = @intCast(uni.source.height - 1);
    const cx: u32 = @intCast(@min(@max(x, 0), maxx));
    const cy: u32 = @intCast(@min(@max(y, 0), maxy));
    const i = cy * uni.source.width + cx;
    const value = src.data[i];
    return @as(Vec4, @floatFromInt(U32x4{ value & 255, (value >> 8) & 255, (value >> 16) & 255, value >> 24 })) / @as(Vec4, @splat(255.0));
}

inline fn luminance(c: Vec4) f32 {
    return @reduce(.Add, Vec3{ c[0], c[1], c[2] } * luma);
}

inline fn clamp01(x: f32) f32 {
    return @min(@max(x, 0.0), 1.0);
}

inline fn clamp01v(v: Vec3) Vec3 {
    return @min(@max(v, @as(Vec3, @splat(0.0))), @as(Vec3, @splat(1.0)));
}

inline fn hue(h: f32) Vec3 {
    const half: Vec3 = @splat(0.5);
    const vh: Vec3 = @splat(h);
    return half + half * @cos(vh + Vec3{ 0.0, std.math.tau / 3.0, (2 * std.math.tau) / 3.0 });
}

inline fn normalize(v: Vec3) Vec3 {
    return v / @as(Vec3, @splat(@sqrt(@reduce(.Add, v * v))));
}

inline fn vec2Norm(p: Vec2) f32 {
    return @sqrt(@reduce(.Add, p * p));
}

fn hologram(x: u32, y: u32) Vec4 {
    const ix: i32 = @intCast(x);
    const iy: i32 = @intCast(y);
    const p = uv(x, y);
    const tilt = Vec2{ @sin(uni.time), @cos(uni.time) };

    const center = sample(ix, iy);
    if (center[3] == 0.0) return center; // alpha 0

    const l = luminance(center);
    const dx = luminance(sample(ix + 1, iy)) - luminance(sample(ix - 1, iy));
    const dy = luminance(sample(ix, iy + 1)) - luminance(sample(ix, iy - 1));
    const edge = @min(1.0, @sqrt(dx * dx + dy * dy) * 3.0);

    const shift = (l - 0.5) * 8.0;
    const off: I32x2 = @intFromFloat(tilt * @as(Vec2, @splat(shift)));
    const rs = sample(ix + off[0], iy + off[1]);
    const bs = sample(ix - off[0], iy - off[1]);

    const normal = normalize(Vec3{ -dx * 6.0, -dy * 6.0, 1.0 });
    const light = normalize(Vec3{ tilt[0] * 0.7, tilt[1] * 0.7, 0.7 });
    const ndl = clamp01(@reduce(.Add, normal * light));
    const spec = clamp01((ndl - 0.4) * 2.0);

    const spark_motion = tilt / @as(Vec2, @splat(12.0));
    const spark_noise = noise(x, y, spark_motion);
    const grain = noise(x, y, @splat(0)) - 0.5;
    const foil = @reduce(.Add, p * tilt) * 38 + vec2Norm(p) * 16 + ndl * 3 + grain * 2;
    const band = 0.5 + 0.5 * @sin(foil * 3.0);
    const fine = 0.5 + 0.5 * @sin(foil * 5.5 + vec2Norm(p) * 40);

    const spark: f32 = if (spark_noise > 1.12 - spec * 0.2) 0.35 + spark_noise * 0.5 else 0.0;

    const wave = foil * 0.04 + band * 0.2 + fine * 0.02;
    const tint = hue(wave * tilt[0] * 2);
    const glow = edge * 0.7 + spec * 0.7 + wave * 0.8;
    const emboss = (dx * tilt[0] + dy * tilt[1]) * 0.8;

    const base = Vec3{ rs[0], center[1], bs[2] } * @as(Vec3, @splat(0.55 + 0.25 * l));
    const color = clamp01v(base + tint * @as(Vec3, @splat(glow * 0.6)) + @as(Vec3, @splat(spark + emboss)));
    return .{ color[0], color[1], color[2], center[3] };
}

export fn main() callconv(.{ .spirv_kernel = .{ .x = 8, .y = 8, .z = 1 } }) void {
    const id = spirv.global_invocation_id;
    const x = id[0];
    const y = id[1];
    if (x >= uni.source.width or y >= uni.source.height) return;
    const c = hologram(x, y);
    const o: U32x4 = @intFromFloat(c * @as(Vec4, @splat(255.0)));
    out.data[y * uni.source.width + x] = o[0] | (o[1] << 8) | (o[2] << 16) | (o[3] << 24);
}
