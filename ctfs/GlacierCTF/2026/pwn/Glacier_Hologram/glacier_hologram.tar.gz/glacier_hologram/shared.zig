pub const Source = extern struct {
    width: u32,
    height: u32,
};

pub const Uniform = extern struct {
    time: f32,
    noise_seed: u32,
    source: Source,
};
