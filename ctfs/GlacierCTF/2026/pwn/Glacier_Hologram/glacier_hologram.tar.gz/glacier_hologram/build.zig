const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    const gpu = b.dependency("mr_gpu", .{ .target = target, .optimize = optimize });
    const zignal = b.dependency("zignal", .{ .target = target, .optimize = optimize });

    const spv_target = b.resolveTargetQuery(.{ .cpu_arch = .spirv64, .os_tag = .vulkan });
    const shader = b.addExecutable(.{ .name = "wm_shader", .root_module = b.createModule(.{
        .root_source_file = b.path("shader.zig"),
        .target = spv_target,
        .optimize = .ReleaseSmall,
    }) });
    shader.use_llvm = false;
    shader.use_lld = false;

    const wf = b.addWriteFiles();
    _ = wf.addCopyFile(shader.getEmittedBin(), "shader.spv");
    const shader_ir = wf.add("shader_ir.zig", "pub const bytes align(4) = @embedFile(\"shader.spv\").*;\n");

    const exe = b.addExecutable(.{
        .name = "challenge",
        .root_module = b.createModule(.{
            .root_source_file = b.path("main.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        }),
    });
    exe.root_module.addImport("mr_gpu", gpu.module("mr_gpu"));
    exe.root_module.addImport("VkBackend", gpu.module("VkBackend"));
    exe.root_module.addImport("zignal", zignal.module("zignal"));
    exe.root_module.addAnonymousImport("shader_ir", .{ .root_source_file = shader_ir });
    exe.root_module.linkSystemLibrary("vulkan", .{});
    b.installArtifact(exe);
}
