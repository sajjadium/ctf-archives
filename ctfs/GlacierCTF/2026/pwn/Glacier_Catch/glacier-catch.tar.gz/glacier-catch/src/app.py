#!/usr/bin/env python3
"""Serve one CHIP-8 session inside each challenge instance."""

import atexit
import io
import os
import subprocess
import tempfile
import threading
import time
from pathlib import Path

from PIL import Image, ImageGrab
from flask import Flask, Response, abort, jsonify, render_template, request
from waitress import serve


WIDTH, HEIGHT = 1280, 640
ROM_LIMIT = 0x1000 - 0x200
KEYS = set("1234qwerasdfzxcv")
KEY_ORDER = "x123qweasdzc4rfv"
DEFAULT_ROM = Path(__file__).resolve().parent / "static/glacier-catch.ch8"
DEFAULT_GAME = "Glacier Catch"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
# Leave web workers available for controls while browsers keep streams open.
stream_slots = threading.BoundedSemaphore(2)


class Emulator:
    def __init__(self):
        self.lock = threading.RLock()
        self.process = None
        self.rom_path = None
        self.window_id = None
        self.generation = 0
        self.game = None

    def running(self):
        with self.lock:
            return self.process is not None and self.process.poll() is None

    def status(self):
        with self.lock:
            running = self.running()
            title = None
            if running and self.window_id is not None:
                result = subprocess.run(
                    ["xdotool", "getwindowname", self.window_id],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    title = result.stdout.rstrip("\r\n")
            return {
                "running": running,
                "game": self.game if running else None,
                "title": title,
            }

    def stop(self):
        with self.lock:
            self.generation += 1
            if self.process is not None:
                if self.process.poll() is None:
                    self.process.terminate()
                    try:
                        self.process.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        self.process.kill()
                        self.process.wait()
                if self.process.stdin is not None:
                    self.process.stdin.close()
                self.process = None
            if self.rom_path is not None:
                Path(self.rom_path).unlink(missing_ok=True)
                self.rom_path = None
            self.window_id = None
            self.game = None

    def start(self, rom, game):
        with self.lock:
            self.stop()
            with tempfile.NamedTemporaryFile(prefix="chip8-", suffix=".rom", delete=False) as file:
                file.write(rom)
                self.rom_path = file.name

            try:
                self.process = subprocess.Popen(
                    ["/app/chip8", self.rom_path],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    close_fds=True,
                )
                # SDL creates its window asynchronously. Focus it so XTest key events reach it.
                for _ in range(60):
                    if self.process.poll() is not None:
                        break
                    result = subprocess.run(
                        ["xdotool", "search", "--onlyvisible", "--pid",
                         str(self.process.pid), "--name", "CHIP8 interpreter"],
                        capture_output=True,
                        text=True,
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        window_id = result.stdout.splitlines()[0]
                        if subprocess.run(
                            ["xdotool", "windowfocus", window_id],
                            capture_output=True,
                        ).returncode == 0:
                            self.window_id = window_id
                            self.generation += 1
                            self.game = game
                            return
                    time.sleep(0.05)
                raise RuntimeError("Emulator window did not start")
            except Exception:
                self.stop()
                raise

    def keys(self, events, buffered=False):
        with self.lock:
            if not self.running():
                return False
            if buffered:
                self.process.stdin.write(bytes(
                    KEY_ORDER.index(event["key"]) | (0x10 if event["pressed"] else 0)
                    for event in events
                ))
                self.process.stdin.flush()
                return True
            command = ["xdotool"]
            for event in events:
                command.extend(("keydown" if event["pressed"] else "keyup",
                                event["key"], "sleep", "0.01"))
            subprocess.run(command, check=True)
            return True


emulator = Emulator()
atexit.register(emulator.stop)


@app.get("/")
def index():
    with emulator.lock:
        if not emulator.running():
            try:
                emulator.start(DEFAULT_ROM.read_bytes(), DEFAULT_GAME)
            except (OSError, RuntimeError, subprocess.CalledProcessError):
                app.logger.exception("Could not start default game")
    return render_template("index.html")


@app.errorhandler(413)
def upload_too_large(_error):
    return jsonify(error="The ROM upload is too large."), 413


@app.get("/api/status")
def status():
    return jsonify(emulator.status())


@app.post("/api/default")
def start_default():
    try:
        emulator.start(DEFAULT_ROM.read_bytes(), DEFAULT_GAME)
    except (OSError, RuntimeError, subprocess.CalledProcessError):
        app.logger.exception("Could not start default game")
        return jsonify(error="The default game could not start."), 500
    return jsonify(emulator.status())


@app.post("/api/start")
def start():
    upload = request.files.get("rom")
    if upload is None:
        return jsonify(error="Choose a ROM file."), 400

    rom = upload.stream.read(ROM_LIMIT + 1)
    if not rom:
        return jsonify(error="The ROM is empty."), 400
    if len(rom) > ROM_LIMIT:
        return jsonify(error=f"ROMs must be at most {ROM_LIMIT} bytes."), 400

    try:
        emulator.start(rom, "Custom ROM")
    except (OSError, RuntimeError, subprocess.CalledProcessError):
        app.logger.exception("Could not start emulator")
        return jsonify(error="The emulator could not start."), 500
    return jsonify(emulator.status())


@app.post("/api/stop")
def stop():
    emulator.stop()
    return jsonify(emulator.status())


@app.post("/api/keys")
def keys():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        abort(400)
    events = data.get("events")
    buffered = data.get("buffered", False)
    if type(buffered) is not bool:
        abort(400)
    if not isinstance(events, list) or not 1 <= len(events) <= (2048 if buffered else 128):
        abort(400)
    if any(not isinstance(event, dict)
           or not isinstance(event.get("key"), str)
           or event["key"] not in KEYS
           or type(event.get("pressed")) is not bool for event in events):
        abort(400)
    try:
        if not emulator.keys(events, buffered):
            abort(409)
    except subprocess.CalledProcessError:
        app.logger.exception("Could not send keys to emulator")
        abort(500)
    except BrokenPipeError:
        abort(409)
    return ("", 204)


@app.get("/stream")
def stream():
    with emulator.lock:
        if not emulator.running():
            abort(409)
        generation = emulator.generation

    def frames():
        while emulator.running() and generation == emulator.generation:
            image = ImageGrab.grab(
                bbox=(0, 0, WIDTH, HEIGHT), xdisplay=os.environ["DISPLAY"]
            )
            image = image.resize((64, 32), Image.Resampling.NEAREST)
            output = io.BytesIO()
            image.save(output, format="JPEG", quality=95, subsampling=0)
            frame = output.getvalue()
            yield (b"--frame\r\nContent-Type: image/jpeg\r\nContent-Length: "
                   + str(len(frame)).encode() + b"\r\n\r\n" + frame + b"\r\n")
            time.sleep(1 / 12)

    response = Response(frames(), mimetype="multipart/x-mixed-replace; boundary=frame")
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Accel-Buffering"] = "no"
    if not stream_slots.acquire(blocking=False):
        abort(429)
    response.call_on_close(stream_slots.release)
    return response


if __name__ == "__main__":
    serve(
        app, host="0.0.0.0", port=1337, threads=8,
        max_request_body_size=app.config["MAX_CONTENT_LENGTH"],
        max_request_header_size=16 * 1024,
    )
