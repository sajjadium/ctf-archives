#!/bin/sh
. /.venv/bin/activate 2>&1 >/dev/null
export PATH="/.venv/bin:$PATH"
export DISPLAY=:99
Xvfb "$DISPLAY" -screen 0 1280x640x24 -nolisten tcp &

i=0
until [ -S /tmp/.X11-unix/X99 ]; do
    i=$((i + 1))
    if [ "$i" -ge 50 ]; then
        echo "Virtual display did not start" >&2
        exit 1
    fi
    sleep 0.1
done
/usr/bin/stdbuf -i0 -o0 -e0 /app/app.py
