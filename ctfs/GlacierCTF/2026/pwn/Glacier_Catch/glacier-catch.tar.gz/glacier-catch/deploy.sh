#!/bin/sh

check() {
  echo -e "\e[1;34m[+] Verifying Challenge Integrity\e[0m"
  sha256sum -c sha256sum
}

build_container() {
  echo -e "\e[1;34m[+] Building Challenge Docker Container\e[0m"
  docker build -t localhost/chall-glacier-catch --platform linux/amd64 --pull=true   . 
}

run_container() {
  echo -e "\e[1;34m[+] Running Challenge Docker Container on 127.0.0.1:1337\e[0m"
  docker run --name chall-glacier-catch --rm -p 127.0.0.1:1337:1337 -p 127.0.0.1:8080:8080 -e HOST=127.0.0.1 -e PORT=1337 -e PUBPORTSTART=11000 -e PUBPORTEND=15000 -e NAME=glacier-catch -e TIMEOUT=600 -e DOMAIN=localhost -e DOMAIN_PORT=8080 -e DOMAIN_PROT=http -e REGISTRY=localhost --privileged --platform linux/amd64 --pull=never localhost/chall-glacier-catch
}

kill_container() {
	docker ps --filter "name=chall-glacier-catch" --format "{{.ID}}" \
		| tr '\n' ' ' \
		| xargs docker stop -t 0 \
		|| true
}

case "${1}" in
  "check")
    check
    ;;
  "build")
    build_container
    ;;
  "run")
    run_container
    ;;
  "kill")
    kill_container
    ;;
  *)
    check
    build_container && run_container
    ;;
esac
