#!/usr/bin/env bash

echo -e "Press [ENTER] to start the instance"
read -n1

# Generate temporary directory per connection
DIR="$(mktemp -d /tmp/gctf-qemu.XXXXXX)"
QEMU_PID=""

cleanup()
{
    set +e

    if [[ -n "$QEMU_PID" ]] && kill -0 "$QEMU_PID" 2>/dev/null; then
        kill "$QEMU_PID" 2>/dev/null
        sleep 1
        kill -KILL "$QEMU_PID" 2>/dev/null
        wait "$QEMU_PID" 2>/dev/null
    fi

    cd /
    if [[ "$DIR" == /tmp/gctf-qemu.* && -d "$DIR" ]]; then
        rm -rf -- "$DIR"
    fi
}

trap cleanup EXIT INT TERM HUP
cd "$DIR"

echo -e "\e[1;34m[+] Generating personal access key...\e[0m"
echo ""

if ! ssh-keygen -t ed25519 -C "player@gctf" -q -N "" -f key; then
    echo "Failed to generate instance credentials."
    exit 1
fi
cat key

echo ""
echo -e "\e[1;34m[+] 1. Paste the key to a file 'key'\e[0m"
echo -e "\e[1;34m[+] 2. Fix key permissions with 'chmod 600 key'\e[0m"

PORT=""
PORT_LOCK_FD=""

for candidate in $(seq "$PUBPORTSTART" "$PUBPORTEND"); do
    exec {fd}>"/tmp/port-${candidate}.lock"

    if flock -n "$fd"; then
        PORT="$candidate"
        PORT_LOCK_FD="$fd"
        break
    fi

    eval "exec ${fd}>&-"
done

if [[ -z "$PORT" ]]; then
    echo "All challenge instances are busy. Try again later."
    exit 1
fi

test -r /dev/kvm -a -w /dev/kvm || {
    echo "/dev/kvm is unavailable inside the container"
    exit 1
}

cp --reflink=auto /app/rootfs.qcow2 "$DIR/rootfs.qcow2"
if ! truncate -s 128M "$DIR/ntfs.img" ||
   ! /usr/sbin/mkntfs --force --quick --label ntfs3rot \
       --sector-size 512 --cluster-size 4096 \
       "$DIR/ntfs.img" >/dev/null 2>&1; then
    echo "Failed to create the NTFS challenge volume."
    exit 1
fi
cp /app/flag.txt "$DIR/flag.txt"

qemu-system-x86_64 \
    -accel kvm \
    -cpu host \
    -kernel /app/bzImage \
    -drive file="$DIR/rootfs.qcow2",format=qcow2,if=virtio \
    -drive file="$DIR/key.pub",format=raw,if=virtio,readonly=on \
    -drive file="$DIR/flag.txt",format=raw,if=virtio,readonly=on \
    -drive file="$DIR/ntfs.img",format=raw,if=virtio \
    -device virtio-rng-pci \
    -netdev user,id=net0,hostfwd=tcp::"${PORT}"-:22 \
    -device virtio-net-pci,netdev=net0 \
    -display none \
    -serial file:"$DIR/serial.log" \
    -monitor none \
    -no-reboot \
    -m 768M \
    -smp 4,sockets=1,cores=4,threads=1 \
    -append "root=/dev/vda rw rootwait console=ttyS0 panic=1 oops=panic" \
    >"$DIR/qemu.log" 2>&1 &

QEMU_PID=$!

sleep 1

if ! kill -0 "$QEMU_PID" 2>/dev/null; then
    echo "Instance failed to start. Contact an administrator."
    exit 1
fi

echo -e "\e[1;34m[+] 3. Wait 10-30 seconds for the system to boot\e[0m"
echo -e "\e[1;34m[+] 4. Clean known_hosts with ssh-keygen -R \"[${DOMAIN}]:${PORT}\"\e[0m"
echo -e "\e[1;34m[+] 5. Connect with 'ssh -p${PORT} -i key user@${DOMAIN}'\e[0m"
echo -e "\e[1;34m[+] 6. Copy exploit files with 'scp -P ${PORT} -i key ./LOCALEXPLOIT user@${DOMAIN}:~/'\e[0m"

echo ""

echo -e "\e[1;34m[+] You have ${TIMEOUT} seconds to solve it. Avoid timeouts by running it locally.\e[0m"

echo ""
echo -e "Press [ENTER] to stop the instance"
read -n1

echo -e "Instance stopped"
