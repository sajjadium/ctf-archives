from __future__ import annotations

import random
import string


PRIMES = [
     3,   5,   7,  11,  13,  17,  19,  23,  29,  31,  37,  41,  43,  47,
    53,  59,  61,  67,  71,  73,  79,  83,  89,  97, 101, 103, 107, 109, 113,
   127, 131, 179

]
BLOCK_SIZE = len(PRIMES)

class CSI_HASH:
    def __init__(self) -> "CSI_HASH":
        self.primes = PRIMES
        self.p = 4 * prod(self.primes) - 1

    def digest(self, message):
        blocks = [
            message[i*BLOCK_SIZE: (i+1)*BLOCK_SIZE]
            for i in range((len(message)+(BLOCK_SIZE - 1))//BLOCK_SIZE)
        ]

        # Add padding to incomplete blocks
        if(len(blocks[-1]) != 4):
            blocks[-1] += bytes.fromhex('80' * (BLOCK_SIZE - len(blocks[-1])))

        # Process the blocks
        block_result = self.process_block(0, blocks[0])
        i = 1
        while i < len(blocks):
            block_result = self.process_block(block_result, blocks[i])
            i += 1

        return block_result

    def process_block(self, intermediate_hash, message_block):
        E = self.montgomery_curve(intermediate_hash, self.p)
        es = [item for item in message_block][:]

        while any(es):
            E._order = (self.p + 1)**2

            P = E.lift_x(GF(self.p).random_element())
            s = +1 if P.xy()[1] in GF(self.p) else -1
            k = prod(
                l 
                for l, e in zip(self.primes, es)
                if sign(e) == s
            )
            P *= (self.p + 1) // k

            for i, (l, e) in enumerate(zip(self.primes, es)):
                if sign(e) != s:
                    continue
                Q = k // l * P
                if not Q: 
                    continue

                Q._order = l
                phi = E.isogeny(Q)
                E, P = phi.codomain(), phi(P)
                es[i] -= s
                k //= l

        return self.montgomery_coefficient(E)

    def montgomery_coefficient(self, E):
        Ew = E.change_ring(GF(self.p)).short_weierstrass_model()
        _, _, _, a, b = Ew.a_invariants()
        R.<z> = GF(self.p)[]
        r = (z**3 + a*z + b).roots(multiplicities=False)[0]
        s = sqrt(3 * r**2 + a)
        if not is_square(s): s = -s
        A = 3 * r / s
        assert self.montgomery_curve(A, self.p).change_ring(GF(self.p)).is_isomorphic(Ew)
        return GF(self.p)(A)

    def montgomery_curve(self, A, p):
        Fp2.<i> = GF(p**2, modulus = x**2 + 1)
        return EllipticCurve(Fp2, [0, A, 0, 1, 0])


def main():
    hash = CSI_HASH()
    challenge_msg = "".join(random.choices(string.ascii_letters, k=BLOCK_SIZE))

    print("Welcome to CSI-HASH")
    print("I bet you aren't able to find a preimage!")

    print(f"Here is your challenge: {challenge_msg}")
    message = input("> ")
    message.strip()
    print("Let me compute the hashes ... this might take some time")

    if challenge_msg == message:
        print("Hey, don't cheat!")
        exit(1)

    if(hash.digest(challenge_msg.encode()) == hash.digest(message.encode())):
        print(f"Wow, you fund a preimage?")
        with open('flag.txt', 'r') as flag:
            print(f"Here, take this: {flag.read()}")
    else:
        print("Sorry, they do not match :(")

if __name__ == "__main__":
    main()
