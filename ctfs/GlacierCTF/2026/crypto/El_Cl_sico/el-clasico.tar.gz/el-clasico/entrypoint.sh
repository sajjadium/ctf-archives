#!/bin/sh
set -eu
cd /app
# Override challenge.go's default :8080 to match template Makefile RARGS.
exec /app/challenge -listen :1337
