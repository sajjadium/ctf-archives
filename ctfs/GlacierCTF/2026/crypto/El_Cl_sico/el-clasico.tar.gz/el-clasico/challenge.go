package main

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"os"
	"strings"

	"github.com/consensys/gnark-crypto/ecc"
	bls12381 "github.com/consensys/gnark-crypto/ecc/bls12-381"
	"github.com/consensys/gnark/backend/groth16"
	"github.com/consensys/gnark/frontend"
	"github.com/consensys/gnark/frontend/cs/r1cs"
	"github.com/consensys/gnark/std/algebra/emulated/sw_emulated"
	"github.com/consensys/gnark/std/math/emulated"
)

type ChallengeCircuit struct {
	S emulated.Element[emulated.BLS12381Fr]        `gnark:",public"`
	P sw_emulated.AffinePoint[emulated.BLS12381Fp] `gnark:",public"`
	A sw_emulated.AffinePoint[emulated.BLS12381Fp] `gnark:",public"`
}

func (c *ChallengeCircuit) Define(api frontend.API) error {
	curve, err := sw_emulated.New[emulated.BLS12381Fp, emulated.BLS12381Fr](
		api, sw_emulated.GetBLS12381Params(),
	)
	if err != nil {
		return err
	}
	fp, err := emulated.NewField[emulated.BLS12381Fp](api)
	if err != nil {
		return err
	}
	fr, err := emulated.NewField[emulated.BLS12381Fr](api)
	if err != nil {
		return err
	}

	fr.AssertIsInRange(&c.S)
	api.AssertIsEqual(fr.IsZero(&c.S), 0)

	curve.AssertIsOnCurve(&c.P)
	curve.AssertIsInSubgroup(&c.P)

	q := curve.ScalarMul(&c.P, &c.S)
	dx := fp.Sub(&q.X, &c.A.X)
	dy := fp.Add(&q.Y, &c.A.Y)

	fp.AssertIsDifferent(&q.X, &c.A.X)
	// (Q.x - a)^3 = (Q.y + b)^2 mod p
	fp.AssertIsEqual(fp.Mul(fp.Mul(dx, dx), dx), fp.Mul(dy, dy))
	return nil
}

type SubmitRequest struct {
	S        string `json:"s"`
	PX       string `json:"p_x"`
	PY       string `json:"p_y"`
	ProofHex string `json:"proof_hex"`
}

func parseElement(value string, modulus *big.Int, positive bool) (*big.Int, error) {
	if value == "" {
		return nil, fmt.Errorf("missing decimal integer")
	}
	for _, digit := range value {
		if digit < '0' || digit > '9' {
			return nil, fmt.Errorf("expected unsigned decimal integer")
		}
	}
	n, ok := new(big.Int).SetString(value, 10)
	if !ok || n.Cmp(modulus) >= 0 || (positive && n.Sign() == 0) {
		if positive {
			return nil, fmt.Errorf("expected integer in (0, modulus)")
		}
		return nil, fmt.Errorf("expected integer in [0, modulus)")
	}
	return n, nil
}

func (req SubmitRequest) assignment(target bls12381.G1Affine) (*ChallengeCircuit, error) {
	var fr emulated.BLS12381Fr
	var fp emulated.BLS12381Fp

	s, err := parseElement(req.S, fr.Modulus(), true)
	if err != nil {
		return nil, fmt.Errorf("s: %w", err)
	}
	if new(big.Int).Mod(s, big.NewInt(9)).Sign() == 0 {
		return nil, fmt.Errorf("s must not be a multiple of 9")
	}
	px, err := parseElement(req.PX, fp.Modulus(), false)
	if err != nil {
		return nil, fmt.Errorf("p_x: %w", err)
	}
	py, err := parseElement(req.PY, fp.Modulus(), false)
	if err != nil {
		return nil, fmt.Errorf("p_y: %w", err)
	}

	return &ChallengeCircuit{
		S: emulated.ValueOf[emulated.BLS12381Fr](s),
		P: sw_emulated.AffinePoint[emulated.BLS12381Fp]{
			X: emulated.ValueOf[emulated.BLS12381Fp](px),
			Y: emulated.ValueOf[emulated.BLS12381Fp](py),
		},
		A: sw_emulated.AffinePoint[emulated.BLS12381Fp]{
			X: emulated.ValueOf[emulated.BLS12381Fp](target.X.BigInt(new(big.Int))),
			Y: emulated.ValueOf[emulated.BLS12381Fp](target.Y.BigInt(new(big.Int))),
		},
	}, nil
}

func randomTarget() (bls12381.G1Affine, error) {
	var fr emulated.BLS12381Fr
	for {
		k, err := rand.Int(rand.Reader, fr.Modulus())
		if err != nil {
			return bls12381.G1Affine{}, err
		}
		if k.Sign() == 0 {
			continue
		}
		var target bls12381.G1Affine
		target.ScalarMultiplicationBase(k)
		return target, nil
	}
}

func challengeHandler(target bls12381.G1Affine) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]string{
			"a":          target.X.String(),
			"b":          target.Y.String(),
			"submission": "POST /submit with decimal strings s, p_x, p_y, plus hex-encoded Groth16 proof_hex",
		})
	}
}

func submitHandler(vk groth16.VerifyingKey, flagStr string, target bls12381.G1Affine) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
		defer r.Body.Close()

		var req SubmitRequest
		decoder := json.NewDecoder(r.Body)
		decoder.DisallowUnknownFields()
		if err := decoder.Decode(&req); err != nil {
			http.Error(w, "invalid JSON", http.StatusBadRequest)
			return
		}
		if err := decoder.Decode(new(any)); err != io.EOF {
			http.Error(w, "expected exactly one JSON object", http.StatusBadRequest)
			return
		}

		assignment, err := req.assignment(target)
		if err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		proofBytes, err := hex.DecodeString(req.ProofHex)
		if err != nil {
			http.Error(w, "invalid proof hex", http.StatusBadRequest)
			return
		}
		proof := groth16.NewProof(ecc.BN254)
		reader := bytes.NewReader(proofBytes)
		if _, err := proof.ReadFrom(reader); err != nil || reader.Len() != 0 {
			http.Error(w, "invalid proof encoding", http.StatusBadRequest)
			return
		}

		publicWitness, err := frontend.NewWitness(assignment, ecc.BN254.ScalarField(), frontend.PublicOnly())
		if err != nil {
			http.Error(w, "failed to build public witness", http.StatusInternalServerError)
			return
		}
		if err := groth16.Verify(proof, vk, publicWitness); err != nil {
			http.Error(w, "invalid proof", http.StatusBadRequest)
			return
		}
		fmt.Fprintf(w, "Flag is: %s\n", flagStr)
	}
}

func writeHex(path string, value io.WriterTo) error {
	var buf bytes.Buffer
	if _, err := value.WriteTo(&buf); err != nil {
		return err
	}
	return os.WriteFile(path, []byte(hex.EncodeToString(buf.Bytes())), 0600)
}

func setup() error {
	ccs, err := frontend.Compile(ecc.BN254.ScalarField(), r1cs.NewBuilder, &ChallengeCircuit{})
	if err != nil {
		return err
	}
	pk, vk, err := groth16.Setup(ccs)
	if err != nil {
		return err
	}
	if err := writeHex("pk.hex", pk); err != nil {
		return err
	}
	return writeHex("vk.hex", vk)
}

func run() error {
	doSetup := flag.Bool("setup", false, "generate pk.hex and vk.hex")
	addr := flag.String("listen", ":1337", "HTTP listen address")
	flag.Parse()

	if *doSetup {
		return setup()
	}
	data, err := os.ReadFile("vk.hex")
	if err != nil {
		return err
	}
	keyBytes, err := hex.DecodeString(strings.TrimSpace(string(data)))
	if err != nil {
		return fmt.Errorf("invalid vk.hex: %w", err)
	}
	vk := groth16.NewVerifyingKey(ecc.BN254)
	reader := bytes.NewReader(keyBytes)
	if _, err := vk.ReadFrom(reader); err != nil {
		return fmt.Errorf("invalid vk.hex: %w", err)
	}
	if reader.Len() != 0 {
		return fmt.Errorf("invalid vk.hex: trailing data")
	}

	flagData, err := os.ReadFile("flag.txt")
	if err != nil {
		return err
	}
	target, err := randomTarget()
	if err != nil {
		return fmt.Errorf("generate target: %w", err)
	}

	mux := http.NewServeMux()
	mux.HandleFunc("GET /challenge", challengeHandler(target))
	mux.HandleFunc("POST /submit", submitHandler(vk, strings.TrimSpace(string(flagData)), target))
	fmt.Printf("listening on %s (random target generated)\n", *addr)
	return http.ListenAndServe(*addr, mux)
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
