#!/usr/bin/env python3
import numpy as np


def galois_multiply(a, b):
    """Galois Field multiplication for AES"""
    p = 0
    while b:
        if b & 1:
            p ^= a
        a <<= 1
        if a & 0x100:
            a ^= 0x1b
        b >>= 1

    return p & 0xff

# Precompute the multiplication tables for encryption
gf_mul_by_2  = np.array([galois_multiply(x,  2) for x in range(256)], dtype=np.uint8)
gf_mul_by_3  = np.array([galois_multiply(x,  3) for x in range(256)], dtype=np.uint8)
# ... for decryption
gf_mul_by_9  = np.array([galois_multiply(x,  9) for x in range(256)], dtype=np.uint8)
gf_mul_by_11 = np.array([galois_multiply(x, 11) for x in range(256)], dtype=np.uint8)
gf_mul_by_13 = np.array([galois_multiply(x, 13) for x in range(256)], dtype=np.uint8)
gf_mul_by_14 = np.array([galois_multiply(x, 14) for x in range(256)], dtype=np.uint8)

def invert_sbox(sbox: bytearray) -> bytearray:
    inv = bytearray(256)
    for i, v in enumerate(sbox):
        inv[v] = i
    return inv


SBOX = bytearray.fromhex(
    "63bf5589ee32d8041bc72df1964aa07c8458b26e09d53fe3fc20ca1671ad479b"
    "05d933ef8854be627da14b97f02cc61ae23ed4086fb359859a46ac7017cb21fd"
    "07dbd60a8a565b877fa3ae72f22e23ffe03c31ed6db1bc609844499515c9c418"
    "865a578b0bd7da06fe222ff373afa27e61bdb06cec303de119c5c81494484599"
    "27fb11cdaa769c405f8369b5d20ee438c01cf62a4d917ba7b8648e5235e903df"
    "419d77abcc10fa2639e50fd3b468825ea67a904c2bf71dc1de02e834538f65b9"
    "439f924ece121fc33be7ea36b66a67bba47875a929f5f824dc000dd1518d805c"
    "c21e13cf4f939e42ba666bb737ebe63a25f9f428a87479a55d818c50d00c01dd"
)
INV_SBOX = invert_sbox(SBOX)

RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


def sub_word(w: bytes) -> bytes:
    return bytes(SBOX[b] for b in w)


def rot_word(w: bytes) -> bytes:
    return w[1:] + w[:1]


def key_schedule(base_key: bytes, num_keys: int = 11) -> np.ndarray:
    """Standard AES-128 key expansion (using our SBOX for SubWord),
    producing `num_keys` 16-byte round keys from a 16-byte base key."""
    if len(base_key) != 16:
        raise ValueError("base key must be 16 bytes")

    words = [bytearray(base_key[4 * i:4 * i + 4]) for i in range(4)]
    for i in range(4, num_keys * 4):
        temp = bytearray(words[i - 1])
        if i % 4 == 0:
            temp = bytearray(sub_word(rot_word(bytes(temp))))
            temp[0] ^= RCON[i // 4 - 1]
        words.append(bytearray(a ^ b for a, b in zip(words[i - 4], temp)))

    round_keys = []
    for r in range(num_keys):
        rk = bytearray()
        for w in words[4 * r:4 * r + 4]:
            rk.extend(w)
        round_keys.append(rk)
    return np.array(round_keys)


class DeCipher:
    @staticmethod
    def mix_columns(block):
        for i in range(4):
            col = i * 4

            v0, v1, v2, v3 = (block[col], block[col + 1], block[col + 2],
                            block[col + 3])

            block[col  ] = gf_mul_by_2[v0] ^ v3 ^ v2 ^ gf_mul_by_3[v1]
            block[col+1] = gf_mul_by_2[v1] ^ v0 ^ v3 ^ gf_mul_by_3[v2]
            block[col+2] = gf_mul_by_2[v2] ^ v1 ^ v0 ^ gf_mul_by_3[v3]
            block[col+3] = gf_mul_by_2[v3] ^ v2 ^ v1 ^ gf_mul_by_3[v0]


    @staticmethod
    def mix_columns_inv(block):
        for i in range(4):
            col = i * 4

            v0, v1, v2, v3 = (block[col], block[col + 1], block[col + 2],
                            block[col + 3])

            block[col  ] = gf_mul_by_14[v0] ^ gf_mul_by_9[v3] ^ gf_mul_by_13[v2] ^ gf_mul_by_11[v1]
            block[col+1] = gf_mul_by_14[v1] ^ gf_mul_by_9[v0] ^ gf_mul_by_13[v3] ^ gf_mul_by_11[v2]
            block[col+2] = gf_mul_by_14[v2] ^ gf_mul_by_9[v1] ^ gf_mul_by_13[v0] ^ gf_mul_by_11[v3]
            block[col+3] = gf_mul_by_14[v3] ^ gf_mul_by_9[v2] ^ gf_mul_by_13[v1] ^ gf_mul_by_11[v0]

    @staticmethod
    def shift_rows(b):
        b[1], b[5], b[ 9], b[13] = b[ 5], b[ 9], b[13], b[ 1]
        b[2], b[6], b[10], b[14] = b[10], b[14], b[ 2], b[ 6]
        b[3], b[7], b[11], b[15] = b[15], b[ 3], b[ 7], b[11]

    @staticmethod
    def shift_rows_inv(b):
        b[ 5], b[ 9], b[13], b[ 1] = b[1], b[5], b[ 9], b[13]
        b[10], b[14], b[ 2], b[ 6] = b[2], b[6], b[10], b[14]
        b[15], b[ 3], b[ 7], b[11] = b[3], b[7], b[11], b[15]


    def _encrypt(self, pt: bytes, proof: list[bytearray]) -> bytes:
        state = bytearray(pt)

        for rk in self._round_keys[:-1]:
            proof.append(bytearray(state))
            for i in range(16):
                state[i] = SBOX[state[i] ^ rk[i]]
            DeCipher.shift_rows(state)
            DeCipher.mix_columns(state)

        proof.append(bytearray(state))

        for i in range(16):
            state[i] = state[i] ^ self._round_keys[-1][i]

        return bytes(state)

    def encrypt(self, pt: bytes):
        if len(pt) != 16:
            raise ValueError()

        proof: list[bytearray] = []
        state = self._encrypt(pt, proof)

        self._proofs.append(proof)
        return state

    def decrypt(self, ct: bytes) -> bytes:
        if len(ct) != 16:
            raise ValueError()

        state = bytearray(ct)
        for i in range(16):
            state[i] ^= self._round_keys[-1][i]

        for rk in reversed(self._round_keys[:-1]):
            DeCipher.mix_columns_inv(state)
            DeCipher.shift_rows_inv(state)
            for i in range(16):
                state[i] = INV_SBOX[state[i]] ^ rk[i]

        return bytes(state)

    def gen_proofs(self) -> np.ndarray:
        proofs = np.array(self._proofs)
        second_order_proofs = proofs[:, None] ^ proofs[None, :]
        return second_order_proofs


    def __init__(self, key: bytes, num_rounds: int = 10):
        if len(key) != 16:
            raise ValueError('only 128-bit (16-byte) keys supported')
        self._round_keys = key_schedule(key, num_rounds + 1)
        self._proofs = []


if __name__ == "__main__":
    key = bytes(range(16))
    pt = bytes(range(16, 32))

    cipher = DeCipher(key)
    ct = cipher.encrypt(pt)
    decrypted = cipher.decrypt(ct)

    assert decrypted == pt, f"{decrypted.hex()} != {pt.hex()}"
    print("OK:", pt.hex(), "->", ct.hex(), "->", decrypted.hex())
