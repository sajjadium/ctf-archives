#!/usr/bin/env python3
import os
from hashlib import sha256
from pathlib import Path

import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from decipher import DeCipher

if __name__ == '__main__':
    base_key = os.urandom(16)
    decipher = DeCipher(base_key)

    plaintexts = [os.urandom(16) for _ in range(16)]
    ciphertexts = [decipher.encrypt(pt) for pt in plaintexts]
    proofs = decipher.gen_proofs()

    try:
        flag = Path('flag-stage2.txt').read_text().strip()
    except FileNotFoundError:
        print('[!] WARN: using demo flag')
        flag = 'gctf{DEMO_STAGE2_DEMO}'

    aes = AESGCM(sha256(decipher._round_keys).digest())
    flag_enc = aes.encrypt(b'\0' * 12, flag.encode(), None)

    print(f"[*] Here's your flag: {flag_enc.hex()}")

    with open('output_stage2.npz', 'wb') as f:
        flag_np = np.array(bytearray(flag_enc))
        plaintexts_np = np.array([bytearray(pt) for pt in plaintexts])
        ciphertexts_np = np.array([bytearray(ct) for ct in ciphertexts])
        np.savez(f, flag=flag_np, plaintexts=plaintexts_np, ciphertexts=ciphertexts_np, proofs=proofs)
