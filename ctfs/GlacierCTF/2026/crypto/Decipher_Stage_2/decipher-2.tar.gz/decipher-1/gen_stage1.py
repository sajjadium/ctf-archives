#!/usr/bin/env python3
import os
from hashlib import sha256
from pathlib import Path

import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from decipher import DeCipher

if __name__ == '__main__':
    base_key = os.urandom(16)
    decipher = DeCipher(base_key)

    plaintexts = [os.urandom(16) for _ in range(16)]
    ciphertexts = [decipher.encrypt(pt) for pt in plaintexts]
    proofs = decipher.gen_proofs()

    flag_key = os.urandom(16)
    print(f'flag key {flag_key.hex()}')
    wrapped_key = decipher.encrypt(flag_key)

    try:
        flag = Path('flag-stage1.txt').read_text().strip()
    except FileNotFoundError:
        print('[!] WARN: using demo flag')
        flag = 'gctf{DEMO_STAGE1_DEMO}'

    aes = AESGCM(flag_key)
    flag_enc = aes.encrypt(b'\0' * 12, flag.encode(), None)

    print(f"[*] Here's your flag: {flag_enc.hex()}")
    print(f"[*] Wrapped key: {wrapped_key.hex()}")

    with open('output_stage1.npz', 'wb') as f:
        flag_np = np.array(bytearray(flag_enc))
        plaintexts_np = np.array([bytearray(pt) for pt in plaintexts])
        ciphertexts_np = np.array([bytearray(ct) for ct in ciphertexts])
        wrapped_key_np = np.array(bytearray(wrapped_key))
        np.savez(f, flag=flag_np, plaintexts=plaintexts_np, ciphertexts=ciphertexts_np, proofs=proofs, wrapped_key=wrapped_key_np)
