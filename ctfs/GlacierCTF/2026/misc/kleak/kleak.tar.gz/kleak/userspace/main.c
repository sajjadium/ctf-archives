#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include <getopt.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <assert.h>

#define STABLE 500
#define UNSTABLE 800
#define PAGE_SIZE 4096

#define BUG_ON(cond)                                           \
  do {                                                         \
    if (__builtin_expect(!!(cond), 0)) {                       \
      fprintf(stderr, "Error on %s:%d\n", __FILE__, __LINE__); \
      abort();                                                 \
    }                                                          \
  } while (0)

static void copy_page(void* _dst, void* _src) {
  uint64_t* src = (uint64_t*)_src;
  uint64_t* dst = (uint64_t*)_dst;
  for (uint32_t i = 0; i < PAGE_SIZE / 8; i++)
    dst[i] = src[i];
}

static void* alloc_page() {
  void* p = aligned_alloc(PAGE_SIZE, PAGE_SIZE);
  assert(p != NULL);
  return p;
}

static void zero_page(void* p) {
  uint64_t* ptr = (uint64_t*)p;
  for (uint32_t i = 0; i < PAGE_SIZE / 8; i++)
    ptr[i] = 0x00;
  ptr[511] = 0x1;
}

static void* alloc_zero_page() {
  void* p = alloc_page();
  zero_page(p);
  return p;
}


static void random_bytes(void *buf, size_t size) {
  uint8_t *cursor = buf;

  while (size != 0) {
    ssize_t ret = getrandom(cursor, size, 0);
    if (ret < 0 && errno == EINTR)
      continue;
    BUG_ON(ret <= 0);
    cursor += (size_t)ret;
    size -= (size_t)ret;
  }
}

static uint32_t random_below(uint32_t bound) {
  uint32_t value;
  uint32_t threshold;

  BUG_ON(bound == 0);
  threshold = -bound % bound;
  do {
    random_bytes(&value, sizeof(value));
  } while (value < threshold);

  return value % bound;
}

static void randomize_page(void *p) {
  random_bytes(p, PAGE_SIZE);
}

int main(int argc, char* argv[]) {
  (void)argc;
  (void)argv;

  FILE *f = fopen("/flag.txt", "r");
  BUG_ON(f == NULL);

  BUG_ON(fseek(f, 0, SEEK_END) != 0);
  long fsize = ftell(f);
  BUG_ON(fsize < 0 || fsize > PAGE_SIZE);
  BUG_ON(fseek(f, 0, SEEK_SET) != 0);

  void *flag = alloc_zero_page();
  memset(flag, 0x0, PAGE_SIZE);
  size_t flag_size = (size_t)fsize;
  size_t ret = fread(flag, 1, flag_size, f);
  BUG_ON(ret != flag_size);
  fclose(f);

  uint8_t *a   = aligned_alloc(PAGE_SIZE, STABLE   * 2 * PAGE_SIZE);
  uint8_t *b   = aligned_alloc(PAGE_SIZE, UNSTABLE * 1 * PAGE_SIZE);

  uint32_t secret_pair = random_below(STABLE);

  for(uint64_t i = 0; i < STABLE; i++) {
    uint8_t *p1 = a + ((i * 2 + 0) * PAGE_SIZE);
    uint8_t *p2 = a + ((i * 2 + 1) * PAGE_SIZE);
    randomize_page(p1);
    copy_page(p2, p1);

    if(i == secret_pair) {
      copy_page(p1, flag);
      copy_page(p2, flag);
    }
  }
  BUG_ON(madvise(a, STABLE * 2 * PAGE_SIZE, MADV_MERGEABLE) != 0);

  /**
   * Generate unstable noise pages
   */
  for(uint64_t i = 0 ; i < UNSTABLE ; i++) {
    uint8_t *p1 = (b + (i * PAGE_SIZE));
    randomize_page(p1);
  }
  BUG_ON(madvise(b , UNSTABLE * 1 * PAGE_SIZE, MADV_MERGEABLE) != 0);

  printf("[+] Challenge started\n");
  while(1){ sleep(60000); }

  return 0;
}
