#!/bin/sh
set -eu

echo 0 > /tmp/port
/app/cleaner.sh &

MAX_CHILDREN=$((PUBPORTEND - PUBPORTSTART))
if [ "${MAX_CHILDREN}" -le 0 ]; then
	echo "Invalid public port range" >&2
	exit 1
fi

socat TCP-LISTEN:1337,fork,nodelay,reuseaddr,pktinfo,max-children="${MAX_CHILDREN}" \
	EXEC:"/usr/bin/timeout -k 5 ${TIMEOUT} /app/entrypoint.sh"
