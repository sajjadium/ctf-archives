#!/bin/sh
export FLAG="$(cat /flag.txt)"
exec node --random-seed=1337 /app/server.js
