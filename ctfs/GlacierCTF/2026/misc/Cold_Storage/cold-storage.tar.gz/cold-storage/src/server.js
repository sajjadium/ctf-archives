const { randomBytes } = require('node:crypto');
const express = require('express');
const { createArchive } = require('./archive');
const { decryptRecord, encryptRecord } = require('./record-crypto');

const key = randomBytes(16);
const archive = createArchive().map(record => ({
  ...record,
  ...encryptRecord(key, record.recorded, record),
}));
let importUsed = false;

const app = express();

app.use(express.urlencoded({ limit: 4096 }));

function sendForm(response, status, fields) {
  response
    .status(status)
    .type('application/x-www-form-urlencoded')
    .send(new URLSearchParams(fields).toString());
}

function isTimestamp(value) {
  return typeof value === 'string'
    && /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\dZ$/.test(value);
}

function handleImport(request, response) {
  const { recorded, sample } = request.body;

  if (importUsed) {
    return sendForm(response, 409, { error: 'Offline import already used.' });
  }
  if (
    !isTimestamp(recorded)
    || typeof sample !== 'string'
    || !/^[a-z0-9-]{2,21}$/.test(sample)
  ) {
    return sendForm(response, 400, { error: 'Invalid field record.' });
  }
  if (archive.some(record => record.recorded === recorded)) {
    return sendForm(response, 409, {
      error: 'A record already exists at that timestamp.',
    });
  }

  const record = { classification: 'open', sample };
  let encryptedFields;
  try {
    encryptedFields = encryptRecord(key, recorded, record);
  } catch {
    return sendForm(response, 400, { error: 'Invalid field record.' });
  }

  importUsed = true;
  return sendForm(response, 200, { recorded, ...record, ...encryptedFields });
}

function handleOpen(request, response) {
  const { recorded, ciphertext, tag } = request.body;

  if (
    !isTimestamp(recorded)
    || typeof ciphertext !== 'string'
    || !/^[0-9a-f]{64}$/i.test(ciphertext)
    || typeof tag !== 'string'
    || !/^[0-9a-f]{32}$/i.test(tag)
  ) {
    return sendForm(response, 400, { error: 'Malformed record.' });
  }

  let record;
  try {
    record = decryptRecord(key, recorded, ciphertext, tag);
  } catch {
    return sendForm(response, 403, { error: 'Record authentication failed.' });
  }

  const isTarget = record.classification === 'restricted'
    && record.sample === 'Ice-VII';

  if (record.classification !== 'open' && !isTarget) {
    return sendForm(response, 403, { error: 'Restricted sample.' });
  }

  const archivedRecord = archive.find(item => item.recorded === recorded);
  return sendForm(response, 200, {
    message: 'Record opened.',
    classification: record.classification,
    sample: record.sample,
    ...(archivedRecord && {
      temperature: archivedRecord.temperature,
      iciness: archivedRecord.iciness,
    }),
    ...(isTarget ? { flag: process.env.FLAG } : {}),
  });
}

app.get('/', (_request, response) => {
  response.sendFile('public/index.html', { root: __dirname });
});

app.get('/api/context', (_request, response) => {
  sendForm(response, 200, {
    targetClassification: 'restricted',
    targetSample: 'Ice-VII',
  });
});

app.get('/archive', (_request, response) => {
  sendForm(response, 200, archive.flatMap(record => Object.entries(record)));
});

app.post('/api/import', handleImport);
app.post('/api/open', handleOpen);

app.use((_error, _request, response, _next) => {
  sendForm(response, 400, { error: 'Could not read that request.' });
});

app.listen(1337, '0.0.0.0');
