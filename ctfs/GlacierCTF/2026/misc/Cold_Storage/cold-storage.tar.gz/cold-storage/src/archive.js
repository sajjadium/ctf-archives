function average(values) {
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function createArchive() {
  const start = Date.parse('1970-01-01T00:00:00Z');
  const durationInSeconds = (
    Date.parse('1994-05-28T00:00:00Z') - start
  ) / 1000;

  return Array.from({ length: 32 }, () => {
    const sampleValue = Math.random();
    const readings = Array.from({ length: 32 }, () => ({
      temperature: Math.random(),
      iciness: Math.random(),
    }));
    const recordedValue = Math.random();
    const recorded = new Date(
      start + Math.floor(recordedValue * durationInSeconds) * 1000,
    );
    const sample = Math.floor(sampleValue * 2 ** 32)
      .toString(16)
      .padStart(8, '0');
    const temperatureValue = average(readings.map(item => item.temperature));
    const icinessValue = average(readings.map(item => item.iciness));

    return {
      recorded: recorded.toISOString().replace('.000Z', 'Z'),
      classification: 'open',
      sample: `ice-${sample}`,
      temperature: `${(-80 + temperatureValue * 60).toFixed(1)} °C`,
      iciness: `${Math.round(icinessValue * 100)}%`,
    };
  });
}

module.exports = { createArchive };
