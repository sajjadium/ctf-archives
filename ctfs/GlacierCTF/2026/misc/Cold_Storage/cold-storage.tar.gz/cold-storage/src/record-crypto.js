const { createCipheriv, createDecipheriv, createHash } = require('node:crypto');

function encodeRecord({ classification, sample }) {
  return Buffer.from(`${classification.padEnd(10)}|${sample.padEnd(21)}`);
}

function decodeRecord(buffer) {
  const [classification, sample] = buffer.toString().split('|');
  return {
    classification: classification.trimEnd(),
    sample: sample.trimEnd(),
  };
}

function createNonce(recorded) {
  return createHash('sha256')
    .update(Temporal.Instant.from(recorded).epochNanoseconds.toString())
    .digest()
    .subarray(0, 12);
}

function encryptRecord(key, recorded, record) {
  const cipher = createCipheriv('aes-128-gcm', key, createNonce(recorded));
  const ciphertext = Buffer.concat([
    cipher.update(encodeRecord(record)),
    cipher.final(),
  ]);

  return {
    ciphertext: ciphertext.toString('hex'),
    tag: cipher.getAuthTag().toString('hex'),
  };
}

function decryptRecord(key, recorded, ciphertext, tag) {
  const decipher = createDecipheriv('aes-128-gcm', key, createNonce(recorded));
  decipher.setAuthTag(Buffer.from(tag, 'hex'));

  return decodeRecord(Buffer.concat([
    decipher.update(Buffer.from(ciphertext, 'hex')),
    decipher.final(),
  ]));
}

module.exports = { decryptRecord, encryptRecord };
