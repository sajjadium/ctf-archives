#!/usr/bin/env python3

import base64
from math import ceil
import os
import secrets
import select
import signal
import subprocess
import sys
import time

# Just a quick heads-up: If you use debug, the behaviour is a bit different,
# because the shell is not blinded and the time limit is disabled.
# To continue with the chall flow from debug, just `exit` the terminal.
# Have fun ^^
DEBUG = False
SENSE_TIME = 3 if not DEBUG else None

FLAG = os.getenv("FLAG", "gctf{FAKE_FAKE_FAKE_FAKE_FAKE_FAKE_FAKE}")

DICE_COMPLEXITY = [10, 1000, 10000, 100000, 65535, (2**32)-1]
SLICE_DIR = "/tmp/prize_slices"
SENSORY_BOX_DIR = "/boxes"


def box_path(nr: int) -> str:
    return f"{SENSORY_BOX_DIR}/box_{nr+1:02}"

def get_boxes_content() -> bytes:
    return subprocess.check_output("find /boxes -type f | sort | xargs sha256sum", shell=True)

# Prepare the prize slices

chunk_size = int(ceil(len(FLAG)/len(DICE_COMPLEXITY)))
prize_chunks = [FLAG[i:i+chunk_size] for i in range(0, len(FLAG), chunk_size)]
prize_passes = []

assert len(FLAG) >= len(DICE_COMPLEXITY)
assert len(prize_chunks) == len(DICE_COMPLEXITY)

os.makedirs(SLICE_DIR)

for i in range(len(prize_chunks)):
    path = box_path(i)
    os.makedirs(path, mode = 0o755)

    with open(f"{SLICE_DIR}/prize_{i+1:02}.txt", "w") as f:
        f.write(prize_chunks[i])

    proc = subprocess.run(["age-keygen"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)

    pubkey = proc.stderr.decode().strip().split(": ")[1]
    prize_passes.append(proc.stdout.decode().strip().splitlines()[-1])

    subprocess.run(["age", "--encrypt", "-r", pubkey, "-o", f"{path}/prize.age", f"{SLICE_DIR}/prize_{i+1:02}.txt"], check=True)

# Place the dice into the sensory boxes

dice = [ secrets.randbelow(el) + 1 for el in DICE_COMPLEXITY ]

for i in range(len(dice)):
    path = box_path(i)
    with open(f"{path}/dice.txt", "x") as f:
        print(f"I am a {dice[i]}-sided dice!", file=f)


# Just to be sure, take a snapshot of our sensory boxes to detect
# fishy behaviour
boxes_content = get_boxes_content()


def sense_dice(dice: int):
    print("Aaaand... ", end="")
    sys.stdout.flush()
    time.sleep(1)
    print("GO!")
    sys.stdout.flush()

    proc = subprocess.Popen(
            ["/bin/sh"],
            stdout=subprocess.DEVNULL if not DEBUG else None,
            stderr=subprocess.DEVNULL if not DEBUG else None,
            cwd=box_path(dice),
            close_fds=True,
            process_group=0,
    )

    # Wait for the sensing time to run out or, if the user is done with
    # sensing before, let them sweat a bit...
    start = time.time()
    try:
        proc.wait(timeout=SENSE_TIME)
    except subprocess.TimeoutExpired:
        proc.kill()
    # Also remove some creepy crawlers that the process may have left over.
    # process_group=0 calls setpgid with pgid=0, which means
    # "the PGID of the process specified by pid is made the same as its process ID"
    try:
        os.killpg(proc.pid, signal.SIGKILL)
    except:
        pass
    end = time.time()

    if not DEBUG:
        if (delta := end-start) < SENSE_TIME:
            time.sleep(SENSE_TIME - delta)

    # Conveniently flush out the input for the user, so that accidental inputs after
    # exiting the sensory box affect the guessing
    polly = select.epoll()
    polly.register(sys.stdin.fileno(), select.EPOLLIN)
    while len(polly.poll(timeout=0.1)) != 0:
        os.read(sys.stdin.fileno(), 4096)
    polly.close()

if DEBUG:
    print(dice)
    print(prize_chunks)
    print(prize_passes)
    #os.system("sh")

print(f"Come ye, come ye, try out the blind sensory box")
print(f"There are {len(dice)} boxes, all of them hiding n-sided dice.")
print(f"You get {SENSE_TIME} to sense them blindly, after that you can give a guess.")
print(f"For each correct guess you get the key to unlock one part of the main prize.")
print(f"Do you manage to get them all?")
print()

for i in range(len(dice)):
    print(50*"-")
    print(f"Dice number {i+1}")

    print(f"You've got {SENSE_TIME} seconds to check out the dice")
    sense_dice(i)

    try:
        guess = int(input("What is your guess? "))
    except:
        print("What is that supposed to mean?")
        exit(1)

    if guess == dice[i]:
        print("DING DING DING! Correct!")
        print("Here is your slice password:", prize_passes[i])
    else:
        print("Sorry, that one is wrong")

# Before handing out anything, check if they stole anything from our boxes
boxes_content_post = get_boxes_content()

if boxes_content != boxes_content_post:
    print("Hey, thief, give me my dice back!")
    exit(1)

print("Here is the bundle with the encrypted prize slices and the dice:")
print(50*"-")
files = []
for i in range(len(dice)):
    path = box_path(i)
    files.append(f"{path}/dice.txt")
    files.append(f"{path}/prize.age")
tarball = subprocess.check_output(["tar", "cJ"] + files, stderr=subprocess.DEVNULL if not DEBUG else None)
print(base64.b64encode(tarball).decode())
