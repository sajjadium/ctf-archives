#!/bin/sh
exec /app/sensory_box.py
