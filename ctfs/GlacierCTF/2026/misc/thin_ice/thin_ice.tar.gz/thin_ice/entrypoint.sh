#!/bin/sh
set -eu

repo_root=/srv/git
repo="$repo_root/shared.git"

mkdir -p "$repo_root"
worktree=$(mktemp -d)

git init --quiet --initial-branch=main "$worktree"
git -C "$worktree" config user.name losfuzzys
git -C "$worktree" config user.email mail@losfuzzys.net

export GIT_AUTHOR_DATE='2004-10-04T00:00:00Z'
export GIT_COMMITTER_DATE="$GIT_AUTHOR_DATE"

printf '%s' "$(cat /flag.txt)" > "$worktree/flag.txt"
git -C "$worktree" add flag.txt
git -C "$worktree" commit --quiet -m 'test.'
git clone --quiet --bare "$worktree" "$repo"

rm -rf "$worktree"

printf '#!/bin/sh\nexit 1\n' > "$repo/hooks/update"
chmod 0555 "$repo/hooks/update"

unset GIT_AUTHOR_DATE GIT_COMMITTER_DATE

exec git daemon \
    --reuseaddr \
    --base-path="$repo_root" \
    --strict-paths \
    --export-all \
    --listen=0.0.0.0 \
    --port=1337 \
    --enable=receive-pack \
    --disable=upload-pack \
    --disable=upload-archive \
    "$repo"
