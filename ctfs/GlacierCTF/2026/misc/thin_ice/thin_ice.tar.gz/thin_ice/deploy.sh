#!/bin/sh

check() {
  echo -e "\e[1;34m[+] Verifying Challenge Integrity\e[0m"
  sha256sum -c sha256sum
}

build_container() {
  echo -e "\e[1;34m[+] Building Challenge Docker Container\e[0m"
  docker build -t localhost/chall-thin_ice --platform linux/amd64 --pull=true   . 
}

run_container() {
  echo -e "\e[1;34m[+] Running Challenge Docker Container on 127.0.0.1:1337\e[0m"
  docker run --name chall-thin_ice --rm -p 127.0.0.1:1337:1337 -p 127.0.0.1:9418:9418 -e HOST=127.0.0.1 -e PORT=1337 -e GIT_HOST=127.0.0.1 -e GIT_PUBLIC_PORT=9418 -e NAME=thin_ice -e TIMEOUT=600 -e DOMAIN=localhost -e REGISTRY=localhost --privileged --platform linux/amd64 --pull=never localhost/chall-thin_ice
}

kill_container() {
	docker ps --filter "name=chall-thin_ice" --format "{{.ID}}" \
		| tr '\n' ' ' \
		| xargs docker stop -t 0 \
		|| true
}

case "$@" in
  "check")
    check
    ;;
  "build")
    build_container
    ;;
  "run")
    run_container
    ;;
  "kill")
    kill_container
    ;;
  *)
    check
    build_container && run_container
    ;;
esac
