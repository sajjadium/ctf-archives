#!/bin/sh
# The container always listens on 1337; the Makefile maps the host PORT to it.
export PORT=1337 BIND_HOST=0.0.0.0 PYTHONUNBUFFERED=1
exec python3 /app/server.py
