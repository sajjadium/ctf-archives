(function () {
    const canvas = document.getElementById("reconMapCanvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");

    function resizeCanvas() {
        const rect = canvas.parentElement.getBoundingClientRect();
        canvas.width = rect.width;
        canvas.height = rect.height;
    }
    window.addEventListener("resize", resizeCanvas);
    resizeCanvas();

    let scanAngle = 0;
    let satPhase = 0;

    const targetSector = {
        name: "SECTOR 7-ECHO",
        lat: 58.2394,
        lon: -17.6622,
        x: 0.44,
        y: 0.38
    };

    function drawMap() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const w = canvas.width;
        const h = canvas.height;

        ctx.strokeStyle = "rgba(35, 45, 62, 0.6)";
        ctx.lineWidth = 1;

        const stepX = w / 10;
        for (let x = 0; x <= w; x += stepX) {
            ctx.beginPath();
            ctx.moveTo(x, 0);
            ctx.lineTo(x, h);
            ctx.stroke();
        }

        const stepY = h / 6;
        for (let y = 0; y <= h; y += stepY) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
        }

        ctx.fillStyle = "rgba(100, 116, 139, 0.45)";
        ctx.font = "9px monospace";
        ctx.fillText("60°N", 8, stepY * 2 - 4);
        ctx.fillText("45°N", 8, stepY * 3 - 4);
        ctx.fillText("30°N", 8, stepY * 4 - 4);
        ctx.fillText("20°W", stepX * 4 + 4, h - 8);
        ctx.fillText("10°W", stepX * 5 + 4, h - 8);
        ctx.fillText("00°E", stepX * 6 + 4, h - 8);

        ctx.strokeStyle = "rgba(42, 60, 84, 0.85)";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(w * 0.36, h * 0.22);
        ctx.lineTo(w * 0.42, h * 0.21);
        ctx.lineTo(w * 0.45, h * 0.27);
        ctx.lineTo(w * 0.38, h * 0.28);
        ctx.closePath();
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(w * 0.52, h * 0.46);
        ctx.lineTo(w * 0.56, h * 0.42);
        ctx.lineTo(w * 0.58, h * 0.52);
        ctx.lineTo(w * 0.54, h * 0.60);
        ctx.closePath();
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(w * 0.48, h * 0.48);
        ctx.lineTo(w * 0.51, h * 0.47);
        ctx.lineTo(w * 0.50, h * 0.55);
        ctx.closePath();
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(w * 0.59, h * 0.15);
        ctx.lineTo(w * 0.65, h * 0.32);
        ctx.lineTo(w * 0.62, h * 0.48);
        ctx.lineTo(w * 0.58, h * 0.68);
        ctx.lineTo(w * 0.56, h * 0.85);
        ctx.stroke();

        ctx.strokeStyle = "rgba(56, 189, 248, 0.35)";
        ctx.setLineDash([3, 4]);
        ctx.beginPath();
        for (let x = 0; x <= w; x += 5) {
            const y = h * 0.5 + Math.sin((x / w) * Math.PI * 2.2 + satPhase) * (h * 0.38);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }
        ctx.stroke();
        ctx.setLineDash([]);

        const sat1X = (w * 0.42 + (satPhase * 60)) % w;
        const sat1Y = h * 0.5 + Math.sin((sat1X / w) * Math.PI * 2.2 + satPhase) * (h * 0.38);

        ctx.strokeStyle = "rgba(56, 189, 248, 0.25)";
        ctx.fillStyle = "rgba(56, 189, 248, 0.03)";
        ctx.beginPath();
        ctx.arc(sat1X, sat1Y, 48, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = "#38bdf8";
        ctx.fillRect(sat1X - 3, sat1Y - 3, 6, 6);
        ctx.font = "9px monospace";
        ctx.fillText("ORB-01 [KU-SAR]", sat1X + 8, sat1Y - 4);

        const tx = w * targetSector.x;
        const ty = h * targetSector.y;

        ctx.strokeStyle = "rgba(245, 158, 11, 0.7)";
        ctx.fillStyle = "rgba(245, 158, 11, 0.05)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(tx - 32, ty - 24);
        ctx.lineTo(tx + 32, ty - 24);
        ctx.lineTo(tx + 40, ty + 24);
        ctx.lineTo(tx - 26, ty + 28);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.save();
        ctx.translate(tx, ty);
        ctx.rotate(scanAngle);
        const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, 42);
        grad.addColorStop(0, "rgba(56, 189, 248, 0.3)");
        grad.addColorStop(1, "rgba(56, 189, 248, 0.0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.arc(0, 0, 42, 0, Math.PI * 0.25);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        ctx.fillStyle = "#f59e0b";
        ctx.beginPath();
        ctx.arc(tx, ty, 3, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = "#f59e0b";
        ctx.font = "10px monospace";
        ctx.fillText("LKF: TARGET ACQUIRED", tx + 8, ty - 6);

        scanAngle += 0.025;
        satPhase += 0.0015;

        requestAnimationFrame(drawMap);
    }

    requestAnimationFrame(drawMap);
})();
