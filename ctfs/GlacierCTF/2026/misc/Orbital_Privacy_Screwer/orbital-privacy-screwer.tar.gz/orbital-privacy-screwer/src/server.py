#!/usr/bin/env python3
"""
PROJECT: ORBITAL PRIVACY SCREWER
Global Target Acquisition System — Classified Surveillance Backend

Architecture:
- Zero external dependencies: pure Python 3.8+ standard library.
- High-precision microsecond-paced Server-Sent Events (SSE) streaming engine.
- Deterministic diagnostic response pipeline with SHA-256 reference indexing.
- Session-based request cancellation and concurrency arbitration.
- Morse steganographic encoder with flag count verification.
"""

import os
import sys
import time
import json
import hashlib
import urllib.parse
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import threading

HOST = os.environ.get("BIND_HOST", "0.0.0.0")
PORT = int(os.environ.get("PORT", 8080))
FLAG_FILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flag.txt")
FALLBACK_FLAG = "gctf{fakefakefake}"

TARGET_DOTS = 30
TARGET_DASHES = 22
TARGET_SEPARATORS = 15
EXPECTED_TOTAL_EVENTS = 67
EXPECTED_DURATION_MS = 7936

DOT_DURATION_MS = 67
DASH_DURATION_MS = 133
SEPARATOR_DURATION_MS = 200

MORSE_CODE = {
    'A': '.-',     'B': '-...',   'C': '-.-.',   'D': '-..',
    'E': '.',      'F': '..-.',   'G': '--.',    'H': '....',
    'I': '..',     'J': '.---',   'K': '-.-',    'L': '.-..',
    'M': '--',     'N': '-.',     'O': '---',    'P': '.--.',
    'Q': '--.-',   'R': '.-.',    'S': '...',    'T': '-',
    'U': '..-',    'V': '...-',   'W': '.--',    'X': '-..-',
    'Y': '-.--',   'Z': '--..',
    '0': '-----',  '1': '.----',  '2': '..---',  '3': '...--',
    '4': '....-',  '5': '.....',  '6': '-....',  '7': '--...',
    '8': '---..',  '9': '----.',
    '{': '-.--.',  '}': '-.--.-', '_': '..--.-', '-': '-....-',
    '.': '.-.-.-', ':': '---...', '/': '-..-.',  '?': '..--..'
}

ACQUISITION_PHASES = [
    "Initializing acquisition protocol",
    "Synchronizing surveillance network",
    "Verifying target intelligence",
    "Establishing orbital coverage",
    "Processing reconnaissance data",
    "Finalizing acquisition cycle"
]

session_lock = threading.Lock()
active_sessions = {}
cancelled_requests = set()

def precise_sleep(duration_s: float):
    target = time.perf_counter() + duration_s
    if duration_s > 0.005:
        time.sleep(duration_s - 0.0035)
    while time.perf_counter() < target:
        pass

def load_and_verify_gctf():
    flag_str = FALLBACK_FLAG
    if os.path.exists(FLAG_FILE_PATH):
        try:
            with open(FLAG_FILE_PATH, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    flag_str = content
                    print(f"[*] Loaded flag from: {FLAG_FILE_PATH}")
        except Exception as e:
            print(f"[!] Warning reading flag.txt: {e}. Using fallback flag.")
    else:
        print(f"[i] No flag.txt found. Using default configured flag: {FALLBACK_FLAG}")

    flag_clean = flag_str.strip().upper()
    dots = 0
    dashes = 0
    morse_tokens = []
    
    for ch in flag_clean:
        if ch not in MORSE_CODE:
            raise ValueError(f"Flag contains unsupported character '{ch}' for Morse transmission")
        m = MORSE_CODE[ch]
        morse_tokens.append(m)
        dots += m.count('.')
        dashes += m.count('-')

    seps = len(morse_tokens) - 1 if len(morse_tokens) > 0 else 0
    total_events = dots + dashes + seps
    total_duration_ms = (dots * DOT_DURATION_MS) + (dashes * DASH_DURATION_MS) + (seps * SEPARATOR_DURATION_MS)

    print("=" * 72)
    print(" PROJECT: ORBITAL PRIVACY SCREWER — CONSTELLATION ENCODER")
    print(f" Active Target Flag     : {flag_clean}")
    print(f" Encoded Event Counts   : Dots={dots}, Dashes={dashes}, Separators={seps}")
    print(f" Total Events / Steps   : {total_events} (Expected: {EXPECTED_TOTAL_EVENTS})")
    print(f" Total Transmission Dur : {total_duration_ms} ms ({total_duration_ms/1000:.3f} s)")

    if dots == TARGET_DOTS and dashes == TARGET_DASHES and seps == TARGET_SEPARATORS:
        print(" [VERIFIED] Flag timing matches specified 7,936 ms CTF parameters.")
    else:
        print(" [!] DISCREPANCY WARNING: Flag event counts differ from standard specification.")
        print(f"     Observed: ({dots} dots, {dashes} dashes, {seps} seps) -> {total_events} events, {total_duration_ms} ms.")
        print(f"     Expected: ({TARGET_DOTS} dots, {TARGET_DASHES} dashes, {TARGET_SEPARATORS} seps) -> {EXPECTED_TOTAL_EVENTS} events, {EXPECTED_DURATION_MS} ms.")
        print("     Proceeding without alteration as mandated.")
    print("=" * 72)

    return flag_clean

ACTIVE_FLAG = load_and_verify_gctf()

def build_morse_event_sequence(flag_text: str):
    raw_events = []
    tokens = [MORSE_CODE[c] for c in flag_text]
    total_tokens = len(tokens)

    for i, token in enumerate(tokens):
        for sym in token:
            if sym == '.':
                raw_events.append({"type": "dot", "duration_ms": DOT_DURATION_MS, "symbol": "."})
            elif sym == '-':
                raw_events.append({"type": "dash", "duration_ms": DASH_DURATION_MS, "symbol": "-"})
        if i < total_tokens - 1:
            raw_events.append({"type": "separator", "duration_ms": SEPARATOR_DURATION_MS, "symbol": " "})

    total_events = len(raw_events)
    total_duration = sum(e["duration_ms"] for e in raw_events)
    accumulated = 0
    event_list = []

    for idx, ev in enumerate(raw_events):
        accumulated += ev["duration_ms"]
        pct = round((accumulated / total_duration) * 100, 2)
        phase_idx = min(int((idx / total_events) * len(ACQUISITION_PHASES)), len(ACQUISITION_PHASES) - 1)
        event_list.append({
            "seq": idx,
            "total_seq": total_events,
            "type": ev["type"],
            "duration_ms": ev["duration_ms"],
            "pct": pct,
            "phase": ACQUISITION_PHASES[phase_idx],
            "carrier_active": (ev["type"] in ("dot", "dash"))
        })

    return event_list

PRECOMPUTED_TRANSMISSION = build_morse_event_sequence(ACTIVE_FLAG)

def process_intel_input(query: str):
    if not query:
        return {
            "success": False,
            "status": "VALIDATION_FAILED",
            "error_code": "ERR-4001",
            "message": "NULL INTELLIGENCE PARAMETER. INPUT REQUIRED."
        }
    
    cleaned = query.strip()
    if len(cleaned) > 128:
        return {
            "success": False,
            "status": "BUFFER_OVERFLOW_REJECTED",
            "error_code": "ERR-4008",
            "message": "INTELLIGENCE PARAMETER EXCEEDS 128 CHARACTER BUFFER LIMIT."
        }
    
    normalized = " ".join(cleaned.lower().split())

    commands = {
        "status": {
            "response": "NETWORK STATUS: OPERATIONAL // ALL CONSTELLATIONS GREEN",
            "sector": "GLOBAL",
            "variance": "0.0012 dB"
        },
        "help": {
            "response": "COMMAND REFERENCE: STATUS, PING, ASSETS, SENSORS, GRID, EPHEMERIS",
            "sector": "INDEX",
            "variance": "0.0000 dB"
        },
        "ping": {
            "response": "CARRIER PING: 18.4 MS // SATLINK TRANSPONDER ACKNOWLEDGED",
            "sector": "RELAY-04",
            "variance": "0.0028 dB"
        },
        "assets": {
            "response": "ORBITAL ASSETS: ORB-01 (ACTIVE), ORB-02 (STANDBY), ORB-03 (REPOS), ORB-04 (ACTIVE)",
            "sector": "CONSTELLATION",
            "variance": "0.0041 dB"
        },
        "sensors": {
            "response": "SENSOR SPECTRUM: KU-BAND SAR, SWIR MULTISPECTRAL, SIGINT 1.2-4.8 GHZ",
            "sector": "PAYLOAD",
            "variance": "0.0019 dB"
        },
        "grid": {
            "response": "PRIMARY SURVEILLANCE GRID: SECTOR 7-ECHO // SUB-GRID 14 [58.2394 N, 17.6622 W]",
            "sector": "SEC-7E",
            "variance": "0.0033 dB"
        },
        "ephemeris": {
            "response": "EPHEMERIS VECTOR: TLE EPOCH 25138.411 // ORBITAL NODES SYNCHRONIZED",
            "sector": "PROPAGATOR",
            "variance": "0.0009 dB"
        }
    }

    if normalized in commands:
        cmd_meta = commands[normalized]
        cmd_hash = hashlib.sha256(f"CMD::{normalized}".encode("utf-8")).hexdigest()[:8].upper()
        return {
            "success": True,
            "status": "COMMAND_PROCESSED",
            "query": cleaned,
            "normalized": normalized,
            "response": cmd_meta["response"],
            "reference_id": f"SYS-{cmd_hash}",
            "hash": cmd_hash,
            "sector_code": cmd_meta["sector"],
            "telemetry_variance": cmd_meta["variance"],
            "classification": "RESTRICTED // INTERNAL"
        }

    raw_hash = hashlib.sha256(normalized.encode("utf-8")).hexdigest().upper()
    short_hash = raw_hash[:8]
    sec_num = int(raw_hash[8:12], 16) % 99 + 1
    variance = (int(raw_hash[12:14], 16) / 255.0) * 0.08 + 0.01

    return {
        "success": True,
        "status": "TARGET_ACQUIRED",
        "query": cleaned,
        "normalized": normalized,
        "response": f"ACQUISITION REFERENCE: {short_hash}",
        "reference_id": f"ACQ-{short_hash}",
        "hash": short_hash,
        "sector_code": f"SEC-{sec_num:02d}",
        "telemetry_variance": f"{variance:.4f} dB",
        "classification": "RESTRICTED // INTERNAL"
    }

class SurveillanceRequestHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
        super().__init__(*args, directory=static_dir, **kwargs)

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/cancel":
            self.handle_cancel()
        else:
            self.send_error(404, "Endpoint not found")

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == "/api/acquire":
            self.handle_acquire_stream(parsed)
        elif parsed.path == "/api/health":
            self.handle_health()
        else:
            super().do_GET()

    def handle_health(self):
        payload = json.dumps({
            "status": "ONLINE",
            "constellation": "ORBITAL PRIVACY SCREWER",
            "assets_online": 4,
            "system_time": time.time()
        }).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def handle_cancel(self):
        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length)
        try:
            body = json.loads(post_data.decode("utf-8")) if post_data else {}
        except Exception:
            body = {}

        session_id = body.get("session_id", "default")
        req_id = body.get("req_id", None)

        with session_lock:
            if req_id:
                cancelled_requests.add(req_id)
            if active_sessions.get(session_id) == req_id:
                active_sessions.pop(session_id, None)

        resp = json.dumps({"status": "ABORTED", "session_id": session_id, "req_id": req_id}).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(resp)))
        self.end_headers()
        self.wfile.write(resp)

    def handle_acquire_stream(self, parsed_url):
        query_params = urllib.parse.parse_qs(parsed_url.query)
        target_param = query_params.get("q", [""])[0]
        req_id = query_params.get("reqId", [f"req_{int(time.time()*1000)}"])[0]
        session_id = query_params.get("sessionId", ["session_default"])[0]

        with session_lock:
            prev_req = active_sessions.get(session_id)
            if prev_req and prev_req != req_id:
                cancelled_requests.add(prev_req)
            active_sessions[session_id] = req_id

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        diagnostic_result = process_intel_input(target_param)

        init_event = json.dumps({
            "type": "cycle_start",
            "req_id": req_id,
            "session_id": session_id,
            "total_steps": len(PRECOMPUTED_TRANSMISSION)
        })
        self.send_sse_message(init_event)

        is_cancelled = False
        for event_data in PRECOMPUTED_TRANSMISSION:
            with session_lock:
                if req_id in cancelled_requests or active_sessions.get(session_id) != req_id:
                    is_cancelled = True
                    break

            payload = json.dumps({
                "type": "step",
                "req_id": req_id,
                "seq": event_data["seq"],
                "total": event_data["total_seq"],
                "pct": event_data["pct"],
                "phase": event_data["phase"],
                "carrier": event_data["carrier_active"]
            })
            if not self.send_sse_message(payload):
                is_cancelled = True
                break

            precise_sleep(event_data["duration_ms"] / 1000.0)

        if not is_cancelled:
            with session_lock:
                if req_id in cancelled_requests or active_sessions.get(session_id) != req_id:
                    is_cancelled = True

        if is_cancelled:
            abort_payload = json.dumps({
                "type": "aborted",
                "req_id": req_id,
                "message": "PREVIOUS ACQUISITION CYCLE INCOMPLETE. OPERATION ABORTED."
            })
            self.send_sse_message(abort_payload)
        else:
            final_payload = json.dumps({
                "type": "complete",
                "req_id": req_id,
                "pct": 100.0,
                "phase": "Acquisition cycle completed",
                "diagnostic": diagnostic_result
            })
            self.send_sse_message(final_payload)
            with session_lock:
                if active_sessions.get(session_id) == req_id:
                    active_sessions.pop(session_id, None)

    def send_sse_message(self, json_data: str) -> bool:
        try:
            msg = f"data: {json_data}\n\n".encode("utf-8")
            self.wfile.write(msg)
            self.wfile.flush()
            return True
        except (BrokenPipeError, ConnectionResetError):
            return False

def run_server():
    print(f"[*] Starting ORBITAL PRIVACY SCREWER server on http://{HOST}:{PORT}")
    server = ThreadingHTTPServer((HOST, PORT), SurveillanceRequestHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[*] Shutting down constellation relay.")
        server.server_close()

if __name__ == "__main__":
    run_server()
