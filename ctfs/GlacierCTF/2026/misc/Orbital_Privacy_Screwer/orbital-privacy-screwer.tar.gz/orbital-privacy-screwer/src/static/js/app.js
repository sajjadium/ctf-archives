(function () {
    const clockEl = document.getElementById("systemUtcClock");
    const intelForm = document.getElementById("intelForm");
    const targetInput = document.getElementById("targetInput");
    const initiateBtn = document.getElementById("initiateBtn");

    const carrierStatusEl = document.getElementById("carrierStatus");
    const phaseTextEl = document.getElementById("acquisitionPhaseText");
    const timingDisplayEl = document.getElementById("sequenceTimingDisplay");
    const progressFill = document.getElementById("progressFill");
    const progressScanhead = document.getElementById("progressScanhead");
    const abortBanner = document.getElementById("abortBanner");

    const diagContainer = document.getElementById("diagnosticContainer");
    const diagStatus = document.getElementById("diagStatus");
    const diagReference = document.getElementById("diagReference");
    const diagSector = document.getElementById("diagSector");
    const diagVariance = document.getElementById("diagVariance");
    const diagOutput = document.getElementById("diagOutput");
    const terminalLog = document.getElementById("terminalLog");

    const sessionId = "sess_" + Math.random().toString(36).substring(2, 9);
    let activeEventSource = null;
    let activeRequestId = null;
    let cycleStartTime = null;
    let cycleTimerInterval = null;

    function updateUtcClock() {
        const now = new Date();
        const iso = now.toISOString().replace("T", " ").replace("Z", "");
        clockEl.textContent = iso + " UTC";
    }
    setInterval(updateUtcClock, 67);
    updateUtcClock();

    function logMessage(tag, message, level = "normal") {
        const now = new Date();
        const timeStr = now.toTimeString().split(" ")[0] + "." + String(now.getMilliseconds()).padStart(3, "0");

        const entry = document.createElement("div");
        entry.className = "log-entry";

        let levelClass = "";
        if (level === "warn") levelClass = "log-warn";
        if (level === "abort") levelClass = "log-abort";

        entry.innerHTML = `<span class="log-time">[${timeStr}]</span> <span class="log-tag">${tag}:</span> <span class="${levelClass}">${escapeHtml(message)}</span>`;
        terminalLog.appendChild(entry);
        terminalLog.scrollTop = terminalLog.scrollHeight;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    }

    logMessage("SYS", "Constellation telemetry transponder locked on node EUR-N/07");
    logMessage("ORB", "Ephemeris coordinates validated for ORB-01, ORB-02, ORB-04");
    logMessage("NET", "Surveillance network operational. Standby for intelligence ingestion.");

    intelForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const rawQuery = targetInput.value;
        startAcquisitionCycle(rawQuery);
    });

    function startAcquisitionCycle(query) {
        const newReqId = "req_" + Date.now() + "_" + Math.random().toString(36).substring(2, 6);

        if (activeEventSource) {
            logMessage("SYS", "New intelligence submission received while cycle active", "warn");
            logMessage("ACQ", "PREVIOUS ACQUISITION CYCLE INCOMPLETE. OPERATION ABORTED.", "abort");
            logMessage("NET", "Reinitializing surveillance network...", "warn");

            abortBanner.style.display = "flex";

            activeEventSource.close();
            activeEventSource = null;

            if (activeRequestId) {
                fetch("/api/cancel", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ session_id: sessionId, req_id: activeRequestId })
                }).catch(() => {});
            }
        } else {
            abortBanner.style.display = "none";
        }

        activeRequestId = newReqId;
        resetProgressBar();
        diagContainer.style.display = "none";

        logMessage("INTEL", `Intelligence parameter ingested: "${query.substring(0, 32)}"`);
        logMessage("ACQ", `Acquisition protocol initialized [ID: ${newReqId}]`);

        const url = `/api/acquire?q=${encodeURIComponent(query)}&reqId=${encodeURIComponent(newReqId)}&sessionId=${encodeURIComponent(sessionId)}`;
        activeEventSource = new EventSource(url);

        cycleStartTime = performance.now();
        if (cycleTimerInterval) clearInterval(cycleTimerInterval);
        cycleTimerInterval = setInterval(updateElapsedTimer, 33);

        activeEventSource.onmessage = function (event) {
            try {
                const data = JSON.parse(event.data);
                handleStreamEvent(data);
            } catch (err) {
                console.error("Malformed SSE frame:", err);
            }
        };

        activeEventSource.onerror = function () {
            if (activeEventSource) {
                activeEventSource.close();
                activeEventSource = null;
            }
            if (cycleTimerInterval) clearInterval(cycleTimerInterval);
            carrierStatusEl.className = "carrier-tag";
            carrierStatusEl.textContent = "CARRIER: IDLE";
        };
    }

    function resetProgressBar() {
        progressFill.style.width = "0%";
        progressScanhead.style.left = "0%";
        progressScanhead.classList.add("active");
        phaseTextEl.textContent = "Initializing acquisition protocol...";
        timingDisplayEl.textContent = "0.000 s / 7.936 s";
        carrierStatusEl.className = "carrier-tag";
        carrierStatusEl.textContent = "CARRIER: ACQUIRING";
    }

    function updateElapsedTimer() {
        if (!cycleStartTime) return;
        const elapsed = (performance.now() - cycleStartTime) / 1000;
        timingDisplayEl.textContent = `${elapsed.toFixed(3)} s / 7.936 s`;
    }

    function handleStreamEvent(data) {
        if (data.req_id && data.req_id !== activeRequestId) {
            return;
        }

        if (data.type === "cycle_start") {
            abortBanner.style.display = "none";
            logMessage("SAT", "Orbital reconnaissance sweep engaged over Sector 7-Echo");
        } else if (data.type === "step") {
            progressFill.style.width = data.pct + "%";
            progressScanhead.style.left = data.pct + "%";
            phaseTextEl.textContent = data.phase + "...";

            if (data.carrier) {
                carrierStatusEl.className = "carrier-tag carrier-active";
                carrierStatusEl.textContent = "CARRIER: LOCK [ACTIVE]";
            } else {
                carrierStatusEl.className = "carrier-tag";
                carrierStatusEl.textContent = "CARRIER: FRAME_SYNC";
            }
        } else if (data.type === "complete") {
            if (cycleTimerInterval) clearInterval(cycleTimerInterval);
            timingDisplayEl.textContent = "7.936 s / 7.936 s";
            progressFill.style.width = "100%";
            progressScanhead.style.left = "100%";
            progressScanhead.classList.remove("active");
            phaseTextEl.textContent = "Acquisition cycle complete";
            carrierStatusEl.className = "carrier-tag";
            carrierStatusEl.textContent = "CARRIER: STANDBY";

            if (activeEventSource) {
                activeEventSource.close();
                activeEventSource = null;
            }

            logMessage("ACQ", "Acquisition cycle completed. Spatial coordinates verified.");
            logMessage("SYS", "Diagnostic telemetry response generated.");

            renderDiagnostic(data.diagnostic);
        } else if (data.type === "aborted") {
            abortBanner.style.display = "flex";
            if (cycleTimerInterval) clearInterval(cycleTimerInterval);
            if (activeEventSource) {
                activeEventSource.close();
                activeEventSource = null;
            }
        }
    }

    function renderDiagnostic(diag) {
        if (!diag) return;
        diagContainer.style.display = "block";

        if (diag.success) {
            diagStatus.textContent = diag.status;
            diagStatus.className = "d-val status-online";
            diagReference.textContent = diag.reference_id || diag.hash;
            diagSector.textContent = diag.sector_code || "N/A";
            diagVariance.textContent = diag.telemetry_variance || "0.000 dB";
            diagOutput.textContent = diag.response;
        } else {
            diagStatus.textContent = diag.status || "ERROR";
            diagStatus.className = "d-val log-abort";
            diagReference.textContent = diag.error_code || "ERR";
            diagSector.textContent = "REJECTED";
            diagVariance.textContent = "N/A";
            diagOutput.textContent = diag.message || "Invalid parameter.";
        }
    }
})();
