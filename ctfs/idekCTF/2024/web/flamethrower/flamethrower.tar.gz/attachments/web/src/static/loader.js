import flamethrower from '/flamethrower.js';
flamethrower({ prefetch: 'visible', log: false, pageTransitions: true });
