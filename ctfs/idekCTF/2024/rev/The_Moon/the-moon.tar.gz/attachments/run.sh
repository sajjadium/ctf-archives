#!/bin/bash

docker build -t the-moon . && docker run --rm -it the-moon