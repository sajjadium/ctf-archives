#!/bin/bash

tar -czvf minecraft-hacked.tar.gz gradlew gradlew.bat build.gradle gradle.properties gradle/ settings.gradle src/ compress.sh Dockerfile docker-compose.yml 