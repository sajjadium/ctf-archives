#!/bin/sh

set -e

verilator --binary +1800-2017ext+sv CPU.h.sv Simulation.sv -DSIMULATION -Isrc -o Simulation --trace -j 4
./obj_dir/Simulation