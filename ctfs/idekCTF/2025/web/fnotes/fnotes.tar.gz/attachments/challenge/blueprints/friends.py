from flask import *
from db import *
from middleware import login_required

friends_bp = Blueprint("friends", __name__, url_prefix="/friends")

def validate_username_input():
	username = request.form.get("username", "").strip()
	if not username:
		flash("username is required", "error")
		return None, None

	user_id = get_user_id(username)
	if user_id is None:
		flash("user not found", "error")
		return None, None

	return username, user_id

@friends_bp.route("/")
@login_required
def index():
	return render_template("friends.html",
		friend_requests=get_friend_requests(session["user"]),
		friends=get_friends(session["user"])
	)

@friends_bp.route("/request", methods=["POST"])
@login_required
def frequest():
	username, subject_user_id = validate_username_input()
	if not username:
		return redirect(url_for("friends.index"))

	current_user_id = session["user"]

	if current_user_id == subject_user_id:
		flash(f"you cannot send a friend request to yourself", "error")
	elif are_friends(current_user_id, subject_user_id):
		flash(f"you are already friends with {username}", "error")
	elif has_sent_friend_request(current_user_id, subject_user_id):
		flash("you have already sent a friend request to this person", "error")
	else:
		send_friend_request(current_user_id, subject_user_id)
		flash(f"sent a friend request to {username}", "success")

	return redirect(url_for("friends.index"))

@friends_bp.route("/accept", methods=["POST"])
@login_required
def accept():
	username, subject_user_id = validate_username_input()
	if not username:
		return redirect(url_for("friends.index"))

	current_user_id = session["user"]

	if not has_sent_friend_request(subject_user_id, current_user_id):
		flash(f"{username} did not send you a friend request", "error")
	else:
		accept_friend_request(subject_user_id, current_user_id)
		flash(f"accepted {username}'s friend request!", "success")

	return redirect(url_for("friends.index"))
