from flask import *
from bleach.linkifier import Linker
from blueprints.auth import auth_bp
from blueprints.notes import notes_bp
from blueprints.friends import friends_bp
from db import *
from flask_wtf.csrf import CSRFProtect, CSRFError
import html5lib
import re
import os
import socket

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", os.urandom(16).hex())

csrf = CSRFProtect(app)
csrf.exempt(auth_bp)

# IN -> html5lib sanitize -> bleach linkify -> OUT
def safe_linkify(text):
	url_re = re.compile(r"https?://[^\s]+", re.IGNORECASE | re.VERBOSE | re.UNICODE)
	linker = Linker(url_re=url_re)
	return linker.linkify(
		html5lib.serialize(html5lib.parseFragment(text), sanitize=True)
	)
app.jinja_env.filters["safe_linkify"] = safe_linkify

init_db()
app.teardown_appcontext(close_db)

@app.errorhandler(CSRFError)
def handle_csrf_error(e):
	flash("bad csrf token", "error")
	return redirect(url_for("auth.login"))

@app.after_request
def add_security_headers(resp):
	resp.headers["X-Content-Type-Options"] = "nosniff"
	resp.headers["X-Frame-Options"] = "DENY"
	resp.headers["Content-Security-Policy"] = (
		"script-src 'none';"
		"style-src 'self';"
		"object-src 'none';"
		"frame-ancestors 'none';"
	)
	return resp

@app.route("/")
def index():
	if "user" in session:
		return redirect(url_for("notes.index"))
	return redirect(url_for("auth.login"))

@app.route("/report")
def report():
	url = request.args.get("url", "")
	if not url:
		return "missing url"

	def stream():
		try:
			with socket.create_connection(("bot", 55555), timeout=300) as s:
				s.sendall(url.encode() + b"\n")

				while True:
					data = s.recv(1024)
					if not data:
						break
					yield f"{data.decode(errors='replace')}"

		except Exception as e:
			yield f"\n\nerror: {str(e)}"

	return Response(stream_with_context(stream()), mimetype="text/event-stream")

app.register_blueprint(auth_bp)
app.register_blueprint(notes_bp)
app.register_blueprint(friends_bp)
