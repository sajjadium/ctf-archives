from flask import *
from db import *
from middleware import login_required

notes_bp = Blueprint("notes", __name__, url_prefix="/notes")

@notes_bp.route("/")
@login_required
def index():
	# show friends' and own notes
	return render_template("notes.html",
		notes=get_visible_notes(session["user"])
	)

@notes_bp.route("/create", methods=["GET", "POST"])
@login_required
def create():
	if request.method == "POST":
		content = request.form.get("content", "").strip()

		if not content:
			flash("content is required", "error")
			return redirect(url_for("notes.create"))
		if len(content) > 1000:
			flash("content is too long", "error")
			return redirect(url_for("notes.create"))

		create_note(session["user"], content)
		flash("fnote created!", "success")
		return redirect(url_for("notes.index"))

	return render_template("create.html")

@notes_bp.route("/delete", methods=["POST"])
@login_required
def delete():
	note_id = request.form.get("note_id", "")

	if not note_id:
		flash("fnote id is required", "error")
		return redirect(url_for("notes.index"))

	note = get_note(note_id)
	if not note:
		flash("fnote not found", "error")
		return redirect(url_for("notes.index"))
	if note["user_id"] != session["user"]:
		flash("cannot delete this fnote", "error")
		return redirect(url_for("notes.index"))

	delete_note(note_id)
	flash("fnote deleted", "success")
	return redirect(url_for("notes.index"))
