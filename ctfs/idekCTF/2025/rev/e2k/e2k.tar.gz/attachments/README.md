# e2k

It is recommended to do everything within the container registry.gitflic.ru/project/mrognor/lcc-env/lcc-container:

`docker run -it --rm -u root --mount src=.,target=/home/ubuntu/build,type=bind registry.gitflic.ru/project/mrognor/lcc-env/lcc-container`

This container already has an emulator, which can be invoked with `e2k main`.
