#!/bin/sh
. /.venv/bin/activate 2>&1 >/dev/null
export PATH="/.venv/bin:$PATH"

mkdir -p /tmp/packages
mkdir -p /tmp/packages-cache
DIR=$(mktemp -d)
cd ${DIR}
mkdir profile

export PYTHONUNBUFFERED=1
/usr/bin/stdbuf -i0 -o0 -e0 /app/challenge
