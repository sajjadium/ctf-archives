/// Compute the mean latitude/longitude (center) of a set of coordinates.
pub fn mean_center(coords: &[(f64, f64)]) -> Option<(f64, f64)> {
    if coords.is_empty() {
        return None;
    }
    let (mut sum_lat, mut sum_lon) = (0.0, 0.0);
    for &(lat, lon) in coords {
        sum_lat += lat;
        sum_lon += lon;
    }
    Some((sum_lat / coords.len() as f64, sum_lon / coords.len() as f64))
}

fn get_center_point(amenity: &str) -> Option<(f64, f64)> {
    // TODO: Get POI's and finde center point.
    unimplemented!();

    return mean_center(nodes);
}

fn calc_final_point(
    a: (f64, f64, f64),
    b: (f64, f64, f64),
    c: (f64, f64, f64),
) -> Option<(f64, f64)> {
    // TODO: Calculate hidden place coords.
    unimplemented!();
}

fn main() {
    let (lat_a, lon_a) = get_center_point("bar").unwrap();
    let (lat_b, lon_b) = get_center_point("atm").unwrap();
    let (lat_c, lon_c) = get_center_point("taxi").unwrap();

    let secret_hideout = calc_final_point(
        // (lat, lon, dis)
        (lat_a, lon_a, 0.6412652119499),
        (lat_b, lon_b, 0.2822972577454),
        (lat_c, lon_c, 0.9572772921063),
    )
    .unwrap();
}
