#include <stdio.h>
#include <stdlib.h>

void win() {
  FILE *f = fopen("/flag.txt", "r");
  if(f == NULL)
    exit(1);

  char flag[256];
  char *r = fgets(flag, 256, f);
  printf("%s\n", flag);
}

void challenge() {
  char buf[0666];
  printf("Enter your input now:\n");
  fread(buf, 1, 666, stdin);
}

int main() {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stdin,  NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  challenge();

  return 0;
}
