#!/bin/sh
/app/challenge
