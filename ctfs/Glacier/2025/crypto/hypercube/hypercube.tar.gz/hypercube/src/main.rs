mod aes_util;
mod prf;

mod aes;
mod ascon;
mod hypercube;
mod sha256;
mod skinny128;


use std::{fs, io};
use std::io::{BufRead, Write};
use std::process;

use crate::hypercube::HyperCube;
use crate::prf::PRF;

use rand::RngCore;
use rand::rngs::OsRng;

fn read_hex(prompt: &str) -> Vec<u8> {
    println!("{}", prompt);
    let _ = io::stdout().lock().flush();

    let mut pt_hex = String::new();
    match std::io::stdin().lock().read_line(&mut pt_hex) {
        Ok(_) => (),
        Err(_) => std::process::exit(1),
    }
    let pt_hex = pt_hex.trim();
    match hex::decode(pt_hex) {
        Ok(pt) => pt,
        Err(_) => {
            println!("bad hex");
            std::process::exit(1);
        },
    }
}


fn main() {
    let flag = fs::read_to_string("flag.txt").unwrap_or_else(|err| {
        eprintln!("could not read flag.txt: {err}");
        process::exit(1);
    });

    let key: [u8; 16] = rand::random();
    // println!("{}", hex::encode(key));

    let cipher = HyperCube::new(key);

    let pt  = read_hex("pt (hex):");

    if pt.len() > 512 * 16 || !pt.len().is_multiple_of(16) {
        println!("you talk too much");
        std::process::exit(1);
    }

    print!("ct: ");
    for i in (0..pt.len()).step_by(16) {
        let mut input = [0u8; 16];
        input.copy_from_slice(&pt[i..i+16]);
        let output = cipher.encrypt(input);

        print!("{}", hex::encode(output))
    }
    println!("");

    let keyguess = read_hex("key (hex):");

    if keyguess == key {
        println!("here you go: {}", flag);
    } else {
        println!("that's not it");
    }
}
