use crate::ascon::Ascon;
use crate::aes::Aes;
use crate::sha256::SHA256;
use crate::skinny128::Skinny128;
use crate::prf::PRF;

use crate::aes_util::xor;

pub struct HyperCube {
    ascon: Ascon,
    aes: Aes,
    sha: SHA256,
    skinny: Skinny128,
}

impl HyperCube {
    pub fn new(key: [u8; 16]) -> HyperCube {
        HyperCube {
            ascon: Ascon::new(key),
            aes: Aes::new(key),
            sha: SHA256::new(key),
            skinny: Skinny128::new(key),
        }
    }
}

impl PRF for HyperCube {
    fn encrypt(&self, pt: [u8; 16]) -> [u8; 16] {
        let mut result = [0u8; 16];

        xor(&mut result, &self.ascon.encrypt(pt));
        xor(&mut result, &self.aes.encrypt(pt));
        xor(&mut result, &self.sha.encrypt(pt));
        xor(&mut result, &self.skinny.encrypt(pt));

        result
    }
}
