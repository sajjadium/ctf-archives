use crate::prf::PRF;

pub static K32: [u32; 64] = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

fn compress_u32(state: &mut [u32; 8]) {
    let [mut a, mut b, mut c, mut d, mut e, mut f, mut g, mut h] = *state;

    for i in 0..2 {
        let s1 = e.rotate_right(6) ^ e.rotate_right(11) ^ e.rotate_right(25);
        let ch = (e & f) ^ ((!e) & g);
        let t1 = s1
            .wrapping_add(ch)
            .wrapping_add(K32[i])
            .wrapping_add(h);
        let s0 = a.rotate_right(2) ^ a.rotate_right(13) ^ a.rotate_right(22);
        let maj = (a & b) ^ (a & c) ^ (b & c);
        let t2 = s0.wrapping_add(maj);

        h = g;
        g = f;
        f = e;
        e = d.wrapping_add(t1);
        d = c;
        c = b;
        b = a;
        a = t1.wrapping_add(t2);
    }

    state[0] = a;
    state[1] = b;
    state[2] = c;
    state[3] = d;
    state[4] = e;
    state[5] = f;
    state[6] = g;
    state[7] = h;
}

pub struct SHA256 {
    key: [u32; 4],
}

impl SHA256 {
    pub fn new(key: [u8; 16]) -> SHA256 {
        let k0: u32 = u32::from_le_bytes(key[0..4].try_into().unwrap());
        let k1: u32 = u32::from_le_bytes(key[4..8].try_into().unwrap());
        let k2: u32 = u32::from_le_bytes(key[8..12].try_into().unwrap());
        let k3: u32 = u32::from_le_bytes(key[12..16].try_into().unwrap());

        SHA256{key: [k0, k1, k2, k3]}
    }
}

impl PRF for SHA256 {
    fn encrypt(&self, pt: [u8; 16]) -> [u8; 16] {
        let mut state: [u32; 8] = [0; 8];
        state[0..4].copy_from_slice(&self.key);
        state[4] = u32::from_le_bytes(pt[0..4].try_into().unwrap());
        state[5] = u32::from_le_bytes(pt[4..8].try_into().unwrap());
        state[6] = u32::from_le_bytes(pt[8..12].try_into().unwrap());
        state[7] = u32::from_le_bytes(pt[12..16].try_into().unwrap());

        compress_u32(&mut state);

        let mut out = [0u8; 16];
        for (i, &word) in state[0..4].iter().enumerate() {
            out[i*4..i*4+4].copy_from_slice(&word.to_le_bytes());
        }
        out
    }
}
