pub trait PRF {
    fn encrypt(&self, pt: [u8; 16]) -> [u8; 16];
}
