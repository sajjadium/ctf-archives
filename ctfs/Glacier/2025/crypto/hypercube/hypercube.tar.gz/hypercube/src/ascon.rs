use crate::prf::PRF;

use ascon_core::State;

pub struct Ascon {
    k0: u64,
    k1: u64,
}

impl Ascon {
    pub fn new(key: [u8; 16]) -> Ascon {
        let k0: u64 = u64::from_le_bytes(key[0..8].try_into().unwrap());
        let k1: u64 = u64::from_le_bytes(key[8..16].try_into().unwrap());
        Ascon {k0, k1}
    }
}

impl PRF for Ascon {
    fn encrypt(&self, pt: [u8; 16]) -> [u8; 16] {
        
        let pt0: u64 = u64::from_le_bytes(pt[0..8].try_into().unwrap());
        let pt1: u64 = u64::from_le_bytes(pt[8..16].try_into().unwrap());
        const IV: u64 = 0x676c616369657200;

        let mut state = State::new(IV, self.k0, self.k1, pt0, pt1);
        state.permute_n(3);
        let state_bytes = state.as_bytes();

        let mut out = [0u8; 16];
        out.copy_from_slice(&state_bytes[0..16]);
        out
    }
}
