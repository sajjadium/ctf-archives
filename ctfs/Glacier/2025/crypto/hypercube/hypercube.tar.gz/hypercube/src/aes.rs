use crate::prf::PRF;
use crate::aes_util::*;

const NUMROUNDS: usize = 1;

pub struct Aes {
    key: [u8; 16],
}

impl Aes {
    pub fn new(key: [u8; 16]) -> Aes {
        Aes { key }
    }
}

impl PRF for Aes {
    fn encrypt(&self, pt: [u8; 16]) -> [u8; 16] {
        let mut state = pt;

        xor(&mut state, &self.key);

        // sub bytes
        for _ in 0..NUMROUNDS {
            sub_bytes(&mut state);
            shift_rows(&mut state);
            mix_columns(&mut state);
            xor(&mut state, &self.key);
        }

        state
    }
}
