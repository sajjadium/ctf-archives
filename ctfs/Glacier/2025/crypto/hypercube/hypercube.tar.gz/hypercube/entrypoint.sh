#!/bin/sh
/usr/bin/stdbuf -i0 -o0 -e0 /app/challenge
