#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Respect the shebang and mark file as executable

import os
import random
import pyotp
from datetime import datetime, timedelta, timezone
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    flash,
    abort,
    jsonify,
)
from flask_login import (
    LoginManager,
    current_user,
    login_user,
    logout_user,
    login_required,
)
from models import (
    Base,
    engine,
    SessionLocal,
    User,
    Secret,
    ShareLink,
    TokenType,
    gen,
)

from waitress import serve
from pathlib import Path
import subprocess
import sys
import threading

# create and configure the app
app = Flask(__name__, instance_relative_config=True)
app.config.from_mapping(SECRET_KEY=random.randbytes(128))

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


@login_manager.user_loader
def load_user(user_id):
    db = SessionLocal()
    try:
        return db.query(User).filter(User.id == int(user_id)).first()
    finally:
        db.close()


# Create database tables
Base.metadata.create_all(bind=engine)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        if not email or not password:
            flash("Email and password are required")
            return render_template("register.html")

        db = SessionLocal()
        try:
            # Check if user already exists
            existing_user = db.query(User).filter(User.email == email).first()
            if existing_user:
                flash("Email already registered")
                return render_template("register.html")

            # Create new user
            new_user = User(email=email)
            new_user.set_password(password)
            db.add(new_user)
            db.commit()

            flash("Registration successful! Please log in.")
            return redirect(url_for("login"))
        finally:
            db.close()

    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        otp_code = request.form.get("otp_code")

        if not email or not password:
            flash("Email and password are required")
            return render_template("login.html")

        db = SessionLocal()
        try:
            user = db.query(User).filter(User.email == email).first()
            if user and user.check_password(password):
                if user.two_fa_enabled and user.two_fa_secret_id:
                    now = datetime.now(timezone.utc)
                    if user.last_attempt_time:
                        last_attempt = user.last_attempt_time
                        if last_attempt.tzinfo is None:
                            last_attempt = last_attempt.replace(tzinfo=timezone.utc)
                        time_diff = (now - last_attempt).total_seconds()
                        if time_diff > 30:
                            user.login_attempts = 0

                    if user.login_attempts >= 3:
                        flash("Too many attempts. Please wait 30 seconds.")
                        db.commit()
                        return render_template("login.html")

                    if not otp_code:
                        flash("2FA code required")
                        return render_template("login.html", needs_2fa=True)

                    # Verify OTP
                    secret = (
                        db.query(Secret)
                        .filter(Secret.id == user.two_fa_secret_id)
                        .first()
                    )
                    if secret:
                        if secret.token_type == TokenType.TOTP:
                            totp = pyotp.TOTP(secret.secret_key)
                            valid = totp.verify(otp_code, valid_window=1)
                        else:  # HOTP
                            hotp = pyotp.HOTP(secret.secret_key)
                            valid = hotp.verify(otp_code, secret.counter)
                            if valid:
                                secret.counter += 1

                        user.login_attempts += 1
                        user.last_attempt_time = now

                        if valid:
                            user.login_attempts = 0
                            db.commit()
                            login_user(user)
                            flash("Login successful!")
                            return redirect(url_for("index"))
                        else:
                            db.commit()
                            flash(
                                f"Invalid 2FA code. {3 - user.login_attempts} attempts remaining."
                            )
                            return render_template("login.html", needs_2fa=True)

                login_user(user)
                flash("Login successful!")
                return redirect(url_for("index"))
            else:
                flash("Invalid email or password")
        finally:
            db.close()

    return render_template("login.html")


@app.route("/logout")
@login_required
def logout():
    logout_user()
    flash("You have been logged out.")
    return redirect(url_for("index"))


@app.route("/enroll", methods=["GET", "POST"])
@login_required
def enroll():
    if request.method == "POST":
        name = request.form.get("name")
        secret_key = request.form.get("secret_key")
        token_type = request.form.get("token_type")

        if not all([name, secret_key, token_type]):
            flash("Name, secret key, and token type are required")
            return render_template("enroll.html")

        if token_type not in [TokenType.HOTP, TokenType.TOTP]:
            flash("Invalid token type")
            return render_template("enroll.html")

        # Validate secret key format
        try:
            if token_type == TokenType.TOTP:
                pyotp.TOTP(secret_key)
            else:
                pyotp.HOTP(secret_key)
        except Exception:
            flash("Invalid secret key format")
            return render_template("enroll.html")

        db = SessionLocal()
        try:
            # Check if name already exists for this user
            existing = (
                db.query(Secret)
                .filter(Secret.user_id == current_user.id, Secret.name == name)
                .first()
            )

            if existing:
                flash("A secret with this name already exists")
                return render_template("enroll.html")

            # Create new secret
            new_secret = Secret(
                user_id=current_user.id,
                name=name,
                secret_key=secret_key,
                token_type=token_type,
            )
            db.add(new_secret)
            db.commit()

            flash("Secret enrolled successfully!")
            return redirect(url_for("secrets"))
        finally:
            db.close()

    return render_template("enroll.html")


@app.route("/secrets")
@login_required
def secrets():
    db = SessionLocal()
    try:
        user_secrets = db.query(Secret).filter(Secret.user_id == current_user.id).all()
        user = db.query(User).filter(User.id == current_user.id).first()
        return render_template(
            "secrets.html",
            secrets=user_secrets,
            two_fa_enabled=user.two_fa_enabled,
            two_fa_secret_id=user.two_fa_secret_id,
        )
    finally:
        db.close()


@app.route("/enable_2fa", methods=["POST"])
@login_required
def enable_2fa():
    secret_id = request.form.get("secret_id")

    if not secret_id:
        flash("Please select a secret for 2FA")
        return redirect(url_for("secrets"))

    db = SessionLocal()
    try:
        secret = (
            db.query(Secret)
            .filter(Secret.id == secret_id, Secret.user_id == current_user.id)
            .first()
        )

        if not secret:
            flash("Invalid secret selected")
            return redirect(url_for("secrets"))

        user = db.query(User).filter(User.id == current_user.id).first()
        user.two_fa_enabled = True
        user.two_fa_secret_id = secret.id
        db.commit()

        flash("2FA enabled successfully!")
    finally:
        db.close()

    return redirect(url_for("secrets"))


@app.route("/disable_2fa", methods=["POST"])
@login_required
def disable_2fa():
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == current_user.id).first()
        user.two_fa_enabled = False
        user.two_fa_secret_id = None
        user.login_attempts = 0
        user.last_attempt_time = None
        db.commit()

        flash("2FA disabled successfully!")
    finally:
        db.close()

    return redirect(url_for("secrets"))


@app.route("/change_password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current_password = request.form.get("current_password")
        new_password = request.form.get("new_password")
        confirm_password = request.form.get("confirm_password")

        if not all([current_password, new_password, confirm_password]):
            flash("All fields are required")
            return render_template("change_password.html")

        if new_password != confirm_password:
            flash("New passwords do not match")
            return render_template("change_password.html")

        db = SessionLocal()
        try:
            user = db.query(User).filter(User.id == current_user.id).first()

            if not user.check_password(current_password):
                flash("Current password is incorrect")
                return render_template("change_password.html")

            user.set_password(new_password)
            db.commit()

            flash("Password changed successfully!")
            return redirect(url_for("secrets"))
        finally:
            db.close()

    return render_template("change_password.html")


@app.route("/api/generate_password", methods=["GET"])
@login_required
def generate_password():
    password = gen.token_urlsafe(256)[:32]
    return jsonify({"password": password})


@app.route("/export", methods=["GET"])
@login_required
def export_secrets():
    """Export all user's secrets as JSON"""
    db = SessionLocal()
    try:
        user_secrets = db.query(Secret).filter(Secret.user_id == current_user.id).all()

        export_data = {
            "user_email": current_user.email,
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "secrets": [],
        }

        for secret in user_secrets:
            secret_data = {
                "name": secret.name,
                "secret_key": secret.secret_key,
                "type": secret.token_type,
                "created_at": secret.created_at.isoformat() if secret.created_at else None,
            }
            export_data["secrets"].append(secret_data)

        # Create response with appropriate headers for file download
        response = jsonify(export_data)
        response.headers["Content-Disposition"] = (
            f"attachment; filename=secrets_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
        response.headers["Content-Type"] = "application/json"

        return response

    finally:
        db.close()


@app.route("/share", methods=["GET", "POST"])
@login_required
def share():
    if request.method == "POST":
        if not current_user.is_authenticated:
            abort(401)
        secret_id = request.form.get("secret_id")
        hours = request.form.get("hours", type=int)

        if not secret_id or not hours:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify(
                    {"success": False, "error": "Secret and time range are required"}
                ), 400
            flash("Secret and time range are required")
            return redirect(url_for("secrets"))

        if hours <= 0 or hours > 24:
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify(
                    {
                        "success": False,
                        "error": "Time range must be between 1 and 24 hours",
                    }
                ), 400
            flash("Time range must be between 1 and 24 hours")
            return redirect(url_for("secrets"))

        db = SessionLocal()
        try:
            secret = (
                db.query(Secret)
                .filter(
                    Secret.id == secret_id,
                )
                .first()
            )

            if not secret:
                if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                    return jsonify({"success": False, "error": "Secret not found"}), 404
                flash("Secret not found")
                return redirect(url_for("secrets"))

            share_token = gen.token_urlsafe(32)
            expires_at = datetime.now(timezone.utc) + timedelta(hours=hours)

            share_link = ShareLink(
                secret_id=secret.id, share_token=share_token, expires_at=expires_at
            )
            db.add(share_link)
            db.commit()

            share_url = url_for("share", token=share_token, _external=True)

            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify(
                    {
                        "success": True,
                        "share_url": share_url,
                        "expires_at": expires_at.strftime("%Y-%m-%d %H:%M UTC"),
                    }
                )

            flash(f"Share link created: {share_url}")
            return redirect(url_for("secrets"))
        except Exception as e:
            db.rollback()
            if request.headers.get("X-Requested-With") == "XMLHttpRequest":
                return jsonify(
                    {"success": False, "error": "Failed to create share link"}
                ), 500
            flash("An error occurred while creating the share link")
            return redirect(url_for("secrets"))
        finally:
            db.close()

    # GET request - view shared secret
    token = request.args.get("token")
    if not token:
        abort(404)

    db = SessionLocal()
    try:
        share_link = db.query(ShareLink).filter(ShareLink.share_token == token).first()

        if not share_link:
            abort(404)

        expires_at = share_link.expires_at
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(tzinfo=timezone.utc)

        if datetime.now(timezone.utc) > expires_at:
            flash("This share link has expired")
            abort(404)

        secret = share_link.secret

        if secret.token_type == TokenType.TOTP:
            totp = pyotp.TOTP(secret.secret_key)
            token_value = totp.now()
        else:
            hotp = pyotp.HOTP(secret.secret_key)
            token_value = hotp.at(secret.counter)
            secret.counter += 1
            db.commit()

        return render_template(
            "view_shared.html",
            secret=secret,
            token_value=token_value,
            expires_at=share_link.expires_at,
        )
    finally:
        db.close()


def _run_bootstrap_once(
    script_rel="admin.py",
):
    script_path = Path(__file__).resolve().parent / script_rel
    db = SessionLocal()
    admin_password = gen.token_urlsafe(16)
    admin_email = "admin@istra.tor"
    new_user = User(email=admin_email)
    new_user.set_password(password=admin_password)
    db.add(new_user)
    env = dict(os.environ)
    env.update(
        {
            "BOOTSTRAP_BASE": "http://127.0.0.1:1337",
            "BOOTSTRAP_EMAIL": admin_email,
            "BOOTSTRAP_PASSWORD": admin_password,
        }
    )

    subprocess.Popen(
        [sys.executable, str(script_path)],
        close_fds=True,
        env=env,
    )


# Start bootstrap in background thread
bootstrap_thread = threading.Thread(target=_run_bootstrap_once, daemon=True)
bootstrap_thread.start()

print("Starting server on 0.0.0.0:1337", flush=True)
serve(app, host="0.0.0.0", port=1337)
