import requests
import os
import time
from urllib.parse import urljoin
import base64


BASE = "http://localhost:1337"
BASE = os.environ.get("BOOTSTRAP_BASE", "http://127.0.0.1:1337")
EMAIL = os.environ.get("BOOTSTRAP_EMAIL", "admin@istra.tor")
PASSWORD = os.environ.get("BOOTSTRAP_PASSWORD")
s = requests.Session()


def wait_for_server(timeout=30):
    """Wait until the app responds with 200/302 on /."""
    deadline = time.time() + timeout
    url = urljoin(BASE, "/")
    while time.time() < deadline:
        time.sleep(0.5)
        try:
            r = s.get(url, timeout=2, allow_redirects=False)
            if r.status_code in (200, 302):
                return True
        except requests.RequestException:
            pass
    return False


def register(email, password):
    return s.post(
        urljoin(BASE, "/register"),
        data={"email": email, "password": password},
        timeout=5,
    )


def login(email, password):
    return s.post(
        urljoin(BASE, "/login"), data={"email": email, "password": password}, timeout=5
    )


def enroll(name, secret_key, token_type="TOTP"):
    return s.post(
        urljoin(BASE, "/enroll"),
        data={"name": name, "secret_key": secret_key, "token_type": token_type},
        timeout=5,
    )


def create_share(secret_id, hours):
    r = s.post(
        urljoin(BASE, "/share"),
        headers={"X-Requested-With": "XMLHttpRequest"},  # get JSON back
        data={"secret_id": secret_id, "hours": hours},
    )


def enable_2fa(secret_id):
    return s.post(
        urljoin(BASE, "/enable_2fa"),
        data={"secret_id": secret_id},
        timeout=5,
    )


def get_secrets():
    r = s.get(urljoin(BASE, "/secrets"), timeout=5)
    # Parse secret IDs from HTML (hacky but works)
    import re

    pattern = r'name="secret_id"\s+value="(\d+)"'
    matches = re.findall(pattern, r.text)
    return matches


def change_password(current_password, new_password):
    return s.post(
        urljoin(BASE, "/change_password"),
        data={
            "current_password": current_password,
            "new_password": new_password,
            "confirm_password": new_password,
        },
        timeout=5,
    )


def generate_password():
    r = s.get(urljoin(BASE, "/api/generate_password"), timeout=5)
    if r.status_code == 200:
        return r.json().get("password")
    return None


def main():
    if not PASSWORD:
        raise SystemExit("BOOTSTRAP_PASSWORD not set")

    if not wait_for_server():
        raise SystemExit("Server did not become ready in time")

    r = register(EMAIL, PASSWORD)

    r = login(EMAIL, PASSWORD)
    if r.status_code not in (200, 302):
        raise SystemExit(f"Login failed: {r.status_code}")

    with open("../flag.txt", "rb") as f:
        flag = f.read().strip()
        b32 = base64.b32encode(flag).decode("ascii")
        r = enroll("Flag OTP", b32, "totp")

    secrets = get_secrets()
    if secrets:
        enable_2fa(secrets[0])

    # Generate a new password using the API and change to it
    new_password = generate_password()
    if new_password:
        r = change_password(PASSWORD, new_password)
        if r.status_code in (200, 302):
            print("Admin password changed successfully")
        else:
            print(f"Failed to change password: {r.status_code}")
    else:
        print("Failed to generate new password")


if __name__ == "__main__":
    main()
