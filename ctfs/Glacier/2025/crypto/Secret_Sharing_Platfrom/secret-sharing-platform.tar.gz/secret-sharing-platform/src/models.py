import os
import base64
import hashlib
import hmac
from datetime import datetime, timezone
from flask_login import UserMixin
from sqlalchemy import (
    create_engine,
    Column,
    BigInteger,
    Integer,
    String,
    Boolean,
    DateTime,
    Enum,
    ForeignKey,
)
from dotenv import load_dotenv
from sqlalchemy.orm import declarative_base, sessionmaker, relationship
from werkzeug.security import generate_password_hash, check_password_hash

Base = declarative_base()

# Create database directory if it doesn't exist
db_dir = "/tmp"
os.makedirs(db_dir, exist_ok=True)
db_path = os.path.join(db_dir, "app.db")

engine = create_engine(f"sqlite:///{db_path}", future=True)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)


class Role:
    USER = "user"
    ADMIN = "admin"


class User(UserMixin, Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    email = Column(String(255), unique=True, nullable=False, index=True)
    password_hash = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    email_confirmed = Column(Boolean, default=False)
    role = Column(Enum(Role.USER, Role.ADMIN, name="role_enum"), default=Role.USER)
    created_at = Column(DateTime, default=datetime.now(timezone.utc))
    two_fa_enabled = Column(Boolean, default=False)
    two_fa_secret_id = Column(BigInteger, ForeignKey("secrets.id"), nullable=True)
    login_attempts = Column(Integer, default=0)
    last_attempt_time = Column(DateTime, nullable=True)

    secrets = relationship(
        "Secret",
        back_populates="user",
        cascade="all, delete-orphan",
        foreign_keys="[Secret.user_id]",
        primaryjoin="User.id==Secret.user_id",
    )

    two_fa_secret = relationship(
        "Secret", foreign_keys=[two_fa_secret_id], post_update=True
    )

    def set_password(self, password: str):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(str(self.password_hash), password)


class TokenType:
    HOTP = "hotp"
    TOTP = "totp"


load_dotenv("/etc/environment", override=False)
seed = os.environ.get("SSP_RNG_SEED")

if seed is None:
    exit()
else:
    try:
        seed = int(seed)
    except ValueError:
        exit()


class TokenPRNG:
    def __init__(self, seed: bytes):
        if not isinstance(seed, (bytes, bytearray)) or len(seed) == 0:
            raise ValueError("seed must be non-empty bytes")
        self._key = bytes(seed)
        self._ctr = 0

    def _prf(self, nbytes: int) -> bytes:
        out = b""
        while len(out) < nbytes:
            self._ctr += 1
            mac = hmac.new(
                self._key, self._ctr.to_bytes(16, "big"), hashlib.sha256
            ).digest()
            out += mac

        return out[:nbytes]

    def token_urlsafe(self, nbytes: int = 32) -> str:
        raw = self._prf(nbytes)
        return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


# usage
gen = TokenPRNG(seed=seed.to_bytes(20))


def rand_pk():
    return int.from_bytes(gen._prf(8), "big") & ((1 << 63) - 1)


class Secret(Base):
    __tablename__ = "secrets"
    id = Column(BigInteger, primary_key=True, default=rand_pk, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    name = Column(String(255), nullable=False)
    secret_key = Column(String(255), nullable=False)
    token_type = Column(
        Enum(TokenType.HOTP, TokenType.TOTP, name="token_type_enum"), nullable=False
    )
    counter = Column(Integer, default=0)  # For HOTP
    created_at = Column(DateTime, default=datetime.now(timezone.utc))

    user = relationship("User", back_populates="secrets", foreign_keys=[user_id])
    share_links = relationship(
        "ShareLink", back_populates="secret", cascade="all, delete-orphan"
    )


class ShareLink(Base):
    __tablename__ = "share_links"
    id = Column(Integer, primary_key=True)
    secret_id = Column(Integer, ForeignKey("secrets.id"), nullable=False)
    share_token = Column(String(255), unique=True, nullable=False, index=True)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.now(timezone.utc))

    secret = relationship("Secret", back_populates="share_links")
