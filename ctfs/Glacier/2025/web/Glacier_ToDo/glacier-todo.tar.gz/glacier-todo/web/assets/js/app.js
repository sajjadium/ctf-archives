function register() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  API.register(username, password)
    .then(res => res.json())
    .then(data => {
      alert('Registered successfully!');
    }).catch(err => alert('Registration failed'));
}

function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  API.login(username, password)
    .then(res => res.json())
    .then(data => {
      loadApp();
    }).catch(err => alert('Login failed'));
}

function loadApp() {
  API.info().then(res => res.json()).then(user => {
    document.getElementById('auth').classList.add('hidden');
    document.getElementById('todoApp').classList.remove('hidden');
    document.getElementById('userDisplay').innerText = user.data.username;
    loadTodos();
  }).catch(err => alert('Session expired or unauthorized'));
}

function loadTodos() {
  API.list()
    .then(res => res.json())
    .then(data => {
      const todos = data.data.todos;
      const list = document.getElementById('todoList');
      list.innerHTML = '';
      todos.forEach(todo => {
        const li = document.createElement('li');
        li.innerHTML = `
          <div>
            <strong>${todo.name}</strong><br>
            <small>${todo.desc}</small>
          </div>
          <button onclick="deleteTodo('${todo.id}')">🗑</button>
        `;
        list.appendChild(li);
      });
    }).catch(err => alert('Failed to load todos'));
}

function addTodo() {
  const name = document.getElementById('todoName').value;
  const desc = document.getElementById('todoDesc').value;
  API.add(name, desc)
    .then(res => res.json())
    .then(() => {
      document.getElementById('todoName').value = '';
      document.getElementById('todoDesc').value = '';
      loadTodos();
    }).catch(err => alert('Failed to add todo'));
}

function deleteTodo(id) {
  API.remove(id)
    .then(res => res.json())
    .then(() => {
      loadTodos();
    }).catch(err => alert('Failed to delete todo'));
}

// Try auto-login
window.addEventListener('DOMContentLoaded', () => {
  API.info()
    .then(res => res.json())
    .then(data => {
      if (data.data.loggedIn) loadApp();
    });
});

