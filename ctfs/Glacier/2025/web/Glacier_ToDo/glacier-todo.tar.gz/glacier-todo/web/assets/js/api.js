const API = new class {
  register(username, password) {
    const formData = new FormData();
    formData.append("username", username)
    formData.append("password", password)
    return fetch("/api.php?path=" + encodeURIComponent("/account/register"), {
      method: "POST",
      body: formData
    })
  }

  login(username, password) {
    const formData = new FormData();
    formData.append("username", username)
    formData.append("password", password)
    return fetch("/api.php?path=" + encodeURIComponent("/account/login"), {
      method: "POST",
      body: formData,
    })
  }

  info() {
    return fetch("/api.php?path=" + encodeURIComponent("/account/info"), {
        method: "GET",
    })
  }

  list() {
    return fetch("/api.php?path=" + encodeURIComponent("/todos/list"), {
      method: "GET",
    })
  }

  add(name, desc) {
    const formData = new FormData();
    formData.append("name", name)
    formData.append("desc", desc)
    return fetch("/api.php?path=" + encodeURIComponent("/todos/add"), {
      method: "POST",
      body: formData
    })
  }

  remove(id) {
    const formData = new FormData();
    formData.append("id", id)
    return fetch("/api.php?path=" + encodeURIComponent("/todos/remove"), {
      method: "POST",
      body: formData
    })
  }
}()
