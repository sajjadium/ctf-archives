<?php

session_start();
header("Content-Type: application/json");
$start = microtime(true);

define("TODOS", "/tmp/todos");
define("USERS", "/tmp/users.json");
define("SESS", "LOGIN_ID");
if(!file_exists(USERS)) file_put_contents(USERS, "[]"); 
if(!is_dir(TODOS)) mkdir(TODOS);

$res = array();
$data = array();
$status = 1;
$path = $_GET["path"];

if($path === "/todos/list") {
  $isLoggedIn = isset($_SESSION[SESS]);
  if(!$isLoggedIn) goto fail;
  $user = $_SESSION[SESS];
  if(!file_exists(TODOS . "/" . $user)) file_put_contents(TODOS . "/" . $user, "[]");
  $todos = json_decode(file_get_contents(TODOS . "/" . $user), true);
  $data["todos"] = array_values($todos);
} elseif($path === "/todos/add") {
  $isLoggedIn = isset($_SESSION[SESS]);
  if(!$isLoggedIn) goto fail;
  $user = $_SESSION[SESS];
  if(!file_exists(TODOS . "/" . $user)) file_put_contents(TODOS . "/" . $user, "[]");
  $todos = json_decode(file_get_contents(TODOS . "/" . $user));
  $name = isset($_POST["name"]) ? filter_input(INPUT_POST, "name") : '';
  $desc = isset($_POST["desc"]) ? filter_input(INPUT_POST, "desc") : '';
  $todos[] = array(
    "id" => uniqid(),
    "name" => $name,
    "desc" => $desc
  );
  file_put_contents(TODOS . "/" . $user, json_encode(array_values($todos)));
} elseif($path === "/todos/remove") {
  $isLoggedIn = isset($_SESSION[SESS]);
  if(!$isLoggedIn) goto fail;
  $user = $_SESSION[SESS];
  if(!file_exists(TODOS . "/" . $user)) file_put_contents(TODOS . "/" . $user, "[]");
  $todos = json_decode(file_get_contents(TODOS . "/" . $user));
  $id = isset($_POST["id"]) ? filter_input(INPUT_POST, "id") : '';
  file_put_contents(TODOS . "/" . $user, json_encode(array_values(array_filter($todos, function($item) use($id) {
    return $item->id !== $id;
  }))));
} elseif($path === "/account/info") {
  $isLoggedIn = isset($_SESSION[SESS]);
  $data["loggedIn"] = $isLoggedIn;  
  $data["username"] = $_SESSION[SESS];  
} elseif($path === "/account/login") {
  $username = isset($_POST["username"]) ? filter_input(INPUT_POST, "username") : '';
  $password = isset($_POST["password"]) ? filter_input(INPUT_POST, "password") : '';
  $users = json_decode(file_get_contents(USERS));
  foreach($users as $user)
    if($user->username === $username && password_verify($password, $user->password))
      goto valid_login;
  goto fail;
  valid_login:
  $_SESSION[SESS] = $username;
} elseif($path === "/account/register") {
  $username = isset($_POST["username"]) ? filter_input(INPUT_POST, "username") : '';
  $password = isset($_POST["password"]) ? filter_input(INPUT_POST, "password") : '';
  $users = json_decode(file_get_contents(USERS));
  foreach($users as $user)
    if($user->username === $username) goto fail;

  $users[] = array(
    "username" => $username,
    "password" => password_hash($password, PASSWORD_DEFAULT)
  );
  file_put_contents(USERS, json_encode($users));
} else {
  http_response_code(404);
}

goto end;
fail:
http_response_code(500);
$status = 0;
end:
$end = microtime(true);
$res["data"] = $data;
$res["success"] = $status;
$res["exec_time"] = $end - $start;
echo json_encode($res);

