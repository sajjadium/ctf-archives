<?php

require_once "/var/www/html/index.php";

$users = json_decode(file_get_contents("/var/www/users.json"));
if(!is_array($users)) return;
foreach($users as $idx => $user) {
  $sessionID = generateSessionID($idx);
  storeSession($sessionID, json_encode($user));
}

?>
