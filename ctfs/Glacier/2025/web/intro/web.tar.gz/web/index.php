<?php

function generateSessionID($seed) {
  return md5($seed); 
}

function storeSession($sessionID, $value) {
  file_put_contents("/tmp/$sessionID", $value);
}

function retrieveSession($sessionID) {
  return json_decode(file_get_contents("/tmp/$sessionID"));
}

function getSessionID() {
  $sessionID = $_COOKIE["sess"];   
  if($sessionID == NULL) return NULL;
  return preg_match('/^[a-f0-9]{32}$/i', $sessionID) ? $sessionID : NULL;
}

function handleLogin() {
  $form = filter_input(INPUT_POST, "form");
  if($form === "login") {
    $username = filter_input(INPUT_POST, "username");
    $password = filter_input(INPUT_POST, "password");
    $users = json_decode(file_get_contents("/var/www/users.json"));
    if(!is_array($users)) return;
    foreach($users as $idx => $user) {
      if($user->username === $username && $user->password === $password) {
        $sessionID = generateSessionID($idx);
        setcookie("sess", $sessionID);
        storeSession($sessionID, json_encode($user));
        header("Location: /");
        exit();
      }
    }
  }
}

handleLogin();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="./main.css">
</head>
<body>

  <?php

if(getSessionID()) {
  $sessionData = retrieveSession(getSessionID());
  if($sessionData != NULL) {
    ?>
    <div class="main-container">
      <h2>Hello <?= $sessionData->username; ?></h2>
      <p>Nice to see you.</p>
      <?php if($sessionData->moderator === true) { ?>
      <p>Oh, you are moderator! Here you go: <?= file_get_contents("/flag.txt"); ?></p>
      <?php } ?>
      </div>

    <?php    
    } else {
    ?>
    <div class="main-container">
      <h2>Oh snap!</h2>
      <p>Something went wrong retrieving the session</p>
      </div>

    <?php
    }
} else {
?>

    <div class="main-container">
        <h2>Login</h2>
        <form action="#" method="POST">
            <input type="hidden" name="form" value="login" />
            <div class="input-group">
                <input type="text" placeholder="Username" name="username" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password" required>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>

  <?php
} ?>
</body>
</html>
