from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from echo.models import Echo


class Command(BaseCommand):
    help = "Seeds the database with initial echo data including the flag"

    def handle(self, *args, **options):
        count = Echo.objects.count()

        if count == 0:
            self.stdout.write("Seeding database with initial echoes...")

            base_time = timezone.now() - timedelta(days=7)

            initial_echoes = [
                Echo(
                    message="GlacierECHO system initialized",
                    content_type="text/plain",
                    timestamp=base_time,
                    ip_address="127.0.0.1",
                ),
                Echo(
                    message="Ice layer health check: STABLE",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(minutes=5),
                    ip_address="127.0.0.1",
                ),
                Echo(
                    message="Welcome to GlacierECHO monitoring system",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(minutes=10),
                    ip_address="192.168.1.100",
                ),
                Echo(
                    message="Arctic sensor array: Online",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=1),
                    ip_address="192.168.1.101",
                ),
                Echo(
                    message="Thermal scan complete: -42°C",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=2),
                    ip_address="192.168.1.102",
                ),
                Echo(
                    message="Remote glacier station connected",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=2, minutes=30),
                    ip_address="10.0.0.5",
                ),
                Echo(
                    message="New echo pattern registered: #IC3-7734",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=3),
                    ip_address="192.168.1.103",
                ),
                Echo(
                    message="Cache cleared: Frost buildup removed",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=4),
                    ip_address="127.0.0.1",
                ),
                Echo(
                    message="Scheduled maintenance: Ice core extraction",
                    content_type="text/plain",
                    timestamp=base_time + timedelta(hours=5),
                    ip_address="127.0.0.1",
                ),
            ]

            Echo.objects.bulk_create(initial_echoes)

            self.stdout.write(
                self.style.SUCCESS(
                    f"Successfully seeded database with {len(initial_echoes)} echoes"
                )
            )
        else:
            self.stdout.write(
                self.style.WARNING(
                    f"Database already contains {count} echoes. Skipping seed."
                )
            )
