from django.contrib.auth.hashers import check_password, make_password
from django.contrib.auth.models import User
from django.db import models


class BaseStation(models.Model):

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        related_name="base_station",
        null=True,
        blank=True,
    )
    station_id = models.CharField(max_length=50, unique=True)
    password_hash = models.CharField(max_length=255)
    station_name = models.CharField(max_length=100)
    location = models.CharField(max_length=100, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "base_stations"

    def set_password(self, password):
        self.password_hash = make_password(password)

    def check_password(self, password):
        return check_password(password, self.password_hash)

    def __str__(self):
        return f"{self.station_id}: {self.station_name}"

    def to_dict(self):
        return {
            "id": self.id,
            "station_id": self.station_id,
            "station_name": self.station_name,
            "location": self.location,
            "created_at": self.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "is_active": self.is_active,
        }


class Echo(models.Model):

    message = models.TextField()
    content_type = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.CharField(max_length=45, blank=True, null=True)
    base_station = models.ForeignKey(
        BaseStation,
        on_delete=models.CASCADE,
        related_name="echoes",
        blank=True,
        null=True,
    )

    class Meta:
        db_table = "echoes"
        ordering = ["-timestamp"]

    def __str__(self):
        return f"Echo {self.id}: {self.message[:30]}..."

    def to_dict(self):
        return {
            "id": self.id,
            "message": self.message,
            "content_type": self.content_type,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "ip_address": self.ip_address,
            "base_station_id": self.base_station_id,
            "station_name": (
                self.base_station.station_name if self.base_station else "System"
            ),
        }
