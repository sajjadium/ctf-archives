#!/bin/bash

set -e

echo "Running database migrations..."
python manage.py migrate --noinput

echo "Setting up Django authentication..."
python manage.py migrate_to_django_auth

echo "Seeding database..."
python manage.py seed_database

echo "Starting Django server on 0.0.0.0:5000..."
exec python manage.py runserver 0.0.0.0:5000
