from django.conf import settings
from django.contrib.auth.models import User
from django.core.management.base import BaseCommand

from echo.models import BaseStation


class Command(BaseCommand):
    help = "Migrate existing users to Django authentication system"

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.SUCCESS("Starting migration to Django authentication...")
        )

        admin_username = settings.ADMIN_USERNAME
        admin_password = settings.ADMIN_PASSWORD

        try:
            admin_user = User.objects.get(username=admin_username)
            admin_user.set_password(admin_password)
            admin_user.is_superuser = True
            admin_user.is_staff = True
            admin_user.save()
            self.stdout.write(
                self.style.SUCCESS(f"✅ Updated admin user password: {admin_username}")
            )
        except User.DoesNotExist:
            admin_user = User.objects.create_superuser(
                username=admin_username,
                password=admin_password,
                email="admin@glacierecho.local",
            )
            self.stdout.write(
                self.style.SUCCESS(f"✅ Created admin user: {admin_username}")
            )

        self.stdout.write(
            self.style.WARNING(f"📝 Current admin password: {admin_password}")
        )

        base_stations = BaseStation.objects.filter(user__isnull=True)
        migrated_count = 0

        for station in base_stations:
            if User.objects.filter(username=station.station_id).exists():
                self.stdout.write(
                    self.style.WARNING(
                        f"⚠️  User already exists for station: {station.station_id}, skipping..."
                    )
                )
                continue

            user = User.objects.create_user(username=station.station_id, password=None)
            user.set_unusable_password()
            user.save()

            station.user = user
            station.save()

            migrated_count += 1
            self.stdout.write(
                self.style.SUCCESS(
                    f"✅ Migrated base station: {station.station_id} (password needs to be reset)"
                )
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"\n✅ Migration complete! Migrated {migrated_count} base station(s)."
            )
        )

        if migrated_count > 0:
            self.stdout.write(
                self.style.WARNING(
                    "\n⚠️  Note: Existing base station users will need to reset their passwords as password hashes cannot be migrated directly."
                )
            )
