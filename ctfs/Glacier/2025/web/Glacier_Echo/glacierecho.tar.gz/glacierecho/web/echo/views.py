import logging
import re
import os

from django.conf import settings
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.models import User
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import csrf_exempt
from redis import Redis
from rq import Queue
from werkzeug.http import parse_options_header

from .models import BaseStation, Echo

q = Queue(connection=Redis.from_url(os.getenv("REDIS", "redis://echo-redis:6379")))
logger = logging.getLogger(__name__)


def validate_password(password):
    errors = []

    if len(password) < 8:
        errors.append("at least 8 characters")
    if not re.search(r"[A-Z]", password):
        errors.append("an uppercase letter")
    if not re.search(r"[a-z]", password):
        errors.append("a lowercase letter")
    if not re.search(r"[0-9]", password):
        errors.append("a number")
    if not re.search(r'[!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?]', password):
        errors.append("a special character")

    if errors:
        return False, f"Password must include: {', '.join(errors)}"
    return True, None


def get_current_user(request):
    if not request.user.is_authenticated:
        return None

    if request.user.is_superuser:
        return {
            "type": "admin",
            "username": request.user.username,
            "role": "admin",
        }

    try:
        base_station = request.user.base_station
        return {
            "type": "base_station",
            "station_id": base_station.station_id,
            "base_station_id": base_station.id,
            "role": "base_station",
        }
    except BaseStation.DoesNotExist:
        return None


def index(request):
    current_user = get_current_user(request)
    if not current_user:
        return redirect("/login")

    message = request.GET.get("message", "")
    content_type = request.GET.get("type", "text/plain")

    past_echoes = []
    if current_user.get("role") == "base_station":
        try:
            echoes = Echo.objects.filter(
                base_station_id=current_user.get("base_station_id")
            )
            past_echoes = [echo.to_dict() for echo in echoes]
        except Exception as e:
            logger.error(f"Failed to fetch echoes for base station: {e}")

    return render(
        request,
        "index.html",
        {
            "message": message,
            "content_type": content_type,
            "current_user": current_user,
            "past_echoes": past_echoes,
        },
    )


@csrf_exempt
def echo(request):
    current_user = get_current_user(request)
    if not current_user:
        return HttpResponse(
            "Error: Authentication required. Please login first.", status=401
        )

    content_type = request.GET.get("type", "text/plain")
    parsed_type = parse_options_header(content_type)[0]

    if parsed_type != "text/plain":
        return HttpResponse("Error: Only text/plain are allowed!", status=403)

    message = request.GET.get("message", "")

    try:
        new_echo = Echo.objects.create(
            message=message,
            content_type=content_type,
            ip_address=request.META.get("REMOTE_ADDR"),
            base_station_id=current_user.get("base_station_id"),
        )
        logger.info(
            f"Saved echo to database for(station: {current_user.get('station_id', 'admin')})"
        )
    except Exception as e:
        logger.error(f"Failed to save echo to database: {e}")

    echo_response = f"{message}\n{message}\n{message}"

    response = HttpResponse(echo_response)
    response["Content-Type"] = content_type
    return response


def register(request):
    if request.method == "POST":
        station_id = request.POST.get("station_id", "").strip()
        password = request.POST.get("password", "")
        station_name = request.POST.get("station_name", "").strip()
        location = request.POST.get("location", "").strip()

        if not station_id or not password or not station_name:
            return render(
                request,
                "register.html",
                {"error": "All required fields must be filled"},
            )

        is_valid, error_message = validate_password(password)
        if not is_valid:
            return render(request, "register.html", {"error": error_message})

        if BaseStation.objects.filter(station_id=station_id).exists():
            return render(
                request, "register.html", {"error": "Station ID already registered"}
            )

        if User.objects.filter(username=station_id).exists():
            return render(
                request, "register.html", {"error": "Username already exists"}
            )

        user = User.objects.create_user(username=station_id, password=password)

        new_station = BaseStation(
            user=user,
            station_id=station_id,
            station_name=station_name,
            location=location,
        )
        new_station.set_password(password)
        new_station.save()

        logger.info(f"New base station registered: {station_id}")

        auth_login(request, user)

        return redirect("/")

    return render(request, "register.html", {"error": None})


def login(request):
    if request.method == "POST":
        username = request.POST.get("username", "")
        password = request.POST.get("password", "")

        logger.info(f"Login attempt: {username}")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            try:
                base_station = user.base_station
                if not base_station.is_active:
                    return render(
                        request, "login.html", {"error": "Base station is inactive"}
                    )
            except BaseStation.DoesNotExist:
                pass

            auth_login(request, user)

            if user.is_superuser:
                return redirect("/control-center")
            else:
                return redirect("/")

        return render(request, "login.html", {"error": "Invalid credentials"})

    return render(request, "login.html", {"error": None})


def admin_panel(request):
    if not request.user.is_authenticated or not request.user.is_superuser:
        return redirect("/login")

    past_echoes = []
    try:
        echoes = Echo.objects.all()
        past_echoes = [echo.to_dict() for echo in echoes]
    except Exception as e:
        logger.error(f"Failed to fetch echoes from database: {e}")

    session_info = {"username": request.user.username, "role": "admin"}

    return render(
        request,
        "admin.html",
        {
            "authenticated": True,
            "session_info": session_info,
            "flag": settings.FLAG,
            "cookies": request.COOKIES,
            "past_echoes": past_echoes,
        },
    )


@csrf_exempt
def report(request):
    current_user = get_current_user(request)
    if not current_user:
        return HttpResponse("Error: Authentication required", status=401)

    echo_id = request.POST.get("echo_id")
    if echo_id:
        try:
            echo = Echo.objects.get(id=echo_id)
            logger.info(
                f"⚠️ REPORT: Station {current_user.get('station_id', 'unknown')} reported echo #{echo_id}"
            )

            visit_url = f"echo?type={echo.content_type}&message={echo.message}"
            q.enqueue("bot.visit", visit_url, echo.id)
            logger.info(f"Admin bot queued to visit echo #{echo_id}")

            return HttpResponse(f"Echo #{echo_id} reported to admin", status=200)
        except Echo.DoesNotExist:
            pass

    return HttpResponse("Invalid request", status=400)


def logout(request):
    if request.user.is_authenticated:
        auth_logout(request)

    return redirect("/")
