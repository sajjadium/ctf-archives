#!/bin/sh
rq worker --with-scheduler --url $REDIS
