import logging
import os
from time import sleep

from playwright.sync_api import sync_playwright

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

f = open("/flag.txt", "r")
flag = f.read()
f.close()

def visit(url, echo_id):
    logger.info(f"Admin bot visiting reported echo #{echo_id}")

    admin_password = os.getenv("ADMIN_PASSWORD", "admin")
    base_url = os.getenv("BASE_URL", "")

    with sync_playwright() as p:
        browser = p.chromium.launch(
            headless=True,
            args=[
                "--disable-dev-shm-usage",
                "--disable-extensions",
                "--disable-gpu",
                "--no-sandbox",
                "--headless",
            ],
        )

        page = browser.new_page()
        page.set_default_timeout(15000)

        try:
            logger.info("Bot: Logging in as admin")
            page.goto(f"{base_url}/login")
            page.fill('input[name="username"]', "admin")
            page.fill('input[name="password"]', admin_password)
            page.click('button[type="submit"]')
            page.wait_for_load_state("networkidle")

            page.goto(f"{base_url}/control-center")
            sleep(2)

            logger.info(f"Bot: Visiting reported URL: {url}")
            page.goto(f"{base_url}/{url}")
            sleep(2)

            logger.info(f"Bot: Testing echo with sensitive data")
            test_message = f"Admin test: {flag}"
            page.goto(f"{base_url}/echo?type=text/plain&message={test_message}")
            sleep(1)

            logger.info(f"Bot: Finished testing echo #{echo_id}")

        except Exception as e:
            logger.error(f"Bot error while visiting echo #{echo_id}: {e}")
        finally:
            browser.close()
