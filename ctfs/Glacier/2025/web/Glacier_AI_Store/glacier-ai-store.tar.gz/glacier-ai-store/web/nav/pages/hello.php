<?php

respondText($SYSTEM, "Hello, I am GlacierAI and will assist you today navigating our Glacier AI Store.");

sendCtrl("HELLO_NEXT");

?>
