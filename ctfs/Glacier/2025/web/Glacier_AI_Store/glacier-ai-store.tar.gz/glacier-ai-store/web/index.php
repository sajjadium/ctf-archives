<html>
  <head>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,300italic,700,700italic">
    <link rel="stylesheet" href="/assets/css/normalize.css">
    <link rel="stylesheet" href="/assets/css/chat.css">
    <link rel="stylesheet" href="/assets/css/main.css">
    <style>
    #iframe {
      position: absolute;
      width: 100%;
      height: 100%;
      border: none;
    }

    .chat-wrapper {
      position: absolute; 
      bottom: 10px; 
      right: 10px;
    }
    </style>
    <title>Glacier AI Store</title>
  </head>
  <body>
    <iframe src="" id="iframe"></iframe>
<div class="chat-wrapper">
<div class="chat">
    <div class="contact bar">
          <div class="pic">
            <img src="/assets/img/chatbot-icon.svg" />
          </div>
      <div class="name">
        Glacier AI 
      </div>
      <div class="seen">
        <span style="color: #14a23e; font-size: 19px;">●</span> Online 
      </div>
      <div style="position: absolute; right: 10px">
          <button id="hide-chat" class="button-3" style="width: 40px; background-color: #F7F7F7; color: #333;">-</button>
      </div>
    </div>
    <div class="messages-element messages chat">
      <div id="chat"></div>
      <div id="ref"></div>
    </div>
    <div class="messages-element input" style="margin: auto; padding-top: 15px;">
      <div id="yesno" style="display: none">
        <button class="button-3" id="yesno_yes">Yes</button>
        <button class="button-3" id="yesno_no">No</button>
      </div>
      <div id="continue" style="display: none">
        <button class="button-3" id="continue_btn">Continue</button>
      </div>
      <div id="restart" style="display: none">
        <button class="button-3" id="restart_btn">Restart</button>
      </div>
    </div>
  </div>
</div>
    </div>

<div style="display: none">
      <div id="user" class="message parker">
        <span data-message></span> 
      </div>
      <div id="system" class="message stark">
        <span data-message></span> 
      </div>
</div>

<script src="/assets/js/chat.js"></script>
<script src="/assets/js/navigation.js"></script>
<script>

navigate()


</script>
    </body>
  </html>
