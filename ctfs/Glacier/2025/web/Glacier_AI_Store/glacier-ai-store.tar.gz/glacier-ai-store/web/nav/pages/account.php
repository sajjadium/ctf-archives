<?php

$loginId = isLoggedIn();

if($loginId) {
  respondText($SYSTEM, "Ok great, you are already logged in.");
  sendCtrl("PRODUCT_LIST");
} else {
  respondText($SYSTEM, "You are not logged in. Please create an account or login to your existing account");
  sendCtrl("ACCOUNT_NOSESSION");
}
