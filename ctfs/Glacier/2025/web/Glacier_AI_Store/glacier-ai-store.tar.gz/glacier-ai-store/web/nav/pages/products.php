<?php


if(!isLoggedIn()) {
  respondText($SYSTEM, "You are not logged in.");
  sendCtrl("ACCOUNT_NOSESSION");
  exit(0);
}

$sell = $_POST["sell"];
$reason = $_POST["reason"];
if(isset($sell) && array_key_exists($sell, $products)) {
  respondText($USER, "Cancel Order for product " . $products[$sell]["title"]);
  respondText($SYSTEM, "Cancelling Order for product " . $products[$sell]["title"]);

  $loginID = getLoginID();
  if(!hasUserProduct($loginID, $sell)) goto product_list;
  increaseBalance($loginID, $products[$sell]["price"]);
  if(isset($reason) && strlen($reason) > 0)
    respondText($USER, $reason);
  sellProduct($loginID, $sell, $reason);
  goto product_list;
}

$product = $_SESSION["product"];
$btn = $_POST["btn"];
if(isset($product) && isset($btn) && array_key_exists($product, $products)) {
  unset($_SESSION["product"]);
  if($btn === "yes") {
    $loginID = getLoginID();
    if(decreaseBalance($loginID, $products[$product]["price"])) {
      respondText($USER, $btn);
      buyProduct($loginID, $product);
      respondText($SYSTEM, "Great, we have received your order.");
    } else {
      respondText($SYSTEM, "Oh snap, seems like you don't have enough balance to buy this product.");
    }
  }
  goto product_list;
}

$product = $_POST["product"];
if(isset($product) && array_key_exists($product, $products)) {
  $_SESSION["product"] = $product;
  respondText($USER, "Order product " . $products[$product]["title"]);
  respondText($SYSTEM, "Are you sure you want to buy the product?");
  sendCtrl("PRODUCT_BUY");
} else {
  respondText($SYSTEM, "I'll forward you to the store, where you can order new products and view your orders.");
}

exit(0);
# https://xkcd.com/292/
product_list:
  sendCtrl("PRODUCT_LIST");

?>
