<?php

require_once __DIR__ . "/../helpers/database.php";
require_once __DIR__ . "/../helpers/user.php";
require_once __DIR__ . "/../helpers/products.php";
require_once __DIR__ . "/../helpers/utils.php";

$page = $_GET["p"];
if(!array_key_exists($page, $navMapping)) $page = 0x8F;

require_once __DIR__ . $navMapping[$page];

?>
