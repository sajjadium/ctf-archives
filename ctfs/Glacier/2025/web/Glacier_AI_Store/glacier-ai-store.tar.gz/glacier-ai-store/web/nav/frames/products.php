<?php
$user = getLoggedInUser();

if(!$user) {
  respondText($SYSTEM, "You need to be logged in to see that page!");
  exit(0);
}

$user_products = getUserProducts(getLoginID());
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.5/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-SgOJa3DmI69IUzQ2PVdRZhwQ+dy64/BUtbMJw1MZ8t5HZApcHrRKUc4W0kG879m7" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">


      <div class="text-center m-2">
        <small class="text-muted">Current Balance: <?= $user["balance"] ?> &euro;</small>
      </div>

<?php if(count($user_products) > 0): ?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Product</th>
      <th scope="col">Order Description</th>
      <th scope="col">Options</th>
    </tr>
  </thead>
  <tbody>
<?php $i = 0; foreach($user_products as $product): ?>
<tr>
  <th><?= $i+1 ?></th>
  <td><?= $products[$product["product"]]["title"] ?></td>
  <td><?= $products[$product["product"]]["ordered_desc"]; ?></td>
  <td>
    <button class="btn btn-sm btn-outline-danger" onclick="request({sell: '<?=$product["product"];?>', reason: ''})">Cancel Order</button>
  </td>
</tr>
<?php $i++; endforeach; ?>
</table>
<?php endif; ?>

<div class="row">
<?php foreach($products as $product => $info): ?>

<div class="col-md-3">
  <div class="card">
            <img src="<?=$info["img"]?>" class="card-img-top" alt="...">
            <div class="card-body">
  <h5 class="card-title"><?= $info["title"] ?></h5>
  <p class="card-text"><?= $info["desc"] ?></p>
              <hr />
              <div class="text-center">
                <p class="card-text">Only for <?= $info["price"] ?> &euro;</p>
                <button class="btn btn-sm btn-outline-success" onclick="request({product: '<?=$product;?>'}, 0x91)">Order Product</button>
                </div>
  </div>
            </div>
</div>

<?php endforeach; ?>

</div>
</div>


<script>

function request(d, p=0) {
  window.parent.postMessage(JSON.stringify({p,d}), "*")
}

</script>
  </body>
</html>


