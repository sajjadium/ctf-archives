let p = 0 

function request(data = {}) {
  return new Promise((res, rej) => {
    const formData = new FormData()
    Object.keys(data).forEach(key => {
      formData.append(key, data[key])
    })
    fetch("/nav/index.php?" + (new URLSearchParams({p})).toString(), {
      method: "POST",
      body: formData
    })
      .then((response) => {
        const reader = response.body.getReader();
        Chat(reader).then((info) => {
          res(info)
        })
    })
  })
}


document.getElementById("yesno_yes").addEventListener("click", _ => {
  navigate({"btn": "yes"})
  document.getElementById("yesno").style.display = "none"
})

document.getElementById("yesno_no").addEventListener("click", _ => {
  document.getElementById("yesno").style.display = "none"
  navigate({"btn": "no"})
})

document.getElementById("continue_btn").addEventListener("click", _ => {
  document.getElementById("continue").style.display = "none"
  navigate()
})

document.getElementById("restart_btn").addEventListener("click", _ => {
  document.getElementById("restart").style.display = "none"
  document.getElementById("chat").innerHTML = ''
  navigate()
})


function navigate(d = {}) {
  request(d).then(([nav, option, frame]) => {
    document.getElementById("iframe").src = `/nav/index.php?p=${frame}`
    p = nav 
    switch(option) {
      case 0x11:
        document.getElementById("yesno").style.display = "block"
        break;
      case 0x12:
        document.getElementById("continue").style.display = "block"
        break;
      case 0x13:
        document.getElementById("restart").style.display = "block"
        break;
      case 0x14:
        break;
      default:
        navigate() 
    }
  })
}

window.addEventListener('message', event => {
  const res = JSON.parse(event.data)
  if(res.p !== 0) p = res.p
  navigate(res.d)
})
