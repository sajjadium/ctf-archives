<?php

session_start();

$navMapping = array(
  0x8F => "/pages/hello.php",
  0x90 => "/pages/goodbye.php",
  0x91 => "/pages/products.php",
  0x92 => "/pages/account.php",

  0xFC => "/frames/account.php",
  0xFD => "/frames/products.php",
  0xFE => "/frames/empty.php"
);

$options = array(
  "NONE" => "\x10",
  "YESNO" => "\x11",
  "CONTINUE" => "\x12",
  "RESTART" => "\x13",
  "STALL" => "\x14"
);

$routes = array(
  "HELLO_NEXT" => $options["NONE"] . "\x92\xFE",
  "ACCOUNT_NOSESSION" => $options["STALL"] . "\x92\xFC",
  "GOODBYE_NEXT" => $options["RESTART"] . "\x8F\xFE",
  "PRODUCT_LIST" => $options["NONE"] . "\x91\xFD",
  "PRODUCT_BUY" => $options["YESNO"] . "\x91\xFE",
);

$SYSTEM = "\x01";
$USER = "\x02";

// Emulates this super fancy AI response thingy
function respondText($type, $msg="") {
  $textToStream = $type . $msg;
  for($i = 0; $i < strlen($textToStream); $i++) {
    echo $textToStream[$i];
    usleep(50000);
    ob_flush();
    flush();
  }
}

function sendCtrl($name) {
  global $routes;
  if(array_key_exists($name, $routes))
    respondText($routes[$name]);
}

function getLoggedInUser() {
  if(!isLoggedIn()) return;
  return getUserById(getLoginID());
}

function getLoginID() {
  return $_SESSION["login_id"];
}

function isLoggedIn() {
  return !!$_SESSION["login_id"];
}

function setLoginID($id) {
  $_SESSION["login_id"] = $id;
}

function login($username, $password) {
  $user = getUser($username);
  if(!$user) return false;
  if(!password_verify($password, $user["password"])) return false;
  setLoginID($user["id"]);
  return true;
}

function register($username, $password, $passwordRepeat) {
  if(strlen($password) === 0 || $password !== $passwordRepeat) return false;
  if(getUser($username)) return false;
  addUser($username, $password);
  return true;
}
