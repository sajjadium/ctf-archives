<?php

respondText($SYSTEM, "Thank you for visiting our store and have a nice day.");
sendCtrl("GOODBYE_NEXT");

?>
