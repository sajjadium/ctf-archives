<?php

function addUser($username, $password) {
  global $db;

  $user = getUser($username);
  if($user) return;

  $stmt = $db->prepare('INSERT INTO users 
    (username, password, balance)
    VALUES (:username, :password, 1)');
  $stmt->bindValue(":username", $username);
  $stmt->bindValue(":password", password_hash($password, PASSWORD_DEFAULT));
  $stmt->execute();
}

function getUser($username) {
  global $db;
  $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
  $stmt->bindValue(":username", $username);
  $result = $stmt->execute();
  $entry = $result->fetchArray(SQLITE3_ASSOC);
  return $entry;
}

function getUserById($id) {
  global $db;
  $stmt = $db->prepare("SELECT * FROM users WHERE id = :id");
  $stmt->bindValue(":id", $id);
  $result = $stmt->execute();
  $entry = $result->fetchArray(SQLITE3_ASSOC);
  return $entry;
}

function updateBalance($userID, $balance) {
  global $db;
  $stmt = $db->prepare("UPDATE users SET balance = :balance WHERE id = :id");
  $stmt->bindValue(":id", $userID);
  $stmt->bindValue(":balance", $balance);
  $stmt->execute();
}

function decreaseBalance($userID, $balance) {
  $user = getUserById($userID);
  if(!$user) return false;
  if(intval($user["balance"]) < intval($balance)) return false;
  updateBalance($userID, intval($user["balance"]) - intval($balance));
  return true;
}

function increaseBalance($userID, $balance) {
  $user = getUserById($userID);
  if(!$user) return false;
  updateBalance($userID, intval($user["balance"]) + intval($balance));
  return true;
}
