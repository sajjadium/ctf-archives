const Chat = (function() {
  const chat = document.getElementById("chat")
  let currentChatEl = document.createElement("div")
  const hideChat = document.getElementById("hide-chat") 
  let isHidden = false

  hideChat.addEventListener("click", _ => {
    isHidden ^= true
    if(isHidden) hide()
    else show()
  })


  function hide() {
    isHidden = true
    document.querySelectorAll(".messages-element").forEach(el => el.style.display = "none")
    document.querySelector(".chat").style.height = "6rem";
    hideChat.textContent = "+"
  }

  function show() {
    isHidden = false
    document.querySelectorAll(".messages-element").forEach(el => el.style.display = "block")
    document.querySelector(".chat").style.height = "38rem";
    hideChat.textContent = "-"
  }

  function updateChatMode(mode) {
    currentChatEl = document.getElementById(mode).cloneNode(true)
    currentChatEl.id = ""
    chat.appendChild(currentChatEl)
  }

  function processChat(reader) {
    show()
    return new Promise((res, rej) => {
      let optionCtrl = false;
      let navCtrl = false;
      let frameCtrl = false;
      new ReadableStream({
        start(controller) {
          return pump();
          function pump() {
            return reader.read().then(({ done, value }) => {
              // When no more data needs to be consumed, close the stream
              if(value.includes(1)) updateChatMode("system")
              if(value.includes(2)) updateChatMode("user") 
              if(value.includes(1) && value.includes(2)) alert("BUG: This should not happen")
              msg = new TextDecoder().decode(value.filter(v => v >= 0x20 && v <= 0x7E))
              document.getElementById("ref").scrollIntoView()
              const options = value.filter(v => v >= 0x10 && v < 0x20)
              if(options.length > 0)
                if(options.length === 1 && optionCtrl === false)
                  optionCtrl = options[0]
                else
                  alert("BUG: There are multiple ctrl options")

              const navs = value.filter(v => v > 0x7E && v < 0xC0)
              if(navs.length > 0)
                if(navs.length === 1 && navCtrl === false)
                  navCtrl = navs[0]
                else
                  alert("BUG: There are multiple ctrl navs")

              const frames = value.filter(v => v >= 0xC0 && v < 0xFF)
              if(frames.length > 0)
                if(frames.length === 1 && frameCtrl === false)
                  frameCtrl = frames[0]
                else
                  alert("BUG: There are multiple ctrl navs")
             
              currentChatEl.querySelector("[data-message]").textContent += msg
              if(navCtrl && optionCtrl && frameCtrl)
                res([navCtrl, optionCtrl, frameCtrl])
              if (done) {
                controller.close();
                return;
              }
              // Enqueue the next data chunk into our target stream
              controller.enqueue(value);
              return pump();
            });
          }
        },
      });
    })
  }
  return processChat.bind(this) 
})()
