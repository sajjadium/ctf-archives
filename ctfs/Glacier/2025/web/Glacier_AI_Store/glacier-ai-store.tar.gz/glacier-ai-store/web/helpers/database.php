<?php

$db = null;

function getDatabase() {
  global $db;
  $db = new SQLite3("/tmp/db.sqlite");
  $db->query('CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    username VARCHAR,
    password VARCHAR,
    balance INTEGER
  )');

  $db->query('CREATE TABLE IF NOT EXISTS user_products (
    id TEXT PRIMARY KEY DEFAULT (hex(randomblob(16))),
    user TEXT,
    product TEXT
  )');
}

getDatabase();

?>
