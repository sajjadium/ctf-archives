<?php

$products = array(
  "stone" => array(
    "title" => "Glacier Stone",
    "price" => 1,
    "desc" => "A very rare stone harvested from the top parts of the Glacier. Very nice decoration for your home.",
    "ordered_desc" =>  "This product will be shipped asap",
    "img" => "/assets/img/glacierstone.png"
  ),
  "water" => array(
    "title" => "Glacier Water",
    "price" => 10,
    "desc" => "Fresh glacier water in a clear bottle – straight from pristine nature. Perfect for those who seek purity and refreshment in its most natural form.",
    "ordered_desc" =>  "This product will be shipped asap",
    "img" => "/assets/img/glacierwater.png"
  ),
  "jar" => array(
    "title" => "Glacier Aurora Jar",
    "price" => 100,
    "desc" => "Capture the magic of the Arctic with our Aurora Jar – a mesmerizing swirl of northern lights sealed in glass, glowing with the spirit of the glacier. A truly unique piece of frozen wonder.",
    "ordered_desc" => "This product will be shipped asap",
    "img" => "/assets/img/glacierjar.png"
  ),
  "flag" => array(
    "title" => "Glacier Flag",
    "price" => 1000,
    "desc" => "This flag brings you joy in your life. All your work and effort putting into earning money will be worth getting this beautiful flag.",
    "ordered_desc" => file_get_contents("/flag.txt"),
    "img" => "/assets/img/glacierflag.png"
  )
);

function buyProduct($userID, $product) {
  global $db;
  global $products;
  if(!array_key_exists($product, $products)) return;
  $stmt = $db->prepare("INSERT INTO user_products 
    (user, product)
    VALUES (:user, :product)");
  $stmt->bindValue(":user", $userID);
  $stmt->bindValue(":product", $product);
  $stmt->execute();
}

function sellProduct($userID, $product) {
  global $db;  
  global $products;
  if(!array_key_exists($product, $products)) return false;
  $stmt = $db->prepare("DELETE FROM user_products 
    WHERE id IN (
    SELECT id 
    FROM user_products 
    WHERE user = :user AND product = :product)
    LIMIT 1
  ");
  $stmt->bindValue(":user", $userID);
  $stmt->bindValue(":product", $product);
  $result = $stmt->execute();
}

function getUserProducts($userID) {
  global $db;
  $stmt = $db->prepare("SELECT user, product FROM user_products
    WHERE user = :user");
  $stmt->bindValue(":user", $userID);
  $result = $stmt->execute();
  $entries = [];
  while($entry = $result->fetchArray(SQLITE3_ASSOC))
    $entries[] = $entry;
  return $entries;
}

function hasUserProduct($userID, $product) {
  $products = getUserProducts($userID);
  $f = array_filter($products, function($dbProduct) use($product) { return $dbProduct["product"] === $product; });
  return count($f) > 0;
}
