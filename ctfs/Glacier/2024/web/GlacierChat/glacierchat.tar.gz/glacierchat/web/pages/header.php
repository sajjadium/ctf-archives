<html>
<head>
<title>GlacierChat</title>
<link href="/assets/paper.min.css" rel="stylesheet" />
<link href="/assets/main.css" rel="stylesheet" />
</head>
  <body>
    <div class="sm-12 md-8 col" style="margin: auto">
      <div class="paper container-lg">
