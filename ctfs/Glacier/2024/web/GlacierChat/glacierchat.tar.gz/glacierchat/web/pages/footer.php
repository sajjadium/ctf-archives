</div>
<div class="text-muted text-center" style="font-size: 12px;"><?= date("r");?></div>
</div>
</body>
</html>
