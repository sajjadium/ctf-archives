<footer>
        &copy; <?php echo date("Y"); ?> FuzzyBytes Malware Scanner | <a href="privacy.php">Privacy Policy</a> | <a href="contact.php">Contact Us</a>
    </footer>
</body>
</html>
