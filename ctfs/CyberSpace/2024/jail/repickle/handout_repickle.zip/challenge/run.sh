#!/bin/bash

cd /home/user || exit
python3 challenge.py