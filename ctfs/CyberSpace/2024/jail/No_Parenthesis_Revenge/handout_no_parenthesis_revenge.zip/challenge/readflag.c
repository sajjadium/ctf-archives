#include <stdio.h>

int main(int argc, char *argv[]) {
  puts("CSCTF{fake_flag_for_testing}");
  return 0;
}