To run this challenge execute:

```
./run.sh
```

It will use docker to start the container on port 5000. 

**PLEASE solve this challenge locally before trying on remote!!
If you think there is something wrong with the challenge, open a ticket and let us know!
The flag format of this challenge is /^CSCTF{a-z0-9}$/
So only lowercase and numbers.**