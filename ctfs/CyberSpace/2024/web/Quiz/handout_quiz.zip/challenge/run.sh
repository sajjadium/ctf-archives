#!/bin/sh

cd /home/user || exit
/usr/local/bin/php -S 0.0.0.0:1337