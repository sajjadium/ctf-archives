#trendz

This is a 4 part challenge. Each part will give you a flag. To run the challenge, you need to run build and run the docker container.
```bash
docker build -t trendz .
docker run --rm -it -p 80:80 trendz
```

Have fun!