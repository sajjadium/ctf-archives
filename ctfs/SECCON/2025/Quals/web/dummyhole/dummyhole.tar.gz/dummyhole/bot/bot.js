import puppeteer from 'puppeteer';

const ADMIN_USERNAME = process.env.ADMIN_USERNAME ?? console.log('No admin username') ?? process.exit(1);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? console.log('No admin password') ?? process.exit(1);
const FLAG = process.env.FLAG ?? console.log('No flag') ?? process.exit(1);

const APP_HOSTNAME = "web";
const APP_URL = 'http://' + APP_HOSTNAME;

const sleep = async (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const visit = async (id) => {
  console.log(`start: ${id}`);

  const browser = await puppeteer.launch({
    headless: 'new',
    executablePath: '/usr/bin/google-chrome-stable',
    args: [
      '--no-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--js-flags="--noexpose_wasm"',
    ],
  });

  const context = await browser.createBrowserContext();

  try {
    const page = await context.newPage();
    await context.setCookie({
      name: 'FLAG',
      value: FLAG,
      domain: APP_HOSTNAME,
      path: '/',
    });
    
    // Login
    await page.goto(`${APP_URL}/login`, { timeout: 10_000 });
    await page.type('input[id="username"]', ADMIN_USERNAME);
    await page.type('input[id="password"]', ADMIN_PASSWORD);
    await page.click('button');

    await page.waitForSelector('#imageFile');


    // Visit reported post
    await page.goto(`${APP_URL}/posts/?id=${encodeURIComponent(id)}`, { timeout: 10_000 });
    await sleep(10_000);
    await page.close();
  } catch (e) {
    console.error(e);
  }

  await context.close();
  await browser.close();

  console.log(`end: ${id}`);
};
