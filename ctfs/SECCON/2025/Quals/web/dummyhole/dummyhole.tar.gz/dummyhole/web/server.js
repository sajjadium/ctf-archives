const express = require('express');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const { S3Client, PutObjectCommand, GetObjectCommand, CreateBucketCommand, HeadBucketCommand } = require('@aws-sdk/client-s3');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');
const rateLimit = require('express-rate-limit');

const ADMIN_USERNAME = process.env.ADMIN_USERNAME ?? console.log('No admin username') ?? process.exit(1);
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? console.log('No admin password') ?? process.exit(1);
const app = express();
const upload = multer({ storage: multer.memoryStorage() });

const s3Client = new S3Client({
  endpoint: 'http://rustfs:9000',
  region: 'us-east-1',
  credentials: {
    accessKeyId: 'rustfs',
    secretAccessKey: 'rustfs',
  },
  forcePathStyle: true,
});

const BUCKET = 'images';

async function initBucket() {
  try {
    await s3Client.send(new HeadBucketCommand({ Bucket: BUCKET }));
    console.log(`Bucket ${BUCKET} already exists`);
  } catch (error) {
    if (error.name === 'NotFound' || error.$metadata?.httpStatusCode === 404) {
      try {
        await s3Client.send(new CreateBucketCommand({ Bucket: BUCKET }));
        console.log(`Bucket ${BUCKET} created successfully`);
      } catch (createError) {
        console.error(`Failed to create bucket: ${createError.message}`);
      }
    } else {
      console.error(`Error checking bucket: ${error.message}`);
    }
  }
}

const users = new Map();
users.set(ADMIN_USERNAME, { password: ADMIN_PASSWORD });
const sessions = new Map();
const posts = new Map();

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

const loginLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 5,
  message: { error: 'Too many login attempts, please try again later' }
});

const uploadLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 10,
  message: { error: 'Too many upload attempts, please try again later' }
});

function checkOrigin(req, res, next) {
  const origin = req.get('Origin');
  const host = req.get('Host');

  if (origin && origin !== `http://${host}`) {
    return res.status(403).json({ error: 'Invalid origin' });
  }
  next();
}

function requireAuth(req, res, next) {
  const sessionId = req.cookies.session;
  if (!sessionId || !sessions.has(sessionId)) {
    return res.redirect('/login');
  }
  req.user = sessions.get(sessionId);
  next();
}

function redirectIfAuthenticated(req, res, next) {
  const sessionId = req.cookies.session;
  if (sessionId && sessions.has(sessionId)) {
    return res.redirect('/upload');
  }
  next();
};

app.get('/', redirectIfAuthenticated, (req, res) => {
  return res.redirect('/login');
});

app.get('/register', redirectIfAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'register.html'));
});

app.post('/register', checkOrigin, (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username and password required' });
  }
  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Invalid username or password' });
  }
  if (username.length <= 4 || password.length <= 4) {
    return res.status(400).json({ error: 'Username and password must be longer than 4 characters' });
  }
  if (users.has(username)) {
    return res.status(400).json({ error: 'User already exists' });
  }
  users.set(username, { password });
  res.json({ success: true });
});

app.get('/login', redirectIfAuthenticated, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/login', checkOrigin, loginLimiter, (req, res) => {
  const { username, password } = req.body;
  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Invalid username or password' });
  }
  const user = users.get(username);
  if (!user || user.password !== password) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const sessionId = uuidv4();
  sessions.set(sessionId, username);
  res.cookie('session', sessionId, {
    httpOnly: true
  });
  res.json({ success: true });
});

app.post('/logout', requireAuth, (req, res) => {
  const sessionId = req.cookies.session;
  sessions.delete(sessionId);
  res.clearCookie('session');

  const post_id = req.body.post_id?.length <= 128 ? req.body.post_id : '';
  const fallback_url = req.body.fallback_url?.length <= 128 ? req.body.fallback_url : '';

  const logoutPage = path.join(__dirname, 'public', 'logout.html');
  const logoutPageContent = fs.readFileSync(logoutPage, 'utf-8')
    .replace('<POST_ID>', encodeURIComponent(post_id))
    .replace('<FALLBACK_URL>', encodeURIComponent(fallback_url));

  res.send(logoutPageContent);
});

app.get('/upload', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'upload.html'));
});

app.post('/upload', checkOrigin, requireAuth, uploadLimiter, upload.single('image'), async (req, res) => {
  try {
    const { title, description } = req.body;
    const file = req.file;

    if (!file || !title) {
      return res.status(400).json({ error: 'Image and title required' });
    }

    if (!file.mimetype || (!file.mimetype.startsWith('image/png') && !file.mimetype.startsWith('image/jpeg'))) {
      return res.status(400).json({ error: 'Invalid file: must be png or jpeg' });
    }

    const postId = uuidv4();

    const command = new PutObjectCommand({
      Bucket: BUCKET,
      Key: postId,
      Body: file.buffer,
      ContentType: file.mimetype,
    });

    await s3Client.send(command);

    posts.set(postId, {
      title,
      description: description || '',
      image_url: `/images/${postId}`,
      author: req.user,
    });

    res.json({ success: true, id: postId });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Upload failed' });
  }
});

app.get('/api/posts/:id', requireAuth, async (req, res) => {
  const id = req.params.id;

  const post = posts.get(id);
  if (!post) {
    return res.status(404).json({ error: 'Post not found' });
  }

  res.json({
    title: post.title,
    description: post.description,
    image_url: post.image_url,
  });
});

app.get('/images/:id', async (req, res) => {
  try {
    const id = req.params.id;

    const command = new GetObjectCommand({
      Bucket: BUCKET,
      Key: id,
    });

    const response = await s3Client.send(command);

    res.setHeader('Content-Type', response.ContentType || 'application/octet-stream');
    res.setHeader('Content-Security-Policy', "default-src 'none'; form-action 'none';");

    const stream = response.Body;
    stream.pipe(res);
  } catch (error) {
    console.error('Image fetch error:', error);
    res.status(404).json({ error: 'Image not found' });
  }
});

app.get('/posts', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'post.html'));
});

app.listen(80, async () => {
  console.log('Server running on port 80');
  await initBucket();
});
