#include "qemu/osdep.h"
#include "hw/pci/pci.h"
#include "hw/pci/pci_device.h"
#include "qemu/log.h"
#include "qapi/error.h"
#include "qemu/module.h"

#define TYPE_SWP "swp"
#define SWP(obj) OBJECT_CHECK(SWPState, (obj), TYPE_SWP)

#define SWP_MMIO_SIZE     (0x20ULL)
#define SWP_PAGE_SIZE     (0x1000ULL)

enum {
    MODE_SWAPOUT = 0,
    MODE_SWAPIN = 1,
};

typedef struct SWPState {
    PCIDevice parent_obj;
    MemoryRegion mmio;
    uint64_t address;
    uint8_t* storage;
    uint32_t size;
    uint32_t mode;
} SWPState;

static bool swp_check_range(PCIDevice* dev, hwaddr page_start) {
    hwaddr mmio_start = pci_get_bar_addr(dev, 0);
    return (page_start < mmio_start + SWP_MMIO_SIZE) \
        && (mmio_start < page_start + SWP_PAGE_SIZE);
}

static void swp_mmio_write(void* opaque, hwaddr addr, uint64_t val, unsigned int len) {
    SWPState* s = opaque;
    uint8_t* storage_base = s->storage;

    switch (addr) {
    case 0x00:
        s->address = val;
        break;

    case 0x08:
        if ((val % SWP_PAGE_SIZE) != 0 || val == s->size) {
            break;
        }

        if (val == 0 && s->storage) {
            munmap(s->storage, s->size);
            s->storage = NULL;
            s->size = 0;
            break;
        }

        s->size = val;
        s->storage = mmap(NULL, s->size, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE, -1, 0);
        if (s->storage == MAP_FAILED) {
            s->storage = NULL;
            s->size = 0;
        }
        break;

    case 0x0c:
        if (val != MODE_SWAPIN && val != MODE_SWAPOUT) {
            break;
        }
        s->mode = val;
        break;

    case 0x10:
        if (val != 0x005ECC02 || s->size == 0) {
            break;
        }
        for (size_t ofs = 0; ofs < s->size; ofs += SWP_PAGE_SIZE) {
            if (swp_check_range(&s->parent_obj, s->address + ofs)) {
                continue;
            }

            if (s->mode == MODE_SWAPOUT) {
                pci_dma_read(&s->parent_obj, s->address + ofs, storage_base + ofs, SWP_PAGE_SIZE);
            }
            else {
                pci_dma_write(&s->parent_obj, s->address + ofs, storage_base + ofs, SWP_PAGE_SIZE);
            }
        }
        break;
    }
}

static uint64_t swp_mmio_read(void* opaque, hwaddr addr, unsigned int len) {
    SWPState* s = opaque;

    switch (addr) {
    case 0x00:
        return s->address;

    case 0x08:
        return s->size;

    case 0x0c:
        return s->mode;
    }

    return 0;
}

static const MemoryRegionOps swp_mmio_ops = {
    .read = swp_mmio_read,
    .write = swp_mmio_write,
    .endianness = DEVICE_NATIVE_ENDIAN,
    .valid.min_access_size = 1,
    .valid.max_access_size = 8,
};

static void swp_realize(PCIDevice* pdev, Error** errp) {
    SWPState* s = SWP(pdev);

    pci_config_set_vendor_id(pdev->config, 0x1234);
    pci_config_set_device_id(pdev->config, 0x1337);
    pci_config_set_class(pdev->config, PCI_CLASS_MEMORY_RAM);

    pci_set_word(pdev->config + PCI_COMMAND, PCI_COMMAND_MEMORY | PCI_COMMAND_MASTER);

    memory_region_init_io(&s->mmio, OBJECT(s), &swp_mmio_ops, s, "swp-mmio", SWP_MMIO_SIZE);
    memory_region_enable_lockless_io(&s->mmio);
    pci_register_bar(pdev, 0, PCI_BASE_ADDRESS_SPACE_MEMORY, &s->mmio);

    s->address = 0;
    s->size = 0;
    s->mode = MODE_SWAPOUT;
    s->storage = NULL;
}

static void swp_unrealize(PCIDevice* pdev)
{
    SWPState* s = SWP(pdev);

    if (s->storage) {
        munmap(s->storage, s->size);
    }

    memory_region_unref(&s->mmio);
}

static void swp_class_init(ObjectClass* klass, const void* data)
{
    PCIDeviceClass* k = PCI_DEVICE_CLASS(klass);

    k->realize = swp_realize;
    k->exit = swp_unrealize;
    k->vendor_id = 0x1234;
    k->device_id = 0x1337;
    k->class_id = PCI_CLASS_MEMORY_RAM;
}

static const TypeInfo swp_info = {
    .name = TYPE_SWP,
    .parent = TYPE_PCI_DEVICE,
    .instance_size = sizeof(SWPState),
    .class_init = swp_class_init,
    .interfaces = (const InterfaceInfo[]) {
        { INTERFACE_CONVENTIONAL_PCI_DEVICE },
        { }
    },
};

static void swp_register_types(void)
{
    type_register_static(&swp_info);
}

type_init(swp_register_types);
