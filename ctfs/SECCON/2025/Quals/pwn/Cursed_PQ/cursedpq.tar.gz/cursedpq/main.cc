#include <iostream>
#include <queue>

void test_priority_queue() {
  long op, val;
  std::priority_queue<long> q;

  while (std::cin.good()) {
    std::cin >> op;
    if (op == 1) {
      std::cin >> val;
      q.push(val);
    } else if (op == 2) {
      q.pop();
    } else if (op == 3) {
      std::cout << "redacted" << std::endl;
    } else {
      break;
    }
  }
}

int main() {
  while (std::cin.good()) {
    test_priority_queue();
  }
  return 1;
}
