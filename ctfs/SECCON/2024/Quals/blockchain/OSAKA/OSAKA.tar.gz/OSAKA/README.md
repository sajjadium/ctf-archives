The infra shouldn't be vulnerable.
It's not necessary to look at anywhere other than the contract files (`src/contracts`) to solve this challenge!

Start the local challenge server:
```
docker compose up --build
```
