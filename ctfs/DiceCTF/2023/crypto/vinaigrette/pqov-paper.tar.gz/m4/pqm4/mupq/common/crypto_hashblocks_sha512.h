#ifndef CRYPTO_HASHBLOCKS_SHA512_H
#define CRYPTO_HASHBLOCKS_SHA512_H

int crypto_hashblocks_sha512(unsigned char *statebytes,const unsigned char *in,
                      unsigned long long inlen);

#endif
