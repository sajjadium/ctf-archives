#ifndef M1CYCLES_H
#define M1CYCLES_H

void __m1_setup_rdtsc(void);

unsigned long long int __m1_rdtsc(void);

#endif
