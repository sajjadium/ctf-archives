# BCU-8 Control Interface

Run `docker-compose up --build` to start the server.

# Experiments

## BCU-diffusion

Hello world experiment example.

## BCU-transcription (rev)

Figure out the input to the transcription experiment that doesn't produce `bad`.

## BCU-translation (rev)

Figure out the input to the translation experiment that doesn't produce `bad`.
