
# DICEON

Set the `OPENAI_API_KEY` environment variable in `docker-compose.yml` to your OpenAI API key.

Run `docker-compose up --build` to start.

Go to http://localhost:8989/ to access the frontend.
