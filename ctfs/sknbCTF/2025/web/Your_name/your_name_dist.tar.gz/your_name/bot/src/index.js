const express = require("express");
const puppeteer = require("puppeteer");


const app = express();
const port = 3000;

app.use(express.urlencoded({
    extended: false,
}));

const visit = async (cookie) => {
    const browser = await puppeteer.launch({
        executablePath: "/usr/bin/chromium",
        args: [
            "--no-sandbox",
        ],
    });
    await browser.setCookie({
        domain: "localhost",
        name: "flag",
        value: "false",
    });

    let resp;
    const page = await browser.newPage();
    await page.setDefaultTimeout(20000);

    // for generating document
    await page.goto("http://localhost:3000/flag");

    const whitelist = /^[a-zA-Z0-9=;\/]+$/
    const cookies = cookie.split(";");
    for (const pair of cookies) {
        if (!whitelist.test(pair)) {
            return "invalid cookie detected";
        }
        if (pair.startsWith("flag=")) {
            return "invalid cookie detected";
        }
    }
    // set cookie
    await page.evaluate(c => document.cookie = c, cookie);
    
    const res = await page.goto("http://localhost:3000/flag");
    resp = await res.text();

    await page.close();
    await browser.close();
    return resp;
}

app.post("/", async (req, res) => {
    const { cookie } = req.body;
    if (!cookie || typeof(cookie) !== "string") {
        res.send("invalid cookie");
        return;
    }
    const result = await visit(cookie);
    res.send(result);
});

app.get("/flag", (req, res) => {
    const cookieHeader = req.headers.cookie;
    if (!cookieHeader) {
        res.send("no cookies :(");
        return;
    }
    for (const cookie of cookieHeader.split(";")) {
        if (cookie === "flag=true") {
            res.send(process.env.GZCTF_FLAG);
            return;
        }
    }
    res.send("no flag for you");
});

app.listen(port, () => {
    console.log(`app is running on port ${port}`);
});
