const bodyParser = require('body-parser');
const express = require("express");


const app = express();
const port = 3000;

app.use(bodyParser.urlencoded({
    extended: false,
}));
app.set("view engine", "ejs");

app.get("/report", (req, res) => {
    res.render("report.ejs");
});

app.post("/report", async (req, res) => {
    const { cookie } = req.body;
    const resp = await fetch("http://bot:3000/", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `cookie=${cookie}`,
    });
    res.send(await resp.text());
});

app.listen(port, console.log(`app is running on port ${port}`));
