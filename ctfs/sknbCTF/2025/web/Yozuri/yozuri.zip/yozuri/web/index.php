<!DOCTYPE html>
<html>
<body>
    <!--- Aomiya Yozuri is very cute cat (/*・ω・)/  -->
    <h1>Yozuri</h1>
    <h3>Source</h3>
    <pre><?php echo htmlspecialchars(file_get_contents(__FILE__)); ?></pre>
    <h3>Content</h3>
    <?php
    if (isset($_GET["data"])) {
        $data = $_GET["data"];
        if (!is_string($data) | strlen($data) > 4096) {
            echo "Invalid data.";
        }
        else {
          unserialize($data);
        }
    } else {
        echo "No data provided.";
    }?>
    <h3>Token</h3>
    <?php echo htmlspecialchars($_COOKIE["TOKEN"] ?? "TOKEN_0123456789abcdef"); ?>
    <h3>Usage</h3>
    <a href="/?data=your_serialized_data">/?data=your_serialized_data</a>
</body>
</html>