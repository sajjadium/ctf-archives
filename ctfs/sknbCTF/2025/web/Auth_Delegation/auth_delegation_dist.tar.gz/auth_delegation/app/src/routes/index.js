const express = require("express");
const passport = require("passport");


const LocalStrategy = require("passport-local").Strategy;
const router = express.Router();

const waf = (req, res, next) => {
  const { username } = req.body;
  if (!username) {
    next();
    return;
  }
  if (username === "admin") {
    res.redirect("/login?message=admin%20detected");
    return;
  }
  next();
}

passport.use(new LocalStrategy(
  (username, password, done) => {
    
    if (username === "admin" && password === "admin") {
      return done(null, { username: "admin" });
    }
    return done(null, false);
  }
));

passport.serializeUser((user, done) => {
  done(null, user);
});

passport.deserializeUser((user, done) => {
  done(null, user);
});

router.get("/", (req, res) => {
  if (!req.user) {
    res.redirect("/login");
    return;
  }
  if (req.user.username === "admin") {
    res.send(process.env.GZCTF_FLAG);
    return;
  }
  res.send("no flag for you");
});

router.get("/login", (req, res) => {
  const { message } = req.query;
  res.render("login.ejs", {
    message: message ? message : undefined,
  });
});

router.post("/login",
  waf,
  passport.authenticate("local",
    {
      failureRedirect : "/login",
      successRedirect : "/"
    }
  )
);

module.exports = router;
