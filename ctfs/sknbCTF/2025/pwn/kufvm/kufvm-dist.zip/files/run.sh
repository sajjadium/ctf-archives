#!/bin/sh
./main chall.bin