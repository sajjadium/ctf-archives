from flask import Flask, request, render_template_string
import yaml

app = Flask(__name__)

# TODO: Remove SECRET_PIN
SECRET_PIN = 20090706
GUEST_PIN = 100
FLAG = "sknb{dummy}"

# Initial YAML template
DASHBOARD_TEMPLATE = '''
# ───────────────────────────
# Dashboard Configuration
# - username: "admin" or "guest"
# - pin_code: specify your PIN here
# ───────────────────────────
username: guest
pin_code: 100
'''

@app.route('/', methods=['GET', 'POST'])
def configure():
    message = ''
    user_yaml = DASHBOARD_TEMPLATE

    if request.method == 'POST':
        user_yaml = request.form.get('settings', '')
        try:
            data = yaml.load(user_yaml, Loader=yaml.FullLoader)
            user = data.get('username')
            user_pin = data.get('pin_code')

            if user == 'admin' and user_pin is SECRET_PIN:
                message = f"<div class='alert alert-success'>Correct! {FLAG}</div>"
            elif user == 'guest' and user_pin is GUEST_PIN:
                message = "<div class='alert alert-info'>Guest login OK!</div>"
            else:
                message = "<div class='alert alert-danger'>Wrong credentials! Try again.</div>"
        except Exception as e:
            message = f"<div class='alert alert-danger'>Parsing error: {e}</div>"

    html = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Settings</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background: #f5f7fa; }
        .container { max-width: 600px; margin: 40px auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h1 { font-size: 1.8rem; margin-bottom: 1rem; text-align: center; color: #333; }
        textarea { width: 100%; height: 220px; font-family: monospace; font-size: 0.95rem; padding: 10px; border: 1px solid #ccc; border-radius: 4px; }
        button { display: block; width: 100%; padding: 12px; font-size: 1rem; background: #007bff; color: #fff; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .alert { margin-top: 20px; padding: 12px; border-radius: 4px; }
        .alert-success { background: #d4edda; color: #155724; }
        .alert-info { background: #cce5ff; color: #004085; }
        .alert-danger { background: #f8d7da; color: #721c24; }
        .note { font-size: 0.85rem; color: #666; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Dashboard Configuration</h1>
        <p class="note">Enter your settings in YAML format and click "Load Settings".</p>
        <form method="post">
            <textarea name="settings">{{ yaml_text }}</textarea>
            <button type="submit">Load Settings</button>
        </form>
        <div>{{ message|safe }}</div>
    </div>
</body>
</html>
'''
    return render_template_string(html, yaml_text=user_yaml, message=message)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050)
