┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃                 KILLER QUEEN                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

Words & Music: Freddie Mercury
Capo: III
Tempo: Moderately
Time: 4/4

------------------------------------
PATTERNS
------------------------------------
Strum: 3, 4
Pick:  1, 3

------------------------------------
VERSE I
------------------------------------
[Am] She keeps Moët et Chandon
[G7] In a pretty cabinet
[C]  "Let them eat cake," she says
[Am] Just like Marie Antoinette

------------------------------------
PROGRESSION A
------------------------------------
Am → G7 → C → Em7 → C7 → F → Fm → F/G

------------------------------------
VERSE II
------------------------------------
[E]  A built-in remedy
[G]  For Khrushchev and Kennedy
[B7] At any time an invitation
[Em] You can't decline

------------------------------------
PROGRESSION B
------------------------------------
D7 → Bm → F#7 → E7
D/F# → E7/G# → A → D → C/D → Gm

------------------------------------
NOTES
------------------------------------
• Repetition is intentional
• Motifs compose into larger motifs
• Order matters more than magnitude
• The Queen speaks in two voices

------------------------------------
CODA
------------------------------------
Pretty cabinet hides the seed
Moët et Chandon reveals the crown


# Every note in the stream comes from a verse number —
# but the verse itself is already a refrain.

read lyrics listen to this song----this md file was touched by killer queen