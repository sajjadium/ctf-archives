# Dream Labyrinth

*You awaken in a shifting corridor of fractal memories. Shadows of equations twist and collapse around you. Four fragments of shattered consciousness lie scattered across impossible geometries.*

**Category:** Crypto  
**Difficulty:** Hard  
**Author:** MrFahrenheit  
**Points:** ???

## Connection

```
nc <host> 1337
```

## Overview

The Dream Labyrinth is a multi-layer interactive cryptographic challenge. You interact with the server by sending JSON commands over TCP.

Upon connecting, you must first solve a **proof-of-work** challenge. Then you navigate four increasingly difficult fragments.

Fragments must be solved in order. Each unlocked fragment decays after a timeout.

## Protocol

Commands are newline-delimited JSON objects. The server will respond with a JSON object.

**Read the welcome message carefully** — it contains the full protocol specification.

## Files

- `client_example.py` — Basic interactive client with PoW solver

## Dependencies

- Python 3.10+
- The rest is yours to figure out.

## Notes

- The flag format is `EH4X{...}`
- Each connection receives a **unique puzzle instance**
- Resources are limited — use them wisely
- Start by running `client_example.py` and reading the server's welcome message
- The mathematics you encounter will tell you what tools you need

Good luck, dreamer.
