#!/usr/bin/env python3
"""
Dream Labyrinth — Example Client
EHAX CTF 2026

Basic TCP client for interacting with the Dream Labyrinth challenge.
This handles the JSON-over-TCP protocol and proof-of-work.

Usage:
    python3 client_example.py <host> <port>

Dependencies: none (stdlib only for this client)
"""

import socket
import json
import hashlib
import sys
import time


def connect(host, port):
    """Connect to server and return socket."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(60)
    sock.connect((host, port))
    return sock


def recv_json(sock):
    """Read one newline-delimited JSON message."""
    buf = ""
    while "\n" not in buf:
        chunk = sock.recv(8192).decode("utf-8", errors="replace")
        if not chunk:
            raise ConnectionError("Server closed connection.")
        buf += chunk
    line, _ = buf.split("\n", 1)
    return json.loads(line.strip()), buf[buf.index("\n")+1:]


def send_json(sock, obj, buf=""):
    """Send a JSON command and read response."""
    sock.sendall((json.dumps(obj) + "\n").encode("utf-8"))
    # Drain any remaining buffer first
    while "\n" not in buf:
        chunk = sock.recv(8192).decode("utf-8", errors="replace")
        if not chunk:
            raise ConnectionError("Server closed connection.")
        buf += chunk
    line, remaining = buf.split("\n", 1)
    return json.loads(line.strip()), remaining


def solve_pow(prefix, difficulty):
    """Brute-force PoW challenge."""
    print(f"[*] Solving PoW (difficulty={difficulty})...")
    target = 1 << (32 - difficulty)
    nonce = 0
    t0 = time.time()
    while True:
        candidate = str(nonce)
        h = hashlib.sha256((prefix + candidate).encode()).digest()
        value = int.from_bytes(h[:4], 'big')
        if value < target:
            print(f"[+] PoW solved: nonce={candidate} ({time.time()-t0:.2f}s)")
            return candidate
        nonce += 1


def main():
    host = sys.argv[1] if len(sys.argv) > 1 else "localhost"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 1337

    print(f"[*] Connecting to {host}:{port}...")
    sock = connect(host, port)

    # Step 1: Receive PoW challenge
    pow_msg, buf = recv_json(sock)
    print(f"[*] Server: {pow_msg.get('message', '')[:120]}")

    if pow_msg.get("status") == "pow_challenge":
        prefix = pow_msg["prefix"]
        difficulty = pow_msg["difficulty"]
        nonce = solve_pow(prefix, difficulty)
        resp, buf = send_json(sock, {"pow_nonce": nonce}, buf)
        print(f"[*] PoW response: {resp}")

    # Step 2: Receive welcome
    welcome, buf = recv_json(sock)
    print(f"\n[*] Session ID: {welcome.get('session_id', 'unknown')}")
    print(f"[*] Protocol actions:")
    for name, desc in welcome.get("protocol", {}).items():
        print(f"     {name}: {desc}")

    # Step 3: Interactive mode
    print("\n[*] Interactive mode. Type JSON commands (one per line):")
    print("[*] Example: {\"action\": \"probe_manifold\", \"layer\": \"layer1\", \"i\": 0, \"j\": 1}")
    print("[*] Example: {\"action\": \"status\"}")
    print()

    while True:
        try:
            line = input("> ").strip()
            if not line:
                continue
            if line.lower() in ("quit", "exit"):
                break
            cmd = json.loads(line)
            resp, buf = send_json(sock, cmd, buf)
            print(json.dumps(resp, indent=2))
        except json.JSONDecodeError:
            print("[-] Invalid JSON. Try again.")
        except (KeyboardInterrupt, EOFError):
            break
        except Exception as e:
            print(f"[-] Error: {e}")
            break

    sock.close()
    print("[*] Disconnected.")


if __name__ == "__main__":
    main()
