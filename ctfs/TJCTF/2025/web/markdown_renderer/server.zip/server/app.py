from flask import Flask, request, render_template
from uuid import uuid4

# ah, yes, the in-memory database
users = {}
markdowns = {}

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    elif request.method == 'POST':
        if not request.json or 'username' not in request.json:
            return {"error": "Invalid request"}, 400

        username = request.json['username']
        
        user_id = str(uuid4())
        users[user_id] = {
            'username': username,
            'markdowns': []
        }
        markdowns[user_id] = []

        return {'user_id': user_id}, 201

@app.route('/render', methods=['POST'])
def render_markdown():
    if not request.json or 'markdown' not in request.json or 'user_id' not in request.json:
        return {"error": "Invalid request"}, 400
    
    user_id = request.json['user_id']
    if user_id not in users:
        return {"error": "User not found"}, 404

    markdown_content = request.json['markdown']
    markdown_id = str(uuid4())
    markdowns[markdown_id] = {
        'content': markdown_content,
        'author': users[request.json['user_id']]['username']
    }
    users[user_id]['markdowns'].append(markdown_id)

    return {'markdown_id': markdown_id}, 201

@app.route('/markdown/<markdown_id>')
def get_markdown(markdown_id):
    markdown = markdowns.get(markdown_id)
    if markdown is None:
        return {"error": "Markdown not found"}, 404
    return render_template('markdown.html', markdownId=markdown_id)

@app.route('/markdown/<markdown_id>/details')
def get_markdown_details(markdown_id):
    markdown = markdowns.get(markdown_id)
    if markdown is None:
        return {"error": "Markdown not found"}, 404
    return {'content': markdown['content'], 'author': markdown['author']}

@app.route('/user/<user_id>')
def get_user_markdowns(user_id):
    if user_id not in users:
        return {"error": "User not found"}, 404
    
    return users[user_id]['markdowns']

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
