<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://patchstack.com
 * @since             1.0.0
 * @package           P_Member_Manager
 *
 * @wordpress-plugin
 * Plugin Name:       Patchstack Member Manager
 * Plugin URI:        https://patchstack.com
 * Description:       A simple member manager.
 * Version:           1.0.0
 * Author:            Patchstack
 * Author URI:        https://patchstack.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       p-member-manager
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if (!defined("WPINC")) {
    die();
}

define("P_MEMBER_MANAGER_VERSION", "1.0.0");

function activate_p_member_manager()
{
    require_once plugin_dir_path(__FILE__) .
        "includes/class-p-member-manager-activator.php";
    P_Member_Manager_Activator::activate();
}

function get_password_reset_key2($user)
{
    global $wp_hasher;

    if (!($user instanceof WP_User)) {
        return new WP_Error(
            "invalidcombo",
            __(
                "<strong>Error:</strong> There is no account with that username or email address."
            )
        );
    }

    /**
     * Fires before a new password is retrieved.
     *
     * Use the 'retrieve_password' hook instead.
     *
     * @since 1.5.0
     * @deprecated 1.5.1 Misspelled. Use 'retrieve_password' hook instead.
     *
     * @param string $user_login The user login name.
     */
    do_action_deprecated(
        "retreive_password",
        [$user->user_login],
        "1.5.1",
        "retrieve_password"
    );

    /**
     * Fires before a new password is retrieved.
     *
     * @since 1.5.1
     *
     * @param string $user_login The user login name.
     */
    do_action("retrieve_password", $user->user_login);

    $password_reset_allowed = wp_is_password_reset_allowed_for_user($user);
    if (!$password_reset_allowed) {
        return new WP_Error(
            "no_password_reset",
            __("Password reset is not allowed for this user")
        );
    } elseif (is_wp_error($password_reset_allowed)) {
        return $password_reset_allowed;
    }

    // Generate something random for a password reset key.
    $key = wp_generate_password(1, false);
    /**
     * Fires when a password reset key is generated.
     *
     * @since 2.5.0
     *
     * @param string $user_login The username for the user.
     * @param string $key        The generated password reset key.
     */
    do_action("retrieve_password_key", $user->user_login, $key);

    // Now insert the key, hashed, into the DB.
    if (empty($wp_hasher)) {
        require_once ABSPATH . WPINC . "/class-phpass.php";
        $wp_hasher = new PasswordHash(8, true);
    }

    $hashed = time() . ":" . $wp_hasher->HashPassword($key);

    $key_saved = wp_update_user([
        "ID" => $user->ID,
        "user_activation_key" => $hashed,
    ]);

    if (is_wp_error($key_saved)) {
        return $key_saved;
    }

    return $key;
}

function deactivate_p_member_manager()
{
    require_once plugin_dir_path(__FILE__) .
        "includes/class-p-member-manager-deactivator.php";
    P_Member_Manager_Deactivator::deactivate();
}

register_activation_hook(__FILE__, "activate_p_member_manager");
register_deactivation_hook(__FILE__, "deactivate_p_member_manager");

require plugin_dir_path(__FILE__) . "includes/class-p-member-manager.php";
add_action("rest_api_init", "register_user_creation_endpoint");

function register_user_creation_endpoint()
{
    register_rest_route("user/v1", "/create", [
        "methods" => "POST",
        "callback" => "create_user_via_api",
        "permission_callback" => "__return_true", // Allow anyone to access this endpoint
    ]);
}

add_action("wp_ajax_reset_key", "reset_password_key_callback");
add_action("wp_ajax_nopriv_reset_key", "reset_password_key_callback");

function reset_password_key_callback()
{
    $user_id = isset($_POST["user_id"]) ? intval($_POST["user_id"]) : 0;
    $user = new WP_User($user_id);
    if ($user_id > 1) {
        if (
            !empty($user->roles) &&
            is_array($user->roles) &&
            in_array("subscriber", $user->roles)
        ) {
            $updated = get_password_reset_key2($user);
            if (is_wp_error($updated)) {
                wp_send_json_error("Failed to reset password key.");
            } else {
                wp_send_json_success([
                    "message" => "Password reset key reset successfully.",
                ]);
            }
        } else {
            wp_send_json_error("User is not a subscriber.");
        }
    } else {
        wp_send_json_error("Invalid user ID.");
    }
}

add_action("wp_ajax_get_latest_posts", "get_latest_posts_callback");

function get_latest_posts_callback()
{
    // Check if the current user has the subscriber role
    if (!current_user_can("subscriber")) {
        wp_send_json_error("Unauthorized access.");
        return;
    }

    // Generate nonce
    $nonce = wp_create_nonce("get_latest_posts_nonce");

    // Get latest 5 posts
    $args = [
        "posts_per_page" => 5,
        "post_status" => "publish",
        "orderby" => "date",
        "order" => "DESC",
    ];

    $latest_posts = get_posts($args);

    // Prepare posts data
    $posts_data = [];
    foreach ($latest_posts as $post) {
        $posts_data[] = [
            "title" => $post->post_title,
            "content" => $post->post_content,
            "link" => get_permalink($post),
        ];
    }

    // Send response with nonce and posts data
    wp_send_json_success(["nonce" => $nonce, "posts" => $posts_data]);
}

add_action("wp_ajax_patchstack_flagger", "flagger_request_callback");

function flagger_request_callback()
{
    // Validate nonce
    $nonce = isset($_REQUEST["nonce"])
        ? sanitize_text_field($_REQUEST["nonce"])
        : "";
    if (!wp_verify_nonce($nonce, "get_latest_posts_nonce")) {
        wp_send_json_error("Invalid nonce.");
        return;
    }
    $user = wp_get_current_user();
    $allowed_roles = ["administrator", "subscriber"];
    if (array_intersect($allowed_roles, $user->roles)) {
        $value = file_get_contents('/flag.txt');
        wp_send_json_success(["value" => $value]);
    } else {
        wp_send_json_error("Missing permission.");
    }
}

function create_user_via_api($request)
{
    $parameters = $request->get_json_params();

    $username = sanitize_text_field($parameters["username"]);
    $email = sanitize_email($parameters["email"]);
    $password = wp_generate_password();

    // Create user
    $user_id = wp_create_user($username, $password, $email);

    if (is_wp_error($user_id)) {
        return new WP_Error(
            "user_creation_failed",
            __("User creation failed.", "text_domain"),
            ["status" => 500]
        );
    }

    // Add user role
    $user = new WP_User($user_id);
    $user->set_role("subscriber");

    return [
        "message" => __("User created successfully.", "text_domain"),
        "user_id" => $user_id,
    ];
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_p_member_manager()
{
    $plugin = new P_Member_Manager();
    $plugin->run();
}
run_p_member_manager();
