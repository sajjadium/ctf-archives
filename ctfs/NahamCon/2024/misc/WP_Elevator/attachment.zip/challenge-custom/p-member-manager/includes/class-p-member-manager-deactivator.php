<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://patchstack.com
 * @since      1.0.0
 *
 * @package    P_Member_Manager
 * @subpackage P_Member_Manager/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    P_Member_Manager
 * @subpackage P_Member_Manager/includes
 * @author     Patchstack <info@patchstack.com>
 */
class P_Member_Manager_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
