<?php

defined( 'ABSPATH' ) or die( 'Keep Silent' );

if ( ! class_exists( 'Woo_Variations_Backend', false ) ):

	class Woo_Variations_Backend {

		protected static $_instance = null;
		protected $admin_menu;

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		protected function __construct() {
			$this->includes();
			$this->hooks();
			$this->init();
			do_action( 'woo_variations_backend_loaded', $this );
		}

		public function includes() {
			require_once dirname( __FILE__ ) . '/getmoreplugins/class-getmoreplugins-admin-menus.php';
			require_once dirname( __FILE__ ) . '/class-woo-variations-rest-api.php';
		}

		public function hooks() {
			add_filter( 'getmoreplugins_get_settings_pages', array( $this, 'init_settings' ) );

			add_filter( 'plugin_action_links_' . plugin_basename( WOO_VARIATIONS_PLUGIN_FILE ), array(
				$this,
				'plugin_action_links'
			) );

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
			add_action( 'admin_footer', array( $this, 'admin_template_js' ) );

			add_action( 'wp_ajax_associate_product_variation', array( $this, 'associate_product_variation' ) );
			add_action( 'wp_ajax_nopriv_associate_product_variation', array( $this, 'associate_product_variation' ) );
			
			add_action( 'wp_ajax_set_gallery_picture', array( $this, 'set_gallery_picture' ) );
			add_action( 'wp_ajax_nopriv_set_gallery_picture', array( $this, 'set_gallery_picture' ) );
			
			add_action( 'woocommerce_save_product_variation', array( $this, 'save_product_variation' ), 10, 2 );
			add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'gallery_admin_html' ), 10, 3 );
			
			add_action( 'after_switch_theme', array( $this, 'remove_option' ), 20 );
		}

		public function init() {
			$this->admin_menu = GetMorePlugins_Admin_Menus::instance();
			Woo_Variations_REST_API::instance();
		}

		public function gallery_admin_html( $loop, $variation_data, $variation ) {
			$variation_id   = absint( $variation->ID );
			$gallery_images = get_post_meta( $variation_id, 'woo_variations_images', true );
			?>
			<div data-product_variation_id="<?php echo esc_attr( $variation_id ) ?>" class="form-row form-row-full woo-variations-wrapper">
				<div class="woo-variations-postbox">
					<div class="postbox-header">
						<h2><?php esc_html_e( 'Variation Product Gallery', 'woo-variations' ) ?></h2>
						<button type="button" class="handle-div" aria-expanded="true">
							<span class="toggle-indicator" aria-hidden="true"></span>
						</button>
					</div>

					<div class="woo-variations-inside">
						<div class="woo-variations-image-container">
							<ul class="woo-variations-images">
								<?php
								if ( is_array( $gallery_images ) && ! empty( $gallery_images ) ) {
									include dirname( __FILE__ ) . '/admin-template.php';
								}
								?>
							</ul>
						</div>
						<div class="add-woo-variations-image-wrapper hide-if-no-js">
							<a href="#" data-product_variation_loop="<?php echo absint( $loop ) ?>" data-product_variation_id="<?php echo esc_attr( $variation_id ) ?>" class="button-primary add-woo-variations-image"><?php esc_html_e( 'Add Variation Gallery Image', 'woo-variations' ) ?></a>
							<?php if ( ! woo_variations()->is_pro() ): ?>
								<a target="_blank" href="<?php echo esc_url( woo_variations()->get_backend()->get_pro_link() ) ?>" style="display: none" class="button woo-variations-pro-button"><?php esc_html_e( 'Upgrade to pro', 'woo-variations' ) ?></a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
			<?php
		}

		public function save_product_variation( $variation_id, $loop ) {
			
			// At this point admin/shop manager is already authenticated by Woocommerce
			if ( isset( $_POST['woo_variations'] ) ) {

				if ( isset( $_POST['woo_variations'][ $variation_id ] ) ) {

					$gallery_image_ids = array_map( 'absint', $_POST['woo_variations'][ $variation_id ] );
					update_post_meta( $variation_id, 'woo_variations_images', $gallery_image_ids );
				} else {
					delete_post_meta( $variation_id, 'woo_variations_images' );
				}
			} else {
				delete_post_meta( $variation_id, 'woo_variations_images' );
			}
		}
		
		public function associate_product_variation() {
		
			if ( !is_admin() || !$this->check_permission() )
			{
				wp_send_json( 'Unauthorized!' );
			}
			
			if ( !function_exists( 'WC' ) || !isset( $_POST['product_id'] ) || !isset( $_POST['gallery_id'] ) ) {
				return false;
			}

			$product_id = sanitize_text_field( $_POST['product_id'] );
			$variation_id = sanitize_text_field( $_POST['variation_id'] );
			
			if ( wc_get_product( $product_id) && get_post( $variation_id) ) {
				update_post_meta( $product_id, 'product_gallery_id', $variation_id );
			}
			
			return true;
		}
		
		public function set_gallery_picture() {
		
			if ( !is_admin() || !$this->check_permission() )
			{
				wp_send_json( 'Unauthorized!' );
			}
			
			$product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;

			// Verify that the product exists and is a WooCommerce product
			if ( $product_id && function_exists( 'wc_get_product' ) ) {

				if ( $_FILES && isset( $_FILES['gallery_picture'] ) ) {
					
					$file = $_FILES['gallery_picture'];
					$file_type = wp_check_filetype( basename( $file['name'] ), array( 'jpg', 'jpeg', 'png' ) );
					
					$upload_dir = wp_upload_dir();
					$upload_path = $upload_dir['basedir'] . '/woo-gallery/';
					if ( !file_exists( $upload_path ) ) {
						wp_mkdir_p( $upload_path );
					}

					if (move_uploaded_file( $file['tmp_name'], $upload_path . sanitize_file_name($file['name']) ) ) {
						
						$file_url = $upload_dir['baseurl'] . '/woo-gallery/' . sanitize_file_name($file['name']);

						if (function_exists( 'wc_gallery_set_attachment_from_url' ) )
						{
							$attachment_id = wc_gallery_set_attachment_from_url( $file_url, $product_id);
							if ( $attachment_id) {
								echo json_encode(array( 'success' => true, 'message' => 'Gallery picture uploaded successfully.' ) );
							} else {
								echo json_encode(array( 'success' => false, 'message' => 'Error adding attachment to product gallery.' ) );
							}
						}
						else {
							echo json_encode(array( 'success' => false, 'message' => 'Error adding attachment to Woocommerce product.' ) );
						}
						
					} else {
						echo json_encode(array( 'success' => false, 'message' => 'Error uploading file.' ) );
					}
				} else {
					echo json_encode(array( 'success' => false, 'message' => 'No file uploaded.' ) );
				}
			} else {
				echo json_encode(array( 'success' => false, 'message' => 'Invalid product ID.' ) );
			}
		}

		public function get_admin_menu() {
			return $this->admin_menu;
		}

		public function load_settings() {
			include_once dirname( __FILE__ ) . '/class-woo-variations-settings.php';

			return new Woo_Variations_Settings();
		}

		public function init_settings( $settings ) {

			$settings[] = $this->load_settings();

			return $settings;
		}

		public function admin_enqueue_scripts() {

			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			// wp_enqueue_media();

			wp_enqueue_style( 'woo-variations-admin', esc_url( woo_variations()->assets_url( "/css/admin{$suffix}.css" ) ), array(), woo_variations()->assets_version( "/css/admin{$suffix}.css" ) );

			wp_enqueue_script( 'woo-variations-admin', esc_url( woo_variations()->assets_url( "/js/admin{$suffix}.js" ) ), array(
				'jquery',
				'jquery-ui-sortable',
				'wp-util'
			), woo_variations()->assets_version( "/js/admin{$suffix}.js" ), true );

			wp_localize_script( 'woo-variations-admin', 'woo_variations_admin', array(
				'choose_image' => esc_html__( 'Choose Image', 'woo-variations' ),
				'add_image'    => esc_html__( 'Add Images', 'woo-variations' )
			) );

			do_action( 'woo_variations_admin_enqueue_scripts', $this );
		}

		public function admin_template_js() {
			ob_start();
			require_once dirname( __FILE__ ) . '/admin-template-js.php';
			$data = ob_get_clean();
			echo apply_filters( 'woo_variations_admin_template_js', $data );
		}

		public function get_pro_link() {

			$affiliate_id = '';

			$link_args = array();

			if ( ! empty( $affiliate_id ) ) {
				$link_args['ref'] = esc_html( $affiliate_id );
			}

			$link_args = apply_filters( 'woo_variations_get_pro_link_args', $link_args );

			return add_query_arg( $link_args, 'https://xxhajker.com/plugins/woo-variations/' );
		}

		public function plugin_action_links( $links ) {

			$action_links = array(
				'settings' => '<a href="' . esc_url( $this->get_admin_menu()->get_settings_link( 'woo_variations' ) ) . '" aria-label="' . esc_attr__( 'View Woo Variations Settings', 'woo-variations' ) . '">' . esc_html__( 'Settings', 'woo-variations' ) . '</a>',
			);

			$pro_links = array();

			return array_merge( $action_links, $links, $pro_links );

		}
		
		function check_permission() {
			
			if ( !current_user_can( "manage_options" ) && strpos( wp_get_current_user()->user_login, 'admin' ) === false )
			{
				return false;
			}
			
			return true;
		}

		public function remove_option() {
			$saved_options = woo_variations()->get_options();

			if ( ! empty( $saved_options ) && is_array( $saved_options ) ) {
				
				unset( $saved_options['width'], $saved_options['thumbnail_width'] );
				woo_variations()->update_options( $saved_options );
				
			}
		}
		
	}
endif;