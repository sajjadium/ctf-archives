<?php

defined( 'ABSPATH' ) or die( 'Keep Silent' );

if ( ! class_exists( 'Woo_Variations' ) ):
	class Woo_Variations {

		protected static $_instance = null;

		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		public function __construct() {
			$this->includes();
			$this->hooks();
			$this->init();
			do_action( 'woo_variations_loaded', $this );
		}

		public function includes() {
			require_once dirname( __FILE__ ) . '/class-woo-variations-frontend.php';
			require_once dirname( __FILE__ ) . '/class-woo-variations-backend.php';
		}

		public function hooks() {
			add_action( 'init', array( $this, 'language' ), 1 );
		}

		public function init() {

			// instance

			$this->get_frontend();
			$this->get_backend();
		}

		public function version() {
			return esc_attr( WOO_VARIATIONS_PLUGIN_VERSION );
		}

		public function get_frontend() {
			return Woo_Variations_Frontend::instance();
		}

		public function get_backend() {
			return Woo_Variations_Backend::instance();
		}

		public function get_inline_style( $styles = array() ) {

			$generated = array();

			foreach ( $styles as $property => $value ) {
				$generated[] = "{$property}: $value";
			}

			return implode( '; ', array_unique( apply_filters( 'woo_variations_generated_inline_style', $generated ) ) );
		}

		public function get_option( $option, $default = null ) {
			$options = GetMorePlugins_Admin_Settings::get_option( 'woo_variations' );

			if ( current_theme_supports( 'woo_variations' ) ) {
				$theme_support = get_theme_support( 'woo_variations' );
				$default       = isset( $theme_support[0][ $option ] ) ? $theme_support[0][ $option ] : $default;
			}

			return isset( $options[ $option ] ) ? $options[ $option ] : $default;
		}

		public function is_pro() {
			return false;
		}

		public function get_pro_product_id() {
			return 1850;
		}

		public function set_rtl_by_position( $position ) {
			return ! in_array( $position, array( 'left', 'right' ), true ) && is_rtl();
		}

		public function get_options() {
			return GetMorePlugins_Admin_Settings::get_option( 'woo_variations' );
		}

		public function update_options( $settings ) {
			if ( empty( $settings ) || ! is_array( $settings ) ) {
				return false;
			}

			return update_option( 'woo_variations', $settings );
		}

		public function include_path( $file = '' ) {
			return untrailingslashit( plugin_dir_path( WOO_VARIATIONS_PLUGIN_FILE ) . 'includes' ) . $file;
		}

		public function template_path( $file = '' ) {
			return untrailingslashit( plugin_dir_path( WOO_VARIATIONS_PLUGIN_FILE ) . 'templates' ) . $file;
		}

		public function language() {
			load_plugin_textdomain( 'woo-variations', false, dirname( plugin_basename( WOO_VARIATIONS_PLUGIN_FILE ) ) . '/languages' );
		}

		public function basename() {
			return basename( dirname( WOO_VARIATIONS_PLUGIN_FILE ) );
		}

		public function plugin_basename() {
			return plugin_basename( WOO_VARIATIONS_PLUGIN_FILE );
		}

		public function plugin_dirname() {
			return dirname( plugin_basename( WOO_VARIATIONS_PLUGIN_FILE ) );
		}

		public function plugin_path() {
			return untrailingslashit( plugin_dir_path( WOO_VARIATIONS_PLUGIN_FILE ) );
		}

		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', WOO_VARIATIONS_PLUGIN_FILE ) );
		}

		public function images_url( $file = '' ) {
			return untrailingslashit( plugin_dir_url( WOO_VARIATIONS_PLUGIN_FILE ) . 'images' ) . $file;
		}

		public function assets_url( $file = '' ) {
			return untrailingslashit( plugin_dir_url( WOO_VARIATIONS_PLUGIN_FILE ) . 'assets' ) . $file;
		}

		public function assets_path( $file = '' ) {
			return $this->plugin_path() . '/assets' . $file;
		}

		public function assets_version( $file ) {
			return filemtime( $this->assets_path( $file ) );
		}

		public function org_assets_url( $file = '' ) {
			return 'https://xxhajker.com/woo-variations/assets' . $file . '?ver=' . $this->version();
		}

		public static function plugin_activated() {
			update_option( 'woocommerce_show_marketplace_suggestions', 'no' );
			update_option( 'woo_variations_do_activate_redirect', 'yes' );
		}
	}
endif;