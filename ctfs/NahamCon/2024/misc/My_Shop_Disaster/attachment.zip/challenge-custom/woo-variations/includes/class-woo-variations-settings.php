<?php

defined( 'ABSPATH' ) or die( 'Keep Quit' );

if ( ! class_exists( 'Woo_Variations_Settings', false ) ):

	class Woo_Variations_Settings extends GetMorePlugins_Settings_Page {

		public function __construct() {
			$this->notices();
			$this->hooks();
			parent::__construct();
		}

		public function get_id() {
			return 'woo_variations';
		}

		public function get_label() {
			return esc_html__( 'Variation Gallery', 'woo-variations' );
		}

		public function get_menu_name() {
			return esc_html__( 'Woo Variations Settings', 'woo-variations' );
		}

		public function get_title() {
			return esc_html__( 'Woo Variations Settings', 'woo-variations' );
		}

		protected function hooks() {
			add_action( 'getmoreplugins_after_delete_options', array( $this, 'delete_old_option_data' ) );
			add_action( 'getmoreplugins_sidebar', array( $this, 'sidebar' ) );
			add_filter( 'show_getmoreplugins_save_button', array( $this, 'show_save_button' ), 10, 3 );
			add_filter( 'show_getmoreplugins_sidebar', array( $this, 'show_sidebar' ), 10, 3 );
		}

		public function show_save_button( $default, $current_tab, $current_section ) {
			if ( $current_tab === $this->get_id() && in_array( $current_section, array( 'tutorial', 'migration' ) ) ) {
				return false;
			}

			return $default;
		}

		public function show_sidebar( $default, $current_tab, $current_section ) {
			if ( $current_tab === $this->get_id() && in_array( $current_section, array( 'tutorial' ) ) ) {
				return false;
			}

			return $default;
		}

		public function sidebar( $current_tab ) {
			if ( $current_tab === $this->get_id() ) {
				include_once dirname( __FILE__ ) . '/html-settings-sidebar.php';
			}
		}

		protected function notices() {
			// phpcs:disable WordPress.Security.NonceVerification.Recommended

			if ( $this->is_current_tab() && isset( $_GET['reset'] ) ) { // WPCS: input var okay, CSRF ok.
				GetMorePlugins_Admin_Settings::add_message( __( 'Woo Variations Settings reset.', 'woo-variations' ) );
			}

			// phpcs:enable
		}

		public function delete_old_option_data() {

			delete_option( 'woo_variations_thumbnails_columns' );
			delete_option( 'woo_variations_thumbnails_gap' );
			delete_option( 'woo_variations_width' );
			delete_option( 'woo_variations_medium_device_width' );
			delete_option( 'woo_variations_small_device_width' );
			delete_option( 'woo_variations_small_device_clear_float' );
			delete_option( 'woo_variations_extra_small_device_width' );
			delete_option( 'woo_variations_extra_small_device_clear_float' );
			delete_option( 'woo_variations_margin' );
			delete_option( 'woo_variations_preloader_disable' );
			delete_option( 'woo_variations_preload_style' );
			delete_option( 'woo_variations_slider_autoplay' );
			delete_option( 'woo_variations_slider_autoplay_speed' );
			delete_option( 'woo_variations_slide_speed' );
			delete_option( 'woo_variations_slider_fade' );
			delete_option( 'woo_variations_slider_arrow' );
			delete_option( 'woo_variations_zoom' );
			delete_option( 'woo_variations_lightbox' );
			delete_option( 'woo_variations_thumbnail_slide' );
			delete_option( 'woo_variations_thumbnail_arrow' );
			delete_option( 'woo_variations_zoom_position' );
			delete_option( 'woo_variations_thumbnail_position' );
			delete_option( 'woo_variations_remove_featured_image' );
			delete_option( 'woo_variations_disabled_product_type' );
			delete_option( 'woo_variations_thumbnail_width' );
			delete_option( 'woo_variations_reset_on_variation_change' );
			delete_option( 'woo_variations_image_preload' );
		}

		/**
		 * Output the settings.
		 */
		public function output( $current_tab ) {
			global $current_section;

			if ( $current_tab === $this->get_id() && 'tutorial' === $current_section ) {
				$this->tutorial_section( $current_section );
			} elseif ( $current_tab === $this->get_id() && 'migration' === $current_section ) {
				$this->migration_section( $current_section );
			} else {
				parent::output( $current_tab );
			}
		}

		public function tutorial_section( $current_section ) {
			ob_start();
			$settings = $this->get_settings( $current_section );
			echo ob_get_clean();
		}

		public function migration_section( $current_section ) {
			ob_start();
			$settings = $this->get_settings( $current_section );
			echo ob_get_clean();
		}

		public function get_all_image_sizes() {

			$image_subsizes = wp_get_registered_image_subsizes();

			return apply_filters( 'woo_variations_get_all_image_sizes', array_reduce( array_keys( $image_subsizes ), function ( $carry, $item ) use ( $image_subsizes ) {

				$title  = ucwords( str_ireplace( array( '-', '_' ), ' ', $item ) );
				$width  = $image_subsizes[ $item ]['width'];
				$height = $image_subsizes[ $item ]['height'];

				$carry[ $item ] = sprintf( '%s (%d &times; %d)', $title, $width, $height );

				return $carry;
			}, array() ) );
		}

		public function plugins_tab( $label ) {
			return sprintf( '<span class="getmoreplugins-recommended-plugins-tab dashicons dashicons-admin-plugins"></span> <span>%s</span>', $label );
		}

		protected function get_own_sections() {
			$sections = array(
				''          => esc_html__( 'General', 'woo-variations' ),
				'configure' => esc_html__( 'Configuration', 'woo-variations' ),
				'advanced'  => esc_html__( 'Advanced', 'woo-variations' )
			);

			return $sections;
		}

		protected function get_settings_for_default_section() {

			$settings = array(

				// Thumbnails Section Start
				array(
					'name' => esc_html__( 'Thumbnail Options', 'woo-variations' ),
					'type' => 'title',
					'desc' => '',
					'id'   => 'thumbnail_options',
				),

				// Thumbnails Item
				array(
					'title'             => esc_html__( 'Thumbnails Item', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_default_thumbnails_columns', 4 ) ),
					'css'               => 'width:50px;',
					'desc_tip'          => esc_html__( 'Product Thumbnails Item Image', 'woo-variations' ),
					'desc'              => sprintf( esc_html__( 'Product Thumbnails Item Image. Default value is: %d. Limit: 2-8.', 'woo-variations' ), absint( apply_filters( 'woo_variations_default_thumbnails_columns', 4 ) ) ),
					'id'                => 'thumbnails_columns',
					'custom_attributes' => array(
						'min'  => 2,
						'max'  => 8,
						'step' => 1,
					),
				),

				// Thumbnails Gap
				array(
					'title'             => esc_html__( 'Thumbnails Gap', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_default_thumbnails_gap', 0 ) ),
					'css'               => 'width:50px;',
					'suffix'            => 'px',
					'desc_tip'          => esc_html__( 'Product Thumbnails Gap In Pixel', 'woo-variations' ),
					'desc'              => sprintf( esc_html__( 'Product Thumbnails Gap In Pixel. Default value is: %d. Limit: 0-20.', 'woo-variations' ), apply_filters( 'woo_variations_default_thumbnails_gap', 0 ) ),
					'id'                => 'thumbnails_gap',
					'custom_attributes' => array(
						'min'  => 0,
						'max'  => 20,
						'step' => 1,
					),
				),

				// Section End
				array(
					'type' => 'sectionend',
					'id'   => 'thumbnail_options'
				),

				// Gallery Section Start
				array(
					'name' => esc_html__( 'Gallery Options', 'woo-variations' ),
					'type' => 'title',
					'desc' => '',
					'id'   => 'main_options',
				),

				// Default Gallery Width
				array(
					'title'             => esc_html__( 'Gallery Width', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_default_width', 30 ) ),
					'css'               => 'width:60px;',
					'suffix'            => '%',
					'desc_tip'          => esc_html__( 'Slider gallery width in % for large devices.', 'woo-variations' ),
					'desc'              => sprintf( __( 'Slider Gallery Width in %%. Default value is: %d. Limit: 10-100. Please check this <a target="_blank" href="%s">how to video to configure it.</a>', 'woo-variations' ), absint( apply_filters( 'woo_variations_default_width', 30 ) ), '' ),
					'id'                => 'width',
					'custom_attributes' => array(
						'min'  => 10,
						'max'  => 100,
						'step' => 1,
					),
				),

				// Medium Devices, Desktop
				array(
					'title'             => esc_html__( 'Gallery Width', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_medium_device_width', 0 ) ),
					'css'               => 'width:60px;',
					'prefix-icon'       => 'dashicons dashicons-desktop',
					'suffix'            => 'px',
					'desc_tip'          => esc_html__( 'Slider gallery width in px for medium devices, small desktop', 'woo-variations' ),
					'desc'              => esc_html__( 'Slider gallery width in pixel for medium devices, small desktop. Default value is: 0. Limit: 0-1000. Media query (max-width : 992px)', 'woo-variations' ),
					'id'                => 'medium_device_width',
					'custom_attributes' => array(
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					),
				),

				// Small Devices, Tablets
				array(
					'title'             => esc_html__( 'Gallery Width', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_small_device_width', 720 ) ),
					'css'               => 'width:60px;',
					'prefix-icon'       => 'dashicons dashicons-tablet',
					'suffix'            => 'px',
					'desc_tip'          => esc_html__( 'Slider gallery width in px for small devices, tablets', 'woo-variations' ),
					'desc'              => esc_html__( 'Slider gallery width in pixel for medium devices, small desktop. Default value is: 720. Limit: 0-1000. Media query (max-width : 768px)', 'woo-variations' ),
					'id'                => 'small_device_width',
					'custom_attributes' => array(
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					),
				),

				// Clear float for Small Devices, Tablets
				array(
					'title'   => esc_html__( 'Clear float', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Clear float for small devices, tablets.', 'woo-variations' ),
					'id'      => 'small_device_clear_float'
				),

				// Extra Small Devices, Phones
				array(
					'title'             => esc_html__( 'Gallery Width', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_extra_small_device_width', 320 ) ),
					'css'               => 'width:60px;',
					'prefix-icon'       => 'dashicons dashicons-smartphone',
					'suffix'            => 'px',
					'desc_tip'          => esc_html__( 'Slider gallery width in px for extra small devices, phones', 'woo-variations' ),
					'desc'              => esc_html__( 'Slider gallery width in pixel for extra small devices, phones. Default value is: 320. Limit: 0-1000. Media query (max-width : 480px)', 'woo-variations' ),
					'id'                => 'extra_small_device_width',
					'custom_attributes' => array(
						'min'  => 0,
						'max'  => 1000,
						'step' => 1,
					),
				),

				// Clear float for Extra Small Devices, Phones
				array(
					'title'   => esc_html__( 'Clear float', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Clear float for extra small devices, mobile.', 'woo-variations' ),
					'id'      => 'extra_small_device_clear_float'
				),

				// Gallery Bottom GAP
				array(
					'title'             => esc_html__( 'Gallery Bottom Gap', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( apply_filters( 'woo_variations_default_margin', 30 ) ),
					'css'               => 'width:60px;',
					'desc_tip'          => esc_html__( 'Slider gallery bottom margin in pixel', 'woo-variations' ),
					'suffix'            => 'px',
					'desc'              => sprintf( esc_html__( 'Slider gallery bottom margin in pixel. Default value is: %d. Limit: 10-100.', 'woo-variations' ), apply_filters( 'woo_variations_default_margin', 30 ) ),
					'id'                => 'margin',
					'custom_attributes' => array(
						'min'  => 10,
						'max'  => 100,
						'step' => 1,
					),
				),

				// Disable Preloader
				array(
					'title'   => esc_html__( 'Disable Preloader', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Disable preloader on loading variation images', 'woo-variations' ),
					'id'      => 'preloader_disable'
				),

				// Preload Style
				array(
					'title'   => esc_html__( 'Preload Style', 'woo-variations' ),
					'type'    => 'select',
					'class'   => 'wc-enhanced-select',
					'default' => 'blur',
					'id'      => 'preload_style',
					'require' => $this->normalize_required_attribute( array( 'preloader_disable' => array( 'type' => 'empty' ) ) ),
					'options' => array(
						'fade' => esc_html__( 'Fade', 'woo-variations' ),
						'blur' => esc_html__( 'Blur', 'woo-variations' ),
						'gray' => esc_html__( 'Gray', 'woo-variations' ),
					)
				),


				// End
				array(
					'type' => 'sectionend',
					'id'   => 'main_options'
				),
			);

			return $settings;
		}

		protected function get_settings_for_configure_section() {

			$settings = array(

				array(
					'name' => esc_html__( 'Gallery Configure', 'woo-variations' ),
					'type' => 'title',
					'desc' => '',
					'id'   => 'configure_settings',
				),

				array(
					'title'   => esc_html__( 'Gallery Auto play', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Gallery Auto Slide / Auto Play', 'woo-variations' ),
					'id'      => 'slider_autoplay'
				),

				array(
					'title'             => esc_html__( 'Gallery Auto Play Speed', 'woo-variations' ),
					'type'              => 'number',
					'default'           => 5000,
					'css'               => 'width:70px;',
					'suffix'            => 'milliseconds',
					'desc'              => esc_html__( 'Slider gallery autoplay speed. Default is 5000 means 5 seconds', 'woo-variations' ),
					'id'                => 'slider_autoplay_speed',
					'require'           => $this->normalize_required_attribute( array( 'slider_autoplay' => array( 'type' => '!empty' ) ) ),
					'custom_attributes' => array(
						'min'  => 500,
						'max'  => 10000,
						'step' => 500,
					),
				),

				array(
					'title'             => esc_html__( 'Gallery Slide / Fade Speed', 'woo-variations' ),
					'type'              => 'number',
					'default'           => 300,
					'suffix'            => 'milliseconds',
					'css'               => 'width:60px;',
					'desc'              => esc_html__( 'Gallery sliding speed. Default is 300 means 300 milliseconds', 'woo-variations' ),
					'id'                => 'slide_speed',
					'custom_attributes' => array(
						'min'  => 100,
						'max'  => 1000,
						'step' => 100,
					),
				),

				array(
					'title'   => esc_html__( 'Fade Slide', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Gallery will change by fade not slide', 'woo-variations' ),
					'id'      => 'slider_fade'
				),

				array(
					'title'   => esc_html__( 'Show Slider Arrow', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Show Gallery Slider Arrow', 'woo-variations' ),
					'id'      => 'slider_arrow'
				),

				array(
					'title'   => esc_html__( 'Enable Image Zoom', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Enable Gallery Image Zoom', 'woo-variations' ),
					'id'      => 'zoom'
				),

				array(
					'title'   => esc_html__( 'Enable Image Popup', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Enable Gallery Image Popup', 'woo-variations' ),
					'id'      => 'lightbox'
				),

				array(
					'title'   => esc_html__( 'Enable Thumbnail Slide', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Enable Gallery Thumbnail Slide', 'woo-variations' ),
					'id'      => 'thumbnail_slide'
				),

				array(
					'title'   => esc_html__( 'Show Thumbnail Arrow', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Show Gallery Thumbnail Arrow', 'woo-variations' ),
					'id'      => 'thumbnail_arrow'
				),

				array(
					'title'    => esc_html__( 'Zoom Icon Display Position', 'woo-variations' ),
					'id'       => 'zoom_position',
					'default'  => 'top-right',
					//'type'     => 'radio',
					'type'     => 'select',
					'class'    => 'wc-enhanced-select',
					'desc_tip' => esc_html__( 'Product Gallery Zoom Icon Display Position', 'woo-variations' ),
					'options'  => array(
						'top-right'    => esc_html__( 'Top Right', 'woo-variations' ),
						'top-left'     => esc_html__( 'Top Left', 'woo-variations' ),
						'bottom-right' => esc_html__( 'Bottom Right', 'woo-variations' ),
						'bottom-left'  => esc_html__( 'Bottom Left', 'woo-variations' ),
					),
				),

				array(
					'title'   => esc_html__( 'Thumbnail Display Position', 'woo-variations' ),
					'id'      => 'thumbnail_position',
					'default' => 'bottom',
					//'type'     => 'radio',
					'type'    => 'select',
					'class'   => 'wc-enhanced-select',
					'desc'    => esc_html__( 'Product Gallery Thumbnail Display Position', 'woo-variations' ),
					'options' => array(
						'left'   => esc_html__( 'Left', 'woo-variations' ),
						'right'  => esc_html__( 'Right', 'woo-variations' ),
						'bottom' => esc_html__( 'Bottom', 'woo-variations' ),
					),
				),

				array(
					'title'   => esc_html__( 'Small Devices Thumbnail Position', 'woo-variations' ),
					'id'      => 'thumbnail_position_small_device',
					'default' => 'bottom',
					//'type'     => 'radio',
					'type'    => 'select',
					'class'   => 'wc-enhanced-select',
					'desc'    => esc_html__( 'Product Gallery Thumbnail Display Position for Small Devices. Below 768px', 'woo-variations' ),
					'options' => array(
						'left'   => esc_html__( 'Left', 'woo-variations' ),
						'right'  => esc_html__( 'Right', 'woo-variations' ),
						'bottom' => esc_html__( 'Bottom', 'woo-variations' ),
					),
				),

				array(
					'type' => 'sectionend',
					'id'   => 'configure_settings'
				),
			);

			return $settings;
		}

		protected function get_settings_for_advanced_section() {
			$settings = array(

				array(
					'name'  => esc_html__( 'Advanced Options', 'woo-variations' ),
					'type'  => 'title',
					'desc'  => '',
					'class' => 'woo-variations-options',
					'id'    => 'advanced_options',
				),

				// Hide default featured image
				array(
					'title'   => esc_html__( 'Hide Main Product Image', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Remove main product image from gallery', 'woo-variations' ),
					'id'      => 'remove_featured_image'
				),

				// Disable on Specific Product type
				array(
					'title'             => esc_html__( 'Disable on Product Type', 'woo-variations' ),
					'type'              => 'multiselect',
					'options'           => wc_get_product_types(),
					'class'             => 'wc-enhanced-select',
					'default'           => array( 'gift-card', 'bundle' ),
					'desc_tip'          => esc_html__( 'Disable Gallery on Specific Product type like: simple product / variable product / bundle product etc.', 'woo-variations' ),
					'id'                => 'disabled_product_type',
					'custom_attributes' => array(
						'data-placeholder' => esc_html__( 'Choose specific product type(s).', 'woo-variations' ),
					)
				),

				// Thumbnails Image Width
				array(
					'title'             => esc_html__( 'Gallery Thumbnails Image Width', 'woo-variations' ),
					'type'              => 'number',
					'default'           => absint( wc_get_theme_support( 'gallery_thumbnail_image_width', 100 ) ),
					'css'               => 'width:65px;',
					'suffix'            => 'px',
					'desc_tip'          => esc_html__( 'Product Gallery Thumbnails Image Width In Pixel to fix blurry thumbnail image.', 'woo-variations' ),
					'desc'              => sprintf( esc_html__( 'Product Gallery Thumbnails Image Width In Pixel to fix blurry thumbnail image. Default value is: %1$d. Limit: 80-300. %2$sRecommended: To Regenerate shop thumbnails after change this setting.%3$s', 'woo-variations' ),
						absint( wc_get_theme_support( 'gallery_thumbnail_image_width', 100 ) ),
						sprintf( '<br /><a target="_blank" href="%s">', esc_url( wp_nonce_url( admin_url( 'admin.php?page=wc-status&tab=tools&action=regenerate_thumbnails' ), 'debug_action' ) ) ),
						'</a>'
					),
					'id'                => 'thumbnail_width',
					'custom_attributes' => array(
						'min'  => 80,
						'max'  => 300,
						'step' => 5,
					),
				),

				// Reset Variation Gallery
				array(
					'title'   => esc_html__( 'Reset Variation Gallery', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Always Reset Gallery After Variation Select', 'woo-variations' ),
					'id'      => 'reset_on_variation_change'
				),

				// Gallery Image Preload
				array(
					'title'   => esc_html__( 'Gallery Image Preload', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'yes',
					'desc'    => esc_html__( 'Variation Gallery Image Preload', 'woo-variations' ),
					'id'      => 'image_preload'
				),
				// Add Product Gallery on Variation Images
				array(
					'title'   => esc_html__( 'Show Default Gallery Image', 'woo-variations' ),
					'type'    => 'checkbox',
					'default' => 'no',
					'desc'    => esc_html__( 'Show Variation Gallery image with default gallery image', 'woo-variations' ),
					'id'      => 'include_default_gallery',
					'is_new'=>true
				),

				array(
					'type' => 'sectionend',
					'id'   => 'advanced_options'
				),
			);

			return $settings;
		}
	}
endif;