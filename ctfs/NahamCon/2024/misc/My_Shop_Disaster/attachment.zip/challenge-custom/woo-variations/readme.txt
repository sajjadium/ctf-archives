/**
 * Plugin Name: Woo Variations
 * Description: Multipurpose plugin to help enhancing store general settings and products variations.
 * Author: GetMorePlugins
 * Version: 1.0.2
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.7
 * Tested up to: 6.5
 * WC requires at least: 5.8
 * WC tested up to: 8.7
 * Requires Plugins: woocommerce
 */