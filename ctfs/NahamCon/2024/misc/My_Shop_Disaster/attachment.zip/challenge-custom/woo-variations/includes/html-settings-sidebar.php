<?php
defined( 'ABSPATH' ) or die( 'Keep Quit' );
?>

<div>
	<h3>
		<span class="dashicons dashicons-media-document"></span> <?php esc_html_e( 'Documentation', 'woo-variations' ) ?>
	</h3>
	<p><?php esc_html_e( 'Get started by spending some time with the', 'woo-variations' ) ?>
		<a target="_blank" href="https://xxhajker.com/documentation/woo-variations/"><?php esc_html_e( 'documentation.', 'woo-variations' ) ?></a>
	</p>
</div>
<div>
	<h3>
		<span class="dashicons dashicons-editor-help"></span> <?php esc_html_e( 'Facing issue?', 'woo-variations' ) ?>
	</h3>
	<p><?php esc_html_e( 'Stuck with something?', 'woo-variations' ) ?>
		<a target="_blank" href="https://xxhajker.com/tickets/"><?php esc_html_e( 'Please open a ticket.', 'woo-variations' ) ?></a> <?php esc_html_e( 'For emergency case join our live chat.', 'woo-variations' ) ?>
	</p>
</div>
<div>
	<h3>
		<span class="dashicons dashicons-star-filled"></span> <?php esc_html_e( 'Love Our Plugin?', 'woo-variations' ) ?>
	</h3>
	<p><?php esc_html_e( 'Thank you for choosing', 'woo-variations' ) ?> <strong><?php esc_html_e( 'Woo Variations', 'woo-variations' ) ?></strong>. <?php esc_html_e( 'If you have found our plugin useful and makes you smile,', 'woo-variations' ) ?>
		<a target="_blank" href="https://xxhajker.com/plugins/woo-variations/"><?php esc_html_e( 'please consider giving us a 5-star rating.', 'woo-variations' ) ?></a> <?php esc_html_e( 'It will help us to grow.', 'woo-variations' ) ?>
	</p>
</div>
