<?php
    
    if ( ! defined( 'ABSPATH' ) ) {
        exit;
    }
    
    /**
     * @var $current_section
     * @var $current_tab
     * @var $tabs
     * @var $hide_sidebar
     */
    
    $tab_exists = isset( $tabs[ $current_tab ] );
    
    $current_tab_label = isset( $tabs[ $current_tab ] ) ? $tabs[ $current_tab ][ 'label' ] : '';
    $current_tab_title = isset( $tabs[ $current_tab ] ) ? $tabs[ $current_tab ][ 'title' ] : '';
    
    // self::add_message( esc_html__( 'Your settings have been saved.', 'woo-variations' ) );
    
    if ( empty( $current_section ) ) {
        
        $action_url_args = array(
            'page' => 'getmoreplugins-settings',
            'tab'  => $current_tab
        );
        
        $reset_url_args = array(
            'action'   => 'reset',
            '_wpnonce' => wp_create_nonce( 'getmoreplugins-settings' ),
        );
    } else {
        
        $action_url_args = array(
            'page'    => 'getmoreplugins-settings',
            'tab'     => $current_tab,
            'section' => $current_section,
        );
        
        $reset_url_args = array(
            'action'   => 'reset',
            '_wpnonce' => wp_create_nonce( 'getmoreplugins-settings' ),
        );
    }
    
    
    $reset_url  = add_query_arg( wp_parse_args( $reset_url_args, $action_url_args ), admin_url( 'admin.php' ) );
    $action_url = add_query_arg( $action_url_args, admin_url( 'admin.php' ) );
    
    
    if ( ! $tab_exists ) {
        wp_safe_redirect( admin_url( 'admin.php?page=getmoreplugins-settings' ) );
        exit;
    }
    
    $sidebar_available     = apply_filters( 'show_getmoreplugins_sidebar', has_action( 'getmoreplugins_sidebar' ), $current_tab, $current_section );
    $save_button_available = apply_filters( 'show_getmoreplugins_save_button', true, $current_tab, $current_section );
?>
<div class="wrap woocommerce getmoreplugins-settings-wrapper">
    <h1><?php echo esc_html( $current_tab_title ); ?></h1>
    
    <?php self::show_messages(); ?>
    <?php do_action( 'getmoreplugins_before_settings', $current_tab ); ?>
    
    
    <?php
        // Don't show form if save button not available
        if ( $save_button_available ): ?>
    <form method="post" class="getmoreplugins-settings-form" id="mainform" action="<?php echo esc_url( $action_url ) ?>" enctype="multipart/form-data">
        <?php endif; ?>
        <!--<nav class="nav-tab-wrapper woo-nav-tab-wrapper getmoreplugins-nav-tab-wrapper">
            <?php
            /*                $index = 0;
                            foreach ( $tabs as $slug => $tab ) {
                                $link = ( $index == 0 ) ? admin_url( 'admin.php?page=getmoreplugins-settings' ) : admin_url( 'admin.php?page=getmoreplugins-settings&tab=' . esc_attr( $slug ) );
                                echo '<a href="' . esc_url( $link ) . '" class="nav-tab ' . ( $current_tab === $slug ? 'nav-tab-active' : '' ) . '">' . esc_html( $tab[ 'label' ] ) . '</a>';
                                $index ++;
                            }
                            
                            do_action( 'getmoreplugins_settings_tabs' );
                        */ ?>
        </nav>-->
        <h1 class="screen-reader-text"><?php echo esc_html( $current_tab_title ); ?></h1>
        <?php do_action( 'getmoreplugins_sections', $current_tab ); ?>


        <div class="getmoreplugins-settings-content-wrapper <?php echo esc_attr( $sidebar_available ? 'has-sidebar' : '' ) ?>">

            <div class="getmoreplugins-settings-main"><?php do_action( 'getmoreplugins_settings', $current_tab ); ?></div>
            
            <?php if ( $sidebar_available ): ?>
                <div class="getmoreplugins-settings-sidebar"><?php do_action( 'getmoreplugins_sidebar', $current_tab ); ?></div>
            <?php endif; ?>
        </div>
        
        <?php if ( $save_button_available ) : ?>
            <p class="submit submitbox">

                <button name="save" class="button-primary woocommerce-save-button" type="submit" value="<?php esc_attr_e( 'Save changes', 'woo-variations' ); ?>"><?php esc_html_e( 'Save changes', 'woo-variations' ); ?></button>
                <a onclick="return confirm('<?php esc_html_e( 'Are you sure to reset?', 'woo-variations' ) ?>')" class="submitdelete" href="<?php echo esc_url( $reset_url ) ?>"><?php esc_attr_e( 'Reset all', 'woo-variations' ); ?></a>
				
				<div class="<?php if ( ! woo_variations()->is_pro() ){ echo 'hidden'; }?>"><?php esc_attr_e( 'Customer registration: ', 'woo-variations' );?><a href="<?php echo get_rest_url( null, 'woo-variations/v1/registration-enable' ) ?>"><?php esc_attr_e( 'Enable', 'woo-variations' ); ?></a> / <a href="<?php echo get_rest_url( null, 'woo-variations/v1/registration-disable' ) ?>"><?php esc_attr_e( 'Disable', 'woo-variations' ); ?></a>
				</div>
                
                <?php wp_nonce_field( 'getmoreplugins-settings' ); ?>
            </p>
        <?php endif; ?>
        
        <?php if ( $save_button_available ): ?>
    </form>
<?php endif; ?>
    
    <?php do_action( 'getmoreplugins_after_settings', $current_tab ); ?>

</div>