<?php
/**
 * Plugin Name: Woo Variations
 * Description: Multipurpose plugin to help enhancing store general settings and products variations.
 * Author: GetMorePlugins
 * Version: 1.0.2
 * Domain Path: /languages
 * Requires PHP: 7.4
 * Requires at least: 5.7
 * Tested up to: 6.5
 * WC requires at least: 5.8
 * WC tested up to: 8.7
 * Requires Plugins: woocommerce
 */

defined( 'ABSPATH' ) or die( 'Keep Silent' );

if ( ! defined( 'WOO_VARIATIONS_PLUGIN_FILE' ) ) {
	define( 'WOO_VARIATIONS_PLUGIN_FILE', __FILE__ );
}

if ( ! defined( 'WOO_VARIATIONS_PLUGIN_VERSION' ) ) {
	define( 'WOO_VARIATIONS_PLUGIN_VERSION', '1.3.22' );
}

// Include the main class.
if ( ! class_exists( 'Woo_Variations', false ) ) {
	require_once dirname( __FILE__ ) . '/includes/class-woo-variations.php';
}

// Require woocommerce admin message
function woo_variations_wc_requirement_notice() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		$text    = esc_html__( 'WooCommerce', 'woo-variations' );
		$link    = esc_url( add_query_arg( array(
			'tab'       => 'plugin-information',
			'plugin'    => 'woocommerce',
			'TB_iframe' => 'true',
			'width'     => '640',
			'height'    => '500',
		), admin_url( 'plugin-install.php' ) ) );
		$message = wp_kses( __( "<strong>Woo Variations</strong> is an add-on of ", 'woo-variations' ), array( 'strong' => array() ) );

		printf( '<div class="%1$s"><p>%2$s <a class="thickbox open-plugin-details-modal" href="%3$s"><strong>%4$s</strong></a></p></div>', 'notice notice-error', $message, $link, $text );
	}
}

add_action( 'admin_notices', 'woo_variations_wc_requirement_notice' );

/**
 * Returns the main instance.
 */

function woo_variations() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid

	if ( ! class_exists( 'WooCommerce', false ) ) {
		return false;
	}

	return Woo_Variations::instance();
}

add_action( 'plugins_loaded', 'woo_variations' );

// Supporting WooCommerce High-Performance Order Storage
function woo_variations_hpos_compatibility() {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
}

add_action( 'before_woocommerce_init', 'woo_variations_hpos_compatibility' );

register_activation_hook( __FILE__, array( 'Woo_Variations', 'plugin_activated' ) );
