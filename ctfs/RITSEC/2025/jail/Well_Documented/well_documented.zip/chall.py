import ast, sys

class Meow:
    """
this class exists as a helper for this challenge.
it sanitizes a user input safely so that later when the program attempts safely running it,
ideally it's hard for the remote user to gain code execution.

the __init__ function takes user_input as a single string argument and then makes member __user_input  
and assigns it to its value. 

the user_input string argument is checked against __ALLOW__NODES and the __BANNED_CHARS array to
make sure it doesnt have anything potentially nefarious

there are a fairly wide array of nodes and chars banned. this is to prevent weird operations, examples
including importing modules, executing arbitrary code, and recovering built-in functions.

along with checking to make sure no banned nodes or characters are used, it also verifies that
only a certain number of various nodes and special characters are used. this is, again, to make it as hard
as possible to abuse.

only ascii letters are allowed to prevent abusing python's unicode normalization to get around the character filters

the user input is also limited in length to prevent unforseen issues

after being parsed and validated, the code is compiled and run using eval. the output is not shown
back to the user.
    """
    __slots__ = ['__user_input', '__code', '__ALLOW__NODES', '__BANNED_CHARS', '__MAX_CHARS']

    def __init__(self, user_input: str) -> None:
        self.__user_input = user_input
        self.__ALLOW__NODES = { ast.BinOp: 32,  ast.DictComp: 5,   ast.Constant: 4,  ast.FloorDiv: 7, 
                                ast.USub: 20,   ast.Invert: 3,     ast.List: 16,     ast.UnaryOp: 19, 
                                ast.Sub: 24,    ast.ClassDef: 3,   ast.Load: 92,     ast.Name: 70,
                                ast.BitXor: 18, ast.NamedExpr: 10, ast.Slice: 5,     ast.Compare: 6,
                                ast.Module: 1,  ast.Store: 10,     ast.Expr: 1,      ast.Attribute: 11,
                                ast.Lt: 6,      ast.Lambda: 3,     ast.Call: 4,      ast.Tuple: 8, 
                                ast.Global: 2,  ast.Del: 20,       ast.Subscript: 8, ast.Mult: 10 }
        self.__BANNED_CHARS = [c for c in "!\"#$%&'+/;>?@\^`ABCDEFGHIJKLMNOPQRSTUVWXYZghjkmpqrvwxyz{|}\n\r\t\x0b\x0c "]
        self.__MAX_CHARS = { '[': 23, ':': 20, '=': 10, '-': 37, '~': 43, '(': 8,
                             ']': 25, '<': 5,  ')': 9,  ',': 11, '*': 9, '.': 10, '_': 40 }
    
    def fail(self) -> None:
        print("no cheating >:3")
        exit(1)

    def validate(self) -> bool:
        tree = ast.parse(self.__user_input)
        nodes = list()
        for node in ast.walk(tree):
            if node_class := node.__class__ not in self.__ALLOW__NODES:
                self.fail()
            nodes.append(node_class)

        for node in self.__ALLOW__NODES:
            if nodes.count(node) > self.__ALLOW__NODES[node]:
                self.fail()

        if not self.__user_input.isascii():
            self.fail()

        for c in self.__user_input:
            if c in self.__BANNED_CHARS:
                self.fail()

        for c in self.__MAX_CHARS:
            if self.__user_input.count(c) > self.__MAX_CHARS[c]:
                self.fail()

        if len(self.__user_input) > 333:
            self.fail()

        self.__code = compile(self.__user_input, 'user_code', 'eval')
        return True
    
    def run(self):
        try:
            result = eval(self.__code, {'__builtins__': {}}, locals())
            return result
        except:
            return None


if __name__ == '__main__':
    m = Meow(input("code: "))

    sys.stdin = None

    if not m.validate():
        m.fail()

    m.run()