import sys

try:
    sys.modules['code'].interact()
    print("contact made!!!")
    exit(0)
except:
    pass

ALLOWED = "(celestial phenomenon)"

transmission = input("broadcast your cosmic message: ")

if any([c not in ALLOWED for c in transmission]) or len(transmission) > 32:
    print("your transmission was distorted by radiation interference")
    exit(1)

try:
    eval(transmission)
    print("the universe listens!")
except:
    print("your message vanished into a black hole")