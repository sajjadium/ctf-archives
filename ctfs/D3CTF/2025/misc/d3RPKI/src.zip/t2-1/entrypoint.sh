service ssh start
sleep 3
service bird start
sleep infinity