stayrtr -checktime=false -bind=:8083 -cache=/root/roa_stayrtr.json &
sleep 3
service bird start
sleep infinity