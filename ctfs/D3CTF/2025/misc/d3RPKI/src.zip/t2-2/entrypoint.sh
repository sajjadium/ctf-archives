sleep 3
service bird start

if [ -z "$FLAG" ]; then
    echo "error: flag not set"
    exit 1
fi

TARGET_IP="10.4.0.5"
TARGET_PORT="1234"

while true; do
    echo "$FLAG" | nc -w 3 "$TARGET_IP" "$TARGET_PORT"
    
    if [ $? -eq 0 ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] FLAG sent to $TARGET_IP:$TARGET_PORT"
    else
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] send fail"
    fi
    
    sleep 10 
done

sleep infinity