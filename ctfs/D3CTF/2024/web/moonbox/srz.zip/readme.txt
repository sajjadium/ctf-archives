https://github.com/vivo/MoonBox/blob/main/docker/docker-compose.yml
