package main

import (
	"crypto/hmac"
	"crypto/sha256"
	"fmt"
	"io"
	"log"
	"math/rand"
	"net"
	"os"
	"slices"
	"strings"
)

var msgs []string

var AuthKey = os.Getenv("authkey")
var GameKey = os.Getenv("gamekey")

func GenMsg() {
	fullMsg := strings.ReplaceAll(`Welcome to D^3CTF 2024, CTFers!
You may found a challenge called "O!!!SPF!!!!!!" in D^3CTF 2022.
Today, we enhanced the past challenge, make it more interesting but also harder.
Wish you to find out the small road to the flag and GOOD LUCK.
Also, salute Soha and his NewYear redbag again.`, "\n", "")
	for i := range len(fullMsg) {
		msgs = append(msgs, fullMsg[:i+1])
	}
}

func main() {
	GenMsg()
	listen, _ := net.ResolveTCPAddr("tcp", ":18080")
	l, err := net.ListenTCP("tcp", listen)
	if err != nil {
		log.Fatal(err)
	}
	for {
		c, err := l.Accept()
		fmt.Println("Accepted from", c.RemoteAddr())
		if err != nil {
			log.Println(err)
		}
		go handleConn(c)
	}
}

func handleConn(c net.Conn) {
	defer c.Close()

	// convince the client that we are the real server
	var challenge [32]byte
	_, err := io.ReadFull(c, challenge[:])
	if err != nil {
		log.Println(err)
		return
	}

	authSigner := hmac.New(sha256.New, []byte(AuthKey))
	authSigner.Write(challenge[:])

	if _, err := c.Write(append(authSigner.Sum(nil))); err != nil {
		log.Println(err)
		return
	}

	// game start message
	_, err = c.Write([]byte("I will send you messages, please reply me the salted hash for confirming. To Players: You are not supposed guess the salt.\n"))
	if err != nil {
		log.Println(err)
		return
	}

	// game loop
	for _, msg := range RandOrder(msgs) {
		_, err = c.Write([]byte(msg + "\n"))
		if err != nil {
			log.Println(err)
			return
		}

		var rec [32]byte
		_, err := io.ReadFull(c, rec[:])
		if err != nil {
			log.Println(err)
			return
		}

		if slices.Compare(rec[:], Sign([]byte(msg))) != 0 {
			_, err = c.Write([]byte("Wrong Hash\n"))
			if err != nil {
				log.Println(err)
				return
			}
		}
	}

	// game end message
	_, err = c.Write([]byte{'\n'})
	if err != nil {
		log.Println(err)
	}

	// game reward
	_, err = c.Write([]byte("Would you like to have a flag?(Y/N)\n"))
	if err != nil {
		log.Println(err)
		return
	}

	var getFlag [1]byte
	_, err = io.ReadFull(c, getFlag[:])
	if err != nil {
		if err != io.EOF {
			log.Println(err)
		}
		return
	}

	if getFlag[0] == 'Y' {
		_, err = c.Write([]byte(os.Getenv("flag")))
		if err != nil {
			log.Println(err)
			return
		}
	}
}

func Sign(s []byte) []byte {
	gameSigner := hmac.New(sha256.New, []byte(GameKey))
	gameSigner.Write(s[:])
	return gameSigner.Sum(nil)
}

func RandOrder[T any](arr []T) func(func(int, T) bool) {
	return func(yield func(int, T) bool) {
		arr2 := make([]int, len(arr))
		for i := range len(arr) {
			arr2[i] = i
		}
		rand.Shuffle(len(arr), func(i, j int) {
			arr2[i], arr2[j] = arr2[j], arr2[i]
		})
		for i, j := range arr2 {
			if !yield(i, arr[j]) {
				break
			}
		}
	}
}
