import { Address, beginCell, Cell, Contract, contractAddress, ContractProvider, Sender, SendMode, Dictionary } from '@ton/core';

export type TonsOfFunConfig = {
    balances: Map<Address, bigint>;
};

export function tonsOfFunConfigToCell(config: TonsOfFunConfig): Cell {
    const dict = Dictionary.empty<Address, bigint>(Dictionary.Keys.Address(), Dictionary.Values.BigUint(256));
    for (const [address, balance] of config.balances.entries()) {
        dict.set(address, balance);
    }
    return beginCell().storeDict(dict).endCell();
}


export const Opcodes = {
    OP_CREATE_ACCOUNT: 0x20000000,
    OP_DELETE_ACCOUNT: 0x20000001,
    OP_TRANSFER_FUNDS: 0x20000002,
    OP_DEPOSIT_FUNDS: 0x20000003,
    OP_WITHDRAW_FUNDS: 0x20000004,
    OP_CHECK_BALANCE: 0x20000005,
    OP_SUCCESS: 0x13370000,
};

export class TonsOfFun implements Contract {
    constructor(readonly address: Address, readonly init?: { code: Cell; data: Cell }) { }

    static createFromAddress(address: Address) {
        return new TonsOfFun(address);
    }

    static createFromConfig(config: TonsOfFunConfig, code: Cell, workchain = 0) {
        const data = tonsOfFunConfigToCell(config);
        const init = { code, data };
        return new TonsOfFun(contractAddress(workchain, init), init);
    }

    async sendDeploy(provider: ContractProvider, via: Sender, value: bigint): Promise<void> {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().endCell(),
        });
    }

    async sendCreateAccount(provider: ContractProvider, via: Sender, value: bigint): Promise<void> {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(Opcodes.OP_CREATE_ACCOUNT, 32).endCell(),
        });
    }

    async sendDeleteAccount(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(Opcodes.OP_DELETE_ACCOUNT, 32).endCell(),
        });
    }

    async sendTransferFunds(
        provider: ContractProvider,
        via: Sender,
        opts: {
            to: Address;
            amount: bigint;
            value: bigint;
        }
    ) {
        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.OP_TRANSFER_FUNDS, 32)
                .storeAddress(opts.to)
                .storeUint(opts.amount, 256)
                .endCell(),
        });
    }

    async sendDepositFunds(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(Opcodes.OP_DEPOSIT_FUNDS, 32).endCell(),
        });
    }

    async sendWithdrawFunds(
        provider: ContractProvider,
        via: Sender,
        opts: {
            amount: bigint;
            value: bigint;
        }
    ) {
        await provider.internal(via, {
            value: opts.value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell()
                .storeUint(Opcodes.OP_WITHDRAW_FUNDS, 32)
                .storeUint(opts.amount, 256)
                .endCell(),
        });
    }

    async sendCheckBalance(provider: ContractProvider, via: Sender, value: bigint) {
        await provider.internal(via, {
            value,
            sendMode: SendMode.PAY_GAS_SEPARATELY,
            body: beginCell().storeUint(Opcodes.OP_CHECK_BALANCE, 32).endCell(),
        });
    }

    async getBalanceOf(provider: ContractProvider, addr: Address): Promise<bigint> {
        const result = await provider.get('balanceOf', [
            { type: 'slice', cell: beginCell().storeAddress(addr).endCell() }
        ]);
        return result.stack.readBigNumber();
    }

    async getConversionRate(provider: ContractProvider): Promise<bigint> {
        const result = await provider.get('conversionRate', [
        ]);
        return result.stack.readBigNumber();
    }

    async getBalanceForFlag(provider: ContractProvider): Promise<bigint> {
        const result = await provider.get('balanceForFlag', [
        ]);
        return result.stack.readBigNumber();
    }
}
