import { Blockchain, SandboxContract, TreasuryContract } from '@ton/sandbox';
import { Cell, toNano, fromNano, Address } from '@ton/core';
import { TonsOfFun } from '../wrappers/TonsOfFun';
import '@ton/test-utils';
import { compile } from '@ton/blueprint';
import { Opcodes as TonsOfFunOpcodes } from '../wrappers/TonsOfFun';
import { randomAddress } from '@ton/test-utils';

describe('TonsOfFun', () => {
    let code: Cell;

    beforeAll(async () => {
        code = await compile('TonsOfFun');
    });

    let blockchain: Blockchain;
    let deployer: SandboxContract<TreasuryContract>;
    let tonsOfFun: SandboxContract<TonsOfFun>;
    let adminAddress: Address;

    beforeEach(async () => {
        blockchain = await Blockchain.create();
        adminAddress = randomAddress();
        const balances = new Map<Address, bigint>();
        balances.set(adminAddress, toNano('1000000'));

        tonsOfFun = blockchain.openContract(
            TonsOfFun.createFromConfig(
                {
                    balances: balances
                },
                code
            )
        );

        deployer = await blockchain.treasury('deployer');

        const deployResult = await tonsOfFun.sendDeploy(deployer.getSender(), toNano('1'));

        expect(deployResult.transactions).toHaveTransaction({
            from: deployer.address,
            to: tonsOfFun.address,
            deploy: true,
            success: true,
        });
    });

    it('should deploy', async () => {
        // the check is done inside beforeEach
        // blockchain and challenge are ready to use
    });

    it("should create an account", async () => {
        const initialValue = 0.01;
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        const balance = await tonsOfFun.getBalanceOf(client.address);
        const conversionRate = await tonsOfFun.getConversionRate();

        expect(Number(fromNano(balance))).toBe((initialValue * Number(conversionRate)));
    });

    it("should delete an account", async () => {
        const initialValue = 1;
        const client = await blockchain.treasury('client');

        const balanceBefore = await client.getBalance();
        const result = await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        const deleteTx = await tonsOfFun.sendDeleteAccount(client.getSender(), toNano('0.01'));
        const balanceAfter = await tonsOfFun.getBalanceOf(client.address);
        const clientBalanceAfter = await client.getBalance();

        expect(Number(fromNano(balanceAfter))).toBe(0);

        const totalFees = result.transactions.reduce((sum, tx) => sum + tx.totalFees.coins, 0n) +
            deleteTx.transactions.reduce((sum, tx) => sum + tx.totalFees.coins, 0n)
            + toNano('0.01');

        expect(clientBalanceAfter).toBeLessThanOrEqual(balanceBefore - totalFees + toNano('0.01'));
        expect(clientBalanceAfter).toBeGreaterThanOrEqual(balanceBefore - totalFees - toNano('0.01'));
    });

    it("should throw when deleting non-existing account", async () => {
        const client = await blockchain.treasury('client');
        const result = await tonsOfFun.sendDeleteAccount(client.getSender(), toNano('0.01'));

        expect(result.transactions).toHaveTransaction({
            from: client.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 401,
        });
    });

    it("should transfer funds between accounts", async () => {
        const initialValue = 1;
        const transferAmount = 50;
        const clientA = await blockchain.treasury('clientA');
        const clientB = await blockchain.treasury('clientB');

        await tonsOfFun.sendCreateAccount(clientA.getSender(), toNano(initialValue));
        await tonsOfFun.sendCreateAccount(clientB.getSender(), toNano(initialValue));

        const transferTx = await tonsOfFun.sendTransferFunds(
            clientA.getSender(),
            {
                to: clientB.address,
                amount: toNano(transferAmount),
                value: toNano('0.01'),
            }
        );

        const balanceA = await tonsOfFun.getBalanceOf(clientA.address);
        const balanceB = await tonsOfFun.getBalanceOf(clientB.address);
        const conversionRate = await tonsOfFun.getConversionRate();

        expect(Number(fromNano(balanceA))).toBe(((initialValue * Number(conversionRate) - transferAmount)));
        expect(Number(fromNano(balanceB))).toBe(((initialValue * Number(conversionRate) + transferAmount)));
    });

    it("should throw when transferring from a non-existing account", async () => {
        const transferAmount = 0.5;
        const clientA = await blockchain.treasury('clientA');
        const clientB = await blockchain.treasury('clientB');

        await tonsOfFun.sendCreateAccount(clientB.getSender(), toNano(1));

        const transferTx = await tonsOfFun.sendTransferFunds(
            clientA.getSender(),
            {
                to: clientB.address,
                amount: toNano(transferAmount),
                value: toNano('0.01'),
            }
        );

        expect(transferTx.transactions).toHaveTransaction({
            from: clientA.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 401,
        });
    });

    it("should throw when transferring more than balance", async () => {
        const initialValue = 1;
        const transferAmount = 2 * Number(await tonsOfFun.getConversionRate());
        const clientA = await blockchain.treasury('clientA');
        const clientB = await blockchain.treasury('clientB');

        await tonsOfFun.sendCreateAccount(clientA.getSender(), toNano(initialValue));
        await tonsOfFun.sendCreateAccount(clientB.getSender(), toNano(initialValue));

        const transferTx = await tonsOfFun.sendTransferFunds(
            clientA.getSender(),
            {
                to: clientB.address,
                amount: toNano(transferAmount),
                value: toNano('0.01'),
            }
        );

        expect(transferTx.transactions).toHaveTransaction({
            from: clientA.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 402,
        });
    });

    it("should transfer funds to a non-existing account", async () => {
        const initialValue = 1;
        const transferAmount = 50;
        const clientA = await blockchain.treasury('clientA');
        const clientB = await blockchain.treasury('clientB');

        await tonsOfFun.sendCreateAccount(clientA.getSender(), toNano(initialValue));

        const transferTx = await tonsOfFun.sendTransferFunds(
            clientA.getSender(),
            {
                to: clientB.address,
                amount: toNano(transferAmount),
                value: toNano('0.01'),
            }
        );

        const balanceA = await tonsOfFun.getBalanceOf(clientA.address);
        const balanceB = await tonsOfFun.getBalanceOf(clientB.address);
        const conversionRate = await tonsOfFun.getConversionRate();

        expect(Number(fromNano(balanceA))).toBe(((initialValue * Number(conversionRate) - transferAmount)));
        expect(Number(fromNano(balanceB))).toBe((transferAmount));
    });

    it("should throw an error when transferring to the same account", async () => {
        const initialValue = 1;
        const transferAmount = 50;
        const clientA = await blockchain.treasury('clientA');

        await tonsOfFun.sendCreateAccount(clientA.getSender(), toNano(initialValue));

        const transferTx = await tonsOfFun.sendTransferFunds(
            clientA.getSender(),
            {
                to: clientA.address,
                amount: toNano(transferAmount),
                value: toNano('0.01'),
            }
        );

        expect(transferTx.transactions).toHaveTransaction({
            from: clientA.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 403,
        });
    });

    it("should deposit funds into an account", async () => {
        const initialValue = 1;
        const depositAmount = 50;
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        await tonsOfFun.sendDepositFunds(client.getSender(), toNano(depositAmount));

        const balance = await tonsOfFun.getBalanceOf(client.address);
        const conversionRate = await tonsOfFun.getConversionRate();

        expect(Number(fromNano(balance))).toBe(((initialValue + depositAmount) * Number(conversionRate)));
    });

    it("should throw when depositing into a non-existing account", async () => {
        const depositAmount = 50;
        const client = await blockchain.treasury('client');

        const depositTx = await tonsOfFun.sendDepositFunds(client.getSender(), toNano(depositAmount));

        expect(depositTx.transactions).toHaveTransaction({
            from: client.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 401,
        });
    });

    it("should withdraw funds from an account", async () => {
        const initialValue = 1;
        const depositAmount = 50;
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        const withdrawTx = await tonsOfFun.sendWithdrawFunds(client.getSender(), {
            amount: toNano(depositAmount),
            value: toNano('0.01'),
        });

        const balance = await tonsOfFun.getBalanceOf(client.address);
        const conversionRate = await tonsOfFun.getConversionRate();
        const clientBalance = await client.getBalance();
        expect(Number(fromNano(balance))).toBe(((initialValue * Number(conversionRate) - depositAmount)));
        expect(clientBalance).toBeGreaterThanOrEqual(toNano(depositAmount) - withdrawTx.transactions.reduce((sum, tx) => sum + tx.totalFees.coins, 0n));
    });

    it("should throw when withdrawing from a non-existing account", async () => {
        const depositAmount = 50;
        const client = await blockchain.treasury('client');

        const withdrawTx = await tonsOfFun.sendWithdrawFunds(client.getSender(), {
            amount: toNano(depositAmount),
            value: toNano('0.01'),
        });

        expect(withdrawTx.transactions).toHaveTransaction({
            from: client.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 401,
        });
    });

    it("should throw when withdrawing more than balance", async () => {
        const initialValue = 1;
        const depositAmount = 2 * Number(await tonsOfFun.getConversionRate());
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));

        const withdrawTx = await tonsOfFun.sendWithdrawFunds(client.getSender(), {
            amount: toNano(depositAmount),
            value: toNano('0.01'),
        });

        expect(withdrawTx.transactions).toHaveTransaction({
            from: client.address,
            to: tonsOfFun.address,
            success: false,
            aborted: true,
            exitCode: 402,
        });
    });

    it("should emit a success log message when balance >= threshold", async () => {
        const initialValue = 10000;
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        const checkBalanceTx = await tonsOfFun.sendCheckBalance(client.getSender(), toNano('0.01'));

        let success = false;
        for (const ext of checkBalanceTx.externals) {
            if (!ext.body) {
                continue;
            }
            const opcode = ext.body.beginParse().loadUint(32);
            if (opcode === TonsOfFunOpcodes.OP_SUCCESS) {
                success = true;
                break;
            }
        }

        expect(success).toBe(true);
    });

    it("should not emit a success log message when balance < threshold", async () => {
        const initialValue = 1;
        const client = await blockchain.treasury('client');

        await tonsOfFun.sendCreateAccount(client.getSender(), toNano(initialValue));
        const checkBalanceTx = await tonsOfFun.sendCheckBalance(client.getSender(), toNano('0.01'));

        let success = false;
        for (const ext of checkBalanceTx.externals) {
            if (!ext.body) {
                continue;
            }
            const opcode = ext.body.beginParse().loadUint(32);
            if (opcode === TonsOfFunOpcodes.OP_SUCCESS) {
                success = true;
                break;
            }
        }

        expect(success).toBe(false);
    });
});