# Tons of Fun

Tons of Fun is written in the [Tolk language](https://docs.ton.org/v3/documentation/smart-contracts/tolk/overview), ran on a local VM of the [Ton blockchain](https://docs.ton.org/). Requests are limited to one second in execution.

## Install
`npm i --save-dev`

## Requirements for Exploit File

After downloading this codebase locally, the one file that requires modifcation is the `contracts/exploit.tolk` file. The `run` function is the only function that should be modified, but DO NOT modify the method signature. The server expects your exploit contract to accept signature: 
```
struct (0xDEADBEEF) Run {
    target: address
    admin: address
}
```
A `SuccessLogMessage` must be emitted by the TonsOfFun smart contract to receieve the flag.

## Running Locally
By running `npm run server`, a local server (from `checker/server.ts`) is started that can be interacted with to run / test your challenge. By running `npm run submit`, you can test your exploit script against the local server. This will compile the smart contract defined in `contracts/exploit.tolk` and submit to the local server for evaluation. The output
```
Server response: { success: true, flag: '...' }
```
indicates a success. Then, you are ready to submit to remote.

## Running Remotely

To run against remote, supply the optional `endpoint` argument to `npm run submit`. E.g `npm run submit <remote server>`.
