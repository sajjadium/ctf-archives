import { compile } from '@ton/blueprint';

async function main() {
    const baseUrl = process.argv[2] || 'http://localhost:3000';
    const submitUrl = new URL('/submit', baseUrl).toString();

    try {
        console.log('Compiling exploit contract...');
        const exploitCode = await compile('Exploit');
        const exploitCodeBase64 = exploitCode.toBoc().toString('base64');

        console.log('Submitting to server...');
        const response = await fetch(submitUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                code: exploitCodeBase64,
            }),
        });

        const data = await response.json();
        console.log('Server response:', data);
    } catch (error) {
        if (error instanceof Error) {
            console.error('Error submitting to server:', error.message);
        } else {
            console.error('Error:', error);
        }
    }
}

main();
