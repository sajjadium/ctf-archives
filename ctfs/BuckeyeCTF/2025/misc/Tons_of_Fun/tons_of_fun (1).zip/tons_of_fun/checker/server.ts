import { Blockchain, SandboxContract } from '@ton/sandbox';
import { beginCell, Cell, toNano, Address } from '@ton/core';
import { TonsOfFun, Opcodes as TonsOfFunOpcodes } from '../wrappers/TonsOfFun';
import { Exploit, Opcodes as ExploitOpcodes } from '../wrappers/Exploit';
import '@ton/test-utils';
import { compile } from '@ton/blueprint';
import express, { Request, Response } from 'express';
import bodyParser from 'body-parser';
import { randomAddress } from '@ton/test-utils';
import timeout from "connect-timeout";

const FLAG = process.env.FLAG || 'bctf{test-flag}';

const app = express();
app.use(bodyParser.json());
app.use(timeout('1s'));

function haltOnTimedout(req: Request, res: Response, next: any) {
    if (!req.timedout) next();
}

let tonsOfFunCode: Cell;

compile('TonsOfFun').then(code => {
    tonsOfFunCode = code;
});

const runExploit = async (exploitCode: Cell): Promise<boolean> => {
    const blockchain = await Blockchain.create();

    // Seed admin address for being the founder
    const adminAddress = randomAddress();
    const balances = new Map<Address, bigint>();
    balances.set(adminAddress, toNano('1000000'));

    const tonsOfFun = blockchain.openContract(TonsOfFun.createFromConfig({
        balances: balances,
    }, tonsOfFunCode));

    const deployer = await blockchain.treasury('deployer');
    await tonsOfFun.sendDeploy(deployer.getSender(), toNano('1'));

    const exploit = blockchain.openContract(Exploit.createFromConfig({ tonsOfFunAddress: tonsOfFun.address }, exploitCode));
    const exploitDeployer = await blockchain.treasury('exploitDeployer');
    await exploit.sendDeploy(exploitDeployer.getSender(), toNano('0.0001'));

    const result = await exploitDeployer.send({
        to: exploit.address,
        value: toNano('0.05'),
        body: beginCell()
            .storeUint(ExploitOpcodes.OP_RUN, 32)
            .storeAddress(tonsOfFun.address)
            .storeAddress(adminAddress)
            .endCell(),
    });

    let success = false;
    for (const ext of result.externals) {
        if (!ext.body) {
            continue;
        }
        const opcode = ext.body.beginParse().loadUint(32);
        if (opcode === TonsOfFunOpcodes.OP_SUCCESS) {
            success = true;
            break;
        }
    }

    return success;
};

app.post('/submit', async (req: Request, res: Response) => {
    try {
        if (!req.body.code) {
            res.status(400).json({ error: 'Missing code in request body' });
            return;
        }

        const exploitCode = Cell.fromBase64(req.body.code);
        const success = await runExploit(exploitCode);

        let response: any = { success };
        if (success) {
            response.flag = FLAG;
        }
        res.json(response);
    } catch (error) {
        console.error('Error processing exploit:', error);
        res.status(500).json({ error: 'Failed to process exploit' });
    }
});

app.get('/', (req: Request, res: Response) => {
    res.send('Tons of Fun Challenge Server is running.');
});

app.use(haltOnTimedout);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
