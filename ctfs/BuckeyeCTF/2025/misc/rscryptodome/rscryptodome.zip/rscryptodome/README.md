# rscryptodome

What do you think of my totally secure [crypto library](https://github.com/smederij-bctf/rscryptodome-bctf)?

## Run

```
docker compose up --build --remove-orphans
```

Then run:

```
nc localhost 2000
```
