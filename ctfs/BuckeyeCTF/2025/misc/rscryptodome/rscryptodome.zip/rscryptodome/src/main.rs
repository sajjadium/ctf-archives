use rscryptodome_bctf::{constant_time_eq, sha256sum};
use std::env;
use std::io::{self, Write};

fn main() {
    let flag = env::var("FLAG").expect("FLAG environment variable not set");

    let flag_hash_hex = sha256sum(flag.as_bytes());

    print!("Enter the hash of the flag: ");
    io::stdout().flush().expect("Failed to flush stdout");

    let mut user_input = String::new();
    io::stdin()
        .read_line(&mut user_input)
        .expect("Failed to read line");

    let user_input = user_input.trim();

    if constant_time_eq(&flag_hash_hex, user_input.as_bytes()) {
        println!("Correct! {}", flag);
    } else {
        println!("Incorrect hash.");
    }
}
