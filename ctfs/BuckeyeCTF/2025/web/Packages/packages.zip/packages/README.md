# packages

Explore the world of debian/debian-based packages.

## Run

```
docker compose up --build --remove-orphans
```

Then go to http://localhost:8000
