# BIG CHUNGUS

There's wabbit twouble afoot

## Run

```
docker compose up --build --remove-orphans
```

Then go to http://localhost:3000
