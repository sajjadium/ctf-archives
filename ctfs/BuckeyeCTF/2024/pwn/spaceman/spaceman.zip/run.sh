#!/bin/sh
/opt/riscv/bin/qemu-riscv64 spaceman
