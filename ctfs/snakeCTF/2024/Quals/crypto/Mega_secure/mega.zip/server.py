#!/usr/bin/env python3

import os
import signal

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Util.number import getPrime, bytes_to_long as btl, long_to_bytes as ltb

TIMEOUT = 500

assert ("FLAG" in os.environ)
FLAG = os.environ["FLAG"]

key = os.urandom(16)


def encrypt_sk(p, q, d):
    u = pow(q, -1, p)
    dp = d % (p - 1)
    dq = d % (q - 1)
    p, q, dp, dq, u = ltb(p), ltb(q), ltb(dp), ltb(dq), ltb(u)
    k = (len(p).to_bytes(2, byteorder="big") + p + len(q).to_bytes(2, byteorder="big") + q +
         len(dp).to_bytes(2, byteorder="big") + dp + len(dq).to_bytes(2, byteorder="big") + dq +
         len(u).to_bytes(2, byteorder="big") + u)

    cipher = AES.new(key, AES.MODE_CBC)
    sk = cipher.iv + cipher.encrypt(pad(k, 16))

    return sk


def extract_value(k):
    len_value = btl(k[:2])
    value = btl(k[2:2 + len_value])
    return value, k[2 + len_value:]


def decode_sk(key, sk):
    cipher = AES.new(key, AES.MODE_CBC, IV=sk[:16])
    k = cipher.decrypt(sk[16:])

    p, k = extract_value(k)
    q, k = extract_value(k)
    dp, k = extract_value(k)
    dq, k = extract_value(k)
    u, k = extract_value(k)

    return p, q, dp, dq, u


def decrypt_msg(c, sk):
    p, q, dp, dq, u = decode_sk(key, sk)

    mp = pow(c, dp, p)
    mq = pow(c, dq, q)
    t = (mp - mq) % p
    h = (t * u) % p
    m = (h * q + mq)

    return m


def handle():
    print("Welcome!!")
    print("Here are the public keys and the encrypted secret keys")

    p, q = getPrime(1024), getPrime(1024)
    e = 65537
    n = p * q
    print("n:", n)
    print("e:", e)

    d = pow(e, -1, (p - 1) * (q - 1))
    sk = encrypt_sk(p, q, d)
    print("sk:", btl(sk))
    print()

    while True:
        print("Choose one of the following options")
        print("[1] Decrypt a message")
        print("[2] Get the flag")
        print("[3] Exit")
        option = input("> ")
        if option == "1":
            try:
                c = int(input("Enter a message to decrypt: "))
                sk = ltb(int(input("Enter the encrypted keys: ")))

                m = decrypt_msg(c, sk)
                if pow(m, e, n) == c:
                    print("Message received")
                else:
                    print("Something is wrong with your key")
            except:
                print("Something went wrong")

        elif option == "2":
            m = btl(os.urandom(32))
            print("To get the flag give the signature of the following message")
            print("Message:", m)
            try:
                s = int(input("Enter the signature: "))
                if s == pow(m, d, n):
                    print("Well done")
                    print(FLAG)
                    break
                else:
                    print("Nice try")
            except:
                print("Something went wrong")

        elif option == "3":
            print("Bye bye!\n")
            break
        else:
            print("Invalid option")
        print()


if __name__ == "__main__":
    signal.alarm(TIMEOUT)
    handle()
