#!/usr/bin/env python3

from ige_mode import encrypt, decrypt
import os
import signal

TIMEOUT = 400

assert ("FLAG" in os.environ)
FLAG = os.environ["FLAG"]

def main():
    key = os.urandom(16)
    enc_flag = encrypt(FLAG.encode(), key)

    while True:
        print(""" 
        MENU:
            1) Get encrypted flag
            2) Decrypt your message
            3) Exit
            """)

        choice = input("> ")

        if choice == "1":
            print(f"The encrypted flag is {enc_flag.hex()}")
        elif choice == "2":
            try:
                your_ciphertext = bytes.fromhex(input("give me your ciphertext (HEX): ").strip())
            except:
                print("This is not an HEX string")
                continue
            
            if len(your_ciphertext) < 48:
                print("There is a minimum required length.")
                continue
            if len(your_ciphertext) % 16 != 0:
                print("The ciphertext must be composed by blocks of 16 bytes")
                continue
            if your_ciphertext == enc_flag:
                print("Eh...no")
                continue
            try:
                decrypt(your_ciphertext, key)
                print("Ahhh, cumò i ti iudi")
            except:
                print("Cemut? I no ai capit")

        elif choice == "3":
            break


if __name__ == "__main__":
    signal.alarm(TIMEOUT)
    main()


