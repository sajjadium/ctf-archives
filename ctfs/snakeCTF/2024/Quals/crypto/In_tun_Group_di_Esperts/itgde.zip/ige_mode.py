from config import *
from AES.aes_utilities import *
from AES.utilities import *
import os
from copy import deepcopy


# plaintext should be an array of integers mod 256 of length 16
def aes_encrypt(plaintext, key):
    assert len(plaintext) == 16

    current_state = deepcopy(plaintext)
    keys = key_expansion(key, TOTAL_ROUNDS + 1)

    for i in range(TOTAL_ROUNDS):
        t = add(current_state, keys[i])
        current_state = forward_round(t)

    current_state = add(current_state, keys[TOTAL_ROUNDS])

    return current_state


# plaintext should be an array of integers mod 256 of length 16
def aes_decrypt(ciphertext, key):
    assert len(ciphertext) == 16
    current_state = deepcopy(ciphertext)
    keys = key_expansion(key, TOTAL_ROUNDS + 1)

    for i in range(TOTAL_ROUNDS, 0, -1):
        t = add(current_state, keys[i])
        current_state = inverse_round(t)

    current_state = add(current_state, keys[0])

    return current_state


def pad(bytes_list):
    pad_length = 16 - (len(bytes_list) % 16)
    for i in range(pad_length):
        bytes_list.append(pad_length)

    return bytes_list


def unpad(bytes_list):
    last_element = bytes_list[-1]
    if 0 < last_element < 17:
        # valid value for padding
        if all([True if el == last_element else False for el in bytes_list[-last_element:]]):
            return bytes_list[:-last_element]
        else:
            raise Exception("Invalid padding!")
    else:
        raise Exception("Invalid padding!")


# plaintext must be a byte string
# key must be a byte string
def encrypt(plaintext, key):
    p = list(plaintext)
    k = list(key)
    # divide p in blocks of 16 bytes (padding if needed)
    bytes_list = pad(p)
    blocks = [bytes_list[i:i + 16] for i in range(0, len(bytes_list), 16)]
    iv1 = list(os.urandom(16))
    iv2 = list(os.urandom(16))

    ciphertext_blocks = []

    for i in range(len(blocks)):
        if i == 0:
            current_state = deepcopy(blocks[i])
            current_state = add(current_state, iv1)
            current_state = aes_encrypt(current_state, k)
            current_state = add(current_state, iv2)
            ciphertext_blocks.append(current_state)
        else:
            current_state = deepcopy(blocks[i])
            current_state = add(current_state, ciphertext_blocks[i - 1])
            current_state = aes_encrypt(current_state, k)
            current_state = add(current_state, blocks[i - 1])
            ciphertext_blocks.append(current_state)

    ciphertext = b""
    for el in ciphertext_blocks:
        ciphertext += bytes(el, )

    return bytes(iv1) + bytes(iv2) + ciphertext


# ciphertext and key must be byte strings
def decrypt(ciphertext, key):
    c = list(ciphertext)
    k = list(key)
    assert len(c) % 16 == 0

    blocks = [c[i:i + 16] for i in range(0, len(c), 16)]

    iv1 = blocks[0]
    iv2 = blocks[1]

    plaintext_blocks = []
    blocks = blocks[2:]
    for i in range(0, len(blocks)):
        if i == 0:
            current_state = deepcopy(blocks[i])
            current_state = add(current_state, iv2)
            current_state = aes_decrypt(current_state, k)
            current_state = add(current_state, iv1)
            plaintext_blocks.append(current_state)
        else:
            current_state = deepcopy(blocks[i])
            current_state = add(current_state, plaintext_blocks[i - 1])
            current_state = aes_decrypt(current_state, k)
            current_state = add(current_state, blocks[i - 1])
            plaintext_blocks.append(current_state)

    plaintext = b""
    for el in plaintext_blocks:
        plaintext += bytes(el)
    try:
        plaintext = bytes(unpad(list(plaintext)))
    except:
        raise Exception("Invalid padding!")

    return plaintext
