#!/usr/bin/env python3

import signal
import re
import time
from datetime import datetime, timezone

from auth import *

TIMEOUT = 500
quotes = [
    "Life, uh, finds a way.",
    "That is one big pile of shit.",
    "Hold on to your butts.",
    "Welcome to Jurassic Park.",
    "Clever girl.",
    "Must go faster.",
    "We spared no expense.",
    "God help us, we're in the hands of engineers",
    "God creates dinosaurs. God destroys dinosaurs. God creates man. Man destroys God. Man creates dinosaurs.",
    "I don't think you're giving us our due credit. Our scientists have done things that nobody's ever done before.",
    "If I could just persuade you to think of our new synthesizing as, well, an alternate strategy...",
    "It's a UNIX System! I know this!"
]

users = {}
current_user = ''
exchange_rate = random.getrandbits(120)

def print_banner():
    print("Welcome to:")
    print("         _                                            _                    _ \n"
          "        | |                             (_)          | |                  | |  \n"
          "        | | _   _  _ __  __ _  ___  ___  _   ___     | |__    __ _  _ __  | | __ \n"
          "    _   | || | | || '__|/ _` |/ __|/ __|| | / __|    | '_ \\  / _` || '_ \\ | |/ / \n"
          "   | |__| || |_| || |  | (_| |\\__\\ \\__ \\| || (__     | |_) || (_| || | | ||   <  \n"
          "    \\____/  \\__,_||_|   \\__,_||___/|___/|_| \\___|    |_.__/  \\__,_||_| |_||_|\\_\\ \n\n"
          "The current excange rate between Ptero-dollars and dollar is \n"
          f"{exchange_rate} : 1\n\n"
          f"Today's new users will get 10 dollar worth in Ptero-dollars\n\n")


def print_menu_logged():
    print()
    print("(1) See Profile")
    print("(2) Add new funds")
    print("(3) Transfer funds")
    print("(4) Retrive funds")
    print("(5) Buy flag")
    print("(6) Log out")
    print("(7) Exit")


def print_menu():
    print()
    print("(1) Create a new Account")
    print("(2) Login into an Account")
    print("(3) Exit")


def handle_new_client():
    global current_user

    print_menu()
    choice = (input("Insert choice: "))
    match choice:
        case '1':
            if len(users) >= 5:
                print('The park is already full, sorry')
                return

            ut = input("Insert username: ")
            pw = hash(input("Insert password: "))

            if not re.match("^[a-z]*$", ut) or len(ut) > 15:
                print("Username not allowed")
                return

            if ut in users:
                print("Username already used")
                return
            current_user = hex(random.getrandbits(32))[2:]
            users[current_user] = {
                'name': ut,
                'pw': pw,
                'Ptero-dollars': 10 * exchange_rate,
            }

        case '2':
            ut = input("Insert username: ")
            pw = input("Insert password: ")
            pw = hash(pw)

            for id, u in users.items():
                if ut == u['name'] and u['pw'] == pw:
                    current_user = id
                    return
            else:
                print("** Wrong credentials, we are a secure bank, just like the fences in the park... opsie **")
        case '3':
            print("Exit information Jurassic Bank")
            exit(0)
        case _:
            print("\n** Not a valid choice, exiting, but first here's a quote from jurassic park: ** \n")
            i = random.randint(0, len(quotes))
            print("\"" + quotes[i] + "\"")
            return


def main():
    global current_user
    print_banner()

    while True:

        try:
            if current_user:
                print_menu_logged()
            else:
                handle_new_client()
                continue

            choice = (input("Insert choice: "))

            match choice:
                case '1':
                    print(
                        "\n\n\nThank you for choosing jurassic bank, the best credit institute of the era with no banks! ")
                    print("------------------------------------------------------------------------------------------")
                    print(
                        f"Welcome {users[current_user]['name']}, the time is {datetime.fromtimestamp(time.time(), tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S')} ")
                    print()
                    print("Here is your profile information:")
                    print("ID: " + current_user)
                    print("password (if you ever need it): " + users[current_user]['pw'])
                    print("Ptero-dollars: " + str(users[current_user]['Ptero-dollars']))

                case '2':
                    for i in range(8):
                        print("YOU DIDN'T SAY THE MAGIC WORD!")
                        time.sleep(0.5)
                case '3':
                    id = input("Insert id recipient: ")
                    qt = int(input("Insert quantity: "))
                    ex = int(input("Insert days since expiration: "))
                    rs = input("Insert reason for the transfer: ")
                    dn = int(input("Insert money to be donated to preistoric snake fund: "))  # actually gas fees

                    if dn < 1:
                        print('You have no hearth')
                        continue

                    if qt < 0 or qt + dn > users[current_user]['Ptero-dollars']:
                        print('Here, watch this: https://www.youtube.com/watch?v=6PeykaclVaA')
                        continue

                    users[current_user]['Ptero-dollars'] -= (qt + dn)

                    token = generate_token({
                        'id': id,
                        'ex': ex,
                        'qt': qt,
                        'rs': rs,
                        'time': int(time.time())
                    })

                    print('Use this token to recieve you prehistoric money')
                    print(token)
                case '4':
                    data = decode_token(input("Insert token: "))
                    if not data or data['id'] != current_user:
                        print('Token not valid')
                        continue

                    diff = datetime.now() - datetime.fromtimestamp(data['time'])

                    if diff.days >= data['ex']:
                        print('Token expired')
                        continue

                    users[current_user]['Ptero-dollars'] += data['qt']

                    print(f"Succesfully added {data['qt']} Ptero-dollars")

                case '5':
                    if users[current_user]['Ptero-dollars'] < 1000 * exchange_rate:
                        print('Poor dinosaur, you need more money to buy the flag!')
                        continue
                    users[current_user]['Ptero-dollars'] -= 1000 * exchange_rate
                    with open('flag.txt', 'r') as f:
                        print(f.read())

                    exit(0)

                case '6':
                    current_user = ''
                case '7':
                    exit(0)
                case _:
                    print("** Not a valid choice, exiting, but first here's a quote from jurassic park: ** \n")
                    i = random.randint(0, len(quotes))
                    print("\"" + quotes[i] + "\"")
                    return

        except Exception as e:
            print("Error: something went wrong! Com'on even a dinosaur can do it!")
            exit(-1)


if __name__ == "__main__":
    signal.alarm(TIMEOUT)
    main()
