#!/usr/bin/env python3


from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from base64 import b64encode

import forkaes
import os
import signal

TIMEOUT = 1800

assert ("FLAG" in os.environ)
FLAG = os.environ["FLAG"]


def main():
    KEY = os.urandom(16)
    KEY = list(KEY)
    assert len(KEY) == forkaes.BLOCK_SIZE

    print("TheFORK oracle is still here!")

    tweak = [int.from_bytes(os.urandom(1), byteorder='big') for _ in range(forkaes.BLOCK_SIZE // 2)]
    plaintext = [int.from_bytes(os.urandom(1), byteorder='big') for _ in range(forkaes.BLOCK_SIZE)]

    left_ct, right_ct = forkaes.encrypt(plaintext, KEY, tweak)

    print("Try to find the key we used to encrypt the following plaintext:")
    print(plaintext)
    print()
    print(f'The tweak we used is:')
    print(tweak)
    print()
    print("The corresponding left and right ciphertexts are:")
    print(f'Left: {left_ct}')
    print(f'Right: {right_ct}')
    print()
    while True:
        print(""" 
        MENU:
            1) Compute sibling
            2) Get flag
            3) Exit
            """)

        choice = input("> ")

        if choice == "1":
            # The below line read inputs from user using map() function
            print(
                f"The ciphertext and the tweak should be represented as a list of values comma separated such as 2, 3, 4, 5, 6\nYou can input only {forkaes.BLOCK_SIZE} numbers")
            ciphertext = list(map(int, input("\nEnter the ciphertext : ").strip().split(',')))[:forkaes.BLOCK_SIZE]
            tweak = list(map(int, input("\nEnter the tweak : ").strip().split(',')))[:forkaes.BLOCK_SIZE // 2]
            side_of_the_ciphertext = input("Side of your ciphertext (possible values are: right | left): ")

            if side_of_the_ciphertext != "left" and side_of_the_ciphertext != "right":
                print("Wrong side value!")
                continue

            print("The other ciphertexts is: ")
            print(forkaes.compute_sibling(ciphertext, KEY, tweak, side=side_of_the_ciphertext))

        elif choice == "2":

            cipher = AES.new(bytes(KEY), AES.MODE_CBC)
            ct_bytes = cipher.encrypt(pad(FLAG.encode(), AES.block_size))
            iv = b64encode(cipher.iv).decode('utf-8')
            ct = b64encode(ct_bytes).decode('utf-8')

            print(iv)
            print(ct)

        elif choice == "3":
            break


if __name__ == "__main__":
    signal.alarm(TIMEOUT)
    main()
