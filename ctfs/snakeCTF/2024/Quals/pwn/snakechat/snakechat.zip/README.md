# snakechat

## Debugging

A script to simplify the debugging process is provided inside of the zip file.

In order to use it, you must uncomment the specified lines inside of `docker-compose.yaml`
and `client/Dockerfile`. 

Then, after starting the bot you can run `./debug.sh` and connect through gdb using `target remote :1234`.

NOTE: the bot takes about 5 seconds to start after the container is up

## Remote

To connect to the remote instance using the provided client you have to setup a tunnel that strips TLS, since
the client only supports raw TCP.

That can be done as follows:
- `socat tcp4-l:1337,fork,reuseaddr openssl:INSTANCE_URL:1337` where INSTANCE_URL is your instance's url

While scripting, you can simply use `r = remote(INSTANCE_URL, 1337, ssl=True)` without the need of a tunnel