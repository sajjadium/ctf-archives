import os
import re
from time import sleep
from subprocess import Popen, PIPE, DEVNULL

LOGIN_LOG = rb"\x1b\[38;2;\d{1,3};\d{1,3};\d{1,3}m\[snakechat\]\x1b\[0m Logged in as \x1b\[38;2;\d{1,3};\d{1,3};\d{1,3}m([A-Za-z0-9\-_]+)\x1b\[0m\n"
JOIN_LOG = rb"\+ \x1b\[38;2;\d{1,3};\d{1,3};\d{1,3}m([A-Za-z0-9\-_]+)\x1b\[0m\n"
LEAVE_LOG = rb"- \x1b\[38;2;\d{1,3};\d{1,3};\d{1,3}m([A-Za-z0-9\-_]+)\x1b\[0m\n"

HOST = os.getenv("SERVER_HOST")
PORT = os.getenv("SERVER_PORT")
CLIENT_PATH = os.getenv("CLIENT_PATH", "client")
BOT_DELAY = int(os.getenv("BOT_DELAY", "1"))


def open_chat(client_path: str, host: str, port: str) -> Popen:
    return Popen([client_path, host, port], stdin=PIPE, stdout=DEVNULL, stderr=PIPE)


def main():
    chat = open_chat(CLIENT_PATH, HOST, PORT)
    chat.stdin.write(b"admin\n")
    chat.stdin.flush()

    my_name = "admin"

    for chat_log in iter(chat.stderr.readline, None):

        if chat.poll() is not None or chat_log == None:
            exit(0)

        if (match := re.search(LOGIN_LOG, chat_log)):
            my_name = match.group(1)
            continue

        if (match := re.search(JOIN_LOG, chat_log)) and (target := match.group(1)) != my_name:
            sleep(BOT_DELAY)
            chat.stdin.write(b"Hello @" + target + b"\n")
            chat.stdin.flush()
            continue

        if (match := re.search(LEAVE_LOG, chat_log)) and (target := match.group(1)) != my_name:
            sleep(BOT_DELAY)
            chat.stdin.write(b"Bye " + target + b"\n")
            chat.stdin.flush()
            continue


if __name__ == "__main__":
    main()
