#!/bin/bash

while true; do
    sleep 5
    python3 /home/ubuntu/bot.py
done
