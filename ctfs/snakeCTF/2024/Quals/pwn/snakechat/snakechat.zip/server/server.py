import os
import socket
import logging
import threading

from client import Client, clients

HOST = os.getenv('HOST', '127.0.0.1')
PORT = int(os.getenv('PORT', '1337'))

log = logging.getLogger("snakechat-server")

def main():

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((HOST, PORT))
        s.listen()
        log.info(f"Listening on {HOST}:{PORT}")

        try:
            while True:
                conn, addr = s.accept()
                client = Client(conn, addr)
                log.info(f"Accepted connection from {addr[0]}:{addr[1]}")

                thread = threading.Thread(target=client.handle)
                thread.start()
    
        except KeyboardInterrupt:
            for client in clients:
                client.disconnect()
            log.info("Shutting down")
        

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format="%(levelname)s\t%(name)s\t%(message)s")
    main()
