import socket
import string
import random
import logging
import threading

from typing import Self
from hashlib import sha256

from proto import *

clients: list["Client"] = []
log = logging.getLogger("snakechat-server")

logging.basicConfig(level=logging.INFO, format="%(levelname)s\t%(name)s\t%(message)s")

class Client:
    def __init__(self: Self, conn: socket.socket, addr):
        self.conn = conn
        self.addr = addr
        self.id = None
        self.name = None
        clients.append(self)

    def disconnect(self: Self):
        if self in clients:
            clients.remove(self)

        self.conn.close()
        
        if self.id and self.name:
            self.send_broadcast(proto_leave(self.id, self.name))
        log.info(f"Disconnected {self}")

    def send_packet(self: Self, packet: bytes):
        try:
            self.conn.sendall(packet)
        except:
            self.disconnect()

    def send_broadcast(self: Self, packet: bytes, include_self: bool = False):
        for client in clients:
            if (include_self or client != self) and client.id and client.name:
                threading.Thread(None, client.send_packet, args=[packet]).start()

    def recv_packet(self: Self) -> bytes:
        buf = b""
        c, lc = None, None
        while lc != b"\r" and c != b"\n":
            lc = c
            c = self.conn.recv(1)
            if not c:
                raise EOFError()
            buf += c
        return buf

    def assign_name(self: Self):
        self.name = "".join(random.sample(string.ascii_letters, 10)).encode()

    def assign_id(self: Self):
        h = sha256(self.name).digest()
        self.id = int.from_bytes([x ^ y for x, y in zip(h[-8:], h[:8])])

    def do_login(self: Self):
        curr_clients = [cl for cl in clients if cl.id and cl.name and cl != self]
        self.send_packet(proto_login_ok(self.id, self.name, [(cl.id, cl.name) for cl in curr_clients]))
        self.send_broadcast(proto_join(self.id, self.name))

    def handle(self: Self):
        log.info(f"Handling client {self}")

        while True:
            try:
                pkt = self.recv_packet()
                _, msg_type = proto_parse_type(pkt)

                match msg_type:
                    case PktType.LOGIN:
                        pkt = LoginPkt(pkt)
                        
                        if any([c.name == pkt.name() for c in clients]) or \
                                any([c not in (string.ascii_letters + string.digits + "_-").encode() for c in pkt.name()]):
                            self.assign_name()
                        else:
                            self.name = pkt.name()
                        self.assign_id()
                        log.info(f"{self} logged in as {self.name} (id {self.id})")
                        self.do_login()
                        
                    case PktType.NEW_MSG:
                        pkt = NewMsgPkt(pkt)
                        
                        self.send_broadcast(proto_new_msg(self.id, pkt.msg(), pkt.args()), include_self=True)
                    
            except EOFError:
                break
            except:
                log.exception(f"Error handling {self}")
                break

        self.disconnect()

    def __repr__(self):
        return f"Client({self.addr})"   