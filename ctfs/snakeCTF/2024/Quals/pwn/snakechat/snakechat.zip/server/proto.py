import string

from enum import Enum
from typing import Self


class PktType(Enum):
    LOGIN = 'LOGIN'
    NEW_MSG = 'NEW_MSG'

    @staticmethod
    def from_str(s: str) -> Self:
        for mt in PktType:
            if mt.value == s:
                return mt
        raise ValueError("Invalid PktType")
    
class LoginPkt():
    
    def __init__(self: Self, b: bytes):
        idx = len(PktType.LOGIN.value)
        _, self._name = parse_proto_str(b[idx:])

    def name(self: Self):
        return self._name


class NewMsgPkt():

    def __init__(self: Self, b: bytes):
        idx = len(PktType.NEW_MSG.value)

        idx_tmp, self._msg = parse_proto_str(b[idx:])
        idx += idx_tmp

        self._args = []
        idx_tmp, args_len = parse_proto_int(b[idx:])
        idx += idx_tmp

        for _ in range(args_len):
            idx_tmp, arg = parse_proto_int(b[idx:])
            idx += idx_tmp
            self._args.append(arg)

    def msg(self: Self) -> bytes:
        return self._msg
    
    def args(self: Self) -> list[int]:
        return self._args


def proto_str(s: bytes) -> bytes:
    s = s.replace(b"\r", b"").replace(b"\n", b"")
    return str(len(s)).encode() + b"\t" + s


def proto_user(id: int, name: bytes) -> bytes:
    return str(id).encode() + b"\t" + proto_str(name)


def proto_list(content: list[bytes]) -> bytes:
    return b"\t".join([str(len(content)).encode(), *content])


def proto_login_ok(id: int, name: bytes, clients: list[tuple[int, bytes]]) -> bytes:
    clients = [proto_user(id, name) for id, name in clients]
    return b"LOGIN_OK\t" + proto_user(id, name) + b"\t" + proto_list(clients) + b"\r\n"


def proto_join(id: int, name: bytes) -> bytes:
    return b"JOIN\t" + proto_user(id, name) + b"\r\n"


def proto_leave(id: int, name: bytes) -> bytes:
    return b"LEAVE\t" + proto_user(id, name) + b"\r\n"


def proto_new_msg(id: int, msg: bytes, args: list[int]) -> bytes:
    return b"NEW_MSG\t" + str(id).encode() + b"\t" + proto_str(msg) + b"\t" + proto_list([str(a).encode() for a in args]) + b"\r\n"


def parse_proto_int(s: bytes) -> tuple[int, int]:
    if not s or s[0:1] != b"\t":
        raise ValueError("Invalid proto int")
    if b"\t" in s[1:]:
        idx = s[1:].index(b"\t") + 1
    elif b"\r" in s[1:]:
        idx = s[1:].index(b"\r") + 1
    else:
        raise ValueError("Invalid proto int")

    if any([c for c in s[1:idx] if c not in string.digits.encode()]):
        raise ValueError("Invalid proto int")
    
    return idx, int(s[1:idx].decode(), 10)


def parse_proto_str(s: bytes) -> tuple[int, bytes]:
    idx, str_l = parse_proto_int(s)

    if s[idx:idx + 1] != b"\t":
        raise ValueError("Invalid proto str")

    if len(s) < idx + str_l + 1 or len(str_p := s[idx + 1:idx + str_l + 1]) != str_l:
        raise ValueError("Invalid proto str length")
    
    if [c for c in str_p if c in b"\r\n"]:
        raise ValueError("Invalid proto str content")
    
    if s[idx + str_l + 1:idx + str_l + 2] not in [b"\r", b"\t"]:
        raise ValueError("Invalid proto str")
    
    return idx + str_l + 1, str_p


def proto_parse_type(s: bytes) -> tuple[int, PktType]:
    idx = s.index(b"\t")

    return idx, PktType.from_str(s[:idx].decode())