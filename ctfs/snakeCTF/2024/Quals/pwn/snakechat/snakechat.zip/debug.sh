#!/bin/sh
docker compose exec -it bot /bin/sh -c "gdbserver 0.0.0.0:1234 --attach \$(pidof client)"
