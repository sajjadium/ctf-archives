#define _GNU_SOURCE

#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <unistd.h>
#include <threads.h>

#define SIZE 256

#define OPT_SET 1
#define OPT_GET 2
#define OPT_EXIT 3

#define print(x) write(STDOUT_FILENO, (x), sizeof((x)) - 1)
#define panic(x) print(x); exit(1)
#define read(buf, len) read(STDIN_FILENO, (buf), (len))


typedef struct {
    char content[8];
} item_t;

void prompt() {
    print("1. Set item\n");
    print("2. Get item\n");
    print("3. Exit\n");
    print("> ");
}

uint32_t get_int() {
    char buf[24] = {};

    if (read(buf, 23) < 0) {
        panic("err: read\n");
    }

    return strtoul(buf, NULL, 10);
}

void read_exact(void *buf, size_t count) {
    size_t bytes_read = 0;
    while (bytes_read < count) {
        ssize_t bytes = read(buf + bytes_read, count - bytes_read);
        if (bytes < 0) {
            panic("err: read\n");
        }
        bytes_read += bytes;
    }
}

void chall() {
    static thread_local item_t notes[SIZE];

    uint32_t choice, index = 0;

    do {
        prompt();
        choice = get_int();

        switch (choice) {
            case OPT_SET:
                print("Index: ");
                index = get_int();

                print("Content: ");
                read_exact(&(notes[index].content), sizeof(item_t) - 1);
                notes[index].content[sizeof(item_t) - 1] = 0;
                break;

            case OPT_GET:
                print("Sorry, we ran out of budget\n");
                
            case OPT_EXIT:
                break;

            default:
                print("Nope!\n");

        }

    } while (choice != OPT_EXIT);

    print("Bye!\n");
}

int main() {
    print("Welcome to my new local storage implementation\n");
    chall();
    return 0;
}
