import Button from "@/components/Button";
import Logo from "@/components/Logo";
import Link from "next/link";

export default function Home() {
  return (<>
    <div className="m-auto w-full max-w-md bg-white/50 rounded-lg p-6 shadow-lg border border-slate-200">
      <Logo className="size-24 mx-auto mb-4 fill-slate-900/40" />

      <h1 className="text-3xl font-black text-center text-slate-900/80">Welcome to ExploitMe!</h1>
      <p className="text-lg text-bold text-center text-slate-900/60 mt-1">
        The dating app for any kind of hackers.
      </p>

      <div className="mt-4 flex gap-x-4">
        <Link href="/register" className="flex-1">
          <Button>
            Register
          </Button>
        </Link>

        <Link href="/login" className="flex-1">
          <Button>
            Login
          </Button>
        </Link>
      </div>
    </div>
  </>);
}