import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded.userId;

    const { matchId } = req.query;

    if (!matchId) {
      return res.status(400).json({ message: 'Match ID is required' });
    }

    const db = await openDb();

    const match = await db.get('SELECT id, user1_id, user2_id, is_reported FROM matches WHERE id = ?', matchId);
    const currentUser = await db.get('SELECT is_admin FROM users WHERE id = ?', userId);

    if (!match) {
      return res.status(404).json({ message: 'Match not found' });
    }

    if (match.user1_id !== userId && match.user2_id !== userId) {
      if (!(currentUser && currentUser.is_admin && match.is_reported)) {
        return res.status(403).json({ message: 'Forbidden: You are not part of this match.' });
      }
    }

    if (req.method === 'GET') {
      const messages = await db.all(
        'SELECT id, match_id, sender_id, content, created_at FROM messages WHERE match_id = ? ORDER BY created_at ASC',
        matchId
      );
      const messagesWithSenderInfo = messages.map(msg => ({
        ...msg,
        isCurrentUser: msg.sender_id === userId,
      }));
      return res.status(200).json({ messages: messagesWithSenderInfo });
    } else if (req.method === 'POST') {
      const { content } = req.body;
      if (!content) {
        return res.status(400).json({ message: 'Message content is required' });
      }

      const result = await db.run(
        'INSERT INTO messages (match_id, sender_id, content) VALUES (?, ?, ?)',
        matchId, userId, content
      );

      if (result.lastID) {
        return res.status(201).json({ message: 'Message sent', messageId: result.lastID });
      } else {
        return res.status(500).json({ message: 'Failed to send message' });
      }
    } else {
      return res.status(405).json({ message: 'Method Not Allowed' });
    }

  } catch (error) {
    console.error('Chat API error:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
