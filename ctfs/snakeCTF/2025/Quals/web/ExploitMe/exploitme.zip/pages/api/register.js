import openDb from '@/lib/db.js';
import notReallyGoodSanitizer from '@/lib/sanitize';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const { username, email, password } = req.body;

  if (!username || !email || !password) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  try {
    const db = await openDb();
    const hashedPassword = await bcrypt.hash(password, 10);

    if (!notReallyGoodSanitizer(username) || !notReallyGoodSanitizer(email)) {
      return res.status(400).json({ message: 'I\'m sorry, but our 100% amazing waf blocked your request because it detected some words that are too 1337 for us.' });
    }

    const result = await db.run(`INSERT INTO users (username, email, password) VALUES ("${username}", "${email}", "${hashedPassword}")`);

    if (result.lastID) {
      const token = jwt.sign({ userId: result.lastID, username: username }, JWT_SECRET, { expiresIn: '1h' });
      res.status(201).json({ message: 'User registered successfully', token });
    } else {
      res.status(500).json({ message: 'Failed to register user' });
    }
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return res.status(409).json({ message: 'Username or email already exists' });
    }
    console.error('Registration error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}
