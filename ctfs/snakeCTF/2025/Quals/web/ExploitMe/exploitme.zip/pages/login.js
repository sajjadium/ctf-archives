import { useState } from 'react';
import Button from "@/components/Button";
import Input from "@/components/Input";
import Logo from "@/components/Logo";

import { useRouter } from 'next/router';
import Link from "next/link";

export default function Home() {
  const router = useRouter();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleLogin = async () => {
    setMessage('');
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage(data.message);
        localStorage.setItem('jwt', data.token);
        router.push(data.onboarded ? '/explore' : '/onboarding');
      } else {
        setMessage(data.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      setMessage('An error occurred during login.');
    }
  };

  return (<>
    <div className="m-auto w-full max-w-md bg-white/50 rounded-lg p-6 shadow-lg border border-slate-200">
      <Logo className="size-24 mx-auto mb-4 fill-slate-900/40" />

      <h1 className="text-3xl font-black text-center text-slate-900/80">Welcome to ExploitMe!</h1>
      <p className="text-lg text-bold text-center text-slate-900/60 mt-1">
        The dating app for any kind of hackers.
      </p>

      <div className="mt-4 flex flex-col gap-4">
        <Input
          label="Username"
          type="text"
          placeholder="1337_H4X0R"
          className="w-full"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        <Input
          label="Password"
          type="password"
          placeholder="the_easiest_password_ever_created"
          className="w-full"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Button className="w-full" onClick={handleLogin}>
          Login now
        </Button>
        {message && <p className="text-center text-sm mt-2">{message}</p>}
      </div>
    </div>
  </>);
}