import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';
import * as yup from 'yup';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded.userId;

    const db = await openDb();
    const user = await db.get('SELECT is_onboarded FROM users WHERE id = ?', userId);

    if (user && user.is_onboarded) {
      return res.status(409).json({ message: 'User already onboarded.' });
    }

    const onboardingSchema = yup.object().shape({
      role: yup.string().oneOf(['WHITE_HAT', 'BLACK_HAT', 'GREY_HAT']).required(),
      looking_for: yup.string().oneOf(['WHITE_HAT', 'BLACK_HAT', 'GREY_HAT']).required(),
      age: yup.number().min(0).max(250).required(),
      likes: yup.array().of(yup.string()).max(10).required(),
      dislikes: yup.array().of(yup.string()).max(10).required(),
      bio: yup.string().max(500).required(),
      location: yup.string().max(100).required(),
      hacks: yup.array().of(yup.string()).max(10).required(),
      favorite_hacker: yup.string().max(100).required(),
      favorite_song: yup.string().max(100).required(),
      favorite_movie: yup.string().max(100).required(),
      touches_grass: yup.boolean().oneOf([false], 'Captcha verification failed: touchesGrass must be false.').required(),
      yt_embed: yup.string().url(),
    });

    try {
      await onboardingSchema.validate(req.body, { abortEarly: false });
    } catch (validationError) {
      return res.status(400).json({ message: validationError.errors.join(', ') });
    }

    const { 
      role, 
      looking_for, 
      age, 
      likes, 
      dislikes, 
      bio, 
      location, 
      hacks, 
      favorite_hacker, 
      favorite_song, 
      favorite_movie, 
      yt_embed 
    } = req.body;

    const updateQuery = `
      UPDATE users
      SET
        role = ?,
        looking_for = ?,
        age = ?,
        likes = ?,
        dislikes = ?,
        bio = ?,
        location = ?,
        hacks = ?,
        favorite_hacker = ?,
        favorite_song = ?,
        favorite_movie = ?,
        yt_embed = ?,
        is_onboarded = TRUE
      WHERE id = ?
    `;

    const result = await db.run(
      updateQuery,
      role,
      looking_for,
      age,
      JSON.stringify(likes),
      JSON.stringify(dislikes),
      bio,
      location,
      JSON.stringify(hacks),
      favorite_hacker,
      favorite_song,
      favorite_movie,
      yt_embed,
      userId
    );

    if (result.changes > 0) {
      res.status(200).json({ message: 'Onboarding complete!' });
    } else {
      res.status(404).json({ message: 'User not found or no changes made.' });
    }

  } catch (error) {
    console.error('Onboarding API error:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
