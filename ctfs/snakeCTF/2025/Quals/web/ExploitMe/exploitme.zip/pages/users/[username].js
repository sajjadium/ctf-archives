import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Button from '@/components/Button';
import Logo from '@/components/Logo';

const Names = {
  WHITE_HAT: "White Hat",
  BLACK_HAT: "Black Hat",
  GREY_HAT: "Grey Hat",
};

const UserProfile = () => {
  const router = useRouter();
  const { username } = router.query;
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [matchStatus, setMatchStatus] = useState(null);
  const [likeLoading, setLikeLoading] = useState(false);

  const fetchUserData = useCallback(async () => {
    const token = localStorage.getItem("jwt");
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const res = await fetch(`/api/users/${username}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else if (res.status === 403) {
        router.push('/onboarding');
      } else {
        const errData = await res.json();
        setError(errData.message || 'Failed to fetch user data');
        console.error('Error fetching user:', errData);
      }
    } catch (err) {
      setError('Network error or unexpected issue.');
      console.error('Network error fetching user:', err);
    } finally {
      setLoading(false);
    }
  }, [username, router]);

  const fetchMatchStatus = useCallback(async () => {
    const token = localStorage.getItem("jwt");
    if (!token || !username) return;

    try {
      const res = await fetch(`/api/match-status?targetUsername=${username}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setMatchStatus(data);
      } else {
        console.error("Failed to fetch match status:", await res.json());
      }
    } catch (error) {
      console.error('Network error fetching match status:', error);
    }
  }, [username]);

  useEffect(() => {
    if (!username) return;
    fetchUserData();
    fetchMatchStatus();
  }, [username, fetchUserData, fetchMatchStatus]);

  const handleLike = async () => {
    setLikeLoading(true);
    const token = localStorage.getItem("jwt");
    if (!token) {
      router.push('/login');
      setLikeLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/like', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ likedUsername: username }),
      });

      if (res.ok) {
        const data = await res.json();
        alert(data.message);
        fetchMatchStatus();
      } else {
        const errData = await res.json();
        alert(errData.message || 'Failed to record like');
      }
    } catch (error) {
      console.error('Error liking user:', error);
      alert('An error occurred while liking.');
    } finally {
      setLikeLoading(false);
    }
  };

  const handleChat = () => {
    if (matchStatus && matchStatus.isMatch && matchStatus.matchId) {
      router.push(`/chat/${matchStatus.matchId}`);
    } else {
      alert("You can only chat with users you've matched with!");
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-xl text-gray-700">Loading user profile...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-xl text-red-500">Error: {error}</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-xl text-gray-700">User not found.</p>
      </div>
    );
  }

  return (<>
    <Logo className="size-24 mx-auto my-4 fill-slate-900/40" />

    <div className="max-w-2xl w-full bg-white/50 rounded-lg shadow-lg border border-slate-200 mx-auto my-2 py-6 px-8">
      <div className="flex flex-col items-center">
        {user.pictures && user.pictures.length > 0 && (
          <img src={user.pictures[0]} alt={user.username} className="w-48 h-48 object-cover rounded-lg mb-4" />
        )}
        <h1 className="text-4xl font-bold text-gray-800 mb-2">{user.username}</h1>
        <p className="text-gray-600 text-lg">{user.bio}</p>
        <p className="text-gray-500 text-sm">{user.location}</p>

        {matchStatus && (
          <div className="mt-4 w-full">
            {matchStatus.isMatch ? (
              <Button onClick={handleChat} disabled={likeLoading}>Chat with {user.username}</Button>
            ) : (
              <Button onClick={handleLike} disabled={likeLoading || matchStatus.currentUserLiked}>
                {matchStatus.currentUserLiked ? 'Liked' : 'Like'}
              </Button>
            )}
          </div>
        )}
      </div>

      <div className="mt-8 grid grid-cols-1 gap-6">
        <div>
          <h2 className="text-2xl font-semibold text-gray-700 mb-3">Details</h2>
          <p className="text-gray-600"><strong>Age:</strong> {user.age}</p>
          <p className="text-gray-600"><strong>Is a:</strong> {Names[user.role]}</p>
          <p className="text-gray-600"><strong>Looking For:</strong> {Names[user.looking_for]}</p>
        </div>

        <div>
          <h2 className="text-2xl font-semibold text-gray-700 mb-3">Interests</h2>
          {user.likes && user.likes.length > 0 && (
            <p className="text-gray-600"><strong>Likes:</strong> {user.likes.join(', ')}</p>
          )}
          {user.dislikes && user.dislikes.length > 0 && (
            <p className="text-gray-600"><strong>Dislikes:</strong> {user.dislikes.join(', ')}</p>
          )}
          {user.hacks && user.hacks.length > 0 && (
            <p className="text-gray-600"><strong>Hacks:</strong> {user.hacks.join(', ')}</p>
          )}
        </div>

        <div>
          <h2 className="text-2xl font-semibold text-gray-700 mb-3">Favorites</h2>
          <p className="text-gray-600"><strong>Favorite Hacker:</strong> {user.favorite_hacker}</p>
          <p className="text-gray-600"><strong>Favorite Song:</strong> {user.favorite_song}</p>
          <p className="text-gray-600"><strong>Favorite Movie:</strong> {user.favorite_movie}</p>
        </div>

        {user.yt_embed && (
          <iframe
            width={560}
            height={315}
            src={user.yt_embed}
            title="YouTube video player"
            frameBorder={0}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            referrerPolicy="strict-origin-when-cross-origin"
            allowFullScreen=""
          />
        )}
      </div>
    </div>
  </>);
};

export default UserProfile;
