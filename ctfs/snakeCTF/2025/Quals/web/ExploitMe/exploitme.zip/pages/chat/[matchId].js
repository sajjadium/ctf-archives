import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/router';
import Head from 'next/head';
import Input from '@/components/Input';
import Button from '@/components/Button';
import { jwtDecode } from 'jwt-decode';

const ChatPage = () => {
  const router = useRouter();
  const { matchId } = router.query;
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentUserId, setCurrentUserId] = useState(null);

  useEffect(() => {
    const token = localStorage.getItem("jwt");
    if (token) {
      try {
        const decoded = jwtDecode(token);
        setCurrentUserId(decoded.userId);
      } catch (err) {
        console.error("Failed to decode JWT:", err);
        router.push('/login');
      }
    } else {
      router.push('/login');
    }
  }, [router]);

  const fetchMessages = useCallback(async () => {
    if (!matchId || currentUserId === null) return;

    const token = localStorage.getItem("jwt");
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const res = await fetch(`/api/chat/${matchId}`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (res.ok) {
        const data = await res.json();
        setMessages(data.messages);
      } else if (res.status === 403) {
        setError('You are not authorized to view this chat.');
      } else {
        const errData = await res.json();
        setError(errData.message || 'Failed to fetch messages');
        console.error('Error fetching messages:', errData);
      }
    } catch (err) {
      setError('Network error or unexpected issue.');
      console.error('Network error fetching messages:', err);
    } finally {
      setLoading(false);
    }
  }, [matchId, currentUserId, router]);

  useEffect(() => {
    if (currentUserId !== null) {
      fetchMessages();
      const interval = setInterval(fetchMessages, 3000);
      return () => clearInterval(interval);
    }
  }, [fetchMessages, currentUserId]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim() || currentUserId === null) return;

    const token = localStorage.getItem("jwt");
    if (!token) {
      router.push('/login');
      return;
    }

    try {
      const res = await fetch(`/api/chat/${matchId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ content: newMessage }),
      });

      if (res.ok) {
        setNewMessage('');
        fetchMessages();
      } else {
        const errData = await res.json();
        alert(errData.message || 'Failed to send message');
      }
    } catch (error) {
      console.error('Error sending message:', error);
      alert('An error occurred while sending message.');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-xl text-gray-700">Loading chat...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-xl text-red-500">Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Head>
        <title>Chat - Match {matchId}</title>
      </Head>
      <div className="flex-grow p-4 overflow-y-auto">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-4">Chat with Match {matchId}</h1>
        <div className="flex flex-col space-y-2">
          {messages.map((msg) => (
            <div key={msg.id} className={`p-3 rounded-lg ${msg.isCurrentUser ? 'bg-blue-500 text-white self-end' : 'bg-gray-300 text-gray-800 self-start'}`}>
              <p>{msg.content}</p>
              <span className="text-xs opacity-75">{new Date(msg.created_at).toLocaleTimeString()}</span>
            </div>
          ))}
        </div>
      </div>
      <form onSubmit={handleSendMessage} className="p-4 bg-white border-t border-gray-200 flex">
        <Input
          type="text"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          placeholder="Type your message..."
          className="flex-grow mr-2"
        />
        <Button type="submit">Send</Button>
      </form>
    </div>
  );
};

export default ChatPage;
