import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';
import * as yup from 'yup';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

const editProfileSchema = yup.object().shape({
  role: yup.string().oneOf(['WHITE_HAT', 'BLACK_HAT', 'GREY_HAT']),
  looking_for: yup.string().oneOf(['WHITE_HAT', 'BLACK_HAT', 'GREY_HAT']),
  age: yup.number().min(0).max(250),
  likes: yup.array().of(yup.string()).max(10),
  dislikes: yup.array().of(yup.string()).max(10),
  bio: yup.string().max(500),
  location: yup.string().max(100),
  hacks: yup.array().of(yup.string()).max(10),
  favorite_hacker: yup.string().max(100),
  favorite_song: yup.string().max(100),
  favorite_movie: yup.string().max(100),
  yt_embed: yup.string().url(),
});

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded.userId;

    const db = await openDb();
    const user = await db.get('SELECT is_onboarded FROM users WHERE id = ?', userId);

    if (user && !user.is_onboarded) {
      return res.status(403).json({ message: 'User has not completed onboarding.' });
    }

    let validated;

    try {
      validated = await editProfileSchema.validate(req.body, { abortEarly: false });
    } catch (validationError) {
      return res.status(400).json({ message: validationError.errors.join(', ') });
    }

    const setClause = Object.keys(validated).map(field => `"${field}" = ?`).join(', ');
    const values = Object.values(validated);

    const updateQuery = `UPDATE users SET ${setClause} WHERE id = ?`;
    values.push(userId);

    const result = await db.run(updateQuery, ...values);


    if (result.changes > 0) {
      res.status(200).json({ message: 'Profile updated successfully!' });
    } else {
      res.status(404).json({ message: 'User not found or no changes made.' });
    }

  } catch (error) {
    console.error('Edit profile API error:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
