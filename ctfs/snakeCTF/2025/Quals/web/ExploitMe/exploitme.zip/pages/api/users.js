import openDb from '@/lib/db.js';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret'; // Use environment variable in production

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ message: 'Method Not Allowed' });
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  const token = authHeader.split(' ')[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const userId = decoded.userId;

    const { limit = 10, offset = 0 } = req.query;

    const db = await openDb();

    const users = await db.all(
      `SELECT id, username, email, role, looking_for, age, likes, dislikes, bio, location, hacks, favorite_hacker, favorite_song, favorite_movie, pictures
       FROM users
       WHERE id != ? AND is_onboarded = TRUE
       LIMIT ? OFFSET ?`,
      userId,
      Number(limit),
      Number(offset)
    );

    const parsedUsers = users.map(user => ({
      ...user,
      likes: user.likes ? JSON.parse(user.likes) : [],
      dislikes: user.dislikes ? JSON.parse(user.dislikes) : [],
      hacks: user.hacks ? JSON.parse(user.hacks) : [],
      pictures: user.pictures ? JSON.parse(user.pictures) : [],
    }));

    res.status(200).json({ users: parsedUsers });

  } catch (error) {
    console.error('Error fetching users:', error);
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    res.status(500).json({ message: 'Internal server error' });
  }
}
