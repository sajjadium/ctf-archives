export default function Input({
    className,
    label,
    ...props
}) {
    return (<>
        <div className="flex flex-col gap-y-1">
            {label && <label className="text-sm font-medium text-slate-900/80">{label}</label>}
            <input
                className={`bg-white border border-slate-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-slate-900/50 focus:border-transparent ${className}`}
                {...props}
            />
        </div>
    </>);
}