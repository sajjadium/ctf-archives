import { openDb } from "@/lib/database";
import { ACTIONS } from "@/lib/actions";
import { authRequired } from "@/lib/auth";
import { sanitizeInput } from "@/lib/validate";

export default async function handler(req, res) {
    if (req.method !== "POST") {
        res.setHeader("Allow", ["POST"]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }

    const userData = await authRequired(req, res);
    if (!userData) return;

    if (userData.groupName == "User") {
        return res.status(403).json({ error: "You do not have permission to perform this action" });
    }

    const { action, params } = req.body;

    if (!action || !ACTIONS[action]) {
        return res.status(400).json({ error: "Invalid action specified" });
    }

    const db = await openDb();
    const actionConfig = ACTIONS[action];

    const sanitizedParams = {};
    for (const key in actionConfig.params) {
        if (actionConfig.params[key].required && typeof params[key] !== actionConfig.params[key].type) {
            return res.status(400).json({ error: `${key} is required` });
        }
        sanitizedParams[key] = sanitizeInput(params[key]);
    }

    try {
        const result = await actionConfig.execute(db, sanitizedParams);
        await db.run(
            "INSERT INTO AuditLogs (userId, actionType, actionDetails, timestamp) VALUES (?, ?, ?, ?)",
            userData.userId,
            action,
            JSON.stringify(sanitizedParams),
            new Date().toISOString()
        );
        res.status(200).json(result);
    } catch (error) {
        console.error("Action execution error:", error);
        res.status(500).json({ error: error.message || "An error occurred while executing the action" });
    }
}