import { getUserFromId, openDb } from "@/lib/database";
import { authRequired } from "@/lib/auth";

import CORS from "cors";

const cors = CORS({
    origin: "*",
    methods: ["GET", "POST", "PATCH", "DELETE"],
});

function runMiddleware(req, res, fn) {
    return new Promise((resolve, reject) => {
        fn(req, res, (result) => {
            if (result instanceof Error) return reject(result)
            return resolve(result)
        })
    })
}

export default async function handler(req, res) {
    await runMiddleware(req, res, cors);

    if (req.method !== "GET") {
        res.setHeader("Allow", ["GET"]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }

    const userData = await authRequired(req, res, true, req.query.id);
    if (!userData) return;

    const db = await openDb();
    const user = await getUserFromId(db, userData.userId);
    if (!user)
        return res.status(404).json({ valid: false });

    return res.status(200).json({ valid: true });
}