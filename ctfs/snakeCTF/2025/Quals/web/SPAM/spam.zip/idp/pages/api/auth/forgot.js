import crypto from "crypto";
import bcrypt from "bcrypt";

import { getUserFromId, getUserFromEmail, openDb } from "@/lib/database";
import { validatePassword } from "@/lib/validate";

export default async function handler(req, res) {
  if (!["POST", "PATCH"].includes(req.method)) {
    res.setHeader("Allow", ["POST", "PATCH"]);
    return res.status(405).end(`Method ${req.method} Not Allowed`);
  }

  const db = await openDb();

  if (req.method === "POST") {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: "Email is required" });
    }

    const user = await getUserFromEmail(db, email);
    if (!user) {
      return res.status(200).json({ message: "If the user exists, a password reset link will be shown on their dashboard." });
    }

    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 3600000);
    await db.run(
      "INSERT INTO PasswordResetTokens (userId, token, expiresAt, used) VALUES (?, ?, ?, ?)",
      user.id,
      token,
      expiresAt,
      false
    );

    return res.status(200).json({ message: "If the user exists, a password reset link will be shown on their dashboard." });
  } else if (req.method === "PATCH") {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) {
      return res.status(400).json({ error: "Token and new password are required" });
    }

    const tokenData = db.get("SELECT * FROM PasswordResetTokens WHERE token = ?", token);

    if (!tokenData) {
      return res.status(400).json({ error: "Invalid or expired token" });
    }
    const tokenUser = await getUserFromId(db, tokenData.userId);

    if (!tokenUser) {
      return res.status(400).json({ error: "Invalid user for the provided token" });
    }

    if (tokenData.used) {
      return res.status(400).json({ error: "This token has already been used" });
    }

    const now = new Date();
    if (new Date(tokenData.expiresAt) < now) {
      return res.status(400).json({ error: "This token has expired" });
    }
    
    if (!validatePassword(newPassword)) {
      return res.status(400).json({ error: "Password must be at least 8 characters long and contain at least one number and one special character and one capital letter" });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await db.run("UPDATE Users SET password = ? WHERE id = ?", hashedPassword, tokenUser.id);
    await db.run("UPDATE PasswordResetTokens SET used = ? WHERE token = ?", true, token);

    return res.status(200).json({ message: "Password has been successfully reset." });
  }
}