import Link from "next/link";

import Input from "@/components/Input";
import Button from "@/components/Button";

export default function Signup() {
    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = {
            name: e.target.name.value,
            surname: e.target.surname.value,
            email: e.target.email.value,
            password: e.target.password.value,
        };

        const response = await fetch('/api/auth/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("Signup failed:", errorData);
            alert("Signup failed: " + errorData.error);
            return;
        }

        const token = await response.text();
        if (token) {
            document.cookie = `token=${token}; path=/; max-age=3600`;
            console.log("Signup successful.");
            window.location.href = "/dashboard";
        }
    };

    return (<>
        <h1 className="text-3xl font-bold text-center mt-10">
            Signup
        </h1>

        <form onSubmit={handleSubmit} className="flex flex-col items-center mt-4">
            <Input
                id="name"
                type="text"
                placeholder="Name"
                className="mb-4 w-full max-w-xs"
            />

            <Input
                id="surname"
                type="text"
                placeholder="Surname"
                className="mb-4 w-full max-w-xs"
            />

            <Input
                id="email"
                type="email"
                placeholder="Email"
                className="mb-4 w-full max-w-xs"
            />
            
            <Input
                id="password"
                type="password"
                placeholder="Password"
                className="mb-4 w-full max-w-xs"
            />

            <Button className="w-full max-w-xs">
                Signup
            </Button>
        </form>
        
        <div className="text-center mt-6 flex flex-col items-center text-blue-500 text-sm">
            <Link href="/signin" className="hover:underline">
                Already have an account? Signin here.
            </Link>
        </div>
    </>);
};

export function getServerSideProps(context) {
    const { req } = context;
    const token = req.cookies.token;

    if (token) {
        return {
            redirect: {
                destination: '/dashboard',
                permanent: false,
            },
        };
    }

    return {
        props: {},
    };
}