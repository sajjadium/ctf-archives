import jwt from "jsonwebtoken";
import { getUserFromId, openDb } from "@/lib/database";
import Button from "@/components/Button";
import Link from "next/link";

export default function AuthorizePage({
    user,
    service,
    token,
    error
}) {
    if (error) {
        return (
            <div className="max-w-lg mt-10 mx-auto bg-red-500/10 border-red-500 p-4 border rounded-md">
                <h2 className="text-xl font-semibold">Error</h2>
                <p>{error}</p>
            </div>
        );
    }

    return (<>
        <div className="max-w-lg mt-10 mx-auto bg-blue-500/10 border-blue-500 p-4 border rounded-md">
            <h2 className="text-xl font-semibold">
                Log in to {service.name}
            </h2>
            <p className="text-xs italic">
                {service.description || "No description available."}
            </p>

            <p className="mt-2">
                You&apos;re about to log in to <strong>{service.name}</strong> as <strong>{user.firstName} {user.lastName}</strong>.
            </p>

            <Link href={`${service.redirectUri}?token=${token}`}>
                <Button id="authorize-btn" className="mt-2 w-full">
                    Authorize access
                </Button>
            </Link>
        </div>
    </>);
};


export async function getServerSideProps(context) {
    const { req } = context;
    const token = req.cookies.token;
    const serviceId = context.query.serviceId;

    if (!serviceId) {
        return {
            props: {
                error: "Service ID is required."
            }
        };
    }

    if (!token) {
        return {
            props: {
                error: "You're not logged in. Please log in and try again."
            }
        };
    }

    try {
        const user = jwt.verify(token, process.env.JWT_SECRET);

        const db = await openDb();
        const userData = await getUserFromId(db, user.userId);
        delete userData.password;

        let query = "SELECT * FROM Services WHERE id = ?";
        if (userData.groupId !== 0) query += " AND hidden = 0";

        const service = await db.get(query, serviceId);
        if (!service) {
            return {
                props: {
                    error: "Service not found or not accessible."
                }
            };
        }

        const authorizationToken = jwt.sign(
            { userId: userData.id, external: true, serviceId: service.id },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        return {
            props: {
                user: userData,
                token: authorizationToken,
                service,
            },
        };
    } catch (error) {
        console.error("JWT verification failed:", error);
        return {
            redirect: {
                destination: '/signin',
                permanent: false,
            },
        };
    }
}