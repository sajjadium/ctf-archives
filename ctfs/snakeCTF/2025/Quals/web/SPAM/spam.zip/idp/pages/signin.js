import Link from "next/link";

import Input from "@/components/Input";
import Button from "@/components/Button";

export default function Signin() {
    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = {
            email: e.target.email.value,
            password: e.target.password.value,
        };

        const response = await fetch('/api/auth/signin', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(formData),
        });

        if (!response.ok) {
            const errorData = await response.json();
            console.error("Signup failed:", errorData);
            alert("Signup failed: " + errorData.error);
            return;
        }

        const token = await response.text();
        if (token) {
            document.cookie = `token=${token}; path=/; max-age=3600`;
            console.log("Signin successful.");
            window.location.href = "/dashboard";
        }
    };

    return (<>
        <h1 className="text-3xl font-bold text-center mt-10">
            Signin
        </h1>

        <form onSubmit={handleSubmit} className="flex flex-col items-center mt-4">
            <Input
                id="email"
                type="email"
                placeholder="Email"
                className="mb-4 w-full max-w-xs"
            />

            <Input
                id="password"
                type="password"
                placeholder="Password"
                className="mb-4 w-full max-w-xs"
            />

            <Button className="w-full max-w-xs">
                Signup
            </Button>
        </form>

        <div className="text-center mt-6 flex flex-col items-center text-blue-500 text-sm">
            <Link href="/signup" className="hover:underline">
                Don&apos;t have an account? Signup here.
            </Link>

            <Link href="/forgot" className="hover:underline">
                Forgot your password?
            </Link>
        </div>
    </>);
};

export function getServerSideProps(context) {
    const { req } = context;
    const token = req.cookies.token;

    if (token) {
        return {
            redirect: {
                destination: '/dashboard',
                permanent: false,
            },
        };
    }

    return {
        props: {},
    };
}