const sqlite3 = require("sqlite3");
const { open } = require("sqlite");

(async () => {
    try {
        const db = await open({
            filename: process.env.DB_FILE || "./database.db",
            driver: sqlite3.Database,
        });

        await db.exec(`
            CREATE TABLE IF NOT EXISTS Users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE,
            password TEXT,
            firstName TEXT,
            lastName TEXT,
            groupId INTEGER,
            FOREIGN KEY(groupId) REFERENCES Groups(id)
            );

            CREATE TABLE IF NOT EXISTS Groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE
            );

            CREATE TABLE IF NOT EXISTS PasswordResetTokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            token TEXT UNIQUE,
            userId INTEGER,
            expiresAt DATETIME,
            used BOOLEAN DEFAULT FALSE,
            FOREIGN KEY(userId) REFERENCES Users(id)
            );

            CREATE TABLE IF NOT EXISTS AuditLogs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            userId INTEGER,
            actionType TEXT,
            actionDetails TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(userId) REFERENCES Users(id)
            );

            CREATE TABLE IF NOT EXISTS Services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            hidden BOOLEAN DEFAULT 0,
            description TEXT,
            homepage TEXT,
            redirectUri TEXT
            );

            -- Insert groups
            INSERT OR IGNORE INTO Groups (id, name) VALUES (0, 'System');
            INSERT OR IGNORE INTO Groups (id, name) VALUES (1, 'Super Admin');
            INSERT OR IGNORE INTO Groups (id, name) VALUES (2, 'Admin');
            INSERT OR IGNORE INTO Groups (id, name) VALUES (3, 'User');

            -- Insert admin user
            INSERT OR IGNORE INTO Users (id, email, password, firstName, lastName, groupId)
            VALUES (0, 'admin@spam.gov.it', '', 'Admin', 'User', 2);

            -- Insert services
            INSERT OR IGNORE INTO Services (id, name, hidden, description, homepage, redirectUri)
            VALUES (0, 'Testing service', 1, 'This service is used to test random functionality', '${process.env.TEST_BASE_URL || "http://localhost:3001"}', '${process.env.TEST_BASE_URL || "http://localhost:3001"}/callback');

            INSERT OR IGNORE INTO Services (id, name, hidden, description, homepage, redirectUri)
            VALUES (1, 'INBS', 0, 'Istituto Nazionale per la Burocrazia Sfinente (National Institute for Exhausting Bureaucracy)', '${process.env.INBS_BASE_URL || "http://localhost:3002"}', '${process.env.INBS_BASE_URL || "http://localhost:3002"}/callback');

            INSERT OR IGNORE INTO Services (id, name, hidden, description, homepage, redirectUri)
            VALUES (2, 'Agenzia delle Uscite', 0, 'Revenue Exit Agency, Making Poverty Possible', '${process.env.AGENZIA_USCITE_BASE_URL || "http://localhost:3003"}', '${process.env.AGENZIA_USCITE_BASE_URL || "http://localhost:3003"}/callback');

            INSERT OR IGNORE INTO Services (id, name, hidden, description, homepage, redirectUri)
            VALUES (3, 'ASP', 0, 'Attendi Sempre di Più (Always Wait More)', '${process.env.ASP_BASE_URL || "http://localhost:3004"}', '${process.env.ASP_BASE_URL || "http://localhost:3004"}/callback');

            INSERT OR IGNORE INTO Services (id, name, hidden, description, homepage, redirectUri)
            VALUES (4, 'DSW', 0, 'Department of Slow Workers', '${process.env.DSW_BASE_URL || "http://localhost:3005"}', '${process.env.DSW_BASE_URL || "http://localhost:3005"}/callback');
        `);
        console.log("Database setup completed successfully.");
    } catch (error) {
        console.error("Error during database setup:", error);
    }
})();