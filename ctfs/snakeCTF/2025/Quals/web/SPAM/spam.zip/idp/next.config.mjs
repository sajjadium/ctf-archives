/** @type {import('next').NextConfig} */

// Disable SSL verification
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

const nextConfig = {
  reactStrictMode: true,
};

export default nextConfig;
