import { useState } from "react";

import jwt from "jsonwebtoken";

import clsx from "clsx";
import Input from "@/components/Input";

import { getUserFromId, openDb } from "@/lib/database";
import { sanitizeInput } from "@/lib/validate";
import Button from "@/components/Button";
import { ACTIONS } from "@/lib/actions";
import Link from "next/link";

export default function Dashboard({
    user,
    auditData
}) {
    const [ActionData, setActionData] = useState({
        action: Object.keys(ACTIONS)[0],
        params: ACTIONS[Object.keys(ACTIONS)[0]].params || {}
    });
    const [ActionParams, setActionParams] = useState({});
    const [ActionResult, setActionResult] = useState({
        success: false,
        data: null,
    });

    const handleSubmit = async (e) => {
        e.preventDefault();

        const token = document.cookie.split('; ').find(row => row.startsWith('token=')).replace("token=", "");

        const res = await fetch("/api/actions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({
                action: ActionData.action,
                params: ActionParams
            })
        });
        const result = await res.json();

        setActionResult({
            success: res.ok,
            data: result
        });
    };

    return (<>
        <h1 className="text-2xl font-bold text-center mt-10">
            Welcome to the Dashboard, {user.firstName}!
        </h1>

        <div className="mt-10 max-w-2xl mx-auto">
            <h2 className="text-xl font-semibold mb-4">User Information</h2>
            <div className="bg-white/5 p-6 rounded-lg shadow-md">
                <p><strong>Name:</strong> {user.firstName} {user.lastName}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Group ID:</strong> {user.groupId}</p>
            </div>
        </div>

        {
            user.passwordResetToken && (
                <div className="mt-6 max-w-2xl mx-auto">
                    <h2 className="text-xl font-semibold mb-4">
                        Someone requested a password reset for your account.
                    </h2>
                    <div className="bg-white/5 p-6 rounded-lg shadow-md">
                        <p>
                            If you did not request this, you can ignore this message (it will disappear in 10 minutes). Otherwise, you can reset your password by clicking the button below.
                        </p>
                        <Link href={`/forgot?token=${user.passwordResetToken}`}>
                            <Button className="mt-4 w-full">
                                Reset Password
                            </Button>
                        </Link>
                    </div>
                </div>
            )
        }
    </>);
}

export async function getServerSideProps(context) {
    const { req } = context;
    const token = req.cookies.token;

    if (!token) {
        return {
            redirect: {
                destination: '/signin',
                permanent: false,
            },
        };
    }

    try {
        const user = jwt.verify(token, process.env.JWT_SECRET);

        const db = await openDb();
        const userData = await getUserFromId(db, user.userId);
        delete userData.password;

        const tokens =
            (await db.all("SELECT * FROM PasswordResetTokens WHERE userId = ? AND used = 0", [user.userId]))
            .filter(token => {
                const now = new Date();
                return new Date(token.expiresAt) > now;
            });

        if (tokens.length > 0) {
            userData.passwordResetToken = tokens[tokens.length - 1].token;
        }

        return {
            props: {
                user: userData,
            },
        };
    } catch (error) {
        console.error("JWT verification failed:", error);
        return {
            redirect: {
                destination: '/signin',
                permanent: false,
            },
        };
    }
}