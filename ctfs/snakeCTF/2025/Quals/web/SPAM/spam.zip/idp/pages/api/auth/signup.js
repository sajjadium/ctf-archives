import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";

import { openDb } from "@/lib/database";
import { validateEmail, sanitizeInput, validatePassword } from "@/lib/validate";

export default async function handler(req, res) {
    if (req.method !== "POST") {
        res.setHeader("Allow", ["POST"]);
        return res.status(405).end(`Method ${req.method} Not Allowed`);
    }

    const {
        email,
        password,
        name,
        surname,
    } = req.body;

    if (!email || !password || !name || !surname) {
        return res.status(400).json({ error: "All fields are required" });
    }

    if (!validateEmail(email)) {
        return res.status(400).json({ error: "Invalid email format" });
    }

    if (!validatePassword(password)) {
        return res.status(400).json({ error: "Password must be at least 8 characters long and contain at least one number and one special character and one capital letter" });
    }

    const sanitizedUser = {
        email: sanitizeInput(email),
        password: sanitizeInput(password),
        name: sanitizeInput(name),
        surname: sanitizeInput(surname),
        groupId: 3, // Default to 'User' group
    };

    const db = await openDb();
    const existingUser = await db.get("SELECT * FROM Users WHERE email = ?", sanitizedUser.email);

    if (existingUser) {
        return res.status(400).json({ error: "User already exists" });
    }

    const hashedPassword = await bcrypt.hash(sanitizedUser.password, 10);

    const result = await db.run(
        "INSERT INTO Users (email, password, firstName, lastName, groupId) VALUES (?, ?, ?, ?, ?)",
        sanitizedUser.email,
        hashedPassword,
        sanitizedUser.name,
        sanitizedUser.surname,
        sanitizedUser.groupId
    );

    if (result.changes === 0) {
        return res.status(500).json({ error: "Failed to create user" });
    }

    const userId = result.lastID;
    const token = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "1h" });

    res.status(201).send(token);
}