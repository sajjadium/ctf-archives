#!/usr/bin/env python3

from base64 import b64decode
import tempfile
import os

data = input("Send your base64 encoded JavaScript exploit: ")
print(data)
data = b64decode(data)

with tempfile.NamedTemporaryFile() as f:
    f.write(data)
    f.flush()

    os.system(f"/app/d8 {f.name}")
