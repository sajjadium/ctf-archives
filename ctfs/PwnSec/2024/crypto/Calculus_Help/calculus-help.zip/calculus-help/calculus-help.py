from secret import flag,f, integrate
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from hashlib import sha256

key = f'{integrate(f, 2.420, 1.77415).evalf():.2f}'

def encrypt(key, data):
    key = sha256(str(key).encode('utf-8')).digest()[16:]
    iv =  sha256(str(key).encode('utf-8')).digest()[:16]
    cipher = AES.new(key, AES.MODE_CBC, iv = iv)
    ct_bytes = cipher.encrypt(pad(data, AES.block_size))
    return ct_bytes

ct = encrypt(key, flag)

def get_hint(x):
    return f(x)

def get_flag():
    return ct.hex()

def main():
    print('''
█░█░█▀▀░█░░░█▀▀░█▀█░█▄█░█▀▀░░░▀█▀░█▀█░░░█▄█░█░█░░░█▀▀░█▀▀░█▀▀░█░█░█▀▄░█▀▀
█▄█░█▀▀░█░░░█░░░█░█░█░█░█▀▀░░░░█░░█░█░░░█░█░░█░░░░▀▀█░█▀▀░█░░░█░█░█▀▄░█▀▀
▀░▀░▀▀▀░▀▀▀░▀▀▀░▀▀▀░▀░▀░▀▀▀░░░░▀░░▀▀▀░░░▀░▀░░▀░░░░▀▀▀░▀▀▀░▀▀▀░▀▀▀░▀░▀░▀▀▀
░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
░█▀▀░█▀█░█▀▀░█▀▄░█░█░█▀█░▀█▀░▀█▀░█▀█░█▀█░░░█▀▀░█▀▀░█▀▄░█░█░▀█▀░█▀▀░█▀▀░█░
░█▀▀░█░█░█░░░█▀▄░░█░░█▀▀░░█░░░█░░█░█░█░█░░░▀▀█░█▀▀░█▀▄░▀▄▀░░█░░█░░░█▀▀░▀░
░▀▀▀░▀░▀░▀▀▀░▀░▀░░▀░░▀░░░░▀░░▀▀▀░▀▀▀░▀░▀░░░▀▀▀░▀▀▀░▀░▀░░▀░░▀▀▀░▀▀▀░▀▀▀░▀░
''')

    hint_ctr = 0
    while True:
        try:
            print("1. Get a hint")
            print("2. Get the flag")
            print("3. Exit")
            option = int(input("Choose an option (1/2/3): "))

            if option == 1:
                if hint_ctr > 2:
                    print("\n[Note] You have exceeded the maximum number of hints allowed.\n")
                    continue
                hint_ctr += 1
                x = float(input("Enter a number for the hint: "))
                print(get_hint(x))
            elif option == 2:
                print(f"\nHere is the flag: {get_flag()}\n")
            elif option == 3:
                print("\nThank you for using the system. Goodbye!\n")
                break
            else:
                print("\nInvalid selection. Please enter 1, 2, or 3.\n")
        except Exception as e:
            print(f"\nAn error occurred: {str(e)}. Please try again.\n")
            continue


if __name__ == '__main__':
    main()