from secret import FLAG
from Crypto.Util.number import *
import random

def Funny(s, fraction = 3):
    s_list = list(s)    
    num_to_replace = len(s_list) // fraction
    indices_to_replace = random.sample(range(len(s_list)), num_to_replace)
    for i in indices_to_replace:
        s_list[i] = '?'
    return ''.join(s_list)

def to_base_9(num):
    result = ""
    while num > 0:
        result += str(num % 9)
        num //= 9
    return result[::-1]


pt = bytes_to_long(FLAG)
e = 0x10001
p, q = getPrime(256), getPrime(256)
n = p * q
ct = pow(pt, e, n)

p, q = bin(p)[2:], bin(q)[2:]

k = len(p) // 2
p_parts = [p[:k], p[k:]]
q_parts = [q[:k], q[k:]]


p_hints = [Funny(p_parts[0]), Funny(to_base_9(int(p_parts[1], 2)), 6)]
q_hints = [Funny(to_base_9(int(q_parts[0], 2)), 6), Funny(q_parts[1])]


print(f"n = {n}")
print(f"e = {e}")
print(f"ct = {ct}")
print(f"p_hints = {[p_hints[1]]}")
print(f"q_hints = {q_hints}")
