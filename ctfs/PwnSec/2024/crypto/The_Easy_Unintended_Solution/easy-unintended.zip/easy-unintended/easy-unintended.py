from Crypto.Util.number import *
from math import prod
import hashlib
from secret import FLAG

FLAG = bytes_to_long(FLAG)
MENU = "1- [A]dd key\n2- [E]ncrypt flag\n3- [Q]uit\n"
keys = [getPrime(1024)]
e = 0x10001

def pad(m, n):
    # A totally original padding scheme that I 100% no doubt came up with (:
    y = int(hashlib.sha256(str(keys).encode()).hexdigest(), 16)
    while m < n:
        m *= y
    return m

def encrypt(m):
    n = prod(keys)
    m = pad(m, n)
    return pow(m, e, n)
    

while True:
    try:
        print(MENU)
        option = input("> ").lower()
        if option == "a":
            p = int(input("p(hex)> "), 16)
            if len(bin(p)) - 2 == 1024 and isPrime(p):
                keys.append(p)
            else:
                raise ValueError("Invalid prime.")
        elif option == "e":
            ct = encrypt(FLAG)
            print(f"Flag: {hex(ct)}")
        elif option == "q":
            break
        
    except KeyboardInterrupt:
        print('Ze Bluetoos device disconnected\n')
        break
    
    except Exception as e:
        print('Ze Bluetoos device crashed {}\n'.format(e))
        
