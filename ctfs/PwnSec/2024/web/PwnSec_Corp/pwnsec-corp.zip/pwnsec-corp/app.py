from flask import Flask, request, render_template, redirect, make_response
from base64 import *
from lxml import etree
import os
import random
from hashlib import sha256

app = Flask(__name__)

with open(os.path.join('data', 'data.xml'), 'r', encoding='utf-8') as xml_file:
    xml_data = xml_file.read()

xml_data_bytes = xml_data.encode('utf-8')
root = etree.fromstring(xml_data_bytes)
secret = os.urandom(random.randint(80,100))


def set_cookie(uname,admin):
    session = f'admin={admin};' + uname
    cookie = sha256(secret + session.encode()).hexdigest()
    return (b64encode((session + '.' + cookie).encode())).decode()

def check_admin():
    cookie = request.cookies.get('session')
    if cookie:
        decoded_cookie = b64decode(cookie)
        session,check = decoded_cookie.split(b'.')
        if sha256(secret + session).hexdigest() != check.decode():
            return False
        if b'admin=1' in session:
            return True
    return False

@app.route('/')
def index():
    response = make_response(render_template('index.html'))
    guest_cookie = set_cookie('guest','0')
    response.set_cookie('session', guest_cookie)
    return response

@app.route('/admin', methods=['GET', 'POST'])
def admin():
    if not check_admin():
        return redirect('/')
    
    result = ""
    if request.method == 'POST':
        name_query = request.form['name']
        try:
            xpath_query = f".//department[dname='{name_query}']"
            found = root.xpath(xpath_query)
            
            if found:
                result = f"User exists!"
            else:
                result = f"User does not exist."
        except etree.XPathEvalError as e:
            result = f"Unexpected Error!"

    return render_template('admin.html', result=result)

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=int(os.getenv('PORT', 3000)))