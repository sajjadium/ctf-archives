const server = Bun.serve({
  port: process.env.BUN_PORT,
  async fetch(req, server) {
    const url = new URL(req.url);
    const time = Math.floor(new Date().getTime() / 1000);

    switch (decodeURI(url.pathname)) {
      case "/":
        return new Response("hey! im just bun ._.", { status: 200 });
      case "/flag/get":
        if (req.method == "GET") {
          return new Response("you resemble mr baker.. something is off tho");
        }

        const body = await req.formData();
        const sent_time = body.get("time");

        if (sent_time && Number(sent_time) != time) {
          return new Response("intruder! intruder wants to steal bun!");
        }

        return new Response(
          `bun is delighted! well done! ${process.env.FLAG}`,
          { status: 500 }
        );

      default:
        return new Response(
          `${url}\ni thought u were mr baker? its ${time} and he hasnt arrived yet :(`,
          {
            status: 404,
          }
        );
    }
  },
});

console.log(`bun: listening on ${server.port}...`);
