package main

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"

	"golang.org/x/net/http2"
	"golang.org/x/net/http2/h2c"
)

var GO_PORT = os.Getenv("GO_PORT")
var BUN_PORT = os.Getenv("BUN_PORT")

func checkErr(err error, msg string) {
    if err == nil {
        return
    }
    fmt.Printf("ERROR: %s: %s\n", msg, err)
    os.Exit(1)
}

func main() {    
    h2s := &http2.Server{}

    handler := http.NewServeMux()
    handler.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
        fmt.Fprintf(w, "<h1>Welcome to the Bakery! 🍞 🥖 🥐</h1>\n<p>Our cutting-edge Bun-on-the-Go system ensures</br>efficient production throughout our pipepline.\n")
    })

    handler.HandleFunc("/bun/", func(w http.ResponseWriter, r *http.Request) {
        bunPath := r.URL.Path[4:]; 

        if strings.HasPrefix(bunPath, "/flag") {
            fmt.Fprintf(w, "The bun told me it doesn't want you there.");
            return;
        }

        url := fmt.Sprintf("http://127.0.0.1:%s/%s", BUN_PORT, bunPath[1:]);
        
        var resp *http.Response;
        if r.Method == "GET" {
            resp, _ = http.Get(url)
        } else if r.Method == "POST" {
            resp, _ = http.Post(url, "application/x-www-form-urlencoded", r.Body);
        }
        
        body, err := io.ReadAll(resp.Body)
        
        if err != nil {
            fmt.Fprintf(w, "500 Internal Server Error");
            return;
        }
        
        fmt.Fprintf(w, "A bun shouts within its oven:\n---\n%s\n---\n", string(body));
    })

    server := &http.Server{
        Addr:    fmt.Sprintf("0.0.0.0:%s", GO_PORT),
        Handler: h2c.NewHandler(handler, h2s),
    }

    fmt.Printf("Listening [0.0.0.0:%s]...\n", GO_PORT)
    checkErr(server.ListenAndServe(), "while listening")
}