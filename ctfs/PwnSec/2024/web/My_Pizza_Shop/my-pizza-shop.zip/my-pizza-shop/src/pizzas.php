<?php

$pizzas = [
    ['id' => 1, 'name' => 'Margherita', 'image' => 'images/margherita.png', 'price' => 8.99],
    ['id' => 2, 'name' => 'Pepperoni', 'image' => 'images/pepperoni.png', 'price' => 9.99],
    ['id' => 3, 'name' => 'BBQ Chicken', 'image' => 'images/bbq_chicken.png', 'price' => 10.99],
    ['id' => 4, 'name' => 'Vegetarian', 'image' => 'images/vegetarian.png', 'price' => 8.99],
];


?>