<?php

$flag = 'PWNSEC{FAKE_FLAG}';

?>