from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from secret import FLAG
import random
import os
import hashlib
seed = os.urandom(8)  
WORDLEN = 8  
random.seed(seed)


def encrypt_flag(flag: str, key: bytes) -> bytes:
    key = hashlib.sha256(key).digest()[:16]  
    cipher = AES.new(key, AES.MODE_CBC)
    iv = cipher.iv
    encrypted_flag = cipher.encrypt(pad(flag.encode(), AES.block_size))
    return iv + encrypted_flag

ct = encrypt_flag(FLAG.decode(), seed)

class wordle:
    def __init__(self):
        words = [random.getrandbits(64).to_bytes(8, 'big') for _ in range(312)]
        self.words = [words[1], words[2], words[3], words[115], words[116]]
        self.todays_word = self.words.pop(0)

    def guess(self, guess: bytes) -> str:
        """
        Check a guess (bytes) against global `todays_word` (bytes).
        Returns a string of same length with characters:
        'G' -> correct byte in correct position,
        'Y' -> byte exists in todays_word but different position,
        'B' -> byte not in todays_word.
        
        Handles duplicate bytes correctly (uses counts like Wordle).
        """
        if len(guess) != WORDLEN:
            raise ValueError(f"guess must be exactly {WORDLEN} bytes long")

        status = ['?'] * WORDLEN
        counts = {}
        for i in range(WORDLEN):
            if guess[i] == self.todays_word[i]:
                status[i] = 'G'
            else:
                counts[self.todays_word[i]] = counts.get(self.todays_word[i], 0) + 1

        for i in range(WORDLEN):
            if status[i] == 'G':
                continue
            gbyte = guess[i]
            if counts.get(gbyte, 0) > 0:
                status[i] = 'Y'
                counts[gbyte] -= 1
            else:
                status[i] = 'B'
        return ''.join(status)
    
    def reset_word(self) -> str:
        if not self.words:
            return "No more words available to reset."        
        self.todays_word = self.words.pop(0)
        return "Word has been reset."


banner = f""" __    __              _ _      
/ / /\ \ \___  _ __ __| | | ___ 
\ \/  \/ / _ \| '__/ _` | |/ _ \\
 \  /\  / (_) | | | (_| | |  __/
  \/  \/ \___/|_|  \__,_|_|\___|
                                  
Welcome to todays Wordle!
You have 6 attempts to guess the word of the day.
The word is 8 characters long.
Good luck!
ct = {ct.hex()}
"""

menu = """1. Guess the word
2. Reset the word
3. Exit
Please choose an option > """


def main():
    print(banner)
    num_of_guesses = 0
    game = wordle()    
    while True:
        choice = input(menu)
        if choice == '1':
            guess = input("Enter your guess (8 characters) > ")
            num_of_guesses += 1
            print(game.guess(guess.encode()))
            if num_of_guesses >= 6:
                num_of_guesses = 0
                print("Maximum number of guesses reached.")
                print(f'The word was: {game.todays_word.hex()}')
                if not game.words:
                    print("No more words available. Exiting the game.")
                    break
                game.reset_word()
        elif choice == '2':
            print(game.reset_word())
        elif choice == '3':
            print("Exiting the game.")
            break
        else:
            print("Invalid option, please try again.")

if __name__ == "__main__":
    main()