from Crypto.Util.number import getPrime, bytes_to_long as b2l
from secrets import randbelow
import os

FLAG  = os.getenv("FLAG", "Lorem ipsum dolor sit amet consectetur adipiscing elit. Pretium tellus duis convallis tempus leo eu aenean. Iaculis massa nisl malesuada lacinia integer nunc posuere. Conubia nostra inceptos himenaeos orci varius natoque penatibus. Nulla molestie mattis scelerisque maximus eget fermentum odio. Blandit quis suspendisse aliquet nisi sodales consequat magna. Ligula congue sollicitudin erat viverra ac tincidunt nam. Velit aliquam imperdiet mollis nullam volutpat porttitor ullamcorper. Dui felis venenatis ultrices proin libero feugiat tristique. Cubilia curae hac habitasse platea dictumst lorem ipsum. Sem placerat in id cursus mi pretium tellus. Fringilla lacus nec metus bibendum egestas iaculis massa. Taciti sociosqu ad litora torquent per conubia nostra. Ridiculus mus donec rhoncus eros lobortis nulla molestie. Mauris pharetra vestibulum fusce dictum risus blandit quis. Finibus facilisis dapibus etiam interdum tortor ligula congue. Justo lectus commodo augue arcu dignissim velit aliquam. Primis vulputate ornare sagittis vehicula praesent dui felis. Senectus netus suscipit auctor curabitur facilisi cubilia curae. Quisque faucibus ex sapien vitae pellentesque sem placerat. flag{dGhpbmtfeW91J3JlX3NtYXJ0X2h1aD8=}").encode()


class ZKP:
    def __init__(self):
        self.p = getPrime(256)
        self.q = getPrime(256) 
        self.g = 2
        self.w = b2l(FLAG) 
        self.y = pow(self.g, self.w, self.p)
    def prover(self):
            r = randbelow(1 << 200)
            a = pow(self.g, r, self.p)
            e = randbelow(1 << 256)
            z = (r + self.w * e) % self.q
            proof = {"a": a, "e": e, "z": z}
            return proof
    def __str__(self):
        return f"ZKP PUBLIC PARAMETERS:\np = {self.p}\nq = {self.q}\ng = {self.g}\ny = {self.y}"




user = ZKP()

banner = """
 █████╗ ███████╗██████╗  █████╗ ██╗██████╗      ██████╗ ███████╗     █████╗ ███████╗██╗     ███╗   ███╗ ██████╗ 
██╔══██╗██╔════╝██╔══██╗██╔══██╗██║██╔══██╗    ██╔═══██╗██╔════╝    ██╔══██╗██╔════╝██║     ████╗ ████║██╔═══██╗
███████║█████╗  ██████╔╝███████║██║██║  ██║    ██║   ██║█████╗      ███████║█████╗  ██║     ██╔████╔██║██║   ██║
██╔══██║██╔══╝  ██╔══██╗██╔══██║██║██║  ██║    ██║   ██║██╔══╝      ██╔══██║██╔══╝  ██║     ██║╚██╔╝██║██║   ██║
██║  ██║██║     ██║  ██║██║  ██║██║██████╔╝    ╚██████╔╝██║         ██║  ██║███████╗███████╗██║ ╚═╝ ██║╚██████╔╝
╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝╚═════╝      ╚═════╝ ╚═╝         ╚═╝  ╚═╝╚══════╝╚══════╝╚═╝     ╚═╝ ╚═════╝                                                                                                             
V.2                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
"""

menu = """
[1] Prover
[2] Exit
"""

def main():
    ctr = 0
    print(banner)
    print(user)
    print(f'hint: {b2l(FLAG).bit_length()}...you\'re welcome :)')

    while True:
        print(menu)
        choice = input("Select an option > ")
        if choice == '1':
            if ctr >= 6:
                print("You have reached the maximum number of proofs.")
                continue
            
            print("Prover selected.")
            print(f'Here is your proof: {user.prover()}')
            ctr += 1

        elif choice == '2':
            print("Goodbye!")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()