package main

// stripped secret
func generate() {
	// adds stuff to alice_says and bobby says
}

var flag = ""
var alice_says = []string{}
var bobby_says = []string{}
