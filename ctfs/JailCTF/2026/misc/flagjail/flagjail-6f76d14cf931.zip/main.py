#!/usr/local/bin/python3
import unicodedata
from flags import FLAGS

code = input("Your flags please > ")

for grapheme in unicodedata.iter_graphemes(code):
    c = code[grapheme.start:grapheme.end]
    
    if c.isascii():
        if c not in '(0)+._':
            print("NO!")
            exit()
    elif c not in FLAGS:
        print("NO!")
        exit()

translation = {0x1f1e6 + i: b"a"[0] + i for i in range(26)}
code = code.translate(translation)[::-1]

print(code)
eval(code)
