#!/usr/local/bin/python3
import sys
import os
import subprocess

inp = input('blindness > ')
assert all(i in '()._abcdefghijklmnopqrstuvwxyz' or i.isspace() for i in inp), 'your input is too blinding'

sys.stdout.close()
flag = open('flag.txt').read()

# source: https://dmoj.ca/problem/helloworldharder
template = f'''class Sandbox(object):
    def __init__(self):
        import sys
        for attr in ["__file__","__loader__","__name__","__doc__","__package__","__annotations__","__spec__","__cached__"]:
            if hasattr(sys.modules["__main__"],attr):
                delattr(sys.modules["__main__"],attr)

        if hasattr(sys.modules["__main__"].__dict__["__builtins__"],"__dict__"):
            original_builtins = sys.modules["__main__"].__dict__["__builtins__"].__dict__.copy()
            for builtin in original_builtins:
                del sys.modules["__main__"].__dict__["__builtins__"].__dict__[builtin]
        else:
            original_builtins = sys.modules["__main__"].__dict__["__builtins__"]
            for builtin in list(original_builtins):
                del sys.modules["__main__"].__dict__["__builtins__"][builtin]

        del sys.modules["__main__"].__dict__["__builtins__"]
        del sys

Sandbox()
del Sandbox

flag = '{flag.strip()}'
{inp}'''

subprocess.run(
    ['/usr/local/bin/python3', '-c', template],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
)
