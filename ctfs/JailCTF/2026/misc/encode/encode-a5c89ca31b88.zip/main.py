#!/usr/local/bin/python3
code = ''

while True:
    option = input('cmd> ')
    if option == 'encode':
        encoding = input('encoding: ')
        code = code.encode(encoding)
    elif option == 'decode':
        encoding = input('encoding: ')
        code = code.decode(encoding)
    elif option == 'quit':
        break
    else:
        print('invalid command')

print('running your input...')
eval(code)
