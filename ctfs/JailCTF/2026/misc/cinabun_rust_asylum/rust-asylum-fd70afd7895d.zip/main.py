#!/usr/bin/python3

import tempfile
import subprocess

banned = "(){}!"
banned += "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

src = input("> ")
for c in src:
    if ord(c) < 0x20 or ord(c) > 0x7e or c in banned:
        print("no")
        exit(1)

if "unsafe" in src:
    print("that would be too easy")
    exit(1)

with tempfile.TemporaryDirectory(dir="/tmp") as tmpdirname:
    src_path = tmpdirname + "/jail.rs"
    bin_path = tmpdirname + "/jail"

    with open(src_path, "w") as f:
        f.write("fn main(){" + src + "}")

    ret = subprocess.run(
        ["/usr/local/cargo/bin/rustc", src_path, "-o", bin_path],
        capture_output=True,
    )
    if ret.returncode != 0:
        print("compilation error")
        exit(1)

    # Flag can be read by running /readflag
    ret = subprocess.run(
        [bin_path],
        stderr=subprocess.DEVNULL,
    )
