#!/usr/local/bin/python3
from hashlib import*;eval(b''.join(sha256(b'%r'%i).digest()for i in input().split()),{'__builtins__':{}})
