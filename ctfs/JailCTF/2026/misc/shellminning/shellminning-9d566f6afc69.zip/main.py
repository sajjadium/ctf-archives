#!/usr/local/bin/python3
from capstone import *
import sys
import subprocess

shellcode = bytes.fromhex(input("Enter shellcode (hex): "))

md = Cs(CS_ARCH_X86, CS_MODE_64)

processed = 0
for address, size, mnemonic, op_str in md.disasm_lite(shellcode, 0):
    if size != 1 and (size != 2 or mnemonic != "syscall"):
        print("Shellcode validation failed")
        sys.exit(1)
    processed += size
    

if processed != len(shellcode):
    print("Not all bytes were processed")
    sys.exit(1)

print("Shellcode validation passed")

r = subprocess.run(
    ['./chal'],
    input=shellcode,
    text=False,
    capture_output=True
)

print(f"Result: {r.stdout}")

