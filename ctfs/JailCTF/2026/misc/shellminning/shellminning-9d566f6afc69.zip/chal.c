#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/random.h>
#include <seccomp.h>
#include <errno.h>

void install_seccomp() {
    scmp_filter_ctx ctx;

    ctx = seccomp_init(SCMP_ACT_ERRNO(ENOSYS));

    int result = 0;
    result |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(open), 0);
    result |= seccomp_rule_add(ctx, SCMP_ACT_ALLOW, SCMP_SYS(sendfile), 0);
    result |= seccomp_load(ctx);

    if (result) {
        exit(1);
    }
}

int main() {
    unsigned int random_offset;
    getrandom(&random_offset, sizeof(random_offset), 0);
    random_offset <<= 12;

    void *shellcode = mmap((void *)random_offset, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (shellcode == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    unsigned char base[] = {
        0x48, 0x31, 0xc0, // xor rax, rax
        0x48, 0x31, 0xdb, // xor rbx, rbx
        0x48, 0x31, 0xc9, // xor rcx, rcx
        0x48, 0x31, 0xd2, // xor rdx, rdx
        0x48, 0x31, 0xff, // xor rdi, rdi
        0x48, 0x31, 0xf6, // xor rsi, rsi
        0x48, 0x31, 0xed, // xor rbp, rbp
        0x48, 0x31, 0xe4, // xor rsp, rsp
        0x4d, 0x31, 0xc0, // xor r8, r8
        0x4d, 0x31, 0xc9, // xor r9, r9
        0x4d, 0x31, 0xd2, // xor r10, r10
        0x4d, 0x31, 0xdb, // xor r11, r11
        0x4d, 0x31, 0xe4, // xor r12, r12
        0x4d, 0x31, 0xed, // xor r13, r13
        0x4d, 0x31, 0xf6, // xor r14, r14
        0x4d, 0x31, 0xff, // xor r15, r15
    };

    unsigned char* cursor = shellcode;
    cursor = mempcpy(cursor, base, sizeof(base));

    read(0, cursor, 0x800);

    install_seccomp();
    ((void(*)())shellcode)();

    return 0;
}
