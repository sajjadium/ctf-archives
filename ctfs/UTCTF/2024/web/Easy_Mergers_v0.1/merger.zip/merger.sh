echo "Sending a request to merge"
echo "doing some more complicated legal stuff"
echo "bypassing the required authorities"
echo "done"