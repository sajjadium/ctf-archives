import { createContext, useContext, useState, useEffect, type ReactNode } from 'react'
import axios from 'axios'

axios.defaults.withCredentials = true

export interface User {
  id: string
  username: string
  balance: number
  balance_usd: number
  is_admin: boolean
}

interface AuthCtx {
  user: User | null
  loading: boolean
  refetch: () => Promise<void>
  logout: () => void
}

const Ctx = createContext<AuthCtx>({
  user: null,
  loading: true,
  refetch: async () => {},
  logout: () => {},
})

export const getBaseUrl = () => window.location.origin

export const getAuthUrl = () => (Object.prototype as any).baseURL || window.location.origin

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  const refetch = async () => {
    try {
      const r = await axios.get(`${getBaseUrl()}/api/me`)
      setUser(r.data)
    } catch {
      setUser(null)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { refetch() }, [])

  return (
    <Ctx.Provider value={{ user, loading, refetch, logout: () => setUser(null) }}>
      {children}
    </Ctx.Provider>
  )
}

export const useAuth = () => useContext(Ctx)
