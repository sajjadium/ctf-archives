import { useToastState } from '@/hooks/useToast'

export function Toaster() {
  const toasts = useToastState()
  return (
    <div className="toasts">
      {toasts.map(t => (
        <div key={t.id} className={`toast ${t.variant ?? ''}`}>
          {t.title}
          {t.description && <span className="muted"> · {t.description}</span>}
        </div>
      ))}
    </div>
  )
}
