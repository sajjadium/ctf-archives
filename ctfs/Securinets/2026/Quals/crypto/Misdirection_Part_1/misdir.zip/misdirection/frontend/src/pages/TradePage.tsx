import { useState } from 'react'
import axios from 'axios'
import { useAuth, getBaseUrl } from '@/lib/auth'
import { usePrice, usd } from '@/lib/price'
import { toast } from '@/hooks/useToast'

export default function TradePage() {
  const { user, refetch } = useAuth()
  const price = usePrice()
  const [side, setSide] = useState<'buy' | 'sell'>('buy')
  const [amount, setAmount] = useState('')
  const [busy, setBusy] = useState(false)

  const amt = parseFloat(amount)

  const handleTrade = async () => {
    setBusy(true)
    try {
      await axios.post(`${getBaseUrl()}/api/trade`, { side, amount_btc: amt })
      toast({ title: `${side === 'buy' ? 'Bought' : 'Sold'} ${amt} BTC`, variant: 'success' })
      setAmount('')
      await refetch()
    } catch (e: any) {
      toast({
        title: 'Trade failed',
        description: e?.response?.status === 402 ? 'Insufficient funds' : 'Server error',
        variant: 'destructive',
      })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <h1>Trade</h1>
      <p className="big">{usd(price)}</p>
      <div className="stack">
        <div className="segmented">
          {(['buy', 'sell'] as const).map(s => (
            <button key={s} className={side === s ? 'on' : ''} onClick={() => setSide(s)}>
              {s === 'buy' ? 'Buy' : 'Sell'}
            </button>
          ))}
        </div>
        <input
          type="number"
          min="0"
          step="any"
          placeholder="Amount in BTC"
          value={amount}
          onChange={e => setAmount(e.target.value)}
        />
        <p className="muted">{amt > 0 ? `${usd(amt * price)}` : ' '}</p>
        <button className="primary" onClick={handleTrade} disabled={busy || !(amt > 0)}>
          {side === 'buy' ? 'Buy' : 'Sell'} BTC
        </button>
      </div>
      <div style={{ marginTop: '3rem' }}>
        <div className="row"><span>BTC</span><span>{Number(user?.balance ?? 0).toFixed(8)}</span></div>
        <div className="row"><span>USD</span><span>{usd(Number(user?.balance_usd ?? 0))}</span></div>
      </div>
    </>
  )
}
