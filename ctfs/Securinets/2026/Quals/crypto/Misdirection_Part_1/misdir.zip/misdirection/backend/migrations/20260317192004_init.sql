CREATE TABLE users (
    id UUID PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    balance NUMERIC(20, 8) NOT NULL DEFAULT 0.1,
    balance_usd NUMERIC(20, 8) NOT NULL DEFAULT 100000.0,
    is_admin BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE passkeys (
    cred_id BYTEA PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    passkey_data JSONB NOT NULL
);

INSERT INTO users (id, username, balance, is_admin) VALUES (
    '00000000-0000-0000-0000-000000000000',
    'admin',
    0.1,
    true
);

INSERT INTO passkeys (cred_id, user_id, passkey_data) VALUES (
    decode('0102030405060708090a0b0c0d0e0f10', 'hex'),
    '00000000-0000-0000-0000-000000000000',
    '{"cred": {"cred": {"key": {"EC_EC2": {"x": "ax-gywE6mENnh-AHn4wRoEgrmC772tSG2jCRCKJQoZc", "y": "8YKWhWAp0RnCeXjFWXWXvXYhlmz9WIEO3FwHWYvOD2M", "curve": "SECP256R1"}}, "type_": "ES256"}, "counter": 0, "cred_id": "AQIDBAUGBwgJCgsMDQ4PEA", "extensions": {"appid": "NotRequested", "cred_props": "Ignored", "cred_protect": "Ignored", "hmac_create_secret": "NotRequested"}, "transports": null, "attestation": {"data": "None", "metadata": "None"}, "backup_state": false, "user_verified": true, "backup_eligible": false, "attestation_format": "none", "registration_policy": "required"}}'::jsonb
);
