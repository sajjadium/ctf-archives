use crate::startup::{var, AppState};
use axum::{
    extract::{Extension, Json},
    http::StatusCode,
};
use rust_decimal::{prelude::*, Decimal};
use serde::{Deserialize, Serialize};
use sqlx::types::Uuid;
use std::time::{SystemTime, UNIX_EPOCH};
use tower_sessions::Session;

const FLAG_BALANCE: i64 = 5_000_000;

#[derive(Serialize)]
pub struct MeResponse {
    id: Uuid,
    username: String,
    balance: Decimal,
    balance_usd: Decimal,
    is_admin: bool,
}

#[derive(Deserialize)]
pub struct AddFundsRequest {
    target_username: String,
    amount: Decimal,
}

#[derive(Deserialize)]
pub struct TradeRequest {
    side: String,
    amount_btc: Decimal,
}

const INTERNAL: StatusCode = StatusCode::INTERNAL_SERVER_ERROR;

async fn session_user(session: &Session) -> Result<Uuid, StatusCode> {
    let user_id: Option<Uuid> = session.get("user_id").await.unwrap_or(None);
    user_id.ok_or(StatusCode::UNAUTHORIZED)
}

fn current_price() -> (u64, f64) {
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs();
    let cycle = (now % 3600) as f64 / 3600.0;
    let oscillation = (cycle * std::f64::consts::PI * 2.0).sin();
    let noise = (now % 60) as f64 * 10.0 - 300.0;
    (now, 65000.0 + oscillation * 5000.0 + noise)
}

pub async fn me_handler(
    Extension(app_state): Extension<AppState>,
    session: Session,
) -> Result<Json<MeResponse>, StatusCode> {
    let user_id = session_user(&session).await?;

    let user = sqlx::query!("SELECT id, username, balance, balance_usd, is_admin FROM users WHERE id = $1", user_id)
        .fetch_optional(&app_state.db)
        .await
        .map_err(|_| INTERNAL)?
        .ok_or(StatusCode::UNAUTHORIZED)?;

    Ok(Json(MeResponse {
        id: user.id,
        username: user.username,
        balance: user.balance,
        balance_usd: user.balance_usd,
        is_admin: user.is_admin,
    }))
}

pub async fn add_funds_handler(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Json(payload): Json<AddFundsRequest>,
) -> Result<StatusCode, StatusCode> {
    let user_id = session_user(&session).await?;

    let user = sqlx::query!("SELECT is_admin FROM users WHERE id = $1", user_id)
        .fetch_optional(&app_state.db)
        .await
        .map_err(|_| INTERNAL)?
        .ok_or(StatusCode::UNAUTHORIZED)?;

    if !user.is_admin {
        return Err(StatusCode::FORBIDDEN);
    }

    let rows_affected = sqlx::query!(
        "UPDATE users SET balance = balance + $1 WHERE username = $2",
        payload.amount,
        payload.target_username
    )
    .execute(&app_state.db)
    .await
    .map_err(|_| INTERNAL)?
    .rows_affected();

    if rows_affected == 0 {
        return Err(StatusCode::NOT_FOUND);
    }

    Ok(StatusCode::OK)
}

pub async fn flag_handler(
    Extension(app_state): Extension<AppState>,
    session: Session,
) -> Result<Json<serde_json::Value>, StatusCode> {
    let user_id = session_user(&session).await?;

    let user = sqlx::query!("SELECT balance FROM users WHERE id = $1", user_id)
        .fetch_optional(&app_state.db)
        .await
        .map_err(|_| INTERNAL)?
        .ok_or(StatusCode::UNAUTHORIZED)?;

    if user.balance < Decimal::new(FLAG_BALANCE, 0) {
        return Err(StatusCode::PAYMENT_REQUIRED);
    }
    Ok(Json(serde_json::json!({ "flag": var("FLAG") })))
}

pub async fn get_price_handler() -> Json<serde_json::Value> {
    let (now, price) = current_price();
    Json(serde_json::json!({
        "pair": "BTC/USD",
        "price": format!("{price:.2}"),
        "timestamp": now
    }))
}

pub async fn trade_handler(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Json(payload): Json<TradeRequest>,
) -> Result<StatusCode, StatusCode> {
    let user_id = session_user(&session).await?;

    if payload.amount_btc <= Decimal::ZERO {
        return Err(StatusCode::BAD_REQUEST);
    }

    let price = Decimal::from_f64(current_price().1).unwrap().round_dp(2);
    let cost_usd = payload.amount_btc * price;

    let mut tx = app_state.db.begin().await.map_err(|_| INTERNAL)?;

    let user = sqlx::query!("SELECT balance, balance_usd FROM users WHERE id = $1 FOR UPDATE", user_id)
        .fetch_optional(&mut *tx)
        .await
        .map_err(|_| INTERNAL)?
        .ok_or(StatusCode::UNAUTHORIZED)?;

    match payload.side.as_str() {
        "buy" => {
            if user.balance_usd < cost_usd {
                return Err(StatusCode::PAYMENT_REQUIRED);
            }
            sqlx::query!(
                "UPDATE users SET balance = balance + $1, balance_usd = balance_usd - $2 WHERE id = $3",
                payload.amount_btc, cost_usd, user_id
            )
            .execute(&mut *tx)
            .await
            .map_err(|_| INTERNAL)?;
        }
        "sell" => {
            if user.balance < payload.amount_btc {
                return Err(StatusCode::PAYMENT_REQUIRED);
            }
            sqlx::query!(
                "UPDATE users SET balance = balance - $1, balance_usd = balance_usd + $2 WHERE id = $3",
                payload.amount_btc, cost_usd, user_id
            )
            .execute(&mut *tx)
            .await
            .map_err(|_| INTERNAL)?;
        }
        _ => return Err(StatusCode::BAD_REQUEST),
    }

    tx.commit().await.map_err(|_| INTERNAL)?;

    Ok(StatusCode::OK)
}
