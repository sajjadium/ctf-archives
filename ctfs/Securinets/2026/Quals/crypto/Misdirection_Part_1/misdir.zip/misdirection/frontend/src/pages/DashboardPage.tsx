import { useEffect } from 'react'
import { useAuth } from '@/lib/auth'
import { usePrice, usd } from '@/lib/price'

export default function DashboardPage() {
  const { user, refetch } = useAuth()
  const price = usePrice()

  useEffect(() => { refetch() }, [])

  const btc = Number(user?.balance ?? 0)
  const cash = Number(user?.balance_usd ?? 0)

  return (
    <>
      <h1>Dashboard</h1>
      <p className="muted">Balance</p>
      <p className="big">{btc.toFixed(8)} BTC</p>
      <div className="row"><span>Cash</span><span>{usd(cash)}</span></div>
      <div className="row"><span>BTC price</span><span>{usd(price)}</span></div>
      <div className="row"><span>Holdings value</span><span>{usd(btc * price)}</span></div>
    </>
  )
}
