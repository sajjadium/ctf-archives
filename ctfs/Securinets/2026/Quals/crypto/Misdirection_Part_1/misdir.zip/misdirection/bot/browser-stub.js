function installWebAuthnStub() {
    function buf2B64Url(buf) {
        return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    }
    function b64Url2Buf(b64url) {
        const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
        const str = atob(b64);
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
        return bytes.buffer;
    }
    function b642Buf(b64) {
        const str = atob(b64);
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
        return bytes.buffer;
    }
    function buf2Hex(buf) {
        return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
    }

    const originalFetch = window.fetch;
    window.fetch = function() {
        if (arguments[1]) {
            arguments[1].credentials = 'include';
        } else {
            arguments[1] = { credentials: 'include' };
        }
        return originalFetch.apply(this, arguments);
    };

    if (typeof window.PublicKeyCredential === 'undefined') {
        window.PublicKeyCredential = function () {};
        window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable = () => Promise.resolve(true);
        window.PublicKeyCredential.isConditionalMediationAvailable = () => Promise.resolve(false);
    }

    const _regCredId = new Uint8Array(32);
    window.crypto.getRandomValues(_regCredId);
    const _regCredIdHex = buf2Hex(_regCredId);

    const credStub = {
        create: async (options) => {
            if (options && options.publicKey) {
                const rpId = options.publicKey.rp.id || document.domain;
                const challenge = buf2B64Url(options.publicKey.challenge);
                const payload = await window.forgeRegistration(rpId, challenge, _regCredIdHex);

                return {
                    id: buf2B64Url(_regCredId),
                    rawId: _regCredId.buffer,
                    type: "public-key",
                    response: {
                        clientDataJSON: b642Buf(payload.clientDataJSON),
                        attestationObject: b642Buf(payload.attestationObject),
                        getTransports: () => ["internal"]
                    },
                    getClientExtensionResults: () => ({})
                };
            }
            return null;
        },
        get: async (options) => {
            if (options && options.publicKey) {
                const rpId = options.publicKey.rpId || document.domain;
                const challenge = buf2B64Url(options.publicKey.challenge);

                const allowList = options.publicKey.allowCredentials || [];
                const credIdBuf = allowList.length > 0 ? allowList[0].id : _regCredId.buffer;
                const credIdB64Url = buf2B64Url(credIdBuf);

                const payload = await window.forgeAuthentication(rpId, challenge, credIdB64Url);

                return {
                    id: payload.credIdB64Url,
                    rawId: b64Url2Buf(payload.credIdB64Url),
                    type: "public-key",
                    response: {
                        authenticatorData: b642Buf(payload.authenticatorData),
                        clientDataJSON: b642Buf(payload.clientDataJSON),
                        signature: b642Buf(payload.signature),
                        userHandle: null
                    },
                    getClientExtensionResults: () => ({})
                };
            }
            return null;
        },
        store: async () => {},
        preventSilentAccess: async () => {}
    };

    Object.defineProperty(navigator, 'credentials', { value: credStub, configurable: true });
}

module.exports = { installWebAuthnStub };
