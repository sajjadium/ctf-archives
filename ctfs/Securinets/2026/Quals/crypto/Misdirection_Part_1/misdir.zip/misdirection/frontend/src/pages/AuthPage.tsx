import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { startRegistration, startAuthentication } from '@simplewebauthn/browser'
import axios from 'axios'
import { useAuth, getAuthUrl } from '@/lib/auth'
import { toast } from '@/hooks/useToast'

export default function AuthPage() {
  const [username, setUsername] = useState('')
  const [busy, setBusy] = useState(false)
  const { refetch } = useAuth()
  const navigate = useNavigate()

  const run = async (flow: () => Promise<void>, failure: string) => {
    setBusy(true)
    try {
      await flow()
      await refetch()
      navigate('/dashboard')
    } catch (e: any) {
      toast({ title: failure, description: e?.message, variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  const handleRegister = () => {
    if (username.trim().toLowerCase() === 'admin') {
      toast({ title: 'That username is reserved', variant: 'destructive' })
      return
    }
    run(async () => {
      const base = getAuthUrl()
      const r = await axios.post(`${base}/register_start/${username}`)
      const att = await startRegistration({ optionsJSON: r.data.publicKey })
      await axios.post(`${base}/register_finish`, att)
    }, 'Registration failed')
  }

  const handleLogin = () =>
    run(async () => {
      const base = getAuthUrl()
      const r = await axios.post(`${base}/login_start/${username}`)
      const ass = await startAuthentication({ optionsJSON: r.data.publicKey })
      await axios.post(`${base}/login_finish`, ass)
    }, 'Sign in failed')

  return (
    <main className="narrow">
      <h1>XChange</h1>
      <div className="stack">
        <input
          id="username"
          autoComplete="username webauthn"
          placeholder="Username"
          value={username}
          onChange={e => setUsername(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleLogin()}
          disabled={busy}
        />
        <div className="buttons">
          <button id="login-button" className="primary" onClick={handleLogin} disabled={busy || !username.trim()}>
            Login
          </button>
          <button id="register-button" className="secondary" onClick={handleRegister} disabled={busy || !username.trim()}>
            Register
          </button>
        </div>
      </div>
    </main>
  )
}
