import { useState, useEffect } from 'react'
import axios from 'axios'
import { getBaseUrl } from '@/lib/auth'

export function usePrice() {
  const [price, setPrice] = useState(0)

  useEffect(() => {
    const load = () =>
      axios.get(`${getBaseUrl()}/api/price`).then(r => setPrice(parseFloat(r.data.price)), () => {})
    load()
    const id = setInterval(load, 3000)
    return () => clearInterval(id)
  }, [])

  return price
}

export const usd = (n: number) =>
  n.toLocaleString('en-US', { style: 'currency', currency: 'USD' })
