import { useState } from 'react'
import axios from 'axios'
import { getBaseUrl } from '@/lib/auth'
import { toast } from '@/hooks/useToast'

const ISSUE_TYPES = [
  ['balance', 'Balance discrepancy'],
  ['auth', 'Authentication issue'],
  ['ui', 'Display bug'],
  ['other', 'Other'],
]

export default function SettingsPage() {
  const [issueType, setIssueType] = useState('')
  const [busy, setBusy] = useState(false)

  const handleReport = async () => {
    setBusy(true)
    try {
      if (issueType === 'auth') {
        const params = new URLSearchParams(window.location.search)
        const rootUrl = window.location.origin + '/' + (params.toString() ? '?' + params.toString() : '')
        const resp = await axios.post(`${getBaseUrl()}/report`, { url: rootUrl })
        toast({
          title: resp.data.message || 'Report submitted',
          variant: resp.data.status === 'success' ? 'success' : 'destructive',
        })
      } else {
        toast({ title: 'Report submitted', variant: 'success' })
      }
      setIssueType('')
    } catch {
      toast({ title: 'Submission failed', variant: 'destructive' })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <h1>Settings</h1>
      <p className="muted">Report an issue</p>
      <div className="stack">
        <select value={issueType} onChange={e => setIssueType(e.target.value)}>
          <option value="" disabled>Select a type</option>
          {ISSUE_TYPES.map(([value, label]) => (
            <option key={value} value={value}>{label}</option>
          ))}
        </select>
        <button className="primary" onClick={handleReport} disabled={busy || !issueType}>
          Submit
        </button>
      </div>
    </>
  )
}
