import { useState } from 'react'
import axios from 'axios'
import { Navigate } from 'react-router-dom'
import { useAuth, getBaseUrl } from '@/lib/auth'
import { toast } from '@/hooks/useToast'

export default function AdminPage() {
  const { user, refetch } = useAuth()
  const [target, setTarget] = useState('')
  const [amount, setAmount] = useState('')
  const [busy, setBusy] = useState(false)

  if (!user?.is_admin) return <Navigate to="/dashboard" replace />

  const amt = parseFloat(amount)

  const handleMint = async () => {
    setBusy(true)
    try {
      await axios.post(`${getBaseUrl()}/api/admin/add_funds`, { target_username: target, amount: amt })
      toast({ title: `Minted ${amt} BTC to ${target}`, variant: 'success' })
      setTarget('')
      setAmount('')
      await refetch()
    } catch (e: any) {
      toast({
        title: 'Mint failed',
        description: e?.response?.status === 404 ? 'User not found' : 'Forbidden',
        variant: 'destructive',
      })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <h1>Admin</h1>
      <div className="stack">
        <input placeholder="Username" value={target} onChange={e => setTarget(e.target.value)} />
        <input
          type="number"
          min="0"
          step="any"
          placeholder="Amount in BTC"
          value={amount}
          onChange={e => setAmount(e.target.value)}
        />
        <button className="primary" onClick={handleMint} disabled={busy || !target || !(amt > 0)}>
          Mint BTC
        </button>
      </div>
    </>
  )
}
