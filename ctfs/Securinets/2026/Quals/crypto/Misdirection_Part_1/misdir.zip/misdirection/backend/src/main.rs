mod admin;
mod auth;
mod error;
mod exchange;
mod startup;

use axum::{
    http::{header, Method},
    routing::{get, post},
    Extension, Router,
};
use sqlx::postgres::PgPoolOptions;
use std::net::SocketAddr;
use tower_http::cors::CorsLayer;
use tower_sessions::{
    cookie::{time::Duration, SameSite},
    Expiry, MemoryStore, SessionManagerLayer,
};

use startup::{frontend_origin, var, AppState};

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();

    let cors = CorsLayer::new()
        .allow_origin(frontend_origin())
        .allow_methods([Method::GET, Method::POST, Method::OPTIONS])
        .allow_headers([header::CONTENT_TYPE, header::AUTHORIZATION, header::ACCEPT, header::ORIGIN])
        .allow_credentials(true);

    let pool = PgPoolOptions::new()
        .max_connections(5)
        .connect(&var("DATABASE_URL"))
        .await
        .expect("Failed to connect to Postgres");
    sqlx::migrate!("./migrations")
        .run(&pool)
        .await
        .expect("Failed to run database migrations");

    let sessions = SessionManagerLayer::new(MemoryStore::default())
        .with_name("xchange-session")
        .with_same_site(SameSite::Lax)
        .with_secure(false)
        .with_expiry(Expiry::OnInactivity(Duration::seconds(360)));

    let app = Router::new()
        .route("/register_start/{username}", post(auth::start_register))
        .route("/register_finish", post(auth::finish_register))
        .route("/login_start/{username}", post(auth::start_authentication))
        .route("/login_finish", post(auth::finish_authentication))
        .route("/report", post(admin::report_handler))
        .route("/api/me", get(exchange::me_handler))
        .route("/api/admin/add_funds", post(exchange::add_funds_handler))
        .route("/api/flag", post(exchange::flag_handler))
        .route("/api/price", get(exchange::get_price_handler))
        .route("/api/trade", post(exchange::trade_handler))
        .layer(Extension(AppState::new(pool)))
        .layer(sessions)
        .layer(cors);

    let addr = SocketAddr::from(([0, 0, 0, 0], 8080));
    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .expect("Unable to bind listener");
    axum::serve(listener, app).await.unwrap();
}
