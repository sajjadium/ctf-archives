use crate::error::WebauthnError;
use crate::startup::AppState;
use sqlx::types::Uuid;
use axum::{
    extract::{Extension, Json, Path},
    http::StatusCode,
    response::IntoResponse,
};
use tower_sessions::Session;
use webauthn_rs::prelude::*;
use tracing::error;

pub async fn start_register(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Path(username): Path<String>,
) -> Result<impl IntoResponse, WebauthnError> {

    if username == "admin" {
        return Err(WebauthnError::NotAllowed);
    }

    let user_record = sqlx::query!("SELECT id FROM users WHERE username = $1", username)
        .fetch_optional(&app_state.db)
        .await
        .map_err(|_| WebauthnError::Unknown)?;

    let user_unique_id = user_record.map(|r| r.id).unwrap_or_else(Uuid::new_v4);

    let _ = session.remove_value("reg_state").await;

    let keys_records = sqlx::query!("SELECT passkey_data FROM passkeys WHERE user_id = $1", user_unique_id)
        .fetch_all(&app_state.db)
        .await
        .map_err(|_| WebauthnError::Unknown)?;

    let exclude_credentials = if keys_records.is_empty() {
        None
    } else {
        Some(
            keys_records
                .into_iter()
                .map(|record| {
                    let passkey: Passkey = serde_json::from_value(record.passkey_data).unwrap();
                    passkey.cred_id().clone()
                })
                .collect()
        )
    };

    let res = match app_state.webauthn.start_passkey_registration(
        user_unique_id,
        &username,
        &username,
        exclude_credentials,
    ) {
        Ok((ccr, reg_state)) => {
            session
                .insert("reg_state", (username, user_unique_id, reg_state))
                .await
                .expect("Failed to insert");
            Json(ccr)
        }
        Err(e) => {
            error!("challenge_register -> {:?}", e);
            return Err(WebauthnError::Unknown);
        }
    };
    Ok(res)
}

pub async fn finish_register(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Json(reg): Json<RegisterPublicKeyCredential>,
) -> Result<impl IntoResponse, WebauthnError> {

    let (username, user_unique_id, reg_state): (String, Uuid, PasskeyRegistration) = match session.get("reg_state").await? {
        Some(data) => data,
        None => {
            error!("Failed to get session");
            return Err(WebauthnError::CorruptSession);
        }
    };

    let _ = session.remove_value("reg_state").await;

    let res = match app_state
        .webauthn
        .finish_passkey_registration(&reg, &reg_state)
    {
        Ok(sk) => {
            sqlx::query!(
                "INSERT INTO users (id, username, balance, balance_usd, is_admin) VALUES ($1, $2, 0.1, 100000.0, false) ON CONFLICT (username) DO NOTHING",
                user_unique_id, username
            )
            .execute(&app_state.db)
            .await
            .map_err(|_| WebauthnError::Unknown)?;

            session.insert("user_id", user_unique_id).await.expect("Failed to insert user_id in session");

            let passkey_json = serde_json::to_value(&sk).unwrap();
            let cred_id_bytes = sk.cred_id().to_vec();

            sqlx::query!(
                "INSERT INTO passkeys (cred_id, user_id, passkey_data) VALUES ($1, $2, $3)",
                cred_id_bytes, user_unique_id, passkey_json
            )
            .execute(&app_state.db)
            .await
            .map_err(|_| WebauthnError::Unknown)?;

            StatusCode::OK
        }
        Err(e) => {
            error!("finish_register -> {:?}", e);
            StatusCode::BAD_REQUEST
        }
    };

    Ok(res)
}

pub async fn start_authentication(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Path(username): Path<String>,
) -> Result<impl IntoResponse, WebauthnError> {

    let _ = session.remove_value("auth_state").await;

    let user_record = sqlx::query!("SELECT id FROM users WHERE username = $1", username)
        .fetch_optional(&app_state.db)
        .await
        .map_err(|_| WebauthnError::Unknown)?;

    let user_unique_id = user_record.ok_or(WebauthnError::UserNotFound)?.id;

    let keys_records = sqlx::query!("SELECT passkey_data FROM passkeys WHERE user_id = $1", user_unique_id)
        .fetch_all(&app_state.db)
        .await
        .map_err(|_| WebauthnError::Unknown)?;

    if keys_records.is_empty() {
        return Err(WebauthnError::UserHasNoCredentials);
    }

    let allow_credentials: Vec<Passkey> = keys_records
        .into_iter()
        .map(|record| serde_json::from_value(record.passkey_data).unwrap())
        .collect();

    let res = match app_state
        .webauthn
        .start_passkey_authentication(&allow_credentials)
    {
        Ok((rcr, auth_state)) => {
            session
                .insert("auth_state", (user_unique_id, auth_state))
                .await
                .expect("Failed to insert");
            Json(rcr)
        }
        Err(e) => {
            error!("start_authentication -> {:?}", e);
            return Err(WebauthnError::Unknown);
        }
    };
    Ok(res)
}

pub async fn finish_authentication(
    Extension(app_state): Extension<AppState>,
    session: Session,
    Json(auth): Json<PublicKeyCredential>,
) -> Result<impl IntoResponse, WebauthnError> {
    let (user_unique_id, auth_state): (Uuid, PasskeyAuthentication) = session
        .get("auth_state")
        .await
        .map_err(|_| WebauthnError::CorruptSession)?
        .ok_or(WebauthnError::CorruptSession)?;

    let _ = session.remove_value("auth_state").await;

    let res = match app_state
        .webauthn
        .finish_passkey_authentication(&auth, &auth_state)
    {
        Ok(auth_result) => {
            let cred_id_bytes = auth.raw_id.to_vec();

            let record = sqlx::query!("SELECT passkey_data FROM passkeys WHERE cred_id = $1", cred_id_bytes)
                .fetch_optional(&app_state.db)
                .await
                .map_err(|_| WebauthnError::Unknown)?;

            let record = record.ok_or(WebauthnError::UserHasNoCredentials)?;
            let mut sk: Passkey = serde_json::from_value(record.passkey_data).unwrap();

            sk.update_credential(&auth_result);

            let updated_json = serde_json::to_value(&sk).unwrap();
            sqlx::query!(
                "UPDATE passkeys SET passkey_data = $1 WHERE cred_id = $2",
                updated_json, cred_id_bytes
            )
            .execute(&app_state.db)
            .await
            .map_err(|_| WebauthnError::Unknown)?;

            session.insert("user_id", user_unique_id).await.expect("Failed to insert user_id in session");

            StatusCode::OK
        }
        Err(e) => {
            error!("finish_authentication -> {:?}", e);
            StatusCode::BAD_REQUEST
        }
    };
    Ok(res)
}
