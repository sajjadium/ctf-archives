import { useState, useEffect } from 'react'

export interface Toast {
  id: string
  title: string
  description?: string
  variant?: 'success' | 'destructive'
}

let toasts: Toast[] = []
let listeners: ((toasts: Toast[]) => void)[] = []

const emit = () => listeners.forEach(l => l(toasts))

export function toast(opts: Omit<Toast, 'id'>) {
  const id = Math.random().toString(36).slice(2)
  toasts = [...toasts, { ...opts, id }]
  emit()
  setTimeout(() => {
    toasts = toasts.filter(t => t.id !== id)
    emit()
  }, 4000)
}

export function useToastState() {
  const [state, setState] = useState(toasts)
  useEffect(() => {
    listeners.push(setState)
    return () => { listeners = listeners.filter(l => l !== setState) }
  }, [])
  return state
}
