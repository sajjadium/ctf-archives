import { useState } from 'react'
import axios from 'axios'
import { useAuth, getBaseUrl } from '@/lib/auth'
import { toast } from '@/hooks/useToast'

const TARGET = 5_000_000

export default function WithdrawPage() {
  const { user } = useAuth()
  const [flag, setFlag] = useState('')
  const [busy, setBusy] = useState(false)

  const balance = Number(user?.balance ?? 0)

  const handleWithdraw = async () => {
    setBusy(true)
    try {
      const r = await axios.post(`${getBaseUrl()}/api/flag`)
      setFlag(r.data.flag)
    } catch {
      toast({
        title: 'Insufficient holdings',
        description: `${TARGET.toLocaleString()} BTC required`,
        variant: 'destructive',
      })
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <h1>Withdraw</h1>
      <p className="muted">Requires {TARGET.toLocaleString()} BTC.</p>
      <p className="big">{balance.toFixed(8)} BTC</p>
      <button className="primary" onClick={handleWithdraw} disabled={busy || balance < TARGET}>
        Withdraw
      </button>
      {flag && <p className="flag">{flag}</p>}
    </>
  )
}
