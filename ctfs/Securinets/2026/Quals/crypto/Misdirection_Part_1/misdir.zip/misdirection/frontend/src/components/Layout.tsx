import { NavLink, Outlet, Navigate } from 'react-router-dom'
import { useAuth } from '@/lib/auth'

const links = [
  ['/dashboard', 'Dashboard'],
  ['/trade', 'Trade'],
  ['/withdraw', 'Withdraw'],
  ['/settings', 'Settings'],
]

export default function Layout() {
  const { user, loading, logout } = useAuth()

  if (loading) return null
  if (!user) return <Navigate to="/auth" replace />

  return (
    <>
      <nav>
        {links.map(([to, label]) => (
          <NavLink key={to} to={to} className={({ isActive }) => (isActive ? 'active' : '')}>
            {label}
          </NavLink>
        ))}
        {user.is_admin && <NavLink to="/admin">Admin</NavLink>}
        <span className="spacer" />
        <span className="muted">{user.username}</span>
        <button onClick={logout}>Sign out</button>
      </nav>
      <main>
        <Outlet />
      </main>
    </>
  )
}
