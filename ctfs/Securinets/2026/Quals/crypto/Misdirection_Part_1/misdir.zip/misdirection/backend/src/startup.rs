use axum::http::HeaderValue;
use sqlx::{Pool, Postgres};
use std::env;
use webauthn_rs::prelude::*;

#[derive(Clone)]
pub struct AppState {
    pub webauthn: Webauthn,
    pub db: Pool<Postgres>,
}

impl AppState {
    pub fn new(db: Pool<Postgres>) -> Self {
        let rp_origin = Url::parse(&var("FRONTEND_URL")).expect("Invalid FRONTEND_URL");
        let webauthn = WebauthnBuilder::new(&var("RP_ID"), &rp_origin)
            .and_then(|builder| builder.build())
            .expect("Invalid webauthn configuration");
        Self { webauthn, db }
    }
}

pub fn var(name: &str) -> String {
    env::var(name).unwrap_or_else(|_| panic!("{name} must be set"))
}

pub fn frontend_origin() -> HeaderValue {
    var("FRONTEND_URL").parse().expect("Invalid FRONTEND_URL")
}
