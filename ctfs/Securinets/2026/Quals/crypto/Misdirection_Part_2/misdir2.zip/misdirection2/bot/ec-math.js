const { BN, P256_P, P256_A } = require('./config');

function modInv(a, p) {
    return a.toRed(BN.mont(p)).redInvm().fromRed();
}

function pointAdd(p1, p2, p) {
    if (!p1) return p2;
    if (!p2) return p1;
    if (p1.x.eq(p2.x) && !p1.y.eq(p2.y)) return null;

    let lambda;
    if (p1.x.eq(p2.x) && p1.y.eq(p2.y)) {
        const num = p1.x.sqr().mul(new BN(3)).add(P256_A).umod(p);
        const den = p1.y.mul(new BN(2)).umod(p);
        lambda = num.mul(modInv(den, p)).umod(p);
    } else {
        const num = p2.y.sub(p1.y).umod(p);
        const den = p2.x.sub(p1.x).umod(p);
        lambda = num.mul(modInv(den, p)).umod(p);
    }

    const x3 = lambda.sqr().sub(p1.x).sub(p2.x).umod(p);
    const y3 = lambda.mul(p1.x.sub(x3)).sub(p1.y).umod(p);
    return { x: x3, y: y3 };
}

function scalarMultUnsafe(scalar, point) {
    let result = null;
    let addend = point;
    let k = scalar.clone();
    while (k.gtn(0)) {
        if (k.isOdd()) result = pointAdd(result, addend, P256_P);
        addend = pointAdd(addend, addend, P256_P);
        k = k.ushrn(1);
    }
    return result;
}

module.exports = { pointAdd, scalarMultUnsafe };
