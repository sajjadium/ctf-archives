function installWebAuthnStub(callerDomain) {
    function buf2B64Url(buf) {
        return btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
    }
    function b64Url2Buf(b64url) {
        const b64 = b64url.replace(/-/g, '+').replace(/_/g, '/');
        const str = atob(b64);
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
        return bytes.buffer;
    }
    function b642Buf(b64) {
        const str = atob(b64);
        const bytes = new Uint8Array(str.length);
        for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i);
        return bytes.buffer;
    }
    function buf2Hex(buf) {
        return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
    }
    function hex2Buf(hex) {
        const bytes = new Uint8Array(hex.length / 2);
        for (let i = 0; i < bytes.length; i++) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
        return bytes.buffer;
    }

    const originalFetch = window.fetch;
    window.fetch = function() {
        if (arguments[1]) {
            arguments[1].credentials = 'include';
        } else {
            arguments[1] = { credentials: 'include' };
        }
        return originalFetch.apply(this, arguments);
    };

    if (typeof window.PublicKeyCredential === 'undefined') {
        window.PublicKeyCredential = function () {};
        window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable = () => Promise.resolve(true);
        window.PublicKeyCredential.isConditionalMediationAvailable = () => Promise.resolve(false);
    }

    const _regCredId = new Uint8Array(32);
    window.crypto.getRandomValues(_regCredId);
    const _regCredIdHex = buf2Hex(_regCredId);

    function isValidRpId(rpId) {
        return callerDomain === rpId || callerDomain.endsWith('.' + rpId);
    }

    const credStub = {
        create: async (options) => {
            if (options && options.publicKey) {
                const rpId = options.publicKey.rp.id || callerDomain;
                if (!isValidRpId(rpId)) throw new DOMException('', 'SecurityError');
                const challenge = buf2B64Url(options.publicKey.challenge);
                const payload = await window.forgeRegistration(rpId, challenge, _regCredIdHex);

                return {
                    id: buf2B64Url(_regCredId),
                    rawId: _regCredId.buffer,
                    type: "public-key",
                    response: {
                        clientDataJSON: b642Buf(payload.clientDataJSON),
                        attestationObject: b642Buf(payload.attestationObject),
                        getTransports: () => ["internal"]
                    },
                    getClientExtensionResults: () => ({})
                };
            }
            return null;
        },
        get: async (options) => {
            if (options && options.publicKey) {
                const rpId = options.publicKey.rpId || callerDomain;
                if (!isValidRpId(rpId)) throw new DOMException('', 'SecurityError');
                const challenge = buf2B64Url(options.publicKey.challenge);

                const allowList = options.publicKey.allowCredentials || [];
                const credIdBuf = allowList.length > 0 ? allowList[0].id : _regCredId.buffer;
                const credIdB64Url = buf2B64Url(credIdBuf);

                const payload = await window.forgeAuthentication(rpId, challenge, credIdB64Url);

                let userHandle = null;
                const saltB64 = options.publicKey.extensions && options.publicKey.extensions.prf
                    && options.publicKey.extensions.prf.eval
                    && options.publicKey.extensions.prf.eval.first;
                if (saltB64) {
                    const prfOutHex = await window.forgePrf(rpId, buf2Hex(b64Url2Buf(saltB64)));
                    if (prfOutHex) userHandle = hex2Buf(prfOutHex);
                }

                return {
                    id: payload.credIdB64Url,
                    rawId: b64Url2Buf(payload.credIdB64Url),
                    type: "public-key",
                    response: {
                        authenticatorData: b642Buf(payload.authenticatorData),
                        clientDataJSON: b642Buf(payload.clientDataJSON),
                        signature: b642Buf(payload.signature),
                        userHandle
                    },
                    getClientExtensionResults: () => ({})
                };
            }
            return null;
        },
        store: async () => {},
        preventSilentAccess: async () => {}
    };

    Object.defineProperty(navigator, 'credentials', { value: credStub, configurable: true });
}

module.exports = { installWebAuthnStub };
