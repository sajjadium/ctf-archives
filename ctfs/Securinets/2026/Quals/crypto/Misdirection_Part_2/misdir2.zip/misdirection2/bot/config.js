const crypto = require('crypto');
const EC = require('elliptic').ec;
const BN = require('bn.js');

const ec = new EC('p256');

const ADMIN_PRIVATE_KEY = process.env.ADMIN_PRIVATE_KEY;
if (!ADMIN_PRIVATE_KEY) {
    console.log('ERROR: ADMIN_PRIVATE_KEY env var not set');
    process.exit(1);
}

const WEBAUTHN_ORIGIN = process.env.WEBAUTHN_ORIGIN;
const REAL_DOMAIN = new URL(WEBAUTHN_ORIGIN).hostname;
const keyPair = ec.keyFromPrivate(ADMIN_PRIVATE_KEY, 'hex');
const BOT_USERNAME = `_bot_${crypto.randomBytes(4).toString('hex')}`;

// P-256 curve params
const P256_P = new BN('ffffffff00000001000000000000000000000000ffffffffffffffffffffffff', 16);
const P256_A = P256_P.sub(new BN(3));

module.exports = { ec, BN, keyPair, ADMIN_PRIVATE_KEY, WEBAUTHN_ORIGIN, REAL_DOMAIN, BOT_USERNAME, P256_P, P256_A };
