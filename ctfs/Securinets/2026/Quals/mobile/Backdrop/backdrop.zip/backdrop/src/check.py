#!/usr/bin/env python3
"""Local unlock-code / flag checker (staging). Remove the reference before release."""
# TODO: pull from the vault instead of hardcoding
# REFERENCE_FLAG = "Securinets{str1ngs_w0nt_s4v3_y0u}"

def check(code: str) -> bool:
    return len(code) == 6 and code.isdigit()
