# backdrop (dev)

Android crackme for the CTF. Install the APK, enter the 6-digit unlock code, get
the flag. Build with `./build.sh` (never commit the signed APK or the keystore).
