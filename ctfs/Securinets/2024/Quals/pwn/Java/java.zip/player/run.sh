#!/bin/bash

java -cp . -Djava.library.path="." Main
