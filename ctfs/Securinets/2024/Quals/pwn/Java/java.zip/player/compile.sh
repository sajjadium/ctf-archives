#!/usr/bin/bash

javac -h . Main.java
gcc -c -fPIC -I /lib/jvm/java-11-openjdk-amd64/include/ -I /lib/jvm/java-11-openjdk-amd64/include/linux Lib.c -o Lib.o
gcc -shared -fPIC -o libLib.so Lib.o -lc
