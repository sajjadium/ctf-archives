import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

   private String first = "";
   private String second = "";
   private String last = "";

   static {
      System.loadLibrary("Lib");
   }

   public native void Kabom();
   public native void Setup();

   public static void main(String[] args) throws IOException{
      BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
      Main me = new Main();

      me.Setup();

      //System.out.println("If I give you a gift, will you give me the right input? ");
      //me.Gift();

      System.out.println("And I'll give you 3 bullets");

      System.out.println("First shot: ");
      me.first = reader.readLine();

      System.out.println("Second shot: ");
      me.second = reader.readLine();

      System.out.println("Last shot: ");
      me.last = reader.readLine();

      me.Kabom();
   }
}
