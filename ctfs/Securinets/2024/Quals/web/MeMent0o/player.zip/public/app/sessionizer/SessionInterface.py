import base64
import yaml
from flask import current_app
from flask.sessions import SessionInterface
from itsdangerous import BadSignature, Signer
from .Session import Session

class CustomSessionInterface(SessionInterface):
    kvSession = Session
    def open_session(self, app, request):
        key = app.secret_key

        if key is not None:
            session_cookie = request.cookies.get(
                app.config['SESSION_COOKIE_NAME'], None)
            s = None
            if session_cookie:
                try:
                    sid_s = Signer(app.secret_key).unsign(
                        session_cookie).decode('ascii')
                    sid = Session.unserialize(sid_s)

                    if sid.has_expired(app.permanent_session_lifetime):
                        raise KeyError
                    s = self.kvSession(
                            yaml.load(base64.b64decode( current_app.kvsession_store.get(sid_s) ), Loader=yaml.UnsafeLoader)
                        )
                    s.sid_s = sid_s
                except (BadSignature, KeyError):
                    pass
            if s is None:
                s = self.kvSession()
                s.new = True

            return s

    def save_session(self, app, session, response):
        if session.modified:
            if not getattr(session, 'sid_s', None):
                session.sid_s = Session(
                    current_app.config['SESSION_RANDOM_SOURCE'].getrandbits(
                        app.config['SESSION_KEY_BITS'])).serialize()
            data = yaml.dump(dict(session), default_flow_style=False)
            store = current_app.kvsession_store
            store.put(session.sid_s, base64.b64encode(data.encode()))
            session.new = False
            session.modified = False
            cookie_data = Signer(app.secret_key).sign(
                session.sid_s.encode('ascii'))
            response.set_cookie(key=app.config['SESSION_COOKIE_NAME'],
                                value=cookie_data,
                                expires=self.get_expiration_time(app, session),
                                path=self.get_cookie_path(app),
                                domain=self.get_cookie_domain(app),
                                secure=app.config['SESSION_COOKIE_SECURE'],
                                httponly=app.config['SESSION_COOKIE_HTTPONLY'])




