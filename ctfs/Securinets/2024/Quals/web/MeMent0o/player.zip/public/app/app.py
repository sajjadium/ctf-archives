from flask import Flask, request, render_template, redirect, url_for, session, flash
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
import os
import pymysql
import requests
from functools import wraps

from sessionizer import SessionHandler
from sessionizer.FilesystemStore import FilesystemStore


app = Flask(__name__)
CSRFProtect(app)

store = FilesystemStore("/tmp/sessions")
SessionHandler(store, app)

MYSQL_HOST = os.getenv("MYSQL_HOST", "localhost")
MYSQL_USER = os.getenv("MYSQL_USER", "memento")
MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD")
MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "mementodb")
ADMIN_USERNAME=os.getenv("ADMIN_USERNAME","admin")
AUTH_SERVICE_URL = os.getenv("AUTH_SERVICE_URL", "http://localhost:1234")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD","REDACTED")

def get_db():
    return pymysql.connect(
        host=MYSQL_HOST,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE,
        cursorclass=pymysql.cursors.DictCursor
    )

def get_auth_token():
    response = requests.post(f"{AUTH_SERVICE_URL}/get_token", json={"username": ADMIN_USERNAME, "password": ADMIN_PASSWORD})
    return response.json()["token"]

def get_secret():
    token = get_auth_token()
    response = requests.get(f"{AUTH_SERVICE_URL}/get_secret_key", headers={"Auth": token})
    return response.json()["Secret_key"]


def get_creds():
	resp=requests.post(f"{AUTH_SERVICE_URL}/get_token",json={
        "username":ADMIN_USERNAME,
        "password":ADMIN_PASSWORD})
	token=resp.json()["token"]
	r=requests.get(f"{AUTH_SERVICE_URL}/get_creds",headers={"Auth":token})
	return r.json()



app.secret_key = get_secret()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            flash("Please log in to access this page.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None or session.get("username") is None or session["username"] != "admin":
            flash("Please log in as admin to access this page.", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("notes"))

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password or len(username) >= 50:
            flash("Invalid username or password", "error")
            return render_template("register.html")

        with get_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                if cursor.fetchone():
                    flash("Username already exists", "error")
                    return render_template("register.html")

                hashed_password = generate_password_hash(password)
                cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))
                conn.commit()
                
                cursor.execute("SELECT id FROM users WHERE username = %s", (username,))
                user = cursor.fetchone()

        session["user_id"] = user["id"]
        session["username"] = username
        flash("Registration successful!", "success")
        return redirect(url_for("notes"))

    return render_template("register.html")

@app.route("/",methods=["GET"])
def home():
	if session.get("username") is not None :
		return render_template("index.html",username=session["username"])
	else:
 		return redirect("/login")



@app.route("/notes", methods=["GET", "POST"])
@login_required
@admin_required
def notes():
    result = []
    if request.method == "POST":
        title = request.form.get("title")
        content = request.form.get("content")
        if not title or not content:
            flash("Title and content are required", "error")
        else:
            with get_db() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("INSERT INTO notes (title, content) VALUES (%s, %s)",
                                   (title, content))
                conn.commit()
            flash("Note added successfully!", "success")

    creds = get_creds()
    with get_db() as conn:
        with conn.cursor() as cursor:
            if session.get("username") == creds["username"]:
                query = "SELECT * FROM notes WHERE title LIKE '%{search}%'"
                cursor.execute(query.format(search=request.args.get("search")))
            else:
                cursor.execute("SELECT * FROM notes")
            result = cursor.fetchall()

    return render_template("notes.html", notes=result, username=session.get("username"))

@app.route("/note/<int:note_id>", methods=["GET", "POST"])
@login_required
@admin_required
def edit_note(note_id):
    with get_db() as conn:
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM notes WHERE id = %s", (note_id,))
            note = cursor.fetchone()

    if not note:
        flash("Note not found or you don't have permission to edit it", "error")
        return redirect(url_for("notes"))

    if request.method == "POST":
        title = request.form.get("title")
        content = request.form.get("content")
        
        if not title or not content:
            flash("Title and content are required", "error")
        else:
            with get_db() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("UPDATE notes SET title = %s, content = %s WHERE id = %s",
                                   (title, content, note_id,))
                    conn.commit()
            flash("Note updated successfully!", "success")
            return redirect(url_for("notes"))

    return render_template("edit_note.html", note=note)

@app.route("/note/<int:note_id>/delete", methods=["POST"])
@login_required
@admin_required
def delete_note(note_id):
    with get_db() as conn:
        with conn.cursor() as cursor:
            cursor.execute("DELETE FROM notes WHERE id = %s", (note_id,))
            conn.commit()
    
    flash("Note deleted successfully!", "success")
    return redirect(url_for("notes"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("notes"))

    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")

        if not username or not password:
            flash("Invalid username or password", "error")
            return render_template("login.html")

        creds=get_creds()
        if username==creds["username"] and password==creds["password"]:
            session["user_id"] = 1
            session["username"] = username
            flash("Logged in successfully!", "success")
            return redirect(url_for("notes"))

        with get_db() as conn:
            with conn.cursor() as cursor:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                user = cursor.fetchone()
                if user and check_password_hash(user["password"], password):
                    session["user_id"] = user["id"]
                    session["username"] = user["username"]
                    flash("Logged in successfully!", "success")
                    return redirect(url_for("notes"))

        flash("Invalid username or password", "error")

    return render_template("login.html")

@app.route("/logout", methods=["GET"])
def logout():
    session.clear()
    flash("Logged out successfully!", "success")
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=False)