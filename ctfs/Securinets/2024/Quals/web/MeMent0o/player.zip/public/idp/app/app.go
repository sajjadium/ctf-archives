package main

import (
	"crypto/rsa"
	"database/sql"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"log"
	"math/big"
	"net/http"
	"os"

	"io"

	_ "github.com/go-sql-driver/mysql"
	"github.com/golang-jwt/jwt/v5"
	"github.com/gorilla/mux"
	"golang.org/x/crypto/bcrypt"
)

var (
	USERNAME   = os.Getenv("USERNAME")
	PASSWORD   = os.Getenv("PASSWORD")
	SECRET_KEY = os.Getenv("SECRET_KEY")
	db         *sql.DB
	privateKey *rsa.PrivateKey
)

type User struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

func main() {
	var err error
	fmt.Printf("%s:%s@tcp(authdb:3306)/mementodb", "memento", os.Getenv("MYSQL_PASSWORD"))
	db, err = sql.Open("mysql", fmt.Sprintf("%s:%s@tcp(authdb:3306)/mementodb", "memento", os.Getenv("MYSQL_PASSWORD")))
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	privateKeyBytes, err := os.ReadFile("keypair.pem")
	if err != nil {
		log.Fatal(err)
	}
	privateKey, err = jwt.ParseRSAPrivateKeyFromPEM(privateKeyBytes)
	if err != nil {
		log.Fatal(err)
	}

	r := mux.NewRouter()
	r.HandleFunc("/register", register).Methods("POST")
	r.HandleFunc("/.well-known/jwks.json", jwks).Methods("GET")
	r.HandleFunc("/get_secret_key", getSecretKey).Methods("GET")
	r.HandleFunc("/get_creds", getCreds).Methods("GET")
	r.HandleFunc("/get_token", getToken).Methods("POST")

	log.Fatal(http.ListenAndServe(":8080", r))
}

func register(w http.ResponseWriter, r *http.Request) {
	var user User
	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if user.Username == "" || len(user.Username) >= 50 || user.Password == "" {
		http.Error(w, "Invalid username or password", http.StatusBadRequest)
		return
	}
	var exists bool
	err := db.QueryRow("SELECT EXISTS(SELECT 1 FROM users WHERE username = ?)", user.Username).Scan(&exists)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}
	if exists {
		http.Error(w, "Username already exists", http.StatusConflict)
		return
	}
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(user.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	_, err = db.Exec("INSERT INTO users (username, password) VALUES (?, ?)", user.Username, string(hashedPassword))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	token, err := createToken(user.Username)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"token": token})
}

func jwks(w http.ResponseWriter, r *http.Request) {
	publicKey := privateKey.Public().(*rsa.PublicKey)
	n := base64.RawURLEncoding.EncodeToString(publicKey.N.Bytes())
	e := base64.RawURLEncoding.EncodeToString(big.NewInt(int64(publicKey.E)).Bytes())

	jwks := map[string]interface{}{
		"keys": []map[string]interface{}{
			{
				"kty": "RSA",
				"use": "sig",
				"alg": "RS256",
				"kid": "001122334455",
				"n":   n,
				"e":   e,
			},
		},
	}
	json.NewEncoder(w).Encode(jwks)
}

func getSecretKey(w http.ResponseWriter, r *http.Request) {
	token := r.Header.Get("Auth")
	if token == "" {
		http.Error(w, "You are not authenticated", http.StatusUnauthorized)
		return
	}

	claims, err := decodeToken(token)
	if err != nil {
		http.Error(w, "Invalid token: "+err.Error(), http.StatusUnauthorized)
		return
	}

	username, ok := (*claims)["username"].(string)
	if !ok {
		http.Error(w, "Invalid token claims", http.StatusUnauthorized)
		return
	}

	if username != "admin" {
		http.Error(w, "You are not authorized", http.StatusForbidden)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"Secret_key": SECRET_KEY})
}

func getCreds(w http.ResponseWriter, r *http.Request) {
	token := r.Header.Get("Auth")
	if token == "" {
		http.Error(w, "You are not authenticated", http.StatusUnauthorized)
		return
	}

	claims, err := decodeToken(token)
	if err != nil {
		http.Error(w, "Invalid token: "+err.Error(), http.StatusUnauthorized)
		return
	}

	username, ok := (*claims)["username"].(string)
	if !ok {
		http.Error(w, "Invalid token claims", http.StatusUnauthorized)
		return
	}

	if username != "admin" {
		http.Error(w, "You are not authorized", http.StatusForbidden)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"username": USERNAME, "password": PASSWORD})
}

func getToken(w http.ResponseWriter, r *http.Request) {
	var user User
	if err := json.NewDecoder(r.Body).Decode(&user); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if user.Username == "" || user.Password == "" {
		http.Error(w, "No username or password specified", http.StatusBadRequest)
		return
	}

	var storedPassword string
	err := db.QueryRow("SELECT password FROM users WHERE username = ?", user.Username).Scan(&storedPassword)
	if err != nil {
		if err == sql.ErrNoRows {
			http.Error(w, "Username or password is incorrect", http.StatusUnauthorized)
		} else {
			http.Error(w, err.Error(), http.StatusInternalServerError)
		}
		return
	}

	if storedPassword != user.Password {
		http.Error(w, "Username or password is incorrect", http.StatusUnauthorized)
		return
	}

	token, err := createToken(user.Username)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{"token": token})
}

func createToken(username string) (string, error) {
	token := jwt.NewWithClaims(jwt.SigningMethodRS256, jwt.MapClaims{
		"username": username,
	})
	token.Header["kid"] = "001122334455"
	token.Header["jku"] = "http://localhost:8080/.well-known/jwks.json"

	return token.SignedString(privateKey)
}

func decodeToken(tokenString string) (*jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodRSA); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}

		jku, ok := token.Header["jku"].(string)
		if !ok {
			return nil, fmt.Errorf("jku header is missing or invalid")
		}

		kid, ok := token.Header["kid"].(string)
		if !ok {
			return nil, fmt.Errorf("kid header is missing or invalid")
		}

		pubKey, err := retrievePubKey(jku, kid)
		if err != nil {
			return nil, fmt.Errorf("failed to retrieve public key: %v", err)
		}

		return pubKey, nil
	})

	if err != nil {
		return nil, err
	}

	if claims, ok := token.Claims.(jwt.MapClaims); ok && token.Valid {
		return &claims, nil
	}

	return nil, fmt.Errorf("invalid token")
}

func retrievePubKey(jkuURL, kid string) (*rsa.PublicKey, error) {
	resp, err := http.Get(jkuURL)
	if err != nil {
		return nil, fmt.Errorf("error fetching JWKS: %v", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("error reading JWKS response: %v", err)
	}

	var jwks struct {
		Keys []struct {
			Kid string `json:"kid"`
			N   string `json:"n"`
			E   string `json:"e"`
		} `json:"keys"`
	}

	if err := json.Unmarshal(body, &jwks); err != nil {
		return nil, fmt.Errorf("error parsing JWKS: %v", err)
	}

	var selectedKey *struct {
		Kid string `json:"kid"`
		N   string `json:"n"`
		E   string `json:"e"`
	}

	for i := range jwks.Keys {
		if jwks.Keys[i].Kid == kid {
			selectedKey = &jwks.Keys[i]
			break
		}
	}

	if selectedKey == nil {
		return nil, fmt.Errorf("no matching key found for kid: %s", kid)
	}

	nBytes, err := base64.RawURLEncoding.DecodeString(selectedKey.N)
	if err != nil {
		return nil, fmt.Errorf("error decoding modulus: %v", err)
	}

	eBytes, err := base64.RawURLEncoding.DecodeString(selectedKey.E)
	if err != nil {
		return nil, fmt.Errorf("error decoding exponent: %v", err)
	}

	n := new(big.Int).SetBytes(nBytes)
	e := int(new(big.Int).SetBytes(eBytes).Int64())

	pubKey := &rsa.PublicKey{
		N: n,
		E: e,
	}
	return pubKey, nil
}
