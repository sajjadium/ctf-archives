#!/bin/sh
touch /var/run/mysqld/mysqld.sock
chown -R mysql /var/run/mysqld
/etc/init.d/mysql restart 

echo "Creating new user ${MYSQL_USER} ..."
mysql -uroot -p$MYSQL_ROOT_PASSWORD -e "CREATE USER '${MYSQL_USER}'@'%' IDENTIFIED BY '${MYSQL_PASSWORD}';"
echo "Granting privileges..."
mysql -uroot -p$MYSQL_ROOT_PASSWORD -e "GRANT ALL PRIVILEGES ON *.* TO '${MYSQL_USER}'@'%';"
mysql -uroot -p$MYSQL_ROOT_PASSWORD -e "FLUSH PRIVILEGES;"
echo "All done."

mysql -u$MYSQL_USER -p$MYSQL_PASSWORD -e "CREATE database mementodb;"
mysql -u$MYSQL_USER -p$MYSQL_PASSWORD mementodb  < /app/init.sql
echo "All done."
sleep 12
service nginx start
python3 app.py