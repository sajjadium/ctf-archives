#!/bin/bash
chmod 000 /flag
chmod 4755 /readflag
java -jar /Javolution-0.0.1-SNAPSHOT.jar