# Tagebuch

A simple diary sharing site, but vulnerable. (TSCTF 2024)
