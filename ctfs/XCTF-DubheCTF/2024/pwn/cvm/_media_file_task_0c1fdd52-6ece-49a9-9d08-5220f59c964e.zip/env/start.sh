#!/bin/sh
# Add your startup script
echo -n 'DubheCTF{fake_flag}' > /home/ctf/flag
chmod 744 /home/ctf/flag

# DO NOT DELETE
/etc/init.d/xinetd start;
sleep infinity;
