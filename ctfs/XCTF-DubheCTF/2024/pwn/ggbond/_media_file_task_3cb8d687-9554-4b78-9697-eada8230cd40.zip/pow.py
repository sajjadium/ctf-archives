
import string
import itertools
import re
from pwn import *
from hashlib import sha256

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#
    # The container will be destroyed after 20 seconds 
    # or when the 'p' socket connection is closed.
    
    # The Docker container challenge's internal network cannot 
    # connect to the external network.
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#

remote_ip = ''
remote_port = 1337

def pow():
    p = remote(remote_ip, remote_port)
    rev = p.recvuntil(b' == ').decode()
    pattern = r'xxxx\+([a-zA-Z0-9]+)'
    rev = re.search(pattern, rev).group(1)
    target_digest = p.recv(64).decode()

    characters = string.ascii_letters + string.digits
    all_combinations = [''.join(comb) for comb in itertools.product(characters, repeat=4)]
    for comb in all_combinations:
        proof = comb+rev
        digest = sha256(proof.encode()).hexdigest()
        if target_digest == digest:
            result = comb
            break
    p.send(result) 
    
    p.recvuntil(b' nc ')
    rev = p.recvline().decode()
    pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\s(\d+)'
    result = re.search(pattern, rev)
    target_ip = result.group(1)
    target_port = int(result.group(2))
    sleep(3)
    return target_ip, target_port
        
target_ip, target_port=pow()
