# TSCTF2024-DayDream

#### The Docker deployment code originates from ByteCTF, thanks a lot.

## Environment

OS: `Android 12L('Sv2')(API 32)`

Device: `Pixel 6 Pro `

## Target

The device has an app installed, with the package name `com.tsctf.victimapp`. It contains a **non-exported** Activity: `SecretActivity`. When this Activity is launched, it will output a flag to logcat. Your goal is to launch this non-exported Activity.

## How to pwn it

1. First, you must complete the proof of work, and then provide a download link for the APK file.

```
Question: sha256(("2234e6"+"xxxx").encode()).hexdigest().startswith("000000")
Please enter xxxx to satisfy the above conditions:
```

2. Then, the service will download your APK , install it and launch it. Please note, the file you provide for download must be a valid APK with the package name `com.tsctf.daydream`.

3. Then the victim will complete a `one-click`action, which involves automatically clicking on `Settings > Display > Screen Saver`, and then selecting the screen saver service provided by your app and **clicking on the option to enable the custom screen saver settings interface**.

4. After completing the one-click action, wait for `5 seconds` and output the information about `SecretActivity` from the `logcat logs`. If the exploit is successful, it may contain the flag. Otherwise, it might be empty.

## Vuln

The vulnerability is located in the `DreamService` service. Please thoroughly understand it before proceeding with vulnerability exploitation. Please note that in Android 12L, the vulnerability can be exploited using the `Parcel MisMatch` vulnerability. Unfortunately, **I have disabled the functionality to trigger the Parcel vulnerability by adding an account. However, if you have any other methods to exploit it and obtain the flag score, they are equally valid.**

