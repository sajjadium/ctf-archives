#!/usr/bin/env python3
# Copyright 2021 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os
import random
import shlex
import string
import subprocess
import sys
import time
import base64
import requests
import uuid
from hashlib import *
import zipfile
import signal
import traceback

random_hex = lambda x: ''.join([random.choice('0123456789abcdef') for _ in range(x)])
difficulty = 6

ADB_PORT = int(random.random() * 60000 + 5000)
EMULATOR_PORT = ADB_PORT + 1
EXPLOIT_TIME_SECS = 10

APK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app-debug.apk")
FLAG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "flag")
HOME = "/home/user"

VICTIM = "com.tsctf.victimapp"
ATTACKER = "com.tsctf.daydream"

ENV = {}
ENV.update(os.environ)
ENV.update({
    "ANDROID_ADB_SERVER_PORT": "{}".format(ADB_PORT),
    "ANDROID_SERIAL": "emulator-{}".format(EMULATOR_PORT),
    "ANDROID_SDK_ROOT": "/opt/android/sdk",
    "ANDROID_SDK_HOME": HOME,
    "ANDROID_PREFS_ROOT": HOME,
    "ANDROID_EMULATOR_HOME": HOME + "/.android",
    "ANDROID_AVD_HOME": HOME + "/.android/avd",
    "JAVA_HOME": "/usr/lib/jvm/java-17-openjdk-amd64",
    "PATH": "/opt/android/sdk/cmdline-tools/latest/bin:/opt/android/sdk/emulator:/opt/android/sdk/platform-tools:/bin:/usr/bin:" + os.environ.get("PATH", "")
})

def print_to_user(message):
    print(message)
    sys.stdout.flush()

def download_file(url):
    try:
        download_dir = "download"
        if not os.path.isdir(download_dir):
            os.mkdir(download_dir)
        tmp_file = os.path.join(download_dir, time.strftime("%m-%d-%H:%M:%S", time.localtime())+str(uuid.uuid4())+'.apk')
        f = requests.get(url)
        if len(f.content) > 10*1024*1024: # Limit size 10M
            return None
        with open(tmp_file, 'wb') as fp:
            fp.write(f.content)
        return tmp_file
    except:
        return None

def proof_of_work():
    prefix = random_hex(6)
    print_to_user(f'Question: sha256(("{prefix}"+"xxxx").encode()).hexdigest().startswith("{difficulty*"0"}")')
    print_to_user(f'Please enter xxxx to satisfy the above conditions:')
    proof = sys.stdin.readline().strip()
    return sha256((prefix+proof).encode()).hexdigest().startswith(difficulty*"0") == True

def check_apk(path):
    # Check if the file is a valid apk file
    # secrect
    pass

def setup_emulator():
    subprocess.call(
        "avdmanager" +
        " create avd" +
        " --name 'pixel_6_pro_api_32'" +
        " --abi 'google_apis/x86_64'" +
        " --package 'system-images;android-32;google_apis;x86_64'" +
        " --device pixel_6_pro" +
        " --force" +
        " > /dev/null 2> /dev/null " + 
        "",
        env=ENV,
        close_fds=True,
        shell=True)

    return subprocess.Popen(
        "emulator" +
        " -avd pixel_6_pro_api_32" +
        " -no-cache" +
        " -no-snapstorage" +
        " -no-snapshot-save" +
        " -no-snapshot-load" +
        " -no-audio" +
        " -no-window" +
        " -no-snapshot" +
        " -no-boot-anim" +
        " -wipe-data" +
        " -accel on" +
        " -netdelay none" +
        " -no-sim" +
        " -netspeed full" +
        " -delay-adb" +
        " -port {}".format(EMULATOR_PORT) +
        " > /dev/null 2> /dev/null " +
        "",
        env=ENV,
        close_fds=True,
        shell=True,
        preexec_fn=os.setsid)

def adb(args, capture_output=True):
    return subprocess.run(
        "adb {} 2> /dev/null".format(" ".join(args)),
        env=ENV,
        shell=True,
        close_fds=True,
        capture_output=capture_output).stdout

def adb_install(apk):
    adb(["install", apk])

def adb_activity(activity, extras=None, wait=False):
    args = ["shell", "am", "start"]
    if wait:
        args += ["-W"]
    args += ["-n", activity]
    if extras:
        for key in extras:
            args += ["-e", key, extras[key]]
    adb(args)

def adb_broadcast(action, receiver, extras=None):
    args = ["shell", "su", "root", "am", "broadcast", "-W", "-a", action, "-n", receiver]
    if extras:
        for key in extras:
            args += ["-e", key, extras[key]]
    adb(args)

def wait_for_device_boot_complete():
    print_to_user("Waiting for device to boot...\n")
    while True:
        result = subprocess.run("adb shell getprop sys.boot_completed",env=ENV, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True).stdout
        if '1' in result:
            print_to_user("Device booted.\n")
            break
        time.sleep(1)
        
def one_click():
    adb(["shell", "am", "start", "-a", "android.settings.DREAM_SETTINGS"])
    adb(["shell", "sleep", "10"])
    adb(["shell", "input", "keyevent", "KEYCODE_DPAD_DOWN"])
    adb(["shell", "sleep", "1"])
    adb(["shell", "input", "keyevent", "KEYCODE_ENTER"])
    adb(["shell", "sleep", "5"])

    adb(["shell", "input", "tap", "675", "1415"])

    adb(["shell", "sleep", "5"])
    adb(["shell", "input", "tap", "1256", "842"])
    adb(["shell", "sleep", "1"])


print_to_user("Welcome to DubheCTF2024 DayDream! Please proof of work to continue.\n")

if not proof_of_work():
    print_to_user("Please proof of work again, exit...\n")
    exit(-1)
        
print_to_user("Please enter your apk url:")
url = sys.stdin.readline().strip()
EXP_FILE = download_file(url)
if not check_apk(EXP_FILE):
    print_to_user("Invalid apk file.\n")
    exit(-1)

print_to_user("Preparing android emulator. This may takes about 2 minutes...\n")
emulator = setup_emulator()
adb(["wait-for-device"])

wait_for_device_boot_complete()
adb(["shell", "su", "root", "pm", "disable", "com.android.settings/.accounts.AddAccountSettings"])

adb_install(APK_FILE)
adb_activity(f"{VICTIM}/.MainActivity", wait=True)
with open(FLAG_FILE, "r") as f:
    adb_broadcast(f"com.tsctf.SET_FLAG", f"{VICTIM}/.FlagReceiver", extras={"flag": f.read()})

time.sleep(3)
adb_install(EXP_FILE)
adb_activity(f"{ATTACKER}/.MainActivity")

print_to_user("Launching!\n")

time.sleep(10)
one_click()
print_to_user("One_click finished! The logcat log will be output after 5 seconds.\n")
time.sleep(5)
adb(["shell","logcat -d -s SecretActivity", ">" ,"/logcat_"+ str(ADB_PORT) + ".txt"])

with open("/logcat_"+ str(ADB_PORT) + ".txt", "r") as f:
    print_to_user(f.read())
print_to_user("Logcat output finished, the emulator will shutdown after 5 seconds.\n")
time.sleep(5)

print_to_user("Shutting down emulator...\n")
try:
    os.killpg(os.getpgid(emulator.pid), signal.SIGTERM)
except:
    traceback.print_exc()