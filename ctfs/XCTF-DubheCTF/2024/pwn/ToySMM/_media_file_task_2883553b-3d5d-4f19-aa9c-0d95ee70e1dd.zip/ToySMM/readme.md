## Quick start

`./run.sh`

## Files

+ flagregion 

​	Real flag (Not very real :)

+ kvmvapic.bin

​	Used by qemu-system-x86_64

+ qemu-system-x86_64

​	Self build qemu with some patch to smm region (Hide real flag in 0x23330000)

+ run.sh

​	Start the virtual UEFI OVMF env.

+ OVMF_CODE.fd OVMF_VARS.fd

​	UEFI emulation env build with edk2

+ rootfs

​	Store a nsh file to auth start ToyApp.efi

## Notice && Tips

+ Seld-build qemu-systyem-x86_64 is built and tested on ubuntu

+ [UEFITools](https://github.com/LongSoft/UEFITool)  is a tool parse UEFI Firmware package

+ Only Ring -2 privileges can read the correct flag in 0x23330000

  

