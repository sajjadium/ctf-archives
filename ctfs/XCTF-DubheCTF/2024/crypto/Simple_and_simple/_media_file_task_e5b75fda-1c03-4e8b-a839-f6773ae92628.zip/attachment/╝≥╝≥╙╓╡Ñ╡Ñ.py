from sage.all import *
from hashlib import md5


def ternary_with_density(density):
    tmp = randrange(0, density)
    if tmp == 0:
        return 1
    elif tmp == 1:
        return -1
    else:
        return 0


def get_matrix(density):
    P = identity_matrix(ZZ, dims)
    for _ in range(2):
        Li = identity_matrix(ZZ, dims)
        Ui = identity_matrix(ZZ, dims)
        for i in range(dims):
            for j in range(i + 1, dims):
                Li[i, j] = ternary_with_density(density)
                Ui[j, i] = ternary_with_density(density)
        P *= Li * Ui
    return P


dims = 190
bits = 20
density = 30
p = random_prime(2**bits, lbound=2**(bits-1))
q = random_prime(2**bits, lbound=2**(bits-1))
N = p * q

X = get_matrix(density)
B = get_matrix(density)
limit = round(2.3 * RR(mean([abs(vi) for vi in (X * B).list()])))
K = random_matrix(ZZ, dims, x=-limit, y=limit+1)

Y = random_matrix(Zmod(N), dims).change_ring(ZZ)
C = p * random_matrix(Zmod(q), dims).change_ring(ZZ)
A = (X.inverse() * (K - Y * C)).change_ring(ZZ)

secret = get_matrix(density)[0]
flag = 'DubheCTF{' + md5(str(secret).encode()).hexdigest() + '}'

r = random_vector(ZZ, dims, x=-N, y=N)
t = get_matrix(density)[0]
cipher = secret * A + r * C + t
data = str(cipher.list()) + '\n' + str(X.list()) + '\n' + str(B.list()) + '\n' + str(C.list()) + '\n' + str(K.list())
open('./cipher.txt', 'w').write(data)
