#!/usr/bin/env python3
from socketserver import BaseRequestHandler,ThreadingTCPServer
import random
import os
import string
from hashlib import sha256
import signal
import json
from flag import flag

assert len(flag) == 42 and flag.startswith(b"DubheCTF{")

with open("polys.txt","r") as f:
    polys = json.load(f)

def random_poly():
    return polys[random.randint(0,len(polys)-1)]

N = 256

BANNER = br'''
 CCCCC  RRRRRR   CCCCC       GGGG    AAA   MM    MM EEEEEEE 
CC    C RR   RR CC    C     GG  GG  AAAAA  MMM  MMM EE      
CC      RRRRRR  CC         GG      AA   AA MM MM MM EEEEE   
CC    C RR  RR  CC    C    GG   GG AAAAAAA MM    MM EE      
 CCCCC  RR   RR  CCCCC      GGGGGG AA   AA MM    MM EEEEEEE 
 '''

class Task(BaseRequestHandler):

    def send(self, msg,newline=True):
        try:
            if newline:
                msg += b'\n'
            self.request.sendall(msg)
        except:
            pass

    def _recv(self, sz):
        try:
            r = sz
            res = b""
            while r > 0:
                res += self.request.recv(r)
                if res.endswith(b"\n"):
                    r = 0
                else:
                    r = sz - len(res)
            res = res.strip()
        except:
            res = b""
        return res.strip(b"\n")

    def recv(self, sz,prompt=b"> "):
        self.send(prompt,newline=False)
        return self._recv(sz)

    def _recvall(self):
        BUFF_SIZE = 1024
        data = b''
        while True:
            _recv = self.request.recv(BUFF_SIZE)
            data += _recv
            if len(_recv) < BUFF_SIZE:
                break
        return data

    def recvall(self,prompt=b"> "):
        self.send(prompt,newline=False)
        return self._recvall()

    def close(self):
        self.send(b'see you next time~~')
        self.request.close()



    def proof_of_work(self):
        random.seed(os.urandom(8))
        proof = ''.join([random.choice(string.ascii_letters + string.digits) for _ in range(20)])
        _hexdigest = sha256(proof.encode()).hexdigest()
        self.send(f"sha256(XXXX+{proof[4:]}) == {_hexdigest}".encode())
        x = self.recvall(prompt=b'Give me XXXX: ')
        if len(x) != 4 or sha256(x + proof[4:].encode()).hexdigest() != _hexdigest:
            return False
        return True

    def crc256(self,msg,IN,OUT,POLY):
        crc = IN
        for b in msg:
            crc ^= b
            for _ in range(8):
                crc = (crc >> 1) ^ (POLY & -(crc & 1))
        return (crc ^ OUT).to_bytes(32,'big')

    def setup(self):
        self.send(BANNER)

    def handle(self):
        signal.alarm(120)
        if not self.proof_of_work():
            return
        # initial
        IN = random.getrandbits(N)
        OUT = random.getrandbits(N)
        POLY = random_poly()

        for i in range(5):
            self.send(b"what do you want to do?")
            self.send(b"1.calculate crc")
            self.send(b"2.getflag")
            self.send(b"3.exit")
            try:
                choice = self.recv(5).decode()
                if choice == '1':
                    self.send(b"Give me your message")
                    msg = self.recv(100)
                    crc_hex = self.crc256(msg,IN,OUT,POLY).hex()
                    self.send(b"Here is your crc: "+crc_hex.encode())
                elif choice == '2':
                    flag_crc = self.crc256(flag,IN,OUT,POLY).hex()
                    self.send(b"Here is your flag: "+flag_crc.encode())
                else:
                    self.close()
                    return
            except:
                self.send(b"error")
                pass


if __name__ == '__main__':
    HOST, PORT = "0.0.0.0", 10000
    server = ThreadingTCPServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()



