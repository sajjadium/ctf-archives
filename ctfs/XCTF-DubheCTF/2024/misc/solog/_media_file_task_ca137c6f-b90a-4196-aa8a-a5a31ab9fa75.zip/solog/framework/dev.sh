# > solana --version
# solana-cli 1.18.1 (src:5d824a36; feat:756280933, client:SolanaLabs)

cd chall/ && cargo build-bpf && cd ..
cargo run