import atexit
import base64
import json
import os
import subprocess
from tempfile import NamedTemporaryFile

black_list = [
    "nosec",
    "import",
    "load",
    "''",
    '""',
    "[]",
    "{}",
    "().",
    "builtins",
    "dict",
    "dir",
    "locals",
    "base",
    "classes",
    "+",
    "mro",
    "attribute",
    "id",
]


def main():
    print("Hello!")
    print("Please send base64 encoded string!")
    data = input("> ")

    if len(data) > 1600:
        print("Too long")
        return

    decode_data = base64.b64decode(data).decode()
    if any(item in decode_data for item in black_list):
        print("Not Safe")
        return

    with NamedTemporaryFile("wt", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(decode_data)
        temp_filename = f.name
    atexit.register(os.remove, temp_filename)

    check_result = json.loads(
        subprocess.run(
            ["bandit", "-r", temp_filename, "-f", "json"],
            capture_output=True,
            encoding="utf-8",
        ).stdout
    )

    if len(check_result["results"]) == 0:
        print("[+] OK")
        subprocess.run(["python3", temp_filename], timeout=60)
        print("[+] Over")
    else:
        print("[+] Not Safe")
    return


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print(b"[+] FAILED!")
        pass
