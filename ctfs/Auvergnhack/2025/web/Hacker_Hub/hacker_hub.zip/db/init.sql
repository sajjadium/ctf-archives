CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    role VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    reset_token VARCHAR(255)
);

INSERT INTO users (email, role, password) VALUES ('admin-random@zitf.fr', 'admin','$2y$10$kF5jN0hIRBAcLFTS2sDz0.bEIBTLKNssiNdLGka6tO6anYvn2QFoW');
