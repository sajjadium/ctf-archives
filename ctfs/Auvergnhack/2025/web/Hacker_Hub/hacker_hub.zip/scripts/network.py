print("""
[*] NETWORK DIAGNOSTICS [*]

TO DO :P

""")