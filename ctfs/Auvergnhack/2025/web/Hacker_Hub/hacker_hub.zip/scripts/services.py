print("""
[*] SERVICES DIAGNOSTICS [*]

TO DO :P

""")