print("""
[*] FILES DIAGNOSTICS [*]

TO DO :P

""")
