print("""
[*] LOGS DIAGNOSTICS [*]

TO DO :P

""")