<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['role'] !== 'admin' ) {
    header('Location: home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Server Analysis - Hacker Hub</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #0f0f0f;
            color: #fff;
            font-family: 'Courier New', Courier, monospace;
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 30%;
            padding: 20px;
            border-right: 2px solid #9b59b6;
            box-shadow: 2px 0 20px #9b59b6;
        }
        .sidebar h2 {
            text-shadow: 0 0 20px #9b59b6;
        }
        .sidebar button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            background: #9b59b6;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .sidebar button:hover {
            box-shadow: 0 0 10px #9b59b6;
        }
        .result {
            width: 70%;
            padding: 20px;
        }
        .result h2 {
            text-shadow: 0 0 20px #8e44ad;
        }
        .result-box {
            border: 2px solid #9b59b6;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px #9b59b6;
            height: calc(100% - 40px);
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>Analysis Actions</h2>
        <form method="get">
            <input name="args" value="none" hidden>
            <button type="submit" name="task" value="network.py">Network Analysis</button>
            <p>Scan active connections, monitor traffic, and check for anomalies.</p>
        </form>
        <form method="get">
            <button type="submit" name="task" value="files.py">File System Analysis</button>
            <p>Analyze file integrity, detect suspicious changes or malware.</p>
        </form>
        <form method="get">
            <button type="submit" name="task" value="logs.py">Log Analysis</button>
            <p>Inspect server logs to trace unusual activities and errors.</p>
        </form>
        <form method="get">
            <button type="submit" name="task" value="services.py">Service Status</button>
            <p>Check running services, ports, and resource usage.</p>
        </form>
    </div>

    <div class="result">
        <h2>Analysis Results</h2>
        <div class="result-box">
            <?php
            if (isset($_GET['task'])) {
                $task = escapeshellarg($_GET['task']);
                $args = isset($_GET['args']) ? $_GET['args'] : ' ';
                chdir('/scripts');
                $command = escapeshellcmd('python3 ' . $task . ' ' . $args);

                if (str_contains($command, ';') || str_contains($command, '&') || str_contains($command, '`') || str_contains($command, '$')) {
                    echo "<pre style='color:red'>STOP HACKING !</pre>";
                } else {
                    $output = shell_exec($command);
                    echo "<pre>" . $output . "</pre>";
                }
            }
            ?>
        </div>
    </div>
</body>
</html>
