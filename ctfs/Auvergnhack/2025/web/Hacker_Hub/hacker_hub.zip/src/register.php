<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create your account</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="container">
        <div class="neon-border">
        <h1 class="glitch">Register</h1>
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Validate</button>
        </form>
        <a href="index.php">Back</a>
    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = :email');
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) {
            try {
                $stmt = $pdo->prepare('INSERT INTO users (email, role, password) VALUES (:email, \'user\', :password)');
                $stmt->execute(['email' => $email, 'password' => $password]);
                echo "<p>Success ! <a href='login.php'>Log In</a></p> ";
            } catch(PDOException $e) {
                echo "<p>Unexpected Error</p>";
            }
        } else {
            echo "<p>Error: This email is already used !</p>";
        }
    }
    ?>
</body>
</html>