<?php
session_start();
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare('SELECT email, role, password FROM users WHERE email = :email');
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        if (password_verify($password, $user['password'])) {
            $_SESSION['user'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            header('Location: home.php');
            exit();
        }
    }
    $error = "Email or Password incorrect.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Hacker Hub</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="container">
        <div class="neon-border">
            <h1 class="glitch">Login</h1>
            <form method="POST">
                <input type="email" name="email" placeholder="Email" required><br>
                <input type="password" name="password" placeholder="Password" required><br>
                <button type="submit">Go !</button>
            </form>
            <?php if (isset($error)) echo '<p style="color:red;">' . $error . '</p><br><a href="forgot_password.php">Forgot password?</a><br>'; ?>

            <a href="index.php">Back</a>
        </div>
    </div>
</body>
</html>