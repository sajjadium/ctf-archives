<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit();
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Hacker Hub</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="container">
        <div class="neon-border">
            <h1 class="glitch">Welcome to Your Dashboard</h1>
            <p>Something new and exciting is coming soon. Stay tuned...</p>
            <?php 
                if(isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
                    echo "<a href=\"analysis.php\">Go to Server Analysis</a> |";
                }
            ?>
            <a href="logout.php">Log out</a>
        </div>
    </div>
</body>
</html>
