<?php
$host = getenv('POSTGRES_HOST');
$user = getenv('POSTGRES_USER');
$password = getenv('POSTGRES_PASSWORD');
$dbname = getenv('POSTGRES_DB');

try {
    $dsn = "pgsql:host=$host;dbname=$dbname";
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => true
    ];
    $pdo = new PDO($dsn, $user, $password, $options);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

?>