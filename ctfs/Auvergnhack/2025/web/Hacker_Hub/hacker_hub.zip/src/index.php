<?php
session_start();
if (isset($_SESSION['user'])) {
    header('Location: home.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacker Hub</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
    <div class="container">
        <div class="neon-border">
            <h1 class="glitch">Welcome to the Hacker Hub</h1>
            <p>Insider access only. Enter at your own risk.</p>
            <a href="login.php">Login</a> | <a href="register.php">Registration</a> | <a href="contact.php">Contact</a>
        </div>
    </div>
</body>
</html>