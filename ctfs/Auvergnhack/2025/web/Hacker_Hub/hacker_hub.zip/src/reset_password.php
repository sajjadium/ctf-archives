<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['token'])) {
    $token = $_GET['token'];
    try {
        $stmt = $pdo->prepare('SELECT * from users WHERE reset_token = :token');
        $stmt->execute(["token" => $token]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user) {
            echo '<html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Password Reset</title>
            <link rel="stylesheet" href="./assets/styles.css">
        </head>
        <body>
        <div class="container">
        <div class="neon-border">
                <h1 class="glitch">Enter your new password</h1>
                <form method="POST" action="#">
                    <!-- <label>Nom:</label> -->
                    <input type="password" name="new_password" placeholder="New Password" required><br>
                    <button type="submit">Send</button>
                </form>
                <a href="index.php">Back</a>
            </div>
            </div>
        </body>
        </html>';
        } else {
            echo "<h1>Invalid Link !</h1>";
        }
    
    } catch (PDOException $e) {
        echo "<h1>SQL ERROR !</h1>";
    }

} elseif ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_GET['token'])) {
    $token = $_GET['token'];
    $new_password = $_POST['new_password'];
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare('UPDATE users SET password = :password, reset_token = NULL WHERE reset_token = :token');
        $stmt->execute(["password" => $hashed_password, "token" => $token]);

    } catch (PDOException $e) {
        header("Location: login.php");
        exit();
    }
} else {
    echo "<p>Token is missing.</p>";
}
?>