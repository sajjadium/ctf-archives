<?php
session_start();
include 'config.php';

function generateToken() {
    $s = date("s");
    $r = rand(6666,9999);
    $t = $s . "_ZiTF_" . $r;
    return $t;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $token = generateToken();
    
    try {
        $stmt = $pdo->prepare('UPDATE users SET reset_token = :token WHERE email = :email');
        $stmt->execute(['token' => $token, "email" => $email]);
    
        $reset_link = "http://localhost:8080/new_password.php?token=$token";
        # TO DO 
    } catch (PDOException $e) {
        # TO DO
    }
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="./assets/styles.css">
</head>
<body>
<div class="container">
<div class="neon-border">
        <h1 class="glitch">Forgot your password ?</h1>
        <form method="POST" action="#">
            <input type="email" name="email" placeholder="Email" required><br>
            <button type="submit">Send</button>
        </form>
        <a href="index.php">Back</a>
    </div>
    </div>
</body>
</html>