"use client";

import { redirect } from 'next/navigation'
import React, { useState, useEffect } from "react";
import { API_BASE_URL } from "@/env";

const ReportPage = ({ params }) => {
				const { id } = React.use(params);
				const [report, setReport] = useState(null);
				const [success, setSuccess] = useState(null);
				const [error, setError] = useState(null);

				console.log(report)

				const handleSubmit = async (e) => {
								e.preventDefault();

								try {
												const response = await fetch(`${API_BASE_URL}/api/admin/tickets/resolve/${report.id}`, {
																method: "POST",
																headers: {
																				"Content-Type": "application/json",
																}//,
																//body: JSON.stringify("{}"),
												});

												if (response.ok) {
																setSuccess("Report marked as solved!");
																setError(null);
												} else {
																setSuccess(null);
																const errorData = await response.json();
																setError(errorData.error || "Failed to resolve the report");
												}
								} catch (err) {
												console.log(err)
												setError("An error occurred. Please try again later.");
								}
								redirect('/admin/reports');
				};

				useEffect(() => {
								if (id) {
												fetch(`${API_BASE_URL}/api/admin/tickets/${id}`)
																.then((res) => res.json())
																.then((data) => {
																				if (data.error) {
																								setError(data.error);
																				} else {
																								setReport(data);
																				}
																})
																.catch(() => setError("Failed to load the report"));
								}
								console.log(report)
				}, [id]);

				if (error) {
								return (
												<div className="min-h-screen bg-neutral-900 text-neutral-200 p-6">
																<h2 className="text-xl font-semibold text-red-500">{error}</h2>
												</div>
								);
				}

				if (!report) {
								return (
												<div className="min-h-screen bg-neutral-900 text-neutral-200 p-6">
																<h2 className="text-xl font-semibold text-neutral-300">Loading report...</h2>
												</div>
								);
				}

				return (
								<div className="h-full bg-neutral-900 text-neutral-200 p-6">
												<h1 className="text-3xl font-semibold text-neutral-100 mb-8 text-center">Product Report Details</h1>

												<div className="bg-neutral-800 p-6 rounded-lg shadow-lg mb-6">
																<p className="text-lg font-semibold text-neutral-100">Product ID: {report.id}</p>
																<p className="text-lg text-neutral-300 mt-2">Reason: {report.reason}</p>
												</div>

												<div className="flex justify-center gap-4">
																<div
																				onClick={handleSubmit}
																				className="bg-yellow-600 text-neutral-100 px-6 py-2 rounded-lg hover:bg-yellow-700 transition duration-300"
																>
																				Mark As Resolved
																</div>
												</div>
								</div>
				);
};

export default ReportPage;

