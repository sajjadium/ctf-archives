"use client";

import Link from "next/link";
import Image from "next/image";

export default function Home() {
  return (
    <div className="h-full text-neutral-200 flex flex-row justify-center items-center">
      <div className="container h-full mx-auto p-6">
        {/* Hero Section */}
        <div className="text-center mb-10">
          <h1 className="text-4xl font-bold text-neutral-100">Welcome to GorillaShop</h1>
          <p className="text-neutral-400 mt-2">
            Explore our latest arrivals and report any product issues with ease!
          </p>
        </div>

        {/* New Arrivals Section */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-neutral-100 mb-4">New Arrivals</h2>
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {newArrivals.map((product) => (
              <Link key={product.id} href={`/products/${product.id}`}>
                <div className="bg-neutral-800 rounded-lg shadow-md p-4 hover:shadow-lg transition cursor-pointer">
                  <Image
                    src={`/images/${product.id}.jpg`}
                    alt={product.name}
                    width={300}
                    height={200}
                    className="w-full h-40 object-cover rounded-lg"
                  />
                  <div className="mt-3">
                    <p className="text-lg font-semibold text-neutral-100">{product.name}</p>
                    <p className="text-sm text-neutral-400">{product.description}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* Feature Announcement */}
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-neutral-100 mb-4">New Feature: Report a Product</h2>
          <p className="text-neutral-400 mb-4">
            You can now report issues with products directly from our website. Click below to submit a report.
          </p>
        </section>

        {/* Action Cards */}
        <div className="grid sm:grid-cols-2 gap-6">
          <Link href="/products">
            <div className="bg-neutral-800 rounded-lg p-6 shadow-md hover:shadow-lg transition cursor-pointer flex flex-col items-center">
              <h3 className="text-lg font-semibold text-neutral-100 mb-2">View All Products</h3>
              <p className="text-sm text-neutral-400 text-center">
                Browse our full collection of items.
              </p>
            </div>
          </Link>

          <Link href="/report">
            <div className="bg-neutral-800 rounded-lg p-6 shadow-md hover:shadow-lg transition cursor-pointer flex flex-col items-center">
              <h3 className="text-lg font-semibold text-neutral-100 mb-2">Report a Product</h3>
              <p className="text-sm text-neutral-400 text-center">
                Encountered an issue? Let us know.
              </p>
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}


// Sample Data for New Arrivals
const newArrivals = [
  { id: "1", name: "Gorilla Mug", description: "A premium quality coffee mug" },
  { id: "2", name: "Gorilla Hoodie", description: "Warm and stylish hoodie" },
  { id: "3", name: "Gorilla Phone Case", description: "Protect your phone in style" },
  { id: "4", name: "Gorilla Notebook", description: "Perfect for jotting down ideas" },
];
