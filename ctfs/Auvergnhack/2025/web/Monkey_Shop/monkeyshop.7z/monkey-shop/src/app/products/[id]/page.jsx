"use client";
				// <p className="text-sm text-neutral-400 mt-4">Submitted on: {new Date(report.createdAt).toLocaleDateString()}</p>
import React, { useState, useEffect } from "react";

import { API_BASE_URL } from "@/env";

function Page({ params }) {
	const { id } = React.use(params);

	const [product, setProduct] = useState(null);
	const [error, setError] = useState(null);

	useEffect(() => {

		if (!id) {
			setError("Product ID is missing");
			return;
		}

		fetch(`${API_BASE_URL}/api/products/${id}`)
			.then((res) => res.json())
			.then((data) => {
				if (data.error) {
					setError(data.error);
				} else {
					setProduct(data);
				}
			})
			.catch(() => setError("Failed to fetch product details"));
	}, []);

	if (error) {
		return (
			<div className="h-full bg-neutral-900 text-neutral-200 p-6 flex items-center justify-center">
				<div className="max-w-lg w-full bg-neutral-800 p-8 rounded-lg shadow-lg">
					<h2 className="font-semibold text-red-500">{error}</h2>
				</div>
			</div>
		);
	}

	if (!product) {
		return (
			<div className="h-full bg-neutral-900 text-neutral-200 p-6 flex items-center justify-center">
				<div className="max-w-lg w-full bg-neutral-800 p-8 rounded-lg shadow-lg">
					<h2 className="text-xl font-semibold text-neutral-300">Loading...</h2>
				</div>
			</div>
		);
	}

	return (
		<div className="h-full bg-neutral-900 text-neutral-200 p-6 flex items-center justify-center">
			<div className="max-w-4xl w-full bg-neutral-800 p-8 rounded-lg shadow-lg">
				{/* Product Image */}
				<div className="flex flex-col md:flex-row items-center space-y-6 md:space-y-0 md:space-x-6">
					<img
						src={`/images/${product.id}.jpg`}
						alt={product.name}
						className="w-full md:w-1/2 h-auto rounded-lg shadow-lg object-cover"
					/>
					<div className="md:w-1/2">
						{/* Product Name and Details */}
						<h2 className="text-3xl font-semibold text-neutral-100">{product.name}</h2>
						<p className="mt-2 text-lg text-neutral-300">Quantity Left: {product.quantity}</p>
						<p className="mt-4 text-sm text-neutral-400">{product.description || "No description available."}</p>
					</div>
				</div>

				{/* Report Button */}
				<div className="mt-8">
					<a
						href={`/report?id=${product.id}`}
						className="w-full py-2 bg-blue-600 text-neutral-100 rounded-lg hover:bg-blue-700 transition duration-300 text-center block"
					>
						Out of stock ? Report this Product
					</a>
				</div>
			</div>
		</div>
	);
};

export default Page;
