"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

import { API_BASE_URL } from "@/env";

const ProductListPage = () => {
	const [products, setProducts] = useState([]);
	const [error, setError] = useState(null);

	useEffect(() => {
		fetch(`${API_BASE_URL}/api/products`)
			.then((res) => res.json())
			.then((data) => {
				if (data.error) {
					setError(data.error);
				} else {
					setProducts(data);
				}
			})
			.catch(() => setError("Failed to load products"));
	}, []);

	if (error) {
		return (
			<div className="h-full bg-neutral-900 text-neutral-200 p-6 flex items-center justify-center">
				<div className="max-w-lg w-full bg-neutral-800 p-8 rounded-lg shadow-lg">
					<h2 className="text-xl font-semibold text-red-500">{error}</h2>
				</div>
			</div>
		);
	}

	if (products.length === 0) {
		return (
			<div className="min-h-screen bg-neutral-900 text-neutral-200 p-6 flex items-center justify-center">
				<div className="max-w-lg w-full bg-neutral-800 p-8 rounded-lg shadow-lg">
					<h2 className="text-xl font-semibold text-neutral-300">No products available</h2>
				</div>
			</div>
		);
	}

	return (
		<div className="min-h-screen bg-neutral-900 text-neutral-200 p-6">
			<h1 className="text-3xl font-semibold text-neutral-100 mb-8 text-center">
				Our Products
			</h1>

			<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
				{products.map((product) => (
					<div
						key={product.id}
						className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all"
					>
						<Link href={`/products/${product.id}`} passHref>
							<div className="cursor-pointer">
								<img
									src={`/images/${product.id}.jpg`}
									alt={product.name}
									className="w-full h-40 object-cover rounded-lg"
								/>
								<div className="mt-4">
									<p className="text-lg font-semibold text-neutral-100">{product.name}</p>
									<p className="text-sm text-neutral-300">Quantity Left: {product.quantity}</p>
								</div>
							</div>
						</Link>
						<div className="mt-4">
							<Link
								href={`/report?id=${product.id}`}
								className="w-full py-2 bg-blue-600 text-neutral-100 rounded-lg hover:bg-blue-700 transition duration-300 text-center block"
							>
								Report this Product
							</Link>
						</div>
					</div>
				))}
			</div>
		</div>
	);
};

export default ProductListPage;
