"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { API_BASE_URL } from "@/env";

const AdminReportsPage = () => {
	const [reports, setReports] = useState([]);
	const [error, setError] = useState(null);

	useEffect(() => {
		fetch(`${API_BASE_URL}/api/admin/tickets`)
			.then((res) => res.json())
			.then((data) => {
				if (data.error) {
					setError(data.error);
				} else {
					setReports(data);
				}
			})
			.catch(() => setError("Failed to load reports"));
	}, []);

  console.log(reports)

	if (error) {
		return (
			<div className="min-h-screen bg-neutral-900 text-neutral-200 p-6">
				<h2 className="text-xl font-semibold text-red-500">{error}</h2>
			</div>
		);
	}

	if (reports.length === 0) {
		return (
			<div className="h-full bg-neutral-900 text-neutral-200 p-6">
				<h2 className="text-xl font-semibold text-neutral-300">No reports available</h2>
			</div>
		);
	}

	return (
		<div className="h-full bg-neutral-900 text-neutral-200 p-6">
			<h1 className="text-3xl font-semibold text-neutral-100 mb-8 text-center">Product Reports</h1>

			<div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
				{reports.map((report) => (
					<div
						key={report.rid}
						className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all"
					>
						<Link href={`/admin/reports/${report.rid}`} passHref>
							<div className="cursor-pointer">
								<p className="text-lg font-semibold text-neutral-100">Report for Product ID: {report.id}</p>
								<p className="text-sm text-neutral-300">Reason: {report.reason}</p>
							</div>
						</Link>
					</div>
				))}
			</div>
		</div>
	);
};

export default AdminReportsPage;

