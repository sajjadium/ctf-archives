"use client";
import { useState } from "react";

import { API_BASE_URL } from "@/env";

export default function ReportProductForm() {
	const [id, setUrl] = useState("");
	const [reason, setReason] = useState("");
	const [error, setError] = useState(null);
	const [success, setSuccess] = useState(null);

	const handleUrlChange = (e) => setUrl(e.target.value);
	const handleReasonChange = (e) => setReason(e.target.value);

	const handleSubmit = async (e) => {
		e.preventDefault();

		const formData = { id, reason };

		try {
			const response = await fetch(`${API_BASE_URL}/api/report`, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify(formData),
			});

			if (response.ok) {
				setSuccess("Report submitted successfully!");
				setError(null);
			} else {
				setSuccess(null);
				const errorData = await response.json();
				setError(errorData.error || "Failed to submit the report");
			}
		} catch (err) {
			setError("An error occurred. Please try again later.");
		}
	};

	return (
		<div className="h-full text-neutral-200 p-6 flex flex-col items-center justify-center">
			<div className="max-w-lg w-full h-full bg-neutral-800 p-8 rounded-lg shadow-lg">
				<h2 className="text-2xl font-semibold text-neutral-100 mb-6 text-center">Submit Product Report</h2>

				<form onSubmit={handleSubmit} className="space-y-6">
					{/* Product URL Field */}
					<div>
						<label htmlFor="id" className="block text-sm font-medium text-neutral-300">
							Product ID
						</label>
						<input
							type="text"
							id="id"
							value={id}
							onChange={handleUrlChange}
							required
							className="mt-2 w-full px-4 py-2 bg-neutral-700 text-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
							placeholder="Enter the product URL"
						/>
					</div>

					{/* Reason Textarea */}
					<div>
						<label htmlFor="reason" className="block text-sm font-medium text-neutral-300">
							Details
						</label>
						<textarea
							id="reason"
							value={reason}
							onChange={handleReasonChange}
							className="mt-2 w-full px-4 py-2 bg-neutral-700 text-neutral-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600"
							rows={4}
							placeholder="Describe the issue with the product"
						/>
					</div>

					{/* Submit Button */}
					<button
						type="submit"
						className="w-full py-2 font-bold bg-neutral-900 text-neutral-100 rounded-lg hover:bg-neutral-900/80 transition duration-300"
					>
						Submit Report
					</button>
				</form>

				{/* Error and Success Messages */}
				{error && <p className="mt-4 text-center text-sm text-red-500">{error}</p>}
				{success && <p className="mt-4 text-sm text-green-500">{success}</p>}
			</div>
		</div>
	);
}

