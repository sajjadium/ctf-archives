"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X } from "lucide-react"; // Icons for mobile menu

export default function Navbar() {
	const [isOpen, setIsOpen] = useState(false);
	const pathname = usePathname(); // Get current route

	return (
		<nav className="bg-neutral-900 border-b border-neutral-800 text-neutral-200">
			<div className="container mx-auto flex justify-between items-center p-4">
				{/* Logo */}
				<Link href="/" className="text-xl font-bold text-neutral-100">
					GorillaShop
				</Link>

				{/* Desktop Menu */}
				<ul className="hidden md:flex space-x-6">
					{navLinks.map(({ name, path }) => (
						<li key={path}>
							<Link
								href={path}
								className={`hover:text-neutral-400 transition ${pathname === path ? "text-neutral-300 border-b-2 border-neutral-600" : ""
									}`}
							>
								{name}
							</Link>
						</li>
					))}
				</ul>

				{/* Mobile Menu Button */}
				<button
					className="md:hidden text-neutral-300 focus:outline-none"
					onClick={() => setIsOpen(!isOpen)}
				>
					{isOpen ? <X size={24} /> : <Menu size={24} />}
				</button>
			</div>

			{/* Mobile Menu Dropdown */}
			{isOpen && (
				<div className="md:hidden bg-neutral-800 border-t border-neutral-700">
					<ul className="flex flex-col items-center py-4 space-y-4">
						{navLinks.map(({ name, path }) => (
							<li key={path}>
								<Link
									href={path}
									className={`block px-4 py-2 text-neutral-300 hover:text-neutral-400 transition ${pathname === path ? "text-neutral-300 border-b border-neutral-500" : ""
										}`}
									onClick={() => setIsOpen(false)} // Close menu on click
								>
									{name}
								</Link>
							</li>
						))}
					</ul>
				</div>
			)}
		</nav>
	);
}

const navLinks = [
	{ name: "Home", path: "/" },
	{ name: "Products", path: "/products" },
	{ name: "Report", path: "/report" },
];
