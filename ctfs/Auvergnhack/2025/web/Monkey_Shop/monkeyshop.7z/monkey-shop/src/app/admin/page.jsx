"use client";

import Link from "next/link";
import { redirect } from 'next/navigation'
import React, { useState, useEffect } from "react";
import { API_BASE_URL } from "@/env";



const AdminHomePage = () => {
				const [success, setSuccess] = useState(null);
				const [error, setError] = useState(null);

				const fetchStock = () => { 
								fetch("http://localhost:8080/api/admin/stockback")
								.then(() => fetchProducts())
								.catch(() => setStock("Failed to fetch stock"));
				};
				const stockLimited = () => { 
								fetch("http://localhost:8080/api/admin/product/stocklimited")
								.then(() => fetchProducts())
								.catch(() => setStock("Failed to fetch stock"));
				};
				useEffect(() => {
								try {
												const response = fetch(`${API_BASE_URL}/api/admin`);
												if (response.ok) {
																setSuccess("Authorized");
																setError(null);
												} else {
																setSuccess(null);
																setError("Unauthorized");
												}
								} catch (err) {
												console.log(err)
												setError("An error occurred. Please try again later.");
												redirect('/');
								}
				}, []);

				return (
								<div className="h-full bg-neutral-900 text-neutral-200 p-6 flex flex-col justify-center items-center">
												<h1 className="text-4xl font-semibold text-neutral-100 mb-8 text-center">Admin Dashboard</h1>

												<div className="w-full flex flex-row items-center justify-center gap-6">
																{/* Product Reports Section */}
																<div className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all">
																				<h2 className="text-2xl font-semibold text-neutral-100 mb-4">Manage Product Reports</h2>
																				<p className="text-neutral-300 mb-4">View and manage all product reports submitted by users.</p>
																				<Link
																								href="/admin/reports"
																								className="bg-neutral-600 text-neutral-100 px-6 py-2 rounded-lg hover:bg-neutral-700 transition duration-300"
																				>
																								View Reports
																				</Link>
																</div>

																{/* New Product Report Section */}
																<div className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all">
																				<h2 className="text-2xl font-semibold text-neutral-100 mb-4">New Product Report</h2>
																				<p className="text-neutral-300 mb-4">Submit a new report for a product in case there’s an issue.</p>
																				<Link
																								href="/report"
																								className="bg-neutral-600 text-neutral-100 px-6 py-2 rounded-lg hover:bg-neutral-700 transition duration-300"
																				>
																								Submit Report
																				</Link>
																</div>
												</div>
												<div className="w-full flex flex-wrap justify-center gap-6 mt-6">
													{/* Restock Product Section */}
													<div className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all max-w-sm">
														<h2 className="text-2xl font-semibold text-neutral-100 mb-4">Restock Products</h2>
														<p className="text-neutral-300 mb-6">Restock all products to satisfy customers.</p>
														<div className="flex justify-center">
															<div
																onClick={fetchStock}
																className="bg-neutral-600 text-neutral-100 px-8 py-3 rounded-lg hover:bg-neutral-700 transition duration-300 text-center inline-block w-full cursor-pointer"
															>
																Restock
															</div>
														</div>
													</div>

													{/* Stock New Products */}
													<div className="bg-neutral-800 p-6 rounded-lg shadow-lg hover:shadow-xl transition-all max-w-sm">
														<h2 className="text-2xl font-semibold text-neutral-100 mb-4">Stock New Products</h2>
														<p className="text-neutral-300 mb-6">Stock all new products.</p>
														<div className="flex justify-center">
															<div
																onClick={stockLimited}
																className="bg-neutral-600 text-neutral-100 px-8 py-3 rounded-lg hover:bg-neutral-700 transition duration-300 text-center inline-block w-full cursor-pointer"
															>
																Stock News
															</div>
														</div>
												</div>
								</div>
								</div>
				);
};

export default AdminHomePage;

