def validate_input(data, required_fields):
    for field in required_fields:
        if not data.get(field):
            return f"{field} is required."

        f = data.get(field)
        if field == "email" and not email_check(f):
            return f"Email is not valid"
        elif not is_safe(field):
            return f"{field} is not valid !"
        '''
        if field == "firstname" and not name_check(f):
            return f"Firstname is not valid"
        if field == "lastname" and not name_check(f):
            return f"Lastname is not valid"
        '''
    return None


def is_safe(input):
    return not (
        "<" in input and ">" in input or
        "{" in input and "}" in input or
        "\"" in input
    )

def email_check(input):
    return is_safe(input) and "@" in input

def name_check(input):
    #todo
    return is_safe(input)
    
    