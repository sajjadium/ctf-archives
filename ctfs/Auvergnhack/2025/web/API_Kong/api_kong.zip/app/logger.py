
from datetime import datetime

class Logger:

    def __init__(self,log_path):
        self.log_path = log_path
        self.log_template = " | User Info : {user.firstname}.{user.lastname}({user.email}) | [{date}] \n"
    
    def get_date(self):
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    def write_log(self,log,user_id):
        with open(f"{self.log_path}/{user_id}","a") as f:
            f.write(log)

    def log_basic(self, endpoint, user):
        log = (endpoint + self.log_template).format(user=user,date=self.get_date())
        self.write_log(log,user.public_id)

    def log_error(self, endpoint,user,error):
        log = (endpoint + " !ERROR! " + self.log_template).format(user=user,date=self.get_date())
        print(log,user.public_id)