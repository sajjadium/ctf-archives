import os

class Config:
    SECRET_KEY = os.urandom(32).hex()
    VERSION = 'v1'
    LOG_PATH = '/logs'
    SQLALCHEMY_DATABASE_URI = 'sqlite:////db/users.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = True