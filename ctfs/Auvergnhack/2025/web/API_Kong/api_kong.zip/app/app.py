from flask import Flask, request, jsonify
import uuid
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
from datetime import datetime, timedelta
from functools import wraps
from logger import Logger
from models import User, db
from config import Config
from validator import *
import re

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
logger = Logger(app.config['LOG_PATH'])

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            token = request.headers['Authorization']

        if not token:
            return jsonify({'message' : 'Token is missing !'}), 401
        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = User.query\
                .filter_by(public_id = data['public_id'])\
                .first()
        except Exception as e:
            print(e)
            return jsonify({
                'message' : 'Token is invalid !'
            }), 401

        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/api/', methods =['GET'])
def home():
    return jsonify({'message' : 'Welcome my friend!'}), 200

@app.route('/api/products', methods =['GET'])
@token_required
def products(current_user):
    products = [
        {"name":"MonkeyHacker T-Shirt","description":"Underground style, ultimate comfort"},
        {"name":"Pentest USB Key","description":"Your hacking tools always within reach"},
        {"name":"Terminal Sticker","description":"Customize your gear with style"}
    ]
    
    if current_user.role == "kong":
         products.append({"name":"FLAG","description":"ZiTF{}"})
    return jsonify(products), 200

@app.route('/api/me', methods =['GET'])
@token_required
def me(current_user):
    current_user_json = current_user.as_dict()
    filters = request.args.getlist('filters')
  
    if filters:
         for f in filters:
              if re.match(r'.*(\<|\>|\{|\}|\"|\'\;).*',f):
                        return jsonify({'message' : 'Stop hacking !'}), 403
         current_user_json = {key: value for key, value in current_user_json.items() if key in filters}
    
    logger.log_basic(f"/me filter={filters}",current_user)
    return jsonify(current_user_json), 200

@app.route('/api/login', methods =['POST'])
def login():
	auth = request.json
	if not auth or not auth['email'] or not auth['password']:
		return jsonify({'message' : 'Missing fields !'}), 401

	user = User.query\
		.filter_by(email = auth['email'])\
		.first()
	if not user:
		return jsonify({'message' : 'Auth Fail !'}), 403

	if check_password_hash(user.password, auth.get('password')):
		token = jwt.encode({
			'public_id': user.public_id,
			'exp' : datetime.utcnow() + timedelta(minutes = 30)
		}, app.config['SECRET_KEY'], algorithm="HS256")
		return jsonify({'token' : token}), 201

	return jsonify({'message' : 'Auth Failed !'}), 403

@app.route('/api/signup', methods =['POST'])
def signup():
    data = request.json
    errors = validate_input(data,['firstname','lastname','email','password'])
    if errors:
        return jsonify({'message' : errors}), 401

    user = User.query\
        .filter_by(email = data['email'])\
        .first()
    if not user:
        user = User(
            public_id = str(uuid.uuid4()),
            role = "monkey",
            firstname = data['firstname'],
            lastname = data['lastname'],
            email = data['email'],
            password = generate_password_hash(data['password'])
        )
        db.session.add(user)
        db.session.commit()

        return jsonify({'message' : 'Successfully registered.'}), 201
    else:
        return jsonify({'message' : 'User already exists. Please Log in.'}), 401

if __name__ == "__main__":
	app.run(host="0.0.0.0",port=5006,debug = False)
