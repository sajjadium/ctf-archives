from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    public_id = db.Column(db.String(50), unique = True)
    role = db.Column(db.String(50), unique = True)
    firstname = db.Column(db.String(100))
    lastname = db.Column(db.String(100))
    email = db.Column(db.String(70), unique = True)
    password = db.Column(db.String(80))

    def as_dict(self):
        return {
            "id": self.id,
            "public_id": self.public_id,
            "role": self.role,
            "firstname": self.firstname,
            "lastname": self.lastname,
            "email": self.email,
        }