#!/usr/bin/python3

import uuid
from datetime import datetime, timedelta
import random
import sqlite3
from faker import Faker
from werkzeug.security import generate_password_hash

def create_users(number):
    users = []
    fake = Faker()
    for i in range(0,number,1):
        users.append({
            "public_id":str(uuid.uuid4()),
            "role":"monkey",
            "firstname":fake.first_name().lower(),
            "lastname":fake.last_name().lower(),
            "email":fake.email(),
            "password":generate_password_hash(fake.password()+fake.password()), #not bruteforce please !
            })
    admin_id = random.randint(0,number-1)
    users[admin_id]["role"] = "kong"
    return users

def create_db(db_name,users):
    conn = sqlite3.connect(db_name)
    cursor = conn.cursor()

    cursor.execute("CREATE TABLE IF NOT EXISTS user (\
id INTEGER PRIMARY KEY AUTOINCREMENT,\
role TEXT NOT NULL,\
public_id TEXT NOT NULL UNIQUE,\
firstname TEXT NOT NULL,\
lastname TEXT NOT NULL,\
email TEXT NOT NULL UNIQUE,\
password TEXT NOT NULL)")

    for user in users:
        try:
            conn.execute("INSERT INTO user (public_id, role, firstname, lastname, email, password) VALUES(?, ?, ?, ?, ?, ?)",(user['public_id'], user['role'], user['firstname'], user['lastname'], user['email'], user['password']))
        except:
            print("[*] Building => Email already exists")
            conn.execute("INSERT INTO user (public_id, role, firstname, lastname, email, password) VALUES(?, ?, ?, ?, ?, ?)",(user['public_id'], user['role'], user['firstname'], user['lastname'], '_'+user['email'], user['password']))

    conn.commit()
    conn.close()

def fake_logdate():
    date_debut_str = '2025-05-05 00:00:00'
    date_fin_str = '2025-05-05 23:59:59'

    date_debut = datetime.strptime(date_debut_str, '%Y-%m-%d %H:%M:%S')
    date_fin = datetime.strptime(date_fin_str, '%Y-%m-%d %H:%M:%S')

    intervalle_secondes = int((date_fin - date_debut).total_seconds())
    date_aleatoire = date_debut + timedelta(seconds=random.randint(0, intervalle_secondes))

    return date_aleatoire.strftime('%Y-%m-%d %H:%M:%S')

def create_logs(folder,users):
    for user in users:
        date = fake_logdate()
        uuid = user['public_id']
        with open(folder+'/'+uuid,'w') as f:
            f.write(f"/me | User Info : {user['firstname']}.{user['lastname']}({user['email']}) | [{date}] \n")

if __name__ == '__main__':
    users = create_users(200)
    create_db('/db/users.db',users)
    create_logs('/logs',users)

    
