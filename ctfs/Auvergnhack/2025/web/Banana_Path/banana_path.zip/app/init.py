#!/usr/bin/python3

import json
import random

with open('/data/users.json','r') as f:
    users = json.load(f)

if users:
    user = random.choice(users)
    user['role'] = 'admin'

    with open('/data/users.json','w') as f:
        json.dump(users,f)