#!/usr/bin/python3

from flask import Flask, jsonify, request
from user_manager import UserManager
from dotenv import load_dotenv
import os

load_dotenv()

APP_NAME = os.getenv('APP_NAME')
APP_PORT = os.getenv('APP_PORT')
DATA_PATH = os.getenv('DATA_PATH')

app = Flask(APP_NAME)
user_manager = UserManager(DATA_PATH)


@app.route('/api/users', methods=['GET'])
def get_users():
    return jsonify(user_manager.get_all_users())


@app.route('/api/user/<int:user_id>', methods=['GET'])
def get_user_by_id(user_id):
    user = user_manager.get_user_by_id(user_id)
    if user:
        return jsonify(user)
    else:
        return jsonify({"message": "User Not Found"}), 404

@app.route('/api/user/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    if 'X-Auth' not in request.headers:
        return jsonify({"message": "Not admin !"}), 403

    data = request.get_json()
    try:
        updated_user = user_manager.update_user(user_id, data)
        if updated_user:
            return jsonify(updated_user)
        else:
            return jsonify({"message": "User Not Found"}), 404
    except:
        return jsonify({'message':'Shit something went wrong ?'}), 500
    
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=APP_PORT)