import os

def safe_path(path):
    norm_path = os.path.normpath(path)

    if norm_path.count('/') < 3:
        print("! Not Possible here !")
        return ''

    return norm_path

def update_token(storage_path,user,old_username):
    token_path = f"{storage_path}/secrets/{user['id']}_{old_username}"
    try:
        if os.path.isfile(token_path):
            os.rename(token_path,f"{storage_path}/secrets/{user['id']}_{user['username']}")
    except:
        print("[*] Rename failed!")

def generate_token(path):
    token = os.urandom(32).hex()
    with open(path,'w') as f:
        f.write(token)
    return token

def get_user_token(storage_path,user):
    user_id = user['id']
    user_username = user['username']
    data=''

    path = safe_path(f'{storage_path}/secrets/{user_id}_{user_username}')
    
    if path != '':
        if not os.path.exists(path):
            return generate_token(path)
        else:
            with open(path,'r') as f:
                data = f.read()
    
    return data