import json
import utils

class UserManager:
    def __init__(self, storage_path):
        self.storage_path = storage_path
        self.file_path = storage_path + '/users.json'
        self._load_users()

    def _load_users(self):
        try:
            with open(self.file_path, 'r') as file:
                self.users = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            self.users = []

    def _save_users(self):
        with open(self.file_path, 'w') as file:
            json.dump(self.users, file, indent=4)

    def get_all_users(self):
        return self.users

    def get_user_by_id(self, user_id):
        user = next((user for user in self.users if user['id'] == user_id), None)
        if user['role'] == 'admin':
            user['token'] = utils.get_user_token(self.storage_path,user)
        return user

    def update_user(self, user_id, data):
        user = self.get_user_by_id(user_id)
        old_username = user['username']
        if user:
            user.update({
                "username": data.get("username", user["username"]),
                "description": data.get("description", user["description"])
            })
            if user['role'] == 'admin':
                utils.update_token(self.storage_path,user,user['username'])
            self._save_users()
            return self.get_user_by_id(user_id)
        return None