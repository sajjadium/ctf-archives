package config

const (
	MTU           = 1500
	TUNName       = "tun0"
	AgentName     = "haha"
	LocalIPv4CIDR = "10.0.0.0/24"
)
