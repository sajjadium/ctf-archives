#include "relay.hpp"
#include "settings.hpp"

#include <drogon/drogon.h>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <utility>

using namespace drogon;

std::stringstream makeStream()
{
	std::stringstream ss;
	ss << std::hex << std::setfill('0');
	return ss;
}

std::string randomKey()
{
	static std::random_device rd;
	static std::mt19937 gen(rd());
	static std::stringstream ss = makeStream();
	std::uniform_int_distribution dist{0, 255};
	ss.str("");
	for (int i = 0; i < 16; i++) {
		ss << std::setw(2) << dist(gen);
	}
	return ss.str();
}

void logRequest(const HttpRequestPtr& req)
{
	auto q = req->getQuery();
	LOG_INFO << req->getMethodString() << " - " << req->getPeerAddr().toIp() << " - " << req->getOriginalPath()
			 << (q.empty() ? "" : "?" + q);
}

void sendResponse(auto&& callback, drogon::HttpStatusCode code, std::string msg = "")
{
	auto resp = HttpResponse::newHttpResponse();
	if (!msg.empty())
		resp->setBody(msg);
	resp->setStatusCode(code);
	callback(resp);
}

bool checkFileExists(const std::string& s)
{
	if (FILE* f = fopen((s + ".csp").data(), "r")) {
		fclose(f);
		return true;
	}
	return false;
}


int main(int, const char*[])
{
	app().loadConfigFile("config.json");

	app().registerHandler("/", [](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback) {
		logRequest(req);
		auto resp = HttpResponse::newHttpViewResponse("upload");
		callback(resp);
	});

	app().registerHandler(
		"/view/{}",
		[](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback, const std::string& page) {
			logRequest(req);
			auto file = "./views/d/" + page + ".csp";
			if (checkFileExists(file)) {
				size_t start = strlen("./views/d/");
				std::string cleaned = file.substr(start, file.find(".csp") - start);
				auto resp = HttpResponse::newHttpViewResponse(cleaned);
				callback(resp);
			} else {
				sendResponse(callback, k404NotFound, "view not found"); // "View? What view?"
			}
		});

	app().registerHandler("/upload",
						  [&](const HttpRequestPtr& req, std::function<void(const HttpResponsePtr&)>&& callback) {
							  logRequest(req);

							  MultiPartParser fileUpload;
							  if (fileUpload.parse(req) != 0 || fileUpload.getFiles().size() != 1) {
								  sendResponse(callback, k403Forbidden, "Expected one file: score.");
								  return;
							  }

							  auto scoreFile = fileUpload.getFiles()[0];

							  auto key = randomKey();

							  auto path = app().getUploadPath() + "/" + key;
							  LOG_INFO << "saving files to " << path;
							  scoreFile.saveAs(path + "/" INPUT_SCORE_FILENAME);

							  auto score = path + "/" INPUT_SCORE_FILENAME;
							  auto outfile = path + "/" OUTPUT_AUDIO_FILENAME;

							  auto res = synthesise(score, outfile);

							  if (res.wasOk()) {
								  std::cout << "(" << key << "): successfully generated audio" << std::endl;
								  auto resp = HttpResponse::newFileResponse(outfile, "", CT_CUSTOM, "audio/wav");
								  callback(resp);

							  } else {
								  std::cout << "[ERROR] (" << key << ") " << res.getErrorMessage() << std::endl;

								  // It was a server error, but it was your fault to begin with. So let's return a 4xx.
								  // Hmm... I wonder which particular 4xx to use...
								  sendResponse(callback, k418ImATeapot, res.getErrorMessage().toStdString());
							  }
						  },
						  {Post});

	LOG_INFO << "running webserver...";
	app().run();
}