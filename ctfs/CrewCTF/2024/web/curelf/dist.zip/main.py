#...

@app.route('/flag')
def flag():
    if request.remote_addr == admin_ip:
        return os.environ["FLAG"]
    else:
        return "You are not admin!"

#...