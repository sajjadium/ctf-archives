mod admin;
mod preview;

use poem::{
    endpoint::{StaticFileEndpoint, StaticFilesEndpoint},
    get, handler,
    http::StatusCode,
    listener::TcpListener,
    middleware::SizeLimit,
    post,
    web::{Form, Query},
    Endpoint, EndpointExt, Error, IntoResponse, Request, Response, Result, Route, Server,
};

use serde::Deserialize;

const CSP: &str = "default-src 'self'; script-src 'self' 'unsafe-eval' cdn.jsdelivr.net cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' cdn.jsdelivr.net cdnjs.cloudflare.com; img-src 'self' data: https:;";

#[derive(Deserialize)]
struct PreviewParams {
    markdown: String,
    debug: Option<bool>,
}

#[handler]
async fn route_preview(Form(PreviewParams { markdown, debug }): Form<PreviewParams>) -> Response {
    if markdown.len() > 2000 {
        return Response::from((StatusCode::IM_A_TEAPOT, "Your message is too long. Do you want to attach it as a file? Sadly, we don't have a file sharing service. Please use something like GitHub instead."));
        // What a short and sweet message, apropos of the input. -T
    }
    let (status, html) = preview::markdown_to_html_output(&markdown, debug.unwrap_or(false)).await;

    return Response::builder()
        .status(status)
        .content_type("text/html")
        .body(html);
}

#[derive(Deserialize)]
struct RunQuery {
    cmd: String,
    arg: Option<String>,
}

#[handler]
pub fn route_admin_run(Query(run): Query<RunQuery>) -> String {
    let RunQuery { cmd, arg } = run;
    admin::run_cmd(cmd, arg.unwrap_or("".to_string()))
}

async fn middleware_localhost<E: Endpoint>(next: E, req: Request) -> Result<Response> {
    // No authentication? -T // "I [too] like to live dangerously." -V
    if let Some(host) = req.uri().host().or(req.header("host")) {
        if !host.trim_start().starts_with("127.0.0.1") {
            return Err(Error::from_status(StatusCode::UNAUTHORIZED));
        }
    } else {
        return Err(Error::from_status(StatusCode::UNAUTHORIZED));
    }

    let resp = next.call(req).await?.into_response();
    Ok(resp)
}

async fn middleware_csp<E: Endpoint>(next: E, req: Request) -> Result<Response> {
    // Having a CSP surely enhances our security posture. -V
    let mut resp = next.call(req).await?.into_response();
    let hdr = resp.headers_mut();
    hdr.insert("Content-Security-Policy", CSP.parse().unwrap());
    Ok(resp)
}

#[tokio::main]
async fn main() -> Result<(), std::io::Error> {
    #[cfg(debug_assertions)]
    if std::env::var_os("RUST_LOG").is_none() {
        std::env::set_var("RUST_LOG", "poem=debug");
    }
    std::env::set_var("RUST_BACKTRACE", "1");
    tracing_subscriber::fmt::init();

    let app = Route::new()
        .at("/", StaticFileEndpoint::new("./static/index.html"))
        .nest("/assets", StaticFilesEndpoint::new("./static/assets/"))
        .at("/preview", post(route_preview).with(SizeLimit::new(4000)))
        .nest(
            "/ai", // Look boss! We have AI in our product! ("Admin Interface") -V // You get a pass this time, but if you mention AI again, I will f****** piledrive you. -T
            Route::new()
                .at("/", StaticFileEndpoint::new("./static/admin.html"))
                .nest("/run", get(route_admin_run)) // TODO: change to post. -V // https://thedailywtf.com/articles/The_Spider_of_Doom -T
                .around(middleware_localhost),
        )
        .around(middleware_csp)
        .catch_error(|_: poem::error::NotFoundError| async move {
            Response::builder()
                // .status(StatusCode::NOT_FOUND)
                // .body("nothing here") // There must be something prettier we can return, right? Something like... a 302 redirect... -T
                .status(StatusCode::FOUND)
                .header("Location", "https://www.youtube.com/watch?v=dQw4w9WgXcQ") // Done! -V // Dammit Victor, I meant a redirect to the index page. -T
                .body("")
        });
    Server::new(TcpListener::bind("0.0.0.0:8000")).run(app).await
}
