const e = document.querySelector("#editor");

// Auto-expanding textarea.
e.addEventListener("input", () => {
    e.style.height = 'auto';
    e.style.height = `${e.scrollHeight}px`;
});

document.body.addEventListener("htmx:afterSwap", () => {
    hljs.highlightAll();
});

const sel = document.querySelector("#cmd-select");
if (sel) {
    const arg = document.querySelector("#cmd-arg");
    sel.addEventListener("change", function() {
        const hasArg = !this.options[this.selectedIndex].hasAttribute("no-arg");
        if (hasArg) {
            arg.removeAttribute("disabled");
            arg.value = '';
        } else {
            arg.setAttribute("disabled", "");
        }
    });
}