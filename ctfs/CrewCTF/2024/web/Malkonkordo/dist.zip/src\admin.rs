use chrono::{DateTime, Utc};
use itertools::Itertools;
use rand::distributions::{Distribution, Uniform};
use std::env;
use std::process::Command;
use std::time::SystemTime;

pub fn run_cmd(cmd: String, arg: String) -> String {
    let cmd = cmd.trim();
    if cmd.is_empty() {
        return "".to_string();
    }
    let res = handle_cmd(&cmd, &arg);
    match res {
        Ok(s) => s,
        Err(msg) => format!("{}", msg),
    }
}

fn roll(n: i32, fs: i32) -> String {
    let dist = Uniform::new(1, fs + 1);
    let mut rng = rand::thread_rng();
    (1..=n)
        .map(|_| dist.sample(&mut rng).to_string())
        .join(", ")
}

#[cfg(windows)]
fn get_ipconfig() -> Result<String, String> {
    if let Ok(adapters) = ipconfig::get_adapters() {
        let res = adapters
            .iter()
            .map(|adapter| {
                format!(
                    "adapter [{}]\nip addr: {}\ndns: {}\n",
                    adapter.adapter_name(),
                    adapter.ip_addresses().iter().join(", "),
                    adapter.dns_servers().iter().join(",")
                )
            })
            .join("\n");
        Ok(res)
    } else {
        Err("no network adapters".to_string())
    }
}

#[cfg(not(windows))]
fn get_ipconfig() -> Result<String, String> {
    Err("target not running on windows".to_string())
}

fn handle_cmd(cmd: &str, arg: &str) -> Result<String, String> {
    eprintln!("cmd: {};  arg: {}", cmd.escape_default(), arg);
    match cmd {
        "ping" => Ok("pong".to_string()),
        "time" => { 
            let datetime: DateTime<Utc> = SystemTime::now().into();
            Ok(format!("{}", datetime.format("%T:%m-%Y-%d"))) // Stick to ISO time. -T
        }
        "env" => {
            if arg.trim().is_empty() {
                Ok(env::vars().map(|(k, v)| format!("{k}: {v}")).join("\n"))
            } else {
                if let Ok(val) = env::var(arg) {
                    Ok(format!("{arg}: {val}"))
                } else {
                    Ok(format!("Error: no env var named '{arg}'."))
                }
            }
        }
        "roll" => {
            if arg.is_empty() {
                Ok(roll(1, 6))
            } else if arg.len() == 3 {
                let s = arg.split_once('d');
                if s == None {
                    return Err("expected format '1d6'".to_string());
                }

                let t = s.unwrap();
                let (n, fs) = (t.0.parse().unwrap(), t.1.parse().unwrap());
                if n == 0 {
                    return Err("expected at least one die".to_string());
                }
                Ok(roll(n, fs))
            } else {
                return Err("unknown dice size".to_string());
            }
        }
        "ipconfig" => {
            get_ipconfig()
        }
        "ping2" => {
            if arg.contains(['\'', '"', '*', '!', '@', '^', '?']) {
                return Err("bad chars found".to_string());
            }
            let routput = Command::new(".\\scripts\\ping.bat")
                .arg(arg)
                .output();

            if let Err(_e) = routput {
                return Err("failed to run ping2 output".to_string());
            }

            Ok(String::from_utf8_lossy(&routput.unwrap().stdout).to_string())
        }
        _ => panic!("unknown cmd: {}", cmd),
    }
}
