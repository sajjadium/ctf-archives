use futures::future;
use itertools::Itertools;
use lazy_static::lazy_static;
use markdown::{to_html_with_options, Constructs, Options, ParseOptions};
use poem::http::StatusCode;
use regex::Regex;
use reqwest::{Client, ClientBuilder, Url};
use std::time::Duration;

const MAX_LINKS_PER_PREVIEW: usize = 3;

lazy_static! {
    static ref EXTRACT_LINK_REGEX: Regex = Regex::new(
        r#"<a\s+(?:\w+(?:="[^">]*")\s+)*\bhref="(https?://[-a-zA-Z0-9.:]{1,256}(?:/[a-zA-Z0-9\-_\.#?=+&;%]*)*)""#,
    ).unwrap();
    static ref FIND_SITENAME_REGEX: Regex = Regex::new(&make_meta_regex("og:site_name")).unwrap();
    static ref FIND_TITLE_REGEX: Regex = Regex::new(&make_meta_regex("og:title")).unwrap();
    static ref FIND_DESC_REGEX: Regex = Regex::new(&make_meta_regex("og:description")).unwrap();
    static ref FIND_IMG_REGEX: Regex = Regex::new(&make_meta_regex("og:image")).unwrap();

    // Ensure quick connections and early timeout.
    static ref CLIENT: Client = ClientBuilder::new()
        .connect_timeout(Duration::from_millis(400))
        .read_timeout(Duration::from_secs(1))
        .build()
        .unwrap();
}

fn make_meta_regex(prop: &str) -> String {
    format!(
        r#"<meta\s+(?:property="{prop}"\s*content="([^"]*)"|content="([^"]*)"\s*property="{prop}")"#
    )
}

fn extract_links(html: &str) -> Vec<&str> {
    // Jank http matching regex. // Moar test cases plz! -T // Nah. -V
    EXTRACT_LINK_REGEX
        .captures_iter(html)
        .take(MAX_LINKS_PER_PREVIEW)
        .map(|s| {
            let (_, [u]) = s.extract();
            u
        })
        .collect()
}

fn extract_meta_tag<'a>(re: &Regex, body: &'a str) -> Option<&'a str> {
    let caps = re
        .captures_iter(&body)
        .map(|c| c.extract())
        .collect::<Vec<_>>();
    if caps.is_empty() {
        None
    } else {
        let (_, [content]) = caps[0];
        Some(content)
    }
}


struct LinkMetadata {
    link: String,
    site_name: String,
    title: String,
    desc: String,
    img: String,
}

impl LinkMetadata {
    fn from_body(body: &str, url: &str) -> LinkMetadata {
        let sitename = extract_meta_tag(&FIND_SITENAME_REGEX, &body);
        let title = extract_meta_tag(&FIND_TITLE_REGEX, &body);
        let desc = extract_meta_tag(&FIND_DESC_REGEX, &body);
        let img = extract_meta_tag(&FIND_IMG_REGEX, &body);
        // Don't bother checking other meta tags (e.g. <title>).

        LinkMetadata {
            link: url.to_string(),
            site_name: sitename.unwrap_or("(No Site Name)").to_string(),
            title: title.unwrap_or("(No Title)").to_string(),
            desc: desc.unwrap_or("(No Description)").to_string(),
            img: img.unwrap_or("/assets/nggyu.webp").to_string(),
        }
    }

    fn to_html(&self) -> String {
        // Use discord's HTML.
        let LinkMetadata {
            link,
            site_name,
            title,
            desc,
            img,
        } = &self;

        format!(
            r###"
<article class="embedWrapper mt-1">
<div class="gridContainer">
    <div class="embedSiteName"><span>{site_name}</span></div>
    <div class="embedTitle mt-2">
        <a class="embedLink markup" href="{link}" tabindex="0" rel="noreferrer noopener"
            target="_blank" role="button">{title}</a>
    </div>
    <div class="embedDescription mt-2">{desc}</div>
    <div class="embedImage mt-3">
        <div class="imageContainer">
            <div class="imageWrapper embedMaxSized">
                <a class="originalLink" tabindex="-1" aria-hidden="true"
                    href="{img}">
                </a>
                <div class="clickableWrapper embedMaxSized" tabindex="0" role="button">
                    <img class="embedMaxSized" alt="{title}"
                        src="{img}">
                </div>
            </div>
        </div>
    </div>
</div>
</article>
"###
        )
        .trim()
        .to_string()
    }
}

enum LinkRawResult {
    Preview(String),
    ErrorCode(StatusCode),
    ConnectionError,
}

struct LinkDebugResult {
    url: String,
    res: LinkRawResult,
}

impl LinkDebugResult {
    fn success(url: String, preview_code: String) -> LinkDebugResult {
        LinkDebugResult {
            url,
            res: LinkRawResult::Preview(preview_code),
        }
    }
    fn fail_with_status(url: String, status: StatusCode) -> LinkDebugResult {
        LinkDebugResult {
            url,
            res: LinkRawResult::ErrorCode(status),
        }
    }
    fn fail_due_to_connection(url: String) -> LinkDebugResult {
        LinkDebugResult {
            url,
            res: LinkRawResult::ConnectionError,
        }
    }

    fn to_md(&self) -> String {
        // Return markdown, which is easier to concatenate (esp for lists).
        let url = &self.url;
        let domain = Url::parse(&self.url).unwrap().host().unwrap().to_string();
        match &self.res {
            LinkRawResult::Preview(code) => {
                format!(
                    "- [link]({url}) ({domain}) successful  \n\t```html\n\t{}\n\t```",
                    code.replace('\n', "\n\t")
                )
            }
            LinkRawResult::ErrorCode(status) => format!(
                "- [link]({url}) ({domain}) returned error code {:?}",
                status
            ),
            LinkRawResult::ConnectionError => {
                format!("- [link]({url}) ({domain}) failed to connect")
            }
        }
    }
}

async fn render_link(url: &str) -> (Option<LinkMetadata>, LinkDebugResult) {
    let url = url.replace("&amp;", "&"); // I guess `&` was reparsed as `&amp;` by markdown-rs. So we'll convert it back here. -V // LGTM. -T
    let rresp = CLIENT.get(&url).send().await;
    if let Err(e) = rresp {
        println!("response: {e:?}");
        if e.is_connect() || e.is_timeout() {
            return (None, LinkDebugResult::fail_due_to_connection(url));
        } else {
            return (
                None,
                LinkDebugResult::fail_with_status(
                    url,
                    e.status().unwrap_or(StatusCode::IM_A_TEAPOT), // I like tea. -V
                ),
            );
        }
    }
    let rbody = rresp.unwrap().text().await;
    if let Err(e) = rbody {
        println!("unknown error: {e:?}");
        return (
            None,
            LinkDebugResult::fail_with_status(url, StatusCode::IM_A_TEAPOT),
        );
    }

    let body = rbody.unwrap();
    (
        Some(LinkMetadata::from_body(&body, &url)),
        LinkDebugResult::success(url.to_string(), body[..body.len().min(500)].to_string()),
    )
}

fn format_debug_output(out: &str) -> String {
    "<hr><h4>Debug Output</h4>".to_string() + out
}

pub async fn markdown_to_html_output(markdown: &str, debug: bool) -> (StatusCode, String) {
    // Force in some newlines.
    let markdown_with_nl = markdown.lines().map(|x| x.to_string() + "  ").join("\n");
    let rhtml = to_html_with_options(
        &markdown_with_nl,
        &Options {
            parse: ParseOptions {
                constructs: Constructs {
                    gfm_autolink_literal: true,
                    // markdown-rs doesn't support double-tilde strikethroughs, so we'll make do with single-tilde.
                    gfm_strikethrough: true,
                    ..Constructs::default()
                },
                ..ParseOptions::default()
            },
            ..Options::default()
        },
    );
    if let Err(msg) = rhtml {
        if debug {
            let fail_html = markdown::to_html(&format!(
                "`markdown::to_html_with_options` failed with: {}",
                msg
            ));
            // For the love of God, stop it with the teapots. -T
            return (StatusCode::IM_A_TEAPOT, format_debug_output(&fail_html));
        } else {
            return (StatusCode::IM_A_TEAPOT, "<em>error</em>".to_string());
        }
    }

    let html = rhtml.unwrap();
    let links = extract_links(&html);

    // Are we still using println? -T  // No, we're using println! -V
    println!("got {} links:", links.len());
    println!("{}", links.join("\n"));

    let (metadata, debug_outputs): (Vec<Option<LinkMetadata>>, Vec<LinkDebugResult>) =
        future::join_all(links.iter().map(|x| render_link(x)))
            .await
            .into_iter()
            .unzip();

    let mut base_output = html
        + &metadata
            .iter()
            .filter(|x| x.is_some())
            .map(|data| data.as_ref().unwrap().to_html())
            .join("");

    if debug {
        let debug_output = markdown::to_html(&debug_outputs.iter().map(|o| o.to_md()).join("\n"));
        if !debug_output.trim().is_empty() {
            base_output += &format_debug_output(&debug_output);
        }
    }

    (StatusCode::OK, base_output)
}


#[cfg(test)]
mod tests {
    // Good stuff. Can't have too many tests. We learnt that the hard way in 12th grade. -T
    use super::*;

    #[test]
    fn regex_find_link_1() {
        let links = extract_links(r#"<h2>Hi</h2><a href="http://example.com">"#);
        assert_eq!(links.len(), 1);
        assert_eq!(links[0], "http://example.com");
    }

    #[test]
    fn regex_find_link_2() {
        let links = extract_links(r#"<h2>Hi</h2><a target="_blank" href="http://example.com">"#);
        assert_eq!(links.len(), 1);
        assert_eq!(links[0], "http://example.com");
    }

    #[test]
    fn regex_find_link_fail_1() {
        let links = extract_links(r#"<h2>Hi</h2><ahref="http://example.com">"#);
        assert_eq!(links.len(), 0);

        let links = extract_links(r#"<h2>Hi</h2>href="http://example.com"#);
        assert_eq!(links.len(), 0);

        let links = extract_links(r#"<h2>Hi</h2><a b=1 ref="http://example.com">"#);
        assert_eq!(links.len(), 0);

        let links = extract_links(r#"<h2>Hi</h2><a b=1><img href="http://example.com">"#);
        assert_eq!(links.len(), 0);
    }

    #[test]
    fn regex_find_link_special() {
        let links = extract_links(r#"<h2>Hi</h2><a b="1><img" href="http://example.com">"#);
        assert_eq!(links.len(), 0);
    }

    #[test]
    fn regex_capture_test() {
        let regex = Regex::new(&make_meta_regex("og:title")).unwrap();
        let res = extract_meta_tag(
            &regex,
            r#"<meta property="og:title" content="Never gonna give you up!@#$">"#,
        );
        assert!(res.is_some());
        assert_eq!(res, Some("Never gonna give you up!@#$"));

        let res2 = extract_meta_tag(
            &regex,
            r#"<meta    property="og:title"    content="Never gonna give you up!@#$">"#,
        );
        assert!(res2.is_some());
        assert_eq!(res2, Some("Never gonna give you up!@#$"));
    }

    #[test]
    fn regex_capture_prop_after() {
        let regex = Regex::new(&make_meta_regex("og:title")).unwrap();
        let res = extract_meta_tag(
            &regex,
            r#"<meta    content="Never gonna give you up!@#$"   property="og:title">"#,
        );
        assert!(res.is_some());
        assert_eq!(res, Some("Never gonna give you up!@#$"));
    }

    #[test]
    fn regex_capture_fail() {
        let regex = Regex::new(&make_meta_regex("og:title")).unwrap();
        let res = extract_meta_tag(
            &regex,
            r#"<meta content="Never gonna give" you up property="og:title">"#,
        );
        assert!(res.is_none());
    }
}
