#include <stdio.h>
#include <stdlib.h>


int main() {

    setvbuf(stdout,0,2,0);
    setvbuf(stdin,0,2,0);
    int ans[7];
    for(int i = 0; i < 7; i++) {
        ans[i] = rand()%49 +1;
    }
    puts("Welclome to Lottery! If You get the jackpot, You win");

    int win = 0;
    int special = 0;
    for(int i = 0; i < 6; i++) {
        int choice;
        scanf("%d", &choice);
        if(choice <= 0) {
            puts("Bad hacker");
            exit(0);
        }
        for (int i = 0; i < 6;i++) {
            if(choice == ans[i]) {
                win++;
                ans[i] = 0;
            }
        }
        if (choice == ans[6]) {
            special = 1;
            ans[6] = 0;
        }
    }
    if(special){
        switch (win)
        {
        case 2:
            puts("You get the 7th price but not 1st QAQ");
            break;
        case 3:
            puts("You get the 6th price but not 1st QAQ");
            break;
        case 4:
            puts("You get the 4th price but not 1st QAQ");
            break;
        case 5:
            puts("You get the 2nd price but not 1st QAQ");
            break;
        default:
            break;
        }
    }
    else {
        switch (win)
        {
        case 3:
            puts("You get the normal price but not 1st QAQ");
            break;
        case 4:
            puts("You get the 5th price but not 1st QAQ");
            break;
        case 5:
            puts("You get the 3th price but not 1st QAQ");
            break;
        default:
            break;
        }
    }
    if (win == 6) {
        puts("JACKPOT!!! ,congratulations");
        system("sh");
    }
    
}
