#include <stdio.h>
#include <stdlib.h>


void win() {
    system("sh");
}


int main() {
    setvbuf(stdin,0,2,0);
    setvbuf(stdout,0,2,0);
    
    puts("Do you want to be a VIP of Country Wahahabihal");
    printf("You would need %lld dollars if you want\n",main);
    char choice [5];
    char username[32];
    scanf("%5s", choice);
    if(choice[0] == 'y'){
        gets(username);
        puts("Congratulation, you're now the 1st VIP of Country Wahahabihal");
    }
    else {
        exit(0);
    }
    return 0;

}
