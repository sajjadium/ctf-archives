#!/bin/sh

exec 2>/dev/null
LD_PRELOAD=/home/chal/THJCC\{\?\?\?}.so timeout 60 /home/chal/chal
