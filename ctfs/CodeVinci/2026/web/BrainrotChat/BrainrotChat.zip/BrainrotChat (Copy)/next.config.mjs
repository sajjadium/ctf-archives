/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: false,
  async headers() {
    return [
      {
        source: "/admin",
        headers: [
          {
            key: "Content-Security-Policy",
            value: [
              "default-src 'self'",
              "script-src 'self' 'unsafe-eval'",
              "style-src 'self' 'unsafe-inline'",
              "img-src * data:",
              "connect-src *",
              "font-src 'self'"
            ].join("; ")
          }
        ]
      }
    ];
  }
};

export default nextConfig;
