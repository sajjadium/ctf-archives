import { clearSessionCookie, deleteSession } from "../../../../lib/auth";

export async function POST(request) {
  const token = request.cookies.get("session")?.value;
  await deleteSession(token);
  return Response.json(
    { ok: true },
    {
      headers: {
        "Set-Cookie": clearSessionCookie()
      }
    }
  );
}
