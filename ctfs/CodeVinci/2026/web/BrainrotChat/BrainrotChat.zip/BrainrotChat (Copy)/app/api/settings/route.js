import { getPool } from "../../../lib/db";
import { getUserFromRequest } from "../../../lib/auth";

export async function POST(request) {
  const user = await getUserFromRequest(request);
  if (!user) {
    return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  const { displayName, bio, status } = await request.json();
  const cleanDisplay = String(displayName || "").trim().slice(0, 64);
  const cleanBio = String(bio || "").trim().slice(0, 255);
  const cleanStatus = String(status || "").trim().slice(0, 1024);
  if (cleanStatus && !/^[A-Za-z0-9+/=]+$/.test(cleanStatus)) {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  try {
    const pool = getPool();
    await pool.query(
      "UPDATE users SET display_name = ?, bio = ?, status = ? WHERE id = ?",
      [cleanDisplay || user.handle, cleanBio, cleanStatus, user.id]
    );

    const macroTag = `profile_${user.id}`;
    await pool.query(
      "INSERT INTO sfx(tag, payload) VALUES (?, ?) ON DUPLICATE KEY UPDATE payload = VALUES(payload)",
      [macroTag, cleanStatus]
    );

    return Response.json({
      ok: true,
      user: {
        handle: user.handle,
        display_name: cleanDisplay || user.handle,
        bio: cleanBio,
        status: cleanStatus
      }
    });
  } catch (err) {
    console.error("Settings update error:", err.message);
    return Response.json({ ok: false, error: "Update failed" }, { status: 500 });
  }
}
