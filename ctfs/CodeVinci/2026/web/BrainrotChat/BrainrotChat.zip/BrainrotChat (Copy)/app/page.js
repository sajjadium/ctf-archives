"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";

function getInitials(text) {
  if (!text) return "?";
  const parts = text.split(/\s|_|-/).filter(Boolean);
  const first = parts[0] ? parts[0][0] : text[0];
  const second = parts[1] ? parts[1][0] : "";
  return (first + second).toUpperCase();
}

function hashOnline(text) {
  let sum = 0;
  for (let i = 0; i < text.length; i += 1) {
    sum += text.charCodeAt(i) * (i + 1);
  }
  return sum % 3 !== 0;
}

export default function HomePage() {
  const [user, setUser] = useState(null);
  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [body, setBody] = useState("");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notice, setNotice] = useState("");
  const [chatError, setChatError] = useState("");
  const [search, setSearch] = useState("");
  const [filtering, setFiltering] = useState(false);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [toast, setToast] = useState("");
  const [showToast, setShowToast] = useState(false);

  const messagesRef = useRef(null);
  const lastMessageCount = useRef(0);
  const lastMessageIdRef = useRef(null);
  const updateSourceRef = useRef("refresh");
  const toastTimerRef = useRef(null);
  const visibilityRef = useRef("visible");


  const activeChatName = useMemo(() => {
    const chat = chats.find((item) => item.id === activeChat);
    return chat ? chat.name : "Select a chat";
  }, [chats, activeChat]);

  const filteredChats = useMemo(() => {
    const term = search.trim().toLowerCase();
    if (!term) return chats;
    return chats.filter((chat) =>
      [chat.name, chat.topic, chat.preview].some((value) =>
        String(value || "").toLowerCase().includes(term)
      )
    );
  }, [chats, search]);

  useEffect(() => {
    fetch("/api/me")
      .then((res) => res.json())
      .then((data) => setUser(data.user || null));
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const handler = () => {
      visibilityRef.current = document.visibilityState || "visible";
    };
    handler();
    document.addEventListener("visibilitychange", handler);
    return () => document.removeEventListener("visibilitychange", handler);
  }, []);

  useEffect(() => {
    fetch("/api/chats")
      .then((res) => res.json())
      .then((data) => {
        setChats(data.chats || []);
        if (data.chats && data.chats.length) {
          setActiveChat(data.chats[0].id);
        } else {
          setActiveChat(null);
        }
      });
  }, [user]);

  const getDistanceFromBottom = useCallback(() => {
    const el = messagesRef.current;
    if (!el) return 0;
    return el.scrollHeight - el.scrollTop - el.clientHeight;
  }, []);

  const scrollToBottom = useCallback((behavior = "auto") => {
    const el = messagesRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior });
  }, []);

  const updateScrollButton = useCallback(() => {
    const distance = getDistanceFromBottom();
    const shouldShow = distance > 200 || unreadCount > 0;
    setShowScrollButton(shouldShow);
    if (distance < 40 && unreadCount) {
      setUnreadCount(0);
      setShowToast(false);
    }
  }, [getDistanceFromBottom, unreadCount]);

  const triggerToast = useCallback((message) => {
    if (visibilityRef.current !== "visible") {
      return;
    }
    setToast(message);
    setShowToast(true);
    if (toastTimerRef.current) {
      clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = setTimeout(() => {
      setShowToast(false);
    }, 2600);
  }, []);

  useEffect(() => {
    if (!activeChat) {
      setMessages([]);
      return;
    }
    updateSourceRef.current = "refresh";
    fetch(`/api/messages?chatId=${activeChat}`)
      .then((res) => res.json())
      .then((data) => setMessages(data.messages || []));
  }, [activeChat, user]);

  useEffect(() => {
    if (!activeChat) return;
    let stopped = false;
    let timeoutId;
    const poll = async () => {
      try {
        const sinceId = lastMessageIdRef.current;
        const url = sinceId
          ? `/api/messages?chatId=${activeChat}&sinceId=${sinceId}`
          : `/api/messages?chatId=${activeChat}`;
        const res = await fetch(url);
        const data = await res.json();
        if (stopped || !data.messages) return;
        const next = data.messages;
        if (!next.length) return;
        updateSourceRef.current = "live";
        const distance = getDistanceFromBottom();
        const shouldAuto = distance < 120 || messagesRef.current?.scrollTop === 0;
        if (!shouldAuto) {
          setUnreadCount((prev) => {
            const total = prev + next.length;
            triggerToast(
              `${total} new message${total > 1 ? "s" : ""} received`
            );
            return total;
          });
          setShowScrollButton(true);
        }
        if (sinceId) {
          setMessages((prev) => [...prev, ...next]);
        } else {
          setMessages(next);
        }
      } catch (err) {
        // Ignore polling errors to avoid spamming UI.
      }
      if (stopped) return;
      const delay = visibilityRef.current === "hidden" ? 15000 : 4000;
      timeoutId = setTimeout(poll, delay);
    };
    const initialDelay = visibilityRef.current === "hidden" ? 15000 : 4000;
    timeoutId = setTimeout(poll, initialDelay);
    return () => {
      stopped = true;
      clearTimeout(timeoutId);
    };
  }, [activeChat, getDistanceFromBottom, triggerToast]);

  useEffect(() => {
    lastMessageCount.current = 0;
    lastMessageIdRef.current = null;
    updateSourceRef.current = "refresh";
    setShowScrollButton(false);
    setUnreadCount(0);
    setShowToast(false);
  }, [activeChat]);

  useEffect(() => {
    const el = messagesRef.current;
    if (!el) return;
    const isNew = messages.length > lastMessageCount.current;
    lastMessageCount.current = messages.length;
    lastMessageIdRef.current = messages.length
      ? messages[messages.length - 1].id
      : null;
    const distanceFromBottom = getDistanceFromBottom();
    const shouldScroll = distanceFromBottom < 120 || el.scrollTop === 0;
    if (isNew && shouldScroll) {
      const behavior = updateSourceRef.current === "live" ? "smooth" : "auto";
      requestAnimationFrame(() => {
        scrollToBottom(behavior);
        updateScrollButton();
      });
    } else {
      updateScrollButton();
    }
    updateSourceRef.current = "refresh";
  }, [messages, getDistanceFromBottom, scrollToBottom, updateScrollButton]);

  useEffect(() => {
    const el = messagesRef.current;
    if (!el) return;
    const handler = () => updateScrollButton();
    el.addEventListener("scroll", handler);
    updateScrollButton();
    return () => el.removeEventListener("scroll", handler);
  }, [activeChat, updateScrollButton]);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) {
        clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  useEffect(() => {
    setFiltering(true);
    const timer = setTimeout(() => setFiltering(false), 180);
    return () => clearTimeout(timer);
  }, [search]);

  const sendMessage = async () => {
    setChatError("");
    if (!body.trim()) return;
    const res = await fetch("/api/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chatId: activeChat, body })
    });
    const data = await res.json();
    if (!data.ok) {
      setChatError(data.error || "Send failed");
      return;
    }
    updateSourceRef.current = "local";
    setBody("");
    setMessages((prev) => [...prev, data.message]);
    lastMessageIdRef.current = data.message.id;
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    setMessages([]);
    setNotice("Logged out.");
  };


  return (
    <main className="main">
      <aside className="sidebar">
        <div className="card">
          <div className="sidebar-header">
            <div>
              <h3>Chats</h3>
              <div className="muted">Workspace rooms</div>
            </div>
            <button className="menu-btn" onClick={() => setDrawerOpen(true)}>
              Menu
            </button>
          </div>
          <input
            className="search-input"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats"
            aria-label="Search chats"
          />
          <div className={`chat-list ${filtering ? "filtering" : ""}`}>
            {filteredChats.map((chat) => {
              const online = hashOnline(chat.name || "");
              return (
                <div
                  key={chat.id}
                  className={`chat-item ${chat.id === activeChat ? "active" : ""}`}
                  onClick={() => setActiveChat(chat.id)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      setActiveChat(chat.id);
                    }
                  }}
                  role="button"
                  tabIndex={0}
                  aria-current={chat.id === activeChat}
                >
                  <div className="chat-item-row">
                    <div className="avatar">
                      {chat.icon || getInitials(chat.name)}
                      <span className={`status-dot ${online ? "on" : "off"}`} />
                    </div>
                    <div className="chat-item-body">
                      <span>{chat.name}</span>
                      <div className="muted">
                        {chat.preview || chat.topic || "No preview"}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            {!filteredChats.length && (
              <div className="muted">No chats available.</div>
            )}
          </div>
        </div>
      </aside>

      <section className="card chat-window">
        <div className="chat-header">
          <h2>{activeChatName}</h2>
          <div className="muted">
            {user ? `Logged in as ${user.display_name || user.handle}` : "Guest view"}
          </div>
        </div>
        <div
          key={activeChat || "none"}
          className="messages fade"
          ref={messagesRef}
        >
          {messages.map((msg, index) => {
            const isSelf = msg.handle === user?.handle;
            const delay = Math.min(index, 8) * 40;
            return (
              <div
                key={msg.id}
                className={`message-row ${isSelf ? "self" : ""}`}
                style={{ "--stagger": `${delay}ms` }}
              >
                {!isSelf && (
                  <div className="avatar message-avatar">
                    {getInitials(msg.handle)}
                  </div>
                )}
                <div className={`message ${isSelf ? "self" : ""}`}>
                  <div className="message-header">
                    <span className="message-name">{msg.handle}</span>
                    <span className="meta-chip">{msg.created_at}</span>
                  </div>
                  <div>{msg.body}</div>
                </div>
                {isSelf && (
                  <div className="avatar message-avatar self">
                    {getInitials(msg.handle)}
                  </div>
                )}
              </div>
            );
          })}
          {!messages.length && <div className="muted">No messages yet.</div>}
        </div>
        {showToast && (
          <button
            className="toast"
            type="button"
            onClick={() => {
              scrollToBottom("smooth");
              setUnreadCount(0);
              setShowToast(false);
            }}
            aria-live="polite"
          >
            {toast}
          </button>
        )}
        {showScrollButton && (
          <button
            className="scroll-button"
            onClick={() => {
              scrollToBottom("smooth");
              setUnreadCount(0);
              setShowToast(false);
            }}
            type="button"
            aria-label="Scroll to bottom"
          >
            {unreadCount > 0
              ? `${unreadCount} new message${unreadCount > 1 ? "s" : ""} ↓`
              : "Scroll to bottom ↓"}
          </button>
        )}
        <div className="message-input">
          <input
            value={body}
            onChange={(e) => setBody(e.target.value)}
            placeholder={
              user
                ? "Type a message"
                : "Login to send messages"
            }
            disabled={!user}
          />
          <button onClick={sendMessage} disabled={!user}>
            Send
          </button>
        </div>
        {chatError && <div className="error">{chatError}</div>}
      </section>

      {drawerOpen && (
        <div className="drawer-overlay" onClick={() => setDrawerOpen(false)} />
      )}
      <aside className={`drawer ${drawerOpen ? "open" : ""}`}>
        <div className="drawer-header">
          <div>
            <div className="drawer-title">
              {user ? user.display_name || user.handle : "Guest"}
            </div>
            <div className="muted">Account menu</div>
          </div>
          <button className="close-btn" onClick={() => setDrawerOpen(false)}>
            Close
          </button>
        </div>

        {!user && (
          <div className="drawer-section">
            <Link className="menu-link" href="/login">
              Login
            </Link>
            <Link className="menu-link" href="/register">
              Create account
            </Link>
            <div className="muted">Sign in to unlock more rooms.</div>
          </div>
        )}

        {user && (
          <div className="drawer-section">
            <Link className="menu-link" href="/settings">
              Settings
            </Link>
            <Link className="menu-link" href="/report">
              Report to admin
            </Link>
            <button className="ghost-btn" onClick={logout}>
              Logout
            </button>
          </div>
        )}

        {notice && <div className="notice">{notice}</div>}
      </aside>
    </main>
  );
}
