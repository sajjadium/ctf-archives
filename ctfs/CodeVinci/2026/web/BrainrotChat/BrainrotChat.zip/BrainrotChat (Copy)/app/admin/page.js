import crypto from "crypto";
import { cookies } from "next/headers";
import { getPool } from "../../lib/db";

export const dynamic = "force-dynamic";

function renderBody(body, secret) {
  if (typeof body === "string" && body.startsWith("sigil::")) {
    const packed = body.slice(7);
    const dot = packed.lastIndexOf(".");
    if (dot === -1) {
      return <div>sigil missing signature</div>;
    }
    const encoded = packed.slice(0, dot);
    const sig = packed.slice(dot + 1);
    const expected = crypto
      .createHash("sha256")
      .update(secret + encoded)
      .digest("hex");
    if (sig !== expected) {
      return <div>sigil signature invalid</div>;
    }
    try {
      const decoded = Buffer.from(encoded, "base64").toString("utf-8");
      return <div dangerouslySetInnerHTML={{ __html: decoded }} />;
    } catch (err) {
      return <div>sigil decode failed</div>;
    }
  }
  return <div>{body}</div>;
}

function isAdmin() {
  const cookieStore = cookies();
  const token = cookieStore.get("admin_session")?.value;
  const expected = process.env.ADMIN_TOKEN || "super-secret";
  return token && token === expected;
}

export default async function AdminPage() {
  if (!isAdmin()) {
    return (
      <main className="main">
        <section className="card">
          <h2>Access denied</h2>
          <p className="muted">This chat is locked.</p>
        </section>
      </main>
    );
  }

  const pool = getPool();
  const secretChatId = Number(process.env.SECRET_CHAT_ID || 2);
  const [messages] = await pool.query(
    "SELECT messages.id, users.handle, messages.body, "
      + "DATE_FORMAT(messages.created_at, '%H:%i:%s') AS ts "
      + "FROM messages "
      + "JOIN users ON users.id = messages.user_id "
      + "WHERE messages.chat_id = ? "
      + "ORDER BY messages.created_at ASC",
    [secretChatId]
  );

  const [flags] = await pool.query("SELECT flag FROM flags LIMIT 1");
  const flag = flags.length ? flags[0].flag : "flag{missing}";
  const [sigilRows] = await pool.query("SELECT secret FROM sigil_keys LIMIT 1");
  const sigilSecret = sigilRows.length ? sigilRows[0].secret : "sigil-secret-key";

  return (
    <main className="main">
      <section className="card chat-window">
        <div className="chat-header">
          <h2>Shadow Chat</h2>
          <div className="muted">Admin view</div>
        </div>
        <script src="/sigil-runner.js" defer />
        <div className="messages">
          {messages.map((msg) => (
            <div key={msg.id} className="message">
              <div className="meta">{msg.handle} - {msg.ts}</div>
              {renderBody(msg.body, sigilSecret)}
            </div>
          ))}
        </div>
        <div id="flag" style={{ display: "none" }}>{flag}</div>
      </section>
    </main>
  );
}
