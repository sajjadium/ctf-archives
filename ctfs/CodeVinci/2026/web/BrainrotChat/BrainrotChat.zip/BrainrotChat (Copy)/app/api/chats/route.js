import { getPool } from "../../../lib/db";
import { getUserFromRequest, isAdminSession } from "../../../lib/auth";

export async function GET(request) {
  const pool = getPool();
  const user = await getUserFromRequest(request);
  const isAdmin = isAdminSession(request);

  let where = "WHERE chats.is_hidden = 0";
  if (!isAdmin) {
    if (!user) {
      where += " AND chats.requires_auth = 0";
    }
  } else {
    where = "";
  }

  const [rows] = await pool.query(
    "SELECT chats.id, chats.name, chats.topic, chats.icon, chats.requires_auth, chats.is_hidden, "
      + "(SELECT body FROM messages WHERE chat_id = chats.id ORDER BY created_at DESC LIMIT 1) AS preview "
      + "FROM chats "
      + where
      + " ORDER BY chats.id ASC"
  );

  return Response.json({
    chats: rows.map((row) => ({
      id: row.id,
      name: row.name,
      topic: row.topic || "",
      icon: row.icon || "",
      preview: row.preview || "",
      requiresAuth: !!row.requires_auth,
      isHidden: !!row.is_hidden
    }))
  });
}
