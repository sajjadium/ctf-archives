import { getUserFromRequest } from "../../../lib/auth";

export async function GET(request) {
  const user = await getUserFromRequest(request);
  if (!user) {
    return Response.json({ user: null });
  }
  return Response.json({
    user: {
      handle: user.handle,
      display_name: user.display_name,
      bio: user.bio,
      status: user.status
    }
  });
}
