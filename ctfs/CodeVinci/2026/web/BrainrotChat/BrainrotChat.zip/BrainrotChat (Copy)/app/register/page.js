"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function RegisterPage() {
  const router = useRouter();
  const [handle, setHandle] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ handle, password, displayName })
    });
    const data = await res.json();
    if (!data.ok) {
      setError(data.error || "Registration failed");
      return;
    }
    router.push("/");
  };

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h2>Create account</h2>
        <p className="muted">Join the workspace and unlock chat rooms.</p>
        <form onSubmit={submit} className="auth-form">
          <input
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            placeholder="handle"
          />
          <input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="display name"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="password"
          />
          <button type="submit">Register</button>
        </form>
        {error && <div className="error">{error}</div>}
      </div>
    </main>
  );
}
