"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function SettingsPage() {
  const router = useRouter();
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [status, setStatus] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    fetch("/api/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        setDisplayName(data.user.display_name || data.user.handle || "");
        setBio(data.user.bio || "");
        setStatus(data.user.status || "");
        setLoaded(true);
      });
  }, [router]);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setNotice("");
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ displayName, bio, status })
    });
    const data = await res.json();
    if (!data.ok) {
      setError(data.error || "Save failed");
      return;
    }
    setNotice("Profile updated.");
  };

  if (!loaded) {
    return (
      <main className="auth-page">
        <div className="auth-card">
          <h2>Loading</h2>
        </div>
      </main>
    );
  }

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h2>Profile settings</h2>
        <p className="muted">Update your display info.</p>
        <form onSubmit={submit} className="auth-form">
          <input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            placeholder="display name"
          />
          <input
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="bio"
          />
          <input
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            placeholder="status (base64)"
          />
          <button type="submit">Save</button>
        </form>
        {error && <div className="error">{error}</div>}
        {notice && <div className="notice">{notice}</div>}
      </div>
    </main>
  );
}
