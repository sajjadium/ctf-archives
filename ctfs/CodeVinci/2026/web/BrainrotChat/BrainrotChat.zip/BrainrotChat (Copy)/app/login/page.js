"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const [handle, setHandle] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ handle, password })
    });
    const data = await res.json();
    if (!data.ok) {
      setError(data.error || "Login failed");
      return;
    }
    router.push("/");
  };

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h2>Sign in</h2>
        <p className="muted">Access your chat workspace.</p>
        <form onSubmit={submit} className="auth-form">
          <input
            value={handle}
            onChange={(e) => setHandle(e.target.value)}
            placeholder="handle"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="password"
          />
          <button type="submit">Login</button>
        </form>
        {error && <div className="error">{error}</div>}
      </div>
    </main>
  );
}
