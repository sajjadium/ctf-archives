"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function ReportPage() {
  const router = useRouter();
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    fetch("/api/me")
      .then((res) => res.json())
      .then((data) => {
        if (!data.user) {
          router.push("/login");
          return;
        }
        if (typeof window !== "undefined") {
          setUrl(`${window.location.origin}/admin`);
        }
        setReady(true);
      });
  }, [router]);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setNotice("");
    const res = await fetch("/api/report", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url })
    });
    const data = await res.json();
    if (!data.ok) {
      setError(data.error || "Bot failed");
      return;
    }
    setNotice("Bot queued.");
  };

  if (!ready) {
    return (
      <main className="auth-page">
        <div className="auth-card">
          <h2>Loading</h2>
        </div>
      </main>
    );
  }

  return (
    <main className="auth-page">
      <div className="auth-card">
        <h2>Report to admin</h2>
        <p className="muted">Request a review by the admin bot.</p>
        <form onSubmit={submit} className="auth-form">
          <input
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="http://localhost:3000/admin"
          />
          <button type="submit">Send report</button>
        </form>
        {error && <div className="error">{error}</div>}
        {notice && <div className="notice">{notice}</div>}
      </div>
    </main>
  );
}
