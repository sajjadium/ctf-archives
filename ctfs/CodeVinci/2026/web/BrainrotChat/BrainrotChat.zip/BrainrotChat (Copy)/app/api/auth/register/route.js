import { getPool } from "../../../../lib/db";
import { createSession, hashPassword, sessionCookie } from "../../../../lib/auth";

export async function POST(request) {
  const { handle, password, displayName } = await request.json();
  const cleanHandle = String(handle || "").trim().toLowerCase();
  const cleanPassword = String(password || "");
  const cleanDisplay = String(displayName || "").trim();

  if (!/^[a-z_][a-z0-9_]{2,15}$/.test(cleanHandle)) {
    return Response.json({ ok: false, error: "Handle invalid" }, { status: 400 });
  }
  if (cleanPassword.length < 6) {
    return Response.json({ ok: false, error: "Password too short" }, { status: 400 });
  }

  const pool = getPool();
  const passwordHash = hashPassword(cleanPassword);
  try {
    const [result] = await pool.query(
      "INSERT INTO users(handle, password_hash, display_name, bio, status, vibe, aura, role) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?, 'user')",
      [
        cleanHandle,
        passwordHash,
        cleanDisplay || cleanHandle,
        "New brainrot resident",
        "",
        "new vibes",
        100
      ]
    );
    const token = await createSession(result.insertId);
    return Response.json(
      {
        ok: true,
        user: {
          id: result.insertId,
          handle: cleanHandle,
          display_name: cleanDisplay || cleanHandle
        }
      },
      {
        headers: {
          "Set-Cookie": sessionCookie(token)
        }
      }
    );
  } catch (err) {
    return Response.json({ ok: false, error: "Handle taken" }, { status: 400 });
  }
}
