import { runBot } from "../../../lib/bot";
import { getUserFromRequest } from "../../../lib/auth";

export const runtime = "nodejs";

export async function POST(request) {
  const user = await getUserFromRequest(request);
  if (!user) {
    return Response.json({ ok: false, error: "Login required" }, { status: 401 });
  }

  const { url } = await request.json();
  if (!url || typeof url !== "string") {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  const origin = process.env.APP_ORIGIN || "http://localhost:3000";
  let parsed;
  try {
    parsed = new URL(url);
  } catch (err) {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }
  if (parsed.origin !== origin) {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  try {
    await runBot(url);
    return Response.json({ ok: true });
  } catch (err) {
    console.error("Bot error:", err.message);
    return Response.json({ ok: false, error: "Request failed" }, { status: 500 });
  }
}
