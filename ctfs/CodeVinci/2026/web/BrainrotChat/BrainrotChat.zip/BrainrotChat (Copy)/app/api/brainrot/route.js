import { getPool } from "../../../lib/db";
import { BrainrotParser, BrainrotParseError } from "../../../lib/brainrotParser";
import { getUserFromRequest } from "../../../lib/auth";

export const runtime = "nodejs";

export async function POST(request) {
  const user = await getUserFromRequest(request);
  if (!user) {
    return Response.json({ ok: false, error: "Login required" }, { status: 401 });
  }

  const { query } = await request.json();
  if (!query || typeof query !== "string") {
    return Response.json({ ok: false, error: "Missing query" }, { status: 400 });
  }

  const pool = getPool();
  const [sfxRows] = await pool.query("SELECT tag, payload FROM sfx");
  const sfxMap = new Map(sfxRows.map((row) => [row.tag, row.payload]));
  const resolveSfx = (tag) => {
    const payload = sfxMap.get(tag);
    if (!payload) return null;
    if (tag.startsWith("profile_")) {
      try {
        return Buffer.from(payload, "base64").toString("utf-8");
      } catch (err) {
        return null;
      }
    }
    return payload;
  };

  try {
    const parser = new BrainrotParser({
      paramPlaceholder: "?",
      allowedTables: ["users", "clips"],
      allowedFields: [
        "id",
        "handle",
        "display_name",
        "bio",
        "status",
        "vibe",
        "aura",
        "role",
        "user_id",
        "chant",
        "intensity",
        "mood"
      ],
      macroResolver: (tag) => resolveSfx(tag)
    });

    const { sql, params } = parser.compile(query);
    const [rows] = await pool.query(sql, params);
    let resultRows = [];
    if (Array.isArray(rows)) {
      resultRows = Array.isArray(rows[0]) ? rows[0] : rows;
    }
    return Response.json({ ok: true, rows: resultRows });
  } catch (err) {
    // Log error internally but don't expose details
    console.error("BrainrotQL error:", err.message);
    return Response.json({ ok: false, error: "Query processing failed" }, { status: 400 });
  }
}
