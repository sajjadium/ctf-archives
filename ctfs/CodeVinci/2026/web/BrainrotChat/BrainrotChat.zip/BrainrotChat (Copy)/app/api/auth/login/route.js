import { getPool } from "../../../../lib/db";
import { createSession, hashPassword, sessionCookie } from "../../../../lib/auth";

export async function POST(request) {
  const { handle, password } = await request.json();
  const cleanHandle = String(handle || "").trim().toLowerCase();
  const cleanPassword = String(password || "");

  if (!cleanHandle || !cleanPassword) {
    return Response.json({ ok: false, error: "Missing credentials" }, { status: 400 });
  }

  const pool = getPool();
  const passwordHash = hashPassword(cleanPassword);
  const [rows] = await pool.query(
    "SELECT id, handle, display_name FROM users WHERE handle = ? AND password_hash = ? LIMIT 1",
    [cleanHandle, passwordHash]
  );

  if (!rows.length) {
    return Response.json({ ok: false, error: "Invalid login" }, { status: 403 });
  }

  const user = rows[0];
  const token = await createSession(user.id);
  return Response.json(
    { ok: true, user },
    {
      headers: {
        "Set-Cookie": sessionCookie(token)
      }
    }
  );
}
