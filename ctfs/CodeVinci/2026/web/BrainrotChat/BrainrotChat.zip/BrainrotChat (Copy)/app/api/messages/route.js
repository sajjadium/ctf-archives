import { getPool } from "../../../lib/db";
import { getUserFromRequest, isAdminSession } from "../../../lib/auth";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const chatId = Number(searchParams.get("chatId"));
  const sinceId = Number(searchParams.get("sinceId") || 0);
  if (!chatId) {
    return Response.json({ messages: [] });
  }

  const pool = getPool();
  const user = await getUserFromRequest(request);
  const admin = isAdminSession(request);

  const [chatRows] = await pool.query(
    "SELECT id, is_hidden, requires_auth FROM chats WHERE id = ?",
    [chatId]
  );
  if (!chatRows.length) {
    return Response.json({ messages: [] });
  }
  const chat = chatRows[0];
  if (chat.is_hidden && !admin) {
    return Response.json({ messages: [] });
  }
  if (chat.requires_auth && !user && !admin) {
    return Response.json({ messages: [] });
  }

  const baseSql =
    "SELECT messages.id, users.handle, messages.body, "
      + "DATE_FORMAT(messages.created_at, '%H:%i:%s') AS created_at "
      + "FROM messages "
      + "JOIN users ON users.id = messages.user_id "
      + "WHERE messages.chat_id = ? ";
  const [rows] = await pool.query(
    sinceId > 0
      ? baseSql + "AND messages.id > ? ORDER BY messages.id ASC LIMIT 80"
      : baseSql + "ORDER BY messages.created_at ASC LIMIT 80",
    sinceId > 0 ? [chatId, sinceId] : [chatId]
  );

  return Response.json({ messages: rows });
}

export async function POST(request) {
  const body = await request.json();
  const chatId = Number(body.chatId);
  const messageBody = String(body.body || "").slice(0, 4000);
  if (!chatId || !messageBody.trim()) {
    return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
  }

  const pool = getPool();
  const user = await getUserFromRequest(request);
  const admin = isAdminSession(request);

  if (!user && !admin) {
    return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });
  }

  try {
    const [chatRows] = await pool.query(
      "SELECT is_hidden, requires_auth FROM chats WHERE id = ?",
      [chatId]
    );
    if (!chatRows.length) {
      return Response.json({ ok: false, error: "Invalid request" }, { status: 400 });
    }
    const chat = chatRows[0];
    if (chat.is_hidden && !admin) {
      return Response.json({ ok: false, error: "Unauthorized" }, { status: 403 });
    }
    if (chat.requires_auth && !user && !admin) {
      return Response.json({ ok: false, error: "Unauthorized" }, { status: 401 });
    }

    const userId = admin && !user ? 1 : user.id;
    const [result] = await pool.query(
      "INSERT INTO messages(chat_id, user_id, body) VALUES (?, ?, ?)",
      [chatId, userId, messageBody]
    );

    return Response.json({
      ok: true,
      message: {
        id: result.insertId,
        handle: user ? user.handle : "admin",
        body: messageBody,
        created_at: new Date().toISOString().slice(11, 19)
      }
    });
  } catch (err) {
    console.error("Message insert error:", err.message);
    return Response.json({ ok: false, error: "Failed to send message" }, { status: 500 });
  }
