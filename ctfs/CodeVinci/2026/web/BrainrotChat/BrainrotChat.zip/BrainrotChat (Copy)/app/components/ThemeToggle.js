"use client";

import { useEffect, useState } from "react";

const THEME_OPTIONS = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "retro", label: "Retro" }
];

const DEFAULT_THEME = "light";

function applyTheme(theme) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.dataset.theme = theme;
}

export default function ThemeToggle() {
  const [theme, setTheme] = useState(DEFAULT_THEME);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = window.localStorage.getItem("brainrot_theme");
    const initial = stored || DEFAULT_THEME;
    setTheme(initial);
    applyTheme(initial);
  }, []);

  const handleChange = (event) => {
    const next = event.target.value;
    setTheme(next);
    applyTheme(next);
    if (typeof window !== "undefined") {
      window.localStorage.setItem("brainrot_theme", next);
    }
  };

  return (
    <div className="theme-toggle">
      <span className="muted">Theme</span>
      <select
        className="theme-select"
        value={theme}
        onChange={handleChange}
        aria-label="Theme selector"
      >
        {THEME_OPTIONS.map((option) => (
          <option key={option.value} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
}
