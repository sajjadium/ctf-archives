import "./globals.css";
import ThemeToggle from "./components/ThemeToggle";

export const metadata = {
  title: "Brainrot Chat",
  description: "Brainrot DSL powered chat archive"
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <div className="app-shell">
          <header className="topbar">
            <div>
              <h1>Brainrot Chat</h1>
              <div className="muted">Secure team messaging</div>
            </div>
            <div className="topbar-actions">
              <ThemeToggle />
              <div className="muted">Enterprise relay</div>
            </div>
          </header>
          {children}
        </div>
      </body>
    </html>
  );
}
