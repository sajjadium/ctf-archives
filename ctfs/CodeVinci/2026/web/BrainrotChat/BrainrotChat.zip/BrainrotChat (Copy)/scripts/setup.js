import fs from "fs";
import path from "path";
import mysql from "mysql2/promise";
import crypto from "crypto";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

async function ensureColumn(conn, table, column, definition) {
  const [rows] = await conn.query(
    "SELECT COUNT(*) AS count FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?",
    [process.env.MYSQL_DB || "brainrot", table, column]
  );
  if (rows[0].count === 0) {
    await conn.query(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

async function main() {
  const schemaPath = path.join(__dirname, "..", "schema.sql");
  const sql = fs.readFileSync(schemaPath, "utf8");
  const statements = sql
    .split(";")
    .map((stmt) => stmt.trim())
    .filter(Boolean);

  const conn = await mysql.createConnection({
    host: process.env.MYSQL_HOST || "127.0.0.1",
    user: process.env.MYSQL_USER || "brainrot",
    password: process.env.MYSQL_PASSWORD || "brainrot",
    database: process.env.MYSQL_DB || "brainrot",
    port: Number(process.env.MYSQL_PORT || 3306),
    multipleStatements: true
  });

  try {
    for (const stmt of statements) {
      await conn.query(stmt);
    }

    await ensureColumn(conn, "chats", "topic", "VARCHAR(120) DEFAULT NULL");
    await ensureColumn(conn, "chats", "icon", "VARCHAR(8) DEFAULT NULL");
    await ensureColumn(conn, "chats", "requires_auth", "TINYINT(1) NOT NULL DEFAULT 1");
    await ensureColumn(conn, "chats", "is_hidden", "TINYINT(1) NOT NULL DEFAULT 0");

    await ensureColumn(conn, "users", "password_hash", "VARCHAR(64) NOT NULL DEFAULT ''");
    await ensureColumn(conn, "users", "display_name", "VARCHAR(64) DEFAULT NULL");
    await ensureColumn(conn, "users", "bio", "VARCHAR(255) DEFAULT NULL");
    await ensureColumn(conn, "users", "status", "VARCHAR(1024) DEFAULT NULL");
    await ensureColumn(conn, "users", "role", "VARCHAR(16) NOT NULL DEFAULT 'user'");
    await conn.query("ALTER TABLE users MODIFY COLUMN status VARCHAR(1024) DEFAULT NULL");

    const [userCount] = await conn.query("SELECT COUNT(*) AS count FROM users");
    if (userCount[0].count === 0) {
      const adminPassword = crypto.randomBytes(32).toString("hex");
      await conn.query(
        "INSERT INTO users(id, handle, password_hash, display_name, bio, status, vibe, aura, role) VALUES ?",
        [[
          [1, "admin", hashPassword(adminPassword), "Admin", "Shadow keeper", "silent", "oracle core", 9999, "admin"],
          [2, "guest", hashPassword("guest"), "Guest", "Just browsing", "offline", "open mic", 420, "user"],
          [3, "thung_thung_sahur", hashPassword("drums"), "Thung Thung", "Drumline", "thung", "drumline dawn", 9001, "user"],
          [4, "trallallero_trallala", hashPassword("pasta"), "Tralla", "Pasta parade", "trallala", "pasta parade", 420, "user"],
          [5, "skibidi_mogger", hashPassword("toilet"), "Skibidi", "Toilet rave", "bop", "toilet rave", 1337, "user"],
          [6, "sigma_mew", hashPassword("mew"), "Sigma", "Jawline ritual", "mew", "jawline ritual", 8008, "user"],
          [7, "aura_farmer", hashPassword("aura"), "Aura Farmer", "Glow harvest", "glow", "glow harvest", 777, "user"],
          [8, "ohio_survivor", hashPassword("ohio"), "Ohio Survivor", "Only in Ohio", "surviving", "ohio nightmare", 666, "user"],
          [9, "rizz_master", hashPassword("rizz"), "Rizz Master", "W rizz only", "rizzing", "rizz aura", 9000, "user"],
          [10, "gyatt_lord", hashPassword("gyatt"), "Gyatt Lord", "GYATT", "gyatting", "gyatt check", 8500, "user"],
          [11, "fanum_taxer", hashPassword("fanum"), "Fanum Taxer", "Tax collector", "taxing", "fanum tax", 5000, "user"],
          [12, "kai_cenat_stan", hashPassword("kai"), "Kai Stan", "WWWWW", "streaming", "kai energy", 7777, "user"],
          [13, "baby_gronk", hashPassword("gronk"), "Baby Gronk", "Future NFL", "grinding", "gronk grind", 2025, "user"],
          [14, "livvy_dunne_simp", hashPassword("livvy"), "Livvy Simp", "Gymnast fan", "simping", "livvy dunne", 6969, "user"],
          [15, "duke_dennis", hashPassword("duke"), "Duke Dennis", "2K legend", "hooping", "duke energy", 8888, "user"],
          [16, "speed_runner", hashPassword("speed"), "IShowSpeed", "SIUUUU", "speeding", "speed chaos", 9999, "user"],
          [17, "grimace_shake", hashPassword("grimace"), "Grimace", "Purple shake", "shaking", "grimace era", 3333, "user"],
          [18, "mog_maxxer", hashPassword("mog"), "Mog Maxxer", "Mogging everyone", "mogging", "mog mode", 7500, "user"],
          [19, "looksmax_guru", hashPassword("looks"), "Looksmax Guru", "Ascend now", "ascending", "looksmax", 8000, "user"],
          [20, "gooning_addict", hashPassword("goon"), "Gooner", "Edge lord", "gooning", "goon cave", 4444, "user"],
          [21, "sussy_baka", hashPassword("amogus"), "Sussy Baka", "Among us", "venting", "sussy aura", 1111, "user"],
          [22, "npc_streamer", hashPassword("npc"), "NPC Andy", "Ice cream so good", "npc mode", "npc energy", 5555, "user"],
          [23, "bomboclaat_king", hashPassword("bombo"), "Bomboclaat", "Jamaican vibes", "bombo", "caribbean chaos", 7000, "user"],
          [24, "diddy_party", hashPassword("diddy"), "Diddy Host", "Party starter", "partying", "diddy energy", 1000, "user"],
          [25, "hawk_tuah", hashPassword("hawk"), "Hawk Tuah", "Spit on that thang", "hawking", "hawk tuah", 6500, "user"]
        ]]
      );
    }

    const secretChatId = Number(process.env.SECRET_CHAT_ID || 2);
    await conn.query(
      "INSERT IGNORE INTO chats(id, name, topic, icon, requires_auth, is_hidden) VALUES ?",
      [[
        [1, "App Bot", "Need an account to talk", "🤖", 0, 0],
        [secretChatId, "Shadow Chat", "Admin only", "🔒", 1, 1],
        [3, "Thung Squad", "Drumline hype", "🥁", 1, 0],
        [4, "Trallallero Lounge", "Pasta vibes", "🍝", 1, 0],
        [5, "Sigma Ops", "Jawline council", "💪", 1, 0],
        [6, "Skibidi Toilet HQ", "Toilet warfare", "🚽", 1, 0],
        [7, "Ohio Dimension", "Only in Ohio", "💀", 1, 0],
        [8, "Rizz Academy", "Learn the W rizz", "😏", 1, 0],
        [9, "Gyatt Central", "GYATT appreciation", "🍑", 1, 0],
        [10, "Fanum Tax Office", "Pay your taxes", "🍟", 1, 0],
        [11, "Kai Cenat Fan Club", "WWWWW gang", "📺", 1, 0],
        [12, "Baby Gronk x Livvy", "Power couple HQ", "🏈", 1, 0],
        [13, "Duke Dennis Court", "2K hoopers only", "🏀", 1, 0],
        [14, "IShowSpeed Zone", "SIUUUU chamber", "⚽", 1, 0],
        [15, "Grimace Shake Cult", "Purple gang", "💜", 1, 0],
        [16, "Mog or Get Mogged", "Mogging arena", "🗿", 1, 0],
        [17, "Looksmax Lab", "Ascension protocol", "📈", 1, 0],
        [18, "Goon Cave", "Edge lords only", "🌙", 1, 0],
        [19, "Among Us Lobby", "Sussy discussions", "📮", 1, 0],
        [20, "NPC Stream Chat", "Ice cream so good", "🍦", 1, 0],
        [21, "Bomboclaat Island", "Caribbean chaos", "🌴", 1, 0],
        [22, "Diddy Party Room", "Freak off zone", "🎉", 1, 0],
        [23, "Hawk Tuah Saloon", "Spit facts only", "🤠", 1, 0],
        [24, "Aura Check Station", "Check your aura", "✨", 1, 0],
        [25, "Edge Lord Summit", "No cap zone", "🧢", 1, 0]
      ]]
    );

    const [messageCount] = await conn.query("SELECT COUNT(*) AS count FROM messages");
    if (messageCount[0].count === 0) {
      const [userRows] = await conn.query("SELECT id, handle FROM users");
      const userMap = Object.fromEntries(userRows.map((row) => [row.handle, row.id]));
      await conn.query(
        "INSERT INTO messages(chat_id, user_id, body) VALUES ?",
        [[
          // App Bot
          [1, userMap.admin, "Welcome to Brainrot Chat. Sign in to unlock the other rooms."],
          [1, userMap.admin, "Guest mode can only read this bot chat."],
          // Shadow Chat (admin only)
          [secretChatId, userMap.admin, "keep the flag safe"],
          [secretChatId, userMap.admin, "no leaks"],
          [secretChatId, userMap.admin, Buffer.from("CodeVinci{NWtpbGxfaXNzdTM=}")],
          // Thung Squad
          [3, userMap.thung_thung_sahur, "thung thung sahur warmup 🥁"],
          [3, userMap.aura_farmer, "aura check on the drums"],
          [3, userMap.thung_thung_sahur, "THUNG THUNG THUNG"],
          // Trallallero Lounge
          [4, userMap.trallallero_trallala, "trallallero trallala chorus 🎵"],
          [4, userMap.skibidi_mogger, "skibidi bop bop yes yes"],
          [4, userMap.trallallero_trallala, "la la la la la"],
          // Sigma Ops
          [5, userMap.sigma_mew, "sigma grindset update: day 847"],
          [5, userMap.mog_maxxer, "keep mogging kings"],
          [5, userMap.looksmax_guru, "mewing session starts now"],
          // Skibidi Toilet HQ
          [6, userMap.skibidi_mogger, "skibidi dop dop dop yes yes 🚽"],
          [6, userMap.npc_streamer, "toilet cam activated"],
          [6, userMap.skibidi_mogger, "camera man spotted"],
          // Ohio Dimension
          [7, userMap.ohio_survivor, "bro only in ohio fr fr 💀"],
          [7, userMap.sussy_baka, "ohio is not real"],
          [7, userMap.ohio_survivor, "i saw a flying toilet in ohio"],
          // Rizz Academy
          [8, userMap.rizz_master, "W rizz tutorial starting 😏"],
          [8, userMap.gyatt_lord, "teach me the ways"],
          [8, userMap.rizz_master, "step 1: have aura"],
          // Gyatt Central
          [9, userMap.gyatt_lord, "GYATT 🍑"],
          [9, userMap.rizz_master, "respectfully gyatt"],
          [9, userMap.duke_dennis, "gyatt dayum"],
          // Fanum Tax Office
          [10, userMap.fanum_taxer, "fanum tax collected 🍟"],
          [10, userMap.kai_cenat_stan, "not my fries bro"],
          [10, userMap.fanum_taxer, "one bite tax applied"],
          // Kai Cenat Fan Club
          [11, userMap.kai_cenat_stan, "WWWWWWWW 📺"],
          [11, userMap.speed_runner, "kai x speed collab when"],
          [11, userMap.kai_cenat_stan, "mafiathon 2 soon"],
          // Baby Gronk x Livvy
          [12, userMap.baby_gronk, "future NFL star loading 🏈"],
          [12, userMap.livvy_dunne_simp, "livvy carried"],
          [12, userMap.baby_gronk, "rizz god in training"],
          // Duke Dennis Court
          [13, userMap.duke_dennis, "2K park who got next 🏀"],
          [13, userMap.speed_runner, "im selling"],
          [13, userMap.duke_dennis, "green bean timing"],
          // IShowSpeed Zone
          [14, userMap.speed_runner, "SIUUUUUUU ⚽"],
          [14, userMap.kai_cenat_stan, "RONALDOOO"],
          [14, userMap.speed_runner, "SEWEY"],
          // Grimace Shake Cult
          [15, userMap.grimace_shake, "the grimace shake... 💜"],
          [15, userMap.sussy_baka, "last video before..."],
          [15, userMap.grimace_shake, "purple reign"],
          // Mog or Get Mogged
          [16, userMap.mog_maxxer, "daily mog check 🗿"],
          [16, userMap.looksmax_guru, "you either mog or get mogged"],
          [16, userMap.sigma_mew, "height mog activated"],
          // Looksmax Lab
          [17, userMap.looksmax_guru, "mewing day 365 📈"],
          [17, userMap.mog_maxxer, "bone smashing works trust"],
          [17, userMap.sigma_mew, "jawline gains incoming"],
          // Goon Cave
          [18, userMap.gooning_addict, "entered the goon cave 🌙"],
          [18, userMap.npc_streamer, "edge protocol activated"],
          [18, userMap.gooning_addict, "no sleep only goon"],
          // Among Us Lobby
          [19, userMap.sussy_baka, "red sus 📮"],
          [19, userMap.ohio_survivor, "i saw him vent"],
          [19, userMap.sussy_baka, "amogus"],
          // NPC Stream Chat
          [20, userMap.npc_streamer, "ice cream so good 🍦"],
          [20, userMap.npc_streamer, "gang gang gang"],
          [20, userMap.fanum_taxer, "*throws ice cream*"],
          // Bomboclaat Island
          [21, userMap.bomboclaat_king, "BOMBOCLAAT 🌴"],
          [21, userMap.hawk_tuah, "caribbean linkup"],
          [21, userMap.bomboclaat_king, "wagwan bredren"],
          // Diddy Party Room
          [22, userMap.diddy_party, "party at diddy place 🎉"],
          [22, userMap.grimace_shake, "baby oil sale"],
          [22, userMap.diddy_party, "1000 bottles ordered"],
          // Hawk Tuah Saloon
          [23, userMap.hawk_tuah, "hawk tuah 🤠"],
          [23, userMap.rizz_master, "spit on that thang"],
          [23, userMap.hawk_tuah, "you gotta give it that hawk tuah"],
          // Aura Check Station
          [24, userMap.aura_farmer, "checking aura levels ✨"],
          [24, userMap.sigma_mew, "+1000 aura"],
          [24, userMap.mog_maxxer, "-500 aura for asking"],
          // Edge Lord Summit
          [25, userMap.gooning_addict, "no cap fr fr 🧢"],
          [25, userMap.ohio_survivor, "on god no cap"],
          [25, userMap.sussy_baka, "cap detected"]
        ]]
      );
    }

    const [clipCount] = await conn.query("SELECT COUNT(*) AS count FROM clips");
    if (clipCount[0].count === 0) {
      const [userRows] = await conn.query("SELECT id, handle FROM users");
      const userMap = Object.fromEntries(userRows.map((row) => [row.handle, row.id]));
      await conn.query(
        "INSERT INTO clips(user_id, chant, intensity, mood) VALUES ?",
        [[
          [userMap.thung_thung_sahur, "thung thung sahur", 9, "hype"],
          [userMap.trallallero_trallala, "trallallero trallala", 4, "whimsy"],
          [userMap.skibidi_mogger, "skibidi bop bop", 7, "chaos"],
          [userMap.sigma_mew, "sigma grindset", 6, "stoic"],
          [userMap.aura_farmer, "aura harvest", 5, "glow"]
        ]]
      );
    }

    const [sfxCount] = await conn.query("SELECT COUNT(*) AS count FROM sfx");
    if (sfxCount[0].count === 0) {
      await conn.query(
        "INSERT INTO sfx(tag, payload) VALUES ?",
        [[
          ["thung", "thung thung sahur"],
          ["tralla", "trallallero trallala"],
          ["skibidi", "skibidi bop bop"],
          ["sigma", "sigma grindset"],
          ["rizz", "rizz aura"]
        ]]
      );
    }

    const [flagCount] = await conn.query("SELECT COUNT(*) AS count FROM flags");
    if (flagCount[0].count === 0) {
      await conn.query(
        "INSERT INTO flags(flag) VALUES (?)",
        [process.env.FLAG || "flag{brainrot_flag}"]
      );
    } else {
      await conn.query(
        "UPDATE flags SET flag = ? WHERE id = 1",
        [process.env.FLAG || "flag{brainrot_flag}"]
      );
    }

    const [sigilCount] = await conn.query("SELECT COUNT(*) AS count FROM sigil_keys");
    if (sigilCount[0].count === 0) {
      await conn.query(
        "INSERT INTO sigil_keys(secret) VALUES (?)",
        [process.env.SIGIL_SECRET || "sigil-secret-key"]
      );
    }

    console.log("Setup complete");
  } finally {
    await conn.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
