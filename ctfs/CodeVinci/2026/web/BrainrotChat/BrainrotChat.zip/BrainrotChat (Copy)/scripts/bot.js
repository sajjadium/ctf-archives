const targetUrl = process.argv[2] || process.env.BOT_URL || "http://localhost:3000/admin";

import("../lib/bot.js")
  .then(({ runBot }) => runBot(targetUrl))
  .then(() => {
    console.log("Bot finished");
  })
  .catch((err) => {
    console.error("Bot error", err);
    process.exit(1);
  });
