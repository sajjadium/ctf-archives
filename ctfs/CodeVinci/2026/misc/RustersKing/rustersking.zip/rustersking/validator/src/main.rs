use syn::{visit::Visit, Expr, Item, LitStr, Macro, Path, Token};
use proc_macro2::{TokenStream, TokenTree};
use std::env;
use std::fs;
use std::process;


struct SecurityGuard {
    found_violation: bool,
}

impl SecurityGuard {
    fn new() -> Self {
        Self { found_violation: false }
    }

    fn check_text(&mut self, text: &str, context: &str) {
        let blacklist = vec![
            "std", "core", "fs", "File", "OpenOptions", "process", "Command",
            "libc", "nix", "winapi",
            "system", "exec", "spawn", "popen",
            "open", "read", "write", "creat",
            "flag", "cat", "sh", "bin"
        ];
        for bad in blacklist {
            if text.contains(bad) {
                println!("not today");
                self.found_violation = true;
            }
        }
    }

    fn scan_tokens(&mut self, tokens: TokenStream) {
        for token in tokens {
            match token {
                TokenTree::Group(g) => self.scan_tokens(g.stream()),
                TokenTree::Ident(i) => self.check_text(&i.to_string(), "Macro Ident"),
                TokenTree::Literal(l) => self.check_text(&l.to_string(), "Macro Lit"),
                _ => {}
            }
        }
    }
}

impl<'ast> Visit<'ast> for SecurityGuard {
    fn visit_ident(&mut self, i: &'ast syn::Ident) {
        self.check_text(&i.to_string(), "Ident");
    }

    fn visit_path(&mut self, i: &'ast Path) {
        for segment in &i.segments {
            self.check_text(&segment.ident.to_string(), "Path");
        }
        syn::visit::visit_path(self, i);
    }

    fn visit_lit_str(&mut self, i: &'ast LitStr) {
        self.check_text(&i.value(), "String Literal");
        syn::visit::visit_lit_str(self, i);
    }

    fn visit_macro(&mut self, i: &'ast Macro) {
        if i.path.is_ident("asm") || i.path.is_ident("global_asm") {
             println!("not today");
             self.found_violation = true;
        }
        self.scan_tokens(i.tokens.clone());
        syn::visit::visit_macro(self, i);
    }
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() < 2 { process::exit(1); }

    let code = fs::read_to_string(&args[1]).unwrap();
    let syntax_tree = syn::parse_file(&code).expect("Syntax Error");

    let mut guard = SecurityGuard::new();
    guard.visit_file(&syntax_tree);

    if guard.found_violation {
        println!("Access Denied. The kitchen is safe...");
        process::exit(1);
    } else {
        println!("Welcome to the kitchen!");
    }
}