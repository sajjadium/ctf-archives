#!/usr/bin/env python3
import os
import subprocess
import sys

USER_PROJECT_DIR = "/home/ctf/project"
VALIDATOR_BIN = "/usr/local/bin/validator"
SOURCE_FILE = os.path.join(USER_PROJECT_DIR, "src/main.rs")
try:
    RUN_TIMEOUT_SECONDS = int(os.environ.get("RUN_TIMEOUT_SECONDS", "7") or 7)
except ValueError:
    RUN_TIMEOUT_SECONDS = 7
if RUN_TIMEOUT_SECONDS <= 0:
    RUN_TIMEOUT_SECONDS = 7

try:
    MAX_CODE_BYTES = int(os.environ.get("MAX_CODE_BYTES", "0") or 0)
except ValueError:
    MAX_CODE_BYTES = 0
if MAX_CODE_BYTES < 0:
    MAX_CODE_BYTES = 0

def main():


    print("""
██████╗░██╗░░░██╗░██████╗████████╗███████╗██████╗░░██████╗██╗░░██╗██╗███╗░░██╗░██████╗░
██╔══██╗██║░░░██║██╔════╝╚══██╔══╝██╔════╝██╔══██╗██╔════╝██║░██╔╝██║████╗░██║██╔════╝░
██████╔╝██║░░░██║╚█████╗░░░░██║░░░█████╗░░██████╔╝╚█████╗░█████═╝░██║██╔██╗██║██║░░██╗░
██╔══██╗██║░░░██║░╚═══██╗░░░██║░░░██╔══╝░░██╔══██╗░╚═══██╗██╔═██╗░██║██║╚████║██║░░╚██╗
██║░░██║╚██████╔╝██████╔╝░░░██║░░░███████╗██║░░██║██████╔╝██║░╚██╗██║██║░╚███║╚██████╔╝
╚═╝░░╚═╝░╚═════╝░╚═════╝░░░░╚═╝░░░╚══════╝╚═╝░░╚═╝╚═════╝░╚═╝░░╚═╝╚═╝╚═╝░░╚══╝░╚═════╝░""")
    print("-" * 40)

    print("Enter your Rust payload in BASE64 (paste and press Enter):")
    sys.stdout.flush()

    import base64
    try:
        b64_payload = input().strip()
    except EOFError:
        print("No input received.")
        sys.exit(1)

    try:
        code = base64.b64decode(b64_payload).decode("utf-8")
    except Exception as e:
        print(f"Base64 decode error: {e}")
        sys.exit(1)

    if not os.path.exists(os.path.dirname(SOURCE_FILE)):
        os.makedirs(os.path.dirname(SOURCE_FILE))
    if MAX_CODE_BYTES and len(code.encode("utf-8")) > MAX_CODE_BYTES:
        print(f"Payload too large (max {MAX_CODE_BYTES} bytes).")
        sys.exit(1)
    with open(SOURCE_FILE, "w") as f:
        f.write(code)

    print("Validating your code...")
    sys.stdout.flush()
    val_proc = subprocess.run(
        [VALIDATOR_BIN, SOURCE_FILE],
        capture_output=True,
        text=True
    )
    if val_proc.returncode != 0:
        print(val_proc.stdout)
        print("Your code was blocked by the Government.")
        sys.exit(1)
    print(val_proc.stdout)
    print("Compiling and running your recipe...")
    sys.stdout.flush()
    try:
        run_proc = subprocess.run(
            ["cargo", "run", "--quiet", "--release"],
            cwd=USER_PROJECT_DIR,
            capture_output=True,
            text=True,
            timeout=RUN_TIMEOUT_SECONDS
        )
        print("--- STDOUT ---")
        print(run_proc.stdout)
        if run_proc.stderr:
            # yeah I think its not necessary :)
            #print("--- STDERR ---")
            # print(run_proc.stderr)
            pass
    except subprocess.TimeoutExpired:
        print("Your recipe took too long to cook.")

if __name__ == "__main__":
    main()