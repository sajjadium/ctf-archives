function getChildElement(name) {
    if (this.getProperty && this.getProperty(name)) {
        var prop = new Property();
        prop.obj = this;
        prop.name = name;
        return prop;
    }
    return this.get(name);
}

function navbarPath_macro() {
    var html = "";
    for (var node = this; node; node = node._parent) {
        if (node._prototype == "Category" || node._prototype == "Video") {
            if (html) {
                html = "<li class='navbarSpacer'>/</li>" + html; 
            }
            html = "<li><a href=" + node.href() + ">" + node.name + "</a></li>" + html;
        }
    }
    return html;
}