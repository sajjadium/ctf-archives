function getElementName() {
    return this.name;
}

function getProperty(name) {
    if (name == "category") {
        return this._parent;
    } else {
        return this[name];
    }
}

function setProperty(name, value) {
    if (name == "category") {
        if (typeof value == "string") {
            value = nodeByHref(value);
        }
        if (value) {
            this._parent.removeChild(this);
            value.add(this);
            this.persist();
        }
    } else {
        this[name] = value;
    }
}