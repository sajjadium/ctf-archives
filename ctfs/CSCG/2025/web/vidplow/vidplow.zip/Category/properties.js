function getElementName() {
    return this.name;
}

function fullName() {
    if (this._parent._prototype == "Category") {
        return this._parent.fullName() + "/" + this.name;
    } else {
        return this.name;
    }
}

function fullName_macro() {
    return this.fullName();
}

function getProperty(name) {
    if (name == "name") {
        return this.name;
    } else if (name == "description") {
        return this.description;
    } else if (name == "parent") {
        return this._parent;
    } else {
        return null;
    }
}

function setProperty(name, value) {
    if (name == "name") {
        this.name = value;
    } else if (name == "description") {
        this.description = value;
    } else if (name == "parent") {
        if (typeof value == "string") {
            value = nodeByHref(value);
        }
        if (value) {
            this._parent.removeChild(this);
            value.add(this);
            this.persist();
        }
    }
}