function checkAccessKey(key) {
    if (key == global.getProperty("accessKey")) {
        return true;
    } else {
        res.reset();
        res.status = 401;
        res.write("Invalid access key");
        return false;
    }
}

function nodeByHref(href) {
    var node = root;
    var path = href.split("/");
    for (var seg in path) {
        if (path[seg].length > 0) {
            node = node.get(path[seg]);
            if (!node) {
                return null;
            }
        }
    }
    return node;
}