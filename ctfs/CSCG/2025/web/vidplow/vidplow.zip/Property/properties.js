function getProperty(name) {
    var prop = this.obj.getProperty(this.name);
    if (prop && prop.getProperty) {
        return prop.getProperty(name);
    } else {
        return null;
    }
}

function setProperty(name, val) {
    var prop = this.obj.getProperty(this.name);
    if (prop && prop.setProperty) {
        prop.setProperty(name, val);
    }
}

function objLink_macro() {
    return this.obj.href();
}