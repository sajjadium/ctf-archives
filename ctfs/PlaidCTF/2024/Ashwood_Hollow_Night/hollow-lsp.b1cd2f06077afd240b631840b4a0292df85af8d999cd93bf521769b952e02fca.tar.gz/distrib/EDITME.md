  ___      _                            _   _   _       _ _                      _   _ _       _     _   
 / _ \    | |                          | | | | | |     | | |                    | \ | (_)     | |   | |  
/ /_\ \___| |____      _____   ___   __| | | |_| | ___ | | | _____      ________|  \| |_  __ _| |__ | |_ 
|  _  / __| '_ \ \ /\ / / _ \ / _ \ / _` | |  _  |/ _ \| | |/ _ \ \ /\ / /______| . ` | |/ _` | '_ \| __|
| | | \__ \ | | \ V  V / (_) | (_) | (_| | | | | | (_) | | | (_) \ V  V /       | |\  | | (_| | | | | |_ 
\_| |_/___/_| |_|\_/\_/ \___/ \___/ \__,_| \_| |_/\___/|_|_|\___/ \_/\_/        \_| \_/_|\__, |_| |_|\__|
                                                                                          __/ |          
                                                                                         |___/           

Welcome to your text editor!

LSP Servers have made editing your code easier, faster, spookier(?)

LSPs, such as hollow-lsp provide incredible features that you will discover in this challenge.

If you want the flag, all you need to do is not quit Neovim.

What? You don't use this editor? The city rules dictate that your LSP might not work with inferior editors.

On eclipse nights, the LSP is said to be buffed, idk what that means. Maybe it does some magical things?

A hollow-nighter claims: Pressing `K` should help you get out of this town.

Try to express your feelings.
