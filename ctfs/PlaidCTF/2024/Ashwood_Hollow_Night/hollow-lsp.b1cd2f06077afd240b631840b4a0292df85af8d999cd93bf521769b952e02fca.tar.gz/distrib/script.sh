#!/bin/sh
nvim -c "source nvim.lua" EDITME.md
