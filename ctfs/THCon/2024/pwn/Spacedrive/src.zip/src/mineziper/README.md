# mineziper 💣
### A Minesweeper for zip files!

Detect zip bombs based on overlapping files.
