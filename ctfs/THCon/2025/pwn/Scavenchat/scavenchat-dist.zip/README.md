# Note to players

## Setting up a debugging environment

The most reliable way to debug your exploit is to run the provided docker container.

Run the docker container

```shell
docker build -t scavenchat .
docker run --name scavenchat --privileged -p1337:1337 -p1234:1234 -it --rm scavenchat
```

Launch gdbserver on the docker container:

```shell
$ docker exec -u0 -it scavenchat /bin/bash
# gdbserver --attach :1234 $(pidof scavenchat)
```

Attach gdb (on your host) to the gdbserver:
```
$ gdb -ex "target remote :1234"
```

## Use the provided libraries

If you still prefer to debug your exploit locally, you can patch the provided binary.

```shell
cp scavenchat scavenchat-patched
patchelf --set-rpath . --set-interpreter ./ld-linux-x86-64.so.2 scavenchat-patched
```
