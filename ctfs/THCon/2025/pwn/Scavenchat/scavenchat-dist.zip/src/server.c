#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>

#include "server.h"
#include "scavenchat.h"

static void handle_client(int clifd)
{
    context_t current_context = {
        .username = { 0 },
        .channel = { 0 },
        .sockfd = clifd,
    };

    pthread_setspecific(current_context_key, &current_context);

    banner();

    handle_commands();

    close(clifd);
}

static void spawn_client_thread(int clifd)
{
    pthread_t tid;
    pthread_create(&tid, NULL, (void *)handle_client, (void *)(intptr_t)clifd);
    pthread_detach(tid);
}

static int setup_server(void)
{
    int sockfd;
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("socket");
        return -1;
    }

    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &(int){ 1 }, sizeof(int));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(SERVER_PORT);

    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) == -1) {
        perror("bind");
        close(sockfd);
        return -1;
    }

    if (listen(sockfd, 10) == -1) {
        perror("listen");
        close(sockfd);
        return -1;
    }
    printf("Server listening on port %d\n", SERVER_PORT);
    return sockfd;
}

void stop_server(void)
{
    printf("\nStopping server...\n");
    
    static int srvfd;

    close(srvfd);
    sqlite3_close(db);
    exit(0);
}

bool start_server(void)
{
    static int srvfd;

    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    srvfd = setup_server();
    if (srvfd == -1) {
        return false;
    }

    signal(SIGINT, (__sighandler_t)stop_server);
    signal(SIGTERM, (__sighandler_t)stop_server);
    signal(SIGKILL, (__sighandler_t)stop_server);
    signal(SIGSEGV, (__sighandler_t)stop_server);

    pthread_key_create(&current_context_key, NULL);

    printf("Waiting for connections...\n");

    while (1) {
        struct sockaddr_in cliaddr;
        socklen_t clilen = sizeof(cliaddr);

        int connfd = accept(srvfd, (struct sockaddr *)&cliaddr, &clilen);
        if (connfd == -1) {
            perror("accept");
            continue;
        }

        spawn_client_thread(connfd);
    }

    return true;
}
