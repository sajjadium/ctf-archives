#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "b64.h"

static const char base64_table[] =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789+/";

static const unsigned char base64_dec_table[256] = {
    [0 ... 255] = 0x80, // mark all as invalid initially
    ['A'] = 0,  ['B'] = 1,  ['C'] = 2,  ['D'] = 3,
    ['E'] = 4,  ['F'] = 5,  ['G'] = 6,  ['H'] = 7,
    ['I'] = 8,  ['J'] = 9,  ['K'] = 10, ['L'] = 11,
    ['M'] = 12, ['N'] = 13, ['O'] = 14, ['P'] = 15,
    ['Q'] = 16, ['R'] = 17, ['S'] = 18, ['T'] = 19,
    ['U'] = 20, ['V'] = 21, ['W'] = 22, ['X'] = 23,
    ['Y'] = 24, ['Z'] = 25,
    ['a'] = 26, ['b'] = 27, ['c'] = 28, ['d'] = 29,
    ['e'] = 30, ['f'] = 31, ['g'] = 32, ['h'] = 33,
    ['i'] = 34, ['j'] = 35, ['k'] = 36, ['l'] = 37,
    ['m'] = 38, ['n'] = 39, ['o'] = 40, ['p'] = 41,
    ['q'] = 42, ['r'] = 43, ['s'] = 44, ['t'] = 45,
    ['u'] = 46, ['v'] = 47, ['w'] = 48, ['x'] = 49,
    ['y'] = 50, ['z'] = 51,
    ['0'] = 52, ['1'] = 53, ['2'] = 54, ['3'] = 55,
    ['4'] = 56, ['5'] = 57, ['6'] = 58, ['7'] = 59,
    ['8'] = 60, ['9'] = 61,
    ['+'] = 62, ['/'] = 63,
    ['='] = 0   // padding
};
    
void base64_encode(char *plain, int plain_len, char *encoded) {
    int i = 0, j = 0;
    unsigned char byte_array_3[3];
    unsigned char byte_array_4[4];

    while (plain_len--) {
        byte_array_3[i++] = *(plain++);
        if (i == 3) {
            byte_array_4[0] = (byte_array_3[0] & 0xfc) >> 2;
            byte_array_4[1] = ((byte_array_3[0] & 0x03) << 4) + ((byte_array_3[1] & 0xf0) >> 4);
            byte_array_4[2] = ((byte_array_3[1] & 0x0f) << 2) + ((byte_array_3[2] & 0xc0) >> 6);
            byte_array_4[3] = byte_array_3[2] & 0x3f;

            for (i = 0; i < 4; i++) {
                encoded[j++] = base64_table[byte_array_4[i]];
            }
            i = 0;
        }
    }

    if (i > 0) {
        for (int k = i; k < 3; k++) {
            byte_array_3[k] = 0;
        }

        byte_array_4[0] = (byte_array_3[0] & 0xfc) >> 2;
        byte_array_4[1] = ((byte_array_3[0] & 0x03) << 4) + ((byte_array_3[1] & 0xf0) >> 4);
        byte_array_4[2] = ((byte_array_3[1] & 0x0f) << 2) + ((byte_array_3[2] & 0xc0) >> 6);
        byte_array_4[3] = byte_array_3[2] & 0x3f;

        for (int k = 0; k < i + 1; k++) {
            encoded[j++] = base64_table[byte_array_4[k]];
        }

        while (i++ < 3) {
            encoded[j++] = '=';
        }
    }

    encoded[j] = 0;
}

void base64_decode(char *encoded, int encoded_len, char *decoded) {
    int i = 0, j = 0;
    unsigned char byte_array_4[4], byte_array_3[3];

    while (encoded_len-- && (*encoded != '=')) {
        unsigned char c = (unsigned char)*encoded++;
        if (base64_dec_table[c] == 0x80) {
            continue;
        }

        byte_array_4[i++] = base64_dec_table[c];
        if (i == 4) {
            byte_array_3[0] = (byte_array_4[0] << 2) | ((byte_array_4[1] & 0x30) >> 4);
            byte_array_3[1] = ((byte_array_4[1] & 0x0F) << 4) | ((byte_array_4[2] & 0x3C) >> 2);
            byte_array_3[2] = ((byte_array_4[2] & 0x03) << 6) | byte_array_4[3];

            for (i = 0; i < 3; i++) {
                decoded[j++] = byte_array_3[i];
            }
            i = 0;
        }
    }

    if (i) {
        for (int k = i; k < 4; k++) {
            byte_array_4[k] = 0;
        }

        byte_array_3[0] = (byte_array_4[0] << 2) | ((byte_array_4[1] & 0x30) >> 4);
        byte_array_3[1] = ((byte_array_4[1] & 0x0F) << 4) | ((byte_array_4[2] & 0x3C) >> 2);
        byte_array_3[2] = ((byte_array_4[2] & 0x03) << 6) | byte_array_4[3];

        for (int k = 0; k < i - 1; k++) {
            decoded[j++] = byte_array_3[k];
        }
    }

    decoded[j] = 0;
}
