#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <malloc.h>

#include "scavenchat.h"
#include "commands.h"
#include "server.h"

#define DEFAULT_DB_PATH "db/scavenchat.db"

sqlite3 *db = NULL;
bool should_quit = false;
pthread_key_t current_context_key;

context_t *get_context(void)
{
    return pthread_getspecific(current_context_key);
}

char *get_current_user(void)
{
    return get_context()->username;
}

char *get_current_channel(void)
{
    return get_context()->channel;
}

state_t get_state(void)
{
    context_t *current_context = get_context();
    if (current_context->username[0] == 0) return LOGGED_OUT;
    if (current_context->channel[0] == 0) return LOGGED_IN;
    return IN_CHANNEL;
}

int get_current_user_id(void)
{
    sqlite3_stmt *stmt;

    if (sqlite3_prepare_v2(db, "SELECT id FROM users WHERE username = ?", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    sqlite3_bind_text(stmt, 1, get_current_user(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_ROW) {
        client_send("Failed to execute statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    int user_id = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);

    return user_id;
}

int get_current_channel_id(void)
{
    sqlite3_stmt *stmt;

    if (sqlite3_prepare_v2(db, "SELECT id FROM channels WHERE name = ?", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    sqlite3_bind_text(stmt, 1, get_current_channel(), -1, SQLITE_STATIC);
    if (sqlite3_step(stmt) != SQLITE_ROW) {
        client_send("Failed to execute statement: %s\n", sqlite3_errmsg(db));
        return -1;
    }

    int channel_id = sqlite3_column_int(stmt, 0);
    sqlite3_finalize(stmt);

    return channel_id;
}

void send_message(char *message)
{
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "INSERT INTO messages (user_id, channel_id, content) VALUES (?, ?, ?)", -1, &stmt, NULL) != SQLITE_OK) {
        printf("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    int user_id = get_current_user_id();
    int channel_id = get_current_channel_id();

    sqlite3_bind_int(stmt, 1, user_id);
    sqlite3_bind_int(stmt, 2, channel_id);
    sqlite3_bind_text(stmt, 3, message, -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_DONE) {
        client_send("Failed to execute statement: %s\n", sqlite3_errmsg(db));
        return;
    }
    sqlite3_finalize(stmt);

    client_send("<%s> %s\n", get_current_user(), message);
}

static void show_prompt(void)
{
    switch (get_state()) {
        case LOGGED_OUT: client_send("> "); break;
        case LOGGED_IN: client_send("<%s> ", get_current_user()); break;
        case IN_CHANNEL: client_send("[%s] <%s> ", get_current_channel(), get_current_user()); break;
    }
}

void banner(void)
{
    client_send("==============================================================================================\n\n");
    client_send("    ██████  ▄████▄   ▄▄▄    ██▒   █▓▓█████  ███▄    █  ▄████▄   ██░ ██  ▄▄▄     ▄▄▄█████▓     \n");
    client_send("    ▒██    ▒ ▒██▀ ▀█  ▒████▄ ▓██░   █▒▓█   ▀  ██ ▀█   █ ▒██▀ ▀█  ▓██░ ██▒▒████▄   ▓  ██▒ ▓▒   \n");
    client_send("    ░ ▓██▄   ▒▓█    ▄ ▒██  ▀█▄▓██  █▒░▒███   ▓██  ▀█ ██▒▒▓█    ▄ ▒██▀▀██░▒██  ▀█▄ ▒ ▓██░ ▒░   \n");
    client_send("      ▒   ██▒▒▓▓▄ ▄██▒░██▄▄▄▄██▒██ █░░▒▓█  ▄ ▓██▒  ▐▌██▒▒▓▓▄ ▄██▒░▓█ ░██ ░██▄▄▄▄██░ ▓██▓ ░    \n");
    client_send("    ▒██████▒▒▒ ▓███▀ ░ ▓█   ▓██▒▒▀█░  ░▒████▒▒██░   ▓██░▒ ▓███▀ ░░▓█▒░██▓ ▓█   ▓██▒ ▒██▒ ░    \n");
    client_send("    ▒ ▒▓▒ ▒ ░░ ░▒ ▒  ░ ▒▒   ▓▒█░░ ▐░  ░░ ▒░ ░░ ▒░   ▒ ▒ ░ ░▒ ▒  ░ ▒ ░░▒░▒ ▒▒   ▓▒█░ ▒ ░░      \n");
    client_send("    ░ ░▒  ░ ░  ░  ▒     ▒   ▒▒ ░░ ░░   ░ ░  ░░ ░░   ░ ▒░  ░  ▒    ▒ ░▒░ ░  ▒   ▒▒ ░   ░       \n");
    client_send("    ░  ░  ░  ░          ░   ▒     ░░     ░      ░   ░ ░ ░         ░  ░░ ░  ░   ▒    ░         \n");
    client_send("          ░  ░ ░            ░  ░   ░     ░  ░         ░ ░ ░       ░  ░  ░      ░  ░           \n");
    client_send("             ░                    ░                     ░                                     \n");
    client_send("\n==============================================================================================\n");                                                                                                                                                                        
}

void handle_commands(void)
{
    char cmd_buffer[512] = { 0 };

    while (!should_quit) {
        show_prompt();

        size_t cmd_len;
        if ((cmd_len = read(get_context()->sockfd, cmd_buffer, sizeof(cmd_buffer))) <= 0) {
            break;
        }

        cmd_buffer[cmd_len - 1] = 0;

        if (cmd_buffer[0] == '/') {
            // Handle command
            char *cmd_name = cmd_buffer + 1;
            char *args = strchr(cmd_name, ' ');
            if (args != NULL) {
                *args++ = 0;
            }

            bool found = false;
            for (size_t i = 0; i < num_commands; i++) {
                if (strcmp(commands[i].name, cmd_name) == 0) {
                    if (commands[i].required_state == ALWAYS || commands[i].required_state == get_state()) {
                        commands[i].handler(args);
                        found = true;
                        break;
                    }
                }
            }

            if (!found) {
                client_send("Unknown command \"%s\", type /help for available commands\n", cmd_name);
            }
        } else {
            // Handle regular message
            switch (get_state()) {
                case LOGGED_OUT:
                client_send("You are not logged in, type /login to login\n");
                    break;
                case LOGGED_IN:
                client_send("You are not in a channel, type /join to join a channel\n");
                    break;
                case IN_CHANNEL:
                    send_message(cmd_buffer);
                    break;
            }
        }
    }
}

static bool open_database(void)
{
    sqlite3_config(SQLITE_CONFIG_MULTITHREAD, 1);

    int rc = sqlite3_open(DEFAULT_DB_PATH, &db);
    if (rc != SQLITE_OK) {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return false;
    }
    return true;
}

static void close_database(void)
{
    sqlite3_close(db);
}

static void __attribute__((constructor)) init(void)
{
    mallopt(M_ARENA_MAX, 1);
}

int main(int argc, char *argv[]) {
    if (!open_database()) {
        return 1;
    }

    start_server();

    stop_server();

    return 0;
}
