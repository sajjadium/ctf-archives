/* Create the database */

CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
);

CREATE TABLE messages (
    id INTEGER PRIMARY KEY,
    user_id INTEGER NOT NULL,
    channel_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users (id)
    FOREIGN KEY (channel_id) REFERENCES channels (id)
);

CREATE TABLE channels (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    access_key TEXT NULL,
    topic TEXT NULL
);

INSERT INTO users (username, password) VALUES ('butch3r', '------------REDACTED------------');
INSERT INTO users (username, password) VALUES ('cryp7', '------------REDACTED------------');
INSERT INTO users (username, password) VALUES ('j3st3r', '------------REDACTED------------');
INSERT INTO users (username, password) VALUES ('sh4d0w', '------------REDACTED------------');
INSERT INTO users (username, password) VALUES ('test', 'test');

INSERT INTO channels (name, access_key, topic) VALUES ('main', '------------REDACTED------------', 'XSS main discussions');
INSERT INTO channels (name, access_key, topic) VALUES ('attacks', '------------REDACTED------------', 'Attack planning and coordination');
INSERT INTO channels (name, access_key, topic) VALUES ('exploits', '------------REDACTED------------', 'Exploit development and sharing');
INSERT INTO channels (name, access_key, topic) VALUES ('memes', '------------REDACTED------------', 'lulz');
INSERT INTO channels (name, access_key, topic) VALUES ('dev', NULL, 'Channel for developers to discuss the project');

INSERT INTO messages(user_id, channel_id, content) VALUES (2, 5, "I'm working on new commands (encode / decode) to hide our communications more efficiently. I'll let you informed.");

INSERT INTO messages(user_id, channel_id, content) VALUES (1, 1, "The next operation will arrive soon. Get ready!");
INSERT INTO messages(user_id, channel_id, content) VALUES (1, 1, "Make sure to keep the codename secret: THC{---------------REDACTED--------------}");
