#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

#include <sqlite3.h>

#include "scavenchat.h"
#include "b64.h"
#include "commands.h"

const command_t commands[] = {
    { "help" , help, ALWAYS },
    { "quit", quit, ALWAYS },
    { "login", login, LOGGED_OUT },
    { "logout", logout, LOGGED_IN },
    { "join", join, LOGGED_IN },
    { "list", list, LOGGED_IN },
    { "pull", pull, IN_CHANNEL },
    { "leave", leave, IN_CHANNEL },
    { "encode", encode, IN_CHANNEL },
    { "decode", decode, IN_CHANNEL },
};

const size_t num_commands = sizeof(commands) / sizeof(*commands);

void help(char *args)
{
    client_send("Available commands:\n");
    for (size_t i = 0; i < num_commands; i++) {
        if (commands[i].required_state != ALWAYS 
            && commands[i].required_state != get_state()) 
            continue;

        client_send("- %s\n", commands[i].name);
    }
}

void login(char *args)
{
    if (args == NULL) {
        client_send("Usage: /login <username> <password>\n");
        return;
    }

    char *username = args;
    char *password = strchr(args, ' ');
    if (!password) {
        client_send("Usage: /login <username> <password>\n");
        return;
    }

    *password++ = 0;

    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "SELECT username FROM users WHERE username = ? AND password = ?", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    sqlite3_bind_text(stmt, 1, username, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, password, -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_ROW) {
        client_send("Invalid username or password\n");
        sqlite3_finalize(stmt);
        return;
    }

    strncpy(get_context()->username, (char *) sqlite3_column_text(stmt, 0), USERNAME_MAX_LEN);
    sqlite3_finalize(stmt);
}

void logout(char *args)
{
    memset(get_context()->username, 0, sizeof(get_context()->username));
}

void join(char *args)
{
    if (args == NULL) {
        client_send("Usage: /join <channel>\n");
        return;
    }

    char *target_channel = args;

    // Check if channel is protected
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "SELECT name, access_key IS NOT NULL as protected FROM channels WHERE name = ?", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    sqlite3_bind_text(stmt, 1, target_channel, -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_ROW) {
        client_send("Channel does not exist\n");
        sqlite3_finalize(stmt);
        return;
    }

    char *channel_name = (char *) sqlite3_column_text(stmt, 0);
    bool protected = sqlite3_column_int(stmt, 1);

    if (!protected) {
        strncpy(get_context()->channel, channel_name, CHANNEL_MAX_LEN);
        sqlite3_finalize(stmt);
        pull(NULL);
        return;
    }

    sqlite3_finalize(stmt);

    char *query = strdup("SELECT name FROM channels WHERE name = ? AND access_key = ?");

    client_send("Channel is protected, please provide an access key: ");
    char access_key[ACCESS_KEY_MAX_LEN];
    size_t access_key_len = 0;
    
    access_key_len = read(get_context()->sockfd, access_key, sizeof(access_key));
    if (access_key_len <= 0) {
        client_send("Failed to read access key\n");
        return;
    }

    access_key[access_key_len - 1] = '\0';

    if (sqlite3_prepare_v2(db, query, -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    sqlite3_bind_text(stmt, 1, target_channel, -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, access_key, -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) != SQLITE_ROW) {
        client_send("Invalid access key\n");
        sqlite3_finalize(stmt);
        return;
    }

    channel_name = (char *) sqlite3_column_text(stmt, 0);

    strncpy(get_context()->channel, channel_name, CHANNEL_MAX_LEN);
    sqlite3_finalize(stmt);        

    pull(NULL);
}

void pull(char *args)
{
    int channel_id = get_current_channel_id();

    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "SELECT users.username, messages.content FROM messages JOIN users ON messages.user_id = users.id WHERE messages.channel_id = ?", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    sqlite3_bind_int(stmt, 1, channel_id);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        const char *username = sqlite3_column_text(stmt, 0);
        const char *content = sqlite3_column_text(stmt, 1);
        client_send("<%s> %s\n", username, content);
    }
    sqlite3_finalize(stmt);
}

void leave(char *args)
{
    memset(get_context()->channel, 0, CHANNEL_MAX_LEN);
}

void list(char *args)
{
    client_send("Available channels:\n");
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(db, "SELECT name, access_key IS NOT NULL as protected, topic FROM channels", -1, &stmt, NULL) != SQLITE_OK) {
        client_send("Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        return;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        const char *name = sqlite3_column_text(stmt, 0);
        int protected = sqlite3_column_int(stmt, 1);
        const char *topic = sqlite3_column_text(stmt, 2);
        client_send("- %s%s: %s\n", name, protected ? " (protected)" : "", topic);
    }

    sqlite3_finalize(stmt);
}

void quit(char *args)
{
    should_quit = true;
}

void encode(char *args)
{
    if (args == NULL) {
        client_send("Usage: /encode <string>\n");
        return;
    }

    char *plain = args;

    int encoded_len = 4 * ((strlen(plain) + 2) / 3);
    char *encoded = malloc(encoded_len + 1);

    base64_encode(plain, strlen(plain), encoded);
    encoded[encoded_len] = 0;
    client_send("%s\n", encoded);

    free(encoded);
}

void decode(char *args)
{
    if (args == NULL) {
        client_send("Usage: /decode <base64_string>\n");
        return;
    }

    char *encoded = args;

    unsigned char encoded_len = strlen(encoded);
    unsigned int decoded_len = encoded_len / 4 * 3;

    char *decoded = malloc(decoded_len);
    base64_decode(encoded, strlen(encoded), decoded);
    client_send("%s\n", decoded);
}
