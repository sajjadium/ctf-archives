#ifndef __SCAVENCHAT_H__
#define __SCAVENCHAT_H__

#include <pthread.h>
#include <stdbool.h>
#include <sqlite3.h>

#define USERNAME_MAX_LEN 0x20
#define CHANNEL_MAX_LEN 0x20
#define ACCESS_KEY_MAX_LEN 0x80

typedef struct context {
    char username[USERNAME_MAX_LEN];
    char channel[CHANNEL_MAX_LEN];
    int sockfd;
} context_t;

typedef enum state {
    ALWAYS,
    LOGGED_OUT,
    LOGGED_IN,
    IN_CHANNEL,
} state_t;

context_t *get_context(void);
char *get_current_user(void);
char *get_current_channel(void);

state_t get_state(void);
int get_current_user_id(void);
int get_current_channel_id(void);

void banner(void);
void handle_commands(void);

#define client_send(format, ...) dprintf(get_context()->sockfd, format, ##__VA_ARGS__)

extern sqlite3 *db;
extern bool should_quit;
extern pthread_key_t current_context_key;

#endif
