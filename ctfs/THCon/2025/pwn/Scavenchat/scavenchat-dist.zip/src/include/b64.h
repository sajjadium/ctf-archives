#ifndef __B64_H__
#define __B64_H__

void base64_encode(char *plain, int plain_len, char *encoded);
void base64_decode(char *encoded, int data_len, char *decoded);

#endif
