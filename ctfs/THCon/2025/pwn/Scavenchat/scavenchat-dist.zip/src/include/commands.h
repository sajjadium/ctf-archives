#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#include <stddef.h>

#include "scavenchat.h"

typedef struct command {
    const char *name;
    void (*handler)(char *args);
    state_t required_state;
} command_t;

void help(char *args);
void login(char *args);
void logout(char *args);
void join(char *args);
void pull(char *args);
void leave(char *args);
void list(char *args);
void quit(char *args);

// Experimental
void encode(char *args);
void decode(char *args);

extern const command_t commands[];
extern const size_t num_commands;

#endif
