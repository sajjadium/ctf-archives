#ifndef __SERVER_H__
#define __SERVER_H__

#include <stdbool.h>

#define SERVER_PORT 1337

void stop_server(void);
bool start_server(void);

#endif
