#!/bin/bash

key_size=32
random_key=$(cat /dev/urandom |head -c ${key_size} |xxd -p -c ${key_size})
export CATALINA_OPTS="$CATALINA_OPTS -Dapp.secret_key='${random_key}'"
