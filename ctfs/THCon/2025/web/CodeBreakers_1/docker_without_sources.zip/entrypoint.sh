#!/bin/sh

user_app="tomcat"
groupadd dockeredit
usermod -a -G dockeredit "$user_app"

chown -R "$user_app":dockeredit /usr/local/tomcat/webapps/app_demo
chmod u+rwx -R /usr/local/tomcat/webapps/app_demo
exec runuser -u "$user_app" "$@"
