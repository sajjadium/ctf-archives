```sh
sudo docker build -t r3ctf-definitely-not-a-web-chal .
sudo docker run --rm -e 'FLAG=r3ctf{local_test_flag}' -p 8082:80 r3ctf-definitely-not-a-web-chal
```
