class VerificationError(Exception):
    pass
