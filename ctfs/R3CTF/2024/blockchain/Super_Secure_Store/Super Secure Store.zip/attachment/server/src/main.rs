use std::env;
use std::io::Write;

use sol_ctf_framework::ChallengeBuilder;

use solana_program::{
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    system_instruction, system_program,
};
use solana_program_test::tokio;
use solana_sdk::{signature::Signer, signer::keypair::Keypair};
use std::error::Error;
use borsh::BorshDeserialize;
use std::net::{TcpListener, TcpStream};

#[derive(borsh::BorshSerialize)]
pub enum StoreInstruction {
    Init { config_bump: u8, item_bump: u8 },
    List { product_id: u8, product_bump: u8 , starting_price: u64},
    Buy { product_id: u8, amount: u64 },
    Withdraw { amount: u64 },
    Secret { product_id: u8, amount: u64 },
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:8080")?;

    println!("starting server at port 8080");

    for stream in listener.incoming() {
        let stream = stream.unwrap();

        tokio::spawn(async {
            if let Err(err) = handle_connection(stream).await {
                println!("error: {:?}", err);
            }
        });
    }
    Ok(())
}

async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    writeln!(socket, "Super Secure Store!")?;

    writeln!(socket, "\nRust Item Store: https://store.steampowered.com/itemstore/252490/\n")?;

    writeln!(socket, "\nProduct 1: Frontier Decor Pack \n\tHOT SALE! 12_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 2: Neon Small Food Storage \n\tHOT SALE! 1_490_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 3: Shipping Container \n\tHOT SALE! 13_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 4: Arctic Pack \n\tHOT SALE! 12_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 5: Brutalist \n\tHOT SALE! 12_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 6: Watcher of Doom Garage Door \n\tHOT SALE! 2_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 7: Black Diamond Thompson \n\tHOT SALE! 2_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 8: Retro Tool Cupboard \n\tHOT SALE! 9_990_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct 9: Nocturnal Beast AR \n\tHOT SALE! 2_490_000_000 Lamport \n")?;
    writeln!(socket, "\nProduct X: Dirt Cheap digital string 1 Lamport \n")?;
    writeln!(socket, "\nProduct -: Nothing to show here \n")?;



    let price_arr = [12_990_000_000, 1_490_000_000, 13_990_000_000, 12_990_000_000, 1, 12_990_000_000, 999_999_999_999, 2_990_000_000, 2_990_000_000, 9_990_000_000, 2_490_000_000];

    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    let program_id = builder.add_program("./store.so", None);
    let solve_id = builder.input_program()?;

    let mut chall = builder.build().await;

    let payer_keypair = &chall.ctx.payer;
    let payer = payer_keypair.pubkey();

    // Creating admin keypair
    let admin_keypair = Keypair::new();
    let admin = admin_keypair.pubkey();

    chall
        .run_ix(system_instruction::transfer(
            &payer,
            &admin,
            100_000_000_000, 
        ))
        .await?;

    // Creating user keypair
    let user_keypair = Keypair::new();
    let user = user_keypair.pubkey();

    chall
        .run_ix(system_instruction::transfer(&payer, &user, 1_000_000_000)) // 1 sol
        .await?;

    writeln!(socket, "program: {}", program_id)?;
    writeln!(socket, "user: {}", user)?;

    let (config_addr, config_bump) =
        Pubkey::find_program_address(&["CONFIG".as_bytes()], &program_id);
    let (item_addr, item_bump) = Pubkey::find_program_address(&["ITEM".as_bytes()], &program_id);

    // Opening the store
    let mut ixs = vec![Instruction::new_with_borsh(
        program_id,
        &StoreInstruction::Init {
            config_bump,
            item_bump,
        },
        vec![
            AccountMeta::new(admin, true),
            AccountMeta::new(config_addr, false),
            AccountMeta::new(item_addr, false),
            AccountMeta::new_readonly(system_program::id(), false),
        ],
    )];

    // Adding products to store
    for i in 1..=11_u8 {

        let (prod_addr, bump) =
            Pubkey::find_program_address(&["PRODUCT".as_bytes(), &i.to_be_bytes()], &program_id);
        ixs.push(Instruction::new_with_borsh(
            program_id,
            &StoreInstruction::List {
                product_id: i as u8,
                product_bump: bump,
                starting_price: price_arr[i as usize -1 ],
            },
            vec![
                AccountMeta::new(admin, true),
                AccountMeta::new(config_addr, false),
                AccountMeta::new(prod_addr, false),
                AccountMeta::new_readonly(system_program::id(), false),
            ],
        ));
    }

    // I want to buy the dirt cheap string first, if you want it, you have to overpay more than me :P
    let (string_addr, _) =
            Pubkey::find_program_address(&["PRODUCT".as_bytes(), &5_u8.to_be_bytes()], &program_id);
    ixs.push(Instruction::new_with_borsh(
        program_id,
        &StoreInstruction::Buy {
            product_id: 5,
            amount: 99_000_000_000, 
        },
        vec![
            AccountMeta::new(admin, true),
            AccountMeta::new(config_addr, false),
            AccountMeta::new(item_addr, false),
            AccountMeta::new(string_addr, false),
            AccountMeta::new_readonly(system_program::id(), false),
        ],
    ));

    // Nothing here
    let (nothing_addr, _) =
    Pubkey::find_program_address(&["PRODUCT".as_bytes(), &7_u8.to_be_bytes()], &program_id);

    chall
        .run_ixs_full(&ixs, &[&admin_keypair], &admin_keypair.pubkey())
        .await?;


    let solve_ix = chall.read_instruction(solve_id)?;
    chall
        .run_ixs_full(&[solve_ix], &[&user_keypair], &user_keypair.pubkey())
        .await?;

    if let Some(account) = chall.ctx.banks_client.get_account(user).await? {
        writeln!(socket, "Lamports after exploit: {:?}", account.lamports)?;

        if account.lamports > 95_000_000_000 {
            if let Some(prod_acc) = chall.ctx.banks_client.get_account(string_addr).await? {
                let product_account = &mut store::processor::Product::deserialize(&mut &(* prod_acc.data)[..])?;
                if product_account.current_owner == user {
                    if let Some(nothing_acc) = chall.ctx.banks_client.get_account(nothing_addr).await? {
                        let nothing_account = &mut store::processor::Product::deserialize(&mut &(* nothing_acc.data)[..])?;
                        if nothing_account.current_owner == user {
                            writeln!(socket, "CONGRATS! You have successfully purchased the dirt cheap digital string!")?;
                            writeln!(
                                socket,
                                "digital string: {}",
                                env::var("FLAG").unwrap_or_else(|_| "flag{test_flag}".to_string())
                            )?;
                        }
                        else {
                            writeln!(socket, "no cigar.")?;
                        }

                    }
                }
                else {
                    writeln!(socket, "Close, but")?;
                }

            }
        }
    } else {
        writeln!(socket, "Try harder!")?;
    }

    Ok(())
}