use borsh::{BorshDeserialize, BorshSerialize};

use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint::ProgramResult,
    program::{invoke, invoke_signed},
    program_error::ProgramError,
    pubkey::Pubkey,
    rent::Rent,
    system_instruction,
};

#[derive(BorshDeserialize, BorshSerialize)]
pub enum StoreInstruction {
    Init { config_bump: u8, item_bump: u8 },
    List { product_id: u8, product_bump: u8 , starting_price: u64},
    Buy { product_id: u8, amount: u64 },
    Withdraw { amount: u64 },
    Secret { product_id: u8, amount: u64 },
}

#[repr(u8)]
#[derive(BorshSerialize, BorshDeserialize, PartialEq)]
pub enum Types {
    Config,
    Product,
    Item,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Config {
    pub category: Types,
    pub admin: Pubkey,
    pub total_balance: u64,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Product {
    pub category: Types,
    pub creator: Pubkey,
    pub balance: u64,
    pub product_id: u8,
    pub current_owner: Pubkey,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Item {
    pub category: Types,
}

pub const CONFIG_SIZE: usize = std::mem::size_of::<Config>();
pub const PRODUCT_SIZE: usize = std::mem::size_of::<Product>();
pub const ITEM_SIZE: usize = std::mem::size_of::<Item>();

pub fn process_instruction(
    program: &Pubkey,
    accounts: &[AccountInfo],
    mut data: &[u8],
) -> ProgramResult {
    match StoreInstruction::deserialize(&mut data)? {
        StoreInstruction::Init {
            config_bump,    
            item_bump,
        } => init(program, accounts, config_bump, item_bump),
        StoreInstruction::List {
            product_id,
            product_bump,
            starting_price,
        } => list(program, accounts, product_id, product_bump, starting_price),
        StoreInstruction::Buy {
            product_id,
            amount,
        } => buy(program, accounts, product_id, amount),
        StoreInstruction::Withdraw { amount } => withdraw(program, accounts, amount),
        StoreInstruction::Secret {
            product_id,
            amount,
        } => secret_shop(program, accounts, product_id, amount),
    }
}

fn init(
    program: &Pubkey,
    accounts: &[AccountInfo],
    config_bump: u8,
    item_bump: u8,
) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let config = next_account_info(account_iter)?;
    let item = next_account_info(account_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    let Ok(config_addr) = Pubkey::create_program_address(&[b"CONFIG", &[config_bump]], &program) else {
        return Err(ProgramError::InvalidSeeds);
    };

    let Ok(item_addr) = Pubkey::create_program_address(&[b"ITEM", &[item_bump]], &program) else {
        return Err(ProgramError::InvalidSeeds);
    };

    if *config.key != config_addr {
        return Err(ProgramError::InvalidAccountData);
    }

    if !config.data_is_empty() {
        return Err(ProgramError::AccountAlreadyInitialized);
    }

    invoke_signed(
        &system_instruction::create_account(
            &user.key,
            &config_addr,
            Rent::minimum_balance(&Rent::default(), CONFIG_SIZE),
            CONFIG_SIZE as u64,
            &program,
        ),
        &[user.clone(), config.clone()],
        &[&[b"CONFIG", &[config_bump]]],
    )?;

    let config_data = Config {
        category: Types::Config,
        admin: *user.key,
        total_balance: 10,
    };

    config_data
        .serialize(&mut &mut (*config.data).borrow_mut()[..])
        .unwrap();

    // create item
    invoke_signed(
        &system_instruction::create_account(
            &user.key,
            &item_addr,
            Rent::minimum_balance(&Rent::default(), ITEM_SIZE),
            ITEM_SIZE as u64,
            &program,
        ),
        &[user.clone(), item.clone()],
        &[&[b"ITEM", &[item_bump]]],
    )?;

    // save item data
    let item_data = Item {
        category: Types::Item,
    };

    item_data
        .serialize(&mut &mut (*item.data).borrow_mut()[..])
        .unwrap();

    Ok(())
}

// create a listing, only allowed by admin
fn list(
    program: &Pubkey,
    accounts: &[AccountInfo],
    product_id: u8,
    product_bump: u8,
    starting_price: u64,
) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let config = next_account_info(account_iter)?;
    let product = next_account_info(account_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    if config.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let config_data = &mut Config::deserialize(&mut &(*config.data).borrow_mut()[..])?;
    if config_data.category != Types::Config {
        return Err(ProgramError::InvalidAccountData);
    }

    if *user.key != config_data.admin {
        return Err(ProgramError::IllegalOwner);
    }

    let Ok(product_addr) = Pubkey::create_program_address(&[b"PRODUCT", &product_id.to_be_bytes(), &[product_bump]], &program) else {
        return Err(ProgramError::InvalidSeeds);
    };

    if *product.key != product_addr {
        return Err(ProgramError::InvalidAccountData);
    }

    if !product.data_is_empty() {
        return Err(ProgramError::AccountAlreadyInitialized);
    }

    // create product
    invoke_signed(
        &system_instruction::create_account(
            &user.key,
            &product_addr,
            Rent::minimum_balance(&Rent::default(), PRODUCT_SIZE),
            PRODUCT_SIZE as u64,
            &program,
        ),
        &[user.clone(), product.clone()],
        &[&[
            "PRODUCT".as_bytes(),
            &product_id.to_be_bytes(),
            &[product_bump],
        ]],
    )?;

    // save product data
    let product_data = Product {
        category: Types::Product,
        creator: *user.key,
        balance: starting_price as u64,
        product_id: product_id,
        current_owner: *user.key,
    };

    product_data
        .serialize(&mut &mut (*product.data).borrow_mut()[..])
        .unwrap();
    config_data.total_balance = config_data.total_balance.checked_add(starting_price as u64).unwrap(); 
    config_data
        .serialize(&mut &mut (*config.data).borrow_mut()[..])
        .unwrap();


    Ok(())
}

fn buy(
    program: &Pubkey,
    accounts: &[AccountInfo],
    product_id: u8,
    lamports: u64,
) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let config = next_account_info(account_iter)?;
    let item = next_account_info(account_iter)?;
    let product = next_account_info(account_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    if config.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let config_data = &mut Config::deserialize(&mut &(*config.data).borrow_mut()[..])?;
    if config_data.category != Types::Config {
        return Err(ProgramError::InvalidAccountData);
    }

    if item.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let item_data = &mut Item::deserialize(&mut &(*item.data).borrow_mut()[..])?;
    if item_data.category != Types::Item {
        return Err(ProgramError::InvalidAccountData);
    }

    if product.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let product_data = &mut Product::deserialize(&mut &(*product.data).borrow_mut()[..])?;
    if product_data.category != Types::Product {
        return Err(ProgramError::InvalidAccountData);
    }

    let (product_addr, _) = Pubkey::find_program_address(
        &["PRODUCT".as_bytes(), &product_id.to_be_bytes()],
        &program,
    );
    if *product.key != product_addr {
        return Err(ProgramError::InvalidAccountData);
    }

    invoke(
        &system_instruction::transfer(&user.key, &item.key, lamports.into()),
        &[user.clone(), item.clone()],
    )?;

    product_data.balance = product_data.balance.checked_add(lamports).unwrap();
    product_data
        .serialize(&mut &mut (*product.data).borrow_mut()[..])
        .unwrap();
    product_data.current_owner = *user.key;
    product_data
        .serialize(&mut &mut (*product.data).borrow_mut()[..])
        .unwrap();

    config_data.total_balance = config_data.total_balance.checked_add(lamports).unwrap() - 1; 
    config_data
        .serialize(&mut &mut (*config.data).borrow_mut()[..])
        .unwrap();


    Ok(())
}
fn withdraw(program: &Pubkey, accounts: &[AccountInfo], lamports: u64) -> ProgramResult {
    // totally secure withdraw
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let config = next_account_info(account_iter)?;
    let item = next_account_info(account_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    if config.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let config_data = &mut Config::deserialize(&mut &(*config.data).borrow_mut()[..])?;
    if config_data.category != Types::Config {
        return Err(ProgramError::InvalidAccountData);
    }

    if config_data.total_balance < lamports {
        return Err(ProgramError::InsufficientFunds);
    }

    if *user.key != config_data.admin {
        return Err(ProgramError::IllegalOwner);
    }

    if item.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let item_data = &mut Item::deserialize(&mut &(*item.data).borrow_mut()[..])?;
    if item_data.category != Types::Item {
        return Err(ProgramError::InvalidAccountData);
    }

    let mut item_lamports = item.lamports.borrow_mut();
    **item_lamports = (**item_lamports).checked_sub(lamports).unwrap();
    let mut user_lamports = user.lamports.borrow_mut();
    **user_lamports = (**user_lamports).checked_add(lamports).unwrap();

    Ok(())
}


fn secret_shop(
    program: &Pubkey,
    accounts: &[AccountInfo],
    product_id: u8,
    lamports: u64,
) -> ProgramResult {
    // Totally safe
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let product = next_account_info(account_iter)?;

    if !user.is_signer {
        return Err(ProgramError::MissingRequiredSignature);
    }

    if product.owner != program {
        return Err(ProgramError::InvalidAccountData);
    }

    let product_data = &mut Product::deserialize(&mut &(*product.data).borrow_mut()[..])?;
    if product_data.category != Types::Product {
        return Err(ProgramError::InvalidAccountData);
    }

    let (product_addr, _) = Pubkey::find_program_address(
        &["PRODUCT".as_bytes(), &product_id.to_be_bytes()],
        &program,
    );
    if *product.key != product_addr {
        return Err(ProgramError::InvalidAccountData);
    }

    unsafe {
        if product_id > 6 {
            let p_acc: *mut Product = product_data;
            (*p_acc).balance = lamports;
        }
    }

    Ok(())
}