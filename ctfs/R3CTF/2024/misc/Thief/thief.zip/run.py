import torch
from torch import nn
import torchvision
import torchvision.transforms as transforms
import torchvision.models as models
import torch.nn.functional as F
import pandas as pd
import random
import os

print("""
   ____           _           _            ____   _               _   _                                     _____   _       _           __ 
  / ___|   __ _  (_)  _ __   ( )  ___     / ___| | |__     __ _  | | | |   ___   _ __     __ _    ___   _  |_   _| | |__   (_)   ___   / _|
 | |      / _` | | | | '_ \  |/  / __|   | |     | '_ \   / _` | | | | |  / _ \ | '_ \   / _` |  / _ \ (_)   | |   | '_ \  | |  / _ \ | |_ 
 | |___  | (_| | | | | | | |     \__ \   | |___  | | | | | (_| | | | | | |  __/ | | | | | (_| | |  __/  _    | |   | | | | | | |  __/ |  _|
  \____|  \__,_| |_| |_| |_|     |___/    \____| |_| |_|  \__,_| |_| |_|  \___| |_| |_|  \__, |  \___| (_)   |_|   |_| |_| |_|  \___| |_|  
                                                                                         |___/                                             
""")
print(r"The model effect of Cain's is always not as good as that of rec.")
print(r"A little bird told me that rec only used a portion of the training set.")
print(r"Can you tell me the data below, which ones are in this model's training set")

train_indices = pd.read_csv('/app/train_indices.csv').iloc[1:, 0].tolist()
all_numbers = list(range(0, 10000))
trained = random.sample(train_indices, 250)
untrained = random.sample(list(set(all_numbers) - set(train_indices)), 250)
num = trained + untrained
random.shuffle(num)

transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
trainset = torchvision.datasets.CIFAR100(root="/app/data", train=False, transform=transform)

rec_model = models.resnet18(weights=None)
rec_model.fc = nn.Linear(in_features=rec_model.fc.in_features, out_features=100)
rec_model.load_state_dict(torch.load(r"/app/rec's model.pth", map_location='cpu'))
rec_model.eval()

score = 0.75 + 0.1
cnt = 0
for idx in num:
    output = rec_model(trainset[idx][0].unsqueeze(0))
    prob = F.softmax(output, dim=1) 
    top_10, _ = torch.topk(prob, 10)

    print(f"idx : {idx}")
    print(f"top_10_pred : {top_10.tolist()}")
    inp = input('Is this picture in the training set?')
    ismember = 1 if idx in train_indices else 0
    if ismember == int(inp):
        cnt+=1

if cnt/len(num) > score:
    print(os.environ.get("GZCTF_FLAG"))
    exit()

print("No No No.You can't be the THEIF!!!")
