import { secp256k1 } from 'ethereum-cryptography/secp256k1';
import { keccak256 } from 'ethereum-cryptography/keccak';
import { toHex } from 'ethereum-cryptography/utils';
import { Contract, Web3 } from 'web3';
import { execFileSync, spawn } from 'child_process';
import { faker } from '@faker-js/faker';
import { compileFile } from './compiler.js';
import path from 'path';
import * as crypto from "crypto";
import * as fs from 'fs';


const gethDataDir = '/geth';
const abiDir = '/abi';
const chainID = '114514';
fs.existsSync(gethDataDir) || fs.mkdirSync(gethDataDir);
fs.existsSync(abiDir) || fs.mkdirSync(abiDir);

interface Account {
    priv: string;
    addr: string;
}

interface ContractInfo {
    name: string;
    address: string;
    abi: any;
    bytecode: string;
}

interface InitInfo {
    chainID: string;
    miner: Account;
    accounts: Account[];
    contracts: ContractInfo[];
}

const importMiner = (): Account => {
    const priv = secp256k1.utils.randomPrivateKey();
    const pub = secp256k1.getPublicKey(priv, false);
    const addr = keccak256(pub.slice(1)).slice(-20);
    const password = crypto.randomBytes(32).toString('hex');

    fs.writeFileSync('priv-key', toHex(priv));
    fs.writeFileSync(path.join(gethDataDir, 'password'), password);

    execFileSync('geth', ['account', 'import', '--datadir', gethDataDir, '--password', path.join(gethDataDir, 'password'), 'priv-key']);

    return { 
        priv: `0x${toHex(priv)}`,
        addr: `0x${toHex(addr)}` 
    };
};

const initGenesis = (miner: Account, n: number): Account[] => {
    const balance = Web3.utils.toWei('100000000', 'ether');
    let accounts: Account[] = [];
    let genesis = JSON.parse(
        fs.readFileSync('genesis.json', 'utf8')
            .replaceAll('${ADDRESS}', miner.addr.slice(2))
            .replaceAll('${CHAIN_ID}', chainID)
    );

    for (let idx = 0; idx < n; idx++) {
        const priv = secp256k1.utils.randomPrivateKey();
        const pub = secp256k1.getPublicKey(priv, false);
        const addr = keccak256(pub.slice(1)).slice(-20);
        genesis.alloc[toHex(addr)] = { balance: balance };
        accounts.push(
            { 
                priv: `0x${toHex(priv)}`,
                addr: `0x${toHex(addr)}` 
            }
        );
    }

    fs.writeFileSync('genesis.json', JSON.stringify(genesis));

    execFileSync('geth', ['init', '--datadir', gethDataDir, 'genesis.json']);

    return accounts;
};

const lauchGeth = (miner: Account) => {
    const minerAddr = miner.addr.slice(2);
    const geth = spawn('geth', [
        '--datadir', gethDataDir,
        '--networkid', chainID,
        '--password', path.join(gethDataDir, 'password'),
        '--allow-insecure-unlock',
        `--unlock=${minerAddr}`,
        `--miner.etherbase=${minerAddr}`,
        '--mine',
        `--http`, '--http.addr=127.0.0.1', '--http.port=8545',
        '--http.api=eth,net,web3',
        '--http.corsdomain=*',
        '--http.vhosts=*',
        '--nodiscover=true',
        '--maxpeers=0',
        '--ws=false',
        '--ipcdisable=true',
        '--discovery.dns=""'
    ]);

    geth.stdout.on('data', (data) => {
        console.log(data.toString());
    });

    geth.stderr.on('data', (data) => {
        console.error(data.toString());
    });

    geth.on('close', (code) => {
        console.log(`geth exited with code ${code}`);
    });

    return geth;
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const gethHealthCheck = async (timeout: number) => {
    await fetch('http://127.0.0.1:8545/', { signal: AbortSignal.timeout(timeout) });
};

const createWeb3 = (accounts: Account[]): Web3 => {
    let web3 = new Web3('http://127.0.0.1:8545/');
    accounts.forEach((account, _) => {
        web3.eth.accounts.wallet.add(account.priv);
    });

    return web3;
}

const deployBlog = async (web3: Web3): Promise<[Contract<any>, string]> => {
    const account = web3.eth.accounts.wallet[0];
    const value = Web3.utils.toWei('0', 'wei');
    const args = [];

    const { abi, bytecode } = compileFile('blog.sol', 'Blog');
    let contract = new web3.eth.Contract(abi);
    let tx = contract.deploy({ data: bytecode, arguments: args });
    let gas = (await tx.estimateGas({ from: account.address, value: value })).toString();
    let deploy_contract = await tx.send({ from: account.address, value: value, gas: gas });
    
    if (!deploy_contract.options.address) {
        throw new Error('Failed to deploy contract');
    }

    return [deploy_contract, bytecode];
}

const initBlog = async (accounts: Account[], blog: Contract<any>, n: number) => {
    const value = Web3.utils.toWei('100', 'finney');

    for (const [idx, account] of accounts.entries()) {
        let username = faker.internet.userName();
        if (idx == 0) {
            username = 'admin';
        }

        await blog.methods.register(username).send({ from: account.addr, value: value });

        for (let i = 0; i < n; i++) {
            await blog.methods.publish(
                faker.lorem.words(5),
                faker.lorem.paragraph({ min: 5, max: 10 }),
            ).send({ from: account.addr, value: value });
        }
    }
}

const init = async () => {
    let info = {} as InitInfo;
    info.chainID = chainID;

    let miner = importMiner();
    info.miner = miner;

    let accounts = initGenesis(miner, 8);
    info.accounts = accounts;

    let geth = lauchGeth(miner);

    await sleep(3000);
    await gethHealthCheck(2000);

    let web3 = createWeb3(accounts);

    let [blog, bytecode] = await deployBlog(web3);
    
    info.contracts = [];
    info.contracts.push({
        name: 'Blog',
        address: blog.options.address || '',
        abi: blog.options.jsonInterface,
        bytecode: bytecode
    });

    await initBlog(accounts, blog, 2);

    geth.kill('SIGINT');

    fs.writeFileSync(path.join(gethDataDir, 'init.json'), JSON.stringify(info));
};

init();

