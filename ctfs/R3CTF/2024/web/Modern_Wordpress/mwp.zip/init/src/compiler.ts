import solc from 'solc';
import path from 'path';
import * as fs from 'fs';

const contractDirectory = 'contracts';

const removeSolcUnhandledRejectionListener = () => {
    const listeners = process.listeners('unhandledRejection')
    if (listeners.length > 0 && listeners[listeners.length - 1].name === 'abort') {
        process.removeListener('unhandledRejection', listeners[listeners.length - 1])
    }
}

const compileContract = (sourceCode: string, contractName: string): { abi: any, bytecode: string } => {
    const input = {
        language: "Solidity",
        sources: {
            main: {
                content: sourceCode
            }
        },
        settings: {
            outputSelection: {
                "*":
                {
                    "*": ["abi", "evm.bytecode"]
                }
            },
            evmVersion: 'istanbul'
        },
    };

    const output = solc.compile(JSON.stringify(input), {
        import: (_path: string) => {
            const filename = path.join(contractDirectory, _path);
            if (!fs.existsSync(filename)) {
                return { error: 'File not found' };
            }
            return { contents: fs.readFileSync(filename, 'utf8') };
        }
    });

    const artifact = JSON.parse(output).contracts.main[contractName];

    return {
        abi: artifact.abi,
        bytecode: artifact.evm.bytecode.object,
    };
}

const compileFile = (filename: string, contractName: string): { abi: any, bytecode: string } => {
    const source = fs.readFileSync(path.join(contractDirectory, filename), 'utf8');
    return compileContract(source, contractName);
}

removeSolcUnhandledRejectionListener();

export { compileFile };