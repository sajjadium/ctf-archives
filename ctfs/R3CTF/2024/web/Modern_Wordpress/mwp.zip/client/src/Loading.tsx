import { Flex } from "./Flex";

const Loading = () => (
    <Flex preset="centered" style={{ flexDirection: "column" }}>
        <h1>Loading...</h1>
    </Flex>
);

export { Loading };