import Web3 from 'web3';
import { Container } from './Container';
import { Layout } from './Layout';
import { useAccount } from './AccountProvider';
import { useBackend } from './BackendProvider';
import { Flex } from './Flex';
import React from 'react';

const Home = () => {
    const { account, balance, username, registered } = useAccount();
    const { blog, version } = useBackend();
    const usernameInputRef = React.createRef<HTMLInputElement>();
    const registerButtonRef = React.createRef<HTMLButtonElement>();

    let userInformation;
   
    if (registered) {
        userInformation = (
            <>
                <p>Username: <strong>{username}</strong></p>
                <p>Address: <strong>{account!.address}</strong></p>
                <p>Balance: <strong>{Web3.utils.fromWei(balance!.toString(), "gwei")} gwei</strong></p>
            </>
        );
    } else {
        userInformation = (
            <>
                <p>Username: <strong>Not Registered</strong></p>
                <p>Address: <strong>{account!.address}</strong></p>
                <p>Balance: <strong>{Web3.utils.fromWei(balance!.toString(), "gwei")} gwei</strong></p>
            </>
        );
    }

    return (
        <Layout>
            <Flex preset="centered" style={{ flexDirection: "column" }}>
                <Container title='Announcement' style={{ width: "100%" }}>
                    <p className="nes-text is-primary">
                        ={'>'} It is not recommended to use this blog for any serious purposes.  <br /><br />
                        ={'>'} The blog is still in development and some features are not implemented yet. 
                    </p>
                </Container>

                <Container title='Backend Information' style={{ width: "100%", marginTop: "40px" }}>
                    <p>Address: <strong>{blog!.options.address}</strong></p>
                    <p>Version: <strong>{version}</strong></p>
                </Container>

                <Container title='User Information' style={{ width: "100%", marginTop: "40px" }}>
                    {userInformation}
                </Container>

                {
                    !registered && (
                        <Container title='Register' style={{ width: "100%", marginTop: "40px" }}>
                            <div className="nes-field">
                                <div>Username</div>
                                <input type="text" ref={usernameInputRef} style={{marginTop: "10px"}} className="nes-input" placeholder="NAME" disabled></input>
                            </div>
                            <button type="submit" ref={registerButtonRef} className="nes-btn is-disabled" style={{marginTop: "20px"}} disabled onClick={() => { }}>Register</button>
                            <div style={{marginTop: "10px", textAlign: "center"}}>  
                                <h4 className="nes-text is-error">Sorry, registration is under maintenance, please contact <a className="nes-text is-error" href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" target="_blank"><b>@crazywoman</b></a> to register. </h4>
                            </div>
                        </Container>
                    )
                }

            </Flex>
        </Layout>
    );
};

export { Home };