import { NavBar } from "./NavBar";
import styles from './Layout.module.scss';
import { Flex } from "./Flex";

interface Props {
    children?: React.ReactNode;
}

const Layout = (props: Props) => {
    return (
        <Flex preset="normal" style={{justifyContent: "center"}}>
            <NavBar />
            <div className={styles.mainContainer}>
                {props.children}
            </div>
        </Flex>
    );
};

export { Layout };