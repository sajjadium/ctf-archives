import React from "react";
import { useBackend } from "./BackendProvider";
import { Container } from "./Container";
import { Flex } from "./Flex";
import { Layout } from "./Layout";
import { Loading } from "./Loading";
import { useWeb3 } from "./Web3Provider";
import { Crash } from "./Crash";
import styles from './Explore.module.scss';
import { classNames } from "./util";
import { useNavigate } from "react-router-dom";

interface User {
    username: string;
    address: string;
    balance: bigint;
}

const Explore = () => {
    const { web3 } = useWeb3();
    const { blog } = useBackend();
    const [userCount, setUserCount] = React.useState<bigint>(BigInt(0));
    const [userList, setUserList] = React.useState<User[]>([]);
    const [error, setError] = React.useState<string | undefined>(undefined);
    const [loading, setLoading] = React.useState<boolean>(true);
    const navigate = useNavigate();

    React.useEffect(() => {
        if (blog === undefined) {
            return;
        }

        setLoading(true);
        blog.methods.getUserNameCount().call().then((result: any) => {
            setUserCount(BigInt(result));
            setLoading(false);
        }).catch(() => {
            setLoading(false);
        });
    }, [blog]);

    React.useEffect(() => {
        const fetchUsers = async () => {
            if (blog === undefined) {
                return;
            }
    
            setLoading(true);
            let _userLists: User[] = [];
    
            for (let idx = BigInt(0); idx < userCount; idx++) {
                try {
                    const username = await blog.methods.users(idx).call() as string;
                    const address = await blog.methods.usernameMapping(username).call() as string;
                    const balance = await web3!.eth.getBalance(address);
                    _userLists.push({ username, address, balance });
                } catch (e) { 
                    setError("Failed to fetch user information");
                }
            }
            setUserList(_userLists);
            setLoading(false);
        }
        fetchUsers();

    }, [blog, userCount]);

    if (error) {
        return (
            <Layout>
                <Crash reason={error} />
            </Layout>
        );
    }

    if (loading) {
        return (
            <Layout>
                <Flex preset="centered">
                    <Loading />
                </Flex>
            </Layout>
        );
    }

    return (
        <Layout>
            <Flex preset="centered" style={{ flexDirection: "column" }}>
                <Container title="User List" style={{ width: "100%" }}>
                        {userList.map((user, idx) => {
                            return (
                                <Container key={idx} titled rounded style={{ width: "100%", marginTop: "30px" }}>
                                    <p className={classNames("title", styles.clickableUsername)} onClick={() => {
                                        navigate(`/${user.username}/post`);
                                    }}>{user.username}</p>
                                    <p>Address: <strong>{user.address}</strong></p>
                                    <p>Balance: <strong>{web3!.utils.fromWei(user.balance.toString(), "gwei")} gwei</strong></p>
                                </Container>
                            );
                        })}
                </Container>
            </Flex>
        </Layout>
    );
};

export { Explore };