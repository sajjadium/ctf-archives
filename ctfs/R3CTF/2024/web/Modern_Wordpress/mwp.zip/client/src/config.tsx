const clientConfig = {
    provider: `${window.location.protocol}//${window.location.host}/rpc`
};

export {
    clientConfig
};