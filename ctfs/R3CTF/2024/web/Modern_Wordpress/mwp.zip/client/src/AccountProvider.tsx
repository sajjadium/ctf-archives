import React from "react";
import { useWeb3 } from "./Web3Provider";
import { Container } from "./Container";
import { Flex } from "./Flex";
import { Crash } from "./Crash";
import { useBackend } from "./BackendProvider";
import { Loading } from "./Loading";

interface Account {
    privateKey: string;
    address: string;
}

interface AccountContext {
    account: Account | undefined;
    balance: bigint | undefined;
    username: string | undefined;
    registered: boolean | undefined;
    loading: boolean;
    refreshBalance: () => void;
}

interface UserMappingResult {
    registered: boolean;
    username: string;
}

const AccountContext = React.createContext<AccountContext | undefined>(undefined);

const AccountProvider = (props: { children: React.ReactNode }) => {
    const { web3 } = useWeb3();
    const { blog } = useBackend();
    const [account, setAccount] = React.useState<Account | undefined>(undefined);
    const [balance, setBalance] = React.useState<bigint | undefined>(undefined);
    const [username, setUsername] = React.useState<string | undefined>(undefined);
    const [registered, setRegistered] = React.useState<boolean | undefined>(undefined);
    const [loading, setLoading] = React.useState<boolean>(true);
    const [error, setError] = React.useState<string | undefined>(undefined);

    const updateAccount = React.useCallback((privateKey: string) => {
        if (web3 === undefined) {
            setError("Web3 is not initialized");
            return false;
        }

        try {
            web3.eth.accounts.wallet.clear();
            const account = web3.eth.accounts.privateKeyToAccount(privateKey);
            web3.eth.accounts.wallet.add(account);
            web3.eth.defaultAccount = account.address;

            setAccount({
                privateKey,
                address: account.address
            });

            return true;
        } catch (e) { }

        return false;
    }, [web3]);

    const refreshBalance = React.useCallback(() => {
        if (web3 === undefined) {
            setError("Failed to fetch balance");
            return;
        }

        if (account === undefined) {
            return;
        }

        web3.eth.getBalance(web3.eth.defaultAccount!).then((balance) => {
            setBalance(balance);
        }).catch(() => {
            setError("Failed to fetch balance");
        });
    }, [account, web3]);

    const refreshUserInformation = React.useCallback(() => {
        if (account === undefined || blog === undefined) {
            return;
        }
        blog?.methods.userMapping(account?.address).call().then((result: any) => {
            let userMappingResult = result as UserMappingResult;
            if (!userMappingResult.registered) {
                setRegistered(false);
                return;
            }
            setRegistered(true);
            setUsername(userMappingResult.username);
        });
    }, [account, blog, web3]);

    React.useEffect(() => {
        const refresh = () => {
            setLoading(true);
            refreshBalance();
            refreshUserInformation();
            setLoading(false);
        };

        refresh();
        
        const interval = setInterval(() => refresh, 15000);

        return () => clearInterval(interval);
    }, [account, blog, web3]);

    if (error !== undefined) {
        return <Crash reason={error} />
    }

    if (account === undefined) {
        const inputRef = React.createRef<HTMLInputElement>();
        const resultRef = React.createRef<HTMLDivElement>();
        return (
            <Flex preset="centered" style={{ flexDirection: "column" }}>
                <h2>Modern Wordpress</h2>
                <Container title="Warning" style={{ width: "1100px", marginTop: "40px" }}>
                    <p className="nes-text is-primary">
                        ={'>'} For security, Your private key will be only stored in memory. <br /><br />
                        ={'>'} Please DONNOT use your account with balance in the mainnet.
                    </p>
                </Container>
                <Container title="Connect" style={{ width: "1100px", marginTop: "40px" }}>
                    <div className="nes-field">
                        <label>Private Key</label>
                        <input ref={inputRef} type="text" className="nes-input" placeholder="0xdeadbeef" />
                        <button type="button" className="nes-btn is-primary" style={{ marginTop: "10px" }} onClick={() => {
                            if (!updateAccount(inputRef.current!.value)) {
                                resultRef.current!.innerText = "Invalid private key";
                            }
                        }}>Connect</button>
                        <div ref={resultRef} className="nes-text is-error" style={{ textAlign: "center", marginTop: "10px" }}></div>
                    </div>
                </Container>
            </Flex>
        );
    }

    if (balance === undefined || registered === undefined) {
        return <Loading />;
    }

    return (
        <AccountContext.Provider value={{ account, balance, username, registered, loading, refreshBalance }}>
            {props.children}
        </AccountContext.Provider>
    );
};

const useAccount = () => {
    const context = React.useContext(AccountContext);
    if (context === undefined) {
        throw new Error("useAccount must be used within a AccountProvider");
    }
    return context;
};

export { AccountProvider, useAccount };