import { Link } from "react-router-dom";
import { Flex } from "./Flex";

interface CrashProps {
    reason: string;
    homeButton?: boolean;
}

const Crash = (props: CrashProps) => (
    <Flex preset="centered" style={{ flexDirection: "column" }}>
        <h2>Oh no! Something went wrong</h2>
        <br />
        <p>{props.reason}</p>
        {
            props.homeButton &&
            <>
                <br /><Link key={0} to='/' style={{ color: "#212529", textDecoration: "underline dotted" }}><div>Go Home</div></Link>
            </>
        }
    </Flex>
);

export { Crash };