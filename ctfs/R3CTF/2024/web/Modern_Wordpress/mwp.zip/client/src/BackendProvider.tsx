import React from "react";
import { Contract } from "web3";
import { Loading } from "./Loading";
import { Crash } from "./Crash";
import { useWeb3 } from "./Web3Provider";

interface BackendContext {
    blog: Contract<any> | undefined;
    version: string | undefined;
}

const BackendContext = React.createContext<BackendContext | undefined>(undefined);

const BackendProvider = (props: { children: React.ReactNode }) => {
    const [blog, setBlog] = React.useState<Contract<any> | undefined>(undefined);
    const [version, setVersion] = React.useState<string | undefined>(undefined);
    const [loading, setLoading] = React.useState<boolean>(true);
    const [error, setError] = React.useState<string | undefined>(undefined);
    const { web3 } = useWeb3();

    React.useEffect(() => {
        setLoading(true);
        fetch('/api/backend')
            .then(response => response.json())
            .then(data => {
                if (data.status === 'ok') {
                    let blogContract = new web3!.eth.Contract(data.data.blog.abi, data.data.blog.address);
                    setVersion(data.data.blog.version);
                    setBlog(blogContract);
                } else {
                    setError('Error fetching backend data');
                }
                setLoading(false);
            })
            .catch(() => {
                setError('Error fetching backend data');
                setLoading(false);
            });
    }, []);

    if (loading) {
        return <Loading />;
    }

    if (error) {
        return <Crash reason={error} />;
    }

    return (
        <BackendContext.Provider value={{ blog, version }}>
            {props.children}
        </BackendContext.Provider>
    );
};

const useBackend = () => {
    const context = React.useContext(BackendContext);
    if (context === undefined) {
        throw new Error("useBackend must be used within a BackendProvider");
    }
    return context;
}

export {
    BackendProvider,
    useBackend
};