import React from "react";
import Web3 from "web3";
import { clientConfig } from "./config";
import { Loading } from "./Loading";
import { Crash } from "./Crash";

interface Web3ProviderProps {
    children: React.ReactNode;
}

interface Web3Context {
    connected: boolean;
    loading: boolean;
    web3: Web3 | undefined;
    chainId: bigint | undefined;
}

const Web3Context = React.createContext<Web3Context | undefined>(undefined);

const Web3Provider = (props: Web3ProviderProps) => {
    const [connected, setConnected] = React.useState(false);
    const [loading, setLoading] = React.useState(false);
    const [web3, setWeb3] = React.useState<Web3 | undefined>(undefined);
    const [chainId, setChainId] = React.useState<bigint | undefined>(undefined);

    const [error, setError] = React.useState<string | undefined>(undefined);

    const connect = React.useCallback(async () => {
        setLoading(true);
        const _web3 = new Web3(clientConfig.provider);
        _web3.eth.getChainId().then((chainId) => {
            setWeb3(_web3);
            setChainId(chainId);
            setConnected(true);
            setLoading(false);
        }).catch(() => {
            setError("Failed to connect to Web3 provider");
            setConnected(false);
            setLoading(false);
        });
    }, []);

    React.useEffect(() => {
        connect();
    }, []);

    if (error !== undefined) {
        return <Crash reason={error} />
    }

    if (loading) {
        return <Loading />
    }

    if (!connected) {
        return <Crash reason="Failed to connect to Web3 provider" />
    }

    return (
        <Web3Context.Provider value={{ connected, loading, web3, chainId }}>
            {props.children}
        </Web3Context.Provider>
    );
}

const useWeb3 = (): Web3Context => {
    const ctx = React.useContext(Web3Context);

    if (ctx === undefined) {
        throw new Error("useWeb3 must be used within a Web3Provider");
    }

    return ctx;
};

export {
    Web3Provider,
    useWeb3
};