import { useParams } from "react-router-dom";
import { Layout } from "./Layout";
import { useAccount } from "./AccountProvider";
import { useBackend } from "./BackendProvider";
import React from "react";
import { Crash } from "./Crash";
import { Container } from "./Container";
import { Flex } from "./Flex";

interface Post {
    title: string;
    content: string;
    timestamp: bigint;
}

const PostElement = (props: Post) => {
    return (
        <Container title={props.title} rounded style={{ width: "100%", marginTop: "30px" }}>
            <p>Time: <strong>{new Date(Number(props.timestamp) * 1000).toLocaleString()}</strong></p>
            <br/>
            <div dangerouslySetInnerHTML={{ __html: props.content }}></div>
        </Container>
    );

}

const Post = () => {
    const params = useParams<{ username: string }>();
    const account = useAccount();
    const { blog } = useBackend();
    const [postCount, setPostCount] = React.useState<number>(0);
    const [posts, setPosts] = React.useState<Post[]>([]);
    const [loading, setLoading] = React.useState<boolean>(true);
    const [error, setError] = React.useState<string | undefined>(undefined);

    React.useEffect(() => {
        let username = params.username ?? account.username;
        if (username === undefined) {
            return;
        }       

        blog?.methods.getUserPostCount(username).call().then((result: any) => {
            setPostCount(result);
        }).catch(() => {
            setError("Failed to fetch post count");
        });
    }, [params.username, account.username, blog]);

    React.useEffect(() => {
        let username = params.username ?? account.username;

        const loadPosts = async () => {
            setLoading(true);
            let posts: Post[] = [];
            try {
                for (let idx = 0; idx < postCount; idx++) {
                    const result = await blog?.methods.read(username, idx).call();
                    posts.push({
                        title: result![0],
                        content: result![1],
                        timestamp: result![2]
                    });
                }
                setPosts(posts);
            } catch (error) {
                setError("Failed to fetch posts");
            }
            setLoading(false);
        }

        loadPosts();
        
    }, [postCount]);

    if (error) {
        return (
            <Layout>
                <Crash reason={error} />
            </Layout>
        );
    }

    if (loading) {
        return (
            <Layout>
                <h1>Loading...</h1>
            </Layout>
        );
    }

    if (params.username === undefined && account.username === undefined) {
        return (
            <Layout>
                <Crash reason="Please register first" />
            </Layout>
        );
    }

    return (
        <Layout>
            <Flex preset="centered" style={{ flexDirection: "column" }}>
                <Container title="Posts" style={{ width: "100%" }}>
                {posts.map((post, idx) => <PostElement key={idx} {...post} />)}
                </Container>
            </Flex>
        </Layout>
    );
};

export { Post };

