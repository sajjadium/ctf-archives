import { useNavigate } from "react-router-dom";
import styles from './NavBar.module.scss';
import { Flex } from "./Flex";

const BreadCrumbElement = (props: { text: string, link?: string, onClick?: () => void }) => {
    let navigate = useNavigate();
    
    return (
        <div className={styles.clickable} onClick={() => {
            if (props.onClick) {
                props.onClick();
            }

            if (props.link) {
                navigate(props.link);
            }
        }}>
            {props.text}
        </div>
    );
}

const NavBar = () => {
    return (
        <div className={styles.nav}>
            <div className={styles.navElements}>
                <span style={{ height: "100%", fontSize: "2em" }}>
                    Modern Wordpress
                </span>
                <Flex className={styles.breadcrumb}>
                    <BreadCrumbElement text="Home" link="/" />
                        / 
                    <BreadCrumbElement text="Post" link="/post" />
                        /
                    <BreadCrumbElement text="Explore" link="/explore" />
                        /
                    <BreadCrumbElement text="Recharge" link="/recharge" />
                </Flex>
            </div>
        </div>
    );
};

export { NavBar };