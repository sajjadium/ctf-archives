import React from 'react';
import { Container } from './Container';
import { Layout } from './Layout';
import { useAccount } from './AccountProvider';
import { Flex } from './Flex';
import { api, classNames } from './util';
import { useWeb3 } from './Web3Provider';

interface RedeemRequest {
    address: string;
    code: string;
    signature: string;
}

interface RedeemResponse {
    status: "ok" | "error";
    message: string;
}

interface RedeemResult {
    className: string;
    message: string;
}

const Recharge = () => {
    const giftCodeInputRef = React.createRef<HTMLInputElement>();
    const [result, setResult] = React.useState<RedeemResult | undefined>(undefined);
    const [redeeming, setRedeeming] = React.useState<boolean>(false);
    const { account, refreshBalance } = useAccount();
    const { web3 } = useWeb3();

    const redeem = React.useCallback(async (giftCode: string) => {
        setResult(undefined);
        setRedeeming(true);
        if (giftCode.length === 0) {
            setRedeeming(false);
            setResult({
                className: "is-error",
                message: "Invalid gift code"
            });
            return;
        }
        let redeemRequest: RedeemRequest = {
            address: account!.address,
            code: giftCode,
            signature: web3!.eth.accounts.sign(`${account!.address}|${giftCode}`, account!.privateKey).signature
        }
        api<RedeemResponse>("POST", "recharge", redeemRequest)
            .then((response) => {
                setResult({
                    className: response.status === "ok" ? "is-success": "is-error",
                    message: response.message
                });

                if (response.status === "ok") {
                    refreshBalance();
                }
            })
            .catch((_) => {
                setResult({
                    className: "is-error",
                    message: "Internal error"
                });
            })
            .finally(() => {
                setRedeeming(false);
            });
    }, []);

    return (
        <Layout>
            <Flex preset="centered" style={{ flexDirection: "column" }}>
                <Container title='FAQ' style={{ width: "100%", marginTop: "40px" }}>
                    <p className="nes-text">
                        Q: Why do I need to recharge? <br /><br />
                        A: Because this is a <b>BLOCKCHAIN</b> blog and you need to pay for the <b>gas fee</b> and <b>tips</b>. <br /><br />
                        <br />
                        Q: Is other payment methods supported? <br /><br />
                        A: <b>No</b>, only gift code is supported for security reasons. <br /><br />
                        <br />
                        Q: How to buy a gift code? <br /><br />
                        A: The most convenient way is to buy it from <a style={{color:"black"}} href="https://www.youtube.com/watch?v=dQw4w9WgXcQ" target="_blank"><b>@crazywoman</b></a>.<br /><br />
                        <br />
                        Q: Can I recharge for others? <br /><br />
                        A: <b>No</b>, you can only recharge for yourself. <br /><br />
                    </p>
                </Container>

                <Container title='Recharge' style={{ width: "100%", marginTop: "40px" }}>
                    <div className="nes-field">
                        <div>Gift Code</div>
                        <input type="text" ref={giftCodeInputRef} style={{marginTop: "10px"}} className="nes-input" placeholder="MWP-xxxx"></input>
                    </div>
                    {
                        redeeming ? (
                            <button type="submit" className="nes-btn is-disabled" style={{marginTop: "20px"}}>Redeeming...</button>
                        ) : (
                            <button type="submit" className="nes-btn is-primary" style={{marginTop: "20px"}} onClick={() => { redeem(giftCodeInputRef.current!.value); }}>Redeem</button>
                        )
                    }
                    
                    <div style={{marginTop: "10px", textAlign: "center"}}>  
                        {result && (
                            <h4 className={classNames("nes-text", result.className)}>{result.message}</h4>
                        )}
                    </div>
                </Container>

            </Flex>
        </Layout>
    );
};

export { Recharge };