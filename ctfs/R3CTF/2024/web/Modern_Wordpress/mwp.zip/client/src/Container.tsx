import { classNames } from "./util";

interface ContainerProps extends React.HTMLAttributes<HTMLDivElement> {
    title?: string;
    centered?: boolean;
    rounded?: boolean;
    titled?: boolean;
}

const containerStyle = {
    width: "fit-content",
    height: "fit-content"
} as React.CSSProperties;

const Container = (props: ContainerProps) => {
    const {
        style,
        className,
        children,
        centered,
        title,
        rounded,
        titled,
        ...others
    } = props;

    let containerClassName = classNames(className || "", "nes-container");

    if (centered) {
        containerClassName = classNames(containerClassName, "is-centered");
    }

    if (title || titled) {
        containerClassName = classNames(containerClassName, "with-title");
    }

    if (rounded) {
        containerClassName = classNames(containerClassName, "is-rounded");
    }

    return (
        <div style={{ ...containerStyle, ...style }} className={containerClassName} {...others}>
            {props.title && <p className="title">{props.title}</p>}
            {props.children}
        </div>
    );
}

export { Container };