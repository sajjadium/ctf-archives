import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { Web3Provider } from './Web3Provider';
import { Home } from './Home';
import { BackendProvider } from './BackendProvider';
import { AccountProvider } from './AccountProvider';
import { Explore } from './Explore';
import { Crash } from './Crash';
import { Post } from './Post';
import { Recharge } from './Recharge';

const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
    ErrorBoundary: () => <Crash reason='404 Not Found' homeButton />
  },
  {
    path: "/post",
    Component: Post
  },
  {
    path: "/:username/post",
    Component: Post
  },
  {
    path: "/explore",
    Component: Explore
  },
  {
    path: "/recharge",
    Component: Recharge
  }
]);

const App = () => {
  return (
    <Web3Provider>
      <BackendProvider>
        <AccountProvider>
          <RouterProvider router={router} />
        </AccountProvider>
      </BackendProvider>
    </Web3Provider>
  );
};

export default App;