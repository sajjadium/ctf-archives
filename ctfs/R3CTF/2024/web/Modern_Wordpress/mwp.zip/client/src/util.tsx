interface ApiErrorMessage {
    status: number;
    content: string | null;
}

class ApiError extends Error {

    public apiError: ApiErrorMessage;

    constructor(message: ApiErrorMessage) {
        super(`Api Error: ${message.status} - ${message.content}`);
        this.name = "ApiError";
        this.apiError = message;
    }
}

const classNames = (...classes: string[]) => {
    return classes.filter((c) => c && c !== "").join(" ");
}

const api = async <T,>(method: string, path: string, body: any): Promise<T> => {
    const response = await fetch(`/api/${path}`, {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(body)
    });

    if (!response.ok) {
        throw new ApiError({
            status: response.status,
            content: await response.text(),
        });
    }

    return response.json() as T;
}

export {
    classNames,
    api
};