#!/bin/sh

chmod 600 /entrypoint.sh

echo -n $GZCTF_FLAG > /flag
chmod 400 /flag
unset GZCTF_FLAG

set -eu

su srv -c 'node dist/index.js'
