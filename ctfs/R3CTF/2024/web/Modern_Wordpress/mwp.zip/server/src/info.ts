import exp from 'constants';
import { config } from './config';
import { readFileSync, rmSync } from 'fs';
import path from 'path';

interface Account {
    priv: string;
    addr: string;
}

interface ContractInfo {
    name: string;
    address: string;
    abi: any;
    bytecode: string;
}

interface InitInfo {
    chainID: string;
    miner: Account;
    accounts: Account[];
    contracts: ContractInfo[];
}

const loadInitInfo = (): InitInfo => {
    const initFile = path.join(config.gethDataDir, 'init.json');
    const info = JSON.parse(readFileSync(initFile, 'utf8'));
    rmSync(initFile);

    return info;
}

const info = loadInitInfo();

export { info };
export type {
    Account,
    ContractInfo,
    InitInfo
};