export const config = {
    gethDataDir: '/geth',
    gethHttpPort: 8545,
    provider: 'http://127.0.0.1:8545',
    proxyTimeout: 60000,
    clientDir: '/client',
    port: 3000,
    chainID: 114514
}