import { createHash } from 'crypto';

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const createVersionFromData = (data: string | Buffer) => {
    let sha1 = createHash('sha1');
    sha1.update(data);
    return sha1.digest('hex').slice(0, 8);
}

const randomString = (length: number) => {
    let result = '';
    while (result.length < length) {
        result += Math.random().toString(36).substring(2);
    }
    return result.slice(0, length); 
}

export {
    sleep,
    createVersionFromData,
    randomString
};