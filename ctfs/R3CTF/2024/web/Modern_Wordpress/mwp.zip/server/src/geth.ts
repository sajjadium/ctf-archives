import { spawn } from 'child_process';
import path from 'path';
import { config } from './config';
import { info } from './info';

const lauchGeth = () => {
    const minerAddr = info.miner.addr.slice(2);
    const geth = spawn('geth', [
        '--datadir', config.gethDataDir,
        '--networkid', info.chainID,
        '--password', path.join(config.gethDataDir, 'password'),
        '--allow-insecure-unlock',
        `--unlock=${minerAddr}`,
        `--miner.etherbase=${minerAddr}`,
        '--mine',
        `--http`, '--http.addr=127.0.0.1', `--http.port=${config.gethHttpPort}`,
        '--http.api=eth,net,web3',
        '--http.corsdomain=*',
        '--http.vhosts=*',
        '--nodiscover=true',
        '--maxpeers=0',
        '--ws=false',
        '--ipcdisable=true',
        '--discovery.dns=""'
    ]);

    geth.stdout.on('data', (data) => {
        console.log(data.toString());
    });

    geth.stderr.on('data', (data) => {
        console.error(data.toString());
    });

    geth.on('close', (code) => {
        console.log(`geth exited with code ${code}`);
    });

    return geth;
}

const gethHealthCheck = async (timeout: number) => {
    await fetch(config.provider, { signal: AbortSignal.timeout(timeout) });
};

export { 
    lauchGeth,
    gethHealthCheck
};