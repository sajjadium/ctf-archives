import express from 'express';
import { Request, Response, NextFunction } from 'express';
import { config } from './config';
import { proxyHandler } from './proxy';
import { lauchGeth, gethHealthCheck } from './geth';
import { randomString, sleep } from './util';
import path from 'path';
import { readFileSync } from 'fs';
import { rechargeHandler } from './recharge';
import { backendHandler } from './backend';
import { botHandler } from './bot';
import { flagHandler } from './flag';

const asyncHandler = func => (req: Request, res: Response, next: NextFunction) => {
    return Promise
        .resolve(func(req, res, next))
        .catch(next);
};

const main = async () => {
    const geth = lauchGeth();
    await sleep(3000);
    await gethHealthCheck(2000);

    const app = express();

    app.use((req, _, next) => {
        (req as any).id = randomString(10);
        next();
    });

    app.post('/rpc', express.raw({ type: "*/*" }), asyncHandler(proxyHandler));

    app.use(express.json());

    app.post('/api/recharge', asyncHandler(rechargeHandler));

    app.get('/api/backend', asyncHandler(backendHandler));

    app.post('/api/bot', asyncHandler(botHandler));

    app.post('/api/flag', asyncHandler(flagHandler));

    app.use('/assets', express.static(path.join(config.clientDir, 'assets')));
    const indexHtml = (readFileSync(path.join(config.clientDir, 'index.html'))).toString();

    app.all('*', (_, res: Response) => {
        res.send(indexHtml);
    });

    app.use((err: any, req: any, res: any, next: any) => {
        if (err) {
            console.error(`[-] Error processing request ${(req as any).id}: ${err}`);
            console.error(err.stack);
            res.status(500).json({ status: 'error', message: 'Internal server error', data: { id: (req as any).id } });
        } else{
            next();
        }
    });

    app.on('close', () => {
        geth.kill('SIGKILL');
        process.exit(0);
    });

    app.listen(config.port, () => {
        console.log(`Listening on port ${config.port}`);
    });
}

main();
