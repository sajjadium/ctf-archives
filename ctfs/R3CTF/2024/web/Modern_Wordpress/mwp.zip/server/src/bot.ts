import { Response, Request } from 'express';
import { config } from './config';
import puppeteer from 'puppeteer';
import { info } from './info';
import { sleep } from './util';

let visiting = false;

export const botHandler = async (req: Request, res: Response) => {
    if (visiting) {
        res.json({ status: 'error', message: 'Bot is already visiting' });
        return;
    }

    visiting = true;

    try {
        let browser = await puppeteer.launch({
            executablePath: '/usr/bin/chromium-browser',
			headless: true,
			args: [
				"--no-sandbox",
				"--disable-setuid-sandbox",
				"--js-flags=--noexpose_wasm,--jitless"
			]
		});
        const page = await browser.newPage();
        await page.goto(`http://localhost:${config.port}`, { waitUntil: 'networkidle2' });
        await page.type("input", info.accounts[0].priv);
        await page.$eval("button", btn => btn.click());

        await page.waitForSelector("xpath///div[contains(text(), 'Post')]");
        await page.$eval("xpath///div[contains(text(), 'Post')]", div => { (div as HTMLElement).click(); });

        await sleep(5000);

        await page.close();
        await browser.close();
        
        res.json({ status: 'success' });
    } catch (error) {
        console.error(`[-] Bot failed to visit: ${error}`);
        res.json({ status: 'error', message: 'Bot failed to visit' });
    } finally {
        visiting = false;
    }
};