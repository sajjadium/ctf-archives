import { info } from './info';
import { Request, Response } from 'express';
import { createVersionFromData } from './util';

export const backendHandler = (req: Request, res: Response) => {
    const blog = info.contracts.find(c => c.name === 'Blog');
    res.json(
        { 
            status: 'ok',
            data: {
                blog: {
                    address: blog!.address,
                    abi: blog!.abi,
                    version: createVersionFromData(blog!.bytecode)
                }
            }
        }
    );
};