import { Request, Response } from 'express';
import { Web3 } from 'web3';
import { isAddress } from 'web3-validator'
import { config } from './config';
import { info } from './info';
import { randomString } from './util';

interface RechargeRequest {
    code: string;
    address: string;
    signature: string;
}

interface Code {
    code: string;
    amount: string;
    used: boolean;
}

let codes = [] as Code[];

let web3 = new Web3(config.provider);
web3.eth.accounts.wallet.add(info.miner.priv);
web3.defaultAccount = info.miner.addr;

console.log('Generating codes...');
for(let i = 0; i < 50; i++) {
    codes.push({
        code: 'MWP-' + randomString(16),
        amount:  Web3.utils.toWei(50, 'finney'),
        used: false
    });
}
console.log('Codes generated');
console.log(codes);

const rechargeAccount = async (web3: Web3, account: string, amount: string): Promise<boolean> => {
    try {
        let result = await web3.eth.sendTransaction({
            from: web3.defaultAccount,
            to: account,
            value: amount,
        });

        if (result.status !== BigInt(1)) {
            return false;
        }

        return true;

    } catch (error) {
        return false;
    }
};

const rechargeHandler = async (req: Request, res: Response) => {
    let { code, address, signature } = req.body as RechargeRequest;

    if (!isAddress(address)) {
        res.json({ status: 'error', message: 'Invalid address' });
        return;
    }

    code = code.trim();

    let matchedCode = codes.find(c => c.code === code);

    if (!matchedCode) {
        res.json({ status: 'error', message: 'Invalid code' });
        return;
    }

    if (matchedCode.used) {
        res.json({ status: 'error', message: 'Code already used' });
        return;
    }

    let recoveredAddress: string;

    try {
        recoveredAddress = web3.eth.accounts.recover(`${address}|${code}`, signature);

        if (!recoveredAddress) {
            res.json({ status: 'error', message: 'Invalid signature' });
            return;
        }
    } catch (error) {
        res.json({ status: 'error', message: 'Invalid signature' });
        return;
    }

    if (recoveredAddress.toLowerCase() !== address.toLowerCase()) {
        res.json({ status: 'error', message: 'You can only recharge your own account' });
        return;
    }

    if (await rechargeAccount(web3, address, matchedCode.amount) === false) {
        res.json({ status: 'error', message: 'Failed to recharge' });
        return;
    }

    matchedCode.used = true;

    res.json({ status: 'ok', message: 'Successfully recharged' });
};

export { 
    rechargeHandler, 
    web3
};