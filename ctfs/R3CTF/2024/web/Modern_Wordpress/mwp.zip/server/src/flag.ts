import { execFileSync } from 'child_process';
import { Request, Response } from 'express';
import { web3 } from './recharge';
import { info } from './info';

interface FlagRequest {
    message: string;
    signature: string;
}

export const flagHandler = async (req: Request, res: Response) => {
    let { message, signature } = req.body as FlagRequest;

    if (message !== `${info.accounts[0].addr}: vivo flag`) {
        res.json({ status: 'error', message: 'Invalid message' });
        return;
    }

    let address: string;

    try {
        address = web3.eth.accounts.recover(message, signature);
    } catch (error) {
        res.json({ status: 'error', message: 'Invalid signature' });
        return;
    }

    if (address.toLowerCase() !== info.accounts[0].addr) {
        res.json({ status: 'error', message: 'The flag is not for you' });
        return;
    }

    res.json({ status: 'success', message: `Congratulations! Your flag: ${execFileSync('/readflag').toString()}` });
};