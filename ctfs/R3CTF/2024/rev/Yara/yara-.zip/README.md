```
❯ yr scan -C rules flag.txt
Congratulations! You have found the flag!
FindFlag flag.txt
────────────────────────────────────────────────────────────────────────────────
 1 file(s) scanned in 0.1s. 1 file(s) matched.
```

