<?php 
show_source(__FILE__);
unserialize($_GET['data']);
