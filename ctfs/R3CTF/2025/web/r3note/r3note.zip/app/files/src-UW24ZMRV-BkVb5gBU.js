import{L as o}from"./features-animation-VlUhDkJm.js";import"./index-CPTaD31V.js";import"./vendor-BvKuX3qW.js";import"./router-Ho2Mfwrb.js";var i=o;export{i as default};
//# sourceMappingURL=src-UW24ZMRV-BkVb5gBU.js.map
