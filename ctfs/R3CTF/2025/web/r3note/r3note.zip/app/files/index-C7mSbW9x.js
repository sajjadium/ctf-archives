import{L as o}from"./features-animation-VlUhDkJm.js";import"./index-CPTaD31V.js";import"./vendor-BvKuX3qW.js";import"./router-Ho2Mfwrb.js";var a=o;export{a as default};
//# sourceMappingURL=index-C7mSbW9x.js.map
