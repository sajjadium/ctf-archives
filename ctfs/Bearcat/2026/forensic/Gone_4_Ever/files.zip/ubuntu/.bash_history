cd
vi flag.txt
export pass=`hexdump -n 4 -e '4/1 "%02x"' /dev/urandom`
for i in {0..100}; do wget "https://placehold.co/400x400.jpg?text="$i -O $i".jpg"; done
steghide embed -ef flag.txt -cf $((RANDOM % 101))".jpg" -p $pass
rm flag.txt 
