Approved-ish — player handout

The live service is the target. Use its browser UI and network requests to
explore the data catalog, aliases, backup/restore, manifests, approvals, and
snapshots. Legacy alias backups may use different ID casing.
Workspaces last up to six hours and may reset during maintenance. New
workspaces may be unavailable at capacity.

This attachment contains the client interface only. The server source and
real flag are not distributed.

Challenge-specific rule: solve Approved-ish without AI assistance. Do not use
chatbots, coding assistants, autonomous agents, or model APIs to analyze the
service, screenshots, or attachment, generate requests, or derive the solution.
Do not ask someone else to relay prompts to an AI for you.
