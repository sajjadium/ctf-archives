I keep all my notes in StickyNotes. Surely nobody else can read them.

The source archive uses `wctf{sample_flag}` for local testing.
