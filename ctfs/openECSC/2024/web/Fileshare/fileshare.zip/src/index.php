<?php
session_start();

include_once('header.php');
?>

<h3>Welcome to Fileshare, a disruptive way to share files</h3>


<p class="my-3">Start sharing files for free <a href="/upload.php">here</a>!</p>

<?php
include_once('footer.php');
?>