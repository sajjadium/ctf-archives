This challenge consists of a client and a server component. Your goal is to exploit the client to exfiltrate the flag located at `C:\flag\flag.txt`. Please read the following instructions carefully.

The client component is `RemoteDiagnostics.Client.exe`. The server component is `RemoteDiagnostics.Server.exe`. The provided server component is not part of the challenge and is only provided to help you understand the client component.

Imagine the server component running on every employee's laptop within an organization, while the client component operates on the IT supporter's computer. The IT supporter uses the client to connect to the server component on an employee's laptop for remote troubleshooting.

The scenario is: What could happen if an IT supporter unintentionally connects to or is deceived into connecting to a malicious server (employee laptop)?

To solve this challenge, you need to host a server that listens for incoming connections and exploits the client.

You can request the challenge client to connect to your server by submitting your server's hostname/IP and port to the challenge web interface listed in the challenge description. A client will then connect to your server using a random username and password each time - to simulate a real-world scenario where an IT supporter connects using their own credentials. The client will then perform a series of actions via an automatic simulation. The simulation and actions are hardcoded in the client.

You can launch the server and client by simply double-clicking the executables `RemoteDiagnostics.Server.exe` and `RemoteDiagnostics.Client.exe`, respectively. You can then connect to `localhost` using your current Windows credentials. **Remember to allow the server and client through your firewall.**

If you want to run the simulation yourself, you can run the client with the following PowerShell command (or otherwise set the environment variables like so):

```powershell
$env:DHost = "localhost"
$env:DUser = "<randomusername>"
$env:DPass = "<randompassword>"
.\RemoteDiagnostics.Client.exe
```

The flag is mounted as read-only at `C:\flag\flag.txt` in a Docker container based on `mcr.microsoft.com/windows/servercore:ltsc2022`. The Docker container is forcefully destroyed after 30 seconds.

**When you believe you have a solution, remember to check that your own simulated client can be exploited using the remote address of your server and a random username/password.**