export const load = (({ params }) => {
    return {
      roomId: params.id
    };
  }
);