This challenge involves an Active Directory setup, which includes four servers and three networks (referred to as the lab). Your objective is to retrieve the flag from `C:\Users\Amministratore\Desktop\flag.txt` located on the server at `10.10.0.10`. Please ensure you follow the instructions provided carefully.

# Mission Brief

## Background

Attention Operative,

In our recent covert Red Team operation against Mamma Mia Pasta Company, our team successfully infiltrated one of their off-site factories, renowned for producing the finest spaghetti known to humankind. We discreetly implanted a network device into the main factory PC, providing us with remote network access via 4G and VPN directly to the workstation where factory employees log their work hours. Initially, we gained control of the PC by booting the workstation from a live USB, mounting the disk, and deploying our C2 malware onto the mounted disk.

Despite our best efforts to maintain stealth, the situation quickly escalated when we rebooted the workstation to its standard operating system. A mistake made by our junior malware developer inadvertently caused the malware to consume excessive amounts of CPU and memory resources, which promptly alerted the remote IT department, leading them to call the factory office phone.

We quickly rushed out of the factory, intentionally leaving our network device plugged into the PC to maintain remote access. Upon returning to the back of our cargo van, we quickly performed initial enumeration using our C2 malware. However, our connection to the malware was suddenly cut short. It became evident that the IT team had stopped and removed our malware, leaving us with only network access to the computer.

Your mission, should you choose to accept it, is to reestablish access to the factory PC and navigate your way through Mamma Mia Pasta Company's complex network, moving from site to site until reaching the heart of their operations: the domain controller safeguarding the closely held secret recipe for their renowned pasta. Time is of the essence, and success requires both skill and precision.

Remember, the outcome of this mission rests in your capable hands. In bocca al lupo, agente.

## Artifacts

Following our initial post-exploitation efforts, we successfully retrieved the following artifacts:

- A registry dump from the factory PC: [./artifacts/factws-registry/](./artifacts/factws-registry/)
- Group Policy Objects (GPOs) from the domain: [./artifacts/policies/](./artifacts/policies/)

## Network

Based on our reconnaissance, we have prepared a network diagram to help you navigate the network setup.

![Network.svg](./Network.svg)

Once connected to the VPN, you will be able to access the factory PC at `172.16.0.2` seamlessly via the network implant. It appears that only port `5986` is open on the factory PC.

# Access

To access a lab instance, you must request a "lease" that grants temporary access. Each lease lasts for one hour, with the option to extend as needed. Request and manage your lease through the link on the challenge card. Leases are granted automatically, but if you encounter issues, contact the support team. Please allow a few minutes for the lab to deploy and start.

VPN access is provided via WireGuard. Download the VPN configuration file from the lease page. If you're unfamiliar with WireGuard, you can find more information on how to install it [here](https://www.wireguard.com/install/) and a quick start guide [here](https://www.wireguard.com/quickstart/).

Once connected, perform a connection test to ensure you can reach the lab environment. You can use the following command to check the open port on the factory PC:

```bash
nc -z -v 172.16.0.2 5986
```

# Rules of Engagement

Lab environments are shared among multiple participants. Please ensure you follow the "Fair Play" rules as outlined at [https://open.ecsc2024.it/rules](https://open.ecsc2024.it/rules).

It is not necessary to perform any actions that could render the challenge unsolvable for others. Please keep this consideration in mind during your interaction with the lab.

# Remarks

Please keep your browser tab open on the lease page and allow notifications to receive information about your lease status or any important updates from the support team. For instance, if a lab is unhealthy, you will be notified that the lab is about to be destroyed, and you should save any important artifacts or progress.

The lab has no internet access, but all servers can communicate with your VPN client to simulate internet connectivity and enable you to download tools, scripts, and files, execute reverse shells, and set up C2 channels. However, despite being against the rules, this setup could allow other participants to potentially access your machine via the lab servers. Therefore, you should consider enabling your firewall to block all incoming connections from the VPN network, and only open ports when necessary.
