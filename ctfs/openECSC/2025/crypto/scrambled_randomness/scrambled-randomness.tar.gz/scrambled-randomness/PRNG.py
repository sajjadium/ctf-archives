import numpy as np

MASK64 = ((1 << 64) - 1)

def rotr(x, n):
	return ((x >> n) | (x << (64 - n))) & MASK64

def clmul(a, b):
	res = 0
	for i in range(64):
		if (a >> i) & 1:
			res ^= b << i
	return res & MASK64

def weird_poly(x, coef):
	y, p = coef[0], 1
	for i in range(1,len(coef)):
		p = clmul(~p,x)
		y ^= clmul(coef[i],p)
	return y

def make_scramble_matrix(n, k):
	k %= 256
	m = np.zeros((8,8))

	for i in range(0,8):
		m[i, i] = (2*((n % 6) + k + 1) + 1)
		
	for i in range(0,8):
		m[i, (i-1)%8] = 2*((5 - n) % 6) + 1

	for i in range(0,8):
		m[i, (i+1)%8] = -1 * (1 + 2*(n % 4)) + 2*k

	for i in range(0,8):
		m[i, n % 8] += 1 if (m[i, n % 8] == 0) else 2
		
	return m

class PRNG:
	def __init__(self, seed):
		assert len(seed) == 8
		self.state = int.from_bytes(seed)
		self.t = 0

	def scramble(self):
		state = self.state

		state ^= rotr(state, 7)

		k = clmul(state, MASK64) >> 63
		vec = np.array(list(state.to_bytes(8)))
		matrix = make_scramble_matrix(self.t // 8 + (1-k) * (-1), k * state - 1)
		state = int.from_bytes((matrix @ vec).astype(np.uint8).tobytes())

		state ^= rotr(state, 17) ^ rotr(state, 42) ^ rotr(state, 24) ^ rotr(state, 53)
		
		state = weird_poly(state, [0x4e1b88c5615038ae, 1, 2, 2, 3, 3, 4, 3, 4])
		state = clmul(state, 0xa90fd521eeab98d3)

		self.state = state

	def __next__(self):
		if self.t % 8 == 0 and self.t != 0:
			self.scramble()

		value = self.state.to_bytes(8)[self.t % 8]
		self.t += 1
		return (value * 55) % 256
	
	def __iter__(self):
		return self
