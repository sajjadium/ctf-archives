import os
from PRNG import PRNG

flag = open('flag.txt', 'rb').read()[::-1]

prng = PRNG(os.urandom(8))
ciphertext = bytes([m ^ k for m,k in zip(flag,prng)])

open('output.txt', 'w').write(ciphertext.hex())