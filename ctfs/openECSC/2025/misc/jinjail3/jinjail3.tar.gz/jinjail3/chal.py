from ctypes import c_ubyte
from jinja2.sandbox import SandboxedEnvironment


class ubyte(c_ubyte):
    def set_value(self, val):
        self.value = val
        return self


env = SandboxedEnvironment()
env.globals["c_ubyte"] = ubyte  # 😇😇😇

forbidden = ["__", "_", "mvm"]


if __name__ == "__main__":
    print("gib template: ")
    template = ""
    while True:
        line = input()
        if line == "===":
            break
        template += line + "\n"

    env.from_string(template).render()
