#!/bin/bash

python faas/app.py
sleep 999999 # make sure no one can escape this