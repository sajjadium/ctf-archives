code = "
class Matcher
  def initialize( search )
    @search = search
  end

  def change_search( new_search )
    @search = Regexp.escape( new_search )
  end

  def not_matches?( input )
    return !input.match?( /\#{@search}/ )
  end

  def matches?( input )
    return !self.not_matches?( input )
  end
end"

puts "Welcome to Enterprise Matcher Ultra!"
puts "You can change one character in the code"

print "Index? "
index = gets.to_i
raise "Invalid index" unless (0 <= index) && (index < code.length)

print "Character? "
char = gets.chomp[0]
raise "I don't like this character!" unless char != nil && char.match?(/\A[\w!"#$%&\\()*+,.<=>?@{}]\z/)

code[index] = char
begin
  eval(code)
rescue Exception => _
  puts "There was an error running the code!"
  exit!
end

print "Search string? "
search = gets.chomp
raise "Empty search" if search == nil
search = Regexp.escape(search)

print "Target string? "
target = gets.chomp
raise "Invalid target" unless target.match?(/\A\w+\z/)

print "Result: "
puts !!Matcher.new(search).matches?(target)

print "Now I will test my flag: "
letter = (('A'..'Z').to_a + ('a'..'z').to_a).sample
flag = "openECSC{REDACTED}"
puts !!Matcher.new(letter).not_matches?(flag)