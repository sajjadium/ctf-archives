from IPython.terminal.embed import InteractiveShell

FORBIDDEN = [
    *"\t\r!#$%&')+-./:;<>?@[\\]^`{|}~",
    *"0123456789",
    *"ABCDEFGHIJKLMNOPQRSTUVWXYZ",
    "__",
    "ascii",
    "assert",
    "breakpoint",
    "builtin",
    "byte",
    "chr",
    "class",
    "complex",
    "copyright",
    "count",
    "def",
    "Error",
    "Exception",
    "eval",
    "exec",
    "exit",
    "flag",
    "globals",
    "help",
    "import",
    "In",
    "index",
    "input",
    "int",
    "lambda",
    "license",
    "locals",
    "mvm",
    "open",
    "ord",
    "Out",
    "pop",
    "print",
    "python",
    "quit",
    "read",
    "repr",
    "return",
    "setattr",
    "str",
    "super",
    "system",
    "utf",
    "w",
]

code = ""
while True:
    line = input()
    if line == "===":
        break
    code += line + "\n"

for bad in FORBIDDEN:
    if bad in code:
        print(f"Code contains {bad!r}, bad user >:c")
        exit(1)

if not code.isascii():
    print("Code has to be ascii, bad user >:c")
    exit(1)

lines = code.splitlines()

if len(lines) > 15:
    print("We don't support programs of this size, bad user >:c")
    exit(1)

for line in lines:
    if len(line) > 10:
        print("We don't support long lines of code, bad user >:c")
        exit(1)


ip = InteractiveShell()
ip.magics_manager.magics["line"].clear()
ip.magics_manager.magics["cell"].clear()
ip.alias_manager.aliases.clear()


def safe_getattr(o, /, name, default=...):
    name = "denied" if "_" in name else name
    if default == ...:
        return getattr(o, name)
    return getattr(o, name, default)


ip.user_ns["getattr"] = safe_getattr

for line in lines:
    ip.run_cell(line)
