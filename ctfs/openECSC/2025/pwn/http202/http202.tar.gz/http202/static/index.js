document.addEventListener('DOMContentLoaded', function() {
    const noteInput = document.getElementById('note-input');
    const addNoteBtn = document.getElementById('add-note');
    const notesList = document.getElementById('notes-list');

    let notes = [];

    // Load notes from server
    function fetchNotes() {
        fetch('/notes/list', { method: 'GET' })
            .then(res => res.json())
            .then(data => renderNotes(data));
    }

    addNoteBtn.addEventListener('click', function() {
        const noteText = noteInput.value.trim();
        if (noteText) {
            fetch('/notes/add', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: noteText
            })
            .then(() => {
                noteInput.value = '';
                fetchNotes();
            });
        }
    });

    function renderNotes(notes) {
        console.log("Rendering notes:", notes);
        notesList.innerHTML = '';
        notes.forEach((note, idx) => {
            const li = document.createElement('li');
            li.textContent = note.content;
            const delBtn = document.createElement('button');
            delBtn.textContent = 'Delete';
            delBtn.className = 'delete-btn';
            delBtn.onclick = function() {
                fetch('/notes/delete', {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: note.id.toString()
                })
                .then(() => {
                    fetchNotes();
                });
            };
            li.appendChild(delBtn);
            notesList.appendChild(li);
        });
    }

    fetchNotes();
});
