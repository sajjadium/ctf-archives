import { Buffer } from "node:buffer";
import { pbkdf2Sync, randomBytes, timingSafeEqual } from "node:crypto";

const ITERATIONS = 100000;

export const hashPw = (password: string) => {
  const salt = randomBytes(16);
  const derivedKey = pbkdf2Sync(password, salt, ITERATIONS, 64, "sha512");
  return {
    salt,
    derivedKey,
  };
};

export const toDB = ({ salt, derivedKey }: ReturnType<typeof hashPw>) =>
  `${salt.toString("base64")}$${derivedKey.toString("base64")}`;

export const fromDB = (pwString: string) => {
  const segs = pwString.split("$");
  const [saltB64, keyB64] = segs;
  if (segs.length !== 2 || !saltB64 || !keyB64) {
    throw new Error("Invalid Password Hash passed to crypto::fromDB.");
  }
  return {
    salt: Buffer.from(saltB64, "base64"),
    derivedKey: Buffer.from(keyB64, "base64"),
  };
};

export const checkPw = (input: string, stored: string) => {
  const { salt, derivedKey: storedKey } = fromDB(stored);
  const derived = pbkdf2Sync(input, salt, ITERATIONS, 64, "sha512");
  return (
    derived.length === storedKey.length &&
    timingSafeEqual(Buffer.from(derived), Buffer.from(storedKey))
  );
};
