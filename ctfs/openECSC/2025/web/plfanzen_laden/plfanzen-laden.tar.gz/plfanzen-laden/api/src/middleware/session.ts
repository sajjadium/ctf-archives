import { Middleware } from "@oak/oak";
import { signCookie, unsignCookie } from "@/cookie.ts";
import { uid } from "@/crypto.ts";
import client from "@/redis.ts";

type SessionOptions = {
  secret: string;
  ttl: number;
  name?: string;
  prefix?: string;
};

const sessionMiddleware = (options: SessionOptions) => {
  const { secret, ttl } = options;
  const name = options.name || "ssid";
  const prefix = options.prefix || "sess:";

  const middleware: Middleware = async (ctx, next) => {
    let ssidCookie = await ctx.cookies.get(name);
    let ssid = ssidCookie
      ? await unsignCookie({ secret, signedCookie: ssidCookie })
      : null;
    if (ssid && !(await client.exists(prefix + ssid))) {
      ssid = null;
    }
    if (!ssid) {
      ssid = uid(24);
      await client.set(prefix + ssid, JSON.stringify({}), {
        PX: ttl,
      });
      ssidCookie = await signCookie({ secret, value: ssid });
      const attl = await client.pTTL(prefix + ssid);
      await ctx.cookies.set(name, ssidCookie, { maxAge: attl });
    }
    const sessRaw = (await client.get(prefix + ssid)) ?? "{}";
    const sessObj = JSON.parse(sessRaw);
    ctx.state.session = sessObj;

    await next();
    if (await client.exists(prefix + ssid)) {
      await client.set(prefix + ssid, JSON.stringify(ctx.state.session), {
        expiration: "KEEPTTL",
      });
    }
    delete ctx.state.session;
  };
  return middleware;
};

export default sessionMiddleware;
