import { Middleware } from "@oak/oak";
import { BurstyRateLimiter, RateLimiterMemory } from "rate-limiter-flexible";

type Opts = ConstructorParameters<typeof RateLimiterMemory>[0];

interface RateLimitOptions {
  normal: Opts;
  burst: Opts;
  key?: string;
}

const rateLimitMiddleware = (opts: RateLimitOptions): Middleware => {
  const burst = new RateLimiterMemory(opts.burst);

  const rateLimiter = new BurstyRateLimiter(
    new RateLimiterMemory(opts.normal),
    burst,
  );
  return async (ctx, next) => {
    const key = opts.key ?? "app";
    try {
      await rateLimiter.consume(key);
    } catch {
      console.log(`doing a funny with a request to ${ctx.request.url}`);
      ctx.response.status = 429;
      ctx.response.body = { error: "nya~" };
      return;
    }
    await next();
    console.log(`at ${await burst.get(key)} points`);
  };
};

export default rateLimitMiddleware;
