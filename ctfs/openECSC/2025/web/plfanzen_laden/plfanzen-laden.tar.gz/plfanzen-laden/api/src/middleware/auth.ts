import { State } from "@/main.ts";
import { Middleware } from "@oak/oak";

export type AuthenticatedState = Required<State>;

const authMiddleware: Middleware<State> = async (ctx, next) => {
  if (ctx.state.user) {
    await next();
    return;
  }

  ctx.response.status = 401;
  ctx.response.body = { error: "Unauthorized" };
};

export default authMiddleware;
