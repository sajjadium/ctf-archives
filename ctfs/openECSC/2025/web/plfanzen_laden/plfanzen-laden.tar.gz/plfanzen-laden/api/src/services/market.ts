import { Client } from "@db/postgres";
import users, { UserPublic } from "@/db/users.ts";
import products from "@/db/products.ts";
import userProducts from "@/db/user-products.ts";

class MarketService {
  client: Client;

  constructor(client: Client) {
    this.client = client;
  }

  async buyProduct(
    user: UserPublic,
    productId: number,
    quantity: number | string,
  ) {
    const U = users(this.client);
    const P = products(this.client);

    quantity = parseInt(quantity as string); // 😇😇😇

    const product = await P.findById(productId);
    if (!product) {
      return;
    }
    if (product.quantity < quantity) {
      return;
    }
    await U.decreaseBalance(user.id, product.price * quantity);
    await P.decreaseQuantity(product.id, quantity);

    const uP = userProducts(this.client);
    await uP.add(user.id, product.id, product.quantity);
  }

  async refundProduct(user: UserPublic, productId: number, quantity: number) {
    const U = users(this.client);
    const P = products(this.client);
    const product = await P.findById(productId);
    if (!product) {
      return;
    }
    const uP = userProducts(this.client);
    const lel = (await uP.findUserProducts(user.id)).find(
      (pp) => pp.id === product.id,
    );
    if (!lel || quantity > lel.quantity) {
      return;
    }
    await uP.remove(user.id, product.id, quantity);
    await P.increaseQuantity(product.id, quantity);
    await U.increaseBalance(
      user.id,
      Math.floor(quantity * product.price * 0.1),
    );
  }
}

export default MarketService;
