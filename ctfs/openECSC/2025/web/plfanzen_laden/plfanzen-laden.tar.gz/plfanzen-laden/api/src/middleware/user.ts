import { Middleware } from "@oak/oak";
import type { State } from "@/main.ts";
import user, { omitPw } from "@/db/users.ts";

const userMiddleware: Middleware<State> = async (
  ctx,
  next,
) => {
  if (!ctx.state.session.uid) {
    await next();
    return;
  }

  const U = user(ctx.state.client);

  const u = await U.findById(ctx.state.session.uid as number);
  if (!u) {
    delete ctx.state.session.uid;
    await next();
    return;
  }

  ctx.state.user = omitPw(u);
  await next();
  delete ctx.state.user;
};

export default userMiddleware;
