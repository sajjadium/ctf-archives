import { Middleware } from "@oak/oak";
import { AuthenticatedState } from "@/middleware/auth.ts";

const premiumMiddleware: Middleware<AuthenticatedState> = async (ctx, next) => {
  if (ctx.state.user.premium) {
    await next();
    return;
  }

  ctx.response.status = 403;
  ctx.response.body = { error: "poor" };
};

export default premiumMiddleware;
