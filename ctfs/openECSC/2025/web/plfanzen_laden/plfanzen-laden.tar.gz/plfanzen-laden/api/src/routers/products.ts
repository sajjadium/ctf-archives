import authMiddleware, { AuthenticatedState } from "@/middleware/auth.ts";
import { Router } from "@oak/oak";
import products, { omitTotal } from "@/db/products.ts";
import userProducts from "@/db/user-products.ts";
import { badRequest, notFound, parseInteger } from "@/utils.ts";
import MarketService from "@/services/market.ts";
import z from "zod";

const router = new Router<AuthenticatedState>({ prefix: "/products" });
router.get("/", async (ctx) => {
  const P = products(ctx.state.client);

  ctx.response.body = (await P.findAll()).map(omitTotal);
});

router.get("/mine", authMiddleware, async (ctx) => {
  const uP = userProducts(ctx.state.client);
  const userId = ctx.state.user.id;
  const products = await uP.findUserProducts(userId);
  ctx.response.body = products.map(omitTotal);
});

router.get("/:id", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;
  ctx.response.body = omitTotal(product);
});

router.use(authMiddleware);

export const byId = async (ctx: any) => {
  const P = products(ctx.state.client);

  const id = parseInteger(ctx.params.id);
  if (!id) {
    badRequest(ctx.response, { error: "invalid id" });
    return;
  }
  const product = await P.findById(id);
  if (!product) {
    notFound(ctx.response);
    return;
  }
  return [P, product] as const;
};

router.post("/:id/buy-all", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const ms = new MarketService(ctx.state.client);
  await ms.buyProduct(ctx.state.user, product.id, product.quantity);

  ctx.response.body = {
    success: true,
    message: "Product bought successfully",
  };
});

router.post("/:id/buy", async (ctx) => {
  const res = await byId(ctx);

  if (!res) {
    return;
  }
  const [, product] = res;

  const quantitySchema = z.object({
    quantity: z
      .number()
      .int()
      .max(
        Math.min(
          Math.floor(ctx.state.user.balance / product.price),
          product.quantity,
        ),
      )
      .min(1),
  });
  const body = await ctx.request.body.json();
  const parsed = quantitySchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.issues);
    return;
  }
  const { quantity } = parsed.data;

  const ms = new MarketService(ctx.state.client);
  await ms.buyProduct(ctx.state.user, product.id, quantity);

  ctx.response.body = {
    success: true,
    message: "Product bought successfully",
  };
});

router.post("/:id/refund-all", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const ms = new MarketService(ctx.state.client);
  const uP = userProducts(ctx.state.client);
  const lel = (await uP.findUserProducts(ctx.state.user.id)).find(
    (pp) => pp.id === product.id,
  );
  if (!lel) {
    badRequest(ctx.response, { error: "you don't own that lol" });
    return;
  }

  await ms.refundProduct(ctx.state.user, product.id, lel.quantity);

  ctx.response.body = {
    success: true,
    message: "Refund successful",
  };
});

router.post("/:id/refund", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const quantitySchema = z.object({
    quantity: z.number().int().positive(),
  });
  const body = await ctx.request.body.json();
  const parsed = quantitySchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.issues);
    return;
  }
  const { quantity } = parsed.data;

  const ms = new MarketService(ctx.state.client);
  const uP = userProducts(ctx.state.client);
  const öhhhh = (await uP.findUserProducts(ctx.state.user.id)).find(
    (pp) => pp.id === product.id,
  );
  if (!öhhhh) {
    badRequest(ctx.response, { error: "you don't own that lol" });
    return;
  }
  if (quantity > öhhhh.quantity) {
    badRequest(ctx.response, { error: "you don't own that many items" });
    return;
  }

  await ms.refundProduct(ctx.state.user, product.id, quantity);

  ctx.response.body = {
    success: true,
    message: "Refund successful",
  };
});

export default router;
