import { Client, ClientOptions } from "@db/postgres";
import { sessionPrefix, startingBalance } from "@/config.ts";
import products from "@/db/products.ts";
import client from "@/redis.ts";

export const getClient = async (opts: ClientOptions) => {
  const client = new Client(opts);

  await client.connect();

  await client.queryArray(`
  CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    balance NUMERIC(1000, 0) DEFAULT ${startingBalance},
    premium BOOLEAN DEFAULT False,
    password_hash TEXT NOT NULL
  );`);

  await client.queryArray`
  CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    price INTEGER NOT NULL,
    quantity NUMERIC(1000, 0),
    total NUMERIC(1000, 0) NOT NULL
  );
  `;

  await client.queryArray`
  CREATE TABLE IF NOT EXISTS user_products (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    quantity NUMERIC(1000, 0) NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, product_id)
  );
  `;

  await client.queryArray`
  CREATE TABLE IF NOT EXISTS reviews (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    description TEXT NOT NULL CHECK (LENGTH(description) <= 1000),
    stars INTEGER NOT NULL CHECK (stars >= 0 AND stars <= 5),
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE (user_id, product_id)
  );
  `;

  const funcExists = await client.queryObject<{
    exists: boolean;
  }>(`
  SELECT EXISTS (
    SELECT 1 FROM pg_proc WHERE proname = 'set_default_quantity'
  ) AS exists;
`);

  if (!funcExists.rows[0].exists) {
    await client.queryObject(`
    CREATE FUNCTION set_default_quantity() RETURNS trigger AS $$
    BEGIN
      IF NEW.quantity IS NULL THEN
        NEW.quantity := NEW.total;
      END IF;
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
  `);
  }

  const triggerExists = await client.queryObject<{
    exists: boolean;
  }>(`
  SELECT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'before_insert_products'
  ) AS exists;
`);

  if (!triggerExists.rows[0].exists) {
    await client.queryObject(`
    CREATE TRIGGER before_insert_products
    BEFORE INSERT ON products
    FOR EACH ROW
    EXECUTE FUNCTION set_default_quantity();
  `);
  }

  const P = products(client);
  try {
    await P.create({
      name: "Plfanzen",
      description: "plants",
      price: 100,
      total: 10,
    });
  } catch {}

  return client;
};

export const reset = async (db: Client) => {
  const keys = await client.KEYS(sessionPrefix + "*");
  if (keys.length) {
    await client.UNLINK(keys);
    console.log(`purged: `, keys);
  }

  await db.queryObject`
    UPDATE products
    SET quantity = total;
  `;
};
