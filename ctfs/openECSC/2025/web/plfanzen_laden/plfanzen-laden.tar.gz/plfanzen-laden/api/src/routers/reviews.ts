import authMiddleware, { AuthenticatedState } from "@/middleware/auth.ts";
import { Router } from "@oak/oak";
import reviews from "@/db/reviews.ts";
import userProducts from "@/db/user-products.ts";
import { byId } from "@/routers/products.ts";
import { badRequest, notFound } from "@/utils.ts";
import z from "zod";
import premiumMiddleware from "@/middleware/premium.ts";

const router = new Router<AuthenticatedState>({ prefix: "/reviews" });
router.use(authMiddleware);

const reviewSchema = z.object({
  description: z.string().min(1).max(1000),
  stars: z.number().int().min(0).max(5),
});

// Get all reviews for a product
router.get("/product/:id", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const R = reviews(ctx.state.client);
  const productReviews = await R.findByProductId(product.id);

  ctx.response.body = productReviews;
});

// Get current user's reviews
router.get("/mine", async (ctx) => {
  const R = reviews(ctx.state.client);
  const userReviews = await R.findByUserId(ctx.state.user.id);

  ctx.response.body = userReviews;
});

// Create or update a review for a product
router.post("/product/:id", premiumMiddleware, async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  // Check if user owns the product
  const uP = userProducts(ctx.state.client);
  const userProductsList = await uP.findUserProducts(ctx.state.user.id);
  const ownsProduct = userProductsList.some((p) => p.id === product.id);

  if (!ownsProduct) {
    badRequest(ctx.response, {
      error: "You must own this product to review it",
    });
    return;
  }

  const body = await ctx.request.body.json();
  const parsed = reviewSchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.issues);
    return;
  }

  const { description, stars } = parsed.data;
  const R = reviews(ctx.state.client);

  // Check if user already has a review for this product
  const existingReview = await R.findByUserAndProduct(
    ctx.state.user.id,
    product.id,
  );

  let review;
  if (existingReview) {
    // Update existing review
    review = await R.update(ctx.state.user.id, product.id, description, stars);
    if (!review) {
      badRequest(ctx.response, { error: "Failed to update review" });
      return;
    }
  } else {
    // Create new review
    review = await R.create({
      userId: ctx.state.user.id,
      productId: product.id,
      description,
      stars,
    });
  }

  ctx.response.body = {
    success: true,
    message: existingReview
      ? "Review updated successfully"
      : "Review created successfully",
    review,
  };
});

// Get user's review for a specific product
router.get("/product/:id/mine", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const R = reviews(ctx.state.client);
  const review = await R.findByUserAndProduct(ctx.state.user.id, product.id);

  if (!review) {
    notFound(ctx.response);
    return;
  }

  ctx.response.body = review;
});

// Delete user's review for a specific product
router.delete("/product/:id", premiumMiddleware, async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [, product] = res;

  const R = reviews(ctx.state.client);
  const deleted = await R.delete(ctx.state.user.id, product.id);

  if (!deleted) {
    notFound(ctx.response);
    return;
  }

  ctx.response.body = {
    success: true,
    message: "Review deleted successfully",
  };
});

export default router;
