import { Client } from "@db/postgres";
import { hashPw, toDB } from "@/db/crypto.ts";

export interface User {
  id: number;
  username: string;
  email: string;
  premium: boolean;
  balance: number;
  password_hash: string;
}

export interface UserDB extends Omit<User, "balance"> {
  balance: string;
}

export type UserPublic = Omit<User, "password_hash">;

interface UserCreation {
  username: string;
  email: string;
  password: string;
}

export const omitPw = (user: User): UserPublic => ({
  id: user.id,
  username: user.username,
  email: user.email,
  premium: user.premium,
  balance: user.balance,
});

const mapDBToUser = (u: UserDB): User => ({
  ...u,
  balance: Number(u.balance),
});

const user = (client: Client) => {
  const create = async (user: UserCreation): Promise<User> => {
    const username = user.username.toLowerCase();
    const email = user.email.toLowerCase();

    const res = await client.queryObject<UserDB>`
      INSERT INTO users (username, email, password_hash)
      VALUES (${username}, ${email}, ${toDB(hashPw(user.password))})
      RETURNING *;
    `;
    return mapDBToUser(res.rows[0]!);
  };

  const findById = async (id: number): Promise<User | undefined> => {
    const res = await client.queryObject<UserDB>`
      SELECT * FROM users WHERE id = ${id};
    `;
    if (!res.rows[0]) return undefined;
    return mapDBToUser(res.rows[0]);
  };

  const findByUsername = async (
    username: string,
  ): Promise<User | undefined> => {
    const res = await client.queryObject<UserDB>`
      SELECT * FROM users WHERE username = ${username.toLowerCase()};
    `;
    if (!res.rows[0]) return undefined;
    return mapDBToUser(res.rows[0]);
  };

  const findByEmail = async (email: string): Promise<User | undefined> => {
    const res = await client.queryObject<UserDB>`
      SELECT * FROM users WHERE email = ${email.toLowerCase()};
    `;
    if (!res.rows[0]) return undefined;
    return mapDBToUser(res.rows[0]);
  };

  const decreaseBalance = async (id: number, amount: number) => {
    const res = await client.queryObject`
      UPDATE users SET balance = balance - ${amount} WHERE id = ${id} AND balance >= ${amount};
    `;
    if (res.rowCount === 0) {
      throw new Error("poor");
    }
  };

  const increaseBalance = async (id: number, amount: number) => {
    await client.queryObject`
      UPDATE users SET balance = balance + ${amount} WHERE id = ${id};
    `;
  };

  return {
    create,
    findById,
    findByUsername,
    findByEmail,
    decreaseBalance,
    increaseBalance,
  };
};

export default user;
