import { getClient } from "@/db/index.ts";
import { Middleware } from "@oak/oak";
import { ClientOptions } from "@db/postgres";

const clientMiddleware = async (options: ClientOptions) => {
  const client = await getClient(options);
  const middleware: Middleware = async (ctx, next) => {
    ctx.state.client = client;
    await next();
    delete ctx.state.client;
  };
  return middleware;
};

export default clientMiddleware;
