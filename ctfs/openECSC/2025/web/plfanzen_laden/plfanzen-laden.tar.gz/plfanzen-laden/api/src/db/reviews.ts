import { Client } from "@db/postgres";

export interface Review {
  id: number;
  userId: number;
  productId: number;
  description: string;
  stars: number;
  createdAt: Date;
}

export interface ReviewDB
  extends Omit<Review, "userId" | "productId" | "createdAt"> {
  user_id: number;
  product_id: number;
  created_at: string;
}

export interface ReviewCreation {
  userId: number;
  productId: number;
  description: string;
  stars: number;
}

export interface ReviewWithUser extends Review {
  username: string;
}

export interface ReviewWithUserDB extends ReviewDB {
  username: string;
}

export const mapDbToReview = (row: ReviewDB): Review => ({
  id: row.id,
  userId: row.user_id,
  productId: row.product_id,
  description: row.description,
  stars: row.stars,
  createdAt: new Date(row.created_at),
});

export const mapDbToReviewWithUser = (
  row: ReviewWithUserDB,
): ReviewWithUser => ({
  id: row.id,
  userId: row.user_id,
  productId: row.product_id,
  description: row.description,
  stars: row.stars,
  createdAt: new Date(row.created_at),
  username: row.username,
});

const reviews = (client: Client) => {
  const create = async (review: ReviewCreation) => {
    const { userId, productId, description, stars } = review;
    const res = await client.queryObject<ReviewDB>`
      INSERT INTO reviews (user_id, product_id, description, stars)
      VALUES (${userId}, ${productId}, ${description}, ${stars})
      RETURNING *;
    `;
    return mapDbToReview(res.rows[0]);
  };

  const findByProductId = async (
    productId: number,
  ): Promise<ReviewWithUser[]> => {
    const res = await client.queryObject<ReviewWithUserDB>`
      SELECT r.*, u.username 
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.product_id = ${productId}
      ORDER BY r.created_at DESC;
    `;
    return res.rows.map(mapDbToReviewWithUser);
  };

  const findByUserId = async (userId: number) => {
    const res = await client.queryObject<ReviewDB>`
      SELECT * FROM reviews WHERE user_id = ${userId}
      ORDER BY created_at DESC;
    `;
    return res.rows.map(mapDbToReview);
  };

  const findByUserAndProduct = async (userId: number, productId: number) => {
    const res = await client.queryObject<ReviewDB>`
      SELECT * FROM reviews 
      WHERE user_id = ${userId} AND product_id = ${productId};
    `;
    if (!res.rows[0]) return undefined;
    return mapDbToReview(res.rows[0]);
  };

  const update = async (
    userId: number,
    productId: number,
    description: string,
    stars: number,
  ) => {
    const res = await client.queryObject<ReviewDB>(`
      UPDATE reviews 
      SET description = ${description}, stars = ${stars}
      WHERE user_id = ${userId} AND product_id = ${productId}
      RETURNING *;
    `);
    if (!res.rows[0]) return undefined;
    return mapDbToReview(res.rows[0]);
  };

  return {
    create,
    findByProductId,
    findByUserId,
    findByUserAndProduct,
    update,
  };
};

export default reviews;
