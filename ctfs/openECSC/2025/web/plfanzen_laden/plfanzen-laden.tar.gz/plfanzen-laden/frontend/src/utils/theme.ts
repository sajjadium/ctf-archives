// Reusable Tailwind CSS classes for consistent dark mode theming

export const themeClasses = {
  // Backgrounds
  bg: {
    primary: 'bg-white dark:bg-gray-800',
    secondary: 'bg-gray-50 dark:bg-gray-900',
    tertiary: 'bg-gray-100 dark:bg-gray-700',
    overlay: 'bg-gray-500 dark:bg-gray-900 bg-opacity-75 dark:bg-opacity-75',
  },

  // Text colors
  text: {
    primary: 'text-gray-900 dark:text-white',
    secondary: 'text-gray-600 dark:text-gray-300',
    tertiary: 'text-gray-700 dark:text-gray-300',
    muted: 'text-gray-500 dark:text-gray-400',
    success: 'text-green-600 dark:text-green-400',
    error: 'text-red-600 dark:text-red-400',
    warning: 'text-yellow-600 dark:text-yellow-400',
  },

  // Borders
  border: {
    primary: 'border-gray-300 dark:border-gray-600',
    secondary: 'border-gray-200 dark:border-gray-700',
  },

  // Form elements
  input: 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white border-gray-300 dark:border-gray-600 placeholder-gray-500 dark:placeholder-gray-400 focus:border-blue-500 focus:ring-blue-500',
  
  // Buttons
  button: {
    primary: 'bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 text-white',
    secondary: 'bg-gray-500 hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-700 text-white',
    success: 'bg-green-500 hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700 text-white',
    danger: 'bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 text-white',
    outline: 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-600',
  },

  // Cards
  card: 'bg-white dark:bg-gray-800 shadow-md border border-gray-200 dark:border-gray-700',

  // Status colors
  status: {
    success: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border-green-400 dark:border-green-600',
    error: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300 border-red-400 dark:border-red-600',
    warning: 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300 border-yellow-400 dark:border-yellow-600',
    info: 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border-blue-400 dark:border-blue-600',
  },

  // Navigation
  nav: {
    bg: 'bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700',
    link: 'text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white',
    linkActive: 'text-blue-600 dark:text-blue-400',
  },
} as const;

// Helper function to combine theme classes
export const cn = (...classes: (string | undefined | false)[]): string => {
  return classes.filter(Boolean).join(' ');
};