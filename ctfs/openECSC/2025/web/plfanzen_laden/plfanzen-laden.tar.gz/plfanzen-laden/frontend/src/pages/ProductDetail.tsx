import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import toast from "react-hot-toast";
import { useAtomValue, useSetAtom } from "jotai";
import type { Product, Review } from "../types/api";
import { productsApi, reviewsApi } from "../services/api";
import { addToCartAtom } from "../atoms/cart";
import { userAtom, refreshUserAtom } from "../atoms/auth";
import StarRating from "../components/StarRating";
import QuantityBadge from "../components/QuantityBadge";
import { themeClasses, cn } from "../utils/theme";

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [ownedProducts, setOwnedProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [error, setError] = useState("");
  const [quantity, setQuantity] = useState(1);
  const [refundQuantity, setRefundQuantity] = useState(1);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [reviewError, setReviewError] = useState("");
  const [reviewSuccess, setReviewSuccess] = useState("");
  const addToCart = useSetAtom(addToCartAtom);
  const user = useAtomValue(userAtom);
  const refreshUser = useSetAtom(refreshUserAtom);

  const productId = parseInt(id || "0");

  const fetchProduct = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await productsApi.getById(productId);

      if (response.success && response.data) {
        setProduct(response.data);
      } else {
        setError("Produkt nicht gefunden");
      }
    } catch (error: any) {
      setError(
        error.response?.data?.error ||
          "Es gab einen Fehler beim Laden des Produktes",
      );
    } finally {
      setLoading(false);
    }
  };

  const fetchReviews = async () => {
    try {
      setReviewsLoading(true);

      const response = await reviewsApi.getByProduct(productId);

      if (response.success && response.data) {
        setReviews(response.data);
      }
    } catch (error) {
      // Reviews might not be available, ignore error
    } finally {
      setReviewsLoading(false);
    }
  };

  const fetchOwnedProducts = async () => {
    if (!user) return;

    try {
      const response = await productsApi.getMine();
      if (response.success && response.data) {
        setOwnedProducts(response.data);
        // Reset refund quantity when owned products change
        const ownedProduct = response.data.find((p) => p.id === productId);
        if (ownedProduct && ownedProduct.quantity > 0) {
          setRefundQuantity(1);
        }
      }
    } catch (error) {
      // Ignore error
    }
  };

  useEffect(() => {
    if (productId) {
      fetchProduct();
      fetchReviews();
      fetchOwnedProducts();
    }
  }, [productId, user]);

  const handleAddToCart = async () => {
    if (!user) {
      toast.error(
        "Sie müssen eingeloggt sein um Produkte in ihren Einkaufswagen zu legen.",
      );
      return;
    }

    const result = await addToCart({ productId, quantity });
    if (result.success) {
      toast.success("Produkt wurde in Ihren Einkaufswagen gelegt!");
    } else {
      toast.error(result.error || "Es gab einen Fehler >...<");
    }
  };

  const handleRefund = async () => {
    if (!user) {
      toast.error(
        "Bitte melden Sie sich an, um eine Rückerstattung zu beantragen",
      );
      return;
    }

    const ownedProduct = ownedProducts.find((p) => p.id === productId);
    if (!ownedProduct) {
      toast.error("Sie besitzen dieses Produkt nicht");
      return;
    }

    try {
      const response = await productsApi.refundPartial(
        productId,
        refundQuantity,
      );
      if (response.success) {
        toast.success("Rückerstattung erfolgreich bearbeitet!");
        await refreshUser(); // Refresh user data to update balance
        await fetchOwnedProducts(); // Refresh owned products
      } else {
        toast.error(response.error || "Rückerstattung fehlgeschlagen");
      }
    } catch (error: any) {
      toast.error(
        error.response?.data?.error || "Rückerstattung fehlgeschlagen",
      );
    }
  };

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    setReviewError("");
    setReviewSuccess("");

    if (!user) {
      setReviewError(
        "Bitte melden Sie sich an, um eine Bewertung zu hinterlassen",
      );
      return;
    }

    try {
      const response = await reviewsApi.create(productId, {
        stars: reviewRating,
        description: reviewComment,
      });

      if (response.success) {
        setReviewSuccess("Bewertung erfolgreich eingereicht!");
        setReviewComment("");
        setReviewRating(5);
        fetchReviews(); // Refresh reviews
      } else {
        setReviewError(
          response.error || "Fehler beim Einreichen der Bewertung",
        );
      }
    } catch (error: any) {
      const errorMessage =
        error.response?.data?.error || "Fehler beim Einreichen der Bewertung";
      setReviewError(errorMessage);
    }
  };

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="text-center py-12">
          <div className="text-gray-600">Loading Produkt...</div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="text-center py-12">
          <div className="text-red-600 mb-4">
            {error || "Product not found"}
          </div>
          <button
            onClick={() => navigate("/products")}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md"
          >
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <button
        onClick={() => navigate("/products")}
        className="mb-6 text-blue-600 hover:text-blue-800 font-medium"
      >
        ← Back to Products
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
        <div>
          <img
            src={product.image_url ?? "/plfanzen.svg"}
            alt={product.name}
            className="w-full rounded-lg shadow-md"
          />
        </div>

        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {product.name}
            </h1>
            <p className="text-gray-600 text-lg">{product.description}</p>
          </div>

          <div className="flex items-center justify-between">
            <div className="text-3xl font-bold text-green-600">
              ${product.price.toFixed(2)}
            </div>
            <QuantityBadge quantity={product.quantity} size="lg" />
          </div>

          {user && product.quantity > 0 && (
            <div className="space-y-6 border-t pt-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  Purchase Options
                </h3>
                <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                  <div>
                    <label
                      htmlFor="quantity"
                      className="block text-sm font-medium text-gray-700 mb-2"
                    >
                      Quantity to purchase:
                    </label>
                    <select
                      id="quantity"
                      value={quantity}
                      onChange={(e) => setQuantity(parseInt(e.target.value))}
                      className="w-full sm:w-auto border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    >
                      {Array.from(
                        { length: Math.min(product.quantity, 10) },
                        (_, i) => i + 1,
                      ).map((num) => (
                        <option key={num} value={num}>
                          {num} {num === 1 ? "unit" : "units"}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    className="w-full bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-md font-medium transition-colors"
                  >
                    In den Einkaufswagen legen - $
                    {(product.price * quantity).toFixed(2)}
                  </button>
                </div>
              </div>

              {(() => {
                const ownedProduct = ownedProducts.find(
                  (p) => p.id === productId,
                );
                if (ownedProduct && ownedProduct.quantity > 0) {
                  return (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Refund Options
                      </h3>
                      <div className="bg-blue-50 rounded-lg p-4 space-y-4">
                        <p className="text-sm text-blue-700">
                          You own {ownedProduct.quantity} unit
                          {ownedProduct.quantity === 1 ? "" : "s"} of this
                          product
                        </p>
                        <div className="bg-amber-50 border border-amber-200 rounded p-2 mb-3">
                          <p className="text-xs text-amber-700">
                            💡 Refund Policy: You will receive 10% of the
                            original purchase price
                          </p>
                        </div>
                        <div>
                          <label
                            htmlFor="refundQuantity"
                            className="block text-sm font-medium text-gray-700 mb-2"
                          >
                            Quantity to refund:
                          </label>
                          <select
                            id="refundQuantity"
                            value={refundQuantity}
                            onChange={(e) =>
                              setRefundQuantity(parseInt(e.target.value))
                            }
                            className="w-full sm:w-auto border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          >
                            {Array.from(
                              { length: ownedProduct.quantity },
                              (_, i) => i + 1,
                            ).map((num) => (
                              <option key={num} value={num}>
                                {num} {num === 1 ? "unit" : "units"}
                              </option>
                            ))}
                          </select>
                        </div>
                        <button
                          onClick={handleRefund}
                          className="w-full bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-3 rounded-md font-medium transition-colors"
                        >
                          Request Refund - $
                          {(product.price * refundQuantity * 0.1).toFixed(2)}{" "}
                          (10% of purchase price)
                        </button>
                      </div>
                    </div>
                  );
                }
                return null;
              })()}
            </div>
          )}

          {user && product.quantity === 0 && (
            <div className="border-t pt-6">
              <div className="bg-red-50 rounded-lg p-4 text-center">
                <p className="text-red-600 font-medium">
                  Dieses Produkt ist derzeit nicht vorrätig.
                </p>
              </div>
            </div>
          )}

          {!user && (
            <div className="border-t pt-6">
              <div className="bg-gray-50 rounded-lg p-4 text-center">
                <p className="text-gray-600 mb-4">
                  Bitte melden Sie sich an, um dieses Produkt zu kaufen.
                </p>
                <button
                  onClick={() => navigate("/login")}
                  className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-md font-medium transition-colors"
                >
                  Anmelden
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Reviews Section */}
      <div className="border-t pt-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Bewertungen</h2>

        {/* Submit Review Form */}
        {user && (
          <div className="bg-gray-50 rounded-lg p-6 mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Eine Bewertung hinterlassen
            </h3>

            {reviewError && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                {reviewError}
              </div>
            )}

            {reviewSuccess && (
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4">
                {reviewSuccess}
              </div>
            )}

            <form onSubmit={handleSubmitReview} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Bewertung:
                </label>
                <StarRating
                  rating={reviewRating}
                  onRatingChange={setReviewRating}
                  size="lg"
                  interactive={true}
                />
              </div>

              <div>
                <label
                  htmlFor="comment"
                  className="block text-sm font-medium text-gray-700"
                >
                  Kommentar:
                </label>
                <textarea
                  id="comment"
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md px-3 py-2"
                  rows={4}
                  required
                />
              </div>

              <button
                type="submit"
                className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md font-medium"
              >
                Bewertung abgeben
              </button>
            </form>
          </div>
        )}

        {/* Reviews List */}
        {reviewsLoading ? (
          <div className="text-center py-4">
            <div className="text-gray-600">Loading Bewertungen...</div>
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-gray-600">
              Noch keine Bewertungen. Seien Sie der Erste, der eine Bewertung
              abgibt!
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {reviews.map((review) => (
              <div key={review.id} className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className="font-semibold text-gray-900">
                    {review.username}
                  </div>
                  <StarRating rating={review.stars} size="md" />
                </div>
                <p className="text-gray-600 leading-relaxed">
                  {review.description}
                </p>
                <div className="text-sm text-gray-500 mt-3">
                  {new Date(review.createdAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
