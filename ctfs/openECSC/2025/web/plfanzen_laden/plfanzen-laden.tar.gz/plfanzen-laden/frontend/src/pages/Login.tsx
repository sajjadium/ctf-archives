import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSetAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { loginAtom } from '../atoms/auth';

const Login: React.FC = () => {
  const { t } = useTranslation();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const login = useSetAtom(loginAtom);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const result = await login({ username, password });

    if (result.success) {
      navigate("/");
    } else {
      setError(result.error || t('auth.loginError'));
    }

    setLoading(false);
  };

  return (
    <div className="app-page">
      <div className="app-card-padded max-w-md w-full space-y-8">
        <div>
          <h2 className="app-heading-lg mt-6 text-center">
            {t('auth.loginTitle')}
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="app-alert-error">
              {error}
            </div>
          )}

          <div className="rounded-md shadow-sm space-y-4">
            <div>
              <label
                htmlFor="username"
                className="app-label"
              >
                {t('auth.username')}
              </label>
              <input
                id="username"
                name="username"
                type="text"
                required
                className="app-input"
                placeholder={t('auth.username')}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="app-label"
              >
                {t('auth.password')}
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="app-input"
                placeholder={t('auth.password')}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="app-btn-primary w-full"
            >
              {loading ? t('auth.loginButtonLoading') : t('auth.loginButton')}
            </button>
          </div>

          <div className="text-center">
            <Link
              to="/register"
              className="app-link font-medium"
            >
              {t('auth.noAccount')}
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;
