// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
}

// User Types
export interface User {
  id: number;
  username: string;
  email: string;
  premium: boolean;
  balance: number;
}

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
}

// Product Types
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  image_url?: string;
  created_at: string;
  updated_at: string;
}

export interface ProductSearchParams {
  q?: string;
  limit?: number;
  offset?: number;
}

// Cart Types
export interface CartItem {
  id: number;
  user_id: number;
  product_id: number;
  quantity: number;
  product: Product;
}

export interface AddToCartRequest {
  product_id: number;
  quantity: number;
}

// Review Types
export interface Review {
  id: number;
  userId: number;
  productId: number;
  stars: number;
  description: string;
  createdAt: string;
  username: string;
}

export interface CreateReviewRequest {
  stars: number;
  description: string;
}

// Transaction Types
export interface PurchaseRequest {
  items: Array<{
    product_id: number;
    quantity: number;
  }>;
}

export interface RefundRequest {
  product_id: number;
  quantity: number;
}
