import React from "react";

interface QuantityBadgeProps {
  quantity: number;
  size?: "sm" | "md" | "lg";
}

const QuantityBadge: React.FC<QuantityBadgeProps> = ({
  quantity,
  size = "md",
}) => {
  const getVariant = () => {
    if (quantity === 0) return "bg-red-100 text-red-800 border-red-200";
    if (quantity <= 3) return "bg-orange-100 text-orange-800 border-orange-200";
    if (quantity <= 10) {
      return "bg-yellow-100 text-yellow-800 border-yellow-200";
    }
    return "bg-green-100 text-green-800 border-green-200";
  };

  const getSizeClasses = () => {
    switch (size) {
      case "sm":
        return "px-2 py-0.5 text-xs";
      case "lg":
        return "px-4 py-2 text-base";
      default:
        return "px-3 py-1 text-sm";
    }
  };

  const getText = () => {
    if (quantity === 0) return "Nicht vorrätig";
    if (quantity === 1) return "Der Letzte!";
    if (quantity <= 3) return `Nur noch ${quantity} verfügbar`;
    if (quantity <= 10) return `${quantity} auf Lager`;
    return `${quantity}+ verfügbar`;
  };

  return (
    <span
      className={`
      inline-flex items-center rounded-full border font-medium
      ${getVariant()}
      ${getSizeClasses()}
    `}
    >
      {getText()}
    </span>
  );
};

export default QuantityBadge;
