import React from 'react';
import { themeClasses, cn } from '../utils/theme';

interface FormContainerProps {
  children: React.ReactNode;
  className?: string;
}

export const FormContainer: React.FC<FormContainerProps> = ({ 
  children, 
  className 
}) => {
  return (
    <div className={cn("min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8", themeClasses.bg.secondary)}>
      <div className={cn("max-w-md w-full space-y-8 p-8 rounded-lg", themeClasses.card, className)}>
        {children}
      </div>
    </div>
  );
};

interface FormFieldProps {
  label: string;
  htmlFor: string;
  children: React.ReactNode;
}

export const FormField: React.FC<FormFieldProps> = ({ 
  label, 
  htmlFor, 
  children 
}) => {
  return (
    <div>
      <label
        htmlFor={htmlFor}
        className={cn("block text-sm font-medium", themeClasses.text.secondary)}
      >
        {label}
      </label>
      {children}
    </div>
  );
};

interface ThemedInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  className?: string;
}

export const ThemedInput: React.FC<ThemedInputProps> = ({ 
  className, 
  ...props 
}) => {
  return (
    <input
      {...props}
      className={cn("mt-1 appearance-none relative block w-full px-3 py-2 rounded-md focus:outline-none focus:ring-1 sm:text-sm", themeClasses.input, className)}
    />
  );
};

interface ThemedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'success' | 'danger' | 'outline';
  className?: string;
}

export const ThemedButton: React.FC<ThemedButtonProps> = ({ 
  variant = 'primary',
  className,
  children,
  ...props 
}) => {
  return (
    <button
      {...props}
      className={cn("px-4 py-2 text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500", themeClasses.button[variant], className)}
    >
      {children}
    </button>
  );
};

interface ErrorMessageProps {
  message: string;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ message }) => {
  return (
    <div className={cn("px-4 py-3 rounded border", themeClasses.status.error)}>
      {message}
    </div>
  );
};

interface SuccessMessageProps {
  message: string;
}

export const SuccessMessage: React.FC<SuccessMessageProps> = ({ message }) => {
  return (
    <div className={cn("px-4 py-3 rounded border", themeClasses.status.success)}>
      {message}
    </div>
  );
};