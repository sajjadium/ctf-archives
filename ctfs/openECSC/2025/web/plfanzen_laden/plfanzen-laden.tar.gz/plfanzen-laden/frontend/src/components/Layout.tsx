import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useAtomValue, useSetAtom } from "jotai";
import { userAtom, logoutAtom } from "../atoms/auth";
import { cartItemsAtom, refreshCartAtom } from "../atoms/cart";
import SettingsModal from "./SettingsModal";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { t } = useTranslation();
  const user = useAtomValue(userAtom);
  const items = useAtomValue(cartItemsAtom);
  const logout = useSetAtom(logoutAtom);
  const refreshCart = useSetAtom(refreshCartAtom);
  const navigate = useNavigate();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Refresh cart when user changes
  useEffect(() => {
    if (user) {
      refreshCart();
    }
  }, [user, refreshCart]);

  const handleLogout = async () => {
    logout();
    navigate("/");
  };

  const cartItemCount = items.reduce((total, item) => total + item.quantity, 0);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <nav className="bg-white dark:bg-gray-800 shadow-sm border-b dark:border-gray-700">
        <div className="mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Link
                to="/"
                className="text-xl font-bold text-gray-900 dark:text-white"
              >
                {t("app.name")}
              </Link>
            </div>

            <div className="flex items-center space-x-6">
              <Link
                to="/products"
                className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
              >
                {t("nav.products")}
              </Link>

              {user ? (
                <>
                  <Link
                    to="/cart"
                    className="relative text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
                  >
                    {t("nav.cart")}
                    {cartItemCount > 0 && (
                      <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        {cartItemCount}
                      </span>
                    )}
                  </Link>

                  <div className="flex items-center space-x-4">
                    <div className="text-sm text-gray-600 dark:text-gray-300">
                      <span className="font-medium">{user.username}</span>
                      {user.premium && (
                        <span className="ml-2 px-2 py-1 bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-300 text-xs rounded-full">
                          {t("settings.account.premium")}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">
                      {t("home.balance")}:{" "}
                      <span className="font-medium text-green-600 dark:text-green-400">
                        ${user.balance.toFixed(2)}
                      </span>
                    </div>
                    <button
                      onClick={() => setIsSettingsOpen(true)}
                      className="bg-gray-500 hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-700 text-white px-3 py-2 rounded-md text-sm font-medium"
                      title={t("nav.settings")}
                    >
                      ⚙️
                    </button>
                    <button
                      onClick={handleLogout}
                      className="bg-red-500 hover:bg-red-600 dark:bg-red-600 dark:hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                    >
                      {t("auth.logout")}
                    </button>
                  </div>
                </>
              ) : (
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="bg-gray-500 hover:bg-gray-600 dark:bg-gray-600 dark:hover:bg-gray-700 text-white px-3 py-2 rounded-md text-sm font-medium"
                    title={t("nav.settings")}
                  >
                    ⚙️
                  </button>
                  <Link
                    to="/login"
                    className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white px-3 py-2 rounded-md text-sm font-medium"
                  >
                    {t("auth.login")}
                  </Link>
                  <Link
                    to="/register"
                    className="bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                  >
                    {t("auth.register")}
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </nav>

      <main className="mx-auto py-6 sm:px-6 lg:px-8">{children}</main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </div>
  );
};

export default Layout;
