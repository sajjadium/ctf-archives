import { atom } from 'jotai';
import type { User } from '../types/api';
import { authApi } from '../services/api';

// Base atoms for auth state
export const userAtom = atom<User | null>(null);
export const authLoadingAtom = atom<boolean>(true);

// Derived atom for checking if user is authenticated
export const isAuthenticatedAtom = atom((get) => get(userAtom) !== null);

// Action atoms for auth operations
export const loginAtom = atom(
  null,
  async (_get, set, { username, password }: { username: string; password: string }) => {
    try {
      console.log("Auth atom: Starting login...");
      const response = await authApi.login({ username, password });
      console.log("Auth atom: Login response:", response);

      if (response.success && response.data) {
        set(userAtom, response.data);
        console.log("Auth atom: User set:", response.data);
        return { success: true };
      } else {
        console.log("Auth atom: Login failed:", response.error);
        return { success: false, error: response.error || "Anmeldung fehlgeschlagen" };
      }
    } catch (error: any) {
      console.log("Auth atom: Login error:", error);
      return {
        success: false,
        error: error.response?.data?.error || "Anmeldung fehlgeschlagen",
      };
    }
  }
);

export const registerAtom = atom(
  null,
  async (_get, _set, { username, email, password }: { username: string; email: string; password: string }) => {
    try {
      console.log("Auth atom: Starting registration...");
      const response = await authApi.register({ username, email, password });
      console.log("Auth atom: Register response:", response);

      if (response.success && response.data) {
        console.log("Auth atom: User set:", response.data);
        return { success: true };
      } else {
        console.log("Auth atom: Registration failed:", response.error);
        return {
          success: false,
          error: response.error || "Registrierung fehlgeschlagen",
        };
      }
    } catch (error: any) {
      console.log("Auth atom: Registration error:", error);
      return {
        success: false,
        error: error.response?.data?.error || "Registrierung fehlgeschlagen",
      };
    }
  }
);

export const logoutAtom = atom(
  null,
  async (_get, set) => {
    try {
      await authApi.logout();
    } catch (error) {
      // Ignore logout errors
    } finally {
      set(userAtom, null);
    }
  }
);

export const refreshUserAtom = atom(
  null,
  async (_get, set) => {
    try {
      const response = await authApi.me();
      if (response.success && response.data) {
        set(userAtom, response.data);
      } else {
        set(userAtom, null);
      }
    } catch (error) {
      set(userAtom, null);
    } finally {
      set(authLoadingAtom, false);
    }
  }
);