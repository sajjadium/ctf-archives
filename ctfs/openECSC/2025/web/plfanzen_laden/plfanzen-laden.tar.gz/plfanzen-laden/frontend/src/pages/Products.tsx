import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useAtomValue, useSetAtom } from 'jotai';
import type { Product } from "../types/api";
import { productsApi } from "../services/api";
import { addToCartAtom } from '../atoms/cart';
import { userAtom } from '../atoms/auth';
import QuantityBadge from "../components/QuantityBadge";

const Products: React.FC = () => {
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [error, setError] = useState("");
  const addToCart = useSetAtom(addToCartAtom);
  const user = useAtomValue(userAtom);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      setError("");

      const response = await productsApi.getAll({ limit: 50 });

      if (response.success && response.data) {
        setAllProducts(response.data);
        setFilteredProducts(response.data);
      } else {
        setError("Fehler beim Laden der Produkte");
        setAllProducts([]);
        setFilteredProducts([]);
      }
    } catch (error: any) {
      setError(error.response?.data?.error || "Fehler beim Laden der Produkte");
      setAllProducts([]);
      setFilteredProducts([]);
    } finally {
      setLoading(false);
    }
  };

  const filterProducts = (query: string) => {
    if (!query.trim()) {
      setFilteredProducts(allProducts);
    } else {
      const filtered = allProducts.filter(
        (product) =>
          product.name.toLowerCase().includes(query.toLowerCase()) ||
          product.description.toLowerCase().includes(query.toLowerCase()),
      );
      setFilteredProducts(filtered);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  useEffect(() => {
    filterProducts(searchQuery);
  }, [searchQuery, allProducts]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    filterProducts(searchQuery);
  };

  const handleAddToCart = async (productId: number) => {
    if (!user) {
      toast.error(
        "Sie müssen sich einloggen um etwas in Ihren Wahrenkorb zu legen.",
      );
      return;
    }

    const result = await addToCart({ productId, quantity: 1 });
    if (result.success) {
      toast.success("Produkt wurde in Ihren Einkaufswagen gelegt!");
    } else {
      toast.error(
        result.error ||
          "Es ist ein Fehler aufgetreten, das Produkt befindet sich nicht in ihrem Einkaufswagen.",
      );
    }
  };

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Produkte</h1>

        {/* Search Form */}
        <form onSubmit={handleSearch} className="max-w-md mx-auto">
          <div className="flex">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Produkte suchen..."
              className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-l-md bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              type="submit"
              className="bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 text-white px-6 py-2 rounded-r-md transition-colors"
            >
              Suchen
            </button>
          </div>
        </form>
      </div>

      {error && (
        <div className="bg-red-100 dark:bg-red-900/30 border border-red-400 dark:border-red-600 text-red-700 dark:text-red-300 px-4 py-3 rounded mb-6">
          {error}
        </div>
      )}

      {loading ? (
        <div className="text-center py-12">
          <div className="text-gray-600 dark:text-gray-400">Loading Produkte...</div>
        </div>
      ) : filteredProducts.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-gray-600 dark:text-gray-400">
            {searchQuery
              ? `No products found for "${searchQuery}"`
              : "No products available"}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow"
            >
              <img
                src={product.image_url ?? "/plfanzen.svg"}
                alt={product.name}
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex-1">
                    {product.name}
                  </h3>
                  <QuantityBadge quantity={product.quantity} size="sm" />
                </div>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                  {product.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-green-600 dark:text-green-400">
                    ${product.price.toFixed(2)}
                  </span>
                  <div className="flex space-x-2">
                    <Link
                      to={`/products/${product.id}`}
                      className="bg-blue-500 hover:bg-blue-600 dark:bg-blue-600 dark:hover:bg-blue-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                    >
                      Anschauen
                    </Link>
                    {user && product.quantity > 0 && (
                      <button
                        onClick={() => handleAddToCart(product.id)}
                        className="bg-green-500 hover:bg-green-600 dark:bg-green-600 dark:hover:bg-green-700 text-white px-3 py-1 rounded text-sm font-medium transition-colors"
                      >
                        In den Einkaufswagen
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Products;
