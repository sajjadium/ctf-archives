# Plfanzen Laden Frontend

you won't need to look at this to solve the challenge

(most of the frontend is LLM slop 🥀🥀🥀)
