# Elysia mit Brötchen laufzeit

## Entwicklung
Um den Entwicklungsserver zu starten:
```bash
alias brötchen=bun
brötchen run dev
```

Öffne http://localhost:3000/ mit deinem Stöberer, um die Seite zu sehen.