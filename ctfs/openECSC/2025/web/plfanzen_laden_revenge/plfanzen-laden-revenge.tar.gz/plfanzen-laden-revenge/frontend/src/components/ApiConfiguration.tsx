import React, { useState } from "react";
import { updateApiBaseUrl, validateApiConnection } from "../services/api";

interface ApiConfigurationProps {
  onSuccess?: (url: string) => void;
  showTitle?: boolean;
  className?: string;
}

const ApiConfiguration: React.FC<ApiConfigurationProps> = ({ 
  onSuccess, 
  showTitle = true,
  className = "" 
}) => {
  const [apiUrl, setApiUrl] = useState(() => 
    localStorage.getItem("PLFANZEN_API_URL") || "http://localhost:3000"
  );
  const [testing, setTesting] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleTest = async () => {
    setError("");
    setSuccessMessage("");

    if (!apiUrl.trim()) {
      setError("Bitte geben Sie eine gültige URL ein.");
      return;
    }

    try {
      new URL(apiUrl);
    } catch {
      setError("Bitte geben Sie eine gültige URL ein (z.B. http://localhost:3000).");
      return;
    }

    setTesting(true);
    try {
      const validationResult = await validateApiConnection(apiUrl.trim());
      
      if (!validationResult.success) {
        setError(validationResult.error || "API-Verbindung fehlgeschlagen");
        return;
      }

      setSuccessMessage("API-Verbindung erfolgreich!");
      localStorage.setItem("PLFANZEN_API_URL", apiUrl.trim());
      updateApiBaseUrl();
      
      if (onSuccess) {
        setTimeout(() => {
          onSuccess(apiUrl.trim());
        }, 1000);
      }
      
    } catch (error: any) {
      setError(`Verbindungstest fehlgeschlagen: ${error.message || "Unbekannter Fehler"}`);
    } finally {
      setTesting(false);
    }
  };

  const handleUseDefault = async () => {
    const defaultUrl = "http://localhost:3000";
    setApiUrl(defaultUrl);
    setError("");
    setSuccessMessage("");
    
    setTesting(true);
    try {
      const validationResult = await validateApiConnection(defaultUrl);
      
      if (!validationResult.success) {
        setError(validationResult.error || "Standard-API ist nicht erreichbar");
        return;
      }

      setSuccessMessage("Standard-API-Verbindung erfolgreich!");
      localStorage.setItem("PLFANZEN_API_URL", defaultUrl);
      updateApiBaseUrl();
      
      if (onSuccess) {
        setTimeout(() => {
          onSuccess(defaultUrl);
        }, 1000);
      }
      
    } catch (error: any) {
      setError(`Verbindungstest fehlgeschlagen: ${error.message || "Unbekannter Fehler"}`);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className={`space-y-6 ${className}`}>
            {showTitle && (
        <div className="mb-6">
          <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">API-Konfiguration</h4>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Bitte geben Sie die API-URL ein. Die Verbindung wird automatisch getestet.
          </p>
        </div>
      )}

      <div>
        <label htmlFor="apiUrl" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          API-URL
        </label>
        <input
          id="apiUrl"
          type="url"
          value={apiUrl}
          onChange={(e) => {
            setApiUrl(e.target.value);
            setError("");
            setSuccessMessage("");
          }}
          placeholder="http://localhost:3000"
          className="block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
        />
        {error && <p className="mt-2 text-sm text-red-600 dark:text-red-400">{error}</p>}
        {successMessage && <p className="mt-2 text-sm text-green-600 dark:text-green-400">{successMessage}</p>}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={handleTest}
          disabled={testing}
          className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 dark:bg-green-600 dark:hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
        >
          {testing ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              API wird getestet...
            </>
          ) : (
            'API-URL testen und speichern'
          )}
        </button>

        <button
          onClick={handleUseDefault}
          disabled={testing}
          className="flex-1 inline-flex justify-center items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
        >
          {testing ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-gray-700 dark:text-gray-300" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
              </svg>
              Wird getestet...
            </>
          ) : (
            'Standard-URL verwenden (localhost:3000)'
          )}
        </button>
      </div>

      <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-md">
        <h5 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Aktuelle Konfiguration</h5>
        <p className="text-sm text-gray-600 dark:text-gray-300">
          <strong>API-URL:</strong> {localStorage.getItem("PLFANZEN_API_URL") || "Nicht gesetzt"}
        </p>
      </div>
    </div>
  );
};

export default ApiConfiguration;