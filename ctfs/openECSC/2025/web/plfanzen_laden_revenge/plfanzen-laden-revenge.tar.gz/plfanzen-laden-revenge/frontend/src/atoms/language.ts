import { atom } from "jotai";
import i18n from "../i18n";

export type Language = "en" | "de";

// Language preference atom (stored in localStorage)
export const languageAtom = atom<Language>("en");

// Atom to persist language to localStorage and update i18n
export const persistedLanguageAtom = atom(
  () => {
    if (typeof window !== "undefined") {
      const stored = localStorage.getItem("language") as Language;
      if (stored && ["en", "de"].includes(stored)) {
        return stored;
      }
    }
    return "de" as Language;
  },
  (_get, set, newLanguage: Language) => {
    set(languageAtom, newLanguage);
    if (typeof window !== "undefined") {
      localStorage.setItem("language", newLanguage);
    }
    // Update i18n language
    i18n.changeLanguage(newLanguage);
  },
);

// Initialize language from localStorage on app start
export const initLanguageAtom = atom(null, (get, set) => {
  const storedLanguage = get(persistedLanguageAtom);
  set(languageAtom, storedLanguage);
});
