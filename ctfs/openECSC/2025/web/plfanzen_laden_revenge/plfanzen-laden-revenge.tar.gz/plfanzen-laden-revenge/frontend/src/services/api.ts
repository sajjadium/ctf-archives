import axios from "axios";
import type {
  AddToCartRequest,
  ApiResponse,
  CartItem,
  CreateReviewRequest,
  LoginRequest,
  Product,
  ProductSearchParams,
  RefundRequest,
  RegisterRequest,
  Review,
  User,
} from "../types/api";

// Get API base URL from localStorage or fallback to default
const getApiBaseUrl = (): string => {
  return localStorage.getItem("PLFANZEN_API_URL") || "http://localhost:3000";
};

// Create axios instance with credentials
const createApiInstance = () => {
  return axios.create({
    baseURL: getApiBaseUrl(),
    withCredentials: true, // Important for session cookies
    headers: {
      "Content-Type": "application/json",
    },
  });
};

// Create initial api instance
let api = createApiInstance();

// Function to update the API base URL (useful when URL changes)
export const updateApiBaseUrl = () => {
  api = createApiInstance();
};

// Function to validate API connectivity
export const validateApiConnection = async (testUrl?: string): Promise<{ 
  success: boolean; 
  error?: string; 
  version?: string;
}> => {
  try {
    // Create a temporary axios instance for testing if URL is provided
    const testApi = testUrl ? axios.create({
      baseURL: testUrl,
      withCredentials: true,
      timeout: 5000, // 5 second timeout
      headers: {
        "Content-Type": "application/json",
      },
    }) : api;

    // Try to hit a basic health check endpoint or any simple endpoint
    // Let's try the users/me endpoint as it's a simple GET request
    const response = await testApi.get("/users/me");
    
    // If we get any response (even 401 unauthorized), the API is reachable
    return { 
      success: true,
      version: response.headers?.['x-api-version'] || 'unknown'
    };
  } catch (error: any) {
    // Check if it's a network/connection error vs an API error
    if (error.code === 'ECONNREFUSED' || 
        error.code === 'ENOTFOUND' || 
        error.code === 'ECONNABORTED' ||
        error.message?.includes('Network Error') ||
        error.message?.includes('timeout')) {
      return {
        success: false,
        error: 'API ist nicht erreichbar. Überprüfen Sie die URL und stellen Sie sicher, dass der Server läuft.'
      };
    }
    
    // If we get a 401, 404, or other HTTP errors, the API is reachable
    if (error.response?.status) {
      return { 
        success: true,
        version: error.response.headers?.['x-api-version'] || 'unknown'
      };
    }
    
    // Unknown error
    return {
      success: false,
      error: `Verbindungsfehler: ${error.message || 'Unbekannter Fehler'}`
    };
  }
};

// Add response interceptor for debugging
api.interceptors.response.use(
  (response) => {
    console.log("API Response:", response.status, response.data);
    return response;
  },
  (error) => {
    console.log("API Error:", error.response?.status, error.response?.data);
    return Promise.reject(error);
  },
);

// Auth API
export const authApi = {
  login: async (data: LoginRequest): Promise<ApiResponse<User>> => {
    try {
      const response = await api.post("/auth/login", data);
      // Backend returns user object directly on success
      return { success: true, data: response.data };
    } catch (error: any) {
      if (error.response?.status === 400) {
        return {
          success: false,
          error: error.response.data?.error || "Login failed",
        };
      }
      throw error;
    }
  },

  register: async (data: RegisterRequest): Promise<ApiResponse<User>> => {
    try {
      const response = await api.post("/auth/signup", data);
      // Backend returns user object directly on success
      return { success: true, data: response.data };
    } catch (error: any) {
      if (error.response?.status === 400) {
        return {
          success: false,
          error: error.response.data?.error || "Registration failed",
        };
      }
      throw error;
    }
  },

  // Note: No logout endpoint in backend, session expires automatically
  logout: async (): Promise<ApiResponse> => {
    // Clear session by making request that will fail, or just return success
    return { success: true };
  },

  // Me endpoint is in users router
  me: async (): Promise<ApiResponse<User>> => {
    try {
      const response = await api.get("/users/me");
      // Backend returns user object directly on success
      return { success: true, data: response.data };
    } catch (error: any) {
      if (error.response?.status === 401) {
        return { success: false, error: "Not authenticated" };
      }
      throw error;
    }
  },
};

// Products API
export const productsApi = {
  getAll: async (
    params?: ProductSearchParams,
  ): Promise<ApiResponse<Product[]>> => {
    try {
      const response = await api.get("/products", { params });
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch products",
      };
    }
  },

  getById: async (id: number): Promise<ApiResponse<Product>> => {
    try {
      const response = await api.get(`/products/${id}`);
      return { success: true, data: response.data };
    } catch (error: any) {
      if (error.response?.status === 404) {
        return { success: false, error: "Product not found" };
      }
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch product",
      };
    }
  },

  search: async (
    params: ProductSearchParams,
  ): Promise<ApiResponse<Product[]>> => {
    try {
      // Since backend doesn't have search endpoint, use getAll and filter client-side
      const response = await api.get("/products", { params });
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Search failed",
      };
    }
  },

  buy: async (id: number, quantity: number): Promise<ApiResponse> => {
    try {
      const response = await api.post(`/products/${id}/buy`, { quantity });
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Purchase failed",
      };
    }
  },

  refund: async (id: number): Promise<ApiResponse> => {
    try {
      const response = await api.post(`/products/${id}/refund-all`);
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Refund failed",
      };
    }
  },

  refundPartial: async (id: number, quantity: number): Promise<ApiResponse> => {
    try {
      const response = await api.post(`/products/${id}/refund`, { quantity });
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Refund failed",
      };
    }
  },

  getMine: async (): Promise<ApiResponse<Product[]>> => {
    try {
      const response = await api.get("/products/mine");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch owned products",
      };
    }
  },
};

// Cart API
export const cartApi = {
  get: async (): Promise<ApiResponse<CartItem[]>> => {
    try {
      const response = await api.get("/cart");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch cart",
      };
    }
  },

  add: async (data: AddToCartRequest): Promise<ApiResponse> => {
    try {
      const response = await api.post(`/cart/${data.product_id}`, {
        quantity: data.quantity,
      });
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to add to cart",
      };
    }
  },

  remove: async (_productId: number): Promise<ApiResponse> => {
    // Note: Backend doesn't have remove individual items, only clear
    try {
      const response = await api.post("/cart/clear");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to clear cart",
      };
    }
  },

  clear: async (): Promise<ApiResponse> => {
    try {
      const response = await api.post("/cart/clear");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to clear cart",
      };
    }
  },

  buy: async (): Promise<ApiResponse> => {
    try {
      const response = await api.post("/cart/checkout");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Checkout failed",
      };
    }
  },
};

// Users API
export const usersApi = {
  getMe: async (): Promise<ApiResponse<User>> => {
    try {
      const response = await api.get("/users/me");
      return { success: true, data: response.data };
    } catch (error: any) {
      if (error.response?.status === 401) {
        return { success: false, error: "Not authenticated" };
      }
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch user",
      };
    }
  },

  elevate: async (): Promise<ApiResponse> => {
    try {
      const response = await api.post("/users/elevate");
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to elevate account",
      };
    }
  },

  refund: async (data: RefundRequest): Promise<ApiResponse> => {
    try {
      const response = await api.post(
        `/products/${data.product_id}/refund-all`,
      );
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Refund failed",
      };
    }
  },
};

// Reviews API
export const reviewsApi = {
  getByProduct: async (productId: number): Promise<ApiResponse<Review[]>> => {
    try {
      const response = await api.get(`/reviews/product/${productId}`);
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to fetch reviews",
      };
    }
  },

  create: async (
    productId: number,
    data: CreateReviewRequest,
  ): Promise<ApiResponse<Review>> => {
    try {2
      const response = await api.post(`/reviews/product/${productId}`, data);
      return { success: true, data: response.data };
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Failed to create review",
      };
    }
  },
};

export default api;
