import React, { useState } from "react";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";
import { useAtomValue, useSetAtom } from 'jotai';
import { cartItemsAtom, cartTotalAtom, cartLoadingAtom, removeFromCartAtom, clearCartAtom, buyCartAtom } from '../atoms/cart';
import { userAtom, refreshUserAtom } from '../atoms/auth';
import ConfirmDialog from "../components/ConfirmDialog";

const Cart: React.FC = () => {
  const items = useAtomValue(cartItemsAtom);
  const total = useAtomValue(cartTotalAtom);
  const loading = useAtomValue(cartLoadingAtom);
  const removeFromCart = useSetAtom(removeFromCartAtom);
  const clearCart = useSetAtom(clearCartAtom);
  const buyCart = useSetAtom(buyCartAtom);
  const user = useAtomValue(userAtom);
  const refreshUser = useSetAtom(refreshUserAtom);
  const [purchasing, setPurchasing] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showPurchaseConfirm, setShowPurchaseConfirm] = useState(false);

  const handleRemoveItem = async (productId: number) => {
    const result = await removeFromCart(productId);
    if (!result.success) {
      toast.error(result.error || "Fehler beim Entfernen des Artikels");
    } else {
      toast.success("Artikel aus dem Einkaufswagen entfernt");
    }
  };

  const handleClearCart = async () => {
    const result = await clearCart();
    if (!result.success) {
      toast.error(result.error || "Fehler beim Leeren des Einkaufswagens");
    } else {
      toast.success("Einkaufswagen geleert");
    }
  };

  const handlePurchase = async () => {
    if (!user) {
      toast.error("Bitte melden Sie sich an, um einen Kauf zu tätigen");
      return;
    }

    if (user.balance < total) {
      toast.error("Unzureichendes Guthaben. Bitte fügen Sie Geld zu Ihrem Konto hinzu.");
      return;
    }

    setPurchasing(true);
    const result = await buyCart();

    if (result.success) {
      toast.success("Kauf erfolgreich!");
      refreshUser(); // Refresh user data to update balance
    } else {
      toast.error(result.error || "Kauf fehlgeschlagen");
    }

    setPurchasing(false);
  };

  if (!user) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="text-center py-12">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">
            Einkaufswagen
          </h1>
          <p className="text-gray-600 mb-6">Bitte melden Sie sich an, um Ihren Einkaufswagen zu sehen</p>
          <Link
            to="/login"
            className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-md font-medium"
          >
            Anmelden
          </Link>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="text-center py-12">
          <div className="text-gray-600">Einkaufswagen wird geladen...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Einkaufswagen</h1>
        {items.length > 0 && (
          <button
            onClick={() => setShowClearConfirm(true)}
            className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md font-medium"
          >
            Einkaufswagen leeren
          </button>
        )}
      </div>

      {items.length === 0
        ? (
          <div className="text-center py-12">
            <svg
              className="mx-auto h-12 w-12 text-gray-400 mb-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M3 3h2l.4 2M7 13h10l4-8H5.4m0 0L7 13m0 0l-2.5 5M7 13l2.5 5m6-5v6a2 2 0 11-4 0v-6m4 0V9a2 2 0 00-2-2H9a2 2 0 00-2 2v4.01"
              />
            </svg>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Ihr Einkaufswagen ist leer
            </h2>
            <p className="text-gray-600 mb-6">
              Beginnen Sie mit dem Einkaufen, um Artikel in Ihren Einkaufswagen zu legen
            </p>
            <Link
              to="/products"
              className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-md font-medium"
            >
              Produkte durchsuchen
            </Link>
          </div>
        )
        : (
          <div className="space-y-6">
            {/* Cart Items */}
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold text-gray-900">
                  Artikel in Ihrem Einkaufswagen
                </h2>
              </div>
              <div className="divide-y divide-gray-200">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="px-6 py-4 flex items-center justify-between"
                  >
                    <div className="flex items-center space-x-4">
                      {item.product.image_url && (
                        <img
                          src={item.product.image_url}
                          alt={item.product.name}
                          className="w-16 h-16 object-cover rounded-md"
                        />
                      )}
                      <div>
                        <Link
                          to={`/products/${item.product.id}`}
                          className="text-lg font-medium text-gray-900 hover:text-blue-600"
                        >
                          {item.product.name}
                        </Link>
                        <p className="text-gray-600">
                          ${item.product.price.toFixed(2)} each
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-4">
                      <div className="text-lg font-medium text-gray-900">
                        Menge: {item.quantity}
                      </div>
                      <div className="text-lg font-semibold text-green-600">
                        ${(item.product.price * item.quantity).toFixed(2)}
                      </div>
                      <button
                        onClick={() => handleRemoveItem(item.product_id)}
                        className="text-red-600 hover:text-red-800 font-medium"
                      >
                        Entfernen
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Cart Summary */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">
                    Bestellübersicht
                  </h2>
                  <p className="text-gray-600">
                    {items.reduce((total, item) => total + item.quantity, 0)}
                    {" "}
                    Artikel
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-green-600">
                    ${total.toFixed(2)}
                  </div>
                  <div className="text-sm text-gray-600">
                    Ihr Guthaben: ${user.balance.toFixed(2)}
                  </div>
                </div>
              </div>

              {user.balance < total && (
                <div className="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded mb-4">
                  Unzureichendes Guthaben. Sie benötigen ${(total - user.balance)
                    .toFixed(2)} mehr.
                </div>
              )}

              <button
                onClick={() => setShowPurchaseConfirm(true)}
                disabled={purchasing || user.balance < total}
                className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-400 disabled:cursor-not-allowed text-white py-3 px-6 rounded-md font-medium text-lg"
              >
                {purchasing
                  ? "Verarbeitung..."
                  : `Kaufen für $${total.toFixed(2)}`}
              </button>
            </div>
          </div>
        )}

      <ConfirmDialog
        isOpen={showClearConfirm}
        onClose={() => setShowClearConfirm(false)}
        onConfirm={handleClearCart}
        title="Einkaufswagen leeren"
        message="Sind Sie sicher, dass Sie alle Artikel aus Ihrem Einkaufswagen entfernen möchten?"
        confirmText="Einkaufswagen leeren"
        cancelText="Abbrechen"
        type="danger"
      />

      <ConfirmDialog
        isOpen={showPurchaseConfirm}
        onClose={() => setShowPurchaseConfirm(false)}
        onConfirm={handlePurchase}
        title="Kauf bestätigen"
        message={`Sind Sie sicher, dass Sie diese Artikel für $${
          total.toFixed(2)
        } kaufen möchten? Hinweis: Rückerstattungen betragen nur 10% des Kaufpreises.`}
        confirmText="Kaufen"
        cancelText="Abbrechen"
        type="info"
      />
    </div>
  );
};

export default Cart;
