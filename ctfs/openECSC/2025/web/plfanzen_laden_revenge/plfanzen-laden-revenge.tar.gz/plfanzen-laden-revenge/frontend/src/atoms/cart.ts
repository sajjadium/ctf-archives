import { atom } from 'jotai';
import type { CartItem } from '../types/api';
import { cartApi } from '../services/api';
import { userAtom } from './auth';

// Base atoms for cart state
export const cartItemsAtom = atom<CartItem[]>([]);
export const cartLoadingAtom = atom<boolean>(false);

// Derived atom for cart total
export const cartTotalAtom = atom((get) => {
  const items = get(cartItemsAtom);
  return items.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
});

// Action atoms for cart operations
export const refreshCartAtom = atom(
  null,
  async (get, set) => {
    const user = get(userAtom);
    
    if (!user) {
      set(cartItemsAtom, []);
      return;
    }

    try {
      set(cartLoadingAtom, true);
      const response = await cartApi.get();
      if (response.success && response.data) {
        set(cartItemsAtom, response.data);
      } else {
        set(cartItemsAtom, []);
      }
    } catch (error) {
      set(cartItemsAtom, []);
    } finally {
      set(cartLoadingAtom, false);
    }
  }
);

export const addToCartAtom = atom(
  null,
  async (_get, set, { productId, quantity }: { productId: number; quantity: number }) => {
    try {
      const response = await cartApi.add({ product_id: productId, quantity });
      if (response.success) {
        // Refresh cart after successful add
        await set(refreshCartAtom);
        return { success: true };
      } else {
        return {
          success: false,
          error: response.error || "Fehler beim Hinzufügen zum Einkaufswagen",
        };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Fehler beim Hinzufügen zum Einkaufswagen",
      };
    }
  }
);

export const removeFromCartAtom = atom(
  null,
  async (_get, set, productId: number) => {
    try {
      const response = await cartApi.remove(productId);
      if (response.success) {
        // Refresh cart after successful removal
        await set(refreshCartAtom);
        return { success: true };
      } else {
        return {
          success: false,
          error: response.error || "Fehler beim Entfernen aus dem Einkaufswagen",
        };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Fehler beim Entfernen aus dem Einkaufswagen",
      };
    }
  }
);

export const clearCartAtom = atom(
  null,
  async (_get, set) => {
    try {
      const response = await cartApi.clear();
      if (response.success) {
        // Refresh cart after successful clear
        await set(refreshCartAtom);
        return { success: true };
      } else {
        return {
          success: false,
          error: response.error || "Fehler beim Leeren des Einkaufswagens",
        };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Fehler beim Leeren des Einkaufswagens",
      };
    }
  }
);

export const buyCartAtom = atom(
  null,
  async (_get, set) => {
    try {
      const response = await cartApi.buy();
      if (response.success) {
        // Refresh cart after successful purchase
        await set(refreshCartAtom);
        return { success: true };
      } else {
        return { success: false, error: response.error || "Kauf fehlgeschlagen" };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.error || "Kauf fehlgeschlagen",
      };
    }
  }
);