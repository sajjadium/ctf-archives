import { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import { Provider, useSetAtom } from 'jotai';
import { refreshUserAtom } from './atoms/auth';
import { initLanguageAtom } from './atoms/language';
import { ThemeProvider } from './components/ThemeProvider';
import Layout from "./components/Layout";
import ApiConfig from "./components/ApiConfig";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Products from "./pages/Products";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import './i18n'; // Initialize i18n

// Component to initialize auth state and language
function AppInitializer() {
  const refreshUser = useSetAtom(refreshUserAtom);
  const initLanguage = useSetAtom(initLanguageAtom);
  
  useEffect(() => {
    refreshUser();
    initLanguage();
  }, [refreshUser, initLanguage]);
  
  return null;
}

function App() {
  const [apiUrl, setApiUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check if API URL is configured in localStorage
    const savedApiUrl = localStorage.getItem("PLFANZEN_API_URL");
    setApiUrl(savedApiUrl);
    setIsLoading(false);
  }, []);

  const handleApiUrlSet = (url: string) => {
    setApiUrl(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-gray-500 dark:text-gray-400">Lade Konfiguration...</div>
      </div>
    );
  }

  // If no API URL is configured, show the configuration screen
  if (!apiUrl) {
    return <ApiConfig onApiUrlSet={handleApiUrlSet} />;
  }

  // Render the main application
  return (
    <Provider>
      <ThemeProvider>
        <AppInitializer />
        <Router>
          <Layout>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/products" element={<Products />} />
              <Route path="/products/:id" element={<ProductDetail />} />
              <Route path="/cart" element={<Cart />} />
            </Routes>
          </Layout>
        </Router>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 3000,
            style: {
              background: "#363636",
              color: "#fff",
            },
          }}
        />
      </ThemeProvider>
    </Provider>
  );
}

export default App;
