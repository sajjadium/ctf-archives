import { useEffect } from 'react';
import { useAtom } from 'jotai';
import { actualThemeAtom, initThemeAtom } from '../atoms/theme';

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [actualTheme] = useAtom(actualThemeAtom);
  const [, initTheme] = useAtom(initThemeAtom);

  // Initialize theme from localStorage on mount
  useEffect(() => {
    initTheme();
  }, [initTheme]);

  // Apply theme class to document root
  useEffect(() => {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove('light', 'dark');
    
    // Add current theme class
    root.classList.add(actualTheme);
    
    // Also set data attribute for Tailwind dark mode
    if (actualTheme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [actualTheme]);

  // Listen for system theme changes when in 'auto' mode
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    
    const handleChange = () => {
      // This will trigger a re-render of actualThemeAtom
      // We don't need to do anything here as the atom will handle the logic
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  return <>{children}</>;
}