import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSetAtom } from 'jotai';
import { useTranslation } from 'react-i18next';
import { registerAtom } from '../atoms/auth';

const Register: React.FC = () => {
  const { t } = useTranslation();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const register = useSetAtom(registerAtom);
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    const result = await register({ username, email, password });

    if (result.success) {
      navigate("/login");
    } else {
      setError(result.error || t('auth.registerError'));
    }

    setLoading(false);
  };

  return (
    <div className="app-page">
      <div className="app-card-padded max-w-md w-full space-y-8">
        <div>
          <h2 className="app-heading-lg mt-6 text-center">
            {t('auth.registerTitle')}
          </h2>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="app-alert-error">
              {error}
            </div>
          )}

          <div className="rounded-md shadow-sm space-y-4">
            <div>
              <label
                htmlFor="username"
                className="app-label"
              >
                {t('auth.username')}
              </label>
              <input
                id="username"
                name="username"
                type="text"
                required
                className="app-input"
                placeholder={t('auth.username')}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="email"
                className="app-label"
              >
                {t('auth.email')}
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                className="app-input"
                placeholder={t('auth.emailAddress')}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label
                htmlFor="password"
                className="app-label"
              >
                {t('auth.password')}
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                className="app-input"
                placeholder={t('auth.password')}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              disabled={loading}
              className="app-btn-primary w-full"
            >
              {loading ? t('auth.registerButtonLoading') : t('auth.registerButton')}
            </button>
          </div>

          <div className="text-center">
            <Link
              to="/login"
              className="app-link font-medium"
            >
              {t('auth.haveAccount')}
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Register;
