import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import deTranslations from './locales/de.json';
import enTranslations from './locales/en.json';

const resources = {
  de: {
    translation: deTranslations
  },
  en: {
    translation: enTranslations
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: localStorage.getItem('language') || 'de', // Default to German
    fallbackLng: 'de',
    interpolation: {
      escapeValue: false // React already escapes values
    }
  });

export default i18n;