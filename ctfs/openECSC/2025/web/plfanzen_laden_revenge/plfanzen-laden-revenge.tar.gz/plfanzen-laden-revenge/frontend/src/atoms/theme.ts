import { atom } from 'jotai';

export type Theme = 'light' | 'dark' | 'auto';

// Theme preference atom (stored in localStorage)
export const themeAtom = atom<Theme>('light');

// Derived atom for the actual theme in use (considering system preference for 'auto')
export const actualThemeAtom = atom((get) => {
  const theme = get(themeAtom);
  
  if (theme === 'auto') {
    // Check system preference
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  }
  
  return theme;
});

// Atom to persist theme to localStorage
export const persistedThemeAtom = atom(
  () => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('theme') as Theme;
      if (stored && ['light', 'dark', 'auto'].includes(stored)) {
        return stored;
      }
    }
    return 'light' as Theme;
  },
  (_get, set, newTheme: Theme) => {
    set(themeAtom, newTheme);
    if (typeof window !== 'undefined') {
      localStorage.setItem('theme', newTheme);
    }
  }
);

// Initialize theme from localStorage on app start
export const initThemeAtom = atom(null, (get, set) => {
  const storedTheme = get(persistedThemeAtom);
  set(themeAtom, storedTheme);
});