import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import { useAtomValue, useSetAtom } from "jotai";
import { userAtom } from "../atoms/auth";
import { themeAtom, persistedThemeAtom, type Theme } from "../atoms/theme";
import {
  languageAtom,
  persistedLanguageAtom,
  type Language,
} from "../atoms/language";
import ApiConfiguration from "./ApiConfiguration";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type SettingsPanel = "api" | "account" | "preferences";

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose }) => {
  const { t } = useTranslation();
  const [activePanel, setActivePanel] = useState<SettingsPanel>("api");
  const user = useAtomValue(userAtom);

  if (!isOpen) return null;

  const panels = [
    { id: "api" as SettingsPanel, name: t("settings.api.title"), icon: "🔗" },
    {
      id: "preferences" as SettingsPanel,
      name: t("settings.preferences.title"),
      icon: "⚙️",
    },
  ];
  if (user) {
    panels.push({
      id: "account" as SettingsPanel,
      name: t("settings.account.title"),
      icon: "👤",
    });
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        {/* Background overlay */}
        <div
          className="fixed inset-0 bg-gray-500 dark:bg-gray-900 bg-opacity-75 dark:bg-opacity-75 transition-opacity"
          onClick={onClose}
        />

        {/* Modal panel */}
        <div className="inline-block align-bottom app-modal-content text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-5xl sm:w-full">
          {/* Header */}
          <div className="app-modal-header">
            <div className="flex items-center justify-between">
              <h3 className="app-heading-md">{t("settings.title")}</h3>
              <button
                onClick={onClose}
                className="app-btn-ghost p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400"
              >
                <span className="sr-only">{t("settings.close")}</span>
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              </button>
            </div>
          </div>

          {/* Content */}
          {/* Content area */}
          <div className="flex min-h-[500px]">
            {/* Sidebar */}
            <div className="app-modal-sidebar bg-gray-50 dark:bg-gray-700">
              <nav className="space-y-3">
                {panels.map((panel) => (
                  <button
                    key={panel.id}
                    onClick={() => setActivePanel(panel.id)}
                    className={`w-full flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors ${
                      activePanel === panel.id
                        ? "app-nav-link-active"
                        : "app-nav-link"
                    }`}
                  >
                    <span className="mr-4 text-lg">{panel.icon}</span>
                    <span className="truncate">{panel.name}</span>
                  </button>
                ))}
              </nav>
            </div>

            {/* Main content */}
            <div className="app-modal-content-area">
              {activePanel === "api" && <ApiConfigPanel />}
              {activePanel === "account" && <AccountPanel user={user} />}
              {activePanel === "preferences" && <PreferencesPanel />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// API Configuration Panel Component
const ApiConfigPanel: React.FC = () => {
  const { t } = useTranslation();

  const handleReload = () => {
    window.location.reload();
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
          {t("settings.api.description")}
        </p>
      </div>

      {/* Import the shared ApiConfiguration component */}
      <ApiConfiguration showTitle={true} />

      <div className="border-t dark:border-gray-600 pt-4">
        <button
          onClick={handleReload}
          className="inline-flex items-center px-4 py-2 border border-gray-300 dark:border-gray-600 text-sm font-medium rounded-md text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          {t("settings.api.reload")}
        </button>
      </div>
    </div>
  );
};

// Account Panel Component
const AccountPanel: React.FC<{ user: any }> = ({ user }) => {
  const { t } = useTranslation();

  return (
    <div className="space-y-6">
      <div>
        <h4 className="text-lg font-medium text-gray-900 dark:text-white mb-4">
          {t("settings.account.title")}
        </h4>
      </div>

      {user ? (
        <div className="space-y-6">
          <div className="app-form-group">
            <label className="app-label">
              {t("settings.account.username")}
            </label>
            <p className="app-text-primary">{user.username}</p>
          </div>

          <div className="app-form-group">
            <label className="app-label">{t("settings.account.email")}</label>
            <p className="app-text-primary">
              {user.email || t("settings.account.notAvailable")}
            </p>
          </div>

          <div className="app-form-group">
            <label className="app-label">{t("settings.account.balance")}</label>
            <p className="font-medium text-green-600 dark:text-green-400">
              ${user.balance?.toFixed(2) || "0.00"}
            </p>
          </div>

          <div className="app-form-group">
            <label className="app-label">{t("settings.account.status")}</label>
            <div className="mt-1">
              {user.premium ? (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                  {t("settings.account.premium")}
                </span>
              ) : (
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                  {t("settings.account.standard")}
                </span>
              )}
            </div>
          </div>
        </div>
      ) : (
        <p className="app-text-muted">{t("settings.account.notLoggedIn")}</p>
      )}
    </div>
  );
};

// Preferences Panel Component
const PreferencesPanel: React.FC = () => {
  const { t } = useTranslation();
  const theme = useAtomValue(themeAtom);
  const language = useAtomValue(languageAtom);
  const setPersistedTheme = useSetAtom(persistedThemeAtom);
  const setPersistedLanguage = useSetAtom(persistedLanguageAtom);

  const handleThemeChange = (newTheme: string) => {
    setPersistedTheme(newTheme as Theme);
  };

  const handleLanguageChange = (newLanguage: string) => {
    setPersistedLanguage(newLanguage as Language);
  };

  return (
    <div className="space-y-8">
      <div>
        <h4 className="app-heading-md mb-6">
          {t("settings.preferences.title")}
        </h4>
      </div>

      <div className="app-form-group-lg">
        <label className="app-label">{t("settings.preferences.theme")}</label>
        <select
          value={theme}
          onChange={(e) => handleThemeChange(e.target.value)}
          className="app-select"
        >
          <option value="light">{t("settings.preferences.light")}</option>
          <option value="dark">{t("settings.preferences.dark")}</option>
          <option value="auto">{t("settings.preferences.auto")}</option>
        </select>
      </div>

      <div className="app-form-group-lg">
        <label className="app-label">
          {t("settings.preferences.language")}
        </label>
        <select
          value={language}
          onChange={(e) => handleLanguageChange(e.target.value)}
          className="app-select"
        >
          <option value="de">{t("settings.preferences.german")}</option>
          <option value="en">{t("settings.preferences.english")}</option>
        </select>
      </div>

      <div className="app-alert-warning p-6 rounded-md">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg
              className="h-5 w-5 text-yellow-400"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z"
                clipRule="evenodd"
              />
            </svg>
          </div>
          <div className="ml-3">
            <h3 className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
              {t("settings.preferences.note")}
            </h3>
            <div className="mt-2 text-sm text-yellow-700 dark:text-yellow-300">
              <p>{t("settings.preferences.reloadNote")}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;
