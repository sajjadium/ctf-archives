#!/bin/bash

curl --max-time 15 -f http://localhost:3000 || pkill -9 deno