#!/bin/bash
set -e

for _ in {1..30}; do
  if PGPASSWORD=postgres /usr/bin/psql -h localhost -U postgres -d postgres -c '\q' 2>/dev/null; then
    break
  fi
  sleep 2
done

for _ in {1..30}; do
  if /usr/bin/redis-cli -h localhost -p 6379 ping 2>/dev/null | grep -q PONG; then
    break
  fi
  sleep 2
done

exec /root/.deno/bin/deno run -A src/main.ts