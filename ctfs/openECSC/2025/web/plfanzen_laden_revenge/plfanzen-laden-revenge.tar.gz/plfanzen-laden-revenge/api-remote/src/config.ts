let _inContainer;

try {
  await Deno.stat("/.dockerenv");
  _inContainer = true;
} catch {
  _inContainer = Deno.env.has("KUBERNETES_SERVICE_HOST");
}

export const inContainer = _inContainer;

export const premiumFee =
  10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000n;

// export const startingBalance = Number(premiumFee);

export const startingBalance = 1000;

export const sessionPrefix = "sess:";

export const DB_CONFIG = {
  user: Deno.env.get("DB_USER") ?? "postgres",
  database: Deno.env.get("DB_NAME") ?? "postgres",
  password: Deno.env.get("DB_PASSWORD") ?? "postgres",
  hostname: "localhost",
  port: 5432,
};
