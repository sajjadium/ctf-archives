#!/bin/bash
set -e

mkdir -p /var/lib/redis /var/log/supervisor /var/log/postgresql
chown -R postgres:postgres /var/lib/postgresql /var/log/postgresql
chown -R redis:redis /var/lib/redis
chmod 700 /var/lib/postgresql/data
chmod 755 /var/log/postgresql

if [ ! -f /var/lib/postgresql/data/PG_VERSION ]; then
    su - postgres -c '/usr/lib/postgresql/15/bin/initdb -D /var/lib/postgresql/data'
fi

su - postgres -c '/usr/lib/postgresql/15/bin/pg_ctl -D /var/lib/postgresql/data -l /var/log/postgresql/postgresql.log start'

until su - postgres -c "/usr/lib/postgresql/15/bin/pg_isready"; do
  sleep 2
done

echo "Configuring PostgreSQL..."
echo "shared_preload_libraries = ''" >> /var/lib/postgresql/data/postgresql.conf
echo "log_statement = 'none'" >> /var/lib/postgresql/data/postgresql.conf
echo "log_min_messages = warning" >> /var/lib/postgresql/data/postgresql.conf

echo "local   all             all                                     trust" >> /var/lib/postgresql/data/pg_hba.conf
echo "host    all             all             127.0.0.1/32            trust" >> /var/lib/postgresql/data/pg_hba.conf
echo "host    all             all             ::1/128                 trust" >> /var/lib/postgresql/data/pg_hba.conf
echo "host    all             all             0.0.0.0/0               md5" >> /var/lib/postgresql/data/pg_hba.conf

su - postgres -c "psql -c \"CREATE DATABASE postgres;\" || true"
su - postgres -c "psql -c \"CREATE USER postgres WITH PASSWORD 'postgres';\" || true"
su - postgres -c "psql -c \"GRANT ALL PRIVILEGES ON DATABASE postgres TO postgres;\" || true"
su - postgres -c "psql -c \"ALTER USER postgres CREATEDB CREATEROLE SUPERUSER;\" || true"

su - postgres -c '/usr/lib/postgresql/15/bin/pg_ctl -D /var/lib/postgresql/data -m fast stop'

sleep 2

exec /usr/bin/supervisord -c /etc/supervisord.conf