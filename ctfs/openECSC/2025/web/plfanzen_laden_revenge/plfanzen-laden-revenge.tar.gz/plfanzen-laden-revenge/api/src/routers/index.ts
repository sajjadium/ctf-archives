export { default as authRouter } from "./auth.ts";
export { default as cartRouter } from "./cart.ts";
export { default as usersRouter } from "./users.ts";
export { default as reviewsRouter } from "./reviews.ts";
export { default as productsRouter } from "./products.ts";
