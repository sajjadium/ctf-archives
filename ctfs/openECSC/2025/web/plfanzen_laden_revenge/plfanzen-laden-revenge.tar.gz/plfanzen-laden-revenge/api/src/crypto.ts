import { encodeBase64Url } from "@std/encoding/base64url";

export const hmacKey = async ({ secret }: { secret: string }) => {
  const encoder = new TextEncoder();

  return await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    {
      name: "HMAC",
      hash: { name: "SHA-256" },
    },
    false,
    ["sign", "verify"],
  );
};

export const encode = (value: string) => {
  const encoder = new TextEncoder();
  return encoder.encode(value);
};

export const sign = async (
  { secret, value }: { secret: string; value: string },
) => {
  const key = await hmacKey({ secret });

  const encoder = new TextEncoder();

  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(value),
  );

  return signature;
};

export const verify = async (
  { secret, value, signature }: {
    secret: string;
    value: string;
    signature: ArrayBuffer;
  },
) => {
  const key = await hmacKey({ secret });
  const encodedValue = encode(value);

  return await crypto.subtle.verify(
    "HMAC",
    key,
    signature,
    encodedValue,
  );
};

export const uid = (n: number) => {
  const rand = new Uint8Array(n);
  crypto.getRandomValues(rand);
  return encodeBase64Url(rand);
};
