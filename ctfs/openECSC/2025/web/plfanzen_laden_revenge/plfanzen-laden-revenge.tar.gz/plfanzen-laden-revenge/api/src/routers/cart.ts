import authMiddleware, { AuthenticatedState } from "@/middleware/auth.ts";
import { Middleware, Router } from "@oak/oak";
import products, { Product } from "@/db/products.ts";
import userProducts from "@/db/user-products.ts";
import users from "@/db/users.ts";
import { badRequest } from "@/utils.ts";
import z from "zod";
import { byId } from "@/routers/products.ts";

export interface Cart {
  // productId: quantity
  [productId: string]: number;
}

const cartMiddleware: Middleware<AuthenticatedState> = async (ctx, next) => {
  if (!ctx.state.session.cart) {
    ctx.state.session.cart = {};
  }
  await next();
};

type CartState = Omit<AuthenticatedState, "session"> & {
  session: { cart: Cart } & Record<string, unknown>;
};

const router = new Router<CartState>({ prefix: "/cart" });

router.use(authMiddleware);
router.use(cartMiddleware);

router.get("/", async (ctx) => {
  const productIds = Object.keys(ctx.state.session.cart);
  if (!productIds.length) {
    ctx.response.body = [];
    return;
  }
  const P = products(ctx.state.client);
  const all = await P.findAll();
  const prods = all.filter((prod: Product) =>
    productIds.includes(prod.id.toString())
  );
  const quantityInCart = (product: Product) =>
    ctx.state.session.cart[product.id] as number;
  ctx.response.body = prods.map((prod: Product) => ({
    product: {
      id: prod.id,
      name: prod.name,
      price: prod.price,
    },
    quantity: quantityInCart(prod),
    totalPrice: quantityInCart(prod) * prod.price,
  }));
});

router.post("/clear", async (ctx) => {
  const P = products(ctx.state.client);
  const productIds = Object.keys(ctx.state.session.cart);
  const promises: any[] = [];
  if (productIds.length) {
    productIds.forEach(async (id) => {
      const quantity = ctx.state.session.cart[id];
      if (quantity) {
        promises.push(P.increaseQuantity(Number(id), quantity));
      }
    });
  }
  await Promise.all(promises);
  ctx.state.session.cart = {};
  ctx.response.status = 200;
  ctx.response.body = { ok: true };
});

router.post("/checkout", async (ctx) => {
  const productIds = Object.keys(ctx.state.session.cart);
  if (!productIds.length) {
    badRequest(ctx.response, { error: "Cart is empty" });
    return;
  }
  const P = products(ctx.state.client);
  const U = users(ctx.state.client);
  // first we get all requested products
  const all = await P.findAll();
  const prods = all.filter((prod: Product) =>
    productIds.includes(prod.id.toString())
  );
  // then we check if all products have enough quantity
  prods.forEach((prod: Product) => {
    const quantity = ctx.state.session.cart[prod.id];
    if (prod.quantity < quantity) {
      badRequest(ctx.response, {
        error: `Not enough quantity for product ${prod.id}`,
      });
      return;
    }
  });

  // then we check if the user has enough money
  const totalPrice = prods.reduce((acc: number, prod: Product) => {
    const quantity = ctx.state.session.cart[prod.id];
    return acc + prod.price * quantity;
  }, 0);
  if (ctx.state.user.balance < totalPrice) {
    badRequest(ctx.response, { error: "poor" });
    return;
  }
  // then we reduce the user balance
  try {
    await U.decreaseBalance(ctx.state.user.id, totalPrice);
  } catch (e) {
    badRequest(ctx.response, { error: "poor" });
    return;
  }

  await Promise.all(
    prods.map((prod: Product) => {
      return P.decreaseQuantity(prod.id, ctx.state.session.cart[prod.id]);
    }),
  );
  const cart = ctx.state.session.cart;

  ctx.state.session.cart = {};

  const uP = userProducts(ctx.state.client);
  await uP.addMultipleProducts(
    ctx.state.user.id,
    prods.map((prod: Product) => ({
      productId: prod.id,
      quantity: cart[prod.id],
    })),
  );
  ctx.response.status = 200;
  ctx.response.body = {
    ok: true,
  };
});

// 🍉
// const quantitySchema = z.object({
//   quantity: z
//     .int()
//     .positive()
// });

const quantitySchema = z.object({
  quantity: z
    .number()
    .positive()
    .min(1)
    .max(10 ** 17), // 😇😇😇
});

router.post("/:id", async (ctx) => {
  const res = await byId(ctx);
  if (!res) {
    return;
  }
  const [P, product] = res;
  const body = await ctx.request.body.json();
  const parsed = quantitySchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.issues);
    return;
  }
  let { quantity } = parsed.data;
  quantity = Math.floor(quantity);

  // check if the product has enough quantity
  if (product.quantity < quantity) {
    badRequest(ctx.response, { error: "Not enough product quantity" });
    return;
  }

  // subtract from product quantity
  await P.decreaseQuantity(product.id, quantity);

  // add to cart
  ctx.state.session.cart[product.id] =
    (ctx.state.session.cart[product.id] ?? 0) + quantity;
  ctx.response.status = 201;
  ctx.response.body = { ok: true };
});

export default router;
