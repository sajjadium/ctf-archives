import { createClient } from "redis";
import { inContainer } from "@/config.ts";

const client = inContainer
  ? createClient({ url: "redis://valkey:6379" })
  : createClient();

await client.connect();

export default client;
