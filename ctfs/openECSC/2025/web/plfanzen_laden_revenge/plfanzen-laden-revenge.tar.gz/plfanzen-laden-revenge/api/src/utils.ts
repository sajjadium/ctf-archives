import { Response } from "@oak/oak";

export const parseInteger = (str: string) => {
  const raw = Number(str);
  return Number.isInteger(raw) ? raw : null;
};

export const notFound = (res: Response, msg?: unknown) => {
  res.status = 404;
  res.body = msg ?? { error: "Not Found" };
};

export const badRequest = (res: Response, msg?: unknown) => {
  res.status = 400;
  res.body = msg ?? { error: "Bad Request" };
};
