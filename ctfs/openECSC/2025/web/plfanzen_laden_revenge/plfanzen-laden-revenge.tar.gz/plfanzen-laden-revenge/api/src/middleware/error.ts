import type { Middleware } from "@oak/oak";

export default function errorMiddleware(): Middleware {
  return async (ctx, next) => {
    try {
      await next();
      const status = ctx.response.status;
      if (status >= 400) {
        const body = ctx.response.body;
        const isJson = typeof body === "object" && body !== null;
        if (!isJson) {
          ctx.response.body = {
            error: body ??
              (ctx.response as unknown as { message: string }).message ??
              status.toString(),
          };
        }
      }
    } catch (err) {
      ctx.response.status = 500;
      ctx.response.body = { error: "Internal server error" };
      console.error(err);
    }
  };
}
