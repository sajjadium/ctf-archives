import { Client } from "@db/postgres";

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  quantity: number;
  total: number;
}

export interface ProductDB extends Omit<Product, "quantity" | "total"> {
  quantity: string; // from DB numeric
  total: string; // from DB numeric
}

export type ProductPublic = Omit<Product, "total">;

interface ProductCreation {
  name: string;
  description: string;
  price: number;
  total: number;
}

export const omitTotal = (product: Product): ProductPublic => ({
  id: product.id,
  name: product.name,
  description: product.description,
  price: product.price,
  quantity: product.quantity,
});

export const mapDbToProduct = (row: ProductDB): Product => ({
  ...row,
  quantity: Number(row.quantity),
  total: Number(row.total),
});

const products = (client: Client) => {
  const create = async (product: ProductCreation): Promise<Product> => {
    const { name, description, price, total } = product;
    const res = await client.queryObject<ProductDB>`
      INSERT INTO products (name, description, price, total)
      VALUES (${name}, ${description}, ${price}, ${total})
      RETURNING *;
    `;
    return mapDbToProduct(res.rows[0]);
  };

  const findById = async (id: number): Promise<Product | undefined> => {
    const res = await client.queryObject<ProductDB>`
      SELECT * FROM products WHERE id = ${id};
    `;
    if (!res.rows[0]) return undefined;
    return mapDbToProduct(res.rows[0]);
  };

  const findAll = async (): Promise<Product[]> => {
    const res = await client.queryObject<ProductDB>`
      SELECT * FROM products;
    `;
    return res.rows.map(mapDbToProduct);
  };

  const decreaseQuantity = async (
    id: number,
    quantity: number,
  ): Promise<Product | undefined> => {
    const res = await client.queryObject<ProductDB>`
      UPDATE products
      SET quantity = quantity - ${quantity}
      WHERE id = ${id} AND quantity >= ${quantity}
      RETURNING *;
    `;
    if (!res.rows[0]) return undefined;
    return mapDbToProduct(res.rows[0]);
  };

  const increaseQuantity = async (
    id: number,
    quantity: number,
  ): Promise<Product | undefined> => {
    const res = await client.queryObject<ProductDB>`
      UPDATE products
      SET quantity = quantity + ${quantity}
      WHERE id = ${id}
      RETURNING *;
    `;
    if (!res.rows[0]) return undefined;
    return mapDbToProduct(res.rows[0]);
  };

  return {
    create,
    findById,
    findAll,
    decreaseQuantity,
    increaseQuantity,
  };
};

export default products;
