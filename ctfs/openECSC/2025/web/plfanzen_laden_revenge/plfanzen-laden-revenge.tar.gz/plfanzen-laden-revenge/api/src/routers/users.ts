import authMiddleware, { AuthenticatedState } from "@/middleware/auth.ts";
import { Router } from "@oak/oak";
import { badRequest } from "@/utils.ts";
import users from "@/db/users.ts";
import { premiumFee } from "@/config.ts";

const router = new Router<AuthenticatedState>({ prefix: "/users" });
router.use(authMiddleware);

router.get("/me", (ctx) => {
  ctx.response.body = ctx.state.user;
});

router.post("/elevate", async (ctx) => {
  const user = ctx.state.user;
  if (!(user.balance > premiumFee)) {
    badRequest(ctx.response, { error: "poor" });
    return;
  }
  const U = users(ctx.state.client);
  await U.decreaseBalance(user.id, Number(premiumFee));
  await ctx.state.client
    .queryObject`UPDATE users SET premium = true WHERE id = ${user.id}`;
  ctx.response.body = { ok: true, message: "Profile elevated 💸💸💸" };
});

export default router;
