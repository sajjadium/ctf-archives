import { Client } from "@db/postgres";
import { ProductPublic } from "@/db/products.ts";

export interface UserProduct {
  userId: number;
  productId: number;
  quantity: number;
}

export interface UserProductDB extends Omit<UserProduct, "quantity"> {
  quantity: string; // from DB numeric
}
export const mapDbToUserProduct = (row: UserProductDB): UserProduct => ({
  ...row,
  quantity: Number(row.quantity),
});

const userProducts = (client: Client) => {
  const findByUserId = async (userId: number): Promise<UserProduct[]> => {
    const res = await client.queryObject<UserProductDB>`
      SELECT * FROM user_products WHERE user_id = ${userId};
    `;
    return res.rows.map(mapDbToUserProduct);
  };

  const add = async (userId: number, productId: number, quantity: number) => {
    await client.queryObject`
      INSERT INTO user_products (user_id, product_id, quantity)
      VALUES (${userId}, ${productId}, ${quantity})
      ON CONFLICT (user_id, product_id) DO UPDATE SET quantity = user_products.quantity + EXCLUDED.quantity;
    `;
  };

  const remove = async (
    userId: number,
    productId: number,
    quantity: number,
  ) => {
    await client.queryObject`
      UPDATE user_products SET quantity = quantity - ${quantity}
      WHERE user_id = ${userId} AND product_id = ${productId} AND quantity >= ${quantity};
    `;
  };

  const findUserProducts = async (userId: number) => {
    const res = await client.queryObject<ProductPublic>`
          SELECT p.id, p.name, p.description, up.quantity FROM products p
          JOIN user_products up ON p.id = up.product_id
          WHERE up.user_id = ${userId};
      `;
    return res.rows;
  };

  const addMultipleProducts = async (
    userId: number,
    products: { productId: number; quantity: number }[],
  ) => {
    const queries = products.map(
      (p) =>
        client.queryObject`
      INSERT INTO user_products (user_id, product_id, quantity)
      VALUES (${userId}, ${p.productId}, ${p.quantity})
      ON CONFLICT (user_id, product_id) DO UPDATE SET quantity = user_products.quantity + EXCLUDED.quantity;
    `,
    );
    await Promise.all(queries);
  };

  return {
    findByUserId,
    add,
    remove,
    findUserProducts,
    addMultipleProducts,
  };
};

export default userProducts;
