import { sign, verify } from "./crypto.ts";
import { decodeBase64Url, encodeBase64Url } from "@std/encoding/base64url";

export const signCookie = async (
  { secret, value }: { secret: string; value: string },
) => {
  const signature = await sign({ secret, value });
  return `${value}.${encodeBase64Url(signature)}`;
};

export const unsignCookie = async (
  { secret, signedCookie }: { secret: string; signedCookie: string },
) => {
  const [value, signatureB64] = signedCookie.split(".");
  if (!value || !signatureB64) {
    return null;
  }
  try {
    const signature = decodeBase64Url(signatureB64);
    if (!(await verify({ secret, value, signature }))) {
      return null;
    }
  } catch {
    return null;
  }
  return value;
};
