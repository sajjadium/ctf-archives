import { State } from "@/main.ts";
import { Router } from "@oak/oak";
import user, { omitPw } from "@/db/users.ts";
import { checkPw } from "@/db/crypto.ts";
import z from "zod";
import { badRequest } from "@/utils.ts";

const router = new Router<State>({ prefix: "/auth" });

const signupSchema = z.object({
  username: z.string().min(1),
  email: z.email(),
  password: z.string().min(1),
});
const loginSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

router.post("/signup", async (ctx) => {
  const body = await ctx.request.body.json();
  const parsed = signupSchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.issues);
    return;
  }
  const { username, password, email } = parsed.data;
  const U = user(ctx.state.client);
  if (await U.findByUsername(username) || await U.findByEmail(email)) {
    ctx.response.status = 400;
    ctx.response.body = { error: "nya~" };
    return;
  }
  const u = await U.create({ username, password, email });
  ctx.response.status = 200;
  ctx.response.body = omitPw(u);
});

router.post("/login", async (ctx) => {
  const body = await ctx.request.body.json();
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    badRequest(ctx.response, parsed.error.message);
    return;
  }
  const { username, password } = parsed.data;
  const U = user(ctx.state.client);
  const u = await U.findByUsername(username);
  if (!u) {
    ctx.response.status = 400;
    ctx.response.body = { error: "nya~" };
    return;
  }
  if (!checkPw(password, u.password_hash)) {
    ctx.response.status = 400;
    ctx.response.body = { error: "nya~" };
    return;
  }
  ctx.state.session.uid = u.id;
  ctx.response.status = 200;
  ctx.response.body = omitPw(u);
});

export default router;
