import re
from os import getenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from time import sleep
from secrets import token_hex

SECRET = getenv('SECRET', token_hex(32))
FLAG_COOKIE = {
    'name': 'secret',
    'value': SECRET,
    'path': '/',
    'httpOnly': True
}
BROWSER_TIMEOUT_SECOND = 10
APP_DOMAIN = 'localhost:8000'
APP_URL = f'http://{APP_DOMAIN}/'
APP_URL_REGEX = re.compile(r'^http://localhost:8000/.*$')

chromeOptions = Options()
chromeOptions.add_argument('--headless')
chromeOptions.add_argument('--no-sandbox')
chromeOptions.add_argument('--disable-dev-shm-usage')
chromeOptions.add_argument('--disable-gpu')
chromeOptions.add_argument('--no-gpu')
chromeOptions.add_argument('--disable-default-apps')
chromeOptions.add_argument('--disable-translate')
chromeOptions.add_argument('--disable-device-discovery-notifications')
chromeOptions.add_argument('--disable-software-rasterizer')
chromeOptions.add_argument('--disable-xss-auditor')
chromeOptions.add_argument('--disable-extensions')
chromeOptions.add_argument('--disable-features=DownloadBubble')
chromeOptions.add_argument('--js-flags=--noexpose_wasm,--jitless')

def visit(url):
    isSuccess = False
    browser = None
    try:
        print(f'[*] The bot is visiting URL: {url}')
        browser = webdriver.Chrome(options=chromeOptions)
        browser.set_page_load_timeout(BROWSER_TIMEOUT_SECOND)
        browser.set_script_timeout(BROWSER_TIMEOUT_SECOND)

        browser.get(APP_URL)
        sleep(1)
        browser.add_cookie(FLAG_COOKIE)

        browser.get(url)
        sleep(5)
        isSuccess = True
        print('[+] The bot has successfully visited your URL')
    except Exception as error:
        print(f'[-] The bot failed to visit your URL: {error}')
    finally:
        if browser is not None:
            browser.quit()

        return isSuccess