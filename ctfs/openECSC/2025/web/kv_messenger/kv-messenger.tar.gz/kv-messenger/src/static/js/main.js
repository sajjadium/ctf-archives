async function storeMessage() {
    const value = document.getElementById('value').value;
    if (!value) {
        alert('Please enter a message');
        return;
    }

    const response = await fetch('/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value })
    });
    const result = await response.json();
    document.getElementById('message').innerText = JSON.stringify(result, null, 2);
}

async function getMessage() {
    const uuid = document.getElementById('getUuid').value;
    if (!uuid) {
        alert('Please enter a UUID');
        return;
    }

    const response = await fetch(`/message?uuid=${encodeURIComponent(uuid)}`);
    const result = await response.json();
    document.getElementById('message').innerText = JSON.stringify(result, null, 2);
}

async function viewMessage() {
    const uuid = document.getElementById('getUuid2').value;
    if (!uuid) {
        alert('Please enter a UUID');
        return;
    }

    const a = document.createElement('a');
    a.href = `/download?uuid=${encodeURIComponent(uuid)}&view=True`;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

async function downloadMessage() {
    const uuid = document.getElementById('downloadUuid').value;
    const filename = document.getElementById('downloadFilename').value;
    if (!uuid || !filename) {
        alert('Please enter both UUID and filename');
        return;
    }

    const response = await fetch(`/download?uuid=${encodeURIComponent(uuid)}&filename=${encodeURIComponent(filename)}`);
    if (!response.ok) {
        const result = await response.json();
        document.getElementById('message').innerText = JSON.stringify(result, null, 2);
        return;
    }

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    document.getElementById('message').innerText = 'Download initiated';
}

async function init() {
    const storeMessageButton = document.getElementById('storeMessageButton');
    const getMessageButton = document.getElementById('getMessageButton');
    const viewMessageButton = document.getElementById('viewMessageButton');
    const downloadMessageButton = document.getElementById('downloadMessageButton');
    storeMessageButton.addEventListener('click', async function (e) {
        await storeMessage();
    });
    getMessageButton.addEventListener('click', async function (e) {
        await getMessage();
    });
    viewMessageButton.addEventListener('click', async function (e) {
        await viewMessage();
    });
    downloadMessageButton.addEventListener('click', async function (e) {
        await downloadMessage();
    });
}

document.addEventListener('DOMContentLoaded', async function() {
    await init();
});