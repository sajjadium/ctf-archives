from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from http import HTTPStatus
from uuid import uuid4, UUID
from os import getenv
import json
import urllib.parse
import bot

FLAG_UUID = str(uuid4())
CONTENT_TYPE = {
    'html': 'text/html; charset=utf-8',
    'json': 'application/json',
    'javascript': 'application/javascript',
    'css': 'text/css'
}
HTML_TEMPLATE_PATH = 'templates'
STATIC_FILE_PATH = 'static'
CSP = 'default-src \'self\'; script-src \'self\'; script-src-elem \'self\'; base-uri \'none\'; object-src \'none\'; frame-ancestors \'none\'; frame-src \'none\'; require-trusted-types-for \'script\';'

messageStore = dict()
messageStore[FLAG_UUID] = getenv('FLAG', 'openECSC{FAKE_FLAG}')

def isValidEndpoint(path, validEndpoints):
    return any(path in endpoint for endpoint in validEndpoints.values())

def isValidMessage(uuid):
    if not uuid:
        return False
    if uuid not in messageStore:
        return False
    try:
        uuidObject = UUID(uuid)
    except:
        return False
    if uuidObject.version != 4:
        return False
    if uuid == FLAG_UUID:
        return False
    
    return True

def generateHtmlMessage(uuid):
    return f'<h1>Message (UUIDv4: {uuid})</h1><code><pre>{messageStore[uuid]}</pre></code>'

def generateMessageUuid():
    newUuid = str(uuid4())
    if newUuid in messageStore:
        return generateMessageUuid()

    return newUuid

class MessageHandler(BaseHTTPRequestHandler):
    _getEndpoints = {
        'index': [ '/', '/index.html' ],
        'static': [ f'/{STATIC_FILE_PATH}/css/main.css', f'/{STATIC_FILE_PATH}/js/main.js' ],
        'message': [ '/message' ],
        'download': [ '/download' ],
        'flag': [ '/flag' ]
    }
    _postEndpoints = {
        'message': [ '/message' ],
        'report': [ '/report' ]
    }
    protocol_version = 'HTTP/1.1'

    def _sendResponse(self, statusCode, responseBody, contentType, headers=list()):
        responseBody = responseBody.encode()
        
        self.send_response(statusCode)
        self.send_header('Content-Security-Policy', CSP)
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Content-Type', contentType)
        self.send_header('Content-Length', str(len(responseBody)))
        if self.headers.get('Connection', '').lower() == 'keep-alive':
            self.send_header('Connection', 'keep-alive')
            self.send_header('Keep-Alive', 'timeout=3, max=5')
        else:
            self.send_header('Connection', 'close')

        if headers:
            for header in headers:
                for key, value in header.items():
                    self.send_header(key, value)
        self.end_headers()
        self.wfile.write(responseBody)

    def _readPostJsonBody(self):
        if self.headers.get('Content-Type') != CONTENT_TYPE['json']:
            return None

        contentLength = int(self.headers.get('Content-Length', 0))
        if contentLength == 0:
            return None

        postData = self.rfile.read(contentLength)
        try:
            data = json.loads(postData.decode())
        except json.JSONDecodeError:
            return None
        
        return data

    def _serveStaticFile(self, filename):
        contentType = CONTENT_TYPE['json']
        if filename.endswith('.html'):
            contentType = CONTENT_TYPE['html']
        elif filename.endswith('.css'):
            contentType = CONTENT_TYPE['css']
        elif filename.endswith('.js'):
            contentType = CONTENT_TYPE['javascript']

        try:
            with open(filename, 'r') as file:
                fileContent = file.read()
        except FileNotFoundError:
            responseBody = json.dumps({ 'error': 'Static file not found' })
            return self._sendResponse(HTTPStatus.NOT_FOUND, responseBody, CONTENT_TYPE['json'])

        return self._sendResponse(HTTPStatus.OK, fileContent, contentType)

    def _handleInvalidEndpoint(self):
        responseBody = json.dumps({ 'error': 'Invalid endpoint' })
        return self._sendResponse(HTTPStatus.NOT_FOUND, responseBody, CONTENT_TYPE['json'])

    def _handleGetMessage(self, query):
        uuidParam = query.get('uuid', [ None ])[0]
        if not isValidMessage(uuidParam):
            responseBody = json.dumps({ 'error': 'No UUID is provided or message not found' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        responseBody = json.dumps({ 'uuid': uuidParam, 'value': messageStore[uuidParam] })
        return self._sendResponse(HTTPStatus.OK, responseBody, CONTENT_TYPE['json'])

    def _handleViewMessage(self, query):
        uuidParam = query.get('uuid', [ None ])[0]
        if not isValidMessage(uuidParam):
            responseBody = json.dumps({ 'error': 'No UUID is provided or message not found' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])

        return self._sendResponse(HTTPStatus.OK, generateHtmlMessage(uuidParam), CONTENT_TYPE['html'])

    def _handleDownloadMessage(self, query):
        uuidParam = query.get('uuid', [ None ])[0]
        filename = query.get('filename', [ '' ])[0].strip()
        if not filename:
            responseBody = json.dumps({ 'error': 'Filename required' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        if not isValidMessage(uuidParam):
            responseBody = json.dumps({ 'error': 'No UUID is provided or message not found' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])

        headers = [ { 'Content-Disposition': f'attachment; filename="{filename}.html"' } ]
        return self._sendResponse(HTTPStatus.OK, generateHtmlMessage(uuidParam), CONTENT_TYPE['html'], headers=headers)

    def _handleFlagMessage(self):
        if not (cookieHeader := self.headers.get('Cookie')):
            responseBody = json.dumps({ 'error': 'Cookie required' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])

        cookies = SimpleCookie()
        cookies.load(cookieHeader)
        secretCookie = cookies.get('secret')
        if not secretCookie or secretCookie.value != bot.SECRET:
            responseBody = json.dumps({ 'error': 'Incorrect secret value' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        responseBody = json.dumps({ 'uuid': FLAG_UUID, 'value': messageStore[FLAG_UUID] })
        return self._sendResponse(HTTPStatus.OK, responseBody, CONTENT_TYPE['json'])

    def _handleCreateNewMessage(self):
        data = self._readPostJsonBody()
        if not data:
            responseBody = json.dumps({ 'error': 'Invalid JSON' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        value = data.get('value')
        if not value:
            responseBody = json.dumps({ 'error': 'Value required' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        if not value.isascii():
            responseBody = json.dumps({ 'error': 'Invalid message. Currently we only allow ASCII characters' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])

        messageUuid = generateMessageUuid()
        messageStore[messageUuid] = value
        responseBody = json.dumps({ 'message': 'Stored successfully', 'uuid': messageUuid })
        return self._sendResponse(HTTPStatus.CREATED, responseBody, CONTENT_TYPE['json'])

    def _handleReport(self):
        data = self._readPostJsonBody()
        if not data:
            responseBody = json.dumps({ 'error': 'Invalid JSON' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        url = data.get('url')
        if not url:
            responseBody = json.dumps({ 'error': 'URL required' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        if bot.APP_URL_REGEX.match(url) is None:
            responseBody = json.dumps({ 'error': f'Invalid URL. Regex pattern: {bot.APP_URL_REGEX.pattern} '})
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        isSuccess = bot.visit(url)
        if not isSuccess:
            responseBody = json.dumps({ 'error': 'The bot failed to visit your URL' })
            return self._sendResponse(HTTPStatus.BAD_REQUEST, responseBody, CONTENT_TYPE['json'])
        
        responseBody = json.dumps({ 'message': 'The bot has successfully visited your URL' })
        return self._sendResponse(HTTPStatus.OK, responseBody, CONTENT_TYPE['json'])

    def do_GET(self):
        parsedPath = urllib.parse.urlparse(self.path)
        path = parsedPath.path
        query = urllib.parse.parse_qs(parsedPath.query)

        if not isValidEndpoint(path, self._getEndpoints):
            return self._handleInvalidEndpoint()
        
        if path in self._getEndpoints['index']:
            return self._serveStaticFile(f'{HTML_TEMPLATE_PATH}/index.html')
        if path in self._getEndpoints['static']:
            if path == self._getEndpoints['static'][0]:
                return self._serveStaticFile(f'{STATIC_FILE_PATH}/css/main.css')
            if path == self._getEndpoints['static'][1]:
                return self._serveStaticFile(f'{STATIC_FILE_PATH}/js/main.js')
        if path in self._getEndpoints['message']:
            return self._handleGetMessage(query)
        if path in self._getEndpoints['download']:
            isViewMessage = True if query.get('view', [ None ])[0] == 'True' else False
            if isViewMessage:
                return self._handleViewMessage(query)
            
            return self._handleDownloadMessage(query)
        if path in self._getEndpoints['flag']:
            return self._handleFlagMessage()

    def do_POST(self):
        parsedPath = urllib.parse.urlparse(self.path)
        path = parsedPath.path

        if not isValidEndpoint(path, self._postEndpoints):
            return self._handleInvalidEndpoint()

        if path in self._postEndpoints['message']:
            return self._handleCreateNewMessage()
        if path in self._postEndpoints['report']:
            return self._handleReport()

def runServer(serverClass=ThreadingHTTPServer, handlerClass=MessageHandler, port=8000):
    serverAddress = ('0.0.0.0', port)
    httpd = serverClass(serverAddress, handlerClass)
    print(f'[*] Starting web server on port {port}...')
    print(f'[*] {bot.SECRET = }')
    httpd.serve_forever()

if __name__ == '__main__':
    runServer()