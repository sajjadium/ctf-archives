# The Hidden Killer
## Description
The FBI just updated the serial killer database, but suddenly seems like the US are becoming too concerned about privacy... and now low-level policemen are allowed to make arrests but not to access the arrest data from other arrests.
Normally, this wouldn't be a real problem, but these days it's spreading some rumors about the capture of the most infamous serial killer of all time: the Zodiac Killer. They even say she's a woman and she's called `Zoe Diack`!

Bob the cop is a true-crime fan and wants to get some proof of it. Will he be able to satiate his curiosity and verify the rumors?

### Authors
- LorenzoB
- MarcoBalo
