from Crypto.Cipher import AES
from Crypto.Util import Counter
from Crypto.Util.number import bytes_to_long
from Crypto.Random import get_random_bytes
from pathlib import Path
import shutil

def encrypt(file, key):
    nonce = Path(file).stem[:16].rjust(16).encode()
    counter = Counter.new(128, initial_value=bytes_to_long(nonce))
    cipher = AES.new(key, AES.MODE_CTR, counter=counter)
    with open(file, "rb") as f:
        data = f.read()
    data_enc = cipher.encrypt(data)
    with open(file, "wb") as f:
        f.write(data_enc)

def decrypt(file, key):
    nonce = Path(file).stem[:16].rjust(16).encode()
    counter = Counter.new(128, initial_value=bytes_to_long(nonce))
    cipher = AES.new(key, AES.MODE_CTR, counter=counter)
    with open(file, "rb") as f:
        data = f.read()
    data_enc = cipher.decrypt(data)
    with open(file, "wb") as f:
        f.write(data_enc)

key = get_random_bytes(16)
test = "image(1).jpg"
flag = "image(2).jpg"

encrypt(test, key)
shutil.copy(test, "output/test_enc.jpg")
decrypt(test, key)
shutil.copy(test, "output/test_dec.jpg")
encrypt(flag, key)
shutil.copy(flag, "output/flag_enc.jpg")

