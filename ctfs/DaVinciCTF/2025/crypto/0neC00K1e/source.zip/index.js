const express = require('express');
const cookieParser = require('cookie-parser');
const cookieEncrypter = require('cookie-encrypter');
require("dotenv").config()

const app = express();

const {FLAG,key}=process.env
const PORT = process.env.PORT || 3000

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

app.use(cookieParser());

app.use(express.static('public'));

app.post('/login', function(req, res) {
    let username=req.body.username
    let password=req.body.password

    if(username=="guest"){
        res.cookie("role",cookieEncrypter.encryptCookie("guest",{key}))
        res.redirect("/locker")
    }else{
        if(username=="admin" && password==FLAG){
            res.cookie("role",cookieEncrypter.encryptCookie("admin",{key}))
            res.redirect("/locker")
        }else{
            res.redirect("/?error=Wrong credentials")
        }
    }
})

app.get("/flag",(req,res)=>{
    let decryptedRole=cookieEncrypter.decryptCookie(req.cookies.role,{key})
    if(decryptedRole=="admin"){
        res.json({message: "Here is what you came from: "+FLAG})
    }else{
        res.json({message: "You're not admin !"})
    }
})

app.listen(PORT,(err)=>{
    if(err) throw err
    console.log("Server running on port",PORT)
})