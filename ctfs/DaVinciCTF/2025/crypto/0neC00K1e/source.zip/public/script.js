let errorDiv=document.getElementById("error")
// get query parameters from the URL
const urlParams = new URLSearchParams(window.location.search);
// get the error parameter
const error = urlParams.get('error');
// if there is an error, show it
if(error){
    errorDiv.innerText=error
    errorDiv.style.display="block"
}