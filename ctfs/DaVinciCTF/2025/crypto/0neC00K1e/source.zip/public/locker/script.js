let result = document.getElementById('result');
async function getFlag(){
    let req = await fetch('/flag');
    let res = await req.json();
    result.innerHTML = res.message;
    result.style.display = 'block';
}