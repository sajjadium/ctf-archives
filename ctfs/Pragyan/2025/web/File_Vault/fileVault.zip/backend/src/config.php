<?php
define('JWT_SECRET', 'super_secret_key');
session_start();
?>