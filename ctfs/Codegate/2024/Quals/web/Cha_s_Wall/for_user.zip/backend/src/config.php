<?php
    define("SECRET_CODE","REDACTED");
?>