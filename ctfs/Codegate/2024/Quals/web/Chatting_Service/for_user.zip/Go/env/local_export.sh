#!/bin/bash
# source ./local_export.sh
export DB_HOST="127.0.0.1"
export DB_NAME="db"
export DB_PASSWORD="codegate2024foruser"
export DB_PORT="5432"
export DB_USER="codegate2024"

echo "DONE"
