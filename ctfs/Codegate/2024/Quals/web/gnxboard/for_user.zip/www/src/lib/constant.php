<?
// 상수 정의

// 입력값 검사 상수
define('_G4_ALPHAUPPER_', 1); // 영대문자
define('_G4_ALPHALOWER_', 2); // 영소문자
define('_G4_ALPHABETIC_', 4); // 영대,소문자
define('_G4_NUMERIC_', 8); // 숫자
define('_G4_HANGUL_', 16); // 한글
define('_G4_SPACE_', 32); // 공백
define('_G4_SPECIAL_', 64); // 특수문자
?>