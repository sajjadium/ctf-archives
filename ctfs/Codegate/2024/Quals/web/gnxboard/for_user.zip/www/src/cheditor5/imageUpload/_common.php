<?
$g4_path = "../.."; // 경로
include_once("$g4_path/common.php");
?>
