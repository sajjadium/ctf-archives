<?
$mysql_host = 'db';
$mysql_user = 'gnxboard';
$mysql_password = 'asdf1234';
$mysql_db = 'gnxboard';
?>
