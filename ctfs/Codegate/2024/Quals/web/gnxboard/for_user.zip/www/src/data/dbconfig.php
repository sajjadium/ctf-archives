<?
$mysql_host = '127.0.0.1';
$mysql_user = 'root';
$mysql_password = 'asdf1234';
$mysql_db = 'gnxboard';
?>