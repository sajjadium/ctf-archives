<?php

define('APP_DB_HOST', 'mysql:dbname=animals;host=127.0.0.1');
define('APP_DB_USER', 'user');
define('APP_DB_PASS', 'pass');
define('APP_SECRET_KEY', 'CHANGEME');
