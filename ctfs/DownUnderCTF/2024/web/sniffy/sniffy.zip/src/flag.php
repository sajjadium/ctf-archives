<?php

define('FLAG', 'DUCTF{}');