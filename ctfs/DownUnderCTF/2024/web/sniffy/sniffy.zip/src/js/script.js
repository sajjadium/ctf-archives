function playAudio(url) {
  new Audio(url).play();
}