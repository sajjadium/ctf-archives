# Runner evidence

A hostile-state campaign targeted a rail-signaling build runner to obstruct recovery. Recover the sealed recovery marker from the supplied records and submit its complete `CSCTF{...}` value.

## Files

- `runner-fs.tar.gz`: a constructed filesystem tree with stored PAX extended attributes.
- `runner.journal`: constructed events imported into the genuine systemd journal format.
- `manifest.sha256`: checksums of these files and this brief.

## Analysis boundary

All organizational labels and the incident are fictional. These records do not prove native compromise, successful privilege use or persistence. Analyze the archive metadata and journal as data; do not restore capabilities, extract as root or run supplied executables. Linux forensic tools (including WSL) are sufficient. `journalctl --file=runner.journal --no-pager -o json` can inspect the journal without root; ordinary archive metadata readers can inspect stored xattrs without applying them. The recovered marker is the submission, not a conclusion about privilege or attribution.
