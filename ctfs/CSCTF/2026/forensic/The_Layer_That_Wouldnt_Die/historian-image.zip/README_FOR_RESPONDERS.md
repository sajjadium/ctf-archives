# Case brief: cascade-historian-config image

Operator (fictional): Cascade Water Systems, a water-treatment SCADA vendor whose historian
gateways serve sites in the Operation Dawn theatre.

A hostile-state campaign reached the vendor's image registry. Before the intrusion, engineering
sealed a site credential into this image. Afterwards, the file that opens the seal no longer
appears in the image's filesystem.

## What you have

- `cascade-historian-config-image/` - the preserved image as an OCI image layout
  (`oci-layout`, `index.json` and the `blobs/sha256/` content store).
- `manifest.sha256` - SHA-256 of this brief and of every layout file, in `sha256sum` format.

## Task

Recover the sealed credential and submit it as the complete `CSCTF{...}` value.

## Notes

- This is a constructed exercise. It is not a registry capture and not a runnable application:
  the image has no entrypoint, and its build history describes its layers rather than logging
  a real build.
- Treat the files as data and do not execute anything from them. Standard archive, JSON and
  hashing tools are enough; no root access and no network are needed.
