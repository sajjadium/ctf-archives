# Historian recovery

During a campaign against the electricity supply, a substation historian's configuration was encrypted and the encryptor was deleted. Recover the original configuration's `SAFETY_INTERLOCK_TOKEN` and submit its complete `CSCTF{...}` value.

The two image files are a constructed exercise volume, not an untouched incident acquisition or a bootable virtual machine. The ext4 filesystem was created on 29 October; selected incident records and access/modification times represent 2 October. Treat those different clocks according to what each records. The supplied flat extent contains all evidence needed; analyze it directly with filesystem tools. The descriptor identifies its format and extent. No external logs or internet service are required.

Inspect recovered programs as data; do not execute them or mount the image. All organizations and events are fictional. `manifest.sha256` covers the two image files and this brief.
