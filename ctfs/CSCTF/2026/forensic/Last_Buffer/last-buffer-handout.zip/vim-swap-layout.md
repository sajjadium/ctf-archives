# Vim swap triage note

The collector stripped the leading dot from swap names.  For native recovery, place one captured
swap in its own temporary directory as `.incident-2026-10-07.md.swp`, copy the saved
`incident-2026-10-07.md` beside it, and run `vim -Nu NONE -r incident-2026-10-07.md`.

For tool-independent review, these are ordinary unencrypted Vim 9 swap files from a little-endian
64-bit Linux host with 4096-byte pages.  Block zero begins `b0`, records the page size at offset 12,
PID at 24, user at 28, host at 68, and original path at 108.  Block one is the root pointer block.
Data blocks begin with little-endian ID `0x6461`; their line count is an eight-byte integer at
offset 16 and four-byte line-start indexes begin at offset 24.  Lines are NUL-terminated.
