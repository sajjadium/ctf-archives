# Response-cell reconstruction policy

The relevant flow is one maintenance client to controller TCP port 502. It uses
MBAP protocol identifier `0x0000` and unit identifier `0x01`, with one request
and its response completed before the next request.

* Accept an FC03 observation only when the immediately preceding FC03 request
  matches reversed-flow transaction ID, protocol ID, unit ID and function code.
  Its response byte count must be twice the request quantity. It updates every
  mapped word it covers.
* Accept an FC16 write only when its reversed-flow normal response has matching
  transaction ID, protocol ID, unit ID and function code and echoes start
  address and quantity. Exception responses never change state.
* Apply an accepted FC16's mapped-word updates after its normal response.
* A target transaction has quantity one and start address `0x0013` or `0x0014`.
  The eight other accepted FC16 writes are ineligible: five update the three
  prerequisite-state words and three are acknowledgement writes outside the
  target pair.
* A target is unsafe exactly when at least one condition is false immediately
  before its normal response: `maintenance_permit == 1`, `isolation_state == 1`,
  and `protection_armed == 1`.

The controller accepts syntactically valid writes. This policy is an offline
response-cell forensic classification rule, not a claimed controller feature.
