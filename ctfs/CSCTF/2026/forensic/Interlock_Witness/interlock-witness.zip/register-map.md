# Interlock register map

Displayed references are operational labels. PDU addresses below are zero based.
All policy values are unsigned 16-bit big-endian holding-register words.

| Displayed reference | PDU address | Meaning | Valid values |
|---|---:|---|---|
| 40011 | `0x000A` | `maintenance_permit` | 0 absent, 1 active |
| 40012 | `0x000B` | `isolation_state` | 0 connected, 1 isolated |
| 40013 | `0x000C` | `protection_armed` | 0 bypassed, 1 armed |
| 40020 | `0x0013` | `trip_limit` | 0–10000 engineering units |
| 40021 | `0x0014` | `restore_delay` | 0–3600 seconds |
