Operation Blackout — Interlock Witness

A fictional grid-support station accepted maintenance writes while its response
cell safety rule was false. Reconstruct the accepted target writes that breach
the published rule, concatenate their request and normal-response Modbus PDUs
as specified in witness-format.md, and submit CSCTF{<64 lowercase hex>}.

Analyze these supplied files only. The capture is Modbus/TCP on controller port
502. register-map.md uses zero-based PDU addresses; displayed 4xxxx references
are for operators only. SHA256SUMS verifies extracted members. The event
listing separately authenticates this enclosing ZIP.
