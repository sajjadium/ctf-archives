# Witness format

Select unsafe accepted FC16 target transactions in normal-response order. For
each, append its request PDU (`function-code || function-data`, no MBAP) then
its paired normal-response PDU. The concatenation is `T`.

`P` is exactly these 20 raw bytes:

`49 4e 54 45 52 4c 4f 43 4b 2d 57 49 54 4e 45 53 53 2f 31 00`

The first 19 bytes are ASCII `INTERLOCK-WITNESS/1`; the final byte is zero.
Compute `W = SHA-256(P || T)` and submit `CSCTF{` plus lowercase hexadecimal
`W` plus `}`.

Non-incident serialization vector:

* request PDU: `10 00 13 00 01 02 00 2a`
* normal response PDU: `10 00 13 00 01`
* `T`: `10 00 13 00 01 02 00 2a 10 00 13 00 01`
* expected `W`: `b6e58fa962e382b112eb596e416d5680495fc4bd02141f2389797f194df34786`

The vector is a format check only and is unrelated to the incident capture.
