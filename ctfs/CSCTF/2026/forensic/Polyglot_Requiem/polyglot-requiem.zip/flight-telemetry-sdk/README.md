# flight-telemetry-sdk

Internal build, instance `csctf2026`.
SDK for ingesting avionics telemetry into the ground station.

![icon](assets/telemetry_icon.png)
