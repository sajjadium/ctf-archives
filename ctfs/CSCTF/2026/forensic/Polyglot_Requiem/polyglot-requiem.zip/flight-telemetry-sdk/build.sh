#!/bin/sh
set -e
echo building flight-telemetry-sdk
make
