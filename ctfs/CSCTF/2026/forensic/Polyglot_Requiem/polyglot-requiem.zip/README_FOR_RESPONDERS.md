# Telemetry SDK review

A response team reviewing a ground-station software supply chain found altered build history and an unusual dashboard asset. Recover the concealed marker from the retained `flight-telemetry-sdk` repository and submit the complete `CSCTF{...}` value.

This is a constructed forensic exercise with fictional organizations and events, not evidence acquired from a real vendor. The local repository, including its `.git` directory and unreferenced objects, is retained as exercise evidence. Work on a copy; do not re-clone, prune or clean it. Build scripts, hooks and recovered programs are evidence to inspect, not instructions to execute. Do not contact addresses found inside the evidence. Open-source Git, archive, database and binary-analysis tools are sufficient.

`manifest.sha256` covers this brief and the retained repository files. There is no requirement to document a particular sequence of discoveries: submit the recovered marker.
