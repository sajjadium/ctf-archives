# Evidence field guide

Work on copies. Do not open the shortcut, load the DLL or contact any address recorded in this case. Offline parsers and archive readers are sufficient.

The registry attachment is a native saved subkey, not a copy of the complete on-disk SOFTWARE hive. An offline reader presents the saved key as its root. Tools that expect the full Windows hive hierarchy therefore need the saved-root path instead.

Wireshark's Export Objects → HTTP and TShark's `--export-objects http,DIRECTORY` recover reassembled HTTP response bodies. A DAV XML response, TCP stream with HTTP headers, and binary object are different byte sequences. When the evidence supplies an object hash, compare the exported file's exact bytes with it.

The following unrelated example checks byte handling if you reconstruct the derivation found in the evidence. These are published example inputs, not values from the acquired workstation:

```text
Binding key, hexadecimal:
000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f

Installation value:
00112233-4455-6677-8899-AABBCCDDEEFF

Message bytes:
UTF8("csctf26/briefing-for-one/v1") || 00 || UTF8("00112233-4455-6677-8899-aabbccddeeff")

HMAC-SHA-256, lowercase hexadecimal:
7dad69912b67470da7713c666337135b568030605bc2e88f99524596366d10d0
```

The installation text has no braces, whitespace, newline or final NUL. The one `00` byte shown above is between the two text strings. UTF-8 has no BOM. A 32-byte digest renders as all 64 hexadecimal characters.
