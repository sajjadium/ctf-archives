#!/usr/bin/env python3
"""Read-only userspace reconstruction of a degraded RAID-5 data area.

This helper knows nothing about md superblocks, filesystems or the files on
them.  You derive every geometry value from the member metadata yourself and
pass it on the command line.  It accepts exactly N-1 distinct member roles and
writes the flat logical byte stream of the array, recomputing the missing
member's data chunks from parity.

Supported layouts are the four standard rotating-parity layouts.  Roles are md
member roles (0..N-1), not file names.  Example:

  python3 raid5_extract.py --member 0:a.raw --member 2:b.raw --member 3:c.raw \\
      --member-count 4 --chunk-bytes 65536 --data-offset-bytes 1048576 \\
      --array-bytes 100663296 --layout left-symmetric --output array.img
"""
from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import BinaryIO, Iterable


class RecoveryError(ValueError):
    """Raised for invalid geometry or an incomplete set of member images."""


LAYOUTS = {
    "left-symmetric",
    "right-symmetric",
    "left-asymmetric",
    "right-asymmetric",
}


@dataclass(frozen=True)
class Geometry:
    member_count: int
    chunk_bytes: int
    data_offset_bytes: int
    array_bytes: int
    layout: str

    def validate(self) -> None:
        if self.member_count < 3:
            raise RecoveryError("RAID-5 requires at least three members")
        if self.chunk_bytes < 512 or self.chunk_bytes & (self.chunk_bytes - 1):
            raise RecoveryError("chunk size must be a power of two and at least 512")
        if self.chunk_bytes % 512:
            raise RecoveryError("chunk size must be sector aligned")
        if self.data_offset_bytes < 0 or self.data_offset_bytes % 512:
            raise RecoveryError("data offset must be a non-negative sector multiple")
        if self.array_bytes <= 0:
            raise RecoveryError("array byte length must be positive")
        if self.layout not in LAYOUTS:
            raise RecoveryError(f"unsupported RAID-5 layout: {self.layout}")

    @property
    def stripe_data_bytes(self) -> int:
        return (self.member_count - 1) * self.chunk_bytes

    @property
    def stripe_count(self) -> int:
        return (self.array_bytes + self.stripe_data_bytes - 1) // self.stripe_data_bytes


def parity_role(stripe: int, geometry: Geometry) -> int:
    """Return the rotating parity member role for one full stripe.

    Roles are md member roles, numbered 0..N-1, never filenames.  This is a
    data-area mapping only: md metadata offsets are passed explicitly.
    """
    rotation = stripe % geometry.member_count
    if geometry.layout.startswith("left-"):
        return geometry.member_count - 1 - rotation
    return rotation


def data_roles(stripe: int, geometry: Geometry) -> tuple[int, ...]:
    """Return physical member roles in logical data-chunk order for a stripe."""
    parity = parity_role(stripe, geometry)
    if geometry.layout.endswith("-symmetric"):
        return tuple((parity + 1 + index) % geometry.member_count
                     for index in range(geometry.member_count - 1))
    return tuple(role for role in range(geometry.member_count) if role != parity)


def parse_member(value: str) -> tuple[int, Path]:
    try:
        role_text, filename = value.split(":", 1)
        role = int(role_text, 10)
    except (ValueError, AttributeError) as exc:
        raise argparse.ArgumentTypeError("member must be ROLE:PATH") from exc
    if not filename:
        raise argparse.ArgumentTypeError("member path may not be empty")
    return role, Path(filename)


def _xor_chunks(chunks: Iterable[bytes], length: int) -> bytes:
    result = bytearray(length)
    count = 0
    for chunk in chunks:
        if len(chunk) != length:
            raise RecoveryError("truncated member data while reconstructing parity")
        count += 1
        for index, value in enumerate(chunk):
            result[index] ^= value
    if count == 0:
        raise RecoveryError("no chunks available for parity reconstruction")
    return bytes(result)


def _read_chunk(handle: BinaryIO, offset: int, chunk_bytes: int) -> bytes:
    handle.seek(offset)
    data = handle.read(chunk_bytes)
    if len(data) != chunk_bytes:
        raise RecoveryError("member is shorter than declared array geometry")
    return data


def _validate_members(members: dict[int, Path], geometry: Geometry) -> int:
    expected_roles = set(range(geometry.member_count))
    supplied_roles = set(members)
    if len(members) != geometry.member_count - 1:
        raise RecoveryError("supply exactly N-1 member images for a degraded RAID-5 array")
    if not supplied_roles <= expected_roles:
        raise RecoveryError("member role is outside 0..N-1")
    missing = expected_roles - supplied_roles
    if len(missing) != 1:
        raise RecoveryError("member roles must be unique and leave exactly one missing role")
    for role, path in members.items():
        try:
            info = path.stat()
        except OSError as exc:
            raise RecoveryError(f"cannot stat role {role} member: {exc}") from exc
        minimum = geometry.data_offset_bytes + geometry.stripe_count * geometry.chunk_bytes
        if info.st_size < minimum:
            raise RecoveryError(f"role {role} is shorter than declared data area")
        if not path.is_file():
            raise RecoveryError(f"role {role} is not a regular file")
    return next(iter(missing))


def reconstruct(members: dict[int, Path], geometry: Geometry, output: BinaryIO) -> None:
    """Write exactly `array_bytes` logical bytes to `output`.

    `members` maps independently derived md roles to raw member files.  The
    function does not read, infer, or validate any md metadata; callers must
    obtain geometry and roles through a separate forensic step.
    """
    geometry.validate()
    missing_role = _validate_members(members, geometry)
    handles: dict[int, BinaryIO] = {}
    try:
        handles = {role: path.open("rb") for role, path in members.items()}
        remaining = geometry.array_bytes
        for stripe in range(geometry.stripe_count):
            member_offset = geometry.data_offset_bytes + stripe * geometry.chunk_bytes
            parity = parity_role(stripe, geometry)
            logical_roles = data_roles(stripe, geometry)
            chunks: dict[int, bytes] = {
                role: _read_chunk(handle, member_offset, geometry.chunk_bytes)
                for role, handle in handles.items()
            }
            if missing_role != parity:
                # XOR of parity and all surviving data chunks recovers the single
                # absent data chunk.  A missing parity chunk is irrelevant to the
                # logical byte stream.
                chunks[missing_role] = _xor_chunks(chunks.values(), geometry.chunk_bytes)
            for role in logical_roles:
                wanted = min(remaining, geometry.chunk_bytes)
                if wanted <= 0:
                    return
                output.write(chunks[role][:wanted])
                remaining -= wanted
        if remaining != 0:
            raise RecoveryError("declared array length was not reconstructed")
    finally:
        for handle in handles.values():
            handle.close()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--member", action="append", default=[], type=parse_member,
                        metavar="ROLE:PATH", help="one present raw member, by md role")
    parser.add_argument("--member-count", type=int, required=True)
    parser.add_argument("--chunk-bytes", type=int, required=True)
    parser.add_argument("--data-offset-bytes", type=int, required=True)
    parser.add_argument("--array-bytes", type=int, required=True)
    parser.add_argument("--layout", choices=sorted(LAYOUTS), required=True)
    parser.add_argument("--output", type=Path, required=True,
                        help="output file for the reconstructed logical byte stream; "
                             "an existing file is refused unless --force is given")
    parser.add_argument("--force", action="store_true",
                        help="overwrite the output file if it already exists")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    members: dict[int, Path] = {}
    for role, path in args.member:
        if role in members:
            raise SystemExit(f"error: duplicate member role {role}")
        members[role] = path
    geometry = Geometry(
        member_count=args.member_count,
        chunk_bytes=args.chunk_bytes,
        data_offset_bytes=args.data_offset_bytes,
        array_bytes=args.array_bytes,
        layout=args.layout,
    )
    if args.output.exists() and not args.force:
        raise SystemExit("error: output exists (refusing overwrite; use --force deliberately)")
    try:
        mode = "wb" if args.force else "xb"
        with args.output.open(mode) as output:
            reconstruct(members, geometry, output)
    except (OSError, RecoveryError) as exc:
        try:
            if args.output.exists() and args.output.stat().st_size == 0:
                args.output.unlink()
        except OSError:
            pass
        raise SystemExit(f"error: {exc}") from exc
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
