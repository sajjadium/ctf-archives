# Registry export profile

This is the complete public contract of an invented application, not a national standard. Reproduce the completed export for `LR-731`; a fingerprint of a source file is not the requested answer.

## Evidence and worker semantics

`registry.sqlite` and its matching `registry.sqlite-wal` were acquired together while the sole writer was quiescent but still open. The main database was checkpointed before the retained WAL epoch; there was no checkpoint or reset during that epoch. Do not assume that opening the current view recovers an earlier job's data. File mtimes do not identify transaction times. The omitted `-shm` is rebuildable coordination state.

The worker loads one immutable manifest, begins an IMMEDIATE SQLite transaction, queries that manifest's parcel set, stages the resulting export, updates that job from `QUEUED` to `COMPLETED`, and commits. No registry write occurs between the query and commit. Only after successful commit does the worker publish that same manifest as the delivery receipt and promote the staged export. The job row persists after completion. The acquired receipt comes from the receiving spool after successful publication. It establishes delivered scope and order, not later application of the records or cryptographic authenticity.

Use the registry state at that job's transition to `COMPLETED`, not an arbitrarily later view where the completed row still exists. SQLite frames contain page images; a transaction need not occupy one frame. Preserve transaction consistency when reconstructing page versions. A frame's nonzero database-size field marks a commit. Matching salts and SQLite's cumulative checksum delimit valid frames within the acquired epoch. The retained main database supplies pages not replaced by an eligible WAL frame. These are ordinary SQLite mechanics, not a custom protocol or a vulnerable SQLite version.

Optional format background: [database/WAL format](https://sqlite.org/fileformat2.html), [WAL operation](https://sqlite.org/wal.html), [file lifecycle](https://sqlite.org/walformat.html), [transaction locking](https://sqlite.org/lang_transaction.html). The evidence and all case-specific rules are supplied locally.

## Schema

```sql
CREATE TABLE parcel(parcel_id INTEGER PRIMARY KEY, district TEXT NOT NULL, plot_ref TEXT NOT NULL UNIQUE);
CREATE TABLE holder(holder_id INTEGER PRIMARY KEY, registry_ref TEXT NOT NULL UNIQUE);
CREATE TABLE title(parcel_id INTEGER NOT NULL REFERENCES parcel(parcel_id), holder_id INTEGER NOT NULL REFERENCES holder(holder_id), interest_bps INTEGER NOT NULL CHECK(interest_bps BETWEEN 1 AND 10000), instrument_ref TEXT NOT NULL, PRIMARY KEY(parcel_id,holder_id));
CREATE TABLE export_job(job_id TEXT PRIMARY KEY NOT NULL, state TEXT NOT NULL CHECK(state IN ('QUEUED','COMPLETED')));
```

Identifiers/text use nonempty `[A-Z0-9-]+`. Integers are positive and below 2147483647. No field is NULL; no floating point, Unicode normalization, timezone or locale rule affects the export. Every parcel's title interests sum to 10000 basis points. A parcel can have multiple holders: include every ownership row. There are no triggers, virtual tables or extension requirements.

`delivery.csv` is ASCII-compatible UTF-8, LF-terminated, with header `job_id,position,parcel_id`. It contains job `LR-731`, twelve distinct existing parcel IDs, and positions 1 through 12 exactly once. Validate it and load its rows into a temporary `manifest(job_id TEXT, position INTEGER, parcel_id INTEGER)` table. Do not substitute database row order for delivery order.

## Exact export

Run this query against the historical registry state described above, with the receipt loaded as `manifest`:

```sql
SELECT m.position,p.parcel_id,p.district,p.plot_ref,h.registry_ref,t.interest_bps,t.instrument_ref
FROM manifest AS m JOIN parcel AS p ON p.parcel_id=m.parcel_id
JOIN title AS t ON t.parcel_id=p.parcel_id JOIN holder AS h ON h.holder_id=t.holder_id
WHERE m.job_id='LR-731' ORDER BY m.position ASC,h.registry_ref COLLATE BINARY ASC;
```

The first line contains these seven names, separated by actual single TAB bytes and terminated by LF:

```text
position\tparcel_id\tdistrict\tplot_ref\tregistry_ref\tinterest_bps\tinstrument_ref\n
```

In that notation `\t` means byte `09` and `\n` means byte `0a`, not a backslash plus a letter. Append every query row, in query order, with one TAB between fields and one LF after each row, including the last. Integers use unsigned decimal without leading zeros. Copy text exactly. Do not add a BOM, quotes, spaces or blank lines. Encode the complete file as ASCII-compatible UTF-8.

Compute SHA-256 of the complete export, including header and final LF. Submit `CSCTF{last_commit_` followed by all 64 lowercase hexadecimal digest characters followed by `}`. No key, secret prefix, enum or attempt budget is involved. The hash is just a compact submission format.

## Unrelated serialization example

These two ownership rows illustrate formatting only, not the target case. The example intentionally has only one parcel and is not a complete twelve-parcel submission:

```text
1\t9901\tD-EX\tP-EX\tHR-EXA\t4000\tIN-EX\n
1\t9901\tD-EX\tP-EX\tHR-EXB\t6000\tIN-EX\n
```

Complete example bytes, including the actual header, as hexadecimal:

```text
706f736974696f6e0970617263656c5f696409646973747269637409706c6f745f7265660972656769737472795f72656609696e7465726573745f62707309696e737472756d656e745f7265660a31093939303109442d455809502d45580948522d455841093430303009494e2d45580a31093939303109442d455809502d45580948522d455842093630303009494e2d45580a
```

SHA-256 of those example bytes: `26114af3af5d4133b5c0f617d5a41ae0185701de214031e75ded356f86eb0dd9`. This is a formatting check, not the case answer.
