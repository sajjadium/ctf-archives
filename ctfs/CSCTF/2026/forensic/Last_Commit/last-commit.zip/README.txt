LAST COMMIT

The national land registry looks normal again, but a completed restoration export may have carried altered ownership into regional offices. Reproduce the ownership export completed by job LR-731 and submit its CSCTF{...} fingerprint.

Provided: registry.sqlite, registry.sqlite-wal, delivery.csv, export-profile.md, provenance.json and SHA256SUMS. The export profile defines the application, requested records, query, exact byte format and submission format.

All institutions, accounts, properties and incidents are fictional. The task is to determine the completed export, not actor attribution or whether recipients applied the records. You need only these files and local SQLite/data tools. Do not install an extension, execute a supplied program, contact a service, upload evidence elsewhere or act on any real land/property records.

Preserve this extraction as evidence and work on disposable copies. Opening a SQLite database with its matching WAL can create an SHM file or change working copies during normal cleanup. Do not open the preserved original pair directly. Keep matching DB/WAL basenames together; do not remove, rename or normalize the original WAL. SHA256SUMS covers every other member of this archive. Check the outer archive's published length and hash before extraction.

Every participant receives identical files, task, hints and answer. Automation using native forensic tools is allowed. There is no live service, timer, special submission quota, per-team variation or external solve dependency.
