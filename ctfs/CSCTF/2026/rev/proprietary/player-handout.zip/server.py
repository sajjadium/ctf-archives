#!/usr/bin/env python3
import html
import json
import os
import resource
import signal
import subprocess
import tempfile
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(os.environ.get("PORT", "8080"))
GRANT_CODE = os.environ.get("GRANT_CODE", "")
CARDVAL = os.environ.get("CARDVAL", os.path.join(os.path.dirname(os.path.abspath(__file__)), "cardval"))
MAX_BODY = 16384
RUN_TIMEOUT = 5


def apply_limits(pid):
    requested = (
        (resource.RLIMIT_AS, 256 * 1024 * 1024),
        (resource.RLIMIT_CPU, 2),
        (resource.RLIMIT_FSIZE, 8 * 1024 * 1024),
        (resource.RLIMIT_NOFILE, 64),
    )
    for limit, value in requested:
        _, hard = resource.getrlimit(limit)
        bound = value if hard == resource.RLIM_INFINITY else min(value, hard)
        resource.prlimit(pid, limit, (bound, bound))


def parse_multipart(body, content_type):
    if "boundary=" not in content_type:
        return None
    boundary = content_type.split("boundary=", 1)[1].strip().strip('"')
    if not boundary or len(boundary) > 70:
        return None
    delim = b"--" + boundary.encode("latin-1")
    for part in body.split(delim):
        if not part or part in (b"--", b"--\r\n"):
            continue
        if part.startswith(b"\r\n"):
            part = part[2:]
        sep = part.find(b"\r\n\r\n")
        if sep < 0:
            continue
        header_blob = part[:sep]
        content = part[sep + 4:]
        if content.endswith(b"\r\n"):
            content = content[:-2]
        header_text = header_blob.decode("latin-1", "replace")
        if 'filename="' in header_text or 'name="card"' in header_text:
            return content
    return None


def validate_card(card_bytes):
    fd, path = tempfile.mkstemp(prefix="card-", suffix=".bin")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(card_bytes)
        child_env = {key: value for key, value in os.environ.items() if key != "GRANT_CODE"}
        try:
            p = subprocess.Popen(
                [CARDVAL, "check", path, "--json"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                start_new_session=True,
                env=child_env,
            )
        except OSError:
            return False
        try:
            apply_limits(p.pid)
            stdout, _stderr = p.communicate(timeout=RUN_TIMEOUT)
        except subprocess.TimeoutExpired:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            p.communicate()
            return False
        except (OSError, ValueError):
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            p.communicate()
            return False
        if p.returncode not in (0, 2):
            return False
        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            return False
        return bool(data.get("accepted"))
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


PAGE = """<!doctype html>
<html>
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>District 7 — Card checker</title>
<style>
body{font-family:monospace;background:#0c1013;color:#d7dde3;max-width:38em;margin:4em auto;padding:0 1.5em}
h1{color:#ffd166;font-size:1.35em}form{display:flex;gap:.75em;align-items:center;flex-wrap:wrap;margin:2em 0}
input[type=file]{max-width:100%;padding:.8em;border:1px solid #2a323c;background:#121820;color:#d7dde3}
button{padding:.8em 1.1em;border:1px solid #2a323c;background:#1d2a34;color:#fff;cursor:pointer}
.accepted{color:#9be38e}.rejected{color:#ff8585}.grant{padding:1em;background:#121820;overflow-wrap:anywhere}
</style></head>
<body>
<h1>District 7 — Card checker</h1>
<form action="/check" method="post" enctype="multipart/form-data">
<input type="file" name="card" required>
<button type="submit">Check card</button>
</form>
{{RESULT}}
</body></html>
"""


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "switchyard-terminal/1.0"

    def log_message(self, fmt, *args):
        pass

    def send_bytes(self, code, body, ctype):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def send_page(self, code, accepted=None):
        if accepted is True:
            result = (
                '<p class="accepted">Accepted</p>'
                f'<p class="grant"><code>{html.escape(GRANT_CODE)}</code></p>'
            )
        elif accepted is False:
            result = '<p class="rejected">Rejected</p>'
        else:
            result = ""
        self.send_bytes(
            code,
            PAGE.replace("{{RESULT}}", result).encode(),
            "text/html; charset=utf-8",
        )

    def send_json(self, code, obj):
        self.send_bytes(code, json.dumps(obj).encode(), "application/json")

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path
        if path in ("/", "/index.html", "/check"):
            self.send_page(200)
        elif path == "/status":
            self.send_json(200, {"ok": True})
        else:
            self.send_bytes(404, b"not found", "text/plain; charset=utf-8")

    def do_POST(self):
        path = urllib.parse.urlparse(self.path).path
        if path != "/check":
            self.send_bytes(404, b"not found", "text/plain; charset=utf-8")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_page(400, False)
            return
        if length <= 0 or length > MAX_BODY:
            self.send_page(413, False)
            return
        body = self.rfile.read(length)
        ctype = self.headers.get("Content-Type", "")
        if ctype.startswith("multipart/form-data"):
            card = parse_multipart(body, ctype)
        else:
            card = body
        if card is None or len(card) < 16:
            self.send_page(400, False)
            return
        self.send_page(200, validate_card(card))


def main():
    if not GRANT_CODE:
        print("error: GRANT_CODE env var must be set", flush=True)
        raise SystemExit(1)
    if not os.path.exists(CARDVAL):
        print(f"error: cardval binary not found at {CARDVAL}", flush=True)
        raise SystemExit(1)
    httpd = ThreadingHTTPServer(("", PORT), Handler)
    print(f"District 7 switchyard terminal listening on :{PORT}", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
