# District 7 - Switchyard Credential

Operation Dawn theatre, District 7. You pulled the maintenance terminal's
software from a decommissioned reader unit, along with a 16-byte fragment of an
operator card that did not survive recovery.

Forge a working operator card and the terminal will issue an access grant.

`starter.bin` is a 16-byte fragment of the destroyed card. It is a valid
(but empty) card image.

1. Reverse engineer `cardval` to recover the card image layout, the
   integrity algorithm and its coverage, the key derivation, and the exact
   rules the terminal's scripted shift session enforces.
2. Construct your own working `card.bin`.
3. Iterate locally: `./cardval check card.bin` reports the check reached. The
   terminal session itself is intentionally summarized; reconstruct its
   behavior from the binary. For a local web checker, run
   `docker compose up --build` and open `http://127.0.0.1:8080/`; it issues
   the placeholder grant `D7-LOCAL-TEST`, not a live access grant.

When your card is accepted locally, submit it to the District 7 checkpoint
checker.

## Submission

Upload `card.bin` on the checker page, or:

```
curl -F 'card=@card.bin' http://<checker-host>/check
```

The checker displays `Accepted` or `Rejected`. An accepted card also
displays the access grant.

## Rules and scope

- The card format, applications, keys, checksums, commands, and tokens in
  this scenario are **fictional**. They are loosely *inspired* by the
  structure of real contactless infrastructure credentials, but this is not
  a real SCADA or smart card protocol, and the integrity codes are not
  cryptographic authenticators.
- No physical hardware is needed or useful. Nothing here touches real
  infrastructure.
- The terminal is deterministic.
