# District 7 — Switchyard Credential

This folder contains the District 7 operator materials. See `DESCRIPTION.md`
for the briefing and submission instructions.

## Files

- `cardval` — Linux x86-64 local validator/simulator. Run
  `./cardval check card.bin`.
- `Dockerfile` — optional offline Docker wrapper for the same validator.
- `docker-compose.yml` and `Dockerfile.checker` — optional local web checker
  that issues the placeholder grant `D7-LOCAL-TEST`.
- `starter.bin` — valid 16-byte empty-card image.

Create `card.bin` yourself, then submit it to the checker URL supplied by the
event. The local validator does not contain the access grant; the checkpoint
service validates every submission independently.

## Run the validator in Docker

Build once from this folder:

```sh
docker build -t district7-cardval .
```

From the folder containing your `card.bin`, run:

```sh
docker run --rm --network none --read-only \
  -v "$PWD:/cards:ro" -w /cards \
  district7-cardval check card.bin
```

The container only runs `cardval` against the mounted file. It has no network
access, does not submit anything, and contains no access grant or server code.
The image targets Linux x86-64; ARM hosts need Docker's amd64 emulation enabled.

## Run the local web checker with Docker Compose

From this folder:

```sh
docker compose up --build
```

Open `http://127.0.0.1:8080/`, upload your `card.bin`, and check it. The local
checker issues the placeholder grant `D7-LOCAL-TEST`; it is not a live access
grant. Stop it with `docker compose down`. The service listens only on your
loopback address.

This is a fictional offline card-image scenario. It does not implement a
real smart-card or SCADA protocol, and its checksum is not cryptographic.
