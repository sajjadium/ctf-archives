// relic - ret2csu
// gcc -O0 -fno-stack-protector -no-pie -Wl,-z,relro,-z,now -o relic relic.c
//
// Built on Ubuntu 20.04 (glibc 2.31) so the real __libc_csu_init is linked in.
#include <stdlib.h>
#include <unistd.h>

#if __GLIBC__ > 2 || (__GLIBC__ == 2 && __GLIBC_MINOR__ >= 34)
// glibc >= 2.34 no longer links __libc_csu_init into executables. For local builds
// only: an instruction-for-instruction copy of the glibc 2.31 x86-64 version (it is never called).
__asm__(
    ".intel_syntax noprefix\n"
    ".text\n"
    ".globl __libc_csu_init\n"
    ".type __libc_csu_init, @function\n"
    "__libc_csu_init:\n"
    "    endbr64\n"
    "    push r15\n"
    "    lea  r15, [rip+__init_array_start]\n"
    "    push r14\n"
    "    mov  r14, rdx\n"
    "    push r13\n"
    "    mov  r13, rsi\n"
    "    push r12\n"
    "    mov  r12d, edi\n"
    "    push rbp\n"
    "    lea  rbp, [rip+__init_array_end]\n"
    "    push rbx\n"
    "    sub  rbp, r15\n"
    "    sub  rsp, 8\n"
    "    call _init\n"
    "    sar  rbp, 3\n"
    "    je   2f\n"
    "    xor  ebx, ebx\n"
    "    nop  dword ptr [rax+rax*1+0x0]\n"
    "1:\n"
    "    mov  rdx, r14\n"
    "    mov  rsi, r13\n"
    "    mov  edi, r12d\n"
    "    call qword ptr [r15+rbx*8]\n"
    "    add  rbx, 1\n"
    "    cmp  rbp, rbx\n"
    "    jne  1b\n"
    "2:\n"
    "    add  rsp, 8\n"
    "    pop  rbx\n"
    "    pop  rbp\n"
    "    pop  r12\n"
    "    pop  r13\n"
    "    pop  r14\n"
    "    pop  r15\n"
    "    ret\n"
    ".size __libc_csu_init, .-__libc_csu_init\n"
    ".att_syntax prefix\n"
);
#endif

#define say(s) write(1, s, sizeof(s) - 1)

static int visited;

static void vault(void) {
    char buf[0x40];

    if (visited++) {
        say("The vault only opens once.\n");
        _exit(1);
    }
    say("Leave something in the vault: ");
    read(0, buf, 0x120);
    say("\n");
}

int main(void) {
    alarm(60);
    say("~~ relic ~~\n");
    say("An old machine. Older than the libc it runs on.\n");
    vault();
    say("Sealed.\n");
    return 0;
}
