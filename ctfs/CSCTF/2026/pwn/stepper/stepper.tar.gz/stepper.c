// stepper - staged shellcode
// gcc -O0 -fstack-protector-strong -fPIE -pie -Wl,-z,relro,-z,now -o stepper stepper.c
//
// Your code runs one tiny step at a time. Registers survive between steps,
// the instruction slot does not. Some bytes are not welcome here.
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

#define MAX_STEPS  12
#define STEP_SIZE  6
#define SLOT_SIZE  8

enum { RAX, RBX, RCX, RDX, RSI, RDI, RBP, RSP, R8, R9, R10, R11, R12, R13, R14, R15 };

uint64_t ctx[16];        // guest register file, persists across steps
uint64_t host_rsp;
uint64_t guest_rip;

void run_step(void *entry);
void guest_exit(void);

__asm__(
    ".intel_syntax noprefix\n"
    ".text\n"
    ".globl run_step\n"
    "run_step:\n"
    "    push rbx\n push rbp\n push r12\n push r13\n push r14\n push r15\n"
    "    mov  [rip+host_rsp], rsp\n"
    "    mov  [rip+guest_rip], rdi\n"
    "    mov  rax, [rip+ctx+0x00]\n"
    "    mov  rbx, [rip+ctx+0x08]\n"
    "    mov  rcx, [rip+ctx+0x10]\n"
    "    mov  rdx, [rip+ctx+0x18]\n"
    "    mov  rsi, [rip+ctx+0x20]\n"
    "    mov  rdi, [rip+ctx+0x28]\n"
    "    mov  rbp, [rip+ctx+0x30]\n"
    "    mov  r8,  [rip+ctx+0x40]\n"
    "    mov  r9,  [rip+ctx+0x48]\n"
    "    mov  r10, [rip+ctx+0x50]\n"
    "    mov  r11, [rip+ctx+0x58]\n"
    "    mov  r12, [rip+ctx+0x60]\n"
    "    mov  r13, [rip+ctx+0x68]\n"
    "    mov  r14, [rip+ctx+0x70]\n"
    "    mov  r15, [rip+ctx+0x78]\n"
    "    mov  rsp, [rip+ctx+0x38]\n"
    "    jmp  qword ptr [rip+guest_rip]\n"
    ".globl guest_exit\n"
    "guest_exit:\n"
    "    mov  [rip+ctx+0x00], rax\n"
    "    mov  [rip+ctx+0x08], rbx\n"
    "    mov  [rip+ctx+0x10], rcx\n"
    "    mov  [rip+ctx+0x18], rdx\n"
    "    mov  [rip+ctx+0x20], rsi\n"
    "    mov  [rip+ctx+0x28], rdi\n"
    "    mov  [rip+ctx+0x30], rbp\n"
    "    mov  [rip+ctx+0x38], rsp\n"
    "    mov  [rip+ctx+0x40], r8\n"
    "    mov  [rip+ctx+0x48], r9\n"
    "    mov  [rip+ctx+0x50], r10\n"
    "    mov  [rip+ctx+0x58], r11\n"
    "    mov  [rip+ctx+0x60], r12\n"
    "    mov  [rip+ctx+0x68], r13\n"
    "    mov  [rip+ctx+0x70], r14\n"
    "    mov  [rip+ctx+0x78], r15\n"
    "    mov  rsp, [rip+host_rsp]\n"
    "    pop r15\n pop r14\n pop r13\n pop r12\n pop rbp\n pop rbx\n"
    "    cld\n"
    "    ret\n"
    ".att_syntax prefix\n"
);

static const unsigned char banned[] = { 0x0f, 0x05, 0x34, 0xcd };

static void setup(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    alarm(60);
}

static void die(const char *msg) {
    puts(msg);
    _exit(1);
}

// raw read(): nothing may be buffered behind the player's back
static void read_exact(unsigned char *buf, size_t n) {
    size_t got = 0;
    while (got < n) {
        ssize_t r = read(0, buf + got, n - got);
        if (r <= 0)
            die("connection lost");
        got += r;
    }
}

static long read_num(void) {
    char line[16];
    size_t i = 0;
    char c;
    while (i < sizeof(line) - 1) {
        if (read(0, &c, 1) != 1)
            die("connection lost");
        if (c == '\n')
            break;
        line[i++] = c;
    }
    line[i] = 0;
    return strtol(line, NULL, 10);
}

int main(void) {
    unsigned char chunk[STEP_SIZE];

    setup();
    puts("=== STEPPER ===");
    puts("Your code runs one small step at a time.");
    printf("Up to %d steps, %d bytes each. Registers are yours to keep.\n", MAX_STEPS, STEP_SIZE);
    puts("Bytes 0x0f 0x05 0x34 0xcd are forbidden.\n");

    unsigned char *code = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE | PROT_EXEC,
                               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    unsigned char *stack = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE,
                                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (code == MAP_FAILED || stack == MAP_FAILED)
        die("mmap failed");

    // slot: [ 8 bytes of player code ][ jmp qword ptr [rip+0] ][ &guest_exit ]
    memset(code, 0xf4, 0x1000);   // hlt everywhere else
    code[SLOT_SIZE + 0] = 0xff;
    code[SLOT_SIZE + 1] = 0x25;
    memset(code + SLOT_SIZE + 2, 0, 4);
    uint64_t exit_addr = (uint64_t)guest_exit;
    memcpy(code + SLOT_SIZE + 6, &exit_addr, 8);

    memset(ctx, 0, sizeof(ctx));
    ctx[RSP] = (uint64_t)(stack + 0x1000 - 0x100);

    for (int step = 1; step <= MAX_STEPS; step++) {
        printf("[step %d/%d] length> ", step, MAX_STEPS);
        long n = read_num();
        if (n <= 0)
            break;
        if (n > STEP_SIZE)
            die("too long.");
        printf("code> ");
        read_exact(chunk, n);

        for (long i = 0; i < n; i++)
            for (size_t j = 0; j < sizeof(banned); j++)
                if (chunk[i] == banned[j])
                    die("forbidden byte, step rejected.");

        memset(code, 0x90, SLOT_SIZE);
        memcpy(code, chunk, n);
        run_step(code);
        puts("step done.");
    }
    puts("out of steps.");
    return 0;
}
