// sigil - SROP
// gcc -O0 -fno-stack-protector -fcf-protection=none -nostdlib -static -no-pie -o sigil sigil.c
//
// No libc. No gifts. Just a kernel that trusts whatever is on the stack.
#define SYS_read   0
#define SYS_write  1
#define SYS_alarm  37
#define SYS_exit   60

static long sys3(long nr, long a, long b, long c) {
    long ret;
    __asm__ volatile ("syscall"
                      : "=a"(ret)
                      : "a"(nr), "D"(a), "S"(b), "d"(c)
                      : "rcx", "r11", "memory");
    return ret;
}

static long attempts;

#define say(s) sys3(SYS_write, 1, (long)(s), sizeof(s) - 1)

static void listen(void) {
    char buf[0x40];

    attempts++;
    say("speak the sigil: ");
    sys3(SYS_read, 0, (long)buf, 0x400);
}

void _start(void) {
    sys3(SYS_alarm, 60, 0, 0);
    say("~~ sigil ~~\nthe kernel remembers every frame you show it.\n");
    listen();
    say("silence.\n");
    sys3(SYS_exit, 0, 0, 0);
}
