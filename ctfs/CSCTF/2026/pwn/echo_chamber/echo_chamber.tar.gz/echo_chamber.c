// echo_chamber - hard ret2libc
// gcc -O0 -fstack-protector-strong -fPIE -pie -Wl,-z,relro,-z,now -o echo_chamber echo_chamber.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void setup(void) {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    alarm(60);
}

static void banner(void) {
    puts("+----------------------------------------+");
    puts("|            THE ECHO CHAMBER            |");
    puts("|  whatever you say, it says right back  |");
    puts("+----------------------------------------+");
}

static void chamber(void) {
    char buf[0x50];

    puts("The chamber listens. Say 'bye' to leave.");
    for (;;) {
        printf("> ");
        read(0, buf, 0x70);
        if (strncmp(buf, "bye", 3) == 0)
            break;
        printf("echo: %s\n", buf);
    }
}

int main(void) {
    setup();
    banner();
    chamber();
    puts("The chamber falls silent.");
    return 0;
}
