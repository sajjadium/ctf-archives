# MCSA Cutover settlement engine (source bundle)

Published for audit. This is the source of the settlement engine that executes
instructions against queued batches on the MCSA real-time settlement rail.

- `src/server.js`: HTTP surface, sessions, instruction execution, receipts
- `src/tiers.js`: tier resolution
- `src/intake.js`: batch manifest intake
- `vendor/flatted/`: wire-format library, pinned at 3.4.1

The engine loads the value day (register, journal, buffer and tier table) from
`STATE_FILE` at start-up and listens on `ENGINE_PORT`. The state file is written
by the rail's state service and is not part of this bundle, so `node src/server.js`
on its own exits at start-up.

The manifest wire format is `flatted` 3.4.1. The API and error taxonomy are
published at `/api/v1/schema` on the duty console.
