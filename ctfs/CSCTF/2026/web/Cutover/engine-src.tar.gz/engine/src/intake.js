"use strict";

const flatted = require("../vendor/flatted");

const ROUTING_DEFAULTS = { priority: "NORMAL", channel: "RTGS" };

// Overlay the rail routing defaults and the participant's routing hints onto
// the manifest's basis record; the effective basis travels with the batch.
function merge(target, source) {
  for (const key of Object.keys(source)) target[key] = source[key];
  return target;
}

function normalise(manifest) {
  const basis = manifest.basis ?? {};
  merge(basis, ROUTING_DEFAULTS);
  merge(basis, manifest.hints ?? {});
  manifest.basis = basis;
  return manifest;
}

function parse(body) {
  return flatted.parse(body);
}

function validate(manifest, state) {
  if (typeof manifest !== "object" || manifest === null || Array.isArray(manifest)) {
    return { field: "body" };
  }
  if (typeof manifest.batch !== "string" || manifest.batch.length > 64) {
    return { field: "batch" };
  }
  if (typeof manifest.originator !== "string") {
    return { field: "originator" };
  }
  if (manifest.valueDate !== state.window.valueDate) {
    return { field: "valueDate" };
  }
  if (typeof manifest.declaredAggregateMinor !== "number" ||
      !Number.isInteger(manifest.declaredAggregateMinor) ||
      manifest.declaredAggregateMinor <= 0) {
    return { field: "declaredAggregateMinor" };
  }
  if (!Array.isArray(manifest.instructions) || manifest.instructions.length === 0) {
    return { field: "instructions" };
  }
  for (const instruction of manifest.instructions) {
    if (typeof instruction !== "object" || instruction === null) {
      return { field: "instructions" };
    }
    if (!Number.isInteger(instruction.amountMinor) || instruction.amountMinor <= 0) {
      return { field: "instructions.amountMinor" };
    }
    if (typeof instruction.counterparty !== "string") {
      return { field: "instructions.counterparty" };
    }
  }
  if (!state.participants.some((p) => p.bic === manifest.originator)) {
    return { field: "originator" };
  }
  if (state.batches.some((b) => b.id === manifest.batch)) {
    return { field: "batch" };
  }
  return null;
}

module.exports = { parse, normalise, validate, merge };
