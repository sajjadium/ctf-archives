"use strict";

// The tier table is an ordered Array of rows, least privileged first. Each row
// keeps its action grants in a lookup container so checks stay O(1) on the
// instruction path.

function container(actions) {
  const grants = [];
  for (const action of actions) grants[action] = true;
  return grants;
}

function compile(rows) {
  return rows.map((row) => ({ role: row.role, grants: container(row.actions) }));
}

function indexOf(table, role) {
  for (let i = 0; i < table.length; i++) {
    if (table[i].role === role) return i;
  }
  return 0;
}

function grantsFor(table, session) {
  const row = table[session.rank] || table[0];
  return row.grants;
}

function permitted(table, session, action) {
  return grantsFor(table, session)[action] === true;
}

module.exports = { compile, indexOf, grantsFor, permitted };
