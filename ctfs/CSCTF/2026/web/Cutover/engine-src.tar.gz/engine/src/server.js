"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const tiers = require("./tiers");
const intake = require("./intake");

const STATE_FILE = process.env.STATE_FILE ||
  path.join(process.env.STATE_DIR || "/app/state", "state.json");
const PORT = Number(process.env.ENGINE_PORT || 8082);
const FLAG = process.env.FLAG ||
  ("CSCTF{" + crypto.randomBytes(16).toString("hex") + "}");
const WINDOW_SECONDS = Number(process.env.WINDOW_SECONDS || 43200);
const OP_START_SECONDS = 14 * 3600 + 55 * 60;
const CUTOVER_SECONDS = 16 * 3600;

const state = JSON.parse(fs.readFileSync(STATE_FILE, "utf8"));
const table = tiers.compile(state.tierTable);
const operatorRank = tiers.indexOf(table, "OPERATOR");

const startedAt = Date.now();
const sessions = new Map();
const queued = state.batches.slice();
const receipts = [];
const limits = new Map();

const RATE = {
  manifests: { limit: 20, window: 480 },
  instructions: { limit: 60, window: 480 },
};

function readBody(req, max) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on("data", (chunk) => {
      size += chunk.length;
      if (size > max) {
        reject(new Error("body too large"));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function send(res, status, body, extra) {
  const payload = JSON.stringify(body);
  const headers = Object.assign(
    { "content-type": "application/json; charset=utf-8" },
    extra || {}
  );
  res.writeHead(status, headers);
  res.end(payload);
}

function fail(res, status, code, detail) {
  const body = { error: code };
  if (detail) body.detail = detail;
  send(res, status, body);
}

function sessionFor(req) {
  const id = req.headers["x-session"];
  if (typeof id !== "string" || id.length < 8 || id.length > 64) return null;
  let session = sessions.get(id);
  if (!session) {
    session = {
      id,
      role: "OPERATOR",
      rank: operatorRank,
      createdAt: new Date().toISOString(),
    };
    sessions.set(id, session);
  }
  return session;
}

function meter(res, session, bucket) {
  const rule = RATE[bucket];
  const now = Date.now();
  let entry = limits.get(session.id + ":" + bucket);
  if (!entry || now - entry.start >= rule.window * 1000) {
    entry = { start: now, count: 0 };
    limits.set(session.id + ":" + bucket, entry);
  }
  entry.count += 1;
  const remaining = Math.max(0, rule.limit - entry.count);
  const reset = Math.ceil((entry.start + rule.window * 1000 - now) / 1000);
  res.setHeader("RateLimit-Limit", String(rule.limit));
  res.setHeader("RateLimit-Remaining", String(remaining));
  res.setHeader("RateLimit-Reset", String(reset));
  return entry.count <= rule.limit;
}

function settledOf(batch) {
  return batch.instructions.reduce((sum, i) => sum + i.amountMinor, 0);
}

function flagUnlock(batchId, settled) {
  return crypto.createHash("sha256")
    .update("cutover|" + batchId + "|" + settled)
    .digest("hex");
}

function clock() {
  const elapsed = (Date.now() - startedAt) / 1000;
  const fraction = Math.min(1, elapsed / WINDOW_SECONDS);
  const operational = OP_START_SECONDS + Math.round(fraction * (CUTOVER_SECONDS - OP_START_SECONDS));
  const fmt = (s) =>
    String(Math.floor(s / 3600)).padStart(2, "0") + ":" +
    String(Math.floor((s % 3600) / 60)).padStart(2, "0") + ":" +
    String(Math.floor(s % 60)).padStart(2, "0");
  return {
    operational: fmt(operational),
    cutover: fmt(CUTOVER_SECONDS),
    valueDate: state.window.valueDate,
    secondsRemaining: Math.max(0, Math.round(WINDOW_SECONDS - elapsed)),
    windowSeconds: WINDOW_SECONDS,
  };
}

function handleSession(req, res) {
  const session = sessionFor(req);
  if (!session) return fail(res, 401, "session.required");
  const grants = tiers.grantsFor(table, session);
  send(res, 200, {
    session: {
      id: session.id,
      role: session.role,
      tier: table[session.rank].role,
      grants: Object.keys(grants).sort(),
      createdAt: session.createdAt,
    },
    rail: state.rail,
  });
}

function handleManifest(req, res) {
  const session = sessionFor(req);
  if (!session) return fail(res, 401, "session.required");
  if (!meter(res, session, "manifests")) return fail(res, 429, "rate.limited");

  readBody(req, 65536)
    .then((body) => {
      let manifest;
      try {
        manifest = intake.parse(body);
        intake.normalise(manifest);
      } catch (e) {
        return fail(res, 400, "manifest.invalid", { field: "body" });
      }
      const problem = intake.validate(manifest, { participants: state.participants, batches: queued, window: state.window });
      if (problem) return fail(res, 400, "manifest.invalid", problem);
      queued.push(manifest);
      send(res, 201, { batch: manifest.batch, queued: true, position: queued.length });
    })
    .catch(() => fail(res, 400, "manifest.invalid", { field: "body" }));
}

function handleInstruction(req, res) {
  const session = sessionFor(req);
  if (!session) return fail(res, 401, "session.required");
  if (!meter(res, session, "instructions")) return fail(res, 429, "rate.limited");

  readBody(req, 16384)
    .then((body) => {
      let instruction;
      try {
        instruction = JSON.parse(body);
      } catch (e) {
        return fail(res, 400, "instruction.invalid", { field: "body" });
      }
      if (typeof instruction !== "object" || instruction === null) {
        return fail(res, 400, "instruction.invalid", { field: "body" });
      }
      if (instruction.type !== "RECALL") {
        return fail(res, 400, "instruction.invalid", { field: "type" });
      }
      if (!tiers.permitted(table, session, "RECALL")) {
        return fail(res, 403, "tier.insufficient", { required: "SUPERVISOR", action: "RECALL" });
      }
      if (typeof instruction.batch !== "string") {
        return fail(res, 400, "instruction.invalid", { field: "batch" });
      }
      const batch = queued.find((b) => b.id === instruction.batch);
      if (!batch) return fail(res, 404, "batch.not_found");
      if (typeof instruction.value !== "number" || !Number.isFinite(instruction.value)) {
        return fail(res, 400, "instruction.invalid", { field: "value" });
      }
      // A wrong batch and a wrong value get the same refusal, so the response
      // does not say which of the two failed to reconcile.
      const settled = settledOf(batch);
      if (batch.id !== state.hostile || instruction.value !== settled) {
        return fail(res, 422, "recall.not_reconcilable", {
          message: "the recall does not reconcile: a recall is whole-batch and its value must equal the settled aggregate of a reconcilable batch",
        });
      }
      const expectedUnlock = flagUnlock(batch.id, settled);
      if (typeof instruction.unlock !== "string" ||
          instruction.unlock.toLowerCase() !== expectedUnlock) {
        return fail(res, 422, "flag.locked", {
          unlock_algorithm: "sha256-hex",
          unlock_input: "cutover|" + batch.id + "|" + settled,
          message: "recall reconciles; resubmit with unlock set to the sha256-hex digest of unlock_input to have the receipt issued",
        });
      }
      if (clock().secondsRemaining <= 0) {
        return fail(res, 409, "window.closed");
      }
      const receipt = {
        id: "RCPT-" + crypto.randomBytes(6).toString("hex").toUpperCase(),
        at: new Date().toISOString(),
        type: "RECALL",
        batch: batch.id,
        value: instruction.value,
        screening: req.headers["x-screening"] || "unscreened",
        settledAggregateMinor: settled,
        operator: session.role,
        flag: FLAG,
      };
      receipts.push(receipt);
      const index = queued.indexOf(batch);
      if (index >= 0) queued.splice(index, 1);
      send(res, 200, { receipt });
    })
    .catch(() => fail(res, 400, "instruction.invalid", { field: "body" }));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, "http://engine.internal");
  const route = req.method + " " + url.pathname;

  if (route === "GET /session") return handleSession(req, res);
  if (route === "POST /manifests") return handleManifest(req, res);
  if (route === "POST /instructions") return handleInstruction(req, res);

  const session = sessionFor(req);
  if (!session) return fail(res, 401, "session.required");

  if (route === "GET /state/participants") return send(res, 200, { participants: state.participants });
  if (route === "GET /state/journal") return send(res, 200, { journal: state.journal });
  if (route === "GET /state/batches") return send(res, 200, { batches: queued });
  if (route === "GET /state/buffer") {
    return send(res, 200, { buffer: state.buffer, rail: state.rail, window: state.window });
  }
  if (route === "GET /state/clock") return send(res, 200, { clock: clock() });
  if (route === "GET /receipts") return send(res, 200, { receipts });

  return fail(res, 404, "route.not_found");
});

server.listen(PORT, "127.0.0.1", () => {
  console.log("settlement engine listening on 127.0.0.1:" + PORT + " (value day " + state.window.valueDate + ")");
});
