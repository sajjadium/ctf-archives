# Golem Assembly (GASM) — language specification

The golem executes a GASM program against an input tape and prints a stream of
numbers. Your job, each round, is to compute that output stream exactly.

Read this spec carefully: several rules are deliberately unusual. `examples.txt`
demonstrates every one of them with a worked program and its exact output — if
your interpreter reproduces all of those, it matches the golem.

## Machine model

- **Registers:** 16 registers, `r0`..`r15`. Every register holds an **unsigned
  16-bit** value. All of them start at `0`.
- **Arithmetic width:** every value written to a register is taken **mod 65536**
  (`& 0xFFFF`). There are no negative values and nothing wider than 16 bits.
- **Input tape:** a finite list of bytes (each `0..255`), consumed left to right
  by the `in` instruction. The round's tape is given on the `INPUT` line as
  space-separated decimals (it may be empty).
- **Output:** a list of 16-bit values appended by `out`. You report it as those
  values in order, space-separated decimals, on one line. If the program emits
  nothing, the output is an empty line.

## Program text

One instruction per line. Tokens are separated by spaces. Blank lines are
ignored. Registers are written `r<N>` with `0 <= N <= 15`. Immediates are
signed decimal integers. Indentation (inside blocks) is cosmetic.

## Instructions

Let `rX` be the destination and `rY`, `rZ` sources. **All three-operand
instructions read `rY` and `rZ` first, then write `rX`.** So `add r0 r0 r0`
doubles `r0`.

| Instruction        | Effect                                                             |
|--------------------|--------------------------------------------------------------------|
| `set rX IMM`       | `rX = IMM mod 65536` (negative/large `IMM` wrap, e.g. `-1` → 65535)|
| `mov rX rY`        | `rX = rY`                                                          |
| `add rX rY rZ`     | `rX = (rY + rZ) mod 65536`                                         |
| `sub rX rY rZ`     | `rX = (rY - rZ) mod 65536`                                         |
| `mul rX rY rZ`     | `rX = (rY * rZ) mod 65536`                                         |
| `div rX rY rZ`     | if `rZ == 0` then `rX = 65535`, else `rX = rY // rZ` (unsigned)    |
| `mod rX rY rZ`     | if `rZ == 0` then `rX = rY`, else `rX = rY % rZ`                   |
| `and rX rY rZ`     | `rX = rY & rZ`                                                     |
| `or  rX rY rZ`     | `rX = rY \| rZ`                                                    |
| `xor rX rY rZ`     | `rX = rY ^ rZ`                                                     |
| `shl rX rY rZ`     | `rX = (rY << (rZ & 15)) mod 65536`  (shift count masked to 4 bits) |
| `shr rX rY rZ`     | `rX = rY >> (rZ & 15)`  (logical, shift count masked to 4 bits)    |
| `not rX rY`        | `rX = (~rY) & 0xFFFF`                                              |
| `in  rX`           | read next tape byte into `rX`; if the tape is exhausted, `rX = 65535` |
| `out rX`           | append `rX` to the output                                         |

### Structured blocks

Blocks open with `rep` / `ifz` / `ifn` and close with a matching `end`. They
nest (every program is well-formed and every `end` matches the nearest open
block). There are no jumps, so programs always terminate.

| Block           | Effect                                                              |
|-----------------|--------------------------------------------------------------------|
| `rep N` … `end` | execute the body exactly `N` times (`N` is a literal, `0..255`). `N = 0` runs the body zero times. |
| `ifz rX` … `end`| execute the body **once** iff `rX == 0`, tested at block entry      |
| `ifn rX` … `end`| execute the body **once** iff `rX != 0`, tested at block entry      |

The `ifz`/`ifn` condition is read **once**, when control reaches the block;
changing `rX` inside the body does not re-test it.

## Protocol (per round)

```
=== round k/100 ===
PROGRAM
<program lines>
.
INPUT <b0 b1 ...>          # the tape, space-separated decimals (maybe empty)
OUTPUT>                    # send your answer here: the out stream, one line
```

Send the output values space-separated on one line (empty line if none). The
server replies `OK` and advances, or `WRONG` and closes the connection. Clear
all 100 rounds to receive the flag.
