/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_maze_free: (a: number, b: number) => void;
export const maze_new: () => number;
export const maze_get_position: (a: number, b: number) => void;
export const maze_check: (a: number, b: number) => void;
export const maze_get_walls: (a: number) => number;
export const maze_move_up: (a: number) => void;
export const maze_move_down: (a: number) => void;
export const maze_move_left: (a: number) => void;
export const maze_move_right: (a: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
