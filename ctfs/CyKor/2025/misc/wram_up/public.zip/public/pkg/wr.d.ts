/* tslint:disable */
/* eslint-disable */
export class Maze {
  free(): void;
  constructor();
  get_position(): string;
  check(): string;
  get_walls(): any;
  move_up(): void;
  move_down(): void;
  move_left(): void;
  move_right(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_maze_free: (a: number, b: number) => void;
  readonly maze_new: () => number;
  readonly maze_get_position: (a: number, b: number) => void;
  readonly maze_check: (a: number, b: number) => void;
  readonly maze_get_walls: (a: number) => number;
  readonly maze_move_up: (a: number) => void;
  readonly maze_move_down: (a: number) => void;
  readonly maze_move_left: (a: number) => void;
  readonly maze_move_right: (a: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
