from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 8000
ADDRESS = "localhost"

def run(server_class=HTTPServer, handler_class=SimpleHTTPRequestHandler):
    server_address = (ADDRESS, PORT)
    httpd = server_class(server_address, handler_class)
    print(f"Serving HTTP on {ADDRESS}:{PORT}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
