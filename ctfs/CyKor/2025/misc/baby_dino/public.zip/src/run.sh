#!/usr/bin/env bash

set -euo pipefail
exec 2>/dev/null

TMPDIR="$(mktemp -d)"
CODE_FILE="${TMPDIR}/code.ts"
IFS= read -r LINE
TRUNCATED="${LINE:0:100}"
printf "%s" "$TRUNCATED" > "$CODE_FILE"

DENO_DIR=/deno-dir/ timeout -s9 3 deno run --no-config --no-remote --no-prompt "$CODE_FILE" </dev/null >/dev/null