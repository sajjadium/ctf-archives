MASK64 = (1 << 64) - 1

def rotl(x, k):
    return ((x << k) & MASK64) | (x >> (64 - k))

class SM64:
    def __init__(self, s):
        self.x = s & MASK64
    def next(self):
        z = (self.x + 0x9E3779B97F4A7C15) & MASK64
        self.x = z
        z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9 & MASK64
        z = (z ^ (z >> 27)) * 0x94D049BB133111EB & MASK64
        return z ^ (z >> 31)

class XS128:
    def __init__(self, s0, s1):
        if (s0 | s1) == 0:
            s1 = 1
        self.s0 = s0 & MASK64
        self.s1 = s1 & MASK64
    def next(self):
        s0 = self.s0
        s1 = self.s1
        r = rotl((s0 * 5) & MASK64, 7) * 9 & MASK64
        s1 ^= s0
        self.s0 = (rotl(s0, 24) ^ s1 ^ ((s1 << 16) & MASK64)) & MASK64
        self.s1 = rotl(s1, 37)
        return r

class PRNG:
    def __init__(self, seed):
        sm = SM64(seed)
        self.g0 = XS128(sm.next(), sm.next())
        self.g1 = XS128(sm.next(), sm.next())
        self.g2 = XS128(sm.next(), sm.next())

    def _w(self):
        a = self.g0.next()
        b = self.g1.next()
        c = self.g2.next()
        t = (rotl((a + b) & MASK64, 17) ^ c) & MASK64
        return a, b, c, t

    def _fb(self, a, b, c, t):
        s0 = (a ^ (a >> 19) ^ rotl(a, 33))
        s1 = (b ^ (b >> 21) ^ rotl(b, 29))
        s2 = (c ^ (c >> 23) ^ rotl(c, 27))
        s3 = (t ^ (t >> 17) ^ rotl(t, 31))

        g1 = ((s0 >> 0) & 1)  & ((s1 >> 7) & 1)  & ((s2 >> 13) & 1) & ((s3 >> 19) & 1) & \
             ((s0 >> 27) & 1) & ((s1 >> 41) & 1)
        g2 = ((s0 >> 3) & 1)  & ((s1 >> 11) & 1) & ((s2 >> 17) & 1) & ((s3 >> 23) & 1) & \
             ((s0 >> 29) & 1) & ((s2 >> 37) & 1) & ((s3 >> 43) & 1)
        g3 = ((s0 >> 5) & 1)  & ((s1 >> 9) & 1)  & ((s2 >> 15) & 1) & ((s3 >> 21) & 1) & \
             ((s0 >> 33) & 1) & ((s1 >> 39) & 1) & ((s2 >> 45) & 1) & ((s3 >> 51) & 1)
        g4 = ((s0 >> 8) & 1)  & ((s1 >> 12) & 1) & ((s2 >> 18) & 1) & ((s3 >> 24) & 1) & \
             ((s0 >> 30) & 1) & ((s1 >> 34) & 1) & ((s2 >> 40) & 1) & ((s3 >> 46) & 1) & \
             ((s0 >> 52) & 1)
        g5 = ((s0 >> 10) & 1) & ((s1 >> 14) & 1) & ((s2 >> 20) & 1) & ((s3 >> 26) & 1) & \
             ((s0 >> 32) & 1) & ((s1 >> 36) & 1) & ((s2 >> 42) & 1) & ((s3 >> 48) & 1) & \
             ((s0 >> 54) & 1) & ((s1 >> 58) & 1)

        return 1 if (g1 | g2 | g3 | g4 | g5) else 0


    def next64(self):
        a, b, c, t = self._w()
        x = (rotl(a, 7) + rotl(b, 13) + rotl(c, 37)) & MASK64
        x ^= (t ^ ((a * 0x9E3779B97F4A7C15) & MASK64) ^ rotl((b * 0xA0761D6478BD642F) & MASK64, 17))
        x &= MASK64
        l = self._fb(a, b, c, t)
        return (x & ~1) | l

    def randint(self):
        return self.next64()
