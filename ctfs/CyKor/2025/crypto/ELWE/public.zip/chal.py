import os
from rand import PRNG
from sage.all import *
from Crypto.Util.number import *


class ElGamal:
    def __init__(self):
        self.p = 0xD4BCD52406F69B35994B88DE5DB89682C8157F62D8F33633EE5772F11F05AB22D6B5145B9F241E5ACC31FF090A4BC71148976F76795094E71E7903529F5A824B
        self.g = 0x2
        self.x = randrange(2, self.p-1) # private key
        self.h = pow(self.g, self.x, self.p)
    
    def encrypt(self, m):
        k = randrange(2, self.p-1)
        c1 = pow(self.g, k, self.p)
        c2 = (m * pow(self.h, k, self.p)) % self.p
        return (c1, c2)

    def decrypt(self, c1, c2):
        m = (c2 * pow(pow(c1, self.x, self.p), -1, self.p)) % self.p
        return m


class LWE:
    def __init__(self):
        self.n = 64
        self.p = 257
        self.q = 65542
        self.delta = self.q // self.p   # 255
        self.S = self.random_vector()
        self.prng = PRNG(bytes_to_long(os.urandom(8)))

    def random_vector(self):
        return vector(Zmod(self.q), [randrange(self.q) for _ in range(self.n)])
    
    def random_error(self):
        e = (self.prng.randint() & 0xFF) - 128
        return e

    def encrypt(self, m):
        A = self.random_vector()
        e = self.random_error()
        b = A * self.S + m * self.delta + e
        return A, b


def menu():
    print()
    print("1. ElGamal encryption (FLAG)")
    print("2. ElGamal decryption / LWE encryption")
    print("3. Exit")
    return int(input('> '))


if __name__ == '__main__':
    elgamal = ElGamal()
    lwe = LWE()

    with open('flag.txt', 'rb') as f:
        FLAG = f.read().strip()

    cnt = 0
    while cnt < 500:
        choice = menu()
        if choice == 1:
            ct = elgamal.encrypt(bytes_to_long(FLAG))
            print(f"{ct = }")

        elif choice == 2:
            c1 = int(input("Enter c1: "))
            c2 = int(input("Enter c2: "))
            m = elgamal.decrypt(c1, c2)
            ct = lwe.encrypt(m)
            print(f"{ct = }")

        elif choice == 3:
            break
        
        cnt += 1
