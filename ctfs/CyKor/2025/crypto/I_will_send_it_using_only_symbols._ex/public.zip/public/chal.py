from hawk_py.keygen import hawkkeygen_unpacked
from hawk_py.sign import hawksign
from hashlib import sha256
from lyrics import lines
import random
import time


logn = 8
n = 1 << logn


f, g, F, G, _, _, _, priv, pub = hawkkeygen_unpacked(logn)
print("pub:", pub.tobytes().hex())


for line in lines:
    sig, leak = hawksign(logn, priv, line)
    for j in range(2 * n):
        leak ^= int(0.39 < random.random() - 0.39) << j
    print(sig.tobytes().hex(), leak.to_bytes(n // 4, 'little').hex())


st = time.time()
LIMIT = 100
for i in range(2):
    h = input("sha256(f + g + F + G)? ")
    if time.time() - st > LIMIT:
        print(f"TIME EXCEEDED")
    elif h != sha256(str(f + g + F + G).encode()).hexdigest():
        print("WRONG!")
    else:
        print(f"CyKor{{[REDACTED]}}")
