import random
import numpy as np

random.seed('音声だけでお送りします / いよわ')
lines = [np.frombuffer(random.randbytes(32), dtype=np.uint8) for _ in range(11)]
