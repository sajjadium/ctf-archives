import os
from flask import Flask, send_from_directory, abort, jsonify

app = Flask(__name__)

TEMPLATES_DIR = os.path.join(os.path.dirname(__file__), "templates")
os.makedirs(TEMPLATES_DIR, exist_ok=True)

@app.route("/list")
def list_templates():
    try:
        files = sorted(f for f in os.listdir(TEMPLATES_DIR) if os.path.isfile(os.path.join(TEMPLATES_DIR, f)))
        return jsonify({"templates": files})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/template/<path:filename>")
def template_download(filename):
    safe_name = os.path.basename(filename)
    full_path = os.path.join(TEMPLATES_DIR, safe_name)
    if not os.path.isfile(full_path):
        abort(404)
    return send_from_directory(TEMPLATES_DIR, safe_name, as_attachment=True,download_name=safe_name)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000)
