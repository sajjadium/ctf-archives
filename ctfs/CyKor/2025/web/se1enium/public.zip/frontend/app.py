import os
import base64
import subprocess
import requests
import shutil
import threading
from flask import (
    Flask,
    request,
    abort,
    render_template,
    redirect  
)

app = Flask(__name__, template_folder="templates")


BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DOWNLOAD_DIR = os.path.join(BASE_DIR, "templates/downloaded_templates")   
TEMPLATE_LIST_API = "http://server/api/list" 

os.makedirs(DOWNLOAD_DIR, exist_ok=True)
_fetch_slots = threading.Semaphore(2)


def _fetch_with_node(url: str):
    if not _fetch_slots.acquire(blocking=False): #Selenium’s ‘only’ drawback: eats way too much RAM T_T
        raise RuntimeError("Too many fetch jobs running; try again in a moment.")

    encoded_url = base64.b64encode(url.encode('utf-8')).decode('utf-8')
    script_path = os.path.join(BASE_DIR, "fetch.js")

    try:
        proc = subprocess.Popen(
            ["node", script_path, encoded_url],
            cwd=BASE_DIR
        )
    except Exception:
        _fetch_slots.release()
        raise

    threading.Thread(
        target=_release_slot_when_done,
        args=(proc,),
        daemon=True,
    ).start()


def _release_slot_when_done(proc: subprocess.Popen):
    try:
        proc.wait()
    finally:
        _fetch_slots.release()


def _get_template_list():
    try:
        response = requests.get(TEMPLATE_LIST_API, timeout=3)
        response.raise_for_status()
        data = response.json()
        return data["templates"], None
    except Exception as e:
        return [], str(e)


@app.route("/")
def index():
    files = os.listdir(DOWNLOAD_DIR)
    return render_template("index.html", files=files)

@app.route("/fetch", methods=["GET", "POST"])
def fetch():
    if request.method == "GET":
        template_list, err = _get_template_list()
        if err:
            return render_template("fetch.html", error=err), 500

        return render_template("fetch.html", templates=template_list)

    elif request.method == "POST":
        path = request.form.get("url", "")
        if not path:
            return redirect("/fetch")

        if not path.startswith("/"):
            path = "/" + path
            
        url = f"http://server{path}"

        template_list, err = _get_template_list()
        if err:
            return render_template("fetch.html", error=err), 500

        try:
            _fetch_with_node(url)
        except RuntimeError as e:
            return render_template("fetch.html", templates=template_list, error=str(e)), 429

        return render_template("fetch.html", templates=template_list, message="Fetch scheduled.")

@app.route("/render")
def render():
    name = request.args.get("name", "Anonymous")
    template = request.args.get("template", "")
    subdir = "downloaded_templates"

    downloaded_path = os.path.join(app.template_folder, subdir)

    try:
        os.listdir(downloaded_path)
    except FileNotFoundError:
        abort(500, description="Template directory not found")

    normalized = os.path.normpath(template)
    if not template or os.path.isabs(template) or normalized.startswith(".."):
        abort(400, description="Invalid template path")

    target_path = os.path.join(downloaded_path, normalized)
    if not os.path.isfile(target_path):
        abort(404, description="Requested template was not found")

    return render_template(f"{subdir}/{normalized}", name=name)

@app.route("/clear", methods=["POST"])
def clear_downloads():
    try:
        if os.path.exists(DOWNLOAD_DIR):
            shutil.rmtree(DOWNLOAD_DIR)
            os.makedirs(DOWNLOAD_DIR, exist_ok=True)
        return redirect("/")
    except Exception as e:
        abort(500, description=f"Failed to delete templates: {str(e)}")


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)
