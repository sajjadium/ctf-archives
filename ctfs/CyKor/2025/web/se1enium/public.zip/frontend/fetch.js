const { Builder, By } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const path = require('path');
const fs = require('fs');

async function fetchUrl(encodedUrl) {
    const url = Buffer.from(encodedUrl, 'base64').toString('utf-8');
    const downloadPath = path.join(__dirname, 'templates', 'downloaded_templates');
    
    if (!fs.existsSync(downloadPath)) {
        fs.mkdirSync(downloadPath, { recursive: true });
    }

    const options = new chrome.Options();
    options.addArguments('--headless');
    options.addArguments('--no-sandbox');
    options.addArguments('--disable-dev-shm-usage');
    options.addArguments('--disable-gpu');
    options.addArguments('--allow-running-insecure-content');
    
    const prefs = {
        'download.default_directory': downloadPath,
        'download.prompt_for_download': false,
        'download.directory_upgrade': true,
        'safebrowsing.enabled': false
    };
    options.setUserPreferences(prefs);

    const driver = await new Builder()
        .forBrowser('chrome')
        .setChromeOptions(options)
        .build();

    try {
        console.log(`Fetching: ${url}`);
        await driver.get(url);
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
    } catch (error) {
        console.error('Error fetching URL:', error);
    } finally {
        await driver.quit();
    }
}

const encodedUrl = process.argv[2];
if (!encodedUrl) {
    process.exit(1);
}

fetchUrl(encodedUrl).catch(console.error);