const express = require("express");
const path = require("path");
const session = require("express-session");
const createDOMPurify = require("dompurify");
const { JSDOM } = require("jsdom");
const puppeteer = require("puppeteer");

const app = express();
const PORT = process.env.PORT || 3000;
const FLAG = process.env.FLAG || "CyKor{fake_flag}";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
const SESSION_SECRET = process.env.SESSION_SECRET || "secret";

const VIEWS_DIR = path.join(__dirname, "../views");

const dompurifyWindow = new JSDOM("").window;
const DOMPurify = createDOMPurify(dompurifyWindow);

const savedHtmlStore = new Map();

const users = new Map();

users.set("admin", { password: ADMIN_PASSWORD });

let store_idx = 1;

const ensureUserStore = (user) => {
  if (!savedHtmlStore.has(user)) {
    savedHtmlStore.set(user, new Map());
  }
  return savedHtmlStore.get(user);
};

app.set("views", VIEWS_DIR);
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: false }));
app.use(
  session({
    name: "sid",
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: "auto",
      maxAge: 1000 * 60 * 60
    }
  })
);
app.use((req, res, next) => {
  res.set("Content-Security-Policy", "default-src 'none'; img-src *");
  next();
});

const requireAuth = (req, res, next) => {
  if (!req.session.user) {
    const error = "Authentication required. Login first.";
    return res.status(401).render("login", { result: { error } });
  }

  req.user = req.session.user;
  return next();
};

app.get("/", (req, res) => {
  res.render("index", { user: req.session.user || null });
});

app.get("/register", (req, res) => {
  res.render("register", { result: null });
});

app.post("/register", (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password || typeof username !== "string" || typeof password !== "string") {
    const error = "Body must include string fields 'username' and 'password'.";
    return res.status(400).render("register", { result: { error } });
  }

  if (users.has(username)) {
    const error = "Username already exists.";
    return res.status(409).render("register", { result: { error } });
  }

  users.set(username, { password });

  const payload = { message: "User registered." };
  return res.render("register", { result: payload });
});

app.get("/login", (req, res) => {
  res.render("login", { result: null });
});

app.post("/login", (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password || typeof username !== "string" || typeof password !== "string") {
    const error = "Body must include string fields 'username' and 'password'.";
    return res.status(400).render("login", { result: { error } });
  }

  const user = users.get(username);
  if (!user || user.password !== password) {
    return res.status(401).send("Invalid credentials.");
  }

  req.session.user = username;
  return res.status(200).send("Login successful.");
});

app.get("/save", requireAuth, (req, res) => {
  res.render("save", { result: null, user: req.user });
});

app.post("/save", requireAuth, async (req, res) => {
  const { html } = req.body || {};

  if (!html || typeof html !== "string") {
    const error = "Body must include a string field 'html'.";
    return res.status(400).render("save", { result: { error }, user: req.user });
  }

  const id = store_idx++;
  const store = ensureUserStore(req.user);
  store.set(id, {
    html,
    savedAt: new Date().toISOString()
  });

  return res.render("save", {
    result: {
      message: "HTML saved.",
      id
    },
    user: req.user
  });
});

app.get("/test", requireAuth, (req, res) => {
  const { html } = req.query || {};

  if (!html) {
    return res.render("test", { result: null, user: req.user });
  }

  if (typeof html !== "string") {
    const error = "Query must include a string field 'html'.";
    return res.status(400).render("test", { result: { error }, user: req.user });
  }

  const dom = new JSDOM(html);
  const { document } = dom.window;
  const placeholderEmbeds = Array.from(document.querySelectorAll("embed[id]"));
  const missingIds = [];
  const store = ensureUserStore(req.user);
  placeholderEmbeds.forEach((embedEl) => {
    const id = embedEl.getAttribute("id");
    const saved = store.get(Number(id));

    if (!saved) {
      missingIds.push(id);
      return;
    }

    const frag = document.createRange().createContextualFragment(saved.html);
    embedEl.replaceWith(frag);
  });

  if (missingIds.length > 0) {
    const error = `Missing saved HTML for embed ids. Call /save first. Missing: ${missingIds.join(", ")}`;
    return res.status(409).render("test", { result: { error }, user: req.user });
  }

  const sanitized = DOMPurify.sanitize(dom.serialize());
  res.set("Content-Type", "text/html; charset=utf-8").send(sanitized);
});

app.post("/bot", requireAuth, async (req, res) => {
  const { url } = req.body || {};
  if (!url || typeof url !== "string") {
    return res.status(400).send("Body must include a string field 'url'.");
  }

  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    return res.status(400).send("URL must start with http:// or https://");
  }

  let browser;
  try {
    browser = await puppeteer.launch({ headless: true, args: ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"] });
    const page = await browser.newPage();
    await page.goto(`http://localhost:${PORT}/login`, { waitUntil: "networkidle2", timeout: 3000 });
    await page.type("input[name='username']", "admin");
    await page.type("input[name='password']", ADMIN_PASSWORD);
    await page.click("button[type='submit']");
    await page.waitForNavigation({ waitUntil: "networkidle2", timeout: 3000 });
    await page.goto(url, { waitUntil: "networkidle2", timeout: 3000 });
    await new Promise(resolve => setTimeout(resolve, 1000));

    res.status(200).send("Bot visited the page.");
  } catch (err) {
    console.error("Bot error:", err);
    res.status(500).send("Bot failed to visit the page.");
  } finally {
    if (browser) {
      await browser.close();
    }
  }
});

app.post("/search", requireAuth, (req, res) => {
  if (req.user !== "admin") {
    return res.status(403).render("save", { result: { error: "Permission denied." }, user: req.user });
  }

  if (!req.body.guess) {
    return res.status(400).render("save", { result: { error: "Query must include a string field 'guess'." }, user: req.user });
  }

  const guess = req.body.guess;
  if (typeof guess !== "string") {
    return res.status(400).render("save", { result: { error: "Query must include a string field 'guess'." }, user: req.user });
  }

  const id = store_idx++;
  const store = ensureUserStore(req.user);

  if (FLAG && FLAG.includes(guess)) {
    store.set(id, {
      html: `You found the flag!`,
      savedAt: new Date().toISOString()
    });
  } else {
    store.set(id, {
      html: `You <del>found</del> the flag!`,
      savedAt: new Date().toISOString()
    });
  }

  return res.status(200).render("save", { result: { message: `HTML saved.`, id }, user: req.user });
});

app.use((req, res) => {
  res.status(404).render("error", { status: 404, message: "Not found" });
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
