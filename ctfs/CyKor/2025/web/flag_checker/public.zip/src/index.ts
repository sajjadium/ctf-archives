import express, { Request, Response } from "express";
import session from "express-session";
import bcrypt from "bcrypt";
import crypto from "crypto";
import path from "path";
import dotenv from "dotenv";
import prisma from "./db";

dotenv.config();

const app = express();
const PORT = 3000;

const LAST_STAGE = 9;
const FLAG = process.env.FLAG || "CyKor{test}";

app.use(express.json());
app.use(
  session({
    secret: crypto.randomBytes(32).toString("hex"),
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      secure: false,
      sameSite: "lax",
      maxAge: 1000 * 60 * 60 * 24 * 30,
    },
  }),
);

const generateAnswer = () => {
  return "KyCor{" + crypto.randomBytes(8).toString("hex") + "}";
};

app.get("/", (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, "..", "views", "index.html"));
});

app.post("/register", async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    if (
      !username ||
      !password ||
      typeof username !== "string" ||
      typeof password !== "string"
    ) {
      return res.status(200).json({ error: "Signup failed." });
    }

    const isUserExist = await prisma.user.findUnique({ where: { username } });

    if (isUserExist) {
      return res.status(200).json({ error: "Signup failed." });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);

    await prisma.user.create({
      data: {
        username,
        password: hashedPassword,
        answer: generateAnswer(),
      },
    });

    res.status(200).json({ message: "Signup successful" });
  } catch (error) {
    res.status(200).json({ error: "Signup failed." });
  }
});

app.post("/login", async (req: Request, res: Response) => {
  try {
    const { username, password } = req.body;
    if (
      !username ||
      !password ||
      typeof username !== "string" ||
      typeof password !== "string"
    ) {
      return res.status(200).json({ error: "Login failed." });
    }

    const user = await prisma.user.findUnique({
      where: { username },
    });

    if (!user) {
      return res.status(200).json({ error: "Login failed." });
    }

    const isPasswordValid = bcrypt.compareSync(password, user.password);

    if (!isPasswordValid) {
      return res.status(200).json({ error: "Login failed." });
    }

    req.session.user = user.id;

    res.status(200).json({ message: "Login successful" });
  } catch (error) {
    res.status(200).json({ error: "Login failed." });
  }
});

app.post("/update", async (req: Request, res: Response) => {
  try {
    if (!req.session.user) {
      return res.status(200).json({ error: "Update failed." });
    }

    const { username, password, oldPassword } = req.body;
    if (
      !username ||
      !password ||
      !oldPassword ||
      typeof username !== "string" ||
      typeof password !== "string" ||
      typeof oldPassword !== "string"
    ) {
      return res.status(200).json({ error: "Update failed." });
    }

    const currentUser = await prisma.user.findUnique({
      where: { id: req.session.user },
    });
    if (!currentUser) {
      return res.status(200).json({ error: "Update failed." });
    }

    const isPasswordValid = bcrypt.compareSync(
      oldPassword,
      currentUser.password,
    );
    if (!isPasswordValid) {
      return res.status(200).json({ error: "Update failed." });
    }

    const isUsernameExist = await prisma.user.findFirst({
      where: { username, NOT: { id: req.session.user } },
    });
    if (isUsernameExist) {
      return res.status(200).json({ error: "Update failed." });
    }

    await prisma.user.update({
      where: { id: req.session.user },
      data: { username, password: bcrypt.hashSync(password, 10) },
    });
    res.status(200).json({ message: "Update successful" });
  } catch (error) {
    res.status(200).json({ error: "Update failed." });
  }
});

app.post("/answer", async (req: Request, res: Response) => {
  try {
    if (!req.session.user) {
      return res.status(200).json({ error: "Answer failed." });
    }

    const { answer } = req.body;
    if (!answer || typeof answer !== "string") {
      return res.status(200).json({ error: "Answer failed." });
    }

    const user = await prisma.user.findUnique({
      where: { id: req.session.user },
    });
    if (!user) {
      return res.status(200).json({ error: "Answer failed." });
    }

    if (user.token <= 0) {
      return res.status(200).json({ error: "You have no token." });
    }

    if (user.answer === answer) {
      if (user.stage === LAST_STAGE) {
        return res.status(200).json({ message: FLAG });
      }

      user.stage = user.stage + 1;
      await prisma.user.update({
        where: { id: user.id },
        data: { stage: user.stage, answer: generateAnswer() },
      });
      return res.status(200).json({ message: "Answer correct" });
    } else {
      await prisma.user.update({
        where: { id: user.id },
        data: { token: user.token - 1 },
      });
      return res.status(200).json({ error: "Answer incorrect" });
    }
  } catch (error) {
    res.status(200).json({ error: "Answer failed." });
  }
});

app.post("/leaderboard", async (req: Request, res: Response) => {
  try {
    const { usernames, stage } = req.body;
    if (usernames && !Array.isArray(usernames)) {
      return res.status(200).json({ error: "Leaderboard failed." });
    }

    const whereStage = stage ? stage : LAST_STAGE;
    const where =
      !usernames || usernames.length === 0
        ? { stage: whereStage }
        : {
            AND: [
              {
                OR: usernames.map((username: string) => ({ username })),
              },
              { stage: whereStage },
            ],
          };

    const result = await prisma.user.findMany({
      where,
      select: {
        id: true,
      },
      orderBy: {
        stage: "desc",
      },
    });

    return res
      .status(200)
      .json({
        ids: result.map((user: { id: number }) => user.id),
      });
  } catch (error) {
    res.status(200).json({ error: "Leaderboard failed." });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
