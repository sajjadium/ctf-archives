#include <stdio.h>

int main(void){
    printf("CyKor{dummy_flag_for_test}");
    return 0;
}