#!/bin/bash

exec timeout 120 /home/prob/prob 2>&1