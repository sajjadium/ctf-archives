# Gram Contract Language

## Comments

```
// Single line comment

/* Multi-line
   comment */
```

## Types

```
u64       // Unsigned 64-bit integer
bool      // Boolean (true, false)
address   // 20-byte address
bytes     // Byte array
```

## Literals

```
123                                               // Integer
true, false                                       // Boolean
0x1234567890abcdef1234567890abcdef12345678        // Address (40 hex chars)
"hello"                                           // String
```

## Contract Structure

```
contract Name {
    storage {
        field1: u64,
        field2: bool,
        field3: address,
        mapping: map<address, u64>
    }
    
    pub fn init() {
        // Constructor, called on deploy
    }
    
    pub fn public_function(arg1: u64, arg2: address) -> u64 {
        // Callable externally
        return arg1;
    }
    
    fn private_function() {
        // Internal only
    }
}
```

## Variables

```
let x: u64 = 100;
let flag: bool = true;
let addr: address = msg.sender;
```

## Assignment Operators

```
x = 10;
x += 5;
x -= 3;
```

## Arithmetic Operators

```
+    // Addition
-    // Subtraction
*    // Multiplication
/    // Division
%    // Modulo
```

## Comparison Operators

```
==   // Equal
!=   // Not equal
<    // Less than
>    // Greater than
<=   // Less than or equal
>=   // Greater than or equal
```

## Logical Operators

```
&&   // Logical AND
||   // Logical OR
!    // Logical NOT
```

## Bitwise Operators

```
&    // Bitwise AND
|    // Bitwise OR
^    // Bitwise XOR
<<   // Left shift
>>   // Right shift
```

## Control Flow

```
// If-else
if condition {
    // ...
} else if other_condition {
    // ...
} else {
    // ...
}

// While loop
while condition {
    // ...
}

// For loop (range)
for i in 0..10 {
    // i goes from 0 to 9
}
```

## Context Variables

```
msg.sender      // Address of caller
msg.value       // Tokens sent with call
self.address    // This contract's address
self.balance    // This contract's token balance
block.number    // Current block number
```

## Storage Access

```
// Simple fields
storage.field = 100;
let x: u64 = storage.field;

// Maps
storage.balances[addr] = 50;
let b: u64 = storage.balances[addr];
```

## Built-in Functions

```
// Transfer tokens from this contract
transfer(to: address, amount: u64)

// Get token balance of address
balance_of(addr: address) -> u64

// Assertions
require(condition: bool, message: string)
assert(condition: bool)

// Events
emit EventName(arg1, arg2, ...)
```

## Contract Calls

```
// Asynchronous call (non-blocking)
call(target: address, func: string, args...)

// Asynchronous call with token transfer
call_with_value(target: address, func: string, value: u64, args...)

// Synchronous call (blocking)
sync_call(target: address, func: string, args...)

// Synchronous call with token transfer
sync_call_with_value(target: address, func: string, value: u64, args...)
```

## Example

```
contract Token {
    storage {
        balances: map<address, u64>,
        total: u64
    }
    
    pub fn init() {
        storage.total = 1000000;
        storage.balances[msg.sender] = 1000000;
    }
    
    pub fn transfer(to: address, amount: u64) {
        let from_bal: u64 = storage.balances[msg.sender];
        require(from_bal >= amount, "insufficient");
        storage.balances[msg.sender] = from_bal - amount;
        let to_bal: u64 = storage.balances[to];
        storage.balances[to] = to_bal + amount;
    }
    
    pub fn balance_of(addr: address) -> u64 {
        return storage.balances[addr];
    }
}
```