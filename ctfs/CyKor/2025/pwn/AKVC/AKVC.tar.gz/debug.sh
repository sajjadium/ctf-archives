#!/bin/bash

print_usage() 
{
    echo "Usage: $0 <Path to Exploit File>"
    echo "       $0 /dev/null"
}

run_vm()
{
    RAM="128M"
    CPU_CORES="2"

    args=(
        -m "$RAM"
        -smp "$CPU_CORES"
        -cpu kvm64,+smep,+smap
        -kernel $(dirname "$0")/bzImage
        -initrd $(dirname "$0")/rootfs.cpio
        -append "root=/dev/vda1 console=ttyS0 quiet loglevel=3 nokaslr panic_on_warn=1"
        -monitor /dev/null
        -nographic
        -hda $1 # host: /path/to/exploit/file, guest: /dev/sda
        -hdb $(dirname "$0")/flag
        -s
    )

    qemu-system-x86_64 "${args[@]}" 2>&1
}

# Sanity check
if [ -z "$1" ]; then
    print_usage
    exit 1
fi

run_vm $1
