#!/bin/bash

SCRIPT_DIR="$(dirname "$0")"
POW_DIFFICULTY=100000 # 38.12s user 0.00s system 96% cpu 39.415 total

run_vm()
{
    local exploit_path="$1"
    local flag_path="$2"

    RAM="128M"
    CPU_CORES="2"

    args=(
        -m "$RAM"
        -smp "$CPU_CORES"
        -cpu kvm64,+smep,+smap
        -kernel "$SCRIPT_DIR/bzImage"
        -initrd "$SCRIPT_DIR/rootfs.cpio"
        -append "root=/dev/vda1 console=ttyS0 quiet loglevel=3 panic_on_warn=1"
        -monitor /dev/null
        -nographic
        -hda "$exploit_path"  # host: /path/to/exploit/file, guest: /dev/sda
        -hdb "$flag_path"
    )

    qemu-system-x86_64 "${args[@]}" 2>&1
}

cleanup() 
{
    [ -n "$TMP_EXPLOIT" ] && rm -f "$TMP_EXPLOIT"
    [ -n "$TMP_FLAG" ] && rm -f "$TMP_FLAG"
}

# if ! /app/pow.py ask $POW_DIFFICULTY; then
#     echo "Error: Proof-of-Work failed"
#     exit 1
# fi

# Read base64 encoded exploit from stdin
echo -n "Exploit file (base64): "
read -r base64_exploit

if [ -z "$base64_exploit" ]; then
    echo "Error: No input provided"
    exit 1
fi

# Create temporary files
TMP_EXPLOIT=$(mktemp)
TMP_FLAG=$(mktemp)

# Decode base64 exploit
if ! echo "$base64_exploit" | base64 -d > "$TMP_EXPLOIT" 2>/dev/null; then
    echo "Error: Failed to decode base64 input"
    exit 1
fi

# Copy flag to temporary file
FLAG_PATH="$SCRIPT_DIR/flag"
if [ ! -f "$FLAG_PATH" ]; then
    echo "Error: Flag file not found: $FLAG_PATH"
    exit 1
fi
cp "$FLAG_PATH" "$TMP_FLAG"

# Run VM
run_vm "$TMP_EXPLOIT" "$TMP_FLAG"

cleanup