#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>

#include "akvc_vm.h"
#include "akvc_ioctl.h"

static int akvc_open(struct inode *inodep, struct file *filep)
{
    struct akvc_vm *vm;

    vm = akvc_vm_init();
    if (IS_ERR(vm))
        return PTR_ERR(vm);

    filep->private_data = vm;

    return 0;
}

static int akvc_release(struct inode *inodep, struct file *filep)
{
    struct akvc_vm *vm = filep->private_data;
    
    filep->private_data = NULL;

    akvc_vm_destroy(vm);

    return 0;
}

static const struct file_operations akvc_fops = {
    .owner = THIS_MODULE,
    .open = akvc_open,
    .release = akvc_release,
    .unlocked_ioctl = akvc_ioctl,
};

static struct miscdevice akvc_device = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = "akvc",
    .fops = &akvc_fops,
    .mode = 0666
};

static int __init akvc_init(void)
{
    int ret;
    
    ret = misc_register(&akvc_device);
    if (ret < 0)
        pr_err("misc_register: %d", ret);

    return ret;
}

static void __exit akvc_exit(void)
{
    misc_deregister(&akvc_device);
}

module_init(akvc_init);
module_exit(akvc_exit);

MODULE_AUTHOR("wlswotmd");
MODULE_DESCRIPTION("Average Kernel VM Challenge");
MODULE_LICENSE("GPL");