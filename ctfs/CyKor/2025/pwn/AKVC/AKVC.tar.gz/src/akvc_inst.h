#ifndef _AKVC_INST_H
#define _AKVC_INST_H

#include <linux/types.h>

#define AKVC_INST_NOP 0
struct akvc_inst_nop {
    // No operation instruction
} __packed;

#define AKVC_INST_MOV 1
struct akvc_inst_mov {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_MOV_IMM 2
struct akvc_inst_mov_imm {
    u8 dst;
    u64 imm;
} __packed;

#define AKVC_INST_ADD 3
struct akvc_inst_add {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_SUB 4
struct akvc_inst_sub {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_MUL 5
struct akvc_inst_mul {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_DIV 6
struct akvc_inst_div {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_MOD 7
struct akvc_inst_mod {
    u8 src;
    u8 dst;
} __packed;

#define AKVC_INST_LOAD 8
struct akvc_inst_load {
    u8 reg;
    u64 addr;
} __packed;

#define AKVC_INST_STORE 9
struct akvc_inst_store {
    u8 reg;
    u64 addr;
} __packed;

#define AKVC_INST_JUMP 10
# define AKVC_COND_JMP 0
# define AKVC_COND_JEQ 1
# define AKVC_COND_JNE 2
# define AKVC_COND_JA  3
# define AKVC_COND_JAE 4
# define AKVC_COND_JB  5
# define AKVC_COND_JBE 6
struct akvc_inst_jump {
    u8 cond;
    u64 target;
} __packed;

#define AKVC_INST_CMP 11
struct akvc_inst_cmp {
    u8 left;
    u8 right;
} __packed;

struct akvc_inst {
    u8 op;
    union {
        struct akvc_inst_nop nop;
        struct akvc_inst_mov mov;
        struct akvc_inst_mov_imm mov_imm;
        struct akvc_inst_add add;
        struct akvc_inst_sub sub;
        struct akvc_inst_mul mul;
        struct akvc_inst_div div;
        struct akvc_inst_mod mod;
        struct akvc_inst_load load;
        struct akvc_inst_store store;
        struct akvc_inst_jump jump;
        struct akvc_inst_cmp cmp;
    };
} __packed;

#endif /* _AKVC_INST_H */