#ifndef _AKVC_API_H
#define _AKVC_API_H

#include <linux/ioctl.h>
#include <linux/types.h>
#include <linux/build_bug.h>

#define AKVC_IOC_TYPE 'A'

#define AKVC_IOCTL_PARAM_MAX_SIZE 128


struct akvc_vm_mmap {
    u64 host_addr;
    u64 vm_addr;
    size_t len;
    unsigned int prot;
};

struct akvc_vm_munmap {
    u64 vm_addr;
    size_t len;
};

struct akvc_vm_mprotect {
    u64 vm_addr;
    size_t len;
    unsigned int prot;
};

struct akvc_vm_run {
    u64 entry_pc;
    u32 max_steps;
};

#define AKVC_IOCTL_VM_MMAP \
    _IOWR(AKVC_IOC_TYPE, 0, struct akvc_vm_mmap)

#define AKVC_IOCTL_VM_MUNMAP \
    _IOWR(AKVC_IOC_TYPE, 1, struct akvc_vm_munmap)

#define AKVC_IOCTL_VM_MPROTECT \
    _IOWR(AKVC_IOC_TYPE, 2, struct akvc_vm_mprotect)

#define AKVC_IOCTL_VM_RUN \
    _IOWR(AKVC_IOC_TYPE, 3, struct akvc_vm_run)

#endif /* _AKVC_API_H */
