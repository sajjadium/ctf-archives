#ifndef _AKVC_VM_H
#define _AKVC_VM_H

#include <linux/list.h>
#include <linux/kref.h>

struct akvc_mm;

enum akvc_register {
    R0 = 0,
    R1 = 1,
    R2 = 2,
    R3 = 3,
    GENERAL_REGISTER_MAX = R3,
    PC = 4,
#define AKVC_FLAGS_ZF (1 << 0)
#define AKVC_FLAGS_CF (1 << 1)
    FLAGS = 5,
    REGISTER_MAX = FLAGS,
};

struct akvc_vm {
    struct akvc_mm *mm;

    u64 registers[REGISTER_MAX + 1];

    /* TODO: handle multiple processes */
    // struct akvc_process *current_process;
    // struct list_head process_list;
};

struct akvc_vm *akvc_vm_init(void);
void akvc_vm_destroy(struct akvc_vm *vm);
int akvc_vm_run(struct akvc_vm *vm, u32 max_steps, u64 entry_pc);

#endif /* _AKVC_VM_H */