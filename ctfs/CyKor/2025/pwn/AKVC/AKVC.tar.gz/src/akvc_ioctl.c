#include <linux/fs.h>
#include <linux/ioctl.h>

#include "akvc_ioctl.h"
#include "akvc_api.h"
#include "akvc_vm.h"
#include "akvc_mm.h"

static long akvc_ioctl_vm_mmap(struct akvc_vm *vm, unsigned int cmd, void *kdata)
{
    struct akvc_vm_mmap *param = kdata;

    return akvc_mm_mmap(vm->mm, param->host_addr, param->vm_addr, param->len, param->prot);
}

static long akvc_ioctl_vm_mprotect(struct akvc_vm *vm, unsigned int cmd, void *kdata)
{
    struct akvc_vm_mprotect *param = kdata;

    return akvc_mm_mprotect(vm->mm, param->vm_addr, param->len, param->prot);
}

static long akvc_ioctl_vm_munmap(struct akvc_vm *vm, unsigned int cmd, void *kdata)
{
    struct akvc_vm_munmap *param = kdata;

    return akvc_mm_munmap(vm->mm, param->vm_addr, param->len);
}

static long akvc_ioctl_vm_run(struct akvc_vm *vm, unsigned int cmd, void *kdata)
{
    struct akvc_vm_run *param = kdata;

    return akvc_vm_run(vm, param->max_steps, param->entry_pc);
}

struct akvc_ioctl_command {
    unsigned int cmd;
    long (*handler)(struct akvc_vm *vm, unsigned int cmd, void *kdata);
};

#define AKVC_IOCTL_COMMAND(_cmd, _handler) \
	[_IOC_NR((_cmd))] = \
		{ .cmd = (_cmd), .handler = (_handler) }


static const struct akvc_ioctl_command akvc_ioctl_commands[] = {
    AKVC_IOCTL_COMMAND(AKVC_IOCTL_VM_MMAP, akvc_ioctl_vm_mmap),
    AKVC_IOCTL_COMMAND(AKVC_IOCTL_VM_MPROTECT, akvc_ioctl_vm_mprotect),
    AKVC_IOCTL_COMMAND(AKVC_IOCTL_VM_MUNMAP, akvc_ioctl_vm_munmap),
    AKVC_IOCTL_COMMAND(AKVC_IOCTL_VM_RUN, akvc_ioctl_vm_run),
};

static long akvc_ioctl_copy_in(unsigned int kernel_cmd, unsigned int user_cmd,
		unsigned long arg, unsigned char *ptr)
{
	unsigned int usize = _IOC_SIZE(user_cmd);
	unsigned int ksize = _IOC_SIZE(kernel_cmd);
	unsigned int copy = ksize < usize ? ksize : usize;

	if ((kernel_cmd & IOC_IN) && (user_cmd & IOC_IN)) {
		if (copy > 0 && copy_from_user(ptr, (void __user *)arg, copy))
			return -EFAULT;
	}

	return 0;
}

static long akvc_ioctl_copy_out(unsigned int kernel_cmd, unsigned int user_cmd,
		unsigned long arg, unsigned char *ptr)
{
	unsigned int usize = _IOC_SIZE(user_cmd);
	unsigned int ksize = _IOC_SIZE(kernel_cmd);
	unsigned int copy = ksize < usize ? ksize : usize;

	if ((kernel_cmd & IOC_OUT) && (user_cmd & IOC_OUT)) {
		if (copy > 0 && copy_to_user((void __user *)arg, ptr, copy))
			return -EFAULT;
	}

	return 0;
}

long akvc_ioctl(struct file *filep, unsigned int cmd, unsigned long arg)
{
    struct akvc_vm *vm = filep->private_data;
    unsigned int cmd_nr = _IOC_NR(cmd);
    char kdata[AKVC_IOCTL_PARAM_MAX_SIZE] = { 0, };
    long ret;

    if (cmd_nr >= ARRAY_SIZE(akvc_ioctl_commands))
        return -ENOIOCTLCMD;

    if (_IOC_TYPE(cmd) != AKVC_IOC_TYPE)
        return -ENOIOCTLCMD;

    if (_IOC_SIZE(akvc_ioctl_commands[cmd_nr].cmd)) {
        ret = akvc_ioctl_copy_in(akvc_ioctl_commands[cmd_nr].cmd, cmd, arg, kdata);
        if (ret)
            return ret;
    }

    ret = akvc_ioctl_commands[cmd_nr].handler(vm, cmd, kdata);
    if (ret == 0 && _IOC_SIZE(akvc_ioctl_commands[cmd_nr].cmd))
        ret = akvc_ioctl_copy_out(akvc_ioctl_commands[cmd_nr].cmd, cmd, arg, kdata);

    return ret;
}