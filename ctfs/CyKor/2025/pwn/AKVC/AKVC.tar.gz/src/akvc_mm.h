#ifndef _AKVC_MM_H
#define _AKVC_MM_H

#include <linux/list.h>
#include <linux/kref.h>

typedef unsigned long vm_address_t;

#define AKVC_MM_MIN_ADDRESS 0UL
#define AKVC_MM_MAX_ADDRESS 0x800000000000UL

#define AKVC_MM_MAP_PROT_READ  (1 << 0)
#define AKVC_MM_MAP_PROT_WRITE (1 << 1)
/* TODO: implement exec */
// #define AKVC_MM_MAP_PROT_EXEC  (1 << 2)

struct akvc_memdesc {
    struct kref refcount;
    pid_t host_pid;
    vm_address_t vm_start;
    u64 __user host_addr;
    size_t len;

    unsigned int prot;
    struct page **pages;
};

struct akvc_mm {
    struct maple_tree *mt;
};

struct akvc_mm *akvc_mm_init(void);
void akvc_mm_destroy(struct akvc_mm *mm);

size_t akvc_mm_read(struct akvc_mm *mm, vm_address_t addr, void *buf, size_t n);
size_t akvc_mm_write(struct akvc_mm *mm, vm_address_t addr, void *buf, size_t n);

int akvc_mm_mmap(struct akvc_mm *mm, u64 __user host_addr, vm_address_t vm_addr, size_t len, unsigned int prot);
int akvc_mm_mprotect(struct akvc_mm *mm, vm_address_t vm_addr, size_t len, unsigned int prot);
int akvc_mm_munmap(struct akvc_mm *mm, vm_address_t vm_addr, size_t len);

/* TODO: optimize these */
static inline int akvc_mm_read_u8(struct akvc_mm *mm, vm_address_t addr, u8 *value)
{
    return akvc_mm_read(mm, addr, value, sizeof(u8));
}

static inline int akvc_mm_read_u16(struct akvc_mm *mm, vm_address_t addr, u16 *value)
{
    return akvc_mm_read(mm, addr, value, sizeof(u16));
}

static inline int akvc_mm_read_u32(struct akvc_mm *mm, vm_address_t addr, u32 *value)
{
    return akvc_mm_read(mm, addr, value, sizeof(u32));
}

static inline int akvc_mm_read_u64(struct akvc_mm *mm, vm_address_t addr, u64 *value)
{
    return akvc_mm_read(mm, addr, value, sizeof(u64));
}

static inline int akvc_mm_write_u8(struct akvc_mm *mm, vm_address_t addr, u8 value)
{
    return akvc_mm_write(mm, addr, &value, sizeof(u8));
}

static inline int akvc_mm_write_u16(struct akvc_mm *mm, vm_address_t addr, u16 value)
{
    return akvc_mm_write(mm, addr, &value, sizeof(u16));
}

static inline int akvc_mm_write_u32(struct akvc_mm *mm, vm_address_t addr, u32 value)
{
    return akvc_mm_write(mm, addr, &value, sizeof(u32));
}

static inline int akvc_mm_write_u64(struct akvc_mm *mm, vm_address_t addr, u64 value)
{
    return akvc_mm_write(mm, addr, &value, sizeof(u64));
}

#endif /* _AKVC_MM_H */