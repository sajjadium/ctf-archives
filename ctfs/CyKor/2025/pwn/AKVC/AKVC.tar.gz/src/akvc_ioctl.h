#ifndef _AKVC_IOCTL_H
#define _AKVC_IOCTL_H

#include <linux/fs.h>

#include "akvc_vm.h"


long akvc_ioctl(struct file *filep, unsigned int cmd, unsigned long arg);

#endif /* _AKVC_IOCTL_H */


