#include <linux/slab.h>
#include <linux/maple_tree.h>
#include <linux/mm.h>
#include <linux/highmem.h>
#include <linux/vmalloc.h>

#include "akvc_mm.h"

static struct akvc_memdesc *akvc_memdesc_init(vm_address_t vm_start, u64 __user host_addr, size_t len, unsigned int prot, struct page **pages)
{
    struct akvc_memdesc *memdesc;

    memdesc = kzalloc(sizeof(*memdesc), GFP_KERNEL_ACCOUNT);
    if (!memdesc)
        return ERR_PTR(-ENOMEM);

    kref_init(&memdesc->refcount);
    memdesc->host_pid = pid_nr(current->thread_pid);
    memdesc->vm_start = vm_start;
    memdesc->host_addr = host_addr;
    memdesc->len = len;
    memdesc->prot = prot;
    memdesc->pages = pages;

    return memdesc;
}

static void akvc_memdesc_destroy(struct kref *kref)
{
    struct akvc_memdesc *memdesc = container_of(kref, struct akvc_memdesc, refcount);
    
    if (memdesc->pages) {
        for (size_t i = 0; i < memdesc->len / PAGE_SIZE; i++) {
            if (memdesc->pages[i])
                put_page(memdesc->pages[i]);
        }
        kfree(memdesc->pages);
    }
    
    kfree(memdesc);
}

static int __must_check akvc_memdesc_get(struct akvc_memdesc *memdesc)
{
    if (!memdesc)
        return 0;

    return kref_get_unless_zero(&memdesc->refcount);
}

static void akvc_memdesc_put(struct akvc_memdesc *memdesc)
{
    if (!memdesc)
        return;

    kref_put(&memdesc->refcount, akvc_memdesc_destroy);
}

static int copy_to_pages(struct page **pages, unsigned int count, off_t offset, const char *from, size_t len)
{
    void *map;

    map = vmap(pages, count, VM_MAP, PAGE_KERNEL);
    if (!map)
        return -ENOMEM;

    memcpy(map + offset, from, len);
    vunmap(map);

    return 0;
}

static int copy_from_pages(struct page **pages, unsigned int count, off_t offset, void *to, size_t len)
{
    void *map;

    map = vmap(pages, count, VM_MAP, PAGE_KERNEL);
    if (IS_ERR(map))
        return PTR_ERR(map);

    memcpy(to, map + offset, len);
    vunmap(map);

    return 0;
}

static size_t akvc_mm_rw(struct akvc_mm *mm, vm_address_t addr, void *buf, size_t n, bool write)
{
    struct akvc_memdesc *memdesc;
    vm_address_t cur_vm = addr;
    vm_address_t end;
    char *cur_buf = (char *)buf;
    size_t read_n = 0;
    int ret;

    if (n == 0)
        return n;

    if (addr < AKVC_MM_MIN_ADDRESS)
        return n;
    
    end = addr + n;
    if (end > AKVC_MM_MAX_ADDRESS)
        return n;

    if (addr > end)
        return n;

    while (cur_vm < end) {
        mtree_lock(mm->mt);
        memdesc = mtree_load(mm->mt, cur_vm);
        if (!memdesc || !akvc_memdesc_get(memdesc)) {
            mtree_unlock(mm->mt);
            return n - read_n;
        }
        mtree_unlock(mm->mt);

        unsigned int prot = READ_ONCE(memdesc->prot);
        if ((write && (prot & AKVC_MM_MAP_PROT_WRITE) == 0) ||
            (!write && (prot & AKVC_MM_MAP_PROT_READ) == 0)) {
            akvc_memdesc_put(memdesc);
            return n - read_n;
        }

        if (cur_vm < memdesc->vm_start || cur_vm >= memdesc->vm_start + memdesc->len) {
            akvc_memdesc_put(memdesc);
            return n - read_n;
        }

        const unsigned int pages_count = memdesc->len / PAGE_SIZE;
        const off_t offset = cur_vm - memdesc->vm_start;
        const unsigned long capacity = memdesc->len - offset;
        const unsigned long copy_n = (end - cur_vm) < capacity ? (end - cur_vm) : capacity;
        if (write)
            ret = copy_to_pages(memdesc->pages, pages_count, offset, cur_buf, copy_n);
        else
            ret = copy_from_pages(memdesc->pages, pages_count, offset, cur_buf, copy_n);
        
        if (ret < 0) {
            akvc_memdesc_put(memdesc);
            return n - read_n;
        }

        cur_vm += copy_n;
        cur_buf += copy_n;
        read_n += copy_n;

        akvc_memdesc_put(memdesc);
    }

    return n - read_n;
}

size_t akvc_mm_read(struct akvc_mm *mm, vm_address_t addr, void *buf, size_t n)
{
    return akvc_mm_rw(mm, addr, buf, n, false);
}

size_t akvc_mm_write(struct akvc_mm *mm, vm_address_t addr, void *buf, size_t n)
{
    return akvc_mm_rw(mm, addr, buf, n, true);
}

static bool validate_vma(struct vm_area_struct *vma, u64 __user host_addr, size_t len)
{
    if (!vma)
        return false;

    /* TODO: support partial mapping */
    if (!(vma->vm_start == host_addr && vma->vm_end == host_addr + len))
        return false;

    /* only anonymous mappings are allowed */
    if (vma->vm_file)
        return false;

    return true;
}

static bool validate_vm_address(struct akvc_mm *mm, vm_address_t addr, size_t len)
{
    vm_address_t start = addr;
    vm_address_t end = addr + len;

    if (!IS_ALIGNED(addr, PAGE_SIZE) || !IS_ALIGNED(len, PAGE_SIZE))
        return false;

    if (len == 0)
        return false;

    if (end > AKVC_MM_MAX_ADDRESS || addr < AKVC_MM_MIN_ADDRESS)
        return false;

    /* overflow? */
    if (end < start)
        return false;

    /* overlap? */
    if (mt_find(mm->mt, &start, end - 1))
        return false;

    return true;
}

int akvc_mm_mmap(struct akvc_mm *mm, u64 __user host_addr, vm_address_t vm_addr, size_t len, unsigned int prot)
{
    struct page **pages = NULL;
    unsigned int gup_flags = (prot & AKVC_MM_MAP_PROT_WRITE) ? FOLL_WRITE : 0;
    unsigned long nr_pages = len / PAGE_SIZE;
    struct akvc_memdesc *memdesc = NULL;
    struct vm_area_struct *vma;
    long nr_pages_ret;
    int ret = 0;

    /* silently ignore unknown prot */
    prot &= (
        AKVC_MM_MAP_PROT_READ | 
        AKVC_MM_MAP_PROT_WRITE
    );

    if (!IS_ALIGNED(host_addr, PAGE_SIZE))
        return -EINVAL;

    if (!validate_vm_address(mm, vm_addr, len))
        return -EINVAL;

    pages = kcalloc(nr_pages, sizeof(*pages), GFP_KERNEL_ACCOUNT);
    if (!pages)
        return -ENOMEM;

    mmap_read_lock(current->mm);
    vma = find_vma(current->mm, host_addr);
    if (!validate_vma(vma, host_addr, len)) {
        mmap_read_unlock(current->mm);
        ret = -EINVAL;
        goto error;
    }

    nr_pages_ret = get_user_pages(host_addr, nr_pages, gup_flags, pages);
    mmap_read_unlock(current->mm);

    if (nr_pages_ret < 0) {
        ret = nr_pages_ret;
        goto error;
    }

    if (nr_pages_ret != nr_pages) {
        ret = -EINVAL;
        goto error;
    }

    ret = do_mseal(host_addr, len, 0);
    if (ret < 0)
        goto error;

    memdesc = akvc_memdesc_init(vm_addr, host_addr, len, prot, pages);
    if (IS_ERR(memdesc)) {
        ret = PTR_ERR(memdesc);
        goto error;
    }

    ret = mtree_store_range(mm->mt, vm_addr, vm_addr + len - 1, memdesc, GFP_KERNEL_ACCOUNT);
    if (ret)
        goto error;

    return ret;

error:
    if (pages) {
        for (long i = 0; i < nr_pages_ret; i++)
            put_page(pages[i]);
        kfree(pages);
    }

    if (memdesc)
        kfree(memdesc);

    return ret;
}

int akvc_mm_mprotect(struct akvc_mm *mm, vm_address_t vm_addr, size_t len, unsigned int prot)
{
    struct akvc_memdesc *memdesc = NULL;
    vm_address_t start = vm_addr;
    struct vm_area_struct *vma;
    u64 __user host_addr;
    int ret = 0;

    /* silently ignore unknown prot */
    prot &= (
        AKVC_MM_MAP_PROT_READ | 
        AKVC_MM_MAP_PROT_WRITE
    );

    mtree_lock(mm->mt);
    memdesc = mtree_load(mm->mt, start);
    if (!memdesc) {
        mtree_unlock(mm->mt);
        ret = -ENOENT;
        goto error;
    }

    if (!akvc_memdesc_get(memdesc)) {
        mtree_unlock(mm->mt);
        memdesc = NULL;
        ret = -ENOENT;
        goto error;
    }
    mtree_unlock(mm->mt);

    if (memdesc->host_pid != pid_nr(current->thread_pid)) {
        ret = -EACCES;
        goto error;
    }

    /* TODO: support partial mprotect */
    if (memdesc->vm_start != vm_addr || memdesc->len != len) {
        ret = -EINVAL;
        goto error;
    }

    host_addr = memdesc->host_addr;

    mmap_read_lock(current->mm);
    vma = find_vma(current->mm, host_addr);
    if (!validate_vma(vma, host_addr, len)) {
        mmap_read_unlock(current->mm);
        ret = -EINVAL;
        goto error;
    }

    if ((prot & AKVC_MM_MAP_PROT_READ) && !(vma->vm_flags & VM_READ)) {
        mmap_read_unlock(current->mm);
        ret = -EACCES;
        goto error;
    }

    if ((prot & AKVC_MM_MAP_PROT_WRITE) && !(vma->vm_flags & VM_WRITE)) {
        mmap_read_unlock(current->mm);
        ret = -EACCES;
        goto error;
    }
    mmap_read_unlock(current->mm);

    memdesc->prot = prot;

error:
    if (memdesc)
        akvc_memdesc_put(memdesc);

    return ret;
}

int akvc_mm_munmap(struct akvc_mm *mm, vm_address_t vm_addr, size_t len)
{
    struct akvc_memdesc *memdesc;
    struct akvc_memdesc *erased_memdesc;

    mtree_lock(mm->mt);
    memdesc = mtree_load(mm->mt, vm_addr);
    if (!memdesc) {
        mtree_unlock(mm->mt);
        return -ENOENT;
    }

    if (!akvc_memdesc_get(memdesc)) {
        mtree_unlock(mm->mt);
        memdesc = NULL;
        return -ENOENT;
    }
    mtree_unlock(mm->mt);

    if (memdesc->host_pid != pid_nr(current->thread_pid)) {
        akvc_memdesc_put(memdesc);
        return -EACCES;
    }

    /* TODO: support partial unmapping */
    if (memdesc->vm_start != vm_addr || memdesc->len != len) {
        akvc_memdesc_put(memdesc);
        return -EINVAL;
    }

    erased_memdesc = mtree_erase(mm->mt, vm_addr);

    /* FIXME: is this possible? */
    WARN_ON(erased_memdesc != memdesc);

    akvc_memdesc_put(memdesc);
    akvc_memdesc_put(erased_memdesc);

    return 0;
}

struct akvc_mm *akvc_mm_init(void)
{
    struct akvc_mm *mm;

    mm = kzalloc(sizeof(*mm), GFP_KERNEL_ACCOUNT);
    if (!mm)
        return ERR_PTR(-ENOMEM);

    mm->mt = kzalloc(sizeof(*mm->mt), GFP_KERNEL_ACCOUNT);
    if (!mm->mt) {
        kfree(mm);
        return ERR_PTR(-ENOMEM);
    }

    mt_init_flags(mm->mt, MT_FLAGS_USE_RCU);

    return mm;
}

void akvc_mm_destroy(struct akvc_mm *mm)
{
    struct akvc_memdesc *memdesc;
    MA_STATE(mas, mm->mt, AKVC_MM_MIN_ADDRESS, AKVC_MM_MAX_ADDRESS);

    if (!mm)
        return;

    mas_lock(&mas);
    mas_for_each(&mas, memdesc, AKVC_MM_MAX_ADDRESS) {
        mas_erase(&mas);
        if (memdesc)
            akvc_memdesc_put(memdesc);
        cond_resched();
    }
    mas_unlock(&mas);

    mtree_destroy(mm->mt);
    kfree(mm->mt);
    kfree(mm);
}