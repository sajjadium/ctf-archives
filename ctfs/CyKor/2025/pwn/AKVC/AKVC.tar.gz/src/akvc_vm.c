#include <linux/slab.h>

#include "akvc_vm.h"
#include "akvc_mm.h"
#include "akvc_inst.h"

static u64 get_register(struct akvc_vm *vm, enum akvc_register reg)
{
    if (WARN_ON(reg < 0 || reg > REGISTER_MAX))
        return 0;

    return vm->registers[reg];
}

static void set_register(struct akvc_vm *vm, enum akvc_register reg, u64 value)
{
    if (WARN_ON(reg < 0 || reg > REGISTER_MAX))
        return;

    vm->registers[reg] = value;
}

static int handle_nop(struct akvc_vm *vm, struct akvc_inst_nop *inst)
{
    return 0;
}

static int handle_mov(struct akvc_vm *vm, struct akvc_inst_mov *inst)
{
    u64 value = get_register(vm, inst->src);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    set_register(vm, inst->dst, value);

    return 0;
}

static int handle_mov_imm(struct akvc_vm *vm, struct akvc_inst_mov_imm *inst)
{
    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    set_register(vm, inst->dst, inst->imm);

    return 0;
}

static int handle_add(struct akvc_vm *vm, struct akvc_inst_add *inst)
{
    u64 src_value = get_register(vm, inst->src);
    u64 dst_value = get_register(vm, inst->dst);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;
    
    set_register(vm, inst->dst, dst_value + src_value);

    return 0;
}

static int handle_sub(struct akvc_vm *vm, struct akvc_inst_sub *inst)
{
    u64 src_value = get_register(vm, inst->src);
    u64 dst_value = get_register(vm, inst->dst);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    set_register(vm, inst->dst, dst_value - src_value);

    return 0;
}

static int handle_mul(struct akvc_vm *vm, struct akvc_inst_mul *inst)
{
    u64 src_value = get_register(vm, inst->src);
    u64 dst_value = get_register(vm, inst->dst);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    set_register(vm, inst->dst, dst_value * src_value);

    return 0;
}

static int handle_div(struct akvc_vm *vm, struct akvc_inst_div *inst)
{
    u64 src_value = get_register(vm, inst->src);
    u64 dst_value = get_register(vm, inst->dst);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    if (src_value == 0)
        return -EINVAL;
    
    set_register(vm, inst->dst, dst_value / src_value);

    return 0;
}

static int handle_mod(struct akvc_vm *vm, struct akvc_inst_mod *inst)
{
    u64 src_value = get_register(vm, inst->src);
    u64 dst_value = get_register(vm, inst->dst);

    if (inst->dst < 0 || inst->dst > GENERAL_REGISTER_MAX)
        return -EINVAL;

    if (src_value == 0)
        return -EINVAL;
    
    set_register(vm, inst->dst, dst_value % src_value);

    return 0;
}

static int handle_load(struct akvc_vm *vm, struct akvc_inst_load *inst)
{
    u64 value;

    if (inst->reg < 0 || inst->reg > GENERAL_REGISTER_MAX)
        return -EINVAL;

    if (akvc_mm_read_u64(vm->mm, inst->addr, &value) != 0)
        return -EFAULT;
    
    set_register(vm, inst->reg, value);

    return 0;
}

static int handle_store(struct akvc_vm *vm, struct akvc_inst_store *inst)
{
    u64 value = get_register(vm, inst->reg);

    if (akvc_mm_write_u64(vm->mm, inst->addr, value) != 0)
        return -EFAULT;

    return 0;
}

static int handle_jump(struct akvc_vm *vm, struct akvc_inst_jump *jump, u64 *pc)
{
    u8 zf = !!(get_register(vm, FLAGS) & AKVC_FLAGS_ZF);
    u8 cf = !!(get_register(vm, FLAGS) & AKVC_FLAGS_CF);
    bool satisfied;

    switch (jump->cond) {
    case AKVC_COND_JMP:
        satisfied = true;
        break;
    case AKVC_COND_JEQ:
        satisfied = zf == 1;
        break;
    case AKVC_COND_JNE:
        satisfied = zf == 0;
        break;
    case AKVC_COND_JA:
        satisfied = (cf == 0) && (zf == 0);
        break;
    case AKVC_COND_JAE:
        satisfied = cf == 0;
        break;
    case AKVC_COND_JB:
        satisfied = cf == 1;
        break;
    case AKVC_COND_JBE:
        satisfied = (cf == 1) || (zf == 1);
        break;
    default:
        return -EINVAL;
    }

    if (satisfied)
        *pc = jump->target;

    return 0;
}

static int handle_cmp(struct akvc_vm *vm, struct akvc_inst_cmp *cmp)
{
    u64 left_value = get_register(vm, cmp->left);
    u64 right_value = get_register(vm, cmp->right);
    u8 flags = get_register(vm, FLAGS);

    if (left_value == right_value)
        flags |= AKVC_FLAGS_ZF;
    else
        flags &= ~AKVC_FLAGS_ZF;

    if (left_value < right_value)
        flags |= AKVC_FLAGS_CF;
    else
        flags &= ~AKVC_FLAGS_CF;

    set_register(vm, FLAGS, flags);

    return 0;
}


int akvc_vm_run(struct akvc_vm *vm, u32 max_steps, u64 entry_pc)
{
    int ret = 0;
    u32 steps = 0;

    set_register(vm, PC, entry_pc);

    while (steps < max_steps) {
        u64 pc = get_register(vm, PC);

        u8 op;

        if (akvc_mm_read_u8(vm->mm, pc, &op) != 0)
            return -EFAULT;

        pc += sizeof(op);

        switch (op) {
        case AKVC_INST_NOP:
            struct akvc_inst_nop nop;
            if (akvc_mm_read(vm->mm, pc, &nop, sizeof(nop)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(nop);
            ret = handle_nop(vm, &nop);
            break;
        case AKVC_INST_MOV:
            struct akvc_inst_mov mov;
            if (akvc_mm_read(vm->mm, pc, &mov, sizeof(mov)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(mov);
            ret = handle_mov(vm, &mov);
            break;
        case AKVC_INST_MOV_IMM:
            struct akvc_inst_mov_imm mov_imm;
            if (akvc_mm_read(vm->mm, pc, &mov_imm, sizeof(mov_imm)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(mov_imm);
            ret = handle_mov_imm(vm, &mov_imm);
            break;
        case AKVC_INST_ADD:
            struct akvc_inst_add add;
            if (akvc_mm_read(vm->mm, pc, &add, sizeof(add)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(add);
            ret = handle_add(vm, &add);
            break;
        case AKVC_INST_SUB:
            struct akvc_inst_sub sub;
            if (akvc_mm_read(vm->mm, pc, &sub, sizeof(sub)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(sub);
            ret = handle_sub(vm, &sub);
            break;
        case AKVC_INST_MUL:
            struct akvc_inst_mul mul;
            if (akvc_mm_read(vm->mm, pc, &mul, sizeof(mul)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(mul);
            ret = handle_mul(vm, &mul);
            break;
        case AKVC_INST_DIV:
            struct akvc_inst_div div;
            if (akvc_mm_read(vm->mm, pc, &div, sizeof(div)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(div);
            ret = handle_div(vm, &div);
            break;
        case AKVC_INST_MOD:
            struct akvc_inst_mod mod;
            if (akvc_mm_read(vm->mm, pc, &mod, sizeof(mod)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(mod);
            ret = handle_mod(vm, &mod);
            break;
        case AKVC_INST_LOAD:
            struct akvc_inst_load load;
            if (akvc_mm_read(vm->mm, pc, &load, sizeof(load)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(load);
            ret = handle_load(vm, &load);
            break;
        case AKVC_INST_STORE:
            struct akvc_inst_store store;
            if (akvc_mm_read(vm->mm, pc, &store, sizeof(store)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(store);
            ret = handle_store(vm, &store);
            break;
        case AKVC_INST_JUMP:
            struct akvc_inst_jump jump;
            if (akvc_mm_read(vm->mm, pc, &jump, sizeof(jump)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(jump);
            ret = handle_jump(vm, &jump, &pc);
            break;
        case AKVC_INST_CMP:
            struct akvc_inst_cmp cmp;
            if (akvc_mm_read(vm->mm, pc, &cmp, sizeof(cmp)) != 0) {
                ret = -EFAULT;
                break;
            }
            pc += sizeof(cmp);
            ret = handle_cmp(vm, &cmp);
            break;
        default:
            ret = -EINVAL;
            break;
        }

        if (ret < 0) {
            pr_err("AKVC: pc: %#llx, error: %d\n", pc, ret);
            break;
        }

        set_register(vm, PC, pc);
        steps++;

        cond_resched();
    }

    return ret;
}

struct akvc_vm *akvc_vm_init(void)
{
    struct akvc_vm *vm;
    struct akvc_mm *mm;

    vm = kzalloc(sizeof(*vm), GFP_KERNEL_ACCOUNT);
    if (!vm)
        return ERR_PTR(-ENOMEM);

    mm = akvc_mm_init();
    if (IS_ERR(mm)) {
        kfree(vm);
        return ERR_CAST(mm);
    }

    vm->mm = mm;

    set_register(vm, R0, 0);
    set_register(vm, R1, 0);
    set_register(vm, R2, 0);
    set_register(vm, R3, 0);
    set_register(vm, PC, 0);
    set_register(vm, FLAGS, 0);

    return vm;
}

void akvc_vm_destroy(struct akvc_vm *vm)
{
    if (!vm)
        return;

    if (vm->mm)
        akvc_mm_destroy(vm->mm);

    kfree(vm);
}