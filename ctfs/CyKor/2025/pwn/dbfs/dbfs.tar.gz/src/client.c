#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/xattr.h>
#include <linux/limits.h>

#include "dbfs_kv.h"

void fatal(const char *msg)
{
    perror(msg);
    _exit(EXIT_FAILURE);
}

int is_file(const char *name)
{
    struct stat stat_buf;
    int ret;

    ret = stat(name, &stat_buf);
    if (ret < 0)
        fatal("stat");

    return S_ISREG(stat_buf.st_mode);
}

int get_file_size(const char *name)
{
    struct stat stat_buf;
    int ret;

    ret = stat(name, &stat_buf);
    if (ret < 0)
        fatal("stat");

    return stat_buf.st_size;
}

void handle_get_file(const char *name)
{
    char type_str[16] = {0, };
    enum dbfs_value_type type;
    int ret;

    ret = getxattr(name, "user.type", type_str, sizeof(type_str));
    if (ret < 0)
        fatal("getxattr");

    type = dbfs_type_string_to_enum(type_str);
    if (type == DBFS_VALUE_TYPE_UNKNOWN)
        fatal("dbfs_type_string_to_enum");
    
    printf("Type: %s\n", type_str);

    switch (type) {
    case DBFS_VALUE_TYPE_NULL:
        printf("Value: null\n");
        break;
    case DBFS_VALUE_TYPE_INT: {
        char buffer[32] = {0, };
        ssize_t bytes_read;

        int fd = open(name, O_RDONLY);
        if (fd < 0)
            fatal("open");

        bytes_read = read(fd, buffer, sizeof(buffer) - 1);
        if (bytes_read < 0)
            fatal("read");
        
        printf("Value: %s\n", buffer);
        close(fd);
        break;
    }
    case DBFS_VALUE_TYPE_BYTES: {
        char *buffer;
        size_t buffer_size;
        ssize_t bytes_read;

        int fd = open(name, O_RDONLY);
        if (fd < 0)
            fatal("open");
        
        buffer_size = get_file_size(name);
        buffer = malloc(buffer_size);
        if (!buffer)
            fatal("malloc");

        bytes_read = read(fd, buffer, buffer_size);
        if ((size_t)bytes_read != buffer_size)
            fatal("read");
        
        printf("Value (hex): ");
        for (size_t i = 0; i < buffer_size; i++) {
            printf("%02x", (unsigned char)buffer[i]);
        }
        printf("\n");
        close(fd);
        break;
    }
    default:
        printf("Value: (unknown type)\n");
        break;
    }
}

void handle_get_dir(const char *name)
{
    DIR *dir;
    struct dirent *entry;

    dir = opendir(name);
    if (dir == NULL)
        fatal("opendir");
    
    while ((entry = readdir(dir)) != NULL)
        printf("%s\n", entry->d_name);

    closedir(dir);
}

void handle_get(const char *name)
{
    if (strchr(name, '/'))
        return;

    if (is_file(name))
        handle_get_file(name);
    else
        handle_get_dir(name);
}

void handle_set_file(const char *name, enum dbfs_value_type type, const char *value, size_t value_len)
{
    int fd;
    ssize_t bytes_written;
    const char *type_str;

    fd = creat(name, 0755);
    if (fd < 0)
        fatal("open");

    type_str = dbfs_type_enum_to_string(type);

    int ret = setxattr(name, "user.type", type_str, strlen(type_str) + 1, 0);
    if (ret < 0)
        fatal("setxattr");

    switch (type) {
    case DBFS_VALUE_TYPE_NULL:
        break;
    case DBFS_VALUE_TYPE_INT: {
        bytes_written = write(fd, value, strlen(value));
        if (bytes_written < 0)
            fatal("write");
        break;
    }
    case DBFS_VALUE_TYPE_BYTES:
        bytes_written = write(fd, value, value_len);
        if (bytes_written != (ssize_t)value_len)
            fatal("write");
        break;
    default:
        break;
    }

    close(fd);
}

void handle_set_dir(const char *name)
{
    int ret;

    ret = mkdir(name, 0755);
    if (ret < 0)
        fatal("mkdir");
}

void handle_set(const char *name, const char *type_str, const char *value, size_t value_len)
{
    enum dbfs_value_type type;

    if (strchr(name, '/'))
        return;

    type = dbfs_type_string_to_enum(type_str);
    if (type == DBFS_VALUE_TYPE_UNKNOWN)
        fatal("dbfs_type_string_to_enum");

    if (type == DBFS_VALUE_TYPE_SET)
        handle_set_dir(name);
    else 
        handle_set_file(name, type, value, value_len);
}

void handle_delete(const char *name)
{
    int ret;

    if (strchr(name, '/'))
        return;

    if (is_file(name)) {
        ret = unlink(name);
        if (ret < 0)
            fatal("unlink");
    } else {
        ret = rmdir(name);
        if (ret < 0)
            fatal("rmdir");
    }
}

void handle_info(const char *name)
{
    struct stat stat_buf;
    char type_str[16] = {0, };
    enum dbfs_value_type type;
    char full_path[PATH_MAX + 1];
    int ret;

    if (strchr(name, '/'))
        return;

    ret = stat(name, &stat_buf);
    if (ret < 0)
        fatal("stat");

    ret = getxattr(name, "user.type", type_str, sizeof(type_str));
    if (ret < 0)
        fatal("getxattr");

    type = dbfs_type_string_to_enum(type_str);
    if (type == DBFS_VALUE_TYPE_UNKNOWN)
        fatal("dbfs_type_string_to_enum");

    getcwd(full_path, sizeof(full_path));
    strcat(full_path, "/");
    strcat(full_path, name);

    printf("-------------- Info --------------\n");
    printf("Name: %s\n", name);
    printf("Full Path: %s\n", full_path);
    printf("Type: %s\n", type_str);
    printf("Size: %ld\n", stat_buf.st_size);
    printf("Owner UID: %d\n", stat_buf.st_uid);
    printf("Owner GID: %d\n", stat_buf.st_gid);
    printf("Mode: %o\n", stat_buf.st_mode);
    printf("----------------------------------\n");
}

void handle_chdir(char *name)
{
    int ret;

    if (strchr(name, '/'))
        return;

    ret = chdir(name);
    if (ret < 0)
        fatal("chdir");
}

int hex2bytes(const char *hexstr, char **out, size_t *out_size)
{
    size_t hexstr_len = strlen(hexstr);
    if (hexstr_len == 0 || hexstr_len % 2 != 0)
        return -1;

    size_t bytes_len = hexstr_len / 2;
    char *bytes = malloc(bytes_len);
    if (!bytes)
        return -1;

    for (size_t i = 0; i < bytes_len; i++) 
        sscanf(hexstr + 2 * i, "%2hhx", &bytes[i]);

    *out_size = bytes_len;
    *out = bytes;

    return 0;
}

int check_int_str(const char *str)
{
    errno = 0;
    strtol(str, NULL, 10);
    if (errno != 0)
        return -1;
    else
        return 0;
}

void execute_command(char *command)
{
    const char *delim = " \t\n";
    char *command_name, *name, *type, *value;
    size_t value_len;
    char *bytes = NULL;
    size_t bytes_len = 0;

    command_name = strtok(command, delim);
    if (command_name == NULL) 
        return;

    name = strtok(NULL, delim);
    if (name == NULL) 
        return;
    
    if (strcmp(command_name, "SET") == 0) {
        type = strtok(NULL, delim);
        if (type == NULL) 
            return;

        value = strtok(NULL, delim);
        
        if (strcmp(type, "bytes") == 0) {
            if (value == NULL) 
                value = "00";

            if (hex2bytes(value, &bytes, &bytes_len) < 0) 
                fatal("hex2bytes");

            value = bytes;
            value_len = bytes_len;
        } else if (strcmp(type, "int") == 0) {
            if (value == NULL) 
                value = "0";

            if (check_int_str(value) < 0) 
                fatal("check_int_str");

            value_len = strlen(value);
        } else if (strcmp(type, "null") == 0 || strcmp(type, "set") == 0) {
            value = NULL;
            value_len = 0;
        } else {
            printf("Unknown type: %s\n", type);
            return;
        }

        handle_set(name, type, value, value_len);

        if (bytes)
            free(bytes);
    } else if (strcmp(command_name, "GET") == 0) {
        handle_get(name);
    } else if (strcmp(command_name, "DELETE") == 0) {
        handle_delete(name);
    } else if (strcmp(command_name, "INFO") == 0) {
        handle_info(name);
    } else if (strcmp(command_name, "CHDIR") == 0) {
        handle_chdir(name);
    } else {
        printf("Unknown command: %s\n", command_name);
    }
}

void setup_chroot_jail(const char *root_directory)
{
    int ret;

    ret = chdir(root_directory);
    if (ret < 0)
        fatal("chdir");

    ret = chroot(root_directory);
    if (ret < 0)
        fatal("chroot");
}

void print_help(void)
{
    printf("Available commands:\n");
    printf("  SET <name> <type> [value]  - Set a key or directory\n");
    printf("  GET <name>                 - Get a key or list a directory\n");
    printf("  DELETE <name>              - Delete a key or directory\n");
    printf("  INFO <name>                - Get information about a key or directory\n");
    printf("  CHDIR <name>               - Change current directory\n");
    printf("Types:\n");
    printf("  int    - Integer value\n");
    printf("  bytes  - Binary data in hex format (e.g., '48656c6c6f' for 'Hello')\n");
    printf("  null   - Null value\n");
    printf("  set    - Directory\n");
}

int main(int argc, char *argv[])
{
    char *command = NULL;
    size_t command_len = 0;
    char *root_directory;

    setbuf(stdin, NULL);
    setbuf(stdout, NULL);
    setbuf(stderr, NULL);
    
    if (argc != 2) {
        fprintf(stderr, "Usage: %s [root directory]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    root_directory = argv[1];

    setup_chroot_jail(root_directory);
    memset(argv[1], 'X', strlen(argv[1]));

    print_help();

    while (1) {
        printf("dbfs> ");
        ssize_t read_len = getline(&command, &command_len, stdin);
        if (read_len < 0)
            fatal("getline");

        execute_command(command);

        free(command);
        command = NULL;
        command_len = 0;
    }
    
    return 0;
}