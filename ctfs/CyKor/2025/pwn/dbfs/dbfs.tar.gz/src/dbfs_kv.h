#ifndef _DBFS_KV_H
#define _DBFS_KV_H

#include <sys/types.h>

#define DBFS_HASH_TABLE_SIZE 0x100

extern struct dbfs_key *dbfs_root_key;

struct dbfs_bytes {
    size_t size;
    char *data;
};

struct dbfs_set {
    struct dbfs_key *hash_table[DBFS_HASH_TABLE_SIZE];

    int refcount;
};

typedef void *dbfs_null_t;
typedef int64_t dbfs_number_t;
typedef struct dbfs_bytes *dbfs_bytes_t;
typedef struct dbfs_set *dbfs_set_t;

union dbfs_value_internal {
    dbfs_null_t null;
    dbfs_number_t number;
    dbfs_bytes_t bytes;
    dbfs_set_t set;
};

enum dbfs_value_type {
    DBFS_VALUE_TYPE_SET = 's',
    DBFS_VALUE_TYPE_NULL = 'n',
    DBFS_VALUE_TYPE_INT = 'i',
    DBFS_VALUE_TYPE_BYTES = 'b',
    DBFS_VALUE_TYPE_UNKNOWN = 'u',
};

struct dbfs_value {
    enum dbfs_value_type type;
    union dbfs_value_internal v;

    uid_t owner_uid;
    gid_t owner_gid;
    mode_t mode;
};

// file / directory name
struct dbfs_key {
    char *name;

    struct dbfs_value *value;
    struct dbfs_key *next;

    int refcount;
};

enum dbfs_value_type dbfs_type_string_to_enum(const char *type_str);
const char *dbfs_type_enum_to_string(enum dbfs_value_type type);

struct dbfs_value *dbfs_value_create(char type, void *value);
void dbfs_value_destroy(struct dbfs_value *value);

struct dbfs_key *dbfs_key_create(const char *name, struct dbfs_value *value);
void dbfs_key_destroy(struct dbfs_key *key);

struct dbfs_set *dbfs_set_create(void);
void dbfs_set_destroy(struct dbfs_set *set);
int dbfs_set_insert_key(struct dbfs_set *set, struct dbfs_key *key);
int dbfs_set_remove_key(struct dbfs_set *set, const char *name);

struct dbfs_key *dbfs_search_key_by_path(const char *path);
struct dbfs_value *dbfs_search_value_by_path(const char *path);

struct dbfs_bytes *dbfs_bytes_create(size_t size);
int dbfs_bytes_resize(struct dbfs_bytes *bytes, size_t new_size);
int dbfs_bytes_destroy(struct dbfs_bytes *bytes);


#endif /* _DBFS_KV_H */