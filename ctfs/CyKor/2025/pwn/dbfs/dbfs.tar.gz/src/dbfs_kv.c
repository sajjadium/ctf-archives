/* The original goal was to pwn the FUSE server too, but I removed it since it looked too complex :) */

#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "dbfs_kv.h"

struct dbfs_key *dbfs_root_key = NULL;

enum dbfs_value_type dbfs_type_string_to_enum(const char *type_str)
{
    if (strcmp(type_str, "set") == 0)
        return DBFS_VALUE_TYPE_SET;
    else if (strcmp(type_str, "null") == 0)
        return DBFS_VALUE_TYPE_NULL;
    else if (strcmp(type_str, "int") == 0)
        return DBFS_VALUE_TYPE_INT;
    else if (strcmp(type_str, "bytes") == 0)
        return DBFS_VALUE_TYPE_BYTES;
    else
        return DBFS_VALUE_TYPE_UNKNOWN;
}

const char *dbfs_type_enum_to_string(enum dbfs_value_type type)
{
    switch (type) {
    case DBFS_VALUE_TYPE_SET:
        return "set";
    case DBFS_VALUE_TYPE_NULL:
        return "null";
    case DBFS_VALUE_TYPE_INT:
        return "int";
    case DBFS_VALUE_TYPE_BYTES:
        return "bytes";
    default:
        return "unknown";
    }
}

static unsigned long hash_djb2(const char *key)
{
    unsigned long hash = 5381;

    for (char c = *key; c != 0; c = *(++key)) {
        hash = ((hash << 5) + hash) + c;
    }

    return hash % DBFS_HASH_TABLE_SIZE;
}

struct dbfs_value *dbfs_value_create(char type, void *value)
{
    struct dbfs_value *val;

    val = calloc(1, sizeof(*val));
    if (!val)
        return NULL;

    val->type = type;
    val->v.null = value;

    return val;
}

void dbfs_value_destroy(struct dbfs_value *value)
{
    if (!value)
        return;

    if (value->type == DBFS_VALUE_TYPE_SET)
        dbfs_set_destroy(value->v.set);
    else if (value->type == DBFS_VALUE_TYPE_BYTES)
        dbfs_bytes_destroy(value->v.bytes);

    free(value);
}

struct dbfs_key *dbfs_key_create(const char *name, struct dbfs_value *value)
{
    struct dbfs_key *key;
    
    key = calloc(1, sizeof(*key));
    if (!key)
        return NULL;

    key->name = strdup(name);
    if (!key->name) {
        free(key);
        return NULL;
    }

    key->value = value;

    return key;
}

void dbfs_key_destroy(struct dbfs_key *key)
{
    if (!key)
        return;

    free(key->name);
    free(key);
}

void dbfs_kv_destroy(struct dbfs_key *key)
{
    if (!key)
        return;

    dbfs_value_destroy(key->value);
    dbfs_key_destroy(key);
}

struct dbfs_set *dbfs_set_create(void)
{
    struct dbfs_set *set;

    set = calloc(1, sizeof(*set));
    if (!set)
        return NULL;

    return set;
}

void dbfs_set_destroy(struct dbfs_set *set)
{
    if (!set)
        return;

    for (int i = 0; i < DBFS_HASH_TABLE_SIZE; i++) {
        struct dbfs_key *current_key = set->hash_table[i];
        while (current_key) {
            struct dbfs_key *next = current_key->next;
            dbfs_value_destroy(current_key->value);
            free(current_key->name);
            free(current_key);
            current_key = next;
        }
    }

    free(set);
}

struct dbfs_key *dbfs_set_search_key_by_name(struct dbfs_set *set, const char *name)
{
    unsigned long index = hash_djb2(name);
    struct dbfs_key *current = set->hash_table[index];

    while (current) {
        if (strcmp(current->name, name) == 0)
            return current;

        current = current->next;
    }

    return NULL;
}

struct dbfs_value *dbfs_set_search_value_by_name(struct dbfs_set *set, const char *name)
{
    struct dbfs_key *key;

    key = dbfs_set_search_key_by_name(set, name);
    if (!key)
        return NULL;

    return key->value;
}


int dbfs_set_insert_key(struct dbfs_set *set, struct dbfs_key *key)
{
    unsigned long index;

    if (dbfs_set_search_key_by_name(set, key->name))
        return -EEXIST;

    index = hash_djb2(key->name);
    key->next = set->hash_table[index];
    set->hash_table[index] = key;

    return 0;
}

int dbfs_set_remove_key(struct dbfs_set *set, const char *name)
{
    unsigned long index;
    struct dbfs_key *current, *prev = NULL;

    index = hash_djb2(name);
    current = set->hash_table[index];

    while (current) {
        if (strcmp(current->name, name) == 0) {
            if (prev)
                prev->next = current->next;
            else
                set->hash_table[index] = current->next;

            dbfs_kv_destroy(current);

            return 0;
        }

        prev = current;
        current = current->next;
    }

    return -ENOENT;
}

struct dbfs_key *dbfs_search_key_by_path(const char *path)
{
    char *path_copy, *token;
    struct dbfs_key *key = NULL;
    struct dbfs_value *value = NULL;
    struct dbfs_set *current_set;

    path_copy = strdup(path);
    if (!path_copy)
        return NULL;

    token = strtok(path_copy, "/");
    key = dbfs_root_key;
    value = key->value;
    current_set = value->v.set;

    while (token) {
        key = dbfs_set_search_key_by_name(current_set, token);
        if (!key)
            goto invalid_path;

        if (key->value->type != DBFS_VALUE_TYPE_SET) {
            if (!strtok(NULL, "/")) // is last token?
                break;
            else
                goto invalid_path;
        } else {
            current_set = key->value->v.set;
        }

        token = strtok(NULL, "/");
    }

    free(path_copy);

    return key;

invalid_path:
    free(path_copy);

    return NULL;
}

struct dbfs_value *dbfs_search_value_by_path(const char *path)
{
    struct dbfs_key *key;

    key = dbfs_search_key_by_path(path);
    if (!key)
        return NULL;

    return key->value;
}

struct dbfs_bytes *dbfs_bytes_create(size_t size)
{
    struct dbfs_bytes *bytes;

    bytes = calloc(1, sizeof(*bytes));
    if (!bytes)
        return NULL;

    bytes->data = calloc(1, size);
    if (!bytes->data) {
        free(bytes);
        return NULL;
    }

    bytes->size = size;

    return bytes;
}

int dbfs_bytes_resize(struct dbfs_bytes *bytes, size_t new_size)
{
    char *new_data;

    if (!bytes)
        return 0;
    
    if (bytes->size >= new_size)
        return 0;

    new_data = realloc(bytes->data, new_size);
    if (!new_data)
        return -ENOMEM;

    bytes->data = new_data;
    bytes->size = new_size;

    return 0;
}

int dbfs_bytes_destroy(struct dbfs_bytes *bytes)
{
    if (!bytes)
        return 0;

    free(bytes->data);
    free(bytes);

    return 0;
}