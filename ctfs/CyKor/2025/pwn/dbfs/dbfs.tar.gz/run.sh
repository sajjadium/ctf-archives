#!/bin/sh
TMP_DIR=`mktemp -d /tmp/dbfs-XXXXXX`

chown 1000:1000 $TMP_DIR

/app/client $TMP_DIR

rm -rf $TMP_DIR