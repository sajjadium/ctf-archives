This binary should run correctly on most Linux environments.

However, if it fails to execute or produces unexpected results, please use the provided Docker setup.
