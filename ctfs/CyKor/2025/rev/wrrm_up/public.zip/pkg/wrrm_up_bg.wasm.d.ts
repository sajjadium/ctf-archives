/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_sudoku_free: (a: number, b: number) => void;
export const sudoku_new: () => number;
export const sudoku_check: (a: number, b: number) => void;
export const sudoku_go_right: (a: number) => void;
export const sudoku_go_left: (a: number) => void;
export const sudoku_go_up: (a: number) => void;
export const sudoku_go_down: (a: number) => void;
export const sudoku_up: (a: number) => void;
export const sudoku_down: (a: number) => void;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
