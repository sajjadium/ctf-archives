/* tslint:disable */
/* eslint-disable */
export class Sudoku {
  free(): void;
  constructor();
  check(): string;
  go_right(): void;
  go_left(): void;
  go_up(): void;
  go_down(): void;
  up(): void;
  down(): void;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_sudoku_free: (a: number, b: number) => void;
  readonly sudoku_new: () => number;
  readonly sudoku_check: (a: number, b: number) => void;
  readonly sudoku_go_right: (a: number) => void;
  readonly sudoku_go_left: (a: number) => void;
  readonly sudoku_go_up: (a: number) => void;
  readonly sudoku_go_down: (a: number) => void;
  readonly sudoku_up: (a: number) => void;
  readonly sudoku_down: (a: number) => void;
  readonly __wbindgen_add_to_stack_pointer: (a: number) => number;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
