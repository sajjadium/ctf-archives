<?php
declare(strict_types=1);
require __DIR__ . '/config.php';

create_schema();
upsert_admin();

