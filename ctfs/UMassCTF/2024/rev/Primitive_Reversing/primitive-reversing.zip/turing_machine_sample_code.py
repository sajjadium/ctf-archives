blank = 0
ACCEPT = "#ACCEPT"
REJECT = "REJECT"
R = 1
L = -1
START = "#START"

class State:
    def __init__(self):
        self.cursor = 0
        self.tape = []
        self.current_state = START


class TuringMachine:
    def __init__(self):
        self.transitions = {}

    def run_machine(self, state: State):
        while True:
            if state.cursor == -1 or state.current_state == REJECT:
                return REJECT
            if state.current_state == ACCEPT:
                return ACCEPT
            if state.cursor >= len(state.tape):
                state.tape += [blank] * 1000
            if (state.current_state, state.tape[state.cursor]) not in self.transitions:
                return REJECT

            write, direction, next_state = self.transitions[(state.current_state, state.tape[state.cursor])]
            state.tape[state.cursor] = write
            state.current_state = next_state
            state.cursor += direction

    def add_transition(self, current, read, write, direction, next_state):
        self.transitions[(current, read)] = (write, direction, next_state)


# put the input to the TM here
INPUT = b""
tm = TuringMachine()

# load the TM in after this with tm.add_transition
flag_state = State()
flag_state.tape = [x for x in INPUT]

tm.run_machine(flag_state)
print(flag_state.tape)