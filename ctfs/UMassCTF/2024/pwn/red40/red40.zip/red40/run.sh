docker build -t red40 .

docker run --privileged -p1337:1337 red40
