echo 0 | tee /proc/sys/kernel/yama/ptrace_scope > /dev/null

/opt/red40/parent