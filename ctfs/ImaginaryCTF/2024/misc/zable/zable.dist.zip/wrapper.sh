#!/bin/sh
python3 -u chall.py