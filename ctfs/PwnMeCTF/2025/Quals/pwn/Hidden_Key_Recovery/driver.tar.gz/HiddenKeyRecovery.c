#include "HiddenKeyRecovery.h"
#include <Library/BaseLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/DebugLib.h>
#include <Library/PcdLib.h>
#include <Library/SmmMemLib.h>
#include <Library/SmmServicesTableLib.h>
#include <Library/UefiLib.h>
#include <Uefi.h>

CHAR8 *RecoveryPassword = "PWNME{fake_flag}                        ";
CHAR8 *PrivateKey = "307311313317331337347";

typedef struct {
  UINT64 Method;
  CHAR8 Password[0x100];
  union {
    CHAR8 NewKey[0x100];
    CHAR8 NewPassword[0x100];
    };
} User_Request;

EFI_STATUS
RecoverKey(IN OUT VOID *CommBuffer, IN OUT UINT64 *CommBufferSize) {
  User_Request *Request = (User_Request *)CommBuffer;

  DEBUG ((DEBUG_INFO, "Entered RecoverKey\n"));
  DEBUG ((DEBUG_INFO, "Request Password %a\n", Request->Password));
  if (AsciiStrCmp(Request->Password, RecoveryPassword)) {
    DEBUG ((DEBUG_INFO, "Wrong password...\n"));
    CopyMem(Request->Password, "Wrong Password\n", 16);
  }
  else {
    DEBUG ((DEBUG_INFO, "Access granted!\n"));
    CopyMem(Request->Password, PrivateKey, 22);
  }
  return EFI_SUCCESS;
}


EFI_STATUS
ChangeKey(IN OUT VOID *CommBuffer, IN OUT UINT64 *CommBufferSize) {
  User_Request *Request = (User_Request *)CommBuffer;
  UINTN len = 0;

  if (AsciiStrCmp(Request->Password, RecoveryPassword)) {
    DEBUG ((DEBUG_INFO, "[-] ChangeKey : Access Denied."));
    *CommBufferSize = -1;
    return EFI_SUCCESS;
    }
  len = AsciiStrLen(Request->NewKey);
  if (len >= 0x100) {
    DEBUG ((DEBUG_INFO, "[-] ChangeKey : New key is too long."));
    *CommBufferSize = -1;
    return EFI_SUCCESS;
  }

  CopyMem(PrivateKey, Request->NewKey, len);
  DEBUG ((DEBUG_INFO, "Successfully changed stored Key to %a", PrivateKey));

  return EFI_SUCCESS;
}


EFI_STATUS
ChangePassword(IN OUT VOID *CommBuffer, IN OUT UINT64 *CommBufferSize) {
  User_Request *Request = (User_Request *)CommBuffer;
  UINTN len = 0;

  if (AsciiStrCmp(Request->Password, RecoveryPassword)) {
    DEBUG ((DEBUG_INFO, "[-] ChangePassword : Access Denied."));
    *CommBufferSize = -1;
    return EFI_SUCCESS;
    }
  len = AsciiStrLen(Request->NewPassword);
  if (len >= 0x100) {
    *CommBufferSize = -1;
    return EFI_SUCCESS;
  }
  CopyMem(RecoveryPassword, Request->NewPassword, len);

  return EFI_SUCCESS;
}


EFI_STATUS (*MethodFunc[])(IN OUT VOID *CommBuffer, IN OUT UINT64 *CommBufferSize) = { RecoverKey, ChangeKey, ChangePassword };

EFI_STATUS
EFIAPI
KeyRecoveryHandler(IN EFI_HANDLE DispatchHandle,
                   IN CONST VOID *Context OPTIONAL,
                   IN OUT VOID *CommBuffer OPTIONAL,
                   IN OUT UINT64 *CommBufferSize OPTIONAL) {

  User_Request *Request = (User_Request *)CommBuffer;


  if (!SmmIsBufferOutsideSmmValid((UINTN)CommBuffer, *CommBufferSize)) {
    DEBUG((DEBUG_INFO, "What are you trying to do...\n"));
    *CommBufferSize = -1;
    return EFI_SUCCESS;
  }

  DEBUG ((DEBUG_INFO, "Buffer Size : %d\n", *CommBufferSize));
  DEBUG ((DEBUG_INFO, "Buffer content : %a\n", CommBuffer));

  if (AsciiStrLen(Request->Password) >= 0x100) {
    DEBUG((DEBUG_INFO, "Maximum password length is 0x100.\n"));
    return EFI_SUCCESS;
  }

  DEBUG ((DEBUG_INFO, "Method requested : %d\n", (Request->Method)));
  DEBUG ((DEBUG_INFO, "Password given : %a\n", Request->Password));
  DEBUG ((DEBUG_INFO, "NUMBER OF METHODS : %d\n",sizeof(MethodFunc) / 0x8));

  if(Request->Method >= sizeof(MethodFunc) / 0x8 ) {
    DEBUG ((DEBUG_ERROR, "[-] ERROR : Requested Method '%x' isn't implemented yet.", Request->Method));
      *CommBufferSize = -1;
      return EFI_SUCCESS;
  }

  DEBUG ((DEBUG_INFO, "[+] Calling method %d ... \n", Request->Method));

  MethodFunc[Request->Method](CommBuffer, CommBufferSize);

  return EFI_SUCCESS;
}

EFI_STATUS
EFIAPI
InitKeyRecovery(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE *SystemTable) {
  EFI_STATUS Status;
  EFI_HANDLE DispatchHandle;

  ASSERT(FeaturePcdGet(PcdSmmSmramRequire));
  Status = gSmst->SmiHandlerRegister(KeyRecoveryHandler,
                                     &gEfiSmmHiddenKeyRecoveryProtocolGuid,
                                     &DispatchHandle);

  DEBUG((DEBUG_INFO, "FLAG : %a\n", RecoveryPassword));

  if (EFI_ERROR(Status)) {
    DEBUG((DEBUG_ERROR, "Error : Skill issue\n"));
  } else {
    DEBUG((DEBUG_INFO, "KeyRecovery protocol installed.\n"));
  }

  return Status;
}
