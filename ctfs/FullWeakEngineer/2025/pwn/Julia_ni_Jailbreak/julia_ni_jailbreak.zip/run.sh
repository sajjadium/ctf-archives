#!/bin/sh
/usr/local/julia/bin/julia jail.jl