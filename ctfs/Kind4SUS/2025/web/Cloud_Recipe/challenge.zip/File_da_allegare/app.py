import os
import re
import secrets
import sqlite3
from flask import (
    Flask, render_template, request, redirect, url_for,
    session, send_from_directory, make_response
)
from flask_talisman import Talisman
from playwright.sync_api import sync_playwright


app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", secrets.token_hex(16))


BOT_TOKEN = os.environ.get("BOT_TOKEN", "...")
SECRET_FLAG = os.environ.get("SECRET_FLAG", "KSUS{FAKE_FLAG}")


app.config['MAX_CONTENT_LENGTH'] = 40 * 1024  
app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}


DATABASE = 'database.db'


csp = {
    'script-src': '',    
    'style-src': ["'self'"],       
    'default-src': ['*']
}

Talisman(app,
         force_https=False,
         session_cookie_secure=False,
         content_security_policy=csp,
         content_security_policy_nonce_in=['script-src', 'style-src']
)


def allowed_file(filename: str) -> bool:
    if not isinstance(filename, str) or not filename.strip():
        return False  
    
    filename = filename.strip()
    
    if '.' not in filename or filename.startswith('.'):
        return False  
    
    ext = os.path.splitext(filename)[-1].lower().lstrip('.')  
    
    return ext in ALLOWED_EXTENSIONS

def secure_filename(filename: str, max_length: int = 40) -> str:
    if not isinstance(filename, str) or not filename.strip():
        return "unnamed_file"

    filename = os.path.basename(filename).strip()
    filename = filename.replace(' ', '_')
    filename = re.sub(r'[^A-Za-z0-9_.-]', '', filename)

    if filename in {"", ".", ".."}:
        return "unnamed_file"

    return filename[:max_length]

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = sqlite3.connect(DATABASE)
    cur = conn.cursor()
   
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            photo TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS sent_recipes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            recipe_id INTEGER NOT NULL,
            sender_id INTEGER NOT NULL,
            FOREIGN KEY (recipe_id) REFERENCES recipes(id),
            FOREIGN KEY (sender_id) REFERENCES users(id)
        )
    ''')
    conn.commit()
    conn.close()

    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

def admin_bot_visit(recipe_id):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) CTF-Admin-Agent"
        )
        
        context.add_cookies([{
            "name": "flag",
            "value": SECRET_FLAG,
            "domain": "127.0.0.1",
            "path": "/",
            "httpOnly": False
        }])
        
        context.set_extra_http_headers({"X-Bot-Token": BOT_TOKEN})

        page = context.new_page()
        url = f"http://127.0.0.1:5000/admin/recipe/{recipe_id}"
        page.goto(url)
        page.wait_for_load_state("networkidle")
        browser.close()


@app.route('/')
def home():
    return render_template('home.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user_id' in session:
        return redirect(url_for('recipes'))
        
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()
        if user and user['password'] == password:
            session['user_id'] = user['id']
            session['username'] = user['username']
            return make_response(redirect(url_for('recipes')))
        else:
            error = 'Invalid credentials, please try again.'
    return render_template('login.html', error=error)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if 'user_id' in session:
        return redirect(url_for('recipes'))
        
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        if not username or not password or not confirm_password:
            error = 'All fields are required.'
        elif password != confirm_password:
            error = 'Passwords do not match.'
        else:
            conn = get_db_connection()
            existing_user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
            if existing_user:
                error = 'Username already exists.'
            else:
                cur = conn.cursor()
                cur.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, password))
                conn.commit()
                user_id = cur.lastrowid
                session['user_id'] = user_id
                session['username'] = username
                conn.close()
                return make_response(redirect(url_for('recipes')))
            conn.close()
    return render_template('register.html', error=error)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/recipes')
def recipes():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    user_recipes = conn.execute(
        'SELECT * FROM recipes WHERE user_id = ?',
        (session['user_id'],)
    ).fetchall()
    conn.close()
    return render_template('recipes.html', recipes=user_recipes)

@app.route('/create_recipe', methods=['GET', 'POST'])
def create_recipe():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    error = None
    if request.method == 'POST':
        title = request.form.get('title')
        description = request.form.get('description')
        photo = request.files.get('photo')
        photo_filename = None

        if not title or not description:
            error = 'Title and description are required.'
        else:
            if photo and photo.filename != '':
                if allowed_file(photo.filename):
                    original_filename = secure_filename(photo.filename)
                    random_prefix = secrets.token_hex(8)
                    filename = f"{random_prefix}_{original_filename}"
                    photo.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                    photo_filename = filename
                else:
                    error = 'File type not allowed. Use png, jpg, jpeg, or gif.'
        if not error:
            conn = get_db_connection()
            conn.execute(
                'INSERT INTO recipes (user_id, title, description, photo) VALUES (?, ?, ?, ?)',
                (session['user_id'], title, description, photo_filename)
            )
            conn.commit()
            conn.close()
            return redirect(url_for('recipes'))
    return render_template('create_recipe.html', error=error)

@app.route('/recipe/<int:recipe_id>')
def recipe(recipe_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    conn = get_db_connection()
    recipe = conn.execute(
        'SELECT * FROM recipes WHERE id = ? AND user_id = ?',
        (recipe_id, session['user_id'])
    ).fetchone()
    conn.close()
    if recipe is None:
        return "Recipe not found", 404
    return render_template('recipe.html', recipe=recipe)

@app.route('/admin/recipe/<int:recipe_id>')
def admin_recipe(recipe_id):
    token = request.headers.get("X-Bot-Token", "")
    if token != BOT_TOKEN:
        return "Access denied!", 403

    conn = get_db_connection()
    recipe = conn.execute('SELECT * FROM recipes WHERE id = ?', (recipe_id,)).fetchone()
    conn.close()
    if recipe is None:
        return "Recipe not found", 404

    return render_template('recipe.html', recipe=recipe)

@app.route('/send_recipe', methods=['GET', 'POST'])
def send_recipe():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    message = None
    error = None

    if request.method == 'POST':
        recipe_id = request.form.get('recipe_id')
        if recipe_id and recipe_id.isdigit():
            conn = get_db_connection()
            recipe = conn.execute(
                'SELECT * FROM recipes WHERE id = ? AND user_id = ?',
                (recipe_id, session['user_id'])
            ).fetchone()
            conn.close()

            if recipe is None:
                error = "Recipe not found"
            else:
                admin_bot_visit(recipe_id)
                message = "The admin has viewed your recipe 😋"
        else:
            error = "Please enter a valid number for the recipe ID."
    
    return render_template('send_recipe.html', message=message, error=error)

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', debug=False)
