document.addEventListener('DOMContentLoaded', function () {
  
  const images = document.querySelectorAll('.content img');

  images.forEach(img => {
    img.style.cursor = 'pointer';

    img.addEventListener('click', function () {
      
      const rect = img.getBoundingClientRect();

      
      const clonedImg = img.cloneNode();
      clonedImg.style.position = 'fixed';
      clonedImg.style.top = rect.top + 'px';
      clonedImg.style.left = rect.left + 'px';
      clonedImg.style.width = rect.width + 'px';
      clonedImg.style.height = rect.height + 'px';
      clonedImg.style.transition = 'all 0.5s ease';
      clonedImg.style.zIndex = '1001';

      
      const overlay = document.createElement('div');
      overlay.style.position = 'fixed';
      overlay.style.top = '0';
      overlay.style.left = '0';
      overlay.style.width = '100vw';
      overlay.style.height = '100vh';
      overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
      overlay.style.opacity = '0';
      overlay.style.transition = 'opacity 0.5s ease';
      overlay.style.zIndex = '1000';

      
      document.body.appendChild(overlay);
      
      document.body.appendChild(clonedImg);

      
      void clonedImg.offsetWidth;
      void overlay.offsetWidth;

      
      clonedImg.style.top = '50%';
      clonedImg.style.left = '50%';
      clonedImg.style.transform = 'translate(-50%, -50%) scale(1.5)';
      overlay.style.opacity = '1';

      
      function closeZoom() {
        
        clonedImg.style.top = rect.top + 'px';
        clonedImg.style.left = rect.left + 'px';
        clonedImg.style.transform = 'none';
        overlay.style.opacity = '0';

        
        clonedImg.addEventListener('transitionend', function handler() {
          clonedImg.removeEventListener('transitionend', handler);
          if (clonedImg.parentElement) {
            clonedImg.parentElement.removeChild(clonedImg);
          }
        });
        overlay.addEventListener('transitionend', function handler() {
          overlay.removeEventListener('transitionend', handler);
          if (overlay.parentElement) {
            overlay.parentElement.removeChild(overlay);
          }
        });
      }

      
      overlay.addEventListener('click', closeZoom);
      clonedImg.addEventListener('click', closeZoom);
    });
  });
});
