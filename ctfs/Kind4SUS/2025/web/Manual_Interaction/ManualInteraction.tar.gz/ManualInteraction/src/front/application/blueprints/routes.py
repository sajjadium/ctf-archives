import uuid
from flask import request, session, render_template, redirect, Blueprint, session, make_response
from application.util.curl import get_url_status_code
from application.util.grpc_utils.grpc_helper import InteractionClient

web = Blueprint("web", __name__)
client = InteractionClient()
@web.route("/", methods=["GET"])
def index():
	if session and session["loggedin"]:
		try:
			items = client.getItems(session["id"]).items
			return render_template("home.html", title="List", items=items, session=session)
		except Exception:
				return render_template("home.html")

	return render_template("home.html")

@web.route("/signup", methods=["GET"])
def signup():
	if session and session["loggedin"]:
		return redirect("/")

	id = str(uuid.uuid4())
	try:
		response = client.createAccount(id)
		if response and response.response == "GOOD":
			session["loggedin"] = True
			session["id"] = id
		return redirect("/")
	except Exception as e:
		return redirect("/")


@web.route("/api-health", methods=["POST"])
def api_health():
	if not session.get("loggedin"):
		return redirect("/")

	url = request.form.get("url")

	if not url:
		return make_response("<h1>Missing url</h1>", 400)

	status_code = get_url_status_code(url)
	return render_template("api-health.html", statuscode=status_code)

@web.route("/logout", methods=["GET"])
def logout():
	session.clear()
	return redirect("/")
