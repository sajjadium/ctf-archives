from application.app import app
import sqlite3


# First init

items = [
    (1, "Pen", "A ballpoint pen for writing."),
    (2, "Notebook", "A spiral-bound notebook."),
    (3, "Mug", "A ceramic coffee mug."),
    (4, "Keys", "A set of house and car keys."),
    (5, "Phone", "A smartphone.")
]
database = sqlite3.connect("/app/db.sqlite3")
cur = database.cursor()
cur.execute("CREATE TABLE flag(flag)")
cur.execute("INSERT INTO flag VALUES(?)", (app.config["FLAG"],))

cur.execute("CREATE TABLE account(id UNIQUE, filter)")

cur.execute("CREATE TABLE items(id, name, description)")
cur.executemany("INSERT INTO items VALUES (?, ?, ?)", items)
cur.close()
database.commit()
database.close()




if __name__ == "__main__":
    app.run(host="0.0.0.0", port=1337, threaded=True, debug=False)
