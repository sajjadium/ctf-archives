import os

class Config(object):
	SECRET_KEY = os.urandom(50).hex()
	FLAG = os.getenv("FLAG")

class ProductionConfig(Config):
	pass

class DevelopmentConfig(Config):
	DEBUG = False

class TestingConfig(Config):
	TESTING = False