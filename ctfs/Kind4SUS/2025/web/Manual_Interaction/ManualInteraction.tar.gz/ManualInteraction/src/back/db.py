import sqlite3

def execute_query(function):
    db = sqlite3.connect("/app/db.sqlite3")
    cur = db.cursor()
    try:
        result = function(cur)
    except sqlite3.Error as err:
        print(f"Sql Error: {err}")
        result = None
    except Exception:
        result = None
    cur.close()
    db.commit()
    db.close()
    return result