import interaction_pb2, interaction_pb2_grpc, grpc
from db import execute_query
from concurrent import futures

class InteractionService(interaction_pb2_grpc.InteractionServiceServicer):
	
    def GetItems(self, request, _):
        items = execute_query(
            lambda cur: 
                (
                    filter := cur.execute("SELECT filter FROM account WHERE id = ?", (request.id,)).fetchone()[0],
                    cur.execute("SELECT id, name, description FROM items " + filter).fetchall()
                )[1]
        )
        items = map(lambda item: interaction_pb2.Item(id=item[0], name=item[1], description=item[2]), items)
        return interaction_pb2.ItemList(items=items)
        

    def SetFilterDebug(self, request, _):
        execute_query(lambda cur: 
            cur.execute("UPDATE account SET filter = ? WHERE id = ?", (request.filter, request.account.id))
        )
        return interaction_pb2.Empty()
    

    def CreateAccount(self, request, _):
        result = execute_query(lambda cur:
            cur.execute("INSERT INTO account VALUES (?, ?)", (request.account.id, request.filter))
        )
        
        return interaction_pb2.ResponseString(response = "GOOD" if result != None else "NOT GOOD")

def start():
	server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
	interaction_pb2_grpc.add_InteractionServiceServicer_to_server(InteractionService(), server)
	server.add_insecure_port("[::]:50051")
	server.start()
	server.wait_for_termination()

if __name__ == "__main__":
	start()
