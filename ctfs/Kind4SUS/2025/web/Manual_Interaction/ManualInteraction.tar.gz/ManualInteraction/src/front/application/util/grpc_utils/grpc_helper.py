import grpc
import application.util.grpc_utils.interaction_pb2 as interaction_pb2
import application.util.grpc_utils.interaction_pb2_grpc as interaction_pb2_grpc

class InteractionClient:
	def __init__(self, host="127.0.0.1", port=50051):
		self.channel = grpc.insecure_channel(f"{host}:{port}")
		self.stub = interaction_pb2_grpc.InteractionServiceStub(self.channel)

	def getItems(self, accountId):
		response = self.stub.GetItems(interaction_pb2.Account(id=accountId))
		return response
		
	def createAccount(self, accountId):
		response = self.stub.CreateAccount(interaction_pb2.AccountValue(
			account = interaction_pb2.Account(id = accountId),
			filter = "LIMIT 2"
		))

		return response