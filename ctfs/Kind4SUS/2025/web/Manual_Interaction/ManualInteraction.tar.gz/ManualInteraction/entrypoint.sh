#!/bin/sh

# Secure entrypoint
chmod 600 /entrypoint.sh

# Launch supervisord
/usr/bin/supervisord -n -c /etc/supervisord.conf
