from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from flag import flag
from Crypto.Util.number import bytes_to_long

with open("id_original_rsa", "rb") as key_file:
    private_key = serialization.load_ssh_private_key(key_file.read(), password=None, backend=default_backend())


d = private_key.private_numbers().d
p = private_key.private_numbers().p
q = private_key.private_numbers().q
e = private_key.private_numbers().public_numbers.e

# write above to log
with open("log.txt", "w") as f:
    # should be 1?
    f.write(f"check:{d * e // ((p - 1) * (q - 1))}")


with open("id_original_rsa.pub", "rb") as key_file:
    public_key = serialization.load_ssh_public_key(key_file.read(), backend=default_backend())

e = public_key.public_numbers().e
n = public_key.public_numbers().n

# ecrypt flag
c = pow(bytes_to_long(flag), e, n)

with open("log.txt", "a") as f:
    f.write(f"\ncipher_txt:{c}")
