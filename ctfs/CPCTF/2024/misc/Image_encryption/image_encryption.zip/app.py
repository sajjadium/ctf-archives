from fastapi import FastAPI, UploadFile
from fastapi.responses import Response
import uvicorn
import numpy as np
import random
from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
import io
import os
import dotenv
import zipfile

app = FastAPI()

imgs = ["903328ilsdl.jpg", "903344ilsdl.jpg","903346ilsdl.jpg","903348ilsdl.jpg"]

# Load the .env file
dotenv.load_dotenv()

def crop_center(pil_img, crop_width, crop_height):
    img_width, img_height = pil_img.size
    return pil_img.crop(((img_width - crop_width) // 2,
                         (img_height - crop_height) // 2,
                         (img_width + crop_width) // 2,
                         (img_height + crop_height) // 2))

def enc(img, m, height, width):
    img = np.array(img)
    blank = np.zeros((height, width, 3))
    for h in range(height):
        for w in range(width):
            l=((m@np.array([h+1,w+1]).T).T)
            blank[h][w]=img[l[0]%height][l[1]%width]
    return Image.fromarray(blank.astype(np.uint8))

def LsbXor(bg_img,img,width,height):
    img = np.array(img)
    bg_img = np.array(bg_img)
    for h in range(height):
        for w in range(width):
            for c in range(3):
                bg_img[h][w][c] = bg_img[h][w][c] ^ (img[h][w][c] & 63)
    return Image.fromarray(bg_img)

@app.post("/upload")
async def upload_image(image: UploadFile):
    up_img = Image.open(image.file)
    img = random.choice(imgs)
    bg_im = Image.open("img/"+img)
    crop_center(bg_im, 1800,1340)
    fx = 0.25
    bg_im = bg_im.resize((round(bg_im.width * fx), round(bg_im.height * fx)))
    width, height = bg_im.size
    up_width, up_height = up_img.size
    if up_width<width or up_height<height:
        return Response(content="Image too small", media_type="text/plain", status_code=400)
    if up_width>width or up_height>height:
        up_img = up_img.crop((0,0,width,height))
    up_width, up_height = up_img.size
    flag=os.getenv("FLAG")
    font_path = ("Roboto/Roboto-Medium.ttf")
    font_size = height//20
    font_color = (0,0,0)
    img = Image.new("RGB", (width, height), (255,255,255))
    draw = ImageDraw.Draw(img)
    font = ImageFont.truetype(font_path, font_size)
    textWidth, textHeight = draw.textlength(flag, font=font), font_size
    textTopLeft = (width//6, height//2-textHeight//2)
    draw.text(textTopLeft, flag, fill=font_color, font=font)
    phi = random.randint(1,20)
    ep = random.randint(1,20)
    m=np.array([[1,ep],[phi,ep*phi+1]])
    flag_enc = enc(img,m,height,width)
    up_img_enc = enc(up_img,m,up_height,up_width)

    return_flag_img = LsbXor(bg_im, flag_enc, min(width, up_width), min(height, up_height))
    return_up_img = LsbXor(return_flag_img, up_img_enc, min(width, up_width), min(height, up_height))
    #convert img to png bytes
    img_flag_bytes = io.BytesIO()
    return_flag_img.save(img_flag_bytes, format='PNG')
    img_flag_bytes = img_flag_bytes.getvalue()
    img_up_bytes = io.BytesIO()
    return_up_img.save(img_up_bytes, format='PNG')
    img_up_bytes = img_up_bytes.getvalue()
    # create a zip of these images
    zipped_images = io.BytesIO()
    with zipfile.ZipFile(zipped_images, "w") as myzip:
        myzip.writestr("flag_image.png", img_flag_bytes)
        myzip.writestr("uploaded_image.png", img_up_bytes)

    #return zip
    return Response(content=zipped_images.getvalue(), media_type="application/zip")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)