import { serveFile } from "jsr:@std/http@1.0.14";

const decoder = new TextDecoder();
const encoder = new TextEncoder();

Deno.serve(async (req) => {
  const pathname = new URL(req.url).pathname;

  if (pathname === "/") {
    return serveFile(req, "./index.html");
  }

  if (pathname === "/execute") {
    if (!req.body) {
      return new Response("Please provide a body", { status: 400 });
    }

    const json = await req.json();
    await using process = new Deno.Command(Deno.execPath(), {
      args: [
        "run",
        "--allow-read",
        "-",
      ],
      env: {
        "NO_COLOR": "1",
      },
      stderr: "piped",
      stdin: "piped",
      stdout: "piped",
    }).spawn();
    let status = 200;
    let error: string | undefined = undefined;
    const timeoutID = setTimeout(() => {
      status = 408;
      error = "Script execution timed out";

      process.kill();
    }, 1000);

    const writer = process.stdin.getWriter();

    await writer.ready;
    writer.write(encoder.encode(json.script));
    await writer.close();

    const cmdOutput = await process.output();

    clearTimeout(timeoutID);

    let output: string | undefined = undefined;

    // タイムアウトしていない場合
    if (!error) {
      output = decoder.decode(cmdOutput.stdout);
      error = decoder.decode(cmdOutput.stderr);

      if (error) {
        status = 400;
      }
    }

    return new Response(JSON.stringify({ output, error }), { status });
  }

  return new Response("Not found", { status: 404 });
});
