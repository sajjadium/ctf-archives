from secrets import randbelow

m = 80701148760020250419  # prime
a = 20250418
b = 240240240240

MAX_N = 10**5
MAX_Q = 100


class myRand:
    def __init__(self):
        self.v = randbelow(m)

    def random(self):
        self.v = (a*self.v+b) % m
        return self.v


def genCase(h, w, rd):
    A = [[rd.random() % MAX_N+1 for _ in range(w)] for _ in range(h)]
    A[rd.random() % h][rd.random() % w] = 0
    return (A, h, w)


def judge(case):
    A, H, W = case
    cnt = 0
    x, y = 0, 0
    print(f"{H} {W}")
    while cnt < MAX_Q:
        cnt += 1
        op = input()
        if op == '>':
            y += 1
        elif op == '<':
            y -= 1
        elif op == '^':
            x -= 1
        elif op == 'v':
            x += 1
        else:
            print("Invalid Input")
            return False
        if x >= 0 and x < H and y >= 0 and y < W:
            print(A[x][y])
            if A[x][y] == 0:
                return True
        else:
            print("Out of Stage")
            return False
    print("Query Over")
    return False


def main():
    r = myRand()
    caseHW = [(5, 5), (10, 10), (50, 50), (50, 50), (50, 50),
              (50, 50), (50, 50), (50, 50), (50, 50), (50, 50), (50, 50)]
    for i in range(len(caseHW)):
        h, w = caseHW[i]
        case = genCase(h, w, r)
        if not judge(case):
            print(f"WA on Case {i}")
            exit(0)
    print("AC!")
    with open("flag.txt") as f:
        print(f.read())
    exit(0)


if __name__ == '__main__':
    try:
        main()
    except:
        print("Judge Error")
        exit()
