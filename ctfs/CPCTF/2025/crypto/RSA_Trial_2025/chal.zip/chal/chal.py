from Crypto.Util.number import getPrime, bytes_to_long
from sympy import nextprime
from secret import flag

p = getPrime(512)
q = getPrime(512)
r = nextprime(p + q)

n = p * q * r
hint = p**3 + q**3 + r**3
e = 0x10001
c = pow(bytes_to_long(flag.encode()), e, n)

with open("output.py", "w") as f:
    f.write(f"e = {e}\n")
    f.write(f"n = {n}\n")
    f.write(f"c = {c}\n")
    f.write(f"hint = {hint}\n")