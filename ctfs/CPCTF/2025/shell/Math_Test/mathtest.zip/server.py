import socket
import random
import threading

# 設定
HOST = '0.0.0.0'
PORT = 3000

# クライアントごとの処理を担当する関数
def handle_client(conn, addr):
    print(f"[接続開始] {addr} が接続しました。")
    with conn:
        try:
            ac = 0
            while True:
                # 1. 問題を作成
                num1 = random.randint(1, 9999)
                num2 = random.randint(1, 9999)
                correct_answer = num1 + num2
                question = f"{num1} + {num2} = ?\n"

                # 2. 問題をクライアントに送信 (UTF-8でエンコード)
                conn.sendall(question.encode('utf-8'))

                # 3. クライアントからの回答を受信 (1024バイトまで)
                #    改行コード(¥n)まで読み取ることを想定
                data_bytes = b""
                while True:
                    chunk = conn.recv(1024)
                    if not chunk: # クライアントが接続を切断した場合
                        print(f"[接続終了] {addr} が切断しました。(データ受信中)")
                        return # このクライアントの処理を終了
                    data_bytes += chunk
                    # バイト列の中に改行コード(¥n)を示すバイト(0x0a)が含まれていたらループを抜ける
                    if b'\n' in data_bytes:
                        break

                # 受信したデータをデコードし、前後の空白や改行を除去
                client_answer_str = data_bytes.decode('utf-8').strip()
                print(f"[{addr}] 受信: {client_answer_str}")

                # 4. 正誤判定
                try:
                    client_answer_int = int(client_answer_str)
                    if client_answer_int == correct_answer:
                        ac+=1
                        if ac > 1000:
                            conn.sendall(b"Congratulations! The flag is: CPCTF{dummy_flag}")
                            break
                    else:
                        conn.sendall(b"wrong...\n")
                        break
                except Exception as e:
                    # その他の予期せぬエラー
                    print(f"[エラー] {addr}: {e}")
                    conn.sendall(b"sorry, error...\n")
                    break

        except ConnectionResetError:
            print(f"[接続エラー] {addr} との接続がリセットされました。")
        except BrokenPipeError:
            print(f"[接続エラー] {addr} との接続が壊れました。")
        except Exception as e:
            print(f"[予期せぬエラー] {addr}: {e}")
        finally:
            print(f"[接続終了] {addr} が切断しました。")

# サーバーのメイン処理
def start_server():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((HOST, PORT))

        server_socket.listen(99)
        print(f"サーバーが起動しました。{HOST}:{PORT} で接続を待っています...")

        try:
            while True:
                client_socket, client_address = server_socket.accept()
                thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
                thread.daemon = True
                thread.start()
        except KeyboardInterrupt:
            print("\nサーバーをシャットダウンします...")
        finally:
            print("サーバーソケットを閉じます。")

if __name__ == "__main__":
    start_server()