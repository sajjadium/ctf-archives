#include <stdio.h>

void init() 
{
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
}

int main()
{
    char input[0x20];
    
    init();

    printf("Hi! I'm an AI agent. What can I do for you?\n");
    printf("Input task: ");
    fgets(input, 0x100, stdin);
    printf("Sorry, I can't do that. Bye!\n");

    return 0;
}