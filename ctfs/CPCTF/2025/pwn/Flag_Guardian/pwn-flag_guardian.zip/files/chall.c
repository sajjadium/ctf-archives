#include <stdio.h>

void init()
{
    setbuf(stdout, NULL); 
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
}

int main()
{
    char input[0x20];
    char flag[0x20];
    FILE *fp;

    init();

    fp = fopen("flag.txt", "r");
    fgets(flag, sizeof(flag), fp);
    fclose(fp);

    printf("Do you want to see the flag? (yes/no) ");
    fgets(input, sizeof(input), stdin);

    printf("You entered: ");
    printf(input);
    printf("\n");
    if (input[0] == 'y' && input[1] == 'e' && input[2] == 's')
    {
        printf("I can't show whole flag, but here is a part of it: \n");
        printf(flag + 0x18); 
        printf("\n");
    }
    else
    {
        printf("Bye!\n");
    }

    return 0;
}