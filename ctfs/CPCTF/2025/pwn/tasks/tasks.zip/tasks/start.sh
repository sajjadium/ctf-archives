#!/bin/bash

cd /home/user
timeout --foreground 60s ./tasks