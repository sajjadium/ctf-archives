#include<stdio.h>
#include<stdlib.h>

void init(){
	setbuf(stdout, NULL);
	setbuf(stdin, NULL);
	setbuf(stderr, NULL);
}

int main(){
	init();

	int hexint, strint, flint;

	puts("hexint");
	scanf("%x", &hexint);
	puts("strint");
	scanf("%4s", &strint);
	puts("flint");
	scanf("%f", &flint);

	if(hexint == 233577965 && strint == 860037486 && flint == 1078530008){
		puts("Correct!");
		system("cat flag.txt");
	}else{
		puts("Wrong...");
		printf("hexint: %d\n", hexint);
		printf("strint: %d\n", strint);
		printf("flint: %d\n", flint);
	}

	return 0;
}
