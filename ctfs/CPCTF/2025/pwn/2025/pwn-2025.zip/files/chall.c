#include <stdio.h>

int main() 
{
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);

    unsigned int a, b;
    printf("Happy New Year 2025!\n");
    printf("Enter two numbers.\n");
    printf("No.1: ");
    scanf("%u", &a);
    printf("No.2: ");
    scanf("%u", &b);

    if (2025 % a == 0 && 2025 % b == 0) 
    {
        printf("Failed.\n");
        return 0;
    } 

    unsigned int c = a * b;

    if (c == 2025)
    {
        printf("Congratulations!\n");
        system("cat flag.txt");
    }
    else 
    {
        printf("Failed.\n");
    }

    return 0;
}