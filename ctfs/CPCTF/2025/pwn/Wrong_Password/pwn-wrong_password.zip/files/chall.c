#include <stdio.h>

void init()
{
    setbuf(stdout, NULL);
    setbuf(stdin, NULL);
    setbuf(stderr, NULL);
}

void win()
{
    printf("You win!\n");

    FILE *fp;
    char flag[100];

    fp = fopen("flag.txt", "r");
    fread(flag, sizeof(char), 100, fp);
    printf("Flag: %s\n", flag);
    fclose(fp);
}

int main()
{
    init();

    char password[16];

    printf("Enter Password: ");
    scanf("%s", password);

    printf("Wrong!\n");
    return 0;
}