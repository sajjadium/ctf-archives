    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> ROIS Blog. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

