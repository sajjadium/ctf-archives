to call the bot use:

echo "http://url" | nc localhost 55555