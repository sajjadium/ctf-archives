use num_bigint::BigUint;
use plonkish_backend::{
    halo2_curves::bn256::{Bn256, Fr},
    pcs::{multilinear::Gemini, univariate::UnivariateKzg, PolynomialCommitmentScheme},
    poly::multilinear::MultilinearPolynomial,
    util::{
        arithmetic::{modulus, Field, PrimeField},
        transcript::{
            FieldTranscript, FieldTranscriptRead, FieldTranscriptWrite, InMemoryTranscript,
            Keccak256Transcript,
        },
    },
    Error as PlonkishError,
};
use rand::{rngs::OsRng, RngCore};
use std::io::{self, Write};
use bincode::{serialize, deserialize};
use base64;


type Transcript = Keccak256Transcript<std::io::Cursor<Vec<u8>>>;
type Pcs = Gemini<UnivariateKzg<Bn256>>;
type Commitment = <Pcs as PolynomialCommitmentScheme<Fr>>::Commitment;
type CommitmentChunk = <Pcs as PolynomialCommitmentScheme<Fr>>::CommitmentChunk;
type UniKzg = UnivariateKzg<Bn256>;

// #[allow(dead_code)]
#[derive(Clone, Debug)]
struct Challenge {
    point: Vec<Fr>,
    target_value: Fr,
}


struct Verifier {
    vp: <Pcs as PolynomialCommitmentScheme<Fr>>::VerifierParam,
}

impl Verifier {
    fn new(vp: <Pcs as PolynomialCommitmentScheme<Fr>>::VerifierParam) -> Self {
        Self { vp }
    }

    fn issue_challenge(&self, num_vars: usize, rng: &mut impl RngCore) -> Challenge {
        let mut point = Vec::with_capacity(num_vars);
        for _ in 0..num_vars {
            point.push(Fr::random(&mut *rng));
        }
        let target_value = Fr::random(&mut *rng);
        Challenge {
            point,
            target_value,
        }
    }

    fn verify(
        &self,
        encoded_commitment: &Vec<u8>,
        challenge: &Challenge,
        encoded_proof: &Vec<u8>,
    ) -> Result<(), PlonkishError> {
        let commitment = Pcs::read_commitment(&self.vp, &mut Transcript::from_proof((), encoded_commitment.as_slice()))?;
        let mut transcript = Transcript::from_proof((), encoded_proof.as_slice());

        Pcs::verify(
            &self.vp,
            &commitment,
            &challenge.point,
            &challenge.target_value,
            &mut transcript,
        )
    }
}


fn fr_to_decimal(fr: &Fr) -> String {
    let repr = fr.to_repr();
    BigUint::from_bytes_le(repr.as_ref()).to_string()
}

fn format_challenge(challenge: &Challenge) -> String {
    let point = challenge
        .point
        .iter()
        .map(fr_to_decimal)
        .collect::<Vec<_>>()
        .join(",");
    let target_value = fr_to_decimal(&challenge.target_value);
    format!("{},{}", point, target_value)
}

fn prompt_line(prompt: &str) -> Result<String, PlonkishError> {
    print!("{}", prompt);
    io::stdout()
        .flush()
        .map_err(|err| PlonkishError::InvalidPcsOpen(err.to_string()))?;
    let mut input = String::new();
    io::stdin()
        .read_line(&mut input)
        .map_err(|err| PlonkishError::InvalidPcsOpen(err.to_string()))?;
    let trimmed = input.trim();
    if trimmed.is_empty() {
        return Err(PlonkishError::InvalidPcsOpen(
            "Received empty input from prover".to_string(),
        ));
    }
    Ok(trimmed.to_string())
}

fn read_hex_line(prompt: &str) -> Result<Vec<u8>, PlonkishError> {
    let line = prompt_line(prompt)?;
    hex::decode(&line)
        .map_err(|err| PlonkishError::InvalidPcsOpen(format!("Invalid hex input: {}", err)))
}

fn win() {
    if let Ok(flag) = std::env::var("FLAG") {
        println!("{}", flag);
    } else {
        println!("WIN");
    }
}

fn main() -> Result<(), PlonkishError> {
    let num_vars = 3usize;
    let poly_size = 1 << num_vars;
    let mut rng = OsRng;

    let param = Pcs::setup(poly_size, 1, &mut rng)?;
    let (pp, vp) = Pcs::trim(&param, poly_size, 1)?;


    let serialized_pp = serialize(&pp).unwrap();
    println!(
        "Serialized prover parameters (base64): {}",
        base64::encode(&serialized_pp)
    );

     let verifier = Verifier::new(vp);

    let commitment_bytes = read_hex_line("Send commitment (hex): ")?;

    let challenge = verifier.issue_challenge(num_vars, &mut rng);
    println!("Challenge: {}", format_challenge(&challenge));

    let proof_bytes = read_hex_line("Send proof (hex): ")?;
    let result = verifier.verify(&commitment_bytes, &challenge, &proof_bytes);
    match result {
        Ok(()) => win(),
        Err(err) => {
            println!("Your proof did not verify :(");
        }
    }


    Ok(())
}
