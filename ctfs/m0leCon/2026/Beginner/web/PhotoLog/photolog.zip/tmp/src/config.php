<?php
// Database configuration
define('DB_HOST', getenv('DB_HOST') ?: 'mysql');
define('DB_NAME', getenv('DB_NAME') ?: 'photolog');
define('DB_USER', getenv('DB_USER') ?: 'photolog');
define('DB_PASS', getenv('DB_PASS') ?: 'photolog');

// Site configuration
define('SITE_NAME', 'PhotoLog');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 3 * 1024 * 1024); // 3MB
define('ALLOWED_TYPES', ['image/jpeg', 'image/png', 'image/gif']);

// Session configuration
ini_set('session.cookie_httponly', 1);
session_start();
