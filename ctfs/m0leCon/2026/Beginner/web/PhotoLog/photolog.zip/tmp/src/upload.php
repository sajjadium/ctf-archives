<?php
require_once 'database.php';
requireLogin();

$user = getCurrentUser();
$db = getDB();

$success = false;
$error = false;

// Handle photo upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (isset($_FILES['photo']) || !empty($_POST['photo_url']))) {
    $caption = trim($_POST['caption'] ?? '');
    $isPrivate = isset($_POST['is_private']) ? 1 : 0;
    $photoUrl = trim($_POST['photo_url'] ?? '');

    if (!empty($photoUrl)) {
        if (!filter_var($photoUrl, FILTER_VALIDATE_URL)) {
            $error = 'Invalid URL provided!';
        } else {
            $urlParts = parse_url($photoUrl);
            $host = $urlParts['host'] ?? '';

            if (empty($host)) {
                $error = 'Invalid URL: no host found!';
            } else {
                // Make sure no requests to our service from localhost is made

                $ip = gethostbyname($host);

                if ($ip === $host && !filter_var($ip, FILTER_VALIDATE_IP)) {
                    $error = 'Could not resolve hostname!';
                }
                elseif ($ip === '127.0.0.1' || $ip === '::1') {
                    $error = 'Access to localhost is not allowed!';
                }
                elseif (
                    filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false
                ) {
                    $error = 'Access to private/reserved IP addresses is not allowed!';
                }
                elseif (strpos($ip, '169.254.') === 0) {
                    $error = 'Access to link-local addresses is not allowed!';
                } else {
                    try {
                        $imageData = @file_get_contents($photoUrl);

                        if ($imageData === false) {
                            $error = 'Failed to download image from URL. Please check the URL is correct.';
                        } else {
                            // Get image info
                            $finfo = new finfo(FILEINFO_MIME_TYPE);
                            $fileType = $finfo->buffer($imageData);
                            $fileSize = strlen($imageData);

                            if ($fileSize > MAX_FILE_SIZE) {
                                $error = 'Image is too large! Maximum size is 3MB.';
                            } elseif (!in_array($fileType, ALLOWED_TYPES)) {
                                $error = 'Invalid file type! Only JPG, PNG, and GIF are allowed.';
                            } else {
                              

                                $extensions = [
                                    'image/jpeg' => 'jpg',
                                    'image/png' => 'png',
                                    'image/gif' => 'gif'
                                ];
                                $extension = $extensions[$fileType] ?? 'jpg';

                                $filename = uniqid() . '_' . time() . '.' . $extension;
                                $destination = UPLOAD_DIR . $filename;

                                if (file_put_contents($destination, $imageData) !== false) {
                                    $stmt = $db->prepare("INSERT INTO photos (user_id, filename, caption, is_private) VALUES (?, ?, ?, ?)");
                                    if ($stmt->execute([$user['id'], $filename, $caption, $isPrivate])) {
                                        $success = 'Photo uploaded successfully from URL!';
                                    } else {
                                        $error = 'Failed to save photo to database.';
                                        unlink($destination);
                                    }
                                } else {
                                    $error = 'Failed to save downloaded image.';
                                }
                            }
                        }
                    } catch (Exception $e) {
                        $error = 'Error downloading image: ' . $e->getMessage();
                    }
                }
            }
        }
    }
    elseif (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['photo'];

        if ($file['error'] === UPLOAD_ERR_OK) {
            $fileSize = $file['size'];
            $fileType = $file['type'];
            $tmpName = $file['tmp_name'];

            if ($fileSize > MAX_FILE_SIZE) {
                $error = 'File is too large! Maximum size is 3MB.';
            } elseif (!in_array($fileType, ALLOWED_TYPES)) {
                $error = 'Invalid file type! Only JPG, PNG, and GIF are allowed.';
            } else {
                if (!is_dir(UPLOAD_DIR)) {
                    mkdir(UPLOAD_DIR, 0755, true);
                }

                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $filename = uniqid() . '_' . time() . '.' . $extension;
                $destination = UPLOAD_DIR . $filename;

                if (move_uploaded_file($tmpName, $destination)) {
                    $stmt = $db->prepare("INSERT INTO photos (user_id, filename, caption, is_private) VALUES (?, ?, ?, ?)");
                    if ($stmt->execute([$user['id'], $filename, $caption, $isPrivate])) {
                        $success = 'Photo uploaded successfully!';
                    } else {
                        $error = 'Failed to save photo to database.';
                        unlink($destination);
                    }
                } else {
                    $error = 'Failed to upload file.';
                }
            }
        } else {
            $error = 'Upload error occurred.';
        }
    } else {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $error = 'Please upload a file or provide a URL!';
        }
    }
}
// Handle photo deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_photo'])) {
    $photoId = $_POST['photo_id'] ?? 0;

    $stmt = $db->prepare("
        SELECT * FROM photos 
        WHERE id = ? AND user_id = ?
    ");
    $stmt->execute([$photoId, $user['id']]);
    $photo = $stmt->fetch();

    if ($photo) {
        $filepath = UPLOAD_DIR . $photo['filename'];
        if (file_exists($filepath)) {
            unlink($filepath);
        }

        $stmt = $db->prepare("DELETE FROM photos WHERE id = ?");
        if ($stmt->execute([$photoId])) {
            $success = 'Photo deleted successfully!';
        }
    }
}

$stmt = $db->prepare("SELECT * FROM photos WHERE user_id = ? ORDER BY uploaded_at DESC");
$stmt->execute([$user['id']]);
$photos = $stmt->fetchAll();

$pageTitle = 'Upload Photos';
require_once 'header.php';
?>
<h2>Upload Photos</h2>
<p><a href="/?page=<?php echo urlencode($user['username']); ?>">← View Public Page</a></p>

<?php if ($error): ?>
    <br>
    <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <br>
    <div class="success-box"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="section">
    <h3>Upload New Photo</h3>
    <form method="POST" enctype="multipart/form-data" class="form">
        <div class="form-group">
            <label>Choose Photo:</label>
            <input type="file" name="photo" accept="image/*" id="photo-file">
            <div class="form-hint">JPG, PNG, or GIF (max 3MB)</div>
        </div>

        <div style="text-align: center; margin: 15px 0; color: #999; font-weight: bold;">- OR -</div>

        <div class="form-group">
            <label>Photo URL:</label>
            <input type="url" name="photo_url" style="width: 100%;" id="photo-url" placeholder="https://example.com/image.jpg">
            <div class="form-hint">Paste a direct link to an image</div>
        </div>

        <div class="form-group">
            <label>Caption (optional):</label>
            <textarea name="caption" rows="2" placeholder="Add a caption..."></textarea>
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" name="is_private" value="1">
                Make this photo private (only you can see it)
            </label>
        </div>

        <button type="submit" class="btn">Upload Photo</button>
    </form>

    <script>
        // Make file input and URL input work together
        const fileInput = document.getElementById('photo-file');
        const urlInput = document.getElementById('photo-url');

        fileInput.addEventListener('change', function() {
            if (this.files.length > 0) {
                urlInput.value = '';
                urlInput.removeAttribute('required');
                this.setAttribute('required', 'required');
            }
        });

        urlInput.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                fileInput.value = '';
                fileInput.removeAttribute('required');
                this.setAttribute('required', 'required');
            }
        });
    </script>
</div>

<div class="section">
    <h3>Uploaded Photos (<?php echo count($photos); ?>)</h3>

    <?php if (empty($photos)): ?>
        <p class="text-muted">No photos uploaded yet. Upload your first photo above!</p>
    <?php else: ?>
        <div class="photo-grid">
            <?php foreach ($photos as $photo): ?>
                <div class="photo-item">
                    <img src="uploads/<?php echo htmlspecialchars($photo['filename']); ?>"
                        alt="<?php echo htmlspecialchars($photo['caption']); ?>">
                    <?php if ($photo['is_private']): ?>
                        <div class="privacy-badge">Private</div>
                    <?php endif; ?>
                    <?php if ($photo['caption']): ?>
                        <div class="photo-caption"><?php echo htmlspecialchars($photo['caption']); ?></div>
                    <?php endif; ?>
                    <div class="photo-date">
                        <?php echo date('M j, Y g:i A', strtotime($photo['uploaded_at'])); ?>
                    </div>
                    <form method="POST" onsubmit="return confirm('Delete this photo?');">
                        <input type="hidden" name="photo_id" value="<?php echo $photo['id']; ?>">
                        <button type="submit" name="delete_photo" class="btn btn-small btn-danger">Delete</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php require_once 'footer.php'; ?>