<?php
require_once 'database.php';

$db = getDB();
$user = getCurrentUser();

// TODO: fetch popular posts, for now we get posts from our friends
$stmt = $db->prepare("
    SELECT u.*, 
           (SELECT COUNT(*) FROM photos WHERE user_id = u.id AND is_private = 0) as photo_count
    FROM users u
    WHERE u.username IN ('pwnthem0le', 'dadadani', 'george_droyd')
");
$stmt->execute();
$pages = $stmt->fetchAll();

foreach ($pages as &$page) {
    $photoStmt = $db->prepare("
        SELECT filename 
        FROM photos 
        WHERE user_id = :user_id AND is_private = 0 
        ORDER BY uploaded_at DESC 
        LIMIT 3
    ");
    $photoStmt->execute(['user_id' => $page['id']]);
    $page['preview_photos'] = $photoStmt->fetchAll(PDO::FETCH_COLUMN);
}
unset($page); 

$pageTitle = 'Share Your Photos Online';
require_once 'header.php';
?>
<?php if (!isLoggedIn()): ?>
    <div class="welcome-box">
        <h2>Welcome to <?php echo SITE_NAME; ?>!</h2>
        <p>Create your own photo page and share your memories with the world.</p>
        <p>Join our community today - it's fast, free, and easy!</p>
        <div>
            <a href="register.php" class="btn">Sign Up Now</a>
            <a href="login.php" class="btn">Login</a>
        </div>
    </div>
<?php endif; ?>

<h2>Browse Recent Pages</h2>

<?php if (empty($pages)): ?>
    <p class="text-muted text-center">No users have registered yet. Be the first to create an account!</p>
<?php else: ?>
    <div class="browse-grid">
        <?php foreach ($pages as $page): ?>
            <div class="browse-card">
                <h3><a href="/?page=<?php echo urlencode($page['username']); ?>">
                        <?php echo htmlspecialchars($page['friendly_name'] ?? $page['username']); ?>
                    </a></h3>
                <div class="browse-meta">
                    <strong>@<?php echo htmlspecialchars($page['username']); ?></strong> |
                    <?php echo $page['photo_count']; ?> photo<?php echo $page['photo_count'] != 1 ? 's' : ''; ?>
                </div>
                <?php if (!empty($page['preview_photos'])): ?>
                    <div class="browse-preview">
                        <?php foreach ($page['preview_photos'] as $photo): ?>
                            <img src="uploads/<?php echo htmlspecialchars($photo); ?>" alt="Preview">
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php require_once 'footer.php'; ?>