<?php

$page_username = trim($_GET['page'] ?? '');

if (strlen($page_username) > 0) {
    require_once "page.php";
} else {
    require_once "home.php";
}
