<?php
require_once 'database.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $friendly_name = trim($_POST['friendly_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'All fields are required!';
    } elseif ($password !== $confirm) {
        $error = 'Passwords do not match!';
    } elseif (strlen($friendly_name) > 100) {
        $error = 'The public name must not be longer thn 100 characters!';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters!';
    } elseif (!preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username)) {
        $error = 'Username must be 4-20 characters (letters, numbers, underscore only)!';
    } else {
        $db = getDB();

        $stmt = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);

        if ($stmt->fetch()) {
            $error = 'Username already exists!';
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("INSERT INTO users (username, friendly_name, password) VALUES (?, ?, ?)");

            if ($stmt->execute([$username, strlen($friendly_name) > 0 ? $friendly_name : null, $hashedPassword])) {
                $success = 'Account created successfully! You can now login.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}

$pageTitle = 'Register';
require_once 'header.php';
?>
<h2>Create Your Account</h2>

<?php if ($error): ?>
    <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="success-box"><?php echo htmlspecialchars($success); ?></div>
    <p><a href="login.php">Click here to login</a></p>
<?php else: ?>
    <form method="POST" class="form">
        <div class="form-group">
            <label>Public Name:</label>
            <input type="text" name="friendly_name"
                value="<?php echo htmlspecialchars($_POST['friendly_name'] ?? ''); ?>">
            <div class="form-hint">optional, a friendly name that will be visible on your page</div>
        </div>

        <div class="form-group">
            <label>Username:</label>
            <input type="text" name="username" required
                value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>">
            <div class="form-hint">3-20 characters, letters/numbers/underscore only</div>
            <div class="form-hint">This will be your page URL: ?page=your-username</div>
        </div>

        <div class="form-group">
            <label>Password:</label>
            <input type="password" name="password" required>
            <div class="form-hint">At least 6 characters</div>
        </div>

        <div class="form-group">
            <label>Confirm Password:</label>
            <input type="password" name="confirm_password" required>
        </div>

        <button type="submit" class="btn">Register</button>
    </form>

    <p class="text-center">
        <br>
        Already have an account? <a href="login.php">Login here</a>
    </p>
<?php endif; ?>
<?php require_once 'footer.php'; ?>