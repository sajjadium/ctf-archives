#!/bin/bash
set -e

if [ ! -f /var/www/html/.htaccess ]; then
    cp /docker-init/.htaccess /var/www/html/.htaccess
fi

if [ ! -d /var/www/html/uploads ]; then
    mkdir -p /var/www/html/uploads
fi

if [ -z "$(ls -A /var/www/html/uploads)" ]; then
    cp -r /docker-init/uploads/* /var/www/html/uploads/ 2>/dev/null || echo "No default photos to copy"
fi

if [ ! -f /var/www/html/uploads/.htaccess ]; then
    cp /docker-init/uploads/.htaccess /var/www/html/uploads/.htaccess 2>/dev/null || echo "No uploads/.htaccess to copy"
fi

chown -R www-data:www-data /var/www/html/uploads
chmod -R 755 /var/www/html/uploads

echo "Initialization complete!"

exec apache2-foreground
