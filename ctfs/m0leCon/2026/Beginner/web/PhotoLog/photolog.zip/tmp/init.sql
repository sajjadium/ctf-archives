CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    friendly_name VARCHAR(150),
    is_admin BOOLEAN DEFAULT FALSE,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_username (username)
);

CREATE TABLE IF NOT EXISTS photos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    caption TEXT,
    is_private BOOLEAN DEFAULT FALSE,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id)
);


INSERT INTO users (friendly_name, is_admin, username, password) VALUES ('PTM', 1, 'pwnthem0le', '$2y$12$YyVIRSxOF9wbLS1D1F5iuOgdvFTKUKFhuym.9C6.gB1w8Ag8MKo9O');
INSERT INTO users (friendly_name, is_admin, username, password) VALUES ('Daniele', 0, 'dadadani', '$2y$12$BuBf1i0r6NETJIIAGREILuuhOET9HCjljHNVsKu8Rt2obXCxbaG5S');
INSERT INTO users (friendly_name, is_admin, username, password) VALUES ('George Droyd', 0, 'george_droyd', '$2y$12$lEMB.djgKpiY.8MuZjWBFOWSthcDjmRJbh1c4Zf50YzRZKC0RL.62');

INSERT INTO photos (user_id, filename, caption, is_private) VALUES ((SELECT id FROM users WHERE username = 'pwnthem0le'), '691732b8654e0_1763127992.png', "m0leCon 2026 is the seventh edition of the computer security conference organized by the student team pwnthem0le in collaboration with Politecnico di Torino. The aim is to bring together hackers, security experts, and IT specialists from different backgrounds and skill levels. The conference will feature a variety of talks and presentations, mostly focused on various aspects of offensive security.", 0);
INSERT INTO photos (user_id, filename, caption, is_private) VALUES ((SELECT id FROM users WHERE username = 'pwnthem0le'), '6917336f78a4b_1763128175.jpg', "PTM{REDACTED}", 1);

INSERT INTO photos (user_id, filename, caption, is_private) VALUES ((SELECT id FROM users WHERE username = 'dadadani'), '6917352e8029a_1763128622.png', "my pc is so slow :(", 0);
INSERT INTO photos (user_id, filename, caption, is_private) VALUES ((SELECT id FROM users WHERE username = 'dadadani'), '691742305b298_1763131952.jpg', "be wary of these russian hackers D:", 0);

INSERT INTO photos (user_id, filename, caption, is_private) VALUES ((SELECT id FROM users WHERE username = 'george_droyd'), '6916693f13fd8_1763076415.jpg', "Yo, check it, lemme tell you 'bout this place
Where dreams go dark and shadows take embrace
It ain't no heaven, ain't no pearly gate
This is Zuck's domain, where fentanyl awaits

The Fent Reactor, a beast of steel and grime
Pumpin' that good shit, one drop at a time
Tears of the broken, souls sold for greed
Fuelin' this machine, plantin' a deadly seed

Niggas lined up, beggin' for a taste
Their minds enslaved, their bodies laced
Zuck laughin' hard, countin' all his stacks
While the world crumbles, caught in fentanyl traps

But I see through it, ain't no foolin' me
This digital nightmare, this twisted reality
I'm fightin' back, breakin' free from these chains
Gonna shut this reactor down, reclaim what remains

So listen close, heed my warning call
The Fent Reactor's grip is destined to fall
We gotta rise up, together we stand tall
Break the cycle, before it consumes us all.", 0);