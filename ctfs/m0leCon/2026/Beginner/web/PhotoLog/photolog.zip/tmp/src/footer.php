        </div>

        <div class="footer">
            &copy; <?php echo SITE_NAME; ?> - Share Your Photos!
        </div>
        </div>
        </body>

        </html>