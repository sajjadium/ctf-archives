<?php
require_once 'database.php';

$db = getDB();

if (empty($page_username)) {
    header('Location: index.php');
    exit;
}

$stmt = $db->prepare("
    SELECT id, friendly_name, username, created_at FROM users WHERE username = ?
");
$stmt->execute([$page_username]);
$user = $stmt->fetch();

if (!$user) {
    http_response_code(404);
    require_once 'header.php';
?>
    <div class="page-header">
        <div class="error-box">Page not found!</div>
    </div>
<?php
    require_once 'footer.php';
    exit;
}

$currentUser = getCurrentUser();
$isOwner = $currentUser && $currentUser['id'] == $user['id'];

// Get photos - show all to owner (or admins), only public to others
if ($isOwner || $currentUser["is_admin"]) {
    $stmt = $db->prepare("SELECT * FROM photos WHERE user_id = ? ORDER BY uploaded_at DESC");
    $stmt->execute([$user['id']]);
} else {
    $stmt = $db->prepare("SELECT * FROM photos WHERE user_id = ? AND is_private = 0 ORDER BY uploaded_at DESC");
    $stmt->execute([$user['id']]);
}
$photos = $stmt->fetchAll();

$pageTitle = $user['friendly_name'] ?? $user["username"];
require_once 'header.php';
?>
<div class="page-header">
    <h2><?php echo htmlspecialchars($user['friendly_name'] ?? $user["username"]); ?></h2>
    <div class="page-meta">
        <strong>@<?php echo htmlspecialchars($user['username']); ?></strong> |
        Created <?php echo date('F j, Y', strtotime($user['created_at'])); ?> |
        <?php echo count($photos); ?> photo<?php echo count($photos) != 1 ? 's' : ''; ?>
    </div>
    <?php if ($isOwner): ?>
        <div class="owner-controls">
            <a href="upload.php" class="btn btn-small">Upload More Photos</a>
        </div>
    <?php endif; ?>
</div>

<?php if (empty($photos)): ?>
    <p class="text-muted text-center">No photos have been uploaded to this page yet.</p>
<?php else: ?>
    <div class="photo-gallery">
        <?php foreach ($photos as $photo): ?>
            <div class="gallery-item">
                <a href="uploads/<?php echo htmlspecialchars($photo['filename']); ?>" target="_blank">
                    <img src="uploads/<?php echo htmlspecialchars($photo['filename']); ?>"
                        alt="<?php echo htmlspecialchars($photo['caption']); ?>">
                </a>
                <?php if ($isOwner && $photo['is_private']): ?>
                    <div class="privacy-badge">Private</div>
                <?php endif; ?>
                <?php if ($photo['caption']): ?>
                    <div class="gallery-caption"><?php echo htmlspecialchars($photo['caption']); ?></div>
                <?php endif; ?>
                <div class="gallery-date">
                    <?php echo date('M j, Y', strtotime($photo['uploaded_at'])); ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php require_once 'footer.php'; ?>