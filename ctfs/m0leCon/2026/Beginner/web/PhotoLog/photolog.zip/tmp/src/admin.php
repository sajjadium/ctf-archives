<?php
require_once 'database.php';

$user = getCurrentUser();
$authorized = false;

if (isset($user) && $user["is_admin"]) {
    $authorized = true;
}

// We need a way to make ourselves admin if there isn't an existing account
if ($_SERVER['REMOTE_ADDR'] == "127.0.0.1") {
    $authorized = true;
}


if (!$authorized) {
    http_response_code(403);
    require_once 'header.php';
?>
    <div class="page-header">
        <div class="error-box">You don't have access to this page!</div>
    </div>
<?php
    require_once 'footer.php';
    exit;
}

$db = getDB();

$success = false;
$error = false;

$user_to_make_admin = trim($_GET['make_admin'] ?? '');
if (strlen($user_to_make_admin) > 0) {

    $stmt = $db->prepare("SELECT id, friendly_name, username, created_at FROM users WHERE username = ?");
    $stmt->execute([$user_to_make_admin]);
    $found = $stmt->fetch();
    if ($found) {
        $stmt = $db->prepare("UPDATE users SET is_admin = 1 WHERE username = ?");
        $stmt->execute([$user_to_make_admin]);
        $success = "Admin role granted to the user!";
    } else {
        $error = "Unable to find user to set admin!";
    }
}

require_once 'header.php';
?>

<h2>Admin Panel</h2>

<?php if ($error): ?>
    <br>
    <div class="error-box"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <br>
    <div class="success-box"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="section">
    <h3>Set user to admin</h3>
    <form method="GET" enctype="multipart/form-data" class="form">

        <div class="form-group">
            <label>User username:</label>
            <input type="text" name="make_admin" style="width: 100%;" id="photo-url" required>
        </div>

        <button type="submit" class="btn">Update Role</button>
    </form>

</div>

<p>TODO: add more functions</p>

<?php require_once 'footer.php'; ?>