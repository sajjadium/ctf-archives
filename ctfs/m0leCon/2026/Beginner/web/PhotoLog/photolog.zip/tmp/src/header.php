<?php
if (!defined('SITE_NAME')) {
    require_once 'database.php';
}
$currentUser = getCurrentUser();
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$viewing_page_username = trim($_GET['page'] ?? '');
$isOnMyPage = isLoggedIn() && !empty($viewing_page_username) && $viewing_page_username === $currentUser['username'];

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($pageTitle) ? htmlspecialchars($pageTitle) . ' - ' : ''; ?><?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <div class="header">
            <h1><a href="index.php"><?php echo SITE_NAME; ?></a></h1>
            <div class="tagline">Share your memories, one photo at a time</div>
        </div>

        <div class="nav">
            <a href="index.php" <?php echo ($currentPage === 'index' && empty($viewing_page_username)) ? 'class="active"' : ''; ?>>Home</a>
            <?php if (isLoggedIn()): ?>
                <a href="/?page=<?php echo urlencode($currentUser['username']); ?>" <?php echo $isOnMyPage ? 'class="active"' : ''; ?>>My Page</a>
                <a href="upload.php" <?php echo $currentPage === 'upload' ? 'class="active"' : ''; ?>>Upload Photos</a>
                <span class="nav-user">Welcome, <?php echo htmlspecialchars($currentUser['username']); ?>!</span>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php" <?php echo $currentPage === 'login' ? 'class="active"' : ''; ?>>Login</a>
                <a href="register.php" <?php echo $currentPage === 'register' ? 'class="active"' : ''; ?>>Register</a>
            <?php endif; ?>
        </div>

        <div class="content-box">