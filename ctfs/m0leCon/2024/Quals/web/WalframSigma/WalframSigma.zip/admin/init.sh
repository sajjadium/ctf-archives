#!/bin/bash
set -ex
here="$(realpath "$(dirname "$0")")"
cd "$here"
