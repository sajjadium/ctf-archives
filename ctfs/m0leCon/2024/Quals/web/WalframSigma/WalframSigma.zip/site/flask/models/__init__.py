from server import db

from .user import User

__all__ = ["db", "User"]
