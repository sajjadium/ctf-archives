#!/bin/bash

supervisord -c /supervisord.conf & disown