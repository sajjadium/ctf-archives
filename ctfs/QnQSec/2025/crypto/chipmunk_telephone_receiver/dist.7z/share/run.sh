#!/bin/sh

exec 2>/dev/null
timeout 300 python3 /home/chal/chal.py

