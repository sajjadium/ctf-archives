use borsh::to_vec;

use solana_program::{
    account_info::{AccountInfo, next_account_info},
    entrypoint::ProgramResult,
    instruction::{AccountMeta, Instruction},
    msg,
    program::invoke,
    pubkey::Pubkey,
    system_program,
};

use vault_program::VaultInstruction;

pub fn process_instruction(
    _program: &Pubkey,
    accounts: &[AccountInfo],
    _data: &[u8],
) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let vault_program = next_account_info(account_iter)?;
    let user = next_account_info(account_iter)?;
    let vault = next_account_info(account_iter)?;

    //write your solution here

    Ok(())
}
