use sol_ctf_framework::ChallengeBuilder;

use solana_sdk::{
    account::Account,
    pubkey::Pubkey,
    signature::{Keypair, Signer},
};

use solana_program::system_program;

use std::{
    error::Error,
    fs,
    io::Write,
    net::{TcpListener, TcpStream},
};

use vault_program::create;

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:5001")?;
    loop {
        let (stream, _) = listener.accept()?;
        // move each socket to a Tokio task
        tokio::spawn(async move {
            if let Err(e) = handle_connection(stream).await {
                eprintln!("handler error: {e}");
            }
        });
    }
}

async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    // load programs
    let solve_pubkey = match builder.input_program() {
        Ok(pubkey) => pubkey,
        Err(e) => {
            writeln!(socket, "Error: cannot add solve program → {e}")?;
            return Ok(());
        }
    };
    let program_key = Pubkey::new_unique();
    let program_pubkey = builder
        .add_program(&"../challenge/vault_program.so", Some(program_key))
        .expect("Duplicate pubkey supplied");

    // make user
    let user = Keypair::new();

    writeln!(socket, "program: {}", program_pubkey)?;
    writeln!(socket, "user: {}", user.pubkey())?;

    const TARGET_AMT: u64 = 10_000_000_000;
    const INIT_BAL: u64 = 12_000_000_000;

    builder.builder.add_account(
        user.pubkey(),
        Account::new(INIT_BAL, 0, &system_program::ID),
    );

    let mut challenge = builder.build().await;

    // create a vault
    challenge
        .run_ixs_full(
            &[create(program_pubkey, user.pubkey())],
            &[&user],
            &user.pubkey(),
        )
        .await?;

    // run solve
    let ixs = challenge.read_instruction(solve_pubkey).unwrap();
    challenge
        .run_ixs_full(&[ixs], &[&user], &user.pubkey())
        .await?;

    // check solve
    let balance = challenge
        .ctx
        .banks_client
        .get_account(user.pubkey())
        .await?
        .unwrap()
        .lamports;
    writeln!(socket, "lamports: {:?}", balance)?;

    if balance > TARGET_AMT {
        let flag = fs::read_to_string("../challenge/flag.txt").unwrap();
        writeln!(
            socket,
            "Congratulations! You found the secret key! Here is your flag \nFlag: {}",
            flag
        )?;
    } else {
        writeln!(socket, "No flag for you!")?;
    }

    Ok(())
}
