use borsh::BorshDeserialize;

use solana_program::{
    account_info::{AccountInfo, next_account_info},
    entrypoint::ProgramResult,
    msg,
    program::invoke_signed,
    program_error::ProgramError,
    pubkey::Pubkey,
    system_instruction,
};

use crate::{UNLOCK_AMOUNT, VaultInstruction};

pub fn process_instruction(
    program: &Pubkey,
    accounts: &[AccountInfo],
    mut data: &[u8],
) -> ProgramResult {
    match VaultInstruction::deserialize(&mut data)? {
        VaultInstruction::Create { vault_bump } => create(program, accounts, vault_bump),
        VaultInstruction::Unlock { key } => unlock(program, accounts, key),
    }
}

fn create(program: &Pubkey, accounts: &[AccountInfo], vault_bump: u8) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let vault = next_account_info(account_iter)?;
    let user = next_account_info(account_iter)?;

    let vault_address =
        Pubkey::create_program_address(&["vault".as_bytes(), &[vault_bump]], &program)?;

    assert_eq!(*vault.key, vault_address);
    assert!(user.is_signer);

    msg!("Vault Owner Before {}", vault.owner);

    invoke_signed(
        &system_instruction::create_account(&user.key, &vault_address, 11_000_000_000, 0, &program),
        &[user.clone(), vault.clone()],
        &[&["vault".as_bytes(), &[vault_bump]]],
    )?;

    msg!("Vault Owner After {}", vault.owner);

    Ok(())
}

fn unlock(program: &Pubkey, accounts: &[AccountInfo], key: u64) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let vault = next_account_info(account_iter)?;
    let user = next_account_info(account_iter)?;

    assert_eq!(vault.owner, program);
    assert!(user.is_signer);

    // obviously not the real key
    if key != 0x1337 {
        return Err(ProgramError::InvalidInstructionData);
    }

    if **vault.try_borrow_lamports()? < UNLOCK_AMOUNT {
        msg!("vault has insufficient funds");
        return Err(ProgramError::InsufficientFunds);
    }

    **vault.try_borrow_mut_lamports()? -= UNLOCK_AMOUNT;
    **user.try_borrow_mut_lamports()? += UNLOCK_AMOUNT;

    msg!("unlocked {} lamports", UNLOCK_AMOUNT);

    Ok(())
}
