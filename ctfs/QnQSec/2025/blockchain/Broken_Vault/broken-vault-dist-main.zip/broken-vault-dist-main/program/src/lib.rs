mod entrypoint;
pub mod processor;

use borsh::{BorshDeserialize, BorshSerialize, to_vec};

use solana_program::{
    instruction::{AccountMeta, Instruction},
    pubkey::Pubkey,
    system_program,
};

#[derive(BorshDeserialize, BorshSerialize)]
pub enum VaultInstruction {
    Create { vault_bump: u8 },
    Unlock { key: u64 },
}

pub const UNLOCK_AMOUNT: u64 = 10_000_000_000;

pub fn create(program: Pubkey, user: Pubkey) -> Instruction {
    let (vault, vault_bump) = Pubkey::find_program_address(&["vault".as_bytes()], &program);
    Instruction {
        program_id: program,
        accounts: vec![
            AccountMeta::new(vault, false),
            AccountMeta::new(user, true),
            AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&VaultInstruction::Create { vault_bump }).unwrap(),
    }
}
