use crate::*;

#[error_code]
pub enum CustomError {
    #[msg("Insufficient balance for transfer")]
    InsufficientBalance,
    #[msg("Balance overflow")]
    BalanceOverflow,
    #[msg("Balance underflow")]
    BalanceUnderflow,
    #[msg("Unauthorized")]
    Unauthorized,
}