use crate::*;

#[derive(Accounts)]
pub struct AdminTransfer<'info> {
    #[account(mut)]
    pub signer: Signer<'info>,
    #[account(
        mut,
        seeds = [b"vault"],
        bump,
    )]
    pub vault: Account<'info, TokenHolder>,
    #[account(mut)]
    pub receiver: Account<'info, TokenHolder>,
    pub admin: Account<'info, Admin>,
}

pub fn process_admin_transfer(ctx: Context<AdminTransfer>, amount: u64) -> Result<()> {
    let vault = &mut ctx.accounts.vault;
    let receiver = &mut ctx.accounts.receiver;
    let admin = &mut ctx.accounts.admin;

    if admin.address != ctx.accounts.signer.key() {
        return Err(CustomError::Unauthorized.into());
    }

    if vault.balance < amount {
        return Err(CustomError::InsufficientBalance.into());
    }
    vault.balance = vault
        .balance
        .checked_sub(amount)
        .ok_or(CustomError::BalanceUnderflow)?;
    receiver.balance = receiver
        .balance
        .checked_add(amount)
        .ok_or(CustomError::BalanceOverflow)?;

    Ok(())
}
