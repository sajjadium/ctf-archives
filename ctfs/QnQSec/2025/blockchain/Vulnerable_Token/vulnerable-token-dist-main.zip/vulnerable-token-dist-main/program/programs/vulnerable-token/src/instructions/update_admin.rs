use crate::*;

#[derive(Accounts)]
pub struct UpdateAdmin<'info> {
    #[account(mut)]
    pub signer: Signer<'info>,
    #[account(mut)]
    pub admin: Account<'info, Admin>,
}

pub fn process_update_admin(ctx: Context<UpdateAdmin>, new_admin: Pubkey) -> Result<()> {
    let admin = &mut ctx.accounts.admin;

    if admin.address != ctx.accounts.signer.key() {
        return Err(CustomError::Unauthorized.into());
    }

    admin.address = new_admin;

    Ok(())
}
