use crate::*;

#[derive(Accounts)]
pub struct Initialize<'info> {
    #[account(
        init,
        payer = signer,
        space = 8 + TokenHolder::INIT_SPACE,
        seeds = [b"vault", signer.key().as_ref()],
        bump,
    )]
    pub player: Account<'info, TokenHolder>,
    #[account(
        init,
        payer = signer,
        space = 8 + TokenHolder::INIT_SPACE,
        seeds = ["vault".as_ref()],
        bump,
    )]
    pub vault: Account<'info, TokenHolder>,
    #[account(
        init,
        payer = signer,
        space = 8 + Admin::INIT_SPACE,
        seeds = ["admin".as_ref()],
        bump,
    )]
    pub admin: Account<'info, Admin>,
    #[account(mut)]
    pub signer: Signer<'info>,
    pub system_program: Program<'info, System>,
}

pub fn process_initialize(ctx: Context<Initialize>) -> Result<()> {
    let player = &mut ctx.accounts.player;
    let vault = &mut ctx.accounts.vault;
    let vault_key = vault.key();
    let admin = &mut ctx.accounts.admin;

    player.authority = ctx.accounts.signer.key();
    player.balance = INITIAL_BALANCE;
    vault.authority = vault_key;
    vault.balance = INITIAL_BALANCE;
    admin.address = INITIAL_ADMIN;

    Ok(())
}
