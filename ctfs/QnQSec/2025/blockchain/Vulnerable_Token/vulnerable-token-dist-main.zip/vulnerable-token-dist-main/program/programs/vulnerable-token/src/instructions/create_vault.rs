use crate::*;

#[derive(Accounts)]
#[instruction(seed1: String)]
pub struct CreateVault<'info> {
    #[account(mut)]
    pub signer: Signer<'info>,
    #[account(
        init,
        space = 8 + TokenHolder::INIT_SPACE,
        payer = signer,
        seeds = [b"vault", seed1.as_bytes()],
        bump,
    )]
    pub vault: Account<'info, TokenHolder>,
    pub system_program: Program<'info, System>,
}

pub fn process_create_vault(ctx: Context<CreateVault>, _seed1: String) -> Result<()> {
    let vault = &mut ctx.accounts.vault;

    vault.balance = 0;
    vault.authority = ctx.accounts.signer.key();

    Ok(())
}
