use anchor_lang::prelude::*;
use anchor_lang::solana_program::{instruction::Instruction, pubkey::Pubkey, system_program};
use anchor_lang::{InstructionData, ToAccountMetas};

pub mod constants;
pub mod errors;
pub mod instructions;
pub mod states;
use constants::*;
use errors::*;
use instructions::*;
use states::*;

declare_id!("FpdiKxHK3WrX6mcahHLt2aWjSxx4BrGBwfG7oVM63QbB");

#[program]
pub mod vulnerable_token {
    use super::*;

    pub fn initialize(ctx: Context<Initialize>) -> Result<()> {
        process_initialize(ctx)
    }

    pub fn create_vault(ctx: Context<CreateVault>, seed1: String) -> Result<()> {
        process_create_vault(ctx, seed1)
    }

    pub fn admin_transfer(ctx: Context<AdminTransfer>, amount: u64) -> Result<()> {
        process_admin_transfer(ctx, amount)
    }

    pub fn update_admin(ctx: Context<UpdateAdmin>, new_admin: Pubkey) -> Result<()> {
        process_update_admin(ctx, new_admin)
    }

    pub fn transfer(ctx: Context<Transfer>, amount: u64) -> Result<()> {
        process_transfer(ctx, amount)
    }

    pub fn multiply(ctx: Context<Multiply>) -> Result<()> {
        process_multiply(ctx)
    }
}

pub fn create(program: Pubkey, user: Pubkey) -> Instruction {
    let (vault, _) = Pubkey::find_program_address(&["vault".as_bytes()], &program);
    let (player, _) = Pubkey::find_program_address(&["vault".as_bytes(), user.as_ref()], &program);
    let (admin, _) = Pubkey::find_program_address(&["admin".as_bytes()], &program);
    Instruction {
        program_id: program,
        accounts: crate::accounts::Initialize {
            admin: admin,
            player: player,
            vault: vault,
            signer: user,
            system_program: system_program::ID,
        }
        .to_account_metas(None),
        data: crate::instruction::Initialize {}.data(),
    }
}

pub fn get_vault(program: Pubkey, user: Pubkey) -> (Pubkey, u8) {
    Pubkey::find_program_address(&["vault".as_bytes(), user.as_ref()], &program)
}
