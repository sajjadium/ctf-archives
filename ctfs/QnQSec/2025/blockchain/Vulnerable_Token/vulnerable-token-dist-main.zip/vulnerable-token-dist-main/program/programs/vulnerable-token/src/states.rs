use crate::*;

#[account]
#[derive(InitSpace)]
pub struct TokenHolder {
    pub authority: Pubkey,
    pub balance: u64,
}

#[account]
#[derive(InitSpace)]
pub struct Admin {
    pub address: Pubkey,
}
