use anchor_lang::{prelude::Pubkey, solana_program::pubkey};

pub const INITIAL_BALANCE: u64 = 1000;
pub const INITIAL_ADMIN: Pubkey = pubkey!("32ge6mrkQSMKo4TDX5fVCMHUDkzswt1ogY2FUvKmHEAP");