use crate::*;

#[derive(Accounts)]
pub struct Multiply<'info> {
    #[account(mut)]
    pub signer: Signer<'info>,
    #[account(
        mut,
        seeds = [b"vault"],
        bump,
    )]
    pub vault: Account<'info, TokenHolder>,
}

pub fn process_multiply(ctx: Context<Multiply>) -> Result<()> {
    let vault = &mut ctx.accounts.vault;

    vault.balance = vault
        .balance
        .checked_mul(2)
        .ok_or(CustomError::BalanceOverflow)?;
    Ok(())
}
