use crate::*;

#[derive(Accounts)]
pub struct Transfer<'info> {
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(
        mut,
        has_one = authority @ CustomError::Unauthorized,
    )]
    pub sender: Account<'info, TokenHolder>,
    #[account(mut)]
    pub receiver: Account<'info, TokenHolder>,
}

pub fn process_transfer(ctx: Context<Transfer>, amount: u64) -> Result<()> {
    let sender = &mut ctx.accounts.sender;
    let receiver = &mut ctx.accounts.receiver;

    if sender.balance < amount {
        return Err(CustomError::InsufficientBalance.into());
    }
    sender.balance = sender
        .balance
        .checked_sub(amount)
        .ok_or(CustomError::BalanceUnderflow)?;
    receiver.balance = receiver
        .balance
        .checked_add(amount)
        .ok_or(CustomError::BalanceOverflow)?;

    Ok(())
}
