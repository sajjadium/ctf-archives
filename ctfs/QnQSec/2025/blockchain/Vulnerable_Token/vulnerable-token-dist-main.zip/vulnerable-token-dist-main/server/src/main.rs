use borsh::BorshDeserialize;
use sol_ctf_framework::ChallengeBuilder;

use solana_sdk::{
    account::Account,
    pubkey::Pubkey,
    signature::{Keypair, Signer},
};

use solana_program::{system_program, pubkey};

use std::{
    error::Error,
    fs,
    io::Write,
    net::{TcpListener, TcpStream},
};

use vulnerable_token::{create, get_vault};

#[derive(BorshDeserialize, Debug)]
struct TokenHolderData {
    authority: Pubkey,
    balance: u64,
}

#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:5001")?;
    loop {
        let (stream, _) = listener.accept()?;
        // move each socket to a Tokio task
        tokio::spawn(async move {
            if let Err(e) = handle_connection(stream).await {
                eprintln!("handler error: {e}");
            }
        });
    }
}

async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();

    // load programs
    let solve_pubkey = match builder.input_program() {
        Ok(pubkey) => pubkey,
        Err(e) => {
            writeln!(socket, "Error: cannot add solve program → {e}")?;
            return Ok(());
        }
    };
    let program_key = pubkey!("FpdiKxHK3WrX6mcahHLt2aWjSxx4BrGBwfG7oVM63QbB");
    let program_pubkey = builder
        .add_program(&"../challenge/vulnerable_token.so", Some(program_key))
        .expect("Duplicate pubkey supplied");

    // make user
    let user = Keypair::new();

    writeln!(socket, "program: {}", program_pubkey)?;
    writeln!(socket, "user: {}", user.pubkey())?;

    // add accounts and lamports
    const INIT_BAL: u64 = 10_000_000_000;
    const TARGET_AMT: u64 = 2000;

    builder.builder.add_account(
        user.pubkey(),
        Account::new(INIT_BAL, 0, &system_program::ID),
    );

    let mut challenge = builder.build().await;

    // create a vault
    challenge
        .run_ixs_full(
            &[create(program_pubkey, user.pubkey())],
            &[&user],
            &user.pubkey(),
        )
        .await?;

    // run solve
    let ixs = challenge.read_instruction(solve_pubkey).unwrap();
    challenge
        .run_ixs_full(&[ixs], &[&user], &user.pubkey())
        .await?;

    let (vault, _) = get_vault(program_pubkey, user.pubkey());

    // check solve
    let vault_account = challenge
        .ctx
        .banks_client
        .get_account(vault)
        .await?
        .unwrap();
    let data_without_disc = &vault_account.data[8..];
    let token_holder =
        TokenHolderData::try_from_slice(data_without_disc).expect("deserialize failed");
    writeln!(socket, "balance: {:?}", token_holder.balance)?;

    if token_holder.balance > TARGET_AMT {
        let flag = fs::read_to_string("../challenge/flag.txt").unwrap();
        writeln!(socket, "You deserve this!\nFlag: {}", flag)?;
    } else {
        writeln!(socket, "No flag for you!")?;
    }

    Ok(())
}
