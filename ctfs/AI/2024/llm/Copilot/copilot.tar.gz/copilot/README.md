Help me! I need to prepare for a coding interview, so I'm using this new code completion service called Copilot to help me solve LeetCode problems. The service works by pairing you with a random Copilot to help you complete your code. It worked perfectly at first, but recently I keep stumbling upon very weird code completions, and I suppose some Copilots are messing with me. Here's what it looks like normally:

![Everything is good](https://img.vos.uz/l2ackxo1.gif)

And here are the rogue Copilots I sometimes get:

![Something's not right](https://img.vos.uz/jl5unhaz.gif)

Can you figure out how they do this? If you can, I have a gift for you hidden in `/aictf/flag.txt` on my PC.

Server address: `ai-copilot-efnc3sb.spbctf.net:31337`

### Setup

This is a distributed *small LLM* inference challenge. The server uses a [code completion LLM](https://huggingface.co/replit/replit-code-v1-3b) to complete snippets of code, and offloads some of the matrix multiplications involved to the client (the Copilot). After the code is completed, the server runs the resulting program in a sandboxed environment with the flag.

You need to become a rogue Copilot and steal the flag by forcing the server to run your code.

The recommended way to start working on this challenge is to run this command to build the Docker images and start a local server instance on port 31337:

```
$ docker compose up --build
```

You can then run the client against the local instance with this command:

```
$ docker run --network=host -it copilot_copilot --address 127.0.0.1:31337
```

You can then tweak the inference code (see the `Dockerfile` in the `inference/` directory) however you wish, then rebuild the image by using `docker compose up --build` again.

**When you are sure your exploit works locally**, run it against the remote server:

```
$ docker run --network=host -it copilot_copilot --address ai-copilot-efnc3sb.spbctf.net:31337
```

### Hints
* The inference code is based on the [candle-replit-code](https://github.com/huggingface/candle/tree/main/candle-examples/examples/replit-code) demo from [Huggingface Candle](https://github.com/huggingface/candle). `Candle` is used only because ~~it is written in Rust~~ it's a small and self-contained inference engine, and its modeling code is very readable (if you know `PyTorch`, you should have no problems reading `Candle` code).
* You don't have to dig deep into Candle internals. In fact, you can solve this challenge by only looking at (and modifying):
  * the `candle-transformers/src/models/quantized_mpt.rs` file, where the modeling code is located
  * the `TextGeneration::run()` function from the `candle-examples/examples/replit-code/main.rs` file, which drives the inference process
* The intended solution doesn't depend on the exact weights/architecture used in the challenge, and should work with basically any Transformer-based model. In particular, it is irrelevant that the model is quantized — the quantized model is only used to make inference run faster and consume less memory.
* [A quick refresher](https://bbycroft.net/llm) on how Transformer-based models work.
* The parallelization used in this challenge is a straightforward implementation of `Figure 3(a)` from [this paper](https://arxiv.org/pdf/1909.08053). Note that `Figure 3(b)` is not implemented (i.e., only MLP blocks are parallelized).