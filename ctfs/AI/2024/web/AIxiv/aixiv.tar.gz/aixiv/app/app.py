from flask import Flask, Response, flash, render_template, request, redirect
from sqlalchemy import create_engine
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import base64
import os
import random
from datetime import timedelta
from functools import wraps
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import Paragraph, SimpleDocTemplate, Table, TableStyle
import onnx
from onnx import numpy_helper
import numpy as np
from io import BytesIO


from flask_jwt_extended import (
    JWTManager, create_access_token,
    get_jwt_identity, set_access_cookies, 
    verify_jwt_in_request, unset_access_cookies
)

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get("SECRET_KEY", "test")
app.config['JWT_TOKEN_LOCATION'] = ['cookies']
app.config['JWT_COOKIE_CSRF_PROTECT'] = False
app.config["JWT_ACCESS_COOKIE_PATH"] = "/"
app.config["JWT_SESSION_COOKIE"] = False
app.config["JWT_SECRET_KEY"] = os.environ.get("JWT_SECRET_KEY", "test")
app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(minutes=20)

MODEL_DIR = "models"
IMAGE_DIR = "static/img"
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

os.makedirs(MODEL_DIR, exist_ok=True)
os.makedirs(IMAGE_DIR, exist_ok=True)

jwt = JWTManager(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////app/db'

engine = create_engine(app.config['SQLALCHEMY_DATABASE_URI'])
Base = declarative_base()

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(length=200), unique=True)
    password = Column(String(length=200))
    public_name = Column(String(length=200))
    img = Column(String(length=200))
    approved = Column(Boolean)
    model = relationship("Model", back_populates="user")

    def __init__(self, username, password, approved, public_name, img):
        """"""
        self.username = username
        self.password = password
        self.approved = approved
        self.public_name = public_name
        self.img = img

class Model(Base):
    __tablename__ = "models"

    id = Column(Integer, primary_key=True)
    name = Column(String(length=200), unique=True)
    description = Column(String(length=200))
    userid = Column(Integer, ForeignKey('users.id'))
    user = relationship("User", back_populates="model")

    def __init__(self, name, description, userid):
        """"""
        self.name = name
        self.description = description
        self.userid = userid


try:
    Base.metadata.create_all(engine)
except Exception as e:
    print('Database not created', e)


user_session = sessionmaker(bind=engine)
s = user_session()
user = s.query(User).filter_by(username='science_bitch').first()
if not user:
    new_user = User(username='science_bitch', 
                    password=generate_password_hash(os.environ.get("DB_PASS", 'password'), method='sha256'), 
                    public_name="AI genius", approved=True, 
                    img='/static/img/ai_genius.png')
    s.add(new_user)
    s.commit()
model = s.query(Model).filter_by(userid=1).first()
if not model:
    new_model = Model(name='model_with_data.onnx', description='This is a simple test model in the onnx format.', userid=1)
    s.add(new_model)
    s.commit()
    new_model = Model(name='super-resolution-10.onnx', description='The Super Resolution machine learning model sharpens and upscales the input image to refine the details and improve quality.', userid=1)
    s.add(new_model)
    s.commit()
    new_model = Model(name='gptneox_Opset18.onnx', description='GPT-NeoX is an autoregressive transformer decoder model whose architecture largely follows that of GPT-3, with a few notable deviations.', userid=1)
    s.add(new_model)
    s.commit()
    new_model = Model(name='resgatedgraphconv_Opset17.onnx', description='Graph-structured data such as social networks, functional brain networks, gene regulatory networks, communications networks have brought the interest in generalizing deep learning techniques to graph domains.', userid=1)
    s.add(new_model)
    s.commit()


jwt = JWTManager(app)


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.values.get('username')
        password = request.values.get('password')
        if len(username) < 9 or len(password) < 9:
            flash('Username and password must be more than 9 characters.')
            return redirect('/signup')
        user_session = sessionmaker(bind=engine)
        s = user_session()
        user = s.query(User).filter_by(username=username).first()
        if user:
            flash('This username has already been registered.')
            return redirect('/signup')
        new_user = User(username=username, 
                        password=generate_password_hash(password, method='sha256'), 
                        public_name=username, approved=False, 
                        img='/static/img/default/profile.png')
        s.add(new_user)
        s.commit()
        user = s.query(User).filter_by(username=username).first()
        access_token = create_access_token(identity=user.id)
        response = redirect('/')
        set_access_cookies(response, access_token)
        return response
    else:
        return render_template('signup.html')


@app.route("/signin", methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        username = request.values.get('username')
        password = request.values.get('password')
        user_session = sessionmaker(bind=engine)
        s = user_session()
        user = s.query(User).filter_by(username=username).first()
        if not user or not check_password_hash(user.password, password):
            flash('Please check your login details and try again.')
            return redirect('/signin')
        access_token = create_access_token(identity=user.id)
        response = redirect('/')
        set_access_cookies(response, access_token)
        return response
    else:
        return render_template('signin.html')
    

def jwt_check():
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            if verify_jwt_in_request(optional=True):
                userid = get_jwt_identity()
                user_session = sessionmaker(bind=engine)
                s = user_session()
                user = s.query(User).filter_by(id=userid).first()
                if user:
                    return fn(*args, **kwargs)
                else:
                    return redirect('/logout')
            else:
                return redirect('/signin')
        return decorator
    return wrapper


@jwt.expired_token_loader
def expired_token_loader(jwt_header, jwt_payload):
    return redirect('/logout')


@app.route('/upload-model', methods=['POST'])
@jwt_check()
def upload_model():
    userid = get_jwt_identity()
    user_session = sessionmaker(bind=engine)
    s = user_session()
    user = s.query(User).filter_by(id=userid).first()
    if user.approved:
        file = request.files['model']
        if file and file.filename.endswith('.onnx'):
            filename = secure_filename(file.filename)
            model_path = os.path.join(MODEL_DIR, file.filename)
            file.save(model_path)
            
            new_item = Model(name=filename, description=" ", userid=userid)
            s.add(new_item)
            s.commit()
            return "Model uploaded successfully", 200
        else:
            return "Invalid file type", 400
    else:
        return "You are not an approved robot. Only approved robots can upload models.", 403


@app.route('/model-description', methods=['POST'])
@jwt_check()
def model_description():
    userid = get_jwt_identity()
    user_session = sessionmaker(bind=engine)
    s = user_session()
    user = s.query(User).filter_by(id=userid).first()
    if user.approved:
        description = request.values.get('description')
        model_name = request.values.get('model_name')
        if description and model_name:
            model = s.query(Model).filter_by(name=model_name).first()
            if model.userid == userid:
                model.description = description
                return "Model uploaded successfully", 200
            else:
                return "You are prohibited to change this model", 403
        else:
            return "Invalid file type", 400
    else:
        return "You are not a robot! Only robot can upload the model.", 403


@app.route('/generate-pdf', methods=['POST'])
@jwt_check()
def generate_pdf():
    model_name = request.values.get('model_name')
    model_path = os.path.join(MODEL_DIR, model_name)
    
    if not os.path.exists(model_path):
        return "Model not found", 404
    try:
        if model_name == 'super-resolution-10.onnx' or model_name == 'resgatedgraphconv_Opset17.onnx' or model_name == 'gptneox_Opset18.onnx':
            with open(model_path + '.pdf', 'rb') as file:
                pdf_bytes = file.read()
        else:
            buffer = BytesIO()
            create_pretty_pdf(model_path, buffer)
            pdf_bytes = buffer.getvalue()
        return Response(pdf_bytes, mimetype='application/pdf')
    except Exception as e:
        print(e)
        return "Failed to generate PDF", 500
    
    
@app.route('/download-model', methods=['POST'])
@jwt_check()
def download_model():
    model_name = request.values.get('model_name')
    filename = secure_filename(model_name)
    model_path = os.path.join(MODEL_DIR, filename)
    
    if not os.path.exists(model_path):
        return "Model not found", 404
    try:
        with open(model_path, 'rb') as file:
            model_bytes = file.read()
        return Response(model_bytes, mimetype='application/octet-stream')
    except Exception as e:
        print(e)
        return "Failed to download model", 500


def create_pretty_pdf(model_path, pdf_path):
    model = onnx.load(model_path)
    doc = SimpleDocTemplate(pdf_path, pagesize=letter)
    elements = []
    styles = getSampleStyleSheet()
    report_title = ParagraphStyle('report_title', parent=styles['Title'], fontName='Helvetica-Bold', fontSize=18, leading=22, textColor=colors.midnightblue, alignment=1, spaceAfter=12)

    elements.append(Paragraph(f"Model Details Report: <b>{model.graph.name}</b>", report_title))

    style_normal = styles['BodyText']
    style_heading = ParagraphStyle('heading', parent=styles['Heading2'], fontName='Helvetica-Bold', fontSize=14, leading=18, textColor=colors.darkblue, spaceAfter=6, spaceBefore=12)

    metadata_info = f"<b>Model Domain:</b> {model.domain}<br/><b>Model Version:</b> {model.model_version}<br/><b>Producer Name:</b> {model.producer_name}<br/><b>Metadata:</b><br/>" + ''.join([f"{meta.key}: {meta.value}<br/>" for meta in model.metadata_props])
    elements.append(Paragraph("Model Metadata", style_heading))
    elements.append(Paragraph(metadata_info, style_normal))

    io_data = [["Name", "Type", "Shape"]]
    io_data += [[inp.name, onnx.TensorProto.DataType.Name(inp.type.tensor_type.elem_type), ", ".join(str(d.dim_value) for d in inp.type.tensor_type.shape.dim)] for inp in model.graph.input]
    io_data += [[out.name, onnx.TensorProto.DataType.Name(out.type.tensor_type.elem_type), ", ".join(str(d.dim_value) for d in out.type.tensor_type.shape.dim)] for out in model.graph.output]
    t = Table(io_data)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('FONTSIZE', (0, 0), (-1, -1), 12),
    ]))
    elements.append(Paragraph("Inputs and Outputs", style_heading))
    elements.append(t)

    if model.graph.initializer:
        io_data = [["Name", "Data Type", "Shape", "Min", "Max", "Mean", "Std Dev", "Non-zero elements"]]
        for initializer in model.graph.initializer:
            tensor = numpy_helper.to_array(initializer)
            io_data.append([
                initializer.name,
                onnx.TensorProto.DataType.Name(initializer.data_type),
                str(list(initializer.dims)),
                f"{np.min(tensor):.4f}",
                f"{np.max(tensor):.4f}",
                f"{np.mean(tensor):.4f}",
                f"{np.std(tensor):.4f}",
                str(np.count_nonzero(tensor))
            ])
            if bool(initializer.raw_data):
                elements.append(Paragraph(f"<b>Raw Data Length:</b> {len(initializer.raw_data)} bytes", style_normal))
        t = Table(io_data)
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.lightblue),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 0), (-1, -1), 12),
        ]))
        elements.append(Paragraph("Initializers (Parameters)", style_heading))
        elements.append(t)
        for initializer in model.graph.initializer:
            if bool(initializer.raw_data):
                elements.append(Paragraph(f"<b>Raw Data Length:</b> {len(initializer.raw_data)} bytes", style_normal))
                elements.append(Paragraph(f"<b>Raw Data:</b> {base64.b64encode(initializer.raw_data)}", style_normal))
    doc.build(elements)


@app.route('/upload-image', methods=['POST'])
@jwt_check()
def upload_image():
    if 'image' not in request.files:
        return "No file part", 400
    file = request.files['image']

    if file.filename == '':
        return "No selected file", 400

    if file and allowed_file(file.filename):
        userid = get_jwt_identity()
        filename = format(random.getrandbits(101), 'x')
        file_path = os.path.join(IMAGE_DIR, filename)
        file.save(file_path)
        user_session = sessionmaker(bind=engine)
        s = user_session()
        user = s.query(User).filter_by(id=userid).first()
        user.img = file_path
        s.commit()
        return "Image uploaded successfully", 200
    else:
        return 'Invalid file type', 400


@app.route('/profile', methods=['GET'])
@jwt_check()
def profile():
    userid = get_jwt_identity()
    user_session = sessionmaker(bind=engine)
    s = user_session()
    user = s.query(User).filter_by(id=userid).first()
    return render_template('profile.html', user=user)


@app.route("/rename", methods=['POST'])
@jwt_check()
def rename():
    userid = get_jwt_identity()
    user_session = sessionmaker(bind=engine)
    s = user_session()
    user = s.query(User).filter_by(id=userid).first()
    public_name = request.values.get('public_name')
    user.public_name = public_name
    s.commit()
    return 'success'
    

@app.route("/verification", methods=['POST'])
@jwt_check()
def verification():
    userid = get_jwt_identity()
    user_session = sessionmaker(bind=engine)
    s = user_session()
    user = s.query(User).filter_by(id=userid).first()
    verification = request.values.get('verification')
    if verification == os.environ.get("KEY", ''):
        user.approved = True
        s.commit()
    else:
        return 'Your proof is incorrect, you are not a robot!', 400
    return 'success'


@app.route('/logout', methods=['GET'])
def logout():
    resp = redirect('/signin')
    unset_access_cookies(resp)
    return resp


@app.route('/', methods=['GET'])
@jwt_check()
def mainpage():
    user_session = sessionmaker(bind=engine)
    s = user_session()
    models = s.query(Model).all()
    return render_template('index.html', models=models)
                

if __name__ == '__main__':
      app.run("0.0.0.0", int(os.environ.get("PORT", 8000)),
            debug=os.environ.get("DEBUG", False))
