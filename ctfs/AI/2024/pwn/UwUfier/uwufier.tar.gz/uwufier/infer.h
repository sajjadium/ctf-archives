#pragma once

#include <cstdint>

#include "detokenize.h"
#include "model.h"

struct Prompt {
    static constexpr size_t MAX_N_TOKENS = 128;

    // We can use `uint16_t` here because the Mamba vocabulary has less than 65536 tokens.
    uint16_t tokens[MAX_N_TOKENS]{};
};

struct Generated {
    // https://platform.openai.com/tokenizer says:
    //   > A helpful rule of thumb is that one token generally corresponds
    //   > to ~4 characters of text for common English text.
    //
    // The generated text is null-terminated.
    static constexpr size_t MAX_N_BYTES = Prompt::MAX_N_TOKENS * 4 - 1;

    // A UTF-8 sequence of bytes (+1 to make space for the trailing null byte).
    char bytes[MAX_N_BYTES + 1]{};
};

__global__ void Infer(Generated* generated,
                      const Prompt* prompt,
                      size_t prompt_len,
                      const Detokenizer* detokenizer,
                      const MambaModel* model);
