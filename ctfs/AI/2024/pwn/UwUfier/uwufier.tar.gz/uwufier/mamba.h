#pragma once

#include "model.h"

#include <utility>

// Stored in shared memory.
struct MambaState {
    float hidden[D_MODEL];
    float normed[D_MODEL];
    float tmp   [D_INNER];

    float pre_dt[D_PRE_DT];
    float b     [D_STATE];
    float c     [D_STATE];
};

// Stored in local memory (or registers, if we have enough of them).
struct MambaThreadState {
    float conv_state[N_LAYERS][D_CONV ][E];
    float ssm_state [N_LAYERS][D_STATE][E];
};

constexpr int WARP_SIZE          = 32;
constexpr int WARP_COUNT         = D_MODEL / WARP_SIZE;
constexpr int XP_WARP_CHUNK      = D_INNER / WARP_SIZE;

template <typename T, typename F>
__device__ __forceinline__ T WarpReduce(T tt, const F& f) {
    #pragma unroll
    for (int lane_mask = 1; lane_mask < WARP_SIZE; lane_mask *= 2) {
        tt = f(tt, __shfl_xor_sync(0xFF'FF'FF'FFU, tt, lane_mask));
    }
    return tt;
}

template <typename T, typename F>
__device__ __forceinline__ T BlockReduce(T tt, T identity, const F& f) {
    __shared__ T warp_res[WARP_COUNT];

    const int tid     = threadIdx.x;
    const int lane_id = tid % WARP_SIZE;
    const int warp_id = tid / WARP_SIZE;

    T res = WarpReduce(tt, f);
    if (lane_id == 0) {
        warp_res[warp_id] = res;
    }
    __syncthreads();

    res = WarpReduce(lane_id < WARP_COUNT ? warp_res[lane_id] : identity, f);
    __syncthreads();

    return res;
}

__device__ __forceinline__ float AddFloats(float xx, float yy) {
    return xx + yy;
}

// `{in,out}_vals` are in shared memory, `weight` is in global memory.
__device__ void RmsNorm(const float* in_vals, float* out_vals, const float* weight) {
    const int tid = threadIdx.x;

    const float val = in_vals[tid];
    const float ss = BlockReduce(val * val, 0.0f, AddFloats);
    out_vals[tid] = in_vals[tid] * weight[tid] * rsqrtf(ss / D_MODEL + 1e-5);
    __syncthreads();
}

__device__ __forceinline__ float Silu(float xx) {
    return xx / (1.0f + expf(-xx));
}

__device__ __forceinline__ float Softplus(float xx) {
    return log1pf(expf(xx));
}

__device__ void ProcessToken(const MambaModel* model, uint16_t token,
                             MambaState* state, MambaThreadState* thread_state) {
    const int tid = threadIdx.x;
    const int lane_id = tid % WARP_SIZE;
    const int warp_id = tid / WARP_SIZE;

    auto& conv_state = thread_state->conv_state;
    auto& ssm_state  = thread_state->ssm_state;

    state->hidden[tid] = model->embs[token][tid];
    __syncthreads();

    for (int lid = 0; lid < N_LAYERS; ++lid) {
        const auto* layer = model->Layer(lid);
        RmsNorm(state->hidden, state->normed, layer->norm);

        // Shift the 1D convolution state.
        #pragma unroll
        for (int ii = 0; ii + 1 < D_CONV; ++ii) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                conv_state[lid][ii][ee] = conv_state[lid][ii + 1][ee];
            }
        }
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            conv_state[lid][D_CONV - 1][ee] = 0.0f;
        }

        // Input projection + gating.
        float gate[E] = {};
        const auto* inp = layer->in_proj;
        for (int kk = 0; kk < D_MODEL; ++kk) {
            const float hh = state->normed[kk];

            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                conv_state[lid][D_CONV - 1][ee] += hh * inp[E*tid + ee + 0      ][kk];
                gate[ee]                        += hh * inp[E*tid + ee + D_INNER][kk];
            }
        }

        // 1D convolution.
        float conv_res[E];
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            conv_res[ee] = layer->conv_bias[E*tid + ee];
        }
        const auto* cww = layer->conv_weight;
        #pragma unroll
        for (int ch = 0; ch < D_CONV; ++ch) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                conv_res[ee] += cww[E*tid + ee][ch] * conv_state[lid][ch][ee];
            }
        }
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            state->tmp[E*tid + ee] = Silu(conv_res[ee]);
        }
        __syncthreads();

        // Selective projection: compute pre-Δ, B, and C.
        float pre_dt[E] = {};
        float b         = 0.0f;
        float c         = 0.0f;
        const bool have_bc = warp_id < D_STATE;
        const int start_kk = lane_id * XP_WARP_CHUNK;
        const int end_kk   = start_kk + XP_WARP_CHUNK;
        const auto* xp     = layer->x_proj;
        for (int kk = start_kk; kk < end_kk; ++kk) {
            const float hh = state->tmp[kk];

            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                pre_dt[ee] += hh * xp[2*warp_id + ee][kk];
            }

            b += have_bc   ? (hh * xp[1*warp_id + D_PRE_DT + 0      ][kk]) : 0.0f;
            c += have_bc   ? (hh * xp[1*warp_id + D_PRE_DT + D_STATE][kk]) : 0.0f;
        }
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            pre_dt[ee] = WarpReduce(pre_dt[ee], AddFloats);
        }
        b = WarpReduce(b, AddFloats);
        c = WarpReduce(c, AddFloats);
        if (lane_id == 0) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                state->pre_dt[2*warp_id + ee] = pre_dt[ee];
            }
            if (have_bc) {
                state->b[warp_id] = b;
                state->c[warp_id] = c;
            }
        }
        __syncthreads();

        // Selective projection: compute Δ.
        float delta[E];
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            delta[ee] = layer->dt_bias[E*tid + ee];
        }
        const auto* dtp = layer->dt_weight;
        for (int kk = 0; kk < D_PRE_DT; ++kk) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                delta[ee] += state->pre_dt[kk] * dtp[E*tid + ee][kk];
            }
        }
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            delta[ee] = Softplus(delta[ee]);
        }

        // Selective state space model.
        float ssm_out[E];
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            ssm_out[ee] = layer->d[E*tid + ee] * state->tmp[E*tid + ee];
        }
        #pragma unroll
        for (int ss = 0; ss < D_STATE; ++ss) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                const float a  = -expf(layer->a_log[E*tid + ee][ss]);
                const float dt = delta[ee];
                const float lhs = ssm_state[lid][ss][ee] * expf(a       * dt);
                const float rhs = state->tmp[E*tid + ee] * state->b[ss] * dt;
                ssm_state[lid][ss][ee] = lhs + rhs;
                ssm_out[ee] += ssm_state[lid][ss][ee] * state->c[ss];
            }
        }
        #pragma unroll
        for (int ee = 0; ee < E; ++ee) {
            state->tmp[E*tid + ee] = ssm_out[ee] * Silu(gate[ee]);
        }
        __syncthreads();

        // Output projection.
        const auto* op = layer->out_proj;
        for (int kk = 0; kk < D_INNER; kk += E) {
            #pragma unroll
            for (int ee = 0; ee < E; ++ee) {
                state->hidden[tid] += state->tmp[kk + ee] * op[tid][kk + ee];
            }
        }
        __syncthreads();
    }
}

__device__ uint16_t SelectMostProbableToken(const MambaModel* model, MambaState* state) {
    RmsNorm(state->hidden, state->normed, model->out_norm);

    const int tid = threadIdx.x;

    constexpr int SMALL_N_TOKENS = VOCAB_SIZE / D_MODEL;
    constexpr int LARGE_N_TOKENS = SMALL_N_TOKENS + 1;
    constexpr int LARGE_THREADS  = VOCAB_SIZE % D_MODEL;

    int n_tokens, start_token;
    if (tid < LARGE_THREADS) {
        n_tokens    = LARGE_N_TOKENS;
        start_token = tid * LARGE_N_TOKENS;
    } else {
        n_tokens    = SMALL_N_TOKENS;
        start_token = (tid - LARGE_THREADS) * SMALL_N_TOKENS + LARGE_THREADS * LARGE_N_TOKENS;
    }

    union Candidate {
        struct {
            float    logit;
            unsigned token;
        };
        unsigned long long packed;
    };

    Candidate cand;

    for (int tkn = start_token; tkn < start_token + n_tokens; ++tkn) {
        float logit = 0.0f;
        for (int kk = 0; kk < D_MODEL; ++kk) {
            logit += state->normed[kk] * model->embs[tkn][kk];
        }

        if (tkn == start_token || logit > cand.logit) {
            cand.logit = logit;
            cand.token = tkn;
        }
    }

    const auto compare = [](unsigned long long aa, unsigned long long bb) {
        Candidate cand_a{.packed = aa};
        Candidate cand_b{.packed = bb};
        return cand_a.logit > cand_b.logit ? aa : bb;
    };

    const Candidate dummy_cand{{.logit = -INFINITY, .token = USHRT_MAX}};
    cand.packed = BlockReduce(cand.packed, dummy_cand.packed, compare);
    return cand.token;
}
