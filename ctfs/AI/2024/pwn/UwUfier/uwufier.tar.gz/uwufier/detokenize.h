#pragma once

#include <memory>

#include "model.h"

struct Detokenizer {
    uint32_t starts[VOCAB_SIZE];
    uint32_t lens  [VOCAB_SIZE];
    char     concat[];
};

using OwnedDetokenizer = std::unique_ptr<Detokenizer, void(*)(void*)>;
OwnedDetokenizer LoadDetokenizerToGpu(const char* file_name);
