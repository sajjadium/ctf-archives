import json
import re
import struct
from pathlib import Path


# See https://github.com/openai/gpt-2/blob/9b63575ef42771a015060c964af2c3da4cf7c8ab/src/encoder.py#L9
def unicode_to_bytes():
    bs = list(range(ord("!"), ord("~")+1))+list(range(ord("¡"), ord("¬")+1))+list(range(ord("®"), ord("ÿ")+1))
    cs = bs[:]
    n = 0
    for b in range(2**8):
        if b not in bs:
            bs.append(b)
            cs.append(2**8+n)
            n += 1
    cs = [chr(n) for n in cs]
    return dict(zip(cs, bs))


if __name__ == '__main__':
    with open('./tokenizer.json') as f:
        vocab = json.load(f)['model']['vocab']

    u2b = unicode_to_bytes()
    starts = []
    lens   = []
    concat = bytearray()

    prev_tkn_id = -1
    for tkn, tkn_id in vocab.items():
        assert tkn_id == prev_tkn_id + 1
        tkn_bytes = bytearray()
        for ch in tkn:
            if ch in u2b:
                tkn_bytes.append(u2b[ch])
            else:
                tkn_bytes.extend(ch.encode())
        starts.append(len(concat))
        lens.append(len(tkn_bytes))
        concat.extend(tkn_bytes)
        prev_tkn_id = tkn_id

    vocab_size = int(
        re.search(
            r'''VOCAB_SIZE = (\d+)''',
            Path('model.h').read_text()
        ).group(1)
    )

    # Collapse tokens that are not explicitly present to empty strings.
    while len(starts) < vocab_size:
        starts.append(starts[-1])
        lens.append(0)

    with open('./detokenizer', 'wb') as f:
        for st in starts:
            f.write(struct.pack('<I', st))
        for ll in lens:
            f.write(struct.pack('<I', ll))
        f.write(concat)
