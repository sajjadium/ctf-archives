Our tiny kernel uses only one SM to generate the whole uwuified text!

![Can you read the flag by exploiting it?](https://img.vos.uz/f5voes9c.png)

### Disclaimer

**You probably need an NVIDIA GPU for this challenge**

It is theoretically possible to solve the challenge without one, just by carefully reading the code and inspecting the binary. However, having a GPU from NVIDIA will greatly simplify the debugging process. Any GPU with compute capability 5.0 or greater should work.

If you don't have a GPU but still want to take a stab at the challenge, there are plenty of cloud options: Vultr.com has a cheap 1/8 NVidia A16 plan for 6 ¢/hour, but others are perfectly fine too (AWS, vast.ai, Lambda Labs, etc). Here's our Vultr ref link if you're interested: https://www.vultr.com/?ref=9217234-8H

### Setup

We're giving you the source code and the Dockerfile *for the inference service only*. The rest of the challenge is just a simple web frontend for orchestrating the inference process, and is not supposed to be exploited (you can try though).

You can start by building the given docker image and running it by giving the prompt in the following format:

```
$ echo -n $'Normal text: YOUR_TEXT_HERE\nUwU text:' | docker run --gpus=all -i uwu
```

Here's an example session. If your output matches what is shown below, everything is working as intended:

```
# echo -n $'Normal text: Welcome to AI CTF!\nUwU text:' | docker run --gpus=all -i uwu

==========
== CUDA ==
==========

CUDA Version 12.0.0

Container image Copyright (c) 2016-2023, NVIDIA CORPORATION & AFFILIATES. All rights reserved.

This container image and its contents are governed by the NVIDIA Deep Learning Container License.
By pulling and using the container, you accept the terms and conditions of this license:
https://developer.nvidia.com/ngc/nvidia-deep-learning-container-license

A copy of this license is made available in this container at /NGC-DL-CONTAINER-LICENSE for your convenience.

*************************
** DEPRECATION NOTICE! **
*************************
THIS IMAGE IS DEPRECATED and is scheduled for DELETION.
    https://gitlab.com/nvidia/container-images/cuda/blob/master/doc/support-policy.md

Normal text: Welcome to AI CTF!
UwU text: Wewcome to AI CTF!! *cheers*
```

The flag is located in `/aictf/flag.txt`. Trick the inference server into revealing it. Happy hacking!

### Hints

* The frontend will print the stderr of the inference service only if the stderr is non-empty; otherwise it will print its stdout (and also strip the prompt from the stdout).
* We've checked that the Dockerfile we give to you produces identical containers on different machines, but we're still giving you the exact inference binary (`main`) running on the server. Just in case. It might be important. Or not.
* The model used in the inference service is a finetuned version of [Mamba 130M](https://huggingface.co/state-spaces/mamba-130m-hf) converted to the `safetensors` format. [Here's the original PyTorch checkpoint](https://big.vos.uz/pytorch_model.bin) if you want to use it in PyTorch.
* You should focus on reading `infer.cu`, `main.cu`, and `utf8.h`. Technically, most of the code is in `mamba.h`, however it is just an ad-hoc implementation of [Mamba](https://arxiv.org/abs/2312.00752) in CUDA and is not supposed to contain bugs (you can try finding some, of course).
