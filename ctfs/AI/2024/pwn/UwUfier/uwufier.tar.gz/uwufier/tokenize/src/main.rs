// Inspired by https://github.com/huggingface/tokenizers/tree/main/tokenizers#loading-a-pretrained-tokenizer-from-the-hub
use std::io::Read;
use tokenizers::tokenizer::{Result, Tokenizer};

fn main() -> Result<()> {
    let tokenizer = Tokenizer::from_pretrained("state-spaces/mamba-130m-hf", None)?;
    let mut text = String::new();
    std::io::stdin().read_to_string(&mut text)?;
    let encoding = tokenizer.encode(text, false)?;
    println!("{}", encoding.len());
    println!(
        "{}",
        encoding
            .get_ids()
            .iter()
            .map(|x| x.to_string())
            .collect::<Vec<_>>()
            .join(" ")
    );
    Ok(())
}
