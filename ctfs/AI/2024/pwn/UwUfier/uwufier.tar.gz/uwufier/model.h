#pragma once

#include <cstddef>
#include <memory>

constexpr size_t VOCAB_SIZE = 50280;
constexpr size_t E          = 2;
constexpr size_t D_MODEL    = 768;
constexpr size_t D_INNER    = E * D_MODEL;
constexpr size_t D_CONV     = 4;
constexpr size_t D_STATE    = 16;
constexpr size_t D_PRE_DT   = D_MODEL / 16;
constexpr size_t N_LAYERS   = 24;

struct MambaLayer {
    float a_log      [D_INNER][D_STATE];
    float d          [D_INNER];
    float conv_bias  [D_INNER];
    float conv_weight[D_INNER][D_CONV];
    float dt_bias    [D_INNER];
    float dt_weight  [D_INNER][D_PRE_DT];
    float in_proj    [2*D_INNER][D_MODEL];
    float out_proj   [D_MODEL][D_INNER];
    float x_proj     [D_PRE_DT + 2*D_STATE][D_INNER];
    float norm       [D_MODEL];
};

struct MambaModel {
    float      embs    [VOCAB_SIZE][D_MODEL];
    MambaLayer layers  [N_LAYERS];
    float      out_norm[D_MODEL];

    __host__ __device__ const MambaLayer* Layer(size_t layer_idx) const {
        // Re-shuffle the alphabetically sorted layers in the original model file.
        if (layer_idx >= 10 && layer_idx <= 19) {
            layer_idx -= 8;
        } else if (layer_idx == 2) {
            layer_idx = 12;
        } else if (layer_idx >= 20 && layer_idx <= 23) {
            layer_idx -= 7;
        } else if (layer_idx >= 3 && layer_idx <= 9) {
            layer_idx += 14;
        }
        return &layers[layer_idx];
    }
};

using OwnedMambaModel = std::unique_ptr<MambaModel, void(*)(void*)>;
OwnedMambaModel LoadModelToGpu(const char* file_name);
