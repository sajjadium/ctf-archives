#include <cub/cub.cuh>

template <unsigned THREAD_COUNT>
__device__ void FixUtf8(char* bytes, unsigned in_len, size_t* out_len) {
    const int tid = threadIdx.x;

    // https://www.fileformat.info/info/unicode/char/fffd/index.htm
    const char fffd[3] = {0xEF, 0xBF, 0xBD};
    constexpr unsigned char min_cont = 0x80;
    constexpr unsigned char max_cont = 0xBF;
    const auto is_cont = [](unsigned char ch) {
        return ch >= min_cont && ch <= max_cont;
    };

    unsigned n_total             = 0;
    unsigned n_valid             = 0;
    unsigned n_fffd              = 0;
    unsigned char valid_bytes[4] = {};
    unsigned cursor              = tid;

    auto check_byte = [&](unsigned idx, unsigned char lb, unsigned char ub) {
        if (n_valid == 0) {
            return;
        }
        if (cursor >= in_len) {
            n_valid = 0;
            return;
        }
        valid_bytes[idx] = bytes[cursor];
        if (valid_bytes[idx] < lb || valid_bytes[idx] > ub) {
            n_valid = 0;
            return;
        }
        ++cursor;
        ++n_valid;
    };

    auto check_cont = [&](unsigned idx) {
        return check_byte(idx, min_cont, max_cont);
    };

    unsigned leading_stray_cont = 0;
    while (leading_stray_cont < in_len && is_cont(bytes[leading_stray_cont])) {
        ++leading_stray_cont;
    }

    if (cursor < in_len) {
        // "This will get messy" © Andrej Karpathy
        // https://github.com/karpathy/llama2.c/blob/b3c4b6c3c4bbff42e5211293280307019368ccb5/run.c#L487
        unsigned char fst = bytes[cursor++];

        if (!is_cont(fst)) {
            valid_bytes[0]    = fst;
            n_valid           = 1;

            // See Table 3.7 in the Unicode standard.
            if (fst >= 0xC2 && fst <= 0xDF) {
                check_cont(1);
            } else if (fst >= 0xE0 && fst <= 0xEF) {
                check_byte(1, fst == 0xE0 ? 0xA0 : min_cont, fst == 0xED ? 0x9F : max_cont);
                check_cont(2);
            } else if (fst >= 0xF0 && fst <= 0xF4) {
                check_byte(1, fst == 0xF0 ? 0x90 : min_cont, fst == 0xF4 ? 0x8F : max_cont);
                check_cont(2);
                check_cont(3);
            } else {
                n_valid = fst <= 0x7F ? 1 : 0;
            }

            if (n_valid == 0) {
                ++n_fffd;
            }

            while (cursor < in_len && is_cont(bytes[cursor])) {
                ++n_fffd;
                ++cursor;
            }

            n_total = n_valid + sizeof(fffd) * n_fffd;
        }
    }

    __syncthreads();

    using BlockScan = cub::BlockScan<unsigned, THREAD_COUNT>;
    __shared__ typename BlockScan::TempStorage tmp;

    unsigned n_cum;
    BlockScan(tmp).ExclusiveSum(n_total, n_cum);

    if (tid == 0) {
        for (unsigned ii = 0; ii < leading_stray_cont; ++ii) {
            memcpy(bytes + ii * sizeof(fffd), fffd, sizeof(fffd));
        }
    }

    n_cum += leading_stray_cont * sizeof(fffd);
    memcpy(bytes + n_cum, valid_bytes, n_valid);
    for (unsigned ii = 0; ii < n_fffd; ++ii) {
        memcpy(bytes + n_cum + n_valid + ii * sizeof(fffd), fffd, sizeof(fffd));
    }

    // The last thread knows the final length after the bytes are fixed.
    if (out_len && tid + 1 == THREAD_COUNT) {
        *out_len = n_cum + n_total;
    }
}

