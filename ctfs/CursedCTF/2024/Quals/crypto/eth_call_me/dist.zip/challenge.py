from ctf_launchers.launcher import Launcher


class Challenge(Launcher):
    pass

Challenge("challenge/contracts").run()
