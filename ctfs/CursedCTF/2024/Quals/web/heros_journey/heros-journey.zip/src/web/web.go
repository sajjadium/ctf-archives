package web

import (
	"database/sql"
	"embed"
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"os"
	"strconv"
	"sync"

	"github.com/google/uuid"
	"movitz.dev/heros-journey/src/db"
	"movitz.dev/heros-journey/src/models"
)

//go:embed templates/*
var templates embed.FS

const cookieName = "hjaeltekaka"

var lock *sync.Mutex = &sync.Mutex{} // no funny business!

type Server struct {
	db      *sql.DB
	flaggan string
}

func New(db *sql.DB) *Server {
	return &Server{
		db:      db,
		flaggan: os.Getenv("FLAG"),
	}
}

func (s *Server) RegisterRoutes(x *http.ServeMux) {

	x.HandleFunc("/", s.index)
	x.HandleFunc("/hero", s.hero)
	x.HandleFunc("/create_hero", s.createHero)
	x.HandleFunc("/update_event", s.updateEvent)
	x.HandleFunc("/flag", s.flag)

}

func (s *Server) index(rw http.ResponseWriter, req *http.Request) {

	c, err := req.Cookie(cookieName)
	if err == http.ErrNoCookie {
		c = &http.Cookie{
			Name:  cookieName,
			Value: uuid.NewString(),
		}
		http.SetCookie(rw, c)
	}

	t, _ := template.ParseFS(templates, "templates/index.html")

	d := db.New(s.db, uuid.MustParse(c.Value))

	heroes, err := d.GetHeros(req.Context())
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	t.Execute(rw, map[string]interface{}{
		"heroes": heroes,
	})
}

func (s *Server) hero(rw http.ResponseWriter, req *http.Request) {
	lock.Lock()
	defer lock.Unlock()

	c, err := req.Cookie(cookieName)
	if err == http.ErrNoCookie {
		c = &http.Cookie{
			Name:  cookieName,
			Value: uuid.NewString(),
		}
		http.SetCookie(rw, c)
	}

	d := db.New(s.db, uuid.MustParse(c.Value))

	hero, err := d.GetHero(req.Context())
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	t, err := template.ParseFS(templates, "templates/hero.html")
	if err != nil {
		fmt.Println(err.Error())
		return
	}

	t.Execute(rw, map[string]interface{}{
		"hero": hero,
	})
}

func (s *Server) createHero(rw http.ResponseWriter, req *http.Request) {
	lock.Lock()
	defer lock.Unlock()

	c, err := req.Cookie(cookieName)
	if err != nil {
		rw.WriteHeader(http.StatusBadRequest)
		rw.Write([]byte{0x6e, 0x61, 0x68, 0x20, 0x62, 0x72, 0x75, 0x68})
		return
	}
	tenant := uuid.MustParse(c.Value)

	d := db.New(s.db, tenant)

	if h, _ := d.GetHero(req.Context()); h != nil {
		rw.WriteHeader(http.StatusBadRequest)
		rw.Write([]byte("because of unintended solutions stemming from multiple paralell storylines, we cannot provide you with a second story, it would just be unfair to the challenge author who wants to see you suffer"))
		return
	}

	events := []*models.Event{}

	err = json.Unmarshal([]byte(req.URL.Query().Get("events")), &events)
	if err != nil {
		rw.WriteHeader(http.StatusBadRequest)
		rw.Write([]byte("bad json"))
		return
	}

	last := 0
	for _, e := range events {
		if int(e.Type) != last && int(e.Type) != last+1 { // jikes
			rw.Write([]byte("Get your words straight, Jack!"))
			return
		}
		last = int(e.Type)
	}

	id, err := d.CreateHero(req.Context(), req.URL.Query().Get("name"), events)
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	http.Redirect(rw, req, "/hero?id="+strconv.Itoa(id), http.StatusFound)
}

func (s *Server) flag(rw http.ResponseWriter, req *http.Request) {
	lock.Lock()
	defer lock.Unlock()

	c, err := req.Cookie(cookieName)
	if err != nil {
		rw.WriteHeader(http.StatusBadRequest)
		rw.Write([]byte{0x6e, 0x61, 0x68, 0x20, 0x62, 0x72, 0x75, 0x68})
		return
	}
	tenant := uuid.MustParse(c.Value)

	d := db.New(s.db, tenant)

	hero, err := d.GetHero(req.Context())
	if err != nil {
		rw.Write([]byte("404"))
		return
	}

	story, err := simulate(hero.Events)
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	if story.andTheyWereHappyEverAfter {
		rw.Write([]byte("a nice, feel good story, worthy of a flag: " + s.flaggan))
		return
	}

	rw.Write([]byte("such a bummer"))

}

func (s *Server) updateEvent(rw http.ResponseWriter, req *http.Request) {
	lock.Lock()
	defer lock.Unlock()

	c, err := req.Cookie(cookieName)
	if err != nil {
		rw.WriteHeader(http.StatusBadRequest)
		rw.Write([]byte{0x6e, 0x61, 0x68, 0x20, 0x62, 0x72, 0x75, 0x68})
		return
	}
	tenant := uuid.MustParse(c.Value)

	db := db.New(s.db, tenant)

	hero, err := db.GetHero(req.Context())
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	last := 0
	for _, e := range hero.Events {
		if int(e.Type) != last && int(e.Type) != last+1 { // jikes
			rw.Write([]byte("Get your words straight, Jack"))
			return
		}
		last = int(e.Type)
	}

	id, _ := strconv.Atoi(req.URL.Query().Get("id"))

	err = db.UpdateEvent(req.Context(), id, req.URL.Query().Get("description"))
	if err != nil {
		rw.Write([]byte(err.Error()))
		return
	}

	rw.Write([]byte("changing your story is unorthodox, but necessary in todays world of flag-worthiness"))

}
