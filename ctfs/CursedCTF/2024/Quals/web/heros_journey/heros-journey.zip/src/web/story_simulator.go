package web

import (
	"errors"
	"fmt"

	"movitz.dev/heros-journey/src/db"
	"movitz.dev/heros-journey/src/models"
)

type StorySimulation struct {
	adventureAccepted           bool
	andTheyWereHappyEverAfter   bool
	mentorAlive                 bool
	inKnownWorld                bool
	abyssDone                   bool
	emotionalTransformationDone bool // THIS IS NEEDED. PEOPLE ARE CHEATING THEIR WAY THROUGH STRUCTURING STORIES. WHAT HAS HAPPENED TO OUR SOCIETY, REALLY
}

func NewStorySimulation() *StorySimulation {
	return &StorySimulation{
		adventureAccepted:           false,
		mentorAlive:                 false,
		andTheyWereHappyEverAfter:   false,
		inKnownWorld:                true,
		abyssDone:                   false,
		emotionalTransformationDone: false,
	}
}

func simulate(events []*db.Event) (*StorySimulation, error) {
	ss := NewStorySimulation()

	for _, e := range events {
		switch e.Type {
		case models.CallToAdventure:

			if !ss.inKnownWorld {
				return nil, errors.New("what the hecking d...")
			}

		case models.Refusal:
			ss.adventureAccepted = false

		case models.MeetingMentor:
			ss.mentorAlive = true
			ss.adventureAccepted = true

		case models.CrossingThreashold:
			if !ss.adventureAccepted {
				return nil, errors.New("that doesn't make any sense!")
			}
			ss.inKnownWorld = false

		case models.Abyss:
			if ss.inKnownWorld {
				return nil, errors.New("wrong place")
			}

			ss.abyssDone = true

		case models.DeathOfMentor:

			if ss.inKnownWorld {
				return nil, errors.New("keep your facts straight")
			}

			ss.mentorAlive = false
			ss.emotionalTransformationDone = true

		case models.Return:

			if !ss.abyssDone {
				return nil, errors.New("need to abyss yourself first!")
			}

			if ss.inKnownWorld {
				return nil, errors.New("returning in wierd ways are for the pwn people! stop trying to be quirky")
			}

			if !ss.emotionalTransformationDone {
				return nil, errors.New("don't try to trick me again! get your act together")
			}

			if ss.mentorAlive {
				ss.andTheyWereHappyEverAfter = true
			}

			ss.inKnownWorld = true

			return ss, nil

		default:
			fmt.Println(e.Type)
			return nil, errors.New("are you mad!?")
		}
	}
	return nil, errors.New("oi bruv")
}
