package db

import (
	"context"
	"database/sql"
	_ "embed"
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/google/uuid"
	"movitz.dev/heros-journey/src/models"
)

//go:embed up.sql
var upSQL string

type Hero struct {
	ID        string
	Name      string
	CreatedAt time.Time

	Events []*Event
}

type Event struct {
	ID          int
	Type        models.StoryStage
	Description string
	UpdatedAt   time.Time
}

type DB struct {
	db     *sql.DB
	schema string
}

func New(db *sql.DB, tenant uuid.UUID) *DB {

	schema := "hero_" + strings.ReplaceAll(tenant.String(), "-", "")

	_, err := db.Exec(strings.ReplaceAll(`CREATE SCHEMA "THE_SCHEMA"`, "THE_SCHEMA", schema))
	_, err = db.Exec(strings.ReplaceAll(upSQL, "THE_SCHEMA", schema))
	if err != nil {
		log.Println(err.Error())
	}

	return &DB{
		db:     db,
		schema: schema,
	}
}

func (b *DB) GetHeros(ctx context.Context) ([]*Hero, error) {

	_, err := b.db.Exec(fmt.Sprintf(`SET search_path TO "%s";`, b.schema))
	if err != nil {
		return nil, err
	}

	row, err := b.db.QueryContext(ctx, "SELECT id, name, created_at FROM heroes")
	if err != nil {
		return nil, err
	}

	heroes := []*Hero{}

	for row.Next() {

		hero := &Hero{}
		err = row.Scan(&hero.ID, &hero.Name, &hero.CreatedAt)
		if err != nil {
			return nil, err
		}

		heroes = append(heroes, hero)
	}

	return heroes, nil

}

func (b *DB) GetHero(ctx context.Context) (*Hero, error) {

	_, err := b.db.Exec(fmt.Sprintf(`SET search_path TO "%s";`, b.schema))
	if err != nil {
		return nil, err
	}

	row := b.db.QueryRowContext(ctx, "SELECT id, name, created_at FROM heroes")
	if err := row.Err(); err != nil {
		return nil, err
	}

	hero := &Hero{
		Events: []*Event{},
	}
	err = row.Scan(&hero.ID, &hero.Name, &hero.CreatedAt)
	if err != nil {
		return nil, err
	}

	rows, err := b.db.QueryContext(ctx, "SELECT id, type, description, updated_at FROM events")
	if err != nil {
		return nil, err
	}

	for rows.Next() {
		event := &Event{}
		err = rows.Scan(&event.ID, &event.Type, &event.Description, &event.UpdatedAt)
		if err != nil {
			return nil, err
		}
		hero.Events = append(hero.Events, event)
	}

	return hero, nil
}

func (b *DB) CreateHero(ctx context.Context, name string, events []*models.Event) (int, error) {

	_, err := b.db.ExecContext(ctx, fmt.Sprintf(`SET search_path TO "%s";`, b.schema))
	if err != nil {
		return 0, err
	}

	res := b.db.QueryRowContext(ctx, "INSERT INTO heroes (name) VALUES ($1) RETURNING id", name)
	if err := res.Err(); err != nil {
		return 0, err
	}

	var heroID int
	err = res.Scan(&heroID)
	if err != nil {
		return 0, err
	}

	for _, e := range events {
		_, err = b.db.ExecContext(ctx, "INSERT INTO events (hero_id, description, type) VALUES ($1, $2, $3)", heroID, e.Description, e.Type)
		if err != nil {
			return 0, err
		}
	}

	return heroID, nil
}

func (b *DB) UpdateEvent(ctx context.Context, eventID int, description string) error {

	_, err := b.db.Exec(fmt.Sprintf(`SET search_path TO "%s";`, b.schema))
	if err != nil {
		return err
	}

	query := "UPDATE events SET "
	args := []any{eventID}
	if description != "" {

		query += "description = $2, "
		args = append(args, description)
	}

	query += "updated_at = NOW() WHERE id = $1"

	_, err = b.db.Exec(query, args...)
	return err
}
