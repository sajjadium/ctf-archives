package models

type StoryStage int

const (
	CallToAdventure StoryStage = iota
	Refusal
	MeetingMentor
	CrossingThreashold
	Abyss
	DeathOfMentor
	Return
)

func ToStoryStage(x string) StoryStage {
	switch x {

	case "call_to_adventure":
		return CallToAdventure

	default:
		panic("no")
	}
}

type Event struct {
	Type        StoryStage `json:"type"`
	Description string     `json:"description"`
}
