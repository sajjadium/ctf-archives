package main

import (
	"database/sql"
	"fmt"
	"net/http"
	"os"

	_ "github.com/lib/pq"
	"movitz.dev/heros-journey/src/web"
)

func main() {
	err := realMain()
	if err != nil {
		fmt.Println(err.Error())
		os.Exit(1)
	}
}

func realMain() error {

	db, err := sql.Open("postgres", "postgresql://postgres:postgres@db/postgres?sslmode=disable")
	if err != nil {
		return err
	}

	s := web.New(db)

	mx := http.NewServeMux()
	s.RegisterRoutes(mx)
	return http.ListenAndServe(":8080", mx)
}
