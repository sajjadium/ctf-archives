#!/bin/sh
A="${1:-QwQ)}"
B="${2:-QuQ}"
if [ $A = 'uwu' ]
then 
    git checkout OwO_QvQ_UvU_u3u_qwq_uWu_UuU_OvO_q3q_0u0 2>/dev/null
    exec ./check_flag.sh 78 79 80 83 84
elif [ $B = 'OwO' ]
then 
    git checkout OwO_UvU_QwQ_OVO_oVo_OuO_uvu_oUo_oUo_0V0 2>/dev/null
    exec ./check_flag.sh
elif [ $A = '>w<' ]
then 
    echo 'You got the flag <^3^>'
elif [ $A = 'QuQ' ]
then 
    echo 'No flag for u ^<QwQ>^'
else
    read -p "Enter flag: " flag
    echo $flag > flag.txt
    git checkout OwO_o3o_u3u_0W0_0v0_OUO_UUU_oVo_O3O_qWq 2>/dev/null
    exec ./check_flag.sh
fi
