use std::fs::File;
use std::io::prelude::*;
use runner::{Problem, run_server};
use tracing::{Level, error};
struct FizzBuzz;



impl Problem for FizzBuzz {
    fn test_case_len() -> usize {
        1
    }

    fn generate_input(idx: usize) -> Vec<u8> {
        (0..100).map(|x| x.to_string()).collect::<Vec<String>>().join("\n").as_bytes().to_vec()
    }

    fn check_output(input: &[u8], output: &[u8]) -> bool {
        String::from_utf8_lossy(output).split('\n').enumerate().filter(|(idx, line)| {
            match (idx % 3, idx % 5) {
                (0, 0) => line == &"FizzBuzz",
                (0, _) => line == &"Fizz",
                (_, 0) => line == &"Buzz",
                _ => line == &idx.to_string(),
            }
        }).count() == 100
    }
    
    fn redis_host() -> &'static str {
        "redis://redis-service.jsrcds-prd-golf-fizzbuzz.svc.cluster.local/"
    }
    
    fn score(input: &[u8]) -> usize {
        input.into_iter().map(|x| x.count_ones() as usize).sum()
    }
    
    fn name() -> &'static str {
        "fizzbuzz"
    }
    
    fn fmt_fail(best: usize) -> String {
        format!("your payload must contain fewer than {} 1 bits", best)
    }
}

#[tokio::main]
async fn main() {
    let collector = tracing_subscriber::fmt()
        // filter spans/events with level TRACE or higher.
        .with_max_level(Level::TRACE)
        .with_ansi(false)
        // build but do not install the subscriber.
        .init();
    // make_test_cases();
    if let Err(e) = run_server::<FizzBuzz>().await {
        error!("{}", e);
    }

}
