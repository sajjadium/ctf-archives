use std::fs::File;
use std::io::prelude::*;
use runner::{Problem, run_server};
use tracing::{Level, error};
struct PalindromeNumber;



impl Problem for PalindromeNumber {
    fn test_case_len() -> usize {
        4
    }

    fn generate_input(idx: usize) -> Vec<u8> {
        [
            0i32,
            12,
            121,
            -121
        ][idx].to_le_bytes().to_vec()
    }

    fn check_output(input: &[u8], output: &[u8]) -> bool {
        if input.len() < 4 || output.len() < 4  {
            return false;
        }
        pub fn is_palindrome(x: i32) -> i32 {
            let (mut rev, mut org) = (0,x);
            
            while org>0 {
                rev = (rev*10) + org%10;
                org/=10;
            }
            
            if rev == x { 1 } else { 0 }
        }
        is_palindrome(i32::from_le_bytes(input[0..4].try_into().unwrap())) == i32::from_le_bytes(output[0..4].try_into().unwrap())
    }
    
    fn redis_host() -> &'static str {
        "redis://redis-service.jsrcds-prd-golf-palindromenumber.svc.cluster.local/"
    }
    
    fn score(input: &[u8]) -> usize {
        input.into_iter().map(|x| x.count_zeros() as usize).sum()
    }
    
    fn name() -> &'static str {
        "palindrome_number"
    }
    
    fn fmt_fail(best: usize) -> String {
        format!("your payload must contain fewer than {} 0 bits", best)
    }
}

#[tokio::main]
async fn main() {
    let collector = tracing_subscriber::fmt()
        // filter spans/events with level TRACE or higher.
        .with_max_level(Level::TRACE)
        .with_ansi(false)
        // build but do not install the subscriber.
        .init();
    // make_test_cases();
    if let Err(e) = run_server::<PalindromeNumber>().await {
        error!("{}", e);
    }

}
