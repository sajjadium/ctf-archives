use axum::routing::post;
use axum::Json;
use axum::{
    routing::get,
    Router,
    debug_handler
};
use redis::aio::AsyncStream;
use redis::{Client, Connection};
use serde::{Serialize, Deserialize};
use unicorn_engine::unicorn_const::{Arch, Mode, Permission};
use unicorn_engine::{RegisterX86, Unicorn, SECOND_SCALE};
use std::pin::Pin;
use std::sync::atomic::{AtomicU64};
use tracing::{error, info, warn};
use axum::extract::State;
use std::sync::{Arc, Mutex};
use eyre::Result;
use redis::AsyncCommands;


#[derive(Serialize,Deserialize)]
struct Payload {
    shellcode: String
}

pub const MAX_SIZE: usize = 4096 * 64;
pub trait Problem {
    fn test_case_len() -> usize;
    fn generate_input(idx: usize) -> Vec<u8>;
    fn check_output(input: &[u8], output: &[u8]) -> bool;
    fn name() -> &'static str;
    fn redis_host() -> &'static str;
    fn score(input: &[u8]) -> usize;
    fn fmt_fail(best: usize) -> String;
}




pub async fn run_server<P: Problem + 'static>() -> Result<()> {
    let app = Router::new()
        .route("/score", get(score::<P>))
        .route("/submit", post(submit::<P>));


    // run our app with hyper, listening globally on port 3000
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3000").await.unwrap();
    axum::serve(listener, app).await.unwrap();
    Ok(())
}

async fn score<P: Problem>() -> String {
    let client = match redis::Client::open(P::redis_host()) {
        Ok(client) => client,
        Err(e) => {
            error!("{}",e);
            return "umm redis failed gg".to_string();
        }
    };
    let mut con = match client.get_multiplexed_async_connection().await {
        Ok(con) => con,
        Err(e) => {
            error!("{}",e);
            return "umm redis failed gg".to_string();
        }
    };
    let best: usize = match redis::cmd("LINDEX").arg(&[&format!("golf:{}", P::name()),"-1"]).query_async::<_, usize>(&mut con).await {
        Ok(best) => {
            best
        },
        Err(e) => {
            warn!("{}",e);
            usize::max_value()
        }
    };
    return P::fmt_fail(best);
}

// basic handler that responds with a static string
async fn submit<P: Problem>(Json(payload): Json<Payload>) -> String {
    let Ok(shellcode) = hex::decode(&payload.shellcode) else { return "invalid input".to_string();};

    let client = match redis::Client::open(P::redis_host()) {
        Ok(client) => client,
        Err(e) => {
            error!("{}",e);
            return "umm redis failed gg".to_string();
        }
    };
    let mut con = match client.get_multiplexed_async_connection().await {
        Ok(con) => con,
        Err(e) => {
            error!("{}",e);
            return "umm redis failed gg".to_string();
        }
    };
    let best: usize = match redis::cmd("LINDEX").arg(&[&format!("golf:{}", P::name()),"-1"]).query_async::<_, usize>(&mut con).await {
        Ok(best) => {
            best
        },
        Err(e) => {
            warn!("{}",e);
            usize::max_value()
        }
    };
    if  P::score(&shellcode) > best {
        return P::fmt_fail(best);
    }
    // todo check if this is the smallest submission
    let mut accum = true;
    info!("received test case {}", payload.shellcode);
    for i in 0..P::test_case_len() {
        let Ok(mut emu) = Unicorn::new(Arch::X86, Mode::MODE_64) else {return "failed to instantiate emulator".to_string();};
        let _ = emu.mem_map(0x10000000, MAX_SIZE, Permission::ALL);
        let _ = emu.mem_map(0x20000000, MAX_SIZE, Permission::ALL);
        let _ = emu.mem_map(0x30000000, MAX_SIZE, Permission::ALL);
        let _ = emu.mem_write(0x10000000, &shellcode);
        let input = P::generate_input(i);
        let _ = emu.mem_write(0x20000000, &input);
        let _ = emu.emu_start(0x10000000, (0x10000000 + shellcode.len()) as u64, 10 * SECOND_SCALE, 1000);
    
        let Ok(output_len) = emu.reg_read(RegisterX86::RAX) else {return ":(".to_string();};
        let Ok(output) = emu.mem_read_as_vec(0x30000000, output_len as usize) else {return "couldn't read output, probably invalid output len".to_string();};
        let ret = P::check_output(&input, &output);
        info!("test case {} = {}, output len = {}", i, ret, output_len);
        accum &= ret;
    }
    if accum {
        redis::cmd("RPUSH").arg(&[&format!("golf:{}", P::name()),&format!("{}", P::score(&shellcode))]).query_async::<_, usize>(&mut con).await;
        env!("FLAG").to_string()
    } else {
        "your answer was wrong smh".to_string()
    }    

}
