use std::fs::File;
use std::io::prelude::*;
use runner::{Problem, run_server};
use tracing::{Level, error};
struct TwoSum {

}


const INPUTS: [&[u8]; 30] = [
    include_bytes!("../two_sum_test_cases/0"),
    include_bytes!("../two_sum_test_cases/1"),
    include_bytes!("../two_sum_test_cases/2"),
    include_bytes!("../two_sum_test_cases/3"),
    include_bytes!("../two_sum_test_cases/4"),
    include_bytes!("../two_sum_test_cases/5"),
    include_bytes!("../two_sum_test_cases/6"),
    include_bytes!("../two_sum_test_cases/7"),
    include_bytes!("../two_sum_test_cases/8"),
    include_bytes!("../two_sum_test_cases/9"),
    include_bytes!("../two_sum_test_cases/10"),
    include_bytes!("../two_sum_test_cases/11"),
    include_bytes!("../two_sum_test_cases/12"),
    include_bytes!("../two_sum_test_cases/13"),
    include_bytes!("../two_sum_test_cases/14"),
    include_bytes!("../two_sum_test_cases/15"),
    include_bytes!("../two_sum_test_cases/16"),
    include_bytes!("../two_sum_test_cases/17"),
    include_bytes!("../two_sum_test_cases/18"),
    include_bytes!("../two_sum_test_cases/19"),
    include_bytes!("../two_sum_test_cases/20"),
    include_bytes!("../two_sum_test_cases/21"),
    include_bytes!("../two_sum_test_cases/22"),
    include_bytes!("../two_sum_test_cases/23"),
    include_bytes!("../two_sum_test_cases/24"),
    include_bytes!("../two_sum_test_cases/25"),
    include_bytes!("../two_sum_test_cases/26"),
    include_bytes!("../two_sum_test_cases/27"),
    include_bytes!("../two_sum_test_cases/28"),
    include_bytes!("../two_sum_test_cases/29"),
];

impl Problem for TwoSum {

    fn test_case_len() -> usize {
        30
    }

    fn generate_input(idx: usize) -> Vec<u8> {
        INPUTS[idx].to_vec()
    }

    fn check_output(input: &[u8], output: &[u8]) -> bool {
        let input=  String::from_utf8_lossy(input).split('\n').flat_map(|f| f.parse::<isize>()).collect::<Vec<_>>();
        let output=  String::from_utf8_lossy(output).split('\n').flat_map(|f| f.parse::<usize>()).collect::<Vec<_>>(); // untrusted
        if output.len() < 2 {
            return false;
        }
        if output[0]  >= input.len() -2 || output[1] >= input.len() -2 {
            return false;
        }
        input[2+output[0]] + input[2+output[1]] == input[0]
    }
    
    fn redis_host() -> &'static str {
        "redis://redis-service.jsrcds-prd-golf-twosum.svc.cluster.local/"
    }
    
    fn score(input: &[u8]) -> usize {
        input.len()
    }
    
    fn name() -> &'static str {
        "twosum"
    }
    
    fn fmt_fail(best: usize) -> String {
        format!("your payload must be smaller than or equal to {} bytes", best)
    }
}


fn make_test_cases() {
    std::fs::create_dir_all("./two_sum_test_cases");
    for tcno in 0..30 {
        let mut file = File::create(&format!("./two_sum_test_cases/{}", tcno)).unwrap();
        let mut nums = Vec::new();
        // initial setup
        for num in 0..fastrand::usize(2..10000) {
            nums.push(fastrand::isize(-1000000000..1000000000))
        }
        let target = fastrand::isize(-1000000000..1000000000);
        let mut indexes_to_delete = Vec::new();
        // delete two-sum-able 
        for (i_idx, i) in nums.iter().enumerate() {
            for (j_idx,j) in nums.iter().enumerate() {
                if *i + *j == target {
                    indexes_to_delete.push(i_idx);
                    indexes_to_delete.push(j_idx);
                }
            }   
        }
        for i in indexes_to_delete {
            nums[i] = 0;
        }

        let r = fastrand::isize(-1000000000..1000000000);
        let l = target - r;
        nums.push(r);
        nums.push(l);
        let mut nums = nums.into_iter().filter(|x| *x != 0).collect::<Vec<isize>>();
        fastrand::shuffle(&mut nums);
        file.write_all(format!("{}\n", target).as_bytes());
        file.write_all(format!("{}\n", nums.len()).as_bytes());
        for num in nums {
            file.write_all(format!("{}\n", num).as_bytes());
        }
    }
    

}

#[tokio::main]
async fn main() {
    let collector = tracing_subscriber::fmt()
        // filter spans/events with level TRACE or higher.
        .with_max_level(Level::TRACE)
        .with_ansi(false)
        // build but do not install the subscriber.
        .init();
    // make_test_cases();
    if let Err(e) = run_server::<TwoSum>().await {
        error!("{}", e);
    }

}
