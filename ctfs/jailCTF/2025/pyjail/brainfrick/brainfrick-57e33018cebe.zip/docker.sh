#!/bin/bash
docker build -t brainfrick .
docker run -d -p 5000:5000 --privileged --name brainfrick brainfrick
