#!/bin/bash
docker build -t impossibler .
docker run -d -p 5000:5000 --privileged --name impossibler impossibler
