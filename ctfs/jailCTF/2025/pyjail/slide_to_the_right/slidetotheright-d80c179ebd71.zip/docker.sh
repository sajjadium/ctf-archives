#!/bin/bash
docker build -t slidetotheright .
docker run -d -p 5000:5000 --privileged --name slidetotheright slidetotheright
