#!/bin/bash
docker build -t seven7seven .
docker run -d -p 5000:5000 --privileged --name seven7seven seven7seven
