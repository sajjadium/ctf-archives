#!/bin/bash
docker build -t dcjail .
docker run -d -p 5000:5000 --privileged --name dcjail dcjail
