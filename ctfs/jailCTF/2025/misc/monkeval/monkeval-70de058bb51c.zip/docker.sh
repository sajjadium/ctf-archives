#!/bin/bash
docker build -t monkeval .
docker run -d -p 5000:5000 --privileged --name monkeval monkeval
