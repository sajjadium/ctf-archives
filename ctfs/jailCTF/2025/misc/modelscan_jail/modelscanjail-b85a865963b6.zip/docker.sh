#!/bin/bash
docker build -t modelscanjail .
docker run -d -p 5000:5000 --privileged --name modelscanjail modelscanjail
