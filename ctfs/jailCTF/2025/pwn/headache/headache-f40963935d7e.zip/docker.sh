#!/bin/bash
docker build -t headache .
docker run -d -p 5000:5000 --privileged --name headache headache
