#!/bin/bash
docker build -t mathjail2 .
docker run -d -p 5000:5000 --privileged --name mathjail2 mathjail2
