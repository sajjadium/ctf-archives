# To Do
- [ ] Make empty lines [] not [""]
- [ ] Better detection of empty spaces
- [ ] Decide whether to add roll (shift string right (and maybe left))?, 
translate and more complex number things e.g. factor
- [ ] Add other operators to tutor? Introduce preinitialized variables?
- [ ] Use one charcoal instance for new charcoal (lambdafy) maybe?
- [ ] zip
- [ ] Make ASTProcessor lines <80 chars
- [ ] Make lambdas not print result if they also return it