#!/usr/bin/env perl
eval<>=~y/rev xs//cdr