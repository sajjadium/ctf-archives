import safernumpy.core
# cant have vulnerabilities in functions if there are no functions to begin with!
