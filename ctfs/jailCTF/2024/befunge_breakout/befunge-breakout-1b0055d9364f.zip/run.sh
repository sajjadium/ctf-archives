#!/bin/sh
/app/src/cbi /app/src/test/calc.bf
