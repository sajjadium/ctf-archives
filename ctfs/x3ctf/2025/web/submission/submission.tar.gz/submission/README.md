docker-compose up
