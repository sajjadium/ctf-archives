The challenge is in redacted.zip

Note: Sometimes our web server has some weird issue for some reason and the zip file is broken - if this happens please ask for support from one of our on-call staff. Check the how_to_check.png image to figure out how to tell if someone is on-call.