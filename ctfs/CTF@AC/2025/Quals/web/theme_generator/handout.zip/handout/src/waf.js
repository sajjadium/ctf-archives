import qs from 'qs';

export function bodyKeyGuard(req, res, next) {
    if (req.body && typeof req.body === 'object') {
        const bad = ['__proto__', 'prototype', 'constructor'];
        for (const k of Object.keys(req.body)) {
            if (bad.includes(k)) return res.status(400).send('blocked');
        }
    }
    next();
}

export function queryParser(str) {
    return qs.parse(str, {
        allowPrototypes: true,
        depth: 10,
        allowDots: true,
        parameterLimit: 1000
    });
}