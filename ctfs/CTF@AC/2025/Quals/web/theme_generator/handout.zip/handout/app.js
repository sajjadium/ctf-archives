import express from 'express';
import path from 'path';
import cookieSession from 'cookie-session';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { authMiddleware, requireAuth, requireAdmin, seedAdmin } from './auth.js';
import { deepMerge } from './merge.js';
import { bodyKeyGuard, queryParser } from './waf.js';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use('/static', express.static(path.join(__dirname, 'public')));

app.use(cookieSession({
name: 'sess',
secret: 'not-a-secret',
httpOnly: true,
sameSite: 'lax'
}));

app.set('query parser', str => queryParser(str));

app.use(express.urlencoded({ extended: true }));
app.use(express.json({ strict: true }));
app.use(bodyKeyGuard);

app.use(authMiddleware);
seedAdmin(app);

const db = {
    users: new Map(),
    presets: new Map(),
};
app.locals.db = db;

if (!db.users.size) {
    db.users.set('guest', { username: 'guest', password: 'guest', isAdmin: false });
    const crypto = await import('crypto');
    const adminPassword = crypto.randomBytes(12).toString('base64url');
    db.users.set('admin', { username: 'admin', password: adminPassword, isAdmin: true });
    console.log(`[INFO] Admin password: ${adminPassword}`);
}

const DEFAULT_PRESET = Object.freeze({
    theme: { name: 'light', colors: { bg: '#fff', fg: '#111' } },
    options: { compact: false }
});

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 } });

app.get('/', (req, res) => {
    const user = req.user || null;
    res.render('index', { user });
});

app.get('/login', (req, res) => {
    res.render('login', { error: null });
});


app.post('/login', (req, res) => {
    const { username, password } = req.body || {};
    const u = app.locals.db.users.get(username);
    if (u && u.password === password) {
        req.session.username = u.username;
        return res.redirect('/');
    }
    return res.status(401).render('login', { error: 'Invalid credentials' });
});


app.get('/logout', (req, res) => {
    req.session = null;
    res.redirect('/');
});

app.get('/dashboard', requireAuth, (req, res) => {
    const preset = app.locals.db.presets.get(req.user.username) || DEFAULT_PRESET;
    res.render('admin', { user: req.user, preset });
});


app.post('/api/preset/upload', requireAuth, upload.single('preset'), (req, res) => {
    try {
        const text = req.file?.buffer?.toString('utf8') ?? '{}';
        let data = {};
        try { data = JSON.parse(text); } catch {
            return res.status(400).send('Invalid JSON');
        }

    for (const k of Object.keys(data)) {
        if (["__proto__", "prototype", "constructor"].includes(k)) {
            return res.status(400).send('blocked');
        }
    }


    const merged = deepMerge({}, DEFAULT_PRESET);
    deepMerge(merged, data);


    app.locals.db.presets.set(req.user.username, merged);
    return res.json({ ok: true, merged });
    } catch (e) {
        return res.status(500).send('error');
    }
});

app.post('/admin/preview', requireAdmin, (req, res) => {
    const payload = req.body || {};
    const widget = typeof payload.widget === 'string' ? payload.widget : '';
    res.render('preview', { user: req.user, widget });
});


app.get('/admin/flag', requireAdmin, (req, res) => {
    const flag = process.env.FLAG || 'Congrats! Contact admin for the flag!';
    res.type('text/plain').send(flag);
});


const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Theme Forge on :${port}`));