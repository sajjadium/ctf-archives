export function authMiddleware(req, _res, next) {
    const username = req.session?.username;
    if (username) {
        const u = req.app.locals.db.users.get(username);
        if (u) {
            req.user = { username: u.username };
            if (u.isAdmin === true) req.user.isAdmin = true;
        }
    }
    next();
}

export function requireAuth(req, res, next) {
    if (!req.user) return res.status(401).send('login required');
    next();
}

export function requireAdmin(req, res, next) {
    if (!req.user || !req.user.isAdmin) return res.status(403).send('admins only');
    next();
}


export function seedAdmin(app) {
    app.locals.adminHint = 'There is exactly one admin: admin/admin';
}