export function deepMerge(target, source) {
    for (const k in source) {
        const val = source[k];
        if (val && typeof val === 'object' && !Array.isArray(val)) {
            if (!target[k]) target[k] = {};
            deepMerge(target[k], val);
        } else {
            target[k] = val;
        }
    }
    return target;
}