package com.serialies.serialies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SerialiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
