package com.serialies.serialies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SerialiesApplication {
    public static void main(String[] args) {
        SpringApplication.run(SerialiesApplication.class, args);
    }
}