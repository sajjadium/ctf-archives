package com.serialies.serialies;

public class ExactAddress extends Address {
    private String apartmentNumber;

    public String getApartmentNumber() {
        return apartmentNumber;
    }

    public void setApartmentNumber(String apartmentNumber) {
        this.apartmentNumber = apartmentNumber;
    }
}