Welcome to the TI84+ CTF Challenge!
In this challenge you must reverse engineer the binary code of this ti84+ program in order to locate the hidden flag within the game.

NOTE: This challenge does not come with the TI-84+ rom. You need to get that from elsewhere.

https://tiroms.weebly.com/uploads/1/1/0/5/110560031/ti84plus.rom

ROM Size: 1048576 bytes (1024 KiB)
ROM SHA1: 5bf30a7ebbebfa90f221cdddc931ae0b96c419db

How to load the game into into WabbitEmu and run it:
Simply click on the Wabbitemu64.exe to run it. And then select the GPL-TI-84.rom as the rom to boot from. Once the calculator has loaded, drag the SWAMPCTF.8xp file into the running WabbitEmu to load the program.

(NOTE: If the calculator is appearing as just the screen, with no visual keyboard, go to View up at the top and check "enable skin" to help you navigate at first)

Unlike the a basic program on the TI83+ this program is assembled machine code, and so the calculator can't immediately run it from the program window. To run it go to the function catalog [2ND + 0] and select "Asm(". Then go to the PRGM menu and select the program. After you have put the program into the "Asm(" function you can run it with enter.
Have some fun and explore around a bit to get accustomed to the environment!

GOOD LUCK AND HAPPY MCGUFFIN HUNTING!

(PS you can go in the house btw)