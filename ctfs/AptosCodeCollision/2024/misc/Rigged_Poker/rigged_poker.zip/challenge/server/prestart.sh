#!/bin/bash 

rm -rf /tmp/instances-by-team
rm -rf /tmp/instances-by-uuid


mkdir -p /tmp/instances-by-uuid
mkdir -p /tmp/instances-by-team