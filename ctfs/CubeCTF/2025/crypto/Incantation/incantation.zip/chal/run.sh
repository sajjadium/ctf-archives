#!/bin/sh
timeout 30 /opt/incantation $FLAG
