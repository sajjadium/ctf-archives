Send us your commands as a bz2 of the commands

If your command list is a text file called `cmds.txt`:
```
7
0 100
7
1 134
0
1
```
Then zip it with:

`bzip2 -zkf cmds.txt` 