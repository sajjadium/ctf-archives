Im sending you the flag and only the flag....but its being jammed....please recover.
Symbol Table: [(1+1j), (-1+1j), (-1-1j), (1-1j)]
Symbol rate is 1/2 times the sample rate
All flags follow format flag{YourFlagIsABunchOfAsciiHere!!!}
