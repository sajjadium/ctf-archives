module workerboard

go 1.24

require github.com/google/uuid v1.6.0
