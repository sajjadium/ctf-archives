#!/usr/local/bin/python3
import sys

try:
    state = bytes.fromhex(sys.stdin.readline())
    src = bytes.fromhex(sys.stdin.readline())
    exec(src)
except Exception:
    print("meow")