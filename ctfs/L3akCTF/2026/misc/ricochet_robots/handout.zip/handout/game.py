import socket, time

UP, DOWN, LEFT, RIGHT = 1, 2, 4, 8

SIZE = 16

DIRECTIONS = {'U': (-1, 0, UP), 'D': (1, 0, DOWN), 'L': (0, -1, LEFT), 'R': (0, 1, RIGHT)}

COLORS = ('red', 'green', 'blue', 'yellow')
SHAPES = ('circle', 'triangle', 'diamond', 'ring')
SYMBOLS = {4 * i + j + 1: f'{c} {s}' for i, c in enumerate(COLORS) for j, s in enumerate(SHAPES)}
SYMBOLS[17] = 'wild'

NORTH_WALLS = [
    (1, 4), (1, 14), (2, 1), (3, 11), (4, 6), (4, 15), (6, 0), (7, 3),
    (7, 7), (7, 8), (7, 10), (7, 13), (8, 5), (9, 7), (9, 8), (10, 1),
    (10, 13), (12, 0), (12, 9), (12, 15), (13, 5), (13, 14), (14, 3), (14, 10),
]

WEST_WALLS = [
    (0, 2), (0, 10), (1, 4), (1, 14), (2, 2), (2, 11), (3, 7), (6, 3),
    (6, 14), (7, 7), (7, 9), (8, 6), (8, 7), (8, 9), (9, 2), (9, 13),
    (11, 10), (13, 6), (13, 15), (14, 3), (14, 10), (15, 7), (15, 12),
]

TARGETS = {
    (15, 6): 1, (1, 14): 2, (2, 11): 3, (9, 1): 4,
    (9, 13): 5, (6, 3): 6, (14, 10): 7, (8, 5): 8,
    (11, 0): 9, (13, 5): 10, (2, 1): 11, (6, 13): 12,
    (11, 9): 13, (1, 4): 14, (14, 3): 15, (3, 6): 16,
    (13, 14): 17,
}

ROBOTS = 'RGBY'

START = {'R': (14, 2), 'G': (13, 11), 'B': (3, 7), 'Y': (1, 3)}

TARGET_LIST = [(ROBOTS[(s - 1) // 4] if s < 17 else None, pos) for pos, s in TARGETS.items()]


class Game:
    def __init__(self, target):
        self.walls = [[0] * SIZE for _ in range(SIZE)]
        for i in range(SIZE):
            self.walls[0][i] |= UP
            self.walls[SIZE - 1][i] |= DOWN
            self.walls[i][0] |= LEFT
            self.walls[i][SIZE - 1] |= RIGHT
        for r, c in NORTH_WALLS:
            self.walls[r][c] |= UP
            self.walls[r - 1][c] |= DOWN
        for r, c in WEST_WALLS:
            self.walls[r][c] |= LEFT
            self.walls[r][c - 1] |= RIGHT
        self.symbols = [[TARGETS.get((r, c), 0) for c in range(SIZE)] for r in range(SIZE)]
        self.robots = dict(START)
        self.target = target

    def cell(self, row, col):
        occupant = next((n for n, p in self.robots.items() if p == (row, col)), None)
        return (self.walls[row][col], self.symbols[row][col], occupant)

    def board(self):
        return [[self.cell(r, c) for c in range(SIZE)] for r in range(SIZE)]

    def _destination(self, robot, direction):
        dr, dc, wall = DIRECTIONS[direction]
        r, c = self.robots[robot]
        occupied = set(self.robots.values())
        while not self.walls[r][c] & wall and (r + dr, c + dc) not in occupied:
            r, c = r + dr, c + dc
        return (r, c)

    def is_legal(self, move):
        if len(move) != 2 or move[0] not in self.robots or move[1] not in DIRECTIONS:
            return False
        return self._destination(move[0], move[1]) != self.robots[move[0]]

    def make_move(self, move):
        if not self.is_legal(move):
            raise ValueError(f'illegal move: {move!r}')
        self.robots[move[0]] = self._destination(move[0], move[1])

    def legal_moves(self):
        return [r + d for r in self.robots for d in DIRECTIONS if self.is_legal(r + d)]

    def is_win(self):
        robot, pos = self.target
        if robot is None:
            return pos in self.robots.values()
        return self.robots[robot] == pos

    def to_bytes(self):
        robot, (r, c) = self.target
        cells = [self.robots[n] for n in ROBOTS]
        return bytes([r * SIZE + c for r, c in cells] +
                     [ROBOTS.index(robot) if robot else len(ROBOTS), r * SIZE + c])

    @classmethod
    def from_bytes(cls, data):
        robot = ROBOTS[data[4]] if data[4] < len(ROBOTS) else None
        game = cls((robot, divmod(data[5], SIZE)))
        game.robots = dict(zip(ROBOTS, (divmod(b, SIZE) for b in data[:4])))
        return game

    def copy(self):
        game = Game(self.target)
        game.robots = dict(self.robots)
        return game

    def __eq__(self, other):
        return isinstance(other, Game) and (self.robots, self.target) == (other.robots, other.target)

    def __hash__(self):
        return hash((frozenset(self.robots.items()), self.target))

    def __str__(self):
        lines = []
        for r in range(SIZE):
            top, mid = '', ''
            for c in range(SIZE):
                walls, symbol, occupant = self.cell(r, c)
                top += '+' + ('---' if walls & UP else '   ')
                mark = occupant or (SYMBOLS[symbol][0] if symbol else ' ')
                mid += ('|' if walls & LEFT else ' ') + f' {mark} '
            lines.append(top + '+')
            lines.append(mid + '|')
        lines.append('+---' * SIZE + '+')
        return '\n'.join(lines)


def run_solution(src: bytes, game: Game):
    try:
        g = game.copy()
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect(("localhost", 4000))
            t1 = time.time_ns()
            s.sendall((g.to_bytes().hex() + "\n").encode())
            s.sendall((src.hex() + "\n").encode())
            resp = s.recv(1024).decode().strip()
            t2 = time.time_ns()
            moves = resp.split()
            for move in moves:
                if move not in g.legal_moves():
                    return False, 0
                g.make_move()
            if g.is_win():
                return True, t2-t1
            else:
                return False, 0
    except:
        return False, 0