#!/bin/sh
socat -d -d TCP-LISTEN:5000,reuseaddr,fork EXEC:"/home/noodler/startup.sh"
