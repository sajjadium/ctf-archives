#!/bin/sh
TEMPDIR=$(mktemp -d)
SOCK=$TEMPDIR/noodled.sock
chmod 777 $TEMPDIR
chmod 777 $SOCK
./noodled $SOCK &
sleep 3
./noodleterm $SOCK
