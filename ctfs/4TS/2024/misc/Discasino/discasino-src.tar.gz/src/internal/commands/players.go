package commands

import "time"

func GetPlayer(ID string) (player *Player, isNew bool) {
	player, found := players[ID]
	if !found {
		player = &Player{
			ID:        ID,
			Balance:   10,
			LastReset: time.Now(),
		}
		players[ID] = player
		return player, true
	}

	return player, false
}
