package commands

import (
	"fmt"

	"github.com/disgoorg/disgo/discord"
	"github.com/disgoorg/disgo/handler"
)

func handleStatus(event *handler.CommandEvent) error {
	content := "Welcome to the Casino!\n\n"
	content += fmt.Sprintf("I've been up since <t:%d:R>.\n", startedAt.Unix())
	content += fmt.Sprintf("I've played %d games so far !\n", plays)
	content += fmt.Sprintf("Players have won %d games so far, which means they've lost %d games :(\n", wins, plays-wins)
	content += fmt.Sprintf("That's a win rate of %.2f%% !\n", float64(wins)/float64(plays)*100)

	return event.CreateMessage(discord.MessageCreate{
		Content: content,
		Flags:   discord.MessageFlagEphemeral,
	})
}
