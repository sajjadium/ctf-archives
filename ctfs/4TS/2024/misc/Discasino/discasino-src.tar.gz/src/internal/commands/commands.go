package commands

import (
	"discasino/internal/interfaces"
	"math/rand"
	"time"

	"github.com/disgoorg/disgo/discord"
	"github.com/disgoorg/disgo/handler"
	"github.com/disgoorg/disgo/handler/middleware"
)

type Player struct {
	ID      string
	Balance int

	LastReset time.Time
	Fails     int
}

type Game struct {
	ID       string
	PlayerID string
}

var (
	startedAt = time.Now()
	random    = rand.New(rand.NewSource(startedAt.Unix()))

	players = make(map[string]*Player)
	games   = make(map[string]*Game)

	plays int64 = 0
	wins  int64 = 0
)

func RegisterCommands(app interfaces.App) {
	client := app.GetClient()
	appId := client.ApplicationID()

	_, err := client.Rest().CreateGlobalCommand(appId, discord.SlashCommandCreate{
		Name:        "status",
		Description: "Get the bot's status",
	})
	if err != nil {
		client.Logger().Error("error creating command", err)
	}

	_, err = client.Rest().CreateGlobalCommand(appId, discord.SlashCommandCreate{
		Name:        "casino",
		Description: "Play the slot machine",
	})
	if err != nil {
		client.Logger().Error("error creating command", err)
	}

	_, err = client.Rest().CreateGlobalCommand(appId, discord.SlashCommandCreate{
		Name:        "reset",
		Description: "Reset your balance",
	})
	if err != nil {
		client.Logger().Error("error creating command", err)
	}

	_, err = client.Rest().CreateGlobalCommand(appId, discord.SlashCommandCreate{
		Name:        "flag",
		Description: "Get the flag",
	})
	if err != nil {
		client.Logger().Error("error creating command", err)
	}

	r := handler.New()
	r.Use(middleware.Logger)
	r.Command("/status", handleStatus)
	r.Command("/casino", handleCasino)
	r.Command("/reset", handleReset)
	r.Command("/flag", handleFlag)
	r.ButtonComponent("/{gameId}/{index}/l", handleCasinoButton)
	r.ButtonComponent("/{gameId}/{index}/w", handleCasinoButton)

	go client.AddEventListeners(r)
}
