package interfaces

import "github.com/disgoorg/disgo/bot"

// App is the interface that wraps the methods required to start the bot.
type App interface {
	// Start starts the bot.
	Start()

	GetClient() bot.Client
}
