package app

import (
	"context"
	"discasino/internal/commands"
	"discasino/internal/config"
	"discasino/internal/interfaces"
	"log/slog"

	"github.com/disgoorg/disgo"
	"github.com/disgoorg/disgo/bot"
	"github.com/disgoorg/disgo/events"
	"github.com/disgoorg/disgo/gateway"
	"github.com/sirupsen/logrus"

	sloglogrus "github.com/samber/slog-logrus/v2"
)

// Ensure App implements interfaces.App
var _ interfaces.App = (*App)(nil)

type App struct {
	client bot.Client
}

func New(cfg *config.Config) interfaces.App {
	app := &App{}

	logger := slog.New(sloglogrus.Option{Level: slog.LevelDebug, Logger: logrus.StandardLogger()}.NewLogrusHandler())

	client, err := disgo.New(cfg.DiscordToken,
		// set gateway options
		bot.WithGatewayConfigOpts(
			// set enabled intents
			gateway.WithIntents(
				gateway.IntentGuilds,
				gateway.IntentGuildMessages,
				gateway.IntentDirectMessages,
			),
		),
		bot.WithEventListenerFunc(app.OnReady),
		bot.WithLogger(logger),
	)
	if err != nil {
		panic(err)
	}

	app.client = client

	return app
}

func (app *App) Start() {
	// connect to the gateway
	if err := app.client.OpenGateway(context.TODO()); err != nil {
		panic(err)
	}
}

func (app *App) OnReady(_ *events.Ready) {
	logrus.Info("Bot is ready, registering commands...")
	commands.RegisterCommands(app)
	err := app.client.SetPresence(context.TODO(), gateway.WithPlayingActivity("Come and gamble into Discasino!"))
	if err != nil {
		logrus.Error("Error setting presence", err)
	}
	logrus.Info("Commands registered!")
}

func (app *App) GetClient() bot.Client {
	return app.client
}
