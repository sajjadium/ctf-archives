package commands

import (
	"fmt"
	"strconv"

	"github.com/disgoorg/disgo/discord"
	"github.com/disgoorg/disgo/handler"
)

var emojis = []string{
	"🍒",
	"🍋",
	"🍇",
	"🍊",
	"🍉",
	"🍓",
	"🍍",
	"🍎",
	"🍏",
	"🍐",
	"🍑",
	"🍈",
}

func handleCasino(event *handler.CommandEvent) error {
	// Get the user's balance
	player, isNew := GetPlayer(event.User().ID.String())

	if player.Balance <= 0 {
		return event.CreateMessage(discord.MessageCreate{
			Content: "You don't have enough coins to play the slot machine!\n\nYou can reset your balance with `/reset`.",
			Flags:   discord.MessageFlagEphemeral,
		})
	}

	if player.Fails >= 3 {
		return event.CreateMessage(discord.MessageCreate{
			Content: "You have lost too many times! You need to reset your balance with `/reset`.",
			Flags:   discord.MessageFlagEphemeral,
		})
	}

	// Shuffle the emojis of the slot machine
	shuffled := make([]string, len(emojis))
	copy(shuffled, emojis)
	for i := range shuffled {
		j := random.Intn(i + 1)
		shuffled[i], shuffled[j] = shuffled[j], shuffled[i]
	}

	// Create the message
	embed := discord.Embed{
		Title:       "🎰 Casino",
		Description: "Let's play the slot machine!\n\nClick on the correct button to win!",
	}

	if isNew {
		embed.Description += "\n\nYou have been given 10 coins to start playing!\nThe first game is on the house!"
	} else {
		player.Balance--
		embed.Description += fmt.Sprintf("\n\nYou have %d coins left to play with!", player.Balance)
	}

	components := []discord.ContainerComponent{}

	gameId := fmt.Sprintf("%d", random.Int63())

	// Choose the winner randomly
	winner := random.Intn(len(shuffled))
	games[gameId] = &Game{
		ID:       gameId,
		PlayerID: event.User().ID.String(),
		Winner:   winner,
	}

	// Create 3 rows of buttons
	for i := 0; i < 3; i++ {
		row := discord.ActionRowComponent{}
		for j := 0; j < 4; j++ {
			index := i*4 + j
			row = row.AddComponents(discord.ButtonComponent{
				Label:    shuffled[index],
				CustomID: fmt.Sprintf("/%s/%d", gameId, index),
				Style:    discord.ButtonStylePrimary,
			})
		}
		components = append(components, row)
	}

	// Send the message
	return event.CreateMessage(discord.MessageCreate{
		Embeds:     []discord.Embed{embed},
		Components: components,
		Flags:      discord.MessageFlagEphemeral,
	})
}

func handleCasinoButton(data discord.ButtonInteractionData, event *handler.ComponentEvent) error {
	gameId := event.Vars["gameId"]
	sIndex := event.Vars["index"]
	index, _ := strconv.Atoi(sIndex)

	game, found := games[gameId]
	if !found {
		return event.CreateMessage(discord.MessageCreate{Content: "This game is already over!", Flags: discord.MessageFlagEphemeral})
	}
	defer delete(games, gameId)

	player, _ := GetPlayer(event.User().ID.String())

	if game.PlayerID != event.User().ID.String() {
		return event.CreateMessage(discord.MessageCreate{Content: "You can't play this game!", Flags: discord.MessageFlagEphemeral})
	}

	plays++

	if index == game.Winner {
		player.Balance += 2
		wins++

		return event.CreateMessage(discord.MessageCreate{Content: fmt.Sprintf("You won! 🎉\n\nHere's your balance : %d", player.Balance), Flags: discord.MessageFlagEphemeral})
	}

	player.Balance--
	player.Fails++
	return event.CreateMessage(discord.MessageCreate{Content: fmt.Sprintf("You lost! 😢\n\nHere's your balance : %d", player.Balance), Flags: discord.MessageFlagEphemeral})
}
