package commands

import (
	"discasino/internal/config"
	"fmt"

	"github.com/disgoorg/disgo/discord"
	"github.com/disgoorg/disgo/handler"
)

func handleFlag(event *handler.CommandEvent) error {
	player, _ := GetPlayer(event.User().ID.String())

	if player.Balance <= 50 {
		return event.CreateMessage(discord.MessageCreate{
			Content: "Nuh-uh! You need at least 50 coins to get the flag!",
			Flags:   discord.MessageFlagEphemeral,
		})
	}

	cfg := config.Get()
	return event.CreateMessage(discord.MessageCreate{
		Content: fmt.Sprintf("Congratulations! Here's the flag: `%s`", cfg.Flag),
		Flags:   discord.MessageFlagEphemeral,
	})
}
