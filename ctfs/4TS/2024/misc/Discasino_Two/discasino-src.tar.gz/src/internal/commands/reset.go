package commands

import (
	"time"

	"github.com/disgoorg/disgo/discord"
	"github.com/disgoorg/disgo/handler"
)

func handleReset(event *handler.CommandEvent) error {
	// Reset the game for the player
	player, _ := GetPlayer(event.User().ID.String())

	if time.Since(player.LastReset) < 10*time.Minute {
		return event.CreateMessage(discord.MessageCreate{
			Content: "You can only reset your balance once every 10 minutes!",
			Flags:   discord.MessageFlagEphemeral,
		})
	}

	return event.CreateMessage(discord.MessageCreate{
		Flags: discord.MessageFlagEphemeral,
	})
}
