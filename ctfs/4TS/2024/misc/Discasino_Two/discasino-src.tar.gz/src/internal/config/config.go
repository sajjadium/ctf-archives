package config

type Config struct {
	DiscordToken string `env:"DISCORD_TOKEN"`
	Flag         string `env:"FLAG"`
}

func Get() *Config {
	return &cfg
}
