package main

import (
	"discasino/internal/app"
	"discasino/internal/config"
	"os"
	"os/signal"
	"syscall"
)

func main() {
	cfg := config.Get()

	app := app.New(cfg)

	app.Start()

	s := make(chan os.Signal, 1)
	signal.Notify(s, syscall.SIGINT, syscall.SIGTERM)
	<-s
}
