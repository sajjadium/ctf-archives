#ifndef MAIN_H
#define MAIN_H
#include "emulator.h"
#include "common.h"
#include "log.h"

#endif
