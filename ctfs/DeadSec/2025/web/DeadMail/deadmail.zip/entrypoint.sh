#!/bin/bash
set -e

# Generate a random deployment path
DEPLOY_DIR="/opt/$(openssl rand -hex 8)"
echo "Deploying to $DEPLOY_DIR"

# Copy app files
cp -r /tmp/template "$DEPLOY_DIR"
rm -rf /tmp/template
chown -R www-data:www-data "$DEPLOY_DIR"
mkdir -p "$DEPLOY_DIR/database" /tmp/deadmail/_cached_templates
chmod -R 755 "$DEPLOY_DIR"
chown -R www-data:www-data /tmp/deadmail/_cached_templates

# Write Nginx config
cat > /etc/nginx/sites-available/default <<EOF
server {
    listen 80;
    server_name _;
    root $DEPLOY_DIR;
    index login.php index.html;

    location / {
        try_files \$uri \$uri/ /login.php?\$query_string;
    }

    location ~ \.php\$ {
        include fastcgi_params;
        fastcgi_pass unix:/var/run/php/php7.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $DEPLOY_DIR\$fastcgi_script_name;
        fastcgi_param PATH_INFO \$fastcgi_path_info;
    }

    location /images {
        autoindex on;
        autoindex_exact_size off;
        autoindex_localtime on;
    }
}
EOF

# Start supervisor (php-fpm + nginx)
exec /usr/bin/supervisord -n -c /etc/supervisor/conf.d/supervisord.conf
