<?php


define('yes',1);
define('no',0);

$ALL_OK = false;

$themes 	= Array();
$languages 	= Array();

$temporary_directory = "/tmp/deadmail/";

$smtp_server = "mail.deadmail.quest";
$allow_filters = no;
$quota_limit = 0;  //  in KB, eg. 4096 Kb = 4MB
$use_password_for_smtp	= no;
$check_first_login		= yes;
$allow_modified_from	= yes;

require("./inc/config.languages.php");

require("./inc/config.security.php");
$mail_server_type 	= "ONE-FOR-EACH";

$mail_detect_remove 		= "www.";
$mail_detect_prefix 		= "mail.";
$mail_detect_login_type 	= "%user%@%domain%";
$mail_detect_protocol 		= "pop3";
$mail_detect_port 		= "110";
$mail_detect_folder_prefix 	= "";

$mail_servers[] = Array(
	"domain" 		=> "deadmail.quest",
	"server" 		=> "mail.deadmail.quest",
	"login_type" 	        => "%user%",
	"protocol"		=> "pop3",
	"port"			=> "110"
);

$default_mail_server 	= "mail.deadmail.quest";
$one_for_all_login_type	= "%user%@%domain%";
$default_protocol		= "pop3";
$default_port			= "110";
$default_folder_prefix	= "";

$mailer_type		= "smtp";

$mail_use_top = yes;

$appversion = "1.1";
$appname = "DeadMail";

$footer = "

________________________________________________
Message sent using $appname $appversion
";
$enable_debug = no;

$default_sortby = "date";
$default_sortorder = "DESC";

$default_preferences = Array(
	"send_to_trash_default" 	=> yes,		# send deleted messages to trash
	"st_only_ready_default" 	=> yes,		# only read messages, otherwise, delete it
	"save_to_sent_default"		=> yes,		# send sent messages to sent
	"empty_trash_default"		=> yes,		# empty trash on logout
	"sortby_default"			=> "date",	# alowed: "attach","subject","fromname","date","size"
	"sortorder_default"			=> "DESC",	# alowed: "ASC","DESC"
	"rpp_default"				=> 20,		# records per page (messages), alowed: 10,20,30,40,50,100,200
	"add_signature_default"		=> no,		# add the signature by default
	"signature_default"			=> "",		# a default signature for all users, use text only, with multiple lines if needed
	"timezone_default"			=> "+0000",	# timezone, format (+|-)HHMM (H=hours, M=minutes)
	"display_images_default"	=> yes,		# automatically show attached images in the body of message
	"editor_mode_default"		=> "html",	# use "html" or "text" to set default editor. "html" will be used only in IE5+ browsers
	"refresh_time_default"		=> 10		# after this time, the message list will be refreshed, in minutes
);

$ALL_OK = true;
?>
