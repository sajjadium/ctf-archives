<?php

$allow_html 			= yes;
$allow_scripts			= no;

$block_external_images = no;

$idle_timeout = 10; //minutes

$require_same_ip = yes; //minutes

?>
