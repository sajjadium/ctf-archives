<?php


@set_time_limit(0);
session_start();
session_name('sid');
$sid = session_id();

require("./inc/config.php");
require("./inc/class.deadmail.php");
require("./inc/lib.php");

$temporary_directory = realpath($temporary_directory).'/';

define("SMARTY_DIR","./smarty/");
require_once(SMARTY_DIR."Smarty.class.php");
$smarty = new Smarty;
$smarty->compile_dir = $temporary_directory;
$smarty->security=true;


$smarty->assign("dmMenuTemplate",dirname($PATH_TRANSLATED).$menu_template);
$smarty->assign("dmLanguageFile",$selected_language.".txt");

$SS = New Session();
$SS->temp_folder 	= $temporary_directory;
$SS->sid 			= $sid;
$SS->timeout 		= $idle_timeout;

$sess = $SS->Load();


if(!array_key_exists("start", $sess )) $sess["start"] = time();
$start = $sess["start"];

$DM = new DeadMail();

if(isset($f_pass) && strlen($f_pass) > 0) {

	switch(strtoupper($mail_server_type)) {

	case "DETECT":
		$f_server 	= strtolower(getenv("HTTP_HOST"));
		$f_server 	= str_replace($mail_detect_remove,"",$f_server);
		$f_server 	= $mail_detect_prefix.$f_server;

		if(preg_match("(.*)@(.*)",$f_email,$regs)) {
			$f_user = $regs[1];
			$domain = $regs[2];
			if($mail_detect_login_type != "") $f_user = preg_replace("%user%",$f_user,preg_replace("%domain%",$domain,$mail_detect_login_type));
		}

		$f_protocol	= $mail_detect_protocol;
		$f_port		= $mail_detect_port;
		$f_prefix	= $mail_detect_folder_prefix;

		break;

	case "ONE-FOR-EACH": 
		$domain 		= $mail_servers[$six]["domain"];
		$f_email 		= $f_user."@".$domain;
		$f_server 		= $mail_servers[$six]["server"];
		$login_type 	        = $mail_servers[$six]["login_type"];

		$f_protocol		= $mail_servers[$six]["protocol"];
		$f_port			= $mail_servers[$six]["port"];
		$f_prefix		= $mail_servers[$six]["folder_prefix"];

		if($login_type != "") $f_user = preg_replace("%user%",$f_user,preg_replace("%domain%",$domain,$login_type));
		break;

	case "ONE-FOR-ALL": 
		if(preg_match("/(.*)@(.*)/",$f_email,$regs)) {
			$f_user = $regs[1];
			$domain = $regs[2];
			if($one_for_all_login_type != "") $f_user = preg_replace("%user%",$f_user,preg_replace("%domain%",$domain,$one_for_all_login_type));
		}
		$f_server = $default_mail_server;

		$f_protocol	= $default_protocol;
		if($f_protocol == "imap")
			$f_port		= "143";
		if($f_protocol == "pop3")
			$f_port		= "110";
		$f_prefix	= $default_folder_prefix;
		break;
	}

	$DM->mail_email 	= $sess["email"]  			= stripslashes($f_email);
	$DM->mail_user 		= $sess["user"]   			= stripslashes($f_user);
	$DM->mail_pass 		= $sess["pass"]   			= stripslashes($f_pass); 
	$DM->mail_server 	= $sess["server"] 			= stripslashes($f_server); 

	$DM->mail_port 		= $sess["port"] 			= intval($f_port); 
	$DM->mail_protocol	= $sess["protocol"] 		= strtolower($f_protocol); 
	$DM->mail_prefix	= $sess["folder_prefix"] 	= $f_prefix; 
	
	$sess['remote_ip'] = $_SERVER['REMOTE_ADDR'];
	
	$refr = 1;

} elseif (
	($sess["auth"] && intval((time()-$start)/60) < $idle_timeout)
	&& $require_same_ip && ($sess["remote_ip"] == $_SERVER['REMOTE_ADDR'])
	) {

	$DM->mail_user   	= $f_user    	= $sess["user"];
	$DM->mail_pass   	= $f_pass    	= $sess["pass"];
	$DM->mail_server 	= $f_server  	= $sess["server"];
	$DM->mail_email  	= $f_email   	= $sess["email"];

	$DM->mail_port 		= $f_port 		= $sess["port"]; 
	$DM->mail_protocol	= $f_protocol	= $sess["protocol"]; 
	$DM->mail_prefix	= $f_prefix 	= $sess["folder_prefix"]; 

} else {
	redirect("./login.php?tid=$tid&lid=$lid"); 
	exit; 
}
$sess["start"] = time();

$SS->Save($sess);

$userfolder = $temporary_directory.preg_replace("[^a-z0-9\._-]","_",strtolower($f_user))."_".strtolower($f_server)."/";

$DM->debug				= $enable_debug;
$DM->use_html			= $allow_html;

$DM->user_folder 		= $userfolder;
$DM->temp_folder		= $temporary_directory;
$DM->timeout			= $idle_timeout;


$prefs = load_prefs();

$DM->timezone			= $prefs["timezone"];
$DM->charset			= $default_char_set;




Header("Expires: Wed, 11 Nov 1998 11:11:11 GMT");
Header("Cache-Control: no-cache");
Header("Cache-Control: must-revalidate");

$nocache = "
<META HTTP-EQUIV=\"Cache-Control\" CONTENT=\"no-cache\">
<META HTTP-EQUIV=\"Expires\" CONTENT=\"-1\">";

if(!isset($sortby) || !ereg("(subject|fromname|date|size)",$sortby)) {
	if(array_key_exists("sort-by",$prefs) && preg_match("(subject|fromname|date|size)",$prefs["sort-by"]))
		$sortby = $prefs["sort-by"];
	else
		$sortby = $default_sortby;
} else {
	$need_save = true;
	$prefs["sort-by"] = $sortby;
}

if(!isset($sortorder) || !ereg("ASC|DESC",$sortorder)) {
	if(array_key_exists("sort-order",$prefs) && preg_match("/ASC|DESC/",$prefs["sort-order"]))
		$sortorder = $prefs["sort-order"];
	else
		$sortorder = $default_sortorder;
} else {
	$need_save = true;
	$prefs["sort-order"] = $sortorder;
}

if(isset($need_save)) save_prefs($prefs);

if(is_array($sess["sysmap"])) 
	while(list($key, $value) = each($sess["sysmap"]))
		if(strtolower($folder) == $key)
			$folder = $value;

if(!isset($folder) || $folder == "" || strpos($folder,"..") !== false ) {
	$folder = $sess["sysmap"]["inbox"];

} elseif (!file_exists($userfolder.$folder)) { 
	redirect("./logout.php?tid=$tid&lid=$lid"); 
	exit; 
}

?>
