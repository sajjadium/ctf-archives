<?php



require("./inc/inc.php");
require("./folder-list.php");

echo($nocache);

$filename = $userfolder."_infos/addressbook.ucf";
$myfile = $DM->_read_file($filename);

if($myfile != "")
        $addressbook = unserialize(base64_decode($myfile));
array_qsort2($addressbook,"name");


$jssource = "
<script language=\"JavaScript\">
function goinbox() { location = 'message-list.php?folder=".$sess["sysmap"]["inbox"]."&tid=$tid&lid=$lid'; }
function newmsg() { location = 'new-message.php?pag=$pag&folder=".urlencode($folder)."&tid=$tid&lid=$lid'; }
function refreshlist() { location = 'address-book.php?tid=$tid&lid=$lid' }
function folderlist() { location = 'manage-folders.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid'}
function search() { location = 'search.php?tid=$tid&lid=$lid'; }
function addresses() { location = 'address-book.php?tid=$tid&lid=$lid'; }
function emptytrash() {        location = 'manage-folders.php?empty=trash&folder=".urlencode($folder)."&goback=true&tid=$tid&lid=$lid';}
function goend() { location = 'logout.php?tid=$tid&lid=$lid'; }
function prefs() { location = 'settings.php?tid=$tid&lid=$lid'; }

</script>
";

$smarty->assign("dmLid",$lid);
$smarty->assign("dmSid",$sid);
$smarty->assign("dmTid",$tid);
$smarty->assign("dmJS",$jssource);
$smarty->assign("dmGoBack","address-book.php?tid=$tid&lid=$lid");


switch($opt) {

        case "save":
                $addressbook[$id]["name"] = $name;
                $addressbook[$id]["email"] = $email;
                $addressbook[$id]["street"] = $street;
                $addressbook[$id]["city"] = $city;
                $addressbook[$id]["state"] = $state;
                $addressbook[$id]["work"] = $work;

				$DM->_save_file($filename,base64_encode(serialize($addressbook)));

				$smarty->assign("dmOpt",1);
				$templatename = "address-results.htm";

                break;
        case "add":
                $id = count($addressbook);
                $addressbook[$id]["name"] = $name;
                $addressbook[$id]["email"] = $email;
                $addressbook[$id]["street"] = $street;
                $addressbook[$id]["city"] = $city;
                $addressbook[$id]["state"] = $state;
                $addressbook[$id]["work"] = $work;

				$DM->_save_file($filename,base64_encode(serialize($addressbook)));

				$smarty->assign("dmOpt",2);
				$templatename = "address-results.htm";

                break;
        case "dele":
                unset($addressbook[$id]);
                $newaddr = Array();
                while(list($l,$value) = each($addressbook))
                        $newaddr[] = $value;
                $addressbook = $newaddr;
				$DM->_save_file($filename,base64_encode(serialize($addressbook)));

				$smarty->assign("dmOpt",3);
				$templatename = "address-results.htm";

                break;
        case "edit":

				$smarty->assign("dmAddrName",$addressbook[$id]["name"]);
				$smarty->assign("dmAddrEmail",$addressbook[$id]["email"]);
				$smarty->assign("dmAddrStreet",$addressbook[$id]["street"]);
				$smarty->assign("dmAddrCity",$addressbook[$id]["city"]);
				$smarty->assign("dmAddrState",$addressbook[$id]["state"]);
				$smarty->assign("dmAddrWork",$addressbook[$id]["work"]);
				$smarty->assign("dmOpt","save");
				$smarty->assign("dmAddrID",$id);
				$templatename = "address-form.htm";


                break;
        case "display":

				$smarty->assign("dmAddrName",$addressbook[$id]["name"]);
				$smarty->assign("dmAddrEmail",$addressbook[$id]["email"]);
				$smarty->assign("dmAddrStreet",$addressbook[$id]["street"]);
				$smarty->assign("dmAddrCity",$addressbook[$id]["city"]);
				$smarty->assign("dmAddrState",$addressbook[$id]["state"]);
				$smarty->assign("dmAddrWork",$addressbook[$id]["work"]);

				$smarty->assign("dmAddrID",$id);
				$templatename = "address-display.htm";


                break;
        case "new":

				$templatename = "address-form.htm";

				$smarty->assign("dmOpt","add");
				$smarty->assign("dmAddrID","N");

                break;

        case "expo":
                require("./inc/lib.export.php");
                export2ou($addressbook[$id]);
                break;

        default:


				$smarty->assign("dmNew","address-book.php?opt=new&tid=$tid&lid=$lid");

				$addresslist = Array();
                for($i=0;$i<count($addressbook);$i++) {
						$ind = count($addresslist);
						$addresslist[$ind]["viewlink"] = "address-book.php?opt=display&id=$i&tid=$tid&lid=$lid";
						$addresslist[$ind]["composelink"] = "new-message.php?nameto=".htmlspecialchars($addressbook[$i]["name"])."&mailto=".htmlspecialchars($addressbook[$i]["email"])."&tid=$tid&lid=$lid";
						$addresslist[$ind]["editlink"] = "address-book.php?opt=edit&id=$i&tid=$tid&lid=$lid";
						$addresslist[$ind]["dellink"] = "address-book.php?opt=dele&id=$i&tid=$tid&lid=$lid";

						$addresslist[$ind]["name"] = $addressbook[$i]["name"];
						$addresslist[$ind]["email"] = $addressbook[$i]["email"];
                }
				$templatename = "address-list.htm";
				$smarty->assign("dmAddressList",$addresslist);
}

$smarty->display("$selected_theme/$templatename");

?>