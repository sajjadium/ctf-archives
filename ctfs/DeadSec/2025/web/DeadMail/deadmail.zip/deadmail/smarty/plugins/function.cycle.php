<?php


function smarty_function_cycle($params, &$smarty)
{
	static $cycle_vars;
	
    extract($params);

    if (empty($name)) {
        $name = 'default';
    }

    if (!isset($print)) {
        $print = true;
    }

    if (!isset($advance)) {
        $advance = true;		
    }	

    if (!isset($reset)) {
        $reset = false;		
    }		
			
    if (!in_array('values', array_keys($params))) {
		if(!isset($cycle_vars[$name]['values'])) {
        	$smarty->trigger_error("cycle: missing 'values' parameter");
        	return;
		}
    } else {
		if(isset($cycle_vars[$name]['values'])
			&& $cycle_vars[$name]['values'] != $values ) {
			$cycle_vars[$name]['index'] = 0;
		}
		$cycle_vars[$name]['values'] = $values;
	}

    if (isset($delimiter)) {
		$cycle_vars[$name]['delimiter'] = $delimiter;
    } elseif (!isset($cycle_vars[$name]['delimiter'])) {
		$cycle_vars[$name]['delimiter'] = ',';		
	}
	
	if(!is_array($cycle_vars[$name]['values'])) {
		$cycle_array = explode($cycle_vars[$name]['delimiter'],$cycle_vars[$name]['values']);
	} else {
		$cycle_array = $cycle_vars[$name]['values'];	
	}
	
	if(!isset($cycle_vars[$name]['index']) || $reset ) {
		$cycle_vars[$name]['index'] = 0;
	}
	
    if (isset($assign)) {
        $print = false;
        $smarty->assign($assign, $cycle_array[$cycle_vars[$name]['index']]);
    }
		
	if($print) {
		echo $cycle_array[$cycle_vars[$name]['index']];
	}

	if($advance) {
		if ( $cycle_vars[$name]['index'] >= count($cycle_array) -1 ) {
			$cycle_vars[$name]['index'] = 0;			
		} else {
			$cycle_vars[$name]['index']++;
		}
	}
}



?>
