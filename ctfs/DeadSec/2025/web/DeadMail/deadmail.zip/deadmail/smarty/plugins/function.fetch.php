<?php


function smarty_function_fetch($params, &$smarty)
{
	$file = $params['file'];

    if (empty($file)) {
        $smarty->_trigger_plugin_error("parameter 'file' cannot be empty");
        return;
    }

    if ($smarty->security && !preg_match('!^(http|ftp)://!i', $file)) {
        foreach ($smarty->secure_dir as $curr_dir) {
            if (substr(realpath($file), 0, strlen(realpath($curr_dir))) == realpath($curr_dir)) {
                $resource_is_secure = true;
                break;
            }
        }
        if (!$resource_is_secure) {
            $smarty->_trigger_plugin_error("(secure mode) fetch '$file' is not allowed");
            return;
        }
		if($fp = @fopen($file,'r')) {
			while(!feof($fp)) {
				$content .= fgets ($fp,4096);
			}
			fclose($fp);
		} else {
            $smarty->_trigger_plugin_error("fetch cannot read file '$file'");
            return;			
		}
    } else {
		if(preg_match('!^http://!i',$file)) {
			if($uri_parts = parse_url($file)) {
				$host = $server_name = $uri_parts['host'];
				$timeout = 30;
				$accept = "image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, *

?>
