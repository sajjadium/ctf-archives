<?php


function smarty_modifier_regex_replace($string, $search, $replace)
{
    return preg_replace($search, $replace, $string);
}



?>
