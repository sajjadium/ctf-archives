<?php


function smarty_modifier_lower($string)
{
	return strtolower($string);
}

?>
