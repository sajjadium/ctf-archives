<?php


require("./inc/inc.php");

if(!isset($folder) || !isset($ix)) die("Expected parameters");
$mail_info = $sess["headers"][base64_encode($folder)][$ix];

echo($nocache);

if(!file_exists($mail_info["localname"])) die("File not found");;
$email = $DM->_read_file($mail_info["localname"]);

$DM->displayimages = $prefs["display-images"];
$DM->allow_scripts = $allow_scripts;

$email = $DM->Decode($email);
$body = $email["body"];
if(eregi("<[ ]*body.*background[ ]*=[ ]*[\"']?([A-Za-z0-9._&?=:/{}%+-]+)[\"']?.*>",$body,$regs))
	$backimg = 	" background=\"".$regs[1]."\"";
$smarty->assign("dmBackImg",$backimg);
if(eregi("<[ ]*body[A-Z0-9._&?=:/\"' -]*bgcolor=[\"']?([A-Z0-9#]+)[\"']?[A-Z0-9._&?=:/\"' -]*>",$body,$regs))
	$backcolor = " bgcolor=\"".$regs[1]."\"";
$smarty->assign("dmBackColor",$backcolor);

$body = eregi_replace("<body","<deadmail_body_not_alowed",$body);
$body = eregi_replace("a:(link|visited|hover)",".".uniqid(""),$body);
$body = eregi_replace("(body)[ ]?\\{",".".uniqid(""),$body);

$smarty->assign("dmMessageBody",$body);


$ARFrom = $email["from"];
$useremail = $sess["email"];
$name = $ARFrom[0]["name"];
$thismail = $ARFrom[0]["mail"];
$ARFrom[0]["link"] = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
$ARRom[0]["title"] = "$name <$thismail>";

$smarty->assign("dmFromList",$ARFrom);
$ARTo = $email["to"];

for($i=0;$i<count($ARTo);$i++) {
	$name = $ARTo[$i]["name"];
	$thismail = $ARTo[$i]["mail"];
	$link = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
	$ARTo[$i]["link"] = $link;
	$ARTo[$i]["title"] = "$name <$thismail>";
	$smarty->assign("dmTOList",$ARTo);
}
$ARCC = $email["cc"];
if(count($ARCC) > 0) {
	$smarty->assign("dmHaveCC",1);
	for($i=0;$i<count($ARCC);$i++) {
		$name = $ARCC[$i]["name"];
		$thismail = $ARCC[$i]["mail"];
		$link = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
		$ARCC[$i]["link"] = $link;
		$ARCC[$i]["title"] = "$name <$thismail>";
	}
	$smarty->assign("dmCCList",$ARCC);
}

$smarty->assign("dmPageTitle",$email["subject"]);

$smarty->assign("dmSubject",$email["subject"]);
$smarty->assign("dmDate",$email["date"]);

$anexos = $email["attachments"];


$haveattachs = (count($anexos) > 0)?1:0;
$smarty->assign("dmHaveAttachments",$haveattachs);

if(count($anexos) > 0) {
	for($i=0;$i<count($anexos);$i++) {
		$link1 = "download-attachment.php?folder=$folder&ix=$ix&mnum=$mnum&bound=".base64_encode($anexos[$i]["boundary"])."&part=".$anexos[$i]["part"]."&tid=$tid&lid=$lid";
		$link2 = "$link1&down=1";
		$anexos[$i]["normlink"] = $link1;
		$anexos[$i]["downlink"] = $link2;
		$anexos[$i]["size"] = ceil($anexos[$i]["size"]/1024);
		$anexos[$i]["type"] = trim($anexos[$i]["content-type"]);
	}
	$smarty->assign("dmAttachList",$anexos);
}

unset($DM);

$smarty->display("$selected_theme/print-message.htm");

?>