<?php





require("./inc/inc.php");
if(!isset($ix) || !isset($folder)) redirect("error-page.php?err=3&tid=$tid&lid=$lid");

$filename = $userfolder."_infos/filters.ucf";
$myfile = $DM->_read_file($filename);
$filters = Array();

if($myfile != "") 
	$filters = unserialize(base64_decode($myfile));

function is_in_filter($email) {
	global $filters;
	foreach($filters as $filter) {
		if($filter["type"] == FL_TYPE_DELETE && $filter["match"] == $email)
			return true;
	}
	return false;
}

$mail_info = $sess["headers"][base64_encode($folder)][$ix];

$emails = Array();
$from = $mail_info["from"];
$to = $mail_info["to"];
$cc = $mail_info["cc"];


for($i=0;$i<count($from);$i++) {
	if(!is_in_filter($from[$i]["mail"])) {
		$from[$i]["index"] = $i;
		$emails[] = $from[$i];
	}
}
$aval = array();


if(isset($fFilter)) {
	for($i=0;$i<count($fFilter);$i++) {

		$filters[] = Array(
					"type" 		=> 2,
					"field"		=> 1,
					"match"		=>  $emails[$fFilter[$i]]["mail"],
					);
	}

	$DM->_save_file($filename,base64_encode(serialize($filters)));

	echo("
	<script language=javascript>
		self.close();
	</script>
	");
	exit;
} else {

	$smarty->assign("dmLid",$lid);
	$smarty->assign("dmSid",$sid);
	$smarty->assign("dmFolder",$folder);
	$smarty->assign("dmIx",$ix);
	$smarty->assign("dmAvailableAddresses",count($emails));

	$smarty->assign("dmAddressList",$emails);

	$smarty->display("$selected_theme/block-address.htm");
}
?>