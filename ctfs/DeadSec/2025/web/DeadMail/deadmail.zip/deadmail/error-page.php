<?php

require("./inc/config.php");
require("./inc/lib.php");

define("SMARTY_DIR","./smarty/");
require_once(SMARTY_DIR."Smarty.class.php");
$smarty = new Smarty;
$smarty->compile_dir = $temporary_directory;
$smarty->security=true;
$smarty->secure_dir=array("./");
$smarty->assign("dmLanguageFile",$selected_language.".txt");


$phpver = phpversion();
$phpver = doubleval($phpver[0].".".$phpver[2]);

if($phpver >= 4.1) {
	extract($_GET);
}

$smarty->assign("dmSid",$sid);
$smarty->assign("dmLid",$lid);
$smarty->assign("dmTid",$tid);

$smarty->assign("dmErrorCode",$err);

$smarty->display("$selected_theme/error.htm");
?>