<?php

require("./inc/inc.php");

if(!isset($ix) || !isset($pag)) redirect("error-page.php?err=3&tid=$tid&lid=$lid");

$folderkey = base64_encode($folder);

$mysess 		= $sess["headers"][$folderkey];
$mail_info 		= $mysess[$ix];
$arAttachment 	= Array();


if(isset($attachment)) {

	$is_attached = true;
	$arAttachment 	= explode(",",$attachment);

	$DM->current_level = $arAttachment;

	$root = $mail_info;
	foreach($arAttachment as $item )
		if(is_numeric($item))
			$root = &$root["attachments"][$item];

	if( !is_array($root) || 
		!file_exists($root["filename"])) redirect("error-page.php?err=3&tid=$tid&lid=$lid");

	$result = $DM->_read_file($root["filename"]);

} else {
	$is_attached = false;
	$arAttachment = Array();

	if(!$DM->mail_connect()) { redirect("error-page.php?err=1&tid=$tid&lid=$lid"); exit; }
	if(!$DM->mail_auth()) { redirect("login-error-page.php?tid=$tid&lid=$lid&error=".urlencode($DM->mail_error_msg)); exit; }

	if(!($result = $DM->mail_retr_msg($mail_info,1))) { 
		redirect("message-list.php?err=2&folder=".urlencode($folder)."&pag=$pag&tid=$tid&lid=$lid&refr=true"); 
		exit; 
	}

	if($DM->mail_set_flag($mail_info,"\\SEEN","+")) {
		$sess["headers"][$folderkey][$ix] = $mail_info;
	}

	$DM->mail_disconnect(); 

}
echo($nocache);

$DM->displayimages = $prefs["display-images"];
$DM->allow_scripts = $allow_scripts;

$email = $DM->Decode($result);


if($ix > 0) {

	$dmHavePrevious 	= 1;
	$dmPreviousSubject 	= $mysess[($ix-1)]["subject"];
	$dmPreviousLink 	= "read-message.php?folder=".urlencode($folder)."&pag=$pag&ix=".($ix-1)."&tid=$tid&lid=$lid";

	$smarty->assign("dmHavePrevious",$dmHavePrevious);
	$smarty->assign("dmPreviousSubject",$dmPreviousSubject);
	$smarty->assign("dmPreviousLink",$dmPreviousLink);

}

if($ix < (count($mysess)-1)) {
	$dmHaveNext 	= 1;
	$dmNextSubject 	= $mysess[($ix+1)]["subject"];
	$dmNextLink 	= "read-message.php?folder=".urlencode($folder)."&pag=$pag&ix=".($ix+1)."&tid=$tid&lid=$lid";
	$smarty->assign("dmHaveNext",$dmHaveNext);
	$smarty->assign("dmNextSubject",$dmNextSubject);
	$smarty->assign("dmNextLink",$dmNextLink);
}



$body	= 	$email["body"];

if($block_external_images) 
	$body = eregi_replace("(src|background)=([\"]?)(http[s]?:\/\/[a-z0-9~#%@\&:=?+\/\.,_-]+[a-z0-9~#%@\&=?+\/_-]+)([\"]?)","\\1=\\2images/trans.gif\\4 original_url=\"\\3\"",$body);


$redir_path = getenv("PHP_SELF")?getenv("PHP_SELF"):$_SERVER["PHP_SELF"];
if(!$redir_path) $redir_path = $PHP_SELF;
$redir_path = dirname($redir_path)."/redirect.php";

$body = eregi_replace("target=[\"]?[A-Z_]+[\"]?","target=\"blank\"",$body);
$body = eregi_replace("href=\"http([s]?)://","target=\"_blank\" href=\"$redir_path?http\\1://",$body);
$body = eregi_replace("href=\"mailto:","target=\"_top\" href=\"new-message.php?tid=$tid&lid=$lid&to=",$body);

$uagent = 	$HTTP_SERVER_VARS["HTTP_USER_AGENT"];

$ns4    = 	(ereg("Mozilla/4",$uagent) && !ereg("MSIE",$uagent) && 
			!ereg("Gecko",$uagent));
$ns6moz = 	ereg("Gecko",$uagent);
$ie4up  = 	ereg("MSIE (4|5|6)",$uagent);
$other	= 	(!$ns4 && !$ns6moz && !$ie4up);


if ($other) {
	$body 	= 	eregi_replace("<base","<deadmail_base_not_alowed",
				eregi_replace("<link","<deadmail_link_not_alowed",
				$body));

	if(eregi("<[ ]*body.*background[ ]*=[ ]*[\"']?([A-Za-z0-9._&?=:/{}%+-]+)[\"']?.*>",$body,$regs))
		$backimg = 	" background=\"".$regs[1]."\"";
	$smarty->assign("dmBackImg",$backimg);
	if(eregi("<[ ]*body[A-Z0-9._&?=:/\"' -]*bgcolor=[\"']?([A-Z0-9#]+)[\"']?[A-Z0-9._&?=:/\"' -]*>",$body,$regs))
		$backcolor = " bgcolor=\"".$regs[1]."\"";
	$smarty->assign("dmBackColor",$backcolor);

	$body = eregi_replace("<body","<deadmail_body_not_alowed",$body);
	$body = eregi_replace("a:(link|visited|hover)",".".uniqid(""),$body);
	$body = eregi_replace("(body)[ ]?\\{",".".uniqid(""),$body);

} elseif($ie4up || $ns6moz) {
	$sess["currentbody"] = $body;;
	$body = "<iframe src=\"message-body.php?tid=$tid&lid=$lid&folder=".htmlspecialchars($folder)."&ix=$ix\" width=\"100%\" height=\"400\" frameborder=\"0\"></iframe>";

} elseif($ns4) {
	$sess["currentbody"] = $body;;
	$body = "<ilayer width=\"100%\" left=\"0\" top=\"0\">$body</ilayer>";
}

$smarty->assign("dmMessageBody",$body);


$ARFrom = $email["from"];
$useremail = $sess["email"];
$name = $ARFrom[0]["name"];
$thismail = $ARFrom[0]["mail"];
$ARFrom[0]["link"] = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
$ARFrom[0]["title"] = "$name <$thismail>";

$smarty->assign("dmFromList",$ARFrom);
$ARTo = $email["to"];

for($i=0;$i<count($ARTo);$i++) {
	$name = $ARTo[$i]["name"];
	$thismail = $ARTo[$i]["mail"];
	$link = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
	$ARTo[$i]["link"] = $link;
	$ARTo[$i]["title"] = "$name <$thismail>";
	$smarty->assign("dmTOList",$ARTo);
}
$ARCC = $email["cc"];
if(count($ARCC) > 0) {
	$smarty->assign("dmHaveCC",1);
	for($i=0;$i<count($ARCC);$i++) {
		$name = $ARCC[$i]["name"];
		$thismail = $ARCC[$i]["mail"];
		$link = "new-message.php?nameto=".urlencode($name)."&mailto=$thismail&tid=$tid&lid=$lid";
		$ARCC[$i]["link"] = $link;
		$ARCC[$i]["title"] = "$name <$thismail>";
	}
	$smarty->assign("dmCCList",$ARCC);
}

$smarty->assign("dmPageTitle",$email["subject"]);

$jssource = "
<script language=\"JavaScript\">
function deletemsg() { 
	if(confirm('".ereg_replace("'","\\'",$confirm_delete)."')) 
		with(document.move) { decision.value = 'delete'; submit(); } 
}
function reply() { document.msg.submit(); }
function movemsg() { document.move.submit(); }
function newmsg() {	location = 'new-message.php?folder=$folder&pag=$pag&tid=$tid&lid=$lid'; }
function headers() { mywin = window.open('message-headers.php?folder=".urlencode($folder)."&ix=$ix&tid=$tid&lid=$lid','Headers','width=550, top=100, left=100, height=320,directories=no,toolbar=no,status=no,scrollbars=yes,resizable=yes'); }
function catch_addresses() { window.open('catch-address.php?folder=".urlencode($folder)."&ix=$ix&tid=$tid&lid=$lid','Catch','width=550, top=100, left=100, height=320,directories=no,toolbar=no,status=no,scrollbars=yes'); }
function block_addresses() { window.open('block-address.php?folder=".urlencode($folder)."&ix=$ix&tid=$tid&lid=$lid','Block','width=550, top=100, left=100, height=320,directories=no,toolbar=no,status=no,scrollbars=yes'); }

function replyall() { with(document.msg) { rtype.value = 'replyall'; submit(); } }
function forward() { with(document.msg) { rtype.value = 'forward'; submit(); } }
function newmsg() { location = 'new-message.php?pag=$pag&folder=".urlencode($folder)."&tid=$tid&lid=$lid'; }
function folderlist() { location = 'manage-folders.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid'}
function goend() { location = 'logout.php?tid=$tid&lid=$lid'; }
function goinbox() { location = 'message-list.php?folder=inbox&tid=$tid&lid=$lid'; }
function goback() { location = 'message-list.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid&pag=$pag'; }
function search() { location = 'search.php?tid=$tid&lid=$lid'; }
function emptytrash() {	location = 'manage-folders.php?empty=trash&folder=".urlencode($folder)."&goback=true&tid=$tid&lid=$lid';}
function addresses() { location = 'address-book.php?tid=$tid&lid=$lid'; }
function prefs() { location = 'settings.php?tid=$tid&lid=$lid'; }
function printit() { window.open('print-message.php?tid=$tid&lid=$lid&folder=".urlencode($folder)."&ix=$ix','PrintView','resizable=1,top=10,left=10,width=600,heigth=500,scrollbars=1,status=0'); }
function openmessage(attach) { window.open('read-message.php?folder=".urlencode($folder)."&pag=$pag&ix=$ix&tid=$tid&lid=$lid&attachment='+attach,'','resizable=1,top=10,left=10,width=600,height=400,scrollbars=1,status=0'); }
function openwin(targetUrl) { window.open(targetUrl); }
</script>
";

$dmDeleteForm = "<input type=hidden name=lid value=$lid>
<input type=hidden name=sid value=\"$sid\">
<input type=hidden name=tid value=\"$tid\">
<input type=hidden name=decision value=move>
<input type=hidden name=folder value=\"".htmlspecialchars($folder)."\">
<input type=hidden name=pag value=$pag>
<input type=hidden name=start_pos value=$ix>
<input type=hidden name=end_pos value=".($ix+1).">
<input type=hidden name=msg_$ix value=X>
<input type=hidden name=back value=true>";

$dmReplyForm = "<form name=msg action=\"new-message.php\" method=POST>
<input type=hidden name=rtype value=\"reply\">
<input type=hidden name=sid value=\"$sid\">
<input type=hidden name=lid value=\"$lid\">
<input type=hidden name=tid value=\"$tid\">
<input type=hidden name=folder value=\"".htmlspecialchars($folder)."\">
<input type=hidden name=ix value=\"$ix\">
</form>
";

$smarty->assign("dmDeleteForm",$dmDeleteForm);
$smarty->assign("dmReplyForm",$dmReplyForm);
$smarty->assign("dmJS",$jssource);

$smarty->assign("dmSubject",$email["subject"]);
$smarty->assign("dmDate",$email["date"]);

$anexos = $email["attachments"];
$haveattachs = (count($anexos) > 0)?1:0;

if(count($anexos) > 0) {
	$root = &$mail_info["attachments"];

	foreach($arAttachment as $item ) {
		if(is_numeric($item)) {
			$root = &$root[$item]["attachments"];
		}
	}

	$root = $email["attachments"];
	$sess["headers"][$folderkey][$ix] = $mail_info;

	$nIndex = count($arAttachment);
	$attachAr = Array();

	for($i=0;$i<count($anexos);$i++) {

		$arAttachment[$nIndex] 	= $i;
		$link1 = "download-attachment.php?folder=$folder&ix=$ix&attach=".join(",",$arAttachment)."&tid=$tid&lid=$lid";
		$link2 = "$link1&down=1";

		if(!$anexos[$i]["temp"]) {
			if($anexos[$i]["content-type"] == "message/rfc822") 
				$anexos[$i]["normlink"]	= "<a href=\"javascript:openmessage('".join(",",$arAttachment)."')\">";
			else
				$anexos[$i]["normlink"] = "<a href=\"$link1\" target=\"_new\">";

			$anexos[$i]["downlink"] = "<a href=\"$link2\" target=\"_new\">";
			$anexos[$i]["size"] = ceil($anexos[$i]["size"]/1024);
			$anexos[$i]["type"] = $anexos[$i]["content-type"];
			$attachAr[] = $anexos[$i];
		}
	}
	$smarty->assign("dmHaveAttachments",(count($attachAr) > 0));
	$smarty->assign("dmAttachList",$attachAr);
}

$SS->Save($sess);

$avalfolders = Array();
$d = dir($userfolder);
while($entry=$d->read()) {
	if(	is_dir($userfolder.$entry) && 
		$entry != ".." && 
		$entry != "." && 
		substr($entry,0,1) != "_" && 
		$entry != $folder &&
		($DM->mail_protocol == "imap" || $entry != "inbox")) {
		$entry = $DM->fix_prefix($entry,0);
		switch($entry) {
		case $sess["sysmap"]["inbox"]:
			$display = $inbox_extended;
			break;
		case $sess["sysmap"]["sent"]:
			$display = $sent_extended;
			break;
		case $sess["sysmap"]["trash"]:
			$display = $trash_extended;
			break;
		default:
			$display = $entry;
		}
		$avalfolders[] = Array("path" => $entry, "display" => $display);

	}
}
$d->close();
$smarty->assign("dmAvalFolders",$avalfolders);
unset($DM);

if($is_attached)
	$smarty->display("$selected_theme/readmsg_popup.htm");
else
	$smarty->display("$selected_theme/readmsg.htm");
?>
