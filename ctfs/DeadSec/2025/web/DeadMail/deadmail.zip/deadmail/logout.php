<?php


require("./inc/inc.php");

if(is_array($sess["headers"]) && file_exists($userfolder)) {

	$inboxdir = $userfolder."inbox/";
	$d = dir($userfolder."_attachments/");
	while($entry=$d->read()) {
		if($entry != "." && $entry != "..") 
			unlink($userfolder."_attachments/$entry");
	}
	$d->close();

	if(is_array($sess["folders"])) {
		$boxes = $sess["folders"];

		for($n=0;$n<count($boxes);$n++) {

			$entry = $boxes[$n]["name"];
			$file_list = Array();

			if(is_array($curfolder = $sess["headers"][base64_encode($entry)])) {

				for($j=0;$j<count($curfolder);$j++) 
					$file_list[] = $curfolder[$j]["localname"];

				$d = dir($userfolder."$entry/");

				while($curfile=$d->read()) {
					if($curfile != "." && $curfile != "..") {
						$curfile = $userfolder."$entry/$curfile";
						if(!in_array($curfile,$file_list)) 
							@unlink($curfile);
					}
				}
				$d->close();
			}
		}
	}


	if($prefs["empty-trash"]) {
		if(!$DM->mail_connect()) { redirect("error-page.php?err=1&tid=$tid&lid=$lid"); exit; }
		if(!$DM->mail_auth()) { redirect("login-error-page.php?tid=$tid&lid=$lid&error=".urlencode($DM->mail_error_msg)); exit; }
		$trash = $sysmap["trash"];
		if(!is_array($sess["headers"][base64_encode($trash)])) $sess["headers"][base64_encode($trash)] = $DM->mail_list_msgs($trash);
		$trash = $sess["headers"][base64_encode($trash)];

		if(count($trash) > 0) {
			for($j=0;$j<count($trash);$j++) {
				$DM->mail_delete_msg($trash[$j],false);
			}
			$DM->mail_expunge();
		}
		$DM->mail_disconnect();
	}
	$SS->Kill();
}	

redirect("./login.php");
?> 