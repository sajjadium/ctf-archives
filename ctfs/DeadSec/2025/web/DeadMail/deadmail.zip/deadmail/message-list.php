<?php


require("./inc/inc.php");


require("./folder-list.php");

$smarty->assign("dmUser",$f_user);
$refreshurl = "process-request.php?tid=$tid&lid=$lid&folder=".urlencode($folder)."&pag=$pag&refr=true";



if(!is_array($headers = $sess["headers"][base64_encode($folder)])) { redirect("error-page.php?err=3&plus=true&tid=$tid&lid=$lid"); exit; }

$arrow = ($sortorder == "ASC")?"images/arrow_up.gif":"images/arrow_down.gif";
$arrow = "&nbsp;<img src=$arrow width=8 height=7 border=0 alt=>";

$attach_arrow  	= "";
$subject_arrow 	= "";
$fromname_arrow = "";
$date_arrow 	= "";
$size_arrow 	= "";

switch($sortby) {
	case "subject":
		$subject_arrow  	= $arrow;
		break;
	case "fromname":
		$fromname_arrow  	= $arrow;
		break;
	case "date":
		$date_arrow  		= $arrow;
		break;
	case "size":
		$size_arrow   		= $arrow;
		break;
}

$elapsedtime = (time()-$sess["last-update"])/60;
$timeleft = ($prefs["refresh-time"]-$elapsedtime);

if($timeleft > 0) {
	echo("<META HTTP-EQUIV=\"Refresh\" CONTENT=\"".(ceil($timeleft)*60)."; URL=$refreshurl\">");
} elseif ($prefs["refresh-time"]) {
	redirect("$refreshurl");
}


$totalused = 0;
while(list($box,$info) = each($sess["headers"])) {
	for($i=0;$i<count($info);$i++)
		$totalused += $info[$i]["size"];
}



$smarty->assign("dmTotalUsed",ceil($totalused/1024));
$quota_enabled = ($quota_limit)?1:0;
$smarty->assign("dmQuotaEnabled",$quota_enabled);
$smarty->assign("dmQuotaLimit",$quota_limit);
$usageGraph = get_usage_graphic(($totalused/1024),$quota_limit);
$smarty->assign("dmUsageGraph",$usageGraph);

$exceeded = (($quota_limit) && (ceil($totalused/1024) >= $quota_limit));


$smarty->assign("dmAttachArrow",$attach_arrow);
$smarty->assign("dmSubjectArrow",$subject_arrow);
$smarty->assign("dmFromArrow",$fromname_arrow);
$smarty->assign("dmDateArrow",$date_arrow);
$smarty->assign("dmSizeArrow",$size_arrow);


$nummsg = count($headers);
if(!isset($pag) || !is_numeric(trim($pag))) $pag = 1;

$reg_pp    = $prefs["rpp"];
$start_pos = ($pag-1)*$reg_pp;
$end_pos   = (($start_pos+$reg_pp) > $nummsg)?$nummsg:$start_pos+$reg_pp;

if(($start_pos >= $end_pos) && ($pag != 1)) redirect("message-list.php?folder=$folder&pag=".($pag-1)."&tid=$tid&lid=$lid\r\n");

echo($nocache);

$jsquota = ($exceeded)?"true":"false";
$jssource = "
<script language=\"JavaScript\">
no_quota  = $jsquota;
quota_msg = '".preg_replace("/'/", "\\'", $quota_exceeded)."';
function readmsg(ix,read) {
	if(!read && no_quota)
		alert(quota_msg)
	else
		location = 'read-message.php?folder=".urlencode($folder)."&pag=$pag&ix='+ix+'&tid=$tid&lid=$lid'; 
}
function newmsg() { location = 'new-message.php?pag=$pag&folder=".urlencode($folder)."&tid=$tid&lid=$lid'; }
function refreshlist() { location = 'process-request.php?refr=true&folder=".urlencode($folder)."&pag=$pag&tid=$tid&lid=$lid' }
function folderlist() { location = 'manage-folders.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid'}
function delemsg() { document.form1.submit() }
function goend() { location = 'logout.php?tid=$tid&lid=$lid'; }
function goinbox() { location = 'message-list.php?folder=inbox&tid=$tid&lid=$lid'; }
function search() { location = 'search.php?tid=$tid&lid=$lid'; }
function emptytrash() {	location = 'manage-folders.php?empty=trash&folder=".urlencode($folder)."&goback=true&tid=$tid&lid=$lid';}
function movemsg() { 
	if(no_quota) 
		alert(quota_msg);
	else {
		with(document.form1) { decision.value = 'move'; submit(); } 
	}
}
function addresses() { location = 'address-book.php?tid=$tid&lid=$lid'; }
function prefs() { location = 'settings.php?tid=$tid&lid=$lid'; }
function sel() {
	with(document.form1) {
		for(i=0;i<elements.length;i++) {
			thiselm = elements[i];
			if(thiselm.name.substring(0,3) == 'msg')
				thiselm.checked = !thiselm.checked
		}
	}
}
sort_colum = '$sortby';
sort_order = '$sortorder';

function sortby(col) {
	if(col == sort_colum) ord = (sort_order == 'ASC')?'DESC':'ASC';
	else ord = 'ASC';
	location = 'process-request.php?folder=$folder&pag=$pag&sortby='+col+'&sortorder='+ord+'&tid=$tid&lid=$lid';
}

</script>
";

if(isset($msg))
	$smarty->assign("dmErrorMessage",$msg);


$forms = "<input type=hidden name=lid value=$lid>
<input type=hidden name=sid value=\"$sid\">
<input type=hidden name=tid value=\"$tid\">
<input type=hidden name=decision value=delete>
<input type=hidden name=folder value=\"".htmlspecialchars($folder)."\">
<input type=hidden name=pag value=$pag>
<input type=hidden name=start_pos value=$start_pos>
<input type=hidden name=end_pos value=$end_pos>";


$smarty->assign("dmJS",$jssource);
$smarty->assign("dmForms",$forms);
$smarty->assign("dmUserEmail",$sess["email"]);
$smarty->assign("dmFolder",$folder);

$messagelist = Array();

$newmsgs = 0;
if($nummsg > 0) {
	
	for($i=0;$i<count($headers);$i++)
		if(!eregi("\\SEEN",$headers[$i]["flags"])) $newmsgs++;

	for($i=$start_pos;$i<$end_pos;$i++) {
		$mnum = $headers[$i]["id"]; 

		$read = (eregi("\\SEEN",$headers[$i]["flags"]))?"true":"false";
		$readlink = "javascript:readmsg($i,$read)";
		$composelink = "new-message.php?folder=$folder&nameto=".htmlspecialchars($headers[$i]["from"][0]["name"])."&mailto=".htmlspecialchars($headers[$i]["from"][0]["mail"])."&tid=$tid&lid=$lid";
		$composelinksent = "new-message.php?folder=$folder&nameto=".htmlspecialchars($headers[$i]["to"][0]["name"])."&mailto=".htmlspecialchars($headers[$i]["to"][0]["name"])."&tid=$tid&lid=$lid";

		$from = $headers[$i]["from"][0]["name"];
		$to = $headers[$i]["to"][0]["name"];
		$subject = $headers[$i]["subject"];
		if(!eregi("\\SEEN",$headers[$i]["flags"])) {
			$msg_img = "./images/msg_unread.gif";
		} elseif (eregi("\\ANSWERED",$headers[$i]["flags"])) {
			$msg_img = "./images/msg_answered.gif";
		} else {
			$msg_img = "./images/msg_read.gif";
		}
		$prior = $headers[$i]["priority"];
		if($prior == 4 || $prior == 5)
			$img_prior = "&nbsp;<img src=\"./images/prior_low.gif\" width=5 height=11 border=0 alt=\"\">";
		elseif($prior == 1 || $prior == 2)
			$img_prior = "&nbsp;<img src=\"./images/prior_high.gif\" width=5 height=11 border=0 alt=\"\">";
		else
			$img_prior = "";

		$msg_img = "&nbsp;<img src=\"$msg_img\" width=14 height=14 border=0 alt=\"\">";
		$checkbox = "<input type=\"checkbox\" name=\"msg_$i\" value=1>";
		$attachimg = ($headers[$i]["attach"])?"&nbsp;<img src=images/attach.gif border=0>":"";

		$date = $headers[$i]["date"];
		$size = ceil($headers[$i]["size"]/1024);
		$index = count($messagelist);

		$messagelist[$index]["read"] = $read;
		$messagelist[$index]["readlink"] = $readlink;
		$messagelist[$index]["composelink"] = $composelink;
		$messagelist[$index]["composelinksent"] = $composelinksent;
		$messagelist[$index]["from"] = $from;
		$messagelist[$index]["to"] = $to;
		$messagelist[$index]["subject"] = $subject;
		$messagelist[$index]["date"] = $date;
		$messagelist[$index]["statusimg"] = $msg_img;
		$messagelist[$index]["checkbox"] = $checkbox;
		$messagelist[$index]["attachimg"] = $attachimg;
		$messagelist[$index]["priorimg"] = $img_prior;
		$messagelist[$index]["size"] = $size;
	}

} 

$smarty->assign("dmNumMessages",$nummsg);
$smarty->assign("dmNumUnread",$newmsgs);
$smarty->assign("dmMessageList",$messagelist);


switch($folder) {
case $sess["sysmap"]["inbox"]:
	$display = $inbox_extended;
	break;
case $sess["sysmap"]["sent"]:
	$display = $sent_extended;
	break;
case $sess["sysmap"]["trash"]:
	$display = $trash_extended;
	break;
default:
	$display = $folder;
}

$smarty->assign("dmBoxName",$display);

if($nummsg > 0) {
	if($pag > 1) $smarty->assign("dmPreviousLink","message-list.php?folder=$folder&pag=".($pag-1)."&tid=$tid&lid=$lid");
	for($i=1;$i<=ceil($nummsg / $reg_pp);$i++) 
		if($pag == $i) $navigation .= "$i ";
		else $navigation .= "<a href=\"message-list.php?folder=$folder&pag=$i&tid=$tid&lid=$lid\" class=\"navigation\">$i</a> ";
	if($end_pos < $nummsg) $smarty->assign("dmNextLink","message-list.php?folder=$folder&pag=".($pag+1)."&tid=$tid&lid=$lid");
	$navigation .= " ($pag/".ceil($nummsg / $reg_pp).")";
}

$smarty->assign("dmNavBar",$navigation);


$avalfolders = Array();
$d = dir($userfolder);
while($entry=$d->read()) {
	if(	is_dir($userfolder.$entry) && 
		$entry != ".." && 
		$entry != "." && 
		substr($entry,0,1) != "_" && 
		$entry != $folder &&
		($DM->mail_protocol == "imap" || $entry != "inbox")) {

		switch(strtolower($entry)) {
		case strtolower($sess["sysmap"]["inbox"]):
			$display = $inbox_extended;
			break;
		case strtolower($sess["sysmap"]["sent"]):
			$display = $sent_extended;
			break;
		case strtolower($sess["sysmap"]["trash"]):
			$display = $trash_extended;
			break;
		default:
			$display = $entry;
			break;
		}
		$avalfolders[] = Array("path" => $entry, "display" => $display);
	}
}
$d->close();

unset($DM);

$smarty->assign("dmAvalFolders",$avalfolders);
$smarty->display("$selected_theme/messagelist.htm");

?>
