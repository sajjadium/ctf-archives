<?php

require("./inc/inc.php");


if(!$DM->mail_connect()) redirect("error-page.php?err=1&tid=$tid&lid=$lid\r\n");
if(!$DM->mail_auth()) { redirect("login-error-page.php?tid=$tid&lid=$lid&error=".urlencode($DM->mail_error_msg)."\r\n"); exit; }

$newfolder = trim($newfolder);

$require_update = false;


if($newfolder != "" && 
	ereg("[A-Za-z0-9 -]",$newfolder) && 
	!file_exists($userfolder.$newfolder)) {
	$DM->mail_create_box($newfolder);
	$require_update = true;
}
if(	$delfolder != "" && 
	$delfolder != $sess["sysmap"]["inbox"] && 
	$delfolder != $sess["sysmap"]["sent"] && 
	$delfolder != $sess["sysmap"]["trash"] && 
	ereg("[A-Za-z0-9 -]",$delfolder) &&
	(strpos($delfolder,"..") === false)) {
	if($DM->mail_delete_box($delfolder)) {
		unset($sess["headers"][base64_encode($delfolder)]);
		$require_update = true;
	}
}

if($require_update)	$sess["folders"] = $DM->mail_list_boxes();

require("./folder-list.php");


if(isset($empty)) {
	$headers = $sess["headers"][base64_encode($empty)];
	for($i=0;$i<count($headers);$i++) {
		$DM->mail_delete_msg($headers[$i],$prefs["save-to-trash"],$prefs["st-only-read"]);
		$expunge = true;
	}
	if($expunge) {
		$DM->mail_expunge();
		unset($sess["headers"][base64_encode($empty)]);
		
		if($prefs["save-to-trash"])
			unset($sess["headers"][base64_encode("trash")]);
		$SS->Save($sess);
	}
	if(isset($goback)) redirect("process-request.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid");

}

$jssource = "
<script language=\"JavaScript\">
function newmsg() { location = 'new-message.php?pag=$pag&folder=".urlencode($folder)."&tid=$tid&lid=$lid'; }
function refreshlist() { location = 'manage-folders.php?folder=".urlencode($folder)."&tid=$tid&lid=$lid'}
function goend() { location = 'logout.php?tid=$tid&lid=$lid'; }
function search() { location = 'search.php?tid=$tid&lid=$lid'; }
function goinbox() { location = 'message-list.php?folder=".$sess["sysmap"]["inbox"]."&tid=$tid&lid=$lid'; }
function emptytrash() {	location = 'manage-folders.php?empty=".$sess["sysmap"]["trash"]."&folder=".urlencode($folder)."&goback=true&tid=$tid&lid=$lid';}
function addresses() { location = 'address-book.php?tid=$tid&lid=$lid'; }
function prefs() { location = 'settings.php?tid=$tid&lid=$lid'; }
function create() {
	strPat = /[^A-Za-z0-9 -]/;
	frm = document.forms[0];
	strName = frm.newfolder.value
	mathArray = strName.match(strPat)
	if(mathArray != null) {
		alert('".ereg_replace("'","\\'",$error_invalid_name)."')
		return false;
	}else
		frm.submit();
}
</script>
";


$smarty->assign("dmJS",$jssource);
$smarty->assign("dmLid",$lid);
$smarty->assign("dmTid",$tid);
$smarty->assign("dmSid",$sid);
$smarty->assign("dmUserEmail",$sess["email"]);


$boxes = $DM->mail_list_boxes();

$scounter = 0;
$pcounter = 0;

for($n=0;$n<count($boxes);$n++) {
	$entry = $boxes[$n]["name"];
	$unread = 0;

	if(!is_array($sess["headers"][base64_encode($entry)])) {
		$thisbox = $DM->mail_list_msgs($entry);
		$sess["headers"][base64_encode($entry)] = $thisbox;
	} else $thisbox = $sess["headers"][base64_encode($entry)];

	$boxsize = 0;

	for($i=0;$i<count($thisbox);$i++) {
		if(!eregi("\\SEEN",$thisbox[$i]["flags"])) $unread++;
		$boxsize += $thisbox[$i]["size"];
	}

	$delete = "&nbsp;";

	if(!in_array($entry, $sess["sysfolders"]))
		$delete = "<a href=\"manage-folders.php?delfolder=$entry&folder=$folder&tid=$tid&lid=$lid\">OK</a>";

	$boxname = $entry;

	if($unread != 0) $unread = "<b>$unread</b>";

	if(in_array($entry, $sess["sysfolders"])) {
		switch(strtolower($entry)) {
		case strtolower($sess["sysmap"]["inbox"]):
			$boxname = $inbox_extended;
			break;
		case strtolower($sess["sysmap"]["sent"]):
			$boxname = $sent_extended;
			break;
		case strtolower($sess["sysmap"]["trash"]):
			$boxname = $trash_extended;
			break;
		}
		$system[$scounter]["entry"]     	= $entry;
		$system[$scounter]["name"]      	= $boxname;
		$system[$scounter]["msgs"]      	= count($thisbox)."/$unread";
		$system[$scounter]["del"]       	= $delete;
		$system[$scounter]["boxsize"]   	= ceil($boxsize/1024);
		$system[$scounter]["chlink"] 		= "process-request.php?folder=".$entry."&tid=$tid&lid=$lid";
		$system[$scounter]["emptylink"]		= "manage-folders.php?empty=".$entry."&folder=".$entry."&tid=$tid&lid=$lid";

		$scounter++;
	} else {

		$personal[$pcounter]["entry"]   	= $entry;
		$personal[$pcounter]["name"]    	= $boxname;
		$personal[$pcounter]["msgs"]    	= count($thisbox)."/$unread";
		$personal[$pcounter]["del"]    		= $delete;
		$personal[$pcounter]["boxsize"]	 	= ceil($boxsize/1024);
		$personal[$pcounter]["chlink"]  	= "process-request.php?folder=".urlencode($entry)."&tid=$tid&lid=$lid";
		$personal[$pcounter]["emptylink"]	= "manage-folders.php?empty=".urlencode($entry)."&folder=".urlencode($entry)."&tid=$tid&lid=$lid";

		$pcounter++;
	}
	$totalused += $boxsize;
}



$SS->Save($sess);
$DM->mail_disconnect();
unset($SS,$DM);
array_qsort2 ($system,"name");

if(!is_array($personal)) $personal = Array();

$dmFolderList = array_merge($system, $personal);


$smarty->assign("dmFolderList",$dmFolderList);

$smarty->assign("dmPersonal",$personal);
$smarty->assign("dmTotalUsed",ceil($totalused/1024));
$quota_enabled = ($quota_limit)?1:0;
$smarty->assign("dmQuotaEnabled",$quota_enabled);
$smarty->assign("dmQuotaLimit",$quota_limit);
$usageGraph = get_usage_graphic(($totalused/1024),$quota_limit);
$smarty->assign("dmUsageGraph",$usageGraph);
$noquota = (($totalused/1024) > $quota_limit)?1:0;
$smarty->assign("dmNoQuota",$noquota);

echo($nocache);

$smarty->display("$selected_theme/folders.htm");

?>
