<?php

require("./inc/config.php");
require("./inc/lib.php");

define("SMARTY_DIR","./smarty/");
require_once(SMARTY_DIR."Smarty.class.php");

$smarty = new Smarty;
$smarty->compile_dir = $temporary_directory;
$smarty->security=true;
$smarty->secure_dir=array("./");

$smarty->assign("dmLanguageFile",$selected_language.".txt");

$error = preg_replace("\[\]", "", $error);

$smarty->assign("dmServerResponse",$error);
$smarty->assign("dmLid",$lid);
$smarty->assign("dmTid",$tid);

$smarty->display("$selected_theme/bad-login.htm");


?>
