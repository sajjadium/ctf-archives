<?php

require("./inc/inc.php");
if(!isset($folder) || !isset($ix)) die("Expected parameters");
$mail_info = $sess["headers"][base64_encode($folder)][$ix];
$smarty->assign("dmPageTitle",$mail_info["subject"]);
$smarty->assign("dmHeaders",preg_replace("/\t/","&nbsp;&nbsp;&nbsp;&nbsp;",nl2br(htmlspecialchars($mail_info["header"]))));
$smarty->display("$selected_theme/headers-window.htm");

?>
