<html>
<?php
extract($_SERVER);
?>
<head>
	<meta http-equiv="refresh" content="0; url=<?=$QUERY_STRING?>">
</head>
<br>
<blockquote>
<a href="<?=$QUERY_STRING?>"><?=$QUERY_STRING?></a>
</blockquote>

</html>