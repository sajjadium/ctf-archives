const puppeteer = require("puppeteer");
const sleep = ms => new Promise(r => setTimeout(r, ms));

const goto = async (url) => {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: "new",
            executablePath: "/usr/bin/google-chrome-stable",
            args: [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                '--js-flags="--noexpose_wasm"'
            ],
        });
        const page = await browser.newPage();
        page.setDefaultNavigationTimeout(10 * 1000);

        // This will be changed in remote deployment
        // await page.goto("http://localhost:3000/login", {
        //     waitUntil: "networkidle0",
        // });

        await page.goto("http://grafana:3000/login", {
            waitUntil: "networkidle0",
        });

        const username = "admin";
        const password = "REDACTED";

        await page.type('[name="user"]', username, { delay: 100 });
        await page.type('[name="password"]', password, { delay: 100 });

        await page.waitForSelector('[type="submit"]', {
            visible: true,
        });
        await page.click('[type="submit"]');

        await page.waitForNavigation({ waitUntil: "networkidle0" });
        console.log(`Navigated to: ${page.url()}`);

        if (page.url().includes("login")) {
            throw new Error("Login failed!");
        }

        await sleep(1000);

        // Navigate to target URL
        console.log(`Navigating to target URL: ${url}`);
        await page.goto(url, {
            waitUntil: "networkidle0",
            timeout: 10000
        });
        console.log(`Successfully navigated to: ${url}`);

        await sleep(2000);

    } catch (error) {
        console.error(`Bot error: ${error.message}`);
        throw error;
    } finally {
        if (browser) {
            await browser.close();
        }
    }
}

module.exports = goto;