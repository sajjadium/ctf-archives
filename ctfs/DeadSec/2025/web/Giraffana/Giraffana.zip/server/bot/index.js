const express = require('express');
const path = require('path');
const goto = require('./bot');

const app = express();
const PORT = process.env.BOT_PORT || 1337;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/visit', async (req, res) => {
    const { url } = req.body;

    if (!url) {
        return res.status(400).json({ error: 'URL is required' });
    }

    // Validate URL format
    try {
        new URL(url);
    } catch (error) {
        return res.status(400).json({ error: 'Invalid URL format' });
    }

    // This will be changed in remote deployment
    // if (!url.startsWith('http://localhost:3000')) {
    //     return res.status(400).json({ 
    //         error: 'URL must start with http://localhost:3000' 
    //     });
    // }

    if (!url.startsWith('http://grafana:3000')) {
        return res.status(400).json({
            error: 'URL must start with http://grafana:3000'
        });
    }

    try {
        console.log(`Bot visiting: ${url}`);
        await goto(url);
        res.json({ success: true, message: 'Bot visited the URL successfully' });
    } catch (error) {
        console.error('Bot error:', error);
        res.status(500).json({ error: 'Failed to visit URL: ' + error.message });
    }
});

app.listen(PORT, () => {
    console.log(`Bot server running on port ${PORT}`);
});