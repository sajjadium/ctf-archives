from PIL import Image, ImageDraw, ImageFont
import cv2
import numpy as np
from tqdm import tqdm
import os
import argparse
import time
import ffmpeg
import tempfile

def font2bitmap(s, font, font_size):
  font_ttf = ImageFont.truetype(font, size=font_size)
  max_w = max_h = 0
  bitmaps = {}
  pad_left, pad_top, _, max_h = font_ttf.getbbox(s)
  for c in s:
    w = font_ttf.getbbox(c)[2]
    max_w = max(max_w, w)

  for c in s:
    image = Image.new('L', (max_w, max_h - pad_top), 0)
    draw = ImageDraw.Draw(image)
    draw.text(
      (-pad_left // 2, -pad_top),
      c,
      fill=255,
      font=font_ttf
    )
    bitmap = np.array(image)
    bitmaps[c] = bitmap
  
  fonts = np.array([bitmaps[c] for c in s])
  return fonts

def frame2ascii(gray_frame, font_bitmaps):
  l = len(font_bitmaps)

  if len(gray_frame.shape) == 3:
    gray_frame = np.dot(gray_frame,  [0.2990, 0.5870, 0.1140]).astype(np.uint16 if l < 32 else np.uint32)
    
  font_h, font_w = font_bitmaps[0].shape[:2]
  gray_frame = gray_frame[::font_h, ::font_w]
  frame_h, frame_w = gray_frame.shape[:2]

  index_buffer = np.empty(gray_frame.shape, dtype=np.uint16 if l < 32 else np.uint32)
  np.multiply(gray_frame, l, out=index_buffer)
  index_buffer >>= 8
  out_frame = font_bitmaps[index_buffer].transpose(0, 2, 1, 3).reshape(frame_h * font_h, frame_w * font_w)
  return out_frame

def video2ascii(file_path, charset, font, font_size, out_file):
  cap = cv2.VideoCapture(file_path)
  frameCount = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
  # frameWidth = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
  # frameHeight = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
  fps = int(cap.get(5))
  font_bitmaps = font2bitmap(charset, font, font_size)

  ret, first_frame = cap.read()
  if not ret:
    return 
  
  first_ascii_frame = frame2ascii(first_frame, font_bitmaps)
  h, w = first_ascii_frame.shape[:2]
  codec_id = "mp4v"  # ID for a video codec.

  fourcc = cv2.VideoWriter_fourcc(*codec_id)
  out = cv2.VideoWriter(out_file, fourcc, float(fps), (w, h), isColor=False)
  
  bar = tqdm(total=frameCount)
  out.write(first_ascii_frame)
  bar.update(1)
  bar.set_description('Converting...')
  while ret:
    ret, frame = cap.read()
    if not ret:
      break
    ascii_frame = frame2ascii(frame, font_bitmaps)
    bar.update(1)
    out.write(ascii_frame)

  bar.close()
  cv2.destroyAllWindows()
  cap.release()
  out.release()

def compress_video(video_full_path, output_file_name, target_size):
    probe = ffmpeg.probe(video_full_path)
    duration = float(probe['format']['duration'])
    target_total_bitrate = (target_size * 1024 * 8) / (1.073741824 * duration)
    video_bitrate = target_total_bitrate 
    i = ffmpeg.input(video_full_path)
    ffmpeg.output(i, output_file_name,
                  **{'c:v': 'libx264', 'b:v': video_bitrate, 'pass': 1, 'f': 'mp4'}
                  ).overwrite_output().run()

def parse_args():
    parser = argparse.ArgumentParser(description='Turn video into ASCII art')

    parser.add_argument('filename', help='File name of the input video.')
    parser.add_argument('out_dir', help='Directory in which to save output video.')

    parser.add_argument('-chars', '--characters', help='ASCII chars to use in media. Default is " .:-=+*#%%@"', default=' .:-=+*#%@')
    parser.add_argument('-f', '--fontsize',
                        help='Font size. Default is 12', type=int, default=12)
    parser.add_argument('-font', '--font', help='Font to use. Default is Firacode',
                        type=str, default='./fonts/fira.ttf')
    parser.add_argument('-c', '--compress', help='Size to compress video to. Default is 50MB',
                        type=int, default=50)
    return parser.parse_args()

def main():
  args = parse_args()

  assert args.fontsize > 0, 'Font size must be > 0.'

  if os.path.isdir(args.out_dir):
    tmp1 = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
    tmp2 = tempfile.NamedTemporaryFile(suffix=".mp4", delete=False)
    video2ascii(args.filename, args.characters, args.font, args.fontsize, tmp1.name)
    file_name = args.filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    out_file = args.out_dir + \
        f'/{file_name.split(".", 1)[0]}_{int(time.time())}.mp4'
    compress_video(tmp1.name, tmp2.name, args.compress * 1000)
    tmp1.close()
    os.unlink(tmp1.name)
    os.system(f"ffmpeg -an -i {tmp2.name} -vn -i {args.filename} -map 0:v -map 1:a -c:v copy -c:a copy -shortest {out_file}")
    tmp2.close()
    os.unlink(tmp2.name)
  else:
    print("out_dir is not a directory")


if __name__ == '__main__':
  main()
