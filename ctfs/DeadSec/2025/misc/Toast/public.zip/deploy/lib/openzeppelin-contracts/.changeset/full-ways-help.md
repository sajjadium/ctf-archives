---
'openzeppelin-solidity': minor
---

`EIP7702Utils`: Add a library for checking if an address has an EIP-7702 delegation in place.
