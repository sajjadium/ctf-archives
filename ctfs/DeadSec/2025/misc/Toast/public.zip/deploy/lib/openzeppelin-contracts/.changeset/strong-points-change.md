---
'openzeppelin-solidity': minor
---

`AccountERC7579Hooked`: Extension of `AccountERC7579` that implements support for ERC-7579 hook modules.
