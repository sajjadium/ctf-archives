---
'openzeppelin-solidity': minor
---

`ERC7739`: An abstract contract to validate signatures following the rehashing scheme from `ERC7739Utils`.
