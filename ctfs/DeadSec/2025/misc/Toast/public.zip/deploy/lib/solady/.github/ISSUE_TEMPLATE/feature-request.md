---
name: Feature request
about: Propose a new feature
title: ''
labels: ''
assignees: ''

---

<!--     Emoji Table:     -->
<!-- new feature       ✨ -->
