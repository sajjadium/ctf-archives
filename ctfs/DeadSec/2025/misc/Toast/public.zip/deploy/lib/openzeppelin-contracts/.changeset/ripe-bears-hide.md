---
'openzeppelin-solidity': minor
---

`ERC20Bridgeable`: Implementation of ERC-7802 that makes an ERC-20 compatible with crosschain bridges.
