---
'openzeppelin-solidity': minor
---

`GovernorNoncesKeyed`: Extension of `Governor` that adds support for keyed nonces when voting by sig.
