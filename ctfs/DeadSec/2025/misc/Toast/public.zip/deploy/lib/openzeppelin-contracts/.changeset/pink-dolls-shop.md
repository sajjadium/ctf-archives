---
'openzeppelin-solidity': minor
---

`EnumerableSet`: Add support for `StringSet` and `BytesSet` types.
