---
'openzeppelin-solidity': minor
---

`SignerERC7913`: Abstract signer that verifies signatures using the ERC-7913 workflow.
