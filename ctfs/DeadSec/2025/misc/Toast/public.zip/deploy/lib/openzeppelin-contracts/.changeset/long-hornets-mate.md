---
'openzeppelin-solidity': minor
---

`EnumerableMap`: Add support for `BytesToBytesMap` type.
