---
'openzeppelin-solidity': minor
---

`EnumerableSet`: Add `values(uint256,uint256)` that returns a subset (slice) of the values in the set.
