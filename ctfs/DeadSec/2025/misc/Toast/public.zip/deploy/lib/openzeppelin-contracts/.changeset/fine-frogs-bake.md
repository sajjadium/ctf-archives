---
'openzeppelin-solidity': minor
---

`EnumerableMap`: Add `keys(uint256,uint256)` that returns a subset (slice) of the keys in the map.
