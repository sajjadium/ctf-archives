---
name: Everything else
about: Refactors, cleanups, optimization, etc.
title: ''
labels: ''
assignees: ''

---

<!--     Emoji Table:     -->
<!-- readme/docs       📝 -->
<!-- refactor/cleanup  ♻️ -->
<!-- nit               🥢 -->
<!-- optimization      ⚡️ -->
<!-- configuration     👷‍♂️ -->
<!-- events            🔊 -->
