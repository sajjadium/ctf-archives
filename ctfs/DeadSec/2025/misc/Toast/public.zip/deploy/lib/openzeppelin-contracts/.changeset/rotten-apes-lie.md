---
'openzeppelin-solidity': minor
---

`IERC7821`, `ERC7821`: Interface and logic for minimal batch execution. No support for additional `opData` is included.
