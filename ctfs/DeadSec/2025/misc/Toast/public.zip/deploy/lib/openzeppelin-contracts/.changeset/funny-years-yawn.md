---
'openzeppelin-solidity': minor
---

`Account`: Added a simple ERC-4337 account implementation with minimal logic to process user operations.
