---
'openzeppelin-solidity': minor
---

`AccountERC7579`: Extension of `Account` that implements support for ERC-7579 modules of type executor, validator, and fallback handler.
