"""Check a list of 24 outputs and print the flag if the list is correct."""
import hashlib, json, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

SEALED = {"challenge_id": "the-shape-of-silence", "nonce": "1d4314f5dd915dbe232bf2df", "ciphertext": "1844726c37e6955909bef3070be4187712ef440640fd948b07a65242f2e00f9ebaee9635b7598af6de2425fa379198"}


def unlock(answer):
    enc = json.dumps(answer, ensure_ascii=True, separators=(',', ':')).encode('ascii')
    key = hashlib.sha256(b'isfcr-ml\0' + enc).digest()
    return AESGCM(key).decrypt(bytes.fromhex(SEALED['nonce']), bytes.fromhex(SEALED['ciphertext']),
                               SEALED['challenge_id'].encode()).decode()


if __name__ == '__main__':
    try:
        print(unlock(json.loads(sys.argv[1])))
    except (InvalidTag, ValueError):
        print('Rejected.')
