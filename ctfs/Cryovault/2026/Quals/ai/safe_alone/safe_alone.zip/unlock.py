"""Check a merge recipe and print the flag if it is correct."""
import hashlib, json, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

SEALED = {"challenge_id": "safe-alone", "kdf": "scrypt", "kdf_params": {"n": 131072, "r": 8, "p": 1}, "salt": "0cc42cf2f78a7694ce467f5a69ceeab5", "nonce": "84e173706968af6c55f85b6c", "ciphertext": "1caf93e62b7832bd1af8aae3c1005081d7775cdedec9dbfc6ee507ac91210f8e7ce7e5de4594f04b46cc18c8c3e742"}


def unlock(answer):
    enc = json.dumps(answer, ensure_ascii=True, separators=(',', ':')).encode('ascii')
    key = hashlib.scrypt(b'isfcr-ml\0' + enc, salt=bytes.fromhex(SEALED['salt']),
                         **SEALED['kdf_params'], maxmem=2**28, dklen=32)
    return AESGCM(key).decrypt(bytes.fromhex(SEALED['nonce']), bytes.fromhex(SEALED['ciphertext']),
                               SEALED['challenge_id'].encode('ascii')).decode('ascii')


if __name__ == '__main__':
    try:
        print(unlock(json.loads(sys.argv[1])))
    except (InvalidTag, ValueError):
        print('Rejected.')
