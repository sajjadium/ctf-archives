"""Check the two recovered records and print the flag if they are correct."""
import hashlib, json, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag

SEALED = {"challenge_id": "the-aggregate-remembers", "nonce": "e998058b414d847495581d10", "ciphertext": "a60e4bf8768408472276e6a39ce958137f41d1a1a9c5be234429a493dce84be925496b86e1a558ea021d84a993bff1"}


def unlock(answer):
    enc = json.dumps(answer, ensure_ascii=True, separators=(',', ':')).encode('ascii')
    key = hashlib.sha256(b'isfcr-ml\0' + enc).digest()
    return AESGCM(key).decrypt(bytes.fromhex(SEALED['nonce']), bytes.fromhex(SEALED['ciphertext']),
                               SEALED['challenge_id'].encode('ascii')).decode('ascii')


if __name__ == '__main__':
    try:
        print(unlock(json.loads(sys.argv[1])))
    except (InvalidTag, ValueError):
        print('Rejected.')
