# Cold-store ledger API

Fleet documentation share, `ledger/API.md`.

The ledger stores rows under keys. A key is 1 to 64 bytes of printable ASCII
(0x21-0x7e) after percent-decoding; it is the rest of the path after `/ledger/`.
Request and response bodies are JSON. Errors look like `{"error": "<message>"}`.

## Sessions

Each crew works in a ledger session of its own. Open one with the button on the
ledger's home page, or `POST /session` with `Accept: application/json`, which
answers `{"token": "...", "base": "http://HOST:PORT/s/<token>/"}`. Every path below
is relative to that base: `GET /ledger/{key}` means `GET /s/<token>/ledger/{key}`.
A session is a ledger of its own (its rows, its vault, its limits) and closes after
three hours without traffic; an unknown or closed session answers `404`.

## Reads

| Request | Responses |
|---|---|
| `GET /ledger/{key}` | `200` row, `403` row is sealed, `404` no such row |
| `GET /ledger` | `200` the calling device's own rows (signed requests only) |
| `GET /healthz` | `200` `{"status": "ok"}` |

A row looks like `{"key": "...", "note": "...", "by": "<device>", "at": "<UTC time>"}`.

## Writes

Writes must be signed by a registered field device.

| Request | Responses |
|---|---|
| `PUT /ledger/{key}` body `{"note": "<at most 200 characters>"}` | `201` created, `200` replaced (own row), `409` key is taken |
| `DELETE /ledger/{key}` | `204` deleted (own row), `403` not your row |

A device holds at most 256 rows at a time. Deleting a row frees its slot.

## Thaw

| Request | Responses |
|---|---|
| `POST /thaw` body `{"seal": "<key of the sealed vault row>"}` | `200` `{"flag": "..."}`, `403` seal rejected, `429` thaw locked |

Thaw attempts are limited per ledger session.

## Signing

Signed requests carry `Signature-Input` and `Signature` fields (HTTP Message
Signatures, RFC 9421), Ed25519, made with the device key from its backup. Field
devices use `fieldsign`. Covered components: `@method`, `@path`, `@authority`.
Parameters: `created` (UNIX time, within 300 s of the ledger clock), `keyid` (the
device name) and `alg` (`ed25519`).
