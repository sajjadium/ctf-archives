SURPLUS LOT 2209-14, ITEM 6
FK-200 field kiosk, bay B, SHARD-24 cold store. Decommissioned 2026-08-14.

Recovered from the kiosk's maintenance partition:

  kiosk-7.backup.json   device configuration export
  fieldsign/            the fleet's request signing tool, as installed on the kiosk
  API.md                ledger API notes, from the fleet documentation share

The ledger's address is on the challenge page. Open a ledger session from its
home page; every API.md path goes below the base URL the session gives you.
