#!/usr/bin/env python3
"""fieldsign 1.4.2 - sign and send cold-store ledger requests from a field device.

    python fieldsign.py --device ../kiosk-7.backup.json GET  http://HOST:PORT/s/SESSION/ledger
    python fieldsign.py --device ../kiosk-7.backup.json PUT  http://HOST:PORT/s/SESSION/ledger/KEY --json '{"note": "..."}'
    python fieldsign.py --device ../kiosk-7.backup.json DELETE http://HOST:PORT/s/SESSION/ledger/KEY
    python fieldsign.py ... --dry-run     show the signed request instead of sending it

http://HOST:PORT/s/SESSION/ is the base URL of your ledger session.

Requests are signed with HTTP Message Signatures (RFC 9421) using the device's Ed25519
key. The covered components and parameters come from the device backup.
"""

import argparse
import base64
import http.client
import json
import sys
import time
import urllib.parse

import http_sfv
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

VERSION = "1.4.2"


def b64url_decode(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


class Device:
    def __init__(self, path):
        with open(path, encoding="utf-8") as f:
            doc = json.load(f)
        jwk = doc["signing_key"]
        if jwk.get("kty") != "OKP" or jwk.get("crv") != "Ed25519":
            raise SystemExit("fieldsign: unsupported key type in %s" % path)
        self.name = doc["device"]
        self.key = Ed25519PrivateKey.from_private_bytes(b64url_decode(jwk["d"]))
        sign = doc.get("ledger", {}).get("sign", {})
        self.components = list(sign.get("components", ["@method", "@path", "@authority"]))
        self.label = sign.get("label", "sig1")
        self.alg = sign.get("alg", "ed25519")


def authority(u):
    host = (u.hostname or "").lower()
    if ":" in host:
        host = "[%s]" % host
    port = u.port
    default = {"http": 80, "https": 443}.get(u.scheme)
    if port is not None and port != default:
        return "%s:%d" % (host, port)
    return host


def component_value(name, method, u, headers):
    if name == "@method":
        return method.upper()
    if name == "@path":
        return u.path or "/"
    if name == "@authority":
        return authority(u)
    if name == "@query":
        return "?" + u.query
    if name.startswith("@"):
        raise SystemExit("fieldsign: component %s is not supported" % name)
    for k, v in headers.items():
        if k.lower() == name:
            return v.strip()
    raise SystemExit("fieldsign: component %s is not present in the request" % name)


def sign_request(dev, method, url, headers, created=None):
    u = urllib.parse.urlsplit(url)
    covered = http_sfv.InnerList(dev.components)
    covered.params["created"] = int(time.time()) if created is None else created
    covered.params["keyid"] = dev.name
    covered.params["alg"] = dev.alg
    lines = ['"%s": %s' % (c, component_value(c, method, u, headers)) for c in dev.components]
    lines.append('"@signature-params": %s' % covered)
    base = "\n".join(lines)
    signature = dev.key.sign(base.encode("ascii"))

    sig_input = http_sfv.Dictionary()
    sig_input[dev.label] = covered
    sig = http_sfv.Dictionary()
    sig[dev.label] = signature
    out = dict(headers)
    out["Signature-Input"] = str(sig_input)
    out["Signature"] = str(sig)
    return out, base


def send(method, url, headers, body):
    u = urllib.parse.urlsplit(url)
    if u.scheme == "https":
        conn = http.client.HTTPSConnection(u.hostname, u.port or 443, timeout=20)
    else:
        conn = http.client.HTTPConnection(u.hostname, u.port or 80, timeout=20)
    target = (u.path or "/") + ("?" + u.query if u.query else "")
    conn.putrequest(method.upper(), target, skip_host=True, skip_accept_encoding=True)
    conn.putheader("Host", authority(u))
    for k, v in headers.items():
        conn.putheader(k, v)
    if body is not None:
        conn.putheader("Content-Length", str(len(body)))
    conn.endheaders(body)
    resp = conn.getresponse()
    data = resp.read()
    conn.close()
    return resp, data


def main():
    ap = argparse.ArgumentParser(description="Sign and send a ledger request (fieldsign %s)." % VERSION)
    ap.add_argument("--device", required=True, help="device backup (JSON) holding the signing key")
    ap.add_argument("--json", help="JSON request body")
    ap.add_argument("-H", "--header", action="append", default=[],
                    help="extra request header, 'Name: value' (may repeat)")
    ap.add_argument("--dry-run", action="store_true", help="print the signed request, do not send")
    ap.add_argument("-v", "--verbose", action="store_true", help="also print the signature base")
    ap.add_argument("method")
    ap.add_argument("url")
    args = ap.parse_args()

    dev = Device(args.device)
    headers = {}
    for h in args.header:
        name, _, value = h.partition(":")
        headers[name.strip()] = value.strip()
    body = None
    if args.json is not None:
        body = args.json.encode("utf-8")
        headers.setdefault("Content-Type", "application/json")

    signed, base = sign_request(dev, args.method, args.url, headers)
    if args.verbose or args.dry_run:
        print("--- signature base ---")
        print(base)
        print("----------------------")
    if args.dry_run:
        u = urllib.parse.urlsplit(args.url)
        print("%s %s HTTP/1.1" % (args.method.upper(), (u.path or "/") + ("?" + u.query if u.query else "")))
        print("Host: %s" % authority(u))
        for k, v in signed.items():
            print("%s: %s" % (k, v))
        if body is not None:
            print()
            print(body.decode("utf-8"))
        return 0

    resp, data = send(args.method, args.url, signed, body)
    print("HTTP %d %s" % (resp.status, resp.reason))
    for k, v in resp.getheaders():
        print("%s: %s" % (k, v))
    print()
    sys.stdout.write(data.decode("utf-8", "replace"))
    if data and not data.endswith(b"\n"):
        print()
    return 0 if resp.status < 400 else 1


if __name__ == "__main__":
    sys.exit(main())
