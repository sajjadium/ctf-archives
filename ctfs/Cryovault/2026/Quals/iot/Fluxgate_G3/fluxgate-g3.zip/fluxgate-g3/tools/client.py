#!/usr/bin/env python3
"""
Tiny convenience client for the Fluxgate G3 maintenance service.

Reads newline commands from stdin and prints responses. Lines beginning with
'@file ' upload the file at the given path as a base64-encoded argument to the
preceding UPDATE/SEND command, so you don't have to base64 by hand:

    UPDATE @file artifacts/pol-v3rc.fw

A single '!' at the start of a line is passed through unchanged (useful for
scripted sessions).

Usage:
    python3 client.py HOST [PORT]
"""
import base64, os, socket, sys


def main():
    if len(sys.argv) < 2:
        print(__doc__.strip()); sys.exit(1)
    host = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 4300

    s = socket.create_connection((host, port))
    s_in = s.makefile("rb")
    s_out = s.makefile("wb")

    def recv_until_quiet(timeout=1.0):
        s.settimeout(timeout)
        try:
            while True:
                line = s_in.readline()
                if not line:
                    return
                sys.stdout.write(line.decode(errors="replace"))
                sys.stdout.flush()
        except socket.timeout:
            return

    recv_until_quiet()

    for raw in sys.stdin:
        line = raw.rstrip("\n")
        if not line:
            continue
        # Expand "@file <path>" tokens.
        parts = line.split()
        rebuilt = []
        i = 0
        while i < len(parts):
            if parts[i] == "@file" and i + 1 < len(parts):
                with open(parts[i + 1], "rb") as f:
                    rebuilt.append(base64.b64encode(f.read()).decode())
                i += 2
            else:
                rebuilt.append(parts[i]); i += 1
        out = " ".join(rebuilt) + "\n"
        s_out.write(out.encode()); s_out.flush()
        recv_until_quiet()

    s.close()


if __name__ == "__main__":
    main()
