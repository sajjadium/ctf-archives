# Maintenance Service — Protocol Reference

The service is line-oriented ASCII over TCP. Every response starts with
either `OK ` or `ERR `. Binary payloads are base64-encoded after a `key_b64=`
tag.

Device state is per-connection; closing the connection throws it away.
`RESET` restores factory defaults on the current connection.

## Commands

| Command                | Description                                               |
|------------------------|-----------------------------------------------------------|
| `HELLO`                | Service banner and vendor Ed25519 public key              |
| `STATUS`               | Installed components, versions, counters, boot state      |
| `TOKEN`                | Base64 of the single operator token issued to you         |
| `UPDATE <base64 blob>` | Install one signed firmware artifact                      |
| `BOOT`                 | Attempt to boot with the currently installed components   |
| `SEND <base64 frame>`  | Transmit a maintenance frame (device must be booted)      |
| `RESET`                | Return the device to factory defaults                     |
| `HELP`                 | Reprint the help text                                     |
| `QUIT`                 | Close the connection                                      |

### Updates

A valid update requires:

1. The artifact's vendor signature verifies.
2. The artifact's security counter is **≥** the stored counter for its
   component. Equal counters are permitted (sidegrade between build variants).
3. After the proposed install, **every** installed component's declared
   dependency ranges are satisfied by the versions in the installed set.

Updates are rejected while the device is booted. Reboot first (see `REBOOT`
action below) or `RESET` and start over.

### Boot

Boot re-runs steps 1 and 3 above over the full installed set and additionally
parses each component's payload. Any failure leaves the device un-booted; the
reasons are printed back one per line.

### Frames

The device accepts frames over `SEND`. Frame layout (big-endian throughout):

```
offset  size  field
  0      2    magic "FG"
  2      1    frame_version          (must match installed rad)
  3      1    opcode
  4      1    payload_len            (0..255)
  5      N    payload
  5+N    24   operator token
```

### Operator token

The token is a 24-byte structure:

```
offset  size  field
  0      2    user_id         (big-endian)
  2      2    capabilities    (big-endian bitmask)
  4      4    nonce           (big-endian)
  8     16    HMAC-SHA256(key, bytes[0..8])[:16]
```

The operator token issued by the device identifies **user_id 42** with
capabilities **0x0003**. The capability-bit catalogue is published in the
tab-component documentation (see `docs/artifact.md`).

### Dispatch

When a frame arrives, the loader:

1. Verifies the frame magic and that `frame_version` matches the installed
   `rad` component.
2. Verifies the operator token's HMAC.
3. Looks up `opcode` in the installed `tab`. If the opcode is not present the
   frame is dropped. Otherwise the required capability bitmask is retrieved
   and compared against `token.capabilities`.
4. Looks up `opcode` in the installed `pol` handler table. The handler's
   action ID is executed by the loader. The handler also carries a short
   fixed "reply hint" that most actions splice into the response.

### Example session

```
> HELLO
OK Fluxgate G3 (sim)
OK vendor_pk=1a3f...e2

> STATUS
OK booted=False
OK   pol: v3 counter=3 build=0x0303 deps=[tab:v2-v2, rad:v2-v2]
OK   tab: v2 counter=2 build=0x1002 deps=[none]
OK   rad: v2 counter=2 build=0x2002 deps=[none]

> BOOT
OK boot ok: pol@v3.0303 tab@v2.1002 rad@v2.2002

> TOKEN
OK token_b64=ACoAAwDA3hM3...

> SEND <base64 frame>
OK resp_b64=<base64>
```
