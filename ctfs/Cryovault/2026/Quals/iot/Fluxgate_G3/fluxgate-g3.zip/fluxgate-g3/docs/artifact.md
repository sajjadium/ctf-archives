# Firmware Artifact — Binary Reference

This document is a straight port of the vendor's "FXG1 Delta Format" spec that
ships with the Fluxgate G3 SDK. Nothing here is proprietary.

## Outer layout

All multi-byte integers are big-endian.

```
offset  size  field
  0      4    magic "FXG1"
  4      4    component   ASCII, NUL-padded ("pol\0", "tab\0", "rad\0")
  8      1    version
  9      1    sec_counter
 10      2    build_id
 12      1    dep_count
 13      D    deps        dep_count * 6 bytes
13+D     2    payload_len (big-endian)
15+D     N    payload
...     64    signature (Ed25519 over bytes [0 .. end-64])
```

### Dependency entry

```
offset  size  field
  0      4    component name (ASCII, NUL-padded)
  4      1    min_version
  5      1    max_version
```

A dependency `tab: v2-v3` means the artifact needs some component named `tab`
installed with `2 <= version <= 3`. A `dep_count` of 0 means the artifact has
no dependencies.

### Signature

Ed25519 signature over the entire artifact up to (but excluding) the signature
field itself. The vendor public key is printed by `HELLO`.

## Payload: `pol` (policy / handler table)

```
offset  size  field
  0      1    num_handlers
  1      ...  num_handlers * {
                 opcode     1
                 action_id  1
                 reply_len  1
                 reply      reply_len bytes
             }
```

### Action IDs (loader-defined, stable across all pol versions)

| action_id | mnemonic       | behaviour                                                   |
|-----------|----------------|-------------------------------------------------------------|
| 0x01      | ECHO           | returns `echo:<reply><frame.payload>`                       |
| 0x02      | STATUS         | returns `status:<reply><boot-banner>`                       |
| 0x03      | DIAG           | returns `diag:<reply>`                                      |
| 0x04      | CONFIG_READ    | returns `cfg:<reply>|buf=<current config buffer>`           |
| 0x05      | CONFIG_WRITE   | copies up to 32 bytes of `frame.payload` into config buffer |
| 0x06      | REBOOT         | returns `reboot:ack`, device transitions out of booted      |
| 0x07      | UNLOCK         | factory service-mode unlock; emits the service blob         |

## Payload: `tab` (translation table)

```
offset  size  field
  0      1    num_entries
  1      ...  num_entries * {
                 opcode          1
                 required_mask   2 (big-endian)
             }
```

The capability bits used throughout the Fluxgate G3 line are:

| bit     | mnemonic     | holder                               |
|---------|--------------|--------------------------------------|
| 0x0001  | BASIC_READ   | any operator token                   |
| 0x0002  | STATUS       | any operator token with status rights|
| 0x0004  | DIAG         | diag technicians                     |
| 0x0008  | CONFIG_READ  | config-review technicians            |
| 0x0100  | CONFIG_WRITE | provisioning technicians             |
| 0x0200  | CONTROL      | reboot/control operators             |
| 0x8000  | SERVICE      | factory service hardware             |

## Payload: `rad` (radio / framing)

```
offset  size  field
  0      1    frame_version
  1      1    hmac_key_id    (must be 0 for standard operator tokens)
```

The installed `rad` component dictates the `frame_version` byte accepted on
the wire.
