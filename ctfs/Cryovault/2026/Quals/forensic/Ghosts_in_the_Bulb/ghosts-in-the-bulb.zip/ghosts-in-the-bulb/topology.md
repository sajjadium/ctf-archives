# Home LAN inventory

*(exported from the router, 2026-09 — devices seen during the capture
window. Broker IP is `192.168.1.100`, port 1883, unauthenticated.)*

| IP            | MAC                 | Hostname     | Notes                        |
|---------------|---------------------|--------------|------------------------------|
| 192.168.1.10  | 02:aa:bb:cc:dd:10   | thermo_lr    | Nest-alike thermostat (LR)   |
| 192.168.1.11  | 02:aa:bb:cc:dd:11   | aq_lr        | Awair-alike air quality (LR) |
| 192.168.1.30  | 02:aa:bb:cc:dd:30   | bulb_lr      | Hue-alike bulb, livingroom   |
| 192.168.1.31  | 02:aa:bb:cc:dd:31   | bulb_kt      | Hue-alike bulb, kitchen      |
| 192.168.1.32  | 02:aa:bb:cc:dd:32   | bulb_br      | Hue-alike bulb, bedroom      |
| 192.168.1.33  | 02:aa:bb:cc:dd:33   | bulb_hw      | Hue-alike bulb, hallway      |
| 192.168.1.34  | 02:aa:bb:cc:dd:34   | bulb_st      | Hue-alike bulb, studio (music-sync) |
| 192.168.1.35  | 02:aa:bb:cc:dd:35   | bulb_gr      | Hue-alike bulb, garden porch |
| 192.168.1.40  | 02:aa:bb:cc:dd:40   | robovac      | Roborock-alike vacuum        |
| 192.168.1.50  | 02:aa:bb:cc:dd:50   | presence     | mmWave presence sensor, office |
| 192.168.1.60  | 02:aa:bb:cc:dd:60   | smartplug    | metered plug, utility closet |
| 192.168.1.70  | 02:aa:bb:cc:dd:70   | waterctl     | garden irrigation controller |
| 192.168.1.100 | 02:aa:bb:cc:dd:01   | broker       | Mosquitto 2.x                |

## Topic conventions

All devices publish to `home/<room>/<device>` with QoS 0, no retain.
Payloads are plain JSON (verified via `mosquitto_sub` audit last week).

No historical broker log was retained; the pcap is the ground truth.