# End Mark

The seal worker read 24 fragments from a SQLite ledger while its writer kept changing the ledger. Its log recorded operations, but omitted the returned bytes. The database and its write-ahead log were captured together immediately after the last recorded operation.

Recover the exact bytes returned by the 24 `FETCH` operations. Concatenate their 24-byte `payload` values in ascending `slot` order (`0` through `23`), and submit the first 32 lowercase hexadecimal digits of the SHA-256 of those bytes inside the event's `isfcr` flag wrapper.

The `seq` field is the total order of the recorded operations. `W` is the sole writer; each recorded `W` commit completed successfully. `C1` through `C6` are separate SQLite connections. `FETCH` means `SELECT payload FROM fragments WHERE slot=?` on the named connection. `READ heartbeat`, `SETUP` and `CHECKPOINT` mean the exact SQL printed in the log, run on the named connection (`CHECKPOINT` on `W`). `BEGIN DEFERRED` and `END` have their usual SQLite meanings. No query results or payload bytes are printed in the log. The capture ran on SQLite 3.50.4 through Python's `sqlite3` module. Reader connections ran in autocommit mode (`isolation_level=None`), so each `SETUP` statement took effect immediately, before that reader's `BEGIN DEFERRED`.

The evidence consists of `ledger.db`, `ledger.db-wal`, and `trace.ndjson`. Treat them as one captured set. The ledger was running in WAL mode. No network service, account, or live external query is part of the challenge.

Work on copies of the database files. Opening a WAL-mode database with SQLite can checkpoint or remove its sidecar when the last connection closes; the original ZIP is your unchanged evidence.
