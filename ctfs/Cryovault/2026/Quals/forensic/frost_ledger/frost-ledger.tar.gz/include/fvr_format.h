/*
 * fvr_format.h — Frostline Vault Registry on-disk structures.
 * Part of the Frostline platform SDK. Version 1.4.2.
 *
 * The payload offset convention has changed once across on-disk versions (see
 * RELEASE-NOTES.txt). Do NOT compute payload addresses by hand: call
 * fvr_cell_key()/fvr_cell_value() from libfvr, which branch on the volume's
 * format_version. Those helpers live in libfvr and are intentionally not
 * inlined here so that callers cannot bake in one version's convention.
 */
#ifndef FVR_FORMAT_H
#define FVR_FORMAT_H
#include <stdint.h>

#define FVR_MAGIC          "FVR"
#define FVR_PAGE_SIZE      4096
#define FVR_ROOT_SLOTS     8

enum fvr_kind { FVR_FREE = 0, FVR_INDEX = 1, FVR_DATA = 2, FVR_OVERFLOW = 3 };

#define FVR_CELL_OVERFLOW  0x2u     /* value is out of line (format v1+) */

struct fvr_root_slot {              /* 32 bytes */
    uint64_t epoch;
    uint32_t root_pgid;
    uint32_t wal_head;
    uint64_t reserved;
    uint64_t slot_fnv1a64;          /* over the first 24 bytes of this slot */
};

struct fvr_superblock {             /* page 0 */
    char     magic[4];              /* "FVR" + format version byte */
    uint32_t page_size;
    uint32_t page_count;
    uint32_t format_version;
    struct fvr_root_slot roots[FVR_ROOT_SLOTS];
};

struct fvr_page_hdr {               /* 24 bytes, every page except page 0 */
    uint32_t pgid;
    uint64_t epoch;
    uint8_t  kind;
    uint8_t  reserved;
    uint16_t cell_count;
    uint32_t body_crc32c;           /* CRC-32C over bytes 24..page_size */
    uint32_t reserved2;
};

/* format v1 descriptor. v0 had no flags word and was 12 bytes. */
struct fvr_cell {                   /* 16 bytes */
    uint32_t koff;                  /* see fvr_cell_key()  — NOT a raw index */
    uint16_t ksize;
    uint16_t vsize;
    uint32_t voff;                  /* see fvr_cell_value() — NOT a raw index */
    uint32_t flags;
};

struct fvr_overflow_hdr {           /* at body offset 0 of a kind=3 page */
    uint32_t next_pgid;             /* 0 terminates */
    uint32_t bytes_used;
};

/* Inline representation of an out-of-line value (FVR_CELL_OVERFLOW set). */
struct fvr_overflow_ref {           /* 12 bytes */
    uint64_t head_pgid;
    uint32_t total_len;             /* STORED length, not decoded length */
};

/* Authority record payloads are not stored verbatim from record-version 4
 * onward (fvregd 1.4.0). record-version is inside the payload. */

/* Implemented in libfvr. Both branch on sb->format_version. */
const void *fvr_cell_key  (const struct fvr_superblock *sb,
                           const void *page, const struct fvr_cell *c);
const void *fvr_cell_value(const struct fvr_superblock *sb,
                           const void *page, const struct fvr_cell *c);

/* Selects the live generation, or NULL if no slot is usable. */
const struct fvr_root_slot *fvr_live_root(const struct fvr_superblock *sb);

#endif /* FVR_FORMAT_H */
