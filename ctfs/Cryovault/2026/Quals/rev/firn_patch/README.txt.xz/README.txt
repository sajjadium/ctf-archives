FIRN cold store - controller maintenance kit
============================================

  patchd     controller firmware: Hexagon (QDSP6), Linux user mode, stripped
  bench.img  image dumped from a retired bench controller

Bench (QEMU user mode; tested with qemu-hexagon 8.2):

    chmod +x patchd
    cat bench.img - | qemu-hexagon-static ./patchd

On the bench the firmware reads its image from standard input, then link traffic.
A live controller already holds its own image, so its link carries only the traffic.

Live: start your instance and use the address it gives you. The maintenance link is a
WebSocket (ws:// or wss://): binary messages carry the link traffic in order, and
message boundaries do not matter. For example, with websocat (-b = binary mode):

    websocat -b ws://HOST:PORT/

To use nc, pwntools or your own TCP client, bridge the link to a local port first:

    websocat -b tcp-l:127.0.0.1:4000 ws://HOST:PORT/
    nc 127.0.0.1 4000

If your instance gives you an nc command instead, that plain TCP link carries the same
traffic.

sha256(patchd) = d8d547424864fca674ad0f3a0f7ab935a42ee1eef0fc8df33649e1424f79f7be
