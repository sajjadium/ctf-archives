while true
do
    rm -rf -- /dev/shm/*
    sleep 1800
done