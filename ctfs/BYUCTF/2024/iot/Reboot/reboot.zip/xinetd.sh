#!/bin/bash

cd /ctf && python3 server.py