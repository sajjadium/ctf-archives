chmod 773 /dev/shm

bash /ctf/clean.sh &

/usr/sbin/xinetd -dontfork