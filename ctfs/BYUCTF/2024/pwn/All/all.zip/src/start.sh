#! /bin/sh

cd /ctf
./all