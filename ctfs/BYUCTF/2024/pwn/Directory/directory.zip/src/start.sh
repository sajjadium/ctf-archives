#! /bin/sh

cd /ctf
./directory