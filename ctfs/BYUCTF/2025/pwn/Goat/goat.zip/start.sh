#!/bin/bash

cd /ctf && python3 rate_limit.py && ./goat