#!/bin/sh

/qemu /app/mips