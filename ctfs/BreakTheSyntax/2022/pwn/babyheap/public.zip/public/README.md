## Docker

```
docker build -t babyheap . && docker run -p 2442:2442 babyheap:latest
```




