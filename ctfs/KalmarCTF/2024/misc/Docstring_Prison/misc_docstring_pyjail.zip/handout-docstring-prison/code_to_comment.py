# Let's just make sure we don't run anything:
quit()

from flag import flag
print(flag)