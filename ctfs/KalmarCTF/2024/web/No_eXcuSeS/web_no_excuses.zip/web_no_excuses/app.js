const express = require('express');
const bodyParser = require('body-parser');
const { visit } = require('./bot'); 

const app = express();
const port = 7357;

app.use(bodyParser.urlencoded({ extended: true }));
app.use('/static', express.static('static'));

app.get('/', (req, res) => {
  res.redirect('/static/index.html');
});

app.post('/report', (req, res) => {
  const url = req.body.url;
  visit(url);

  res.send('Bot is visiting your url');
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Server is running on http://0.0.0.0:${port}`);
});
