const puppeteer = require('puppeteer');

const FLAG = 'kalmar{this_is_a_test_flag!!}';
const HOST = "http://localhost:7357";

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function visit(url) {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: "new",
            args: [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-setuid-sandbox",
                "--js-flags=--noexpose_wasm,--jitless",
            ],
        });

        let page = await browser.newPage();
        await page.goto(HOST, { timeout: 1000, waitUntil: 'domcontentloaded' });

        await page.evaluate((flag) => {
            document.cookie = "flag=" + flag + "; path=/";
        }, FLAG);

        await page.close();
        page = await browser.newPage();

        await page.goto(url, { timeout: 3000, waitUntil: 'domcontentloaded' })
        await sleep(2000);

        await browser.close();
        browser = null;
    } catch (err) {
        console.log(err);
    } finally {
        if (browser) await browser.close();
    }
}


module.exports = { visit };
