from enum import Enum, auto
from struct import pack, unpack
from flask.sessions import SecureCookieSessionInterface
from flask import Flask, request, session
from itsdangerous import HMACAlgorithm, Serializer
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import load_ssh_private_key

app = Flask(__name__)
app.config['MAX_FORM_MEMORY_SIZE'] = app.config['MAX_CONTENT_LENGTH'] = 1024 * 1024  # Plz dont DoS

KEY = load_ssh_private_key(open("onekeytorulethemall", "rb").read(), password=None)
app.secret_key = KEY.private_bytes_raw()
del KEY

class ACCESS_LEVEL(Enum):
    GUEST = auto()
    ADMIN = auto()
    SUPER_ADMIN = auto()

class Serialiser(Serializer):
    @staticmethod
    def loads(obj: bytes) -> dict:
        result = {}
        try:
            while len(obj) > 0:
                k, obj = Serialiser._decode(obj)
                v, obj = Serialiser._decode(obj)
                result[k] = v
        except: ...
        return result

    @staticmethod
    def dumps(obj: dict) -> bytes:
        """ Encode everything as [len(key1)||key1||len(val1)||val1||...||len(keyN)||keyN||valN]. """
        items = list(obj.items())

        # Lets not `_encode()` last item value (`content`), so you can store more than 0xFFFFFFFF bytes if your browser supports it
        has_opt = False
        if len(items) > 1:
            last_k, last_v = items.pop(-1)
            has_opt = True
        result = b''.join(map(lambda kv: Serialiser._encode(kv[0]) + Serialiser._encode(kv[1]), items))
        if has_opt:
            result += Serialiser._encode(last_k)
            result += last_v  # We save 4 bytes by not having len(last_v)!
        return result

    @staticmethod
    def _encode(msg):
        if isinstance(msg, Enum):
            return bytes([ord(str(msg.value))])
        if isinstance(msg, int):
            msg = str(msg)
        if isinstance(msg, str):
            msg = msg.encode()
        assert len(msg) < 0xFF_FF_FF_FF
        return pack(">I", len(msg)) + msg

    @staticmethod
    def _decode(msg):
        (msg_len,) = unpack(">I", msg[:4])
        if len(msg[4:]) >= msg_len:
            return msg[4:msg_len+4], msg[msg_len+4:]
        try:
            # Prefix is not [len(data), data]. Try decode as enum:
            return ACCESS_LEVEL(int(chr(msg[0]))), msg[1:]
        except:
            # This must be the last block (w/o) length in front. Return all of it:
            return msg, b''

class SignerAlgorithm(HMACAlgorithm):
    @staticmethod
    def get_signature(key: bytes, value: bytes) -> bytes:
        return Ed25519PrivateKey.from_private_bytes(key).sign(value)

    @staticmethod
    def verify_signature(key: bytes, value: bytes, sig: bytes) -> bool:
        try:
            Ed25519PrivateKey.from_private_bytes(key).public_key().verify(sig, value)
            return True
        except InvalidSignature:
            return False

class VerySecureCookieSessionInterface(SecureCookieSessionInterface):
    def get_signing_serializer(self, app: "Flask"):
        return Serializer(
            app.secret_key,
            serializer=Serialiser,
            signer_kwargs=dict(key_derivation='none', algorithm=SignerAlgorithm),
        )
app.session_interface = VerySecureCookieSessionInterface()

def get_access(username=None, password=None, **kwargs):
    if username == 'admin' and password == f'{ ... }':
        return ACCESS_LEVEL.ADMIN
    return ACCESS_LEVEL.GUEST

@app.after_request
def add_header(response):
    # This is not about XSS
    response.headers['Content-Security-Policy'] = "default-src 'none'; style-src 'unsafe-inline'"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "DENY"
    response.headers['Referrer-Policy'] = "no-referrer"
    response.headers['X-XSS-Protection'] = "0"
    response.headers['Server'] = "Apache/1.3.3.7"  # lol
    return response

HTML_HEADER = b"""<!DOCTYPE html><html lang="en">
<body style="max-width: 800px;  margin: auto;">
  <h1 style="text-align: center; background: linear-gradient(to right, #ef5350, #f48fb1, #7e57c2, #2196f3, #26c6da, #43a047, #eeff41, #f9a825, #ff5722);">GDPR Friendly Note Taking App (or simply: GDPRFNTA)</h1>
"""

@app.route("/")
def frontpage():
    username = b"guest"
    title = content = b""

    lst = list(session.items())
    print(lst)
    if len(lst) == 2:
        # Python3 dicts are ordered, so this is fine(TM)
        title, content = lst.pop()
        username, access_level = lst.pop()

    return HTML_HEADER + b'''<form action="/note" method="post">
    <!-- Username: --><input name="username" value="''' + username + b'''" hidden />
    <!-- Password: --><input name="password" value="" hidden />
    Title: <input name="note_title" value="''' + title + b'''" /><br/>
    Content:<br/><textarea name="note_content" rows="4" cols="50">''' + content + b'''</textarea><br/>
    <input type="submit" value="Save note">
    <a href="/privacy" style="float: right;">Privacy Policy</a>
  </form>
'''

@app.route("/privacy")
def privacy():
    return HTML_HEADER + b"""<p>At GDPRFNTA we take the privacy of your notes very serious.</p>
    <p>Notes are stored <b>locally</b> so this is very GDPR friendly!</p>
    <p>To ensure the safety and integrity of your notes, we will quickly process them server-side.</p>
    <p>Hackers are not allowed server-side, so everything is fine.</p>
    <p>In the future it will be possible to password protect notes, but this has been disabled for now.</p>"""

@app.route("/note", methods=['POST'])
def save_note():
    flash = lambda html: f"<!DOCTYPE html><html><head><meta http-equiv=\"refresh\" content=\"2;URL='{request.base_url}/../'\"><body>{html}"
    data = {kv[0].decode(): kv[1] for kv in map(lambda kv: kv.split(b"="), request.get_data().split(b"&"))}

    try:
        username = data['username']
        password = data['password']
        note_title = data['note_title']
        note_content = data['note_content']
    except:
        return flash("<p>Missing required params</p>")

    if username == b'admin':
        return HTML_HEADER + b"Login functionality not yet implemented", 403

    # Clean old stored notes:
    for k in list(session.keys()):
        del session[k]

    # Save new user note:
    session[username] = get_access(**request.form)
    session[note_title] = note_content

    return flash("<p>Note saved<sup>-ish</sup></p>")


if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000, threaded=True)
