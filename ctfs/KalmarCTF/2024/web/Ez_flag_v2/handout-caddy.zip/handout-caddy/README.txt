
To run this challenge locally:

 * docker compose up
 * curl --insecure --resolve caddy.chal-kalmarc.tf:443:127.0.0.1 https://caddy.chal-kalmarc.tf/
 * (or change your `hosts` file)

Difference between handout and real challenge:
 * `tls internal` in handout is just `tls` on prod (doesn't matter for intended solution)
 * filename for flag is different between handout and prod - good luck!

