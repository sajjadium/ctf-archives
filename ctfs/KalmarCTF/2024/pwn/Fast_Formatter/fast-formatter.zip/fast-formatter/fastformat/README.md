Build with `pip3 install .`
