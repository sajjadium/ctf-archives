from setuptools import setup, Extension

setup(
    name='fastformat',
    version='1.0.0',
    install_requires=[],
    packages=[],
    ext_modules=[
        Extension('fastformat', ['src/fastformat.c']),
    ]
)
