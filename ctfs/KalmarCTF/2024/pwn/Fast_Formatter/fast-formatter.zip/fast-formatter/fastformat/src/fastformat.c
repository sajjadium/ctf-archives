#define PY_SSIZE_T_CLEAN
#include <Python.h>


static int count_symbols(const char *c) {
    char num[5];
    int count = 0, out = 0;
    while ((c = strchr(c, '{'))) {
        c++;
        int i;
        for (i = 0; i < 4; i++) {
            if (*c < '0' || '9'< *c) break;
            num[i] = *c++;
        }
        if (*c != '}') {
            continue;
        }
        if (i == 0) {
            count++;
        } else {
            num[i] = 0;
            int val = atoi(num) + 1;
            out = val > out ? val : out;
        }
    }
    if (count && out) return -1;
    return count > out ? count : out;
}


struct Buffer {
    char *data;
    size_t size;
    size_t capacity;
};

static inline int reserve (struct Buffer *buffer, size_t size) {
    size_t newsize = buffer->size + size;
    
    if (newsize <= buffer->capacity)
        return 0;
    
    while (buffer->capacity < newsize) {
        buffer->capacity <<= 1;
    }
    char *newdata = PyMem_Realloc(buffer->data, buffer->capacity);
    if (newdata == NULL)
        return -1;
    buffer->data = newdata;
}

static inline int add_string (struct Buffer *buffer, const char *str) {
    size_t len = strlen(str);
    if (reserve(buffer, len+1))
        return -1;
    strcpy(&buffer->data[buffer->size], str);
    buffer->size += len;
    return 0;
}

static PyObject *do_format(const char *fmtstr, PyObject *args) {
    struct Buffer buffer = {
        .size = 0,
        .capacity = 16,
        .data = PyMem_Malloc(16),
    };
    PyObject* out = NULL;
    char num[5];
    int count = 1;    
    char *ptr = fmtstr, *c = fmtstr;
    while ((c = strchr(c, '{'))) {
        if (reserve(&buffer, (size_t)(c-ptr))) goto end;
        memcpy(&buffer.data[buffer.size], ptr, c-ptr);
        buffer.size += c-ptr;
        ptr = c;
        c++;
        int i;
        for (i = 0; i < 4; i++) {
            if (*c < '0' || '9'< *c) break;
            num[i] = *c++;
        }
        if (*c != '}') {
            continue;
        }
        ptr = ++c;
        int idx;
        if (i == 0) {
            idx = count++;
        } else {
            num[i] = 0;
            idx = atoi(num) + 1;
        }
        
        PyObject *curr = PyObject_Str(PyTuple_GET_ITEM(args, idx));
        if (curr == NULL) goto end;
        
        char *repr = PyUnicode_AsUTF8(curr);
        Py_DECREF(curr);
        
        if (add_string(&buffer, repr)) goto end;
    }
    if (add_string(&buffer, ptr)) goto end;
    out = PyUnicode_FromString(buffer.data);
end:
    PyMem_Free(buffer.data);
    return out;
}

static PyObject*
fastformat_format(PyObject *self, PyObject *args) {
    const char* fmtstr;

    if (PyTuple_Size(args) < 1) {
    	PyErr_SetString(PyExc_TypeError, "Missing format string");
        return NULL;
    }

    if (!(fmtstr = PyUnicode_AsUTF8(PyTuple_GET_ITEM(args, 0)))) return NULL;
    int cnt = count_symbols(fmtstr);
    
    if (cnt == -1) {
        PyErr_SetString(PyExc_ValueError, "Invalid format string");
        return NULL;
    }
    if (cnt > PyTuple_Size(args) - 1) {
        PyErr_SetString(PyExc_IndexError, "Not enough arguments");
        return NULL;
    }
    
    return do_format(fmtstr, args);
}


static PyMethodDef FastFormatMethods[] = {
    {"format", fastformat_format, METH_VARARGS, "Return formatted string"},
    {0}
};

static struct PyModuleDef fastformat_module = {
    PyModuleDef_HEAD_INIT,
    "fastformat",
    NULL,
    -1,
    FastFormatMethods
};


PyMODINIT_FUNC PyInit_fastformat (void) {
    return PyModule_Create(&fastformat_module);
}
