use actix_web::web;

mod index;
mod login;

pub fn init_routes(cfg: &mut web::ServiceConfig) {
    cfg.service(index::get_index);
    cfg.service(login::get_login);
    cfg.service(login::post_login);
}