use actix_web::{http, get, HttpResponse};
use actix_session::{
    Session,
};
use sailfish::TemplateSimple;

#[derive(TemplateSimple)]
#[template(path = "index.stpl")]
struct IndexPage {
    username: String,
    flag: String,
}

#[get("/")]
pub async fn get_index(session: Session) -> HttpResponse {
    let Some(username) = session.get::<String>("user").unwrap() else {
        return HttpResponse::Found().insert_header((http::header::LOCATION, "/login")).finish();
    };

    match std::fs::read_to_string("flag.txt") {
        Ok(flag) => HttpResponse::Ok().body(IndexPage { username, flag }.render_once().unwrap()),
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
}
