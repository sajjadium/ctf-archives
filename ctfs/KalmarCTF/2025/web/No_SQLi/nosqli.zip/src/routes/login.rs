use actix_web::{web, http, get, post, HttpResponse};
use actix_session::Session;
use actix_web_flash_messages::{
    FlashMessage, IncomingFlashMessages,
};
use serde::Deserialize;
use sailfish::TemplateSimple;
use mongodb::{bson::doc, bson::Document, Client, Collection};


#[derive(Clone, PartialEq, Deserialize)]
struct LoginForm {
    pub username: String,
    pub password: String,
}


#[derive(TemplateSimple)]
#[template(path = "login.stpl")]
struct LoginPage {
    messages: IncomingFlashMessages,
}


#[get("/login")]
pub async fn get_login(messages: IncomingFlashMessages) -> HttpResponse {
    let body = LoginPage { messages }.render_once().unwrap();
    HttpResponse::Ok().body(body)
}


#[post("/login")]
pub async fn post_login(client: web::Data<Client>, session: Session, form: web::Form<LoginForm>) -> HttpResponse {
    let form = form.into_inner();
    let collection: Collection<Document> = client.database(crate::db::DB_NAME).collection("users");

    match collection.find_one(doc! { "u": &form.username, "p": form.password }, None).await {
        Ok(Some(_user)) => {
            session.insert::<String>("user", form.username).unwrap();
            HttpResponse::Found()
                .insert_header((http::header::LOCATION, "/"))
                .finish()
        },
        Ok(None) => {
            FlashMessage::error("Invalid username or password").send();

            HttpResponse::Found()
                .insert_header((http::header::LOCATION, "/login"))
                .finish()
        }
        Err(err) => HttpResponse::InternalServerError().body(err.to_string()),
    }
}
