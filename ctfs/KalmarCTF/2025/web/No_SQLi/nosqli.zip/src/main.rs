mod db;
mod routes;
use actix_session::{
    config::PersistentSession, storage::CookieSessionStore, SessionMiddleware,
};
use actix_web::{
	cookie::{time::Duration, Key},
	web, App, HttpServer,
};
use actix_web_flash_messages::{FlashMessagesFramework, storage::CookieMessageStore};
use mongodb::Client;


#[actix_rt::main]
async fn main() -> std::io::Result<()> {
	let mongo_uri = std::env::var("MONGODB_URI").unwrap_or_else(|_| "mongodb://localhost:27017".into());
	
	let client = Client::with_uri_str(mongo_uri).await.expect("failed to connect");
	db::create_indexes(&client).await;

	let secret_key = Key::generate();
    let message_store = CookieMessageStore::builder(secret_key.clone()).build();
    let message_framework = FlashMessagesFramework::builder(message_store).build();
    
    let addr = "0.0.0.0:8080";
    let server = HttpServer::new(move || {
		App::new()
			.app_data(web::Data::new(client.clone()))
            .app_data(web::FormConfig::default().limit(1<<32))
			.wrap(message_framework.clone())
            .wrap(
                SessionMiddleware::builder(CookieSessionStore::default(), secret_key.clone())
                    .cookie_secure(false)
                    .session_lifecycle(
                        PersistentSession::default().session_ttl(Duration::hours(2)),
                    )
                    .build(),
            )
			.configure(routes::init_routes)
	})
	.bind(addr)
	.unwrap()
	.run();
    println!("Server running at http://{}", addr);
    server.await
}
