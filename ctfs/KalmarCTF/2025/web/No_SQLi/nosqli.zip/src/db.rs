use mongodb::{
    bson::{doc, Document},
    options::IndexOptions, 
    Client,
    IndexModel,
};

pub const DB_NAME: &str = "mydb";


pub async fn create_indexes (client: &Client) {
    // users
    let options = IndexOptions::builder().unique(true).build();
    let index = IndexModel::builder()
        .keys(doc! { "u": 1 })
        .options(options)
        .build();
    client
        .database(DB_NAME)
        .collection::<Document>("users")
        .create_index(index, None)
        .await.unwrap();
}