To run locally:

- run `./gen_certs.sh` to generate local self-signed certs
- add to hosts file:
```
127.0.0.1 xss-spukhafte.kalmarctf.local
127.0.0.1 bot-spukhafte.kalmarctf.local
127.0.0.1 notes-spukhafte.kalmarctf.local
```

Good luck :)