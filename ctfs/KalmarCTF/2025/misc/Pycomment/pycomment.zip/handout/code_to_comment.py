#!/usr/bin/env python3 
# We would like to extend our sincere apologies due to the fiasco
# displayed below. As we all know, when we write python, we should
# closely follow the zen of python. Just to refresh your mind, I'll
# share the most important lines with you again:
"""
Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated.
Flat is better than nested.
"""

# Extra safety, make sure no code is run:
quit()

def wish_printer():
    # 
    wish = 'Kalmar says' + ' cheers!!'
    print(wish)
