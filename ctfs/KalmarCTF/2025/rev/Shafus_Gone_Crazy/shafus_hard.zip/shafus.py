import hashlib
import sys

# This is the python version of shafus
FLAG=b'kalmar{...}'
print(hashlib.sha256(FLAG[:16] + sys.argv[1].encode() + FLAG[16:]).hexdigest())

