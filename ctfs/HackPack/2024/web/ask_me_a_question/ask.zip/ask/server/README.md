## Server

This is a crude mockup of how our internal server behaves, there is no exploitable code in this directory. This is mainly there to aid testing.