from fastapi import FastAPI, Request
from langchain_openai import ChatOpenAI
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage
from langchain.cache import SQLAlchemyCache
from langchain.globals import set_llm_cache
#import mockdatabase_model as database_model # Where database schema is stored
#import mockdatabase as database # Where psql connection is created
import json
import os

HUGGINGFACE_API_URL = os.environ.get('HUGGINGFACE_API_URL')
HUGGINGFACE_API_TOKEN = os.environ.get('HUGGINGFACE_API_TOKEN')
# This exists on our servers to improve performance, but is not important to our challenge
#set_llm_cache(SQLAlchemyCache(database.sql_engine, database_model.FulltextLLMCache))

mistral_config = {
    "base_url": HUGGINGFACE_API_URL, 
	"api_key": HUGGINGFACE_API_TOKEN,
    "temperature": 0.01,
    "max_tokens": 100,
    "streaming": False
}

mistral = ChatOpenAI(**mistral_config)

app = FastAPI(
    title="Backend",
    version="1.1",
    description="Backend",
)

@app.post('/ask-me-a-question/invoke')
async def askmeaquestion(request: Request):
    body = await request.body()
    try:
        messages = json.loads(body)['messages']
        prompt = []
        for message in messages:
            if message['role'] == 'system':
                prompt.append(SystemMessage(content=message['content']))
            elif message['role'] == 'assistant':
                prompt.append(AIMessage(content=message['content']))
            elif message['role'] == 'user':
                prompt.append(HumanMessage(content=message['content']))
        msg = await mistral.ainvoke(prompt)
    except Exception as e:
        print(e)
        return {"output": {"content": "Malformed input, blocking prompt injection"}}
    return {"output": {"content": f"{msg.content}"}}
