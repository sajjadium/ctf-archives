from flask import Flask, render_template, request
from flask import abort
import os
import html
import re
from urllib.parse import unquote

app = Flask(__name__)
SECRET_TOKEN = os.getenv('SECRET_TOKEN')

def sanitize_css_value(value):
    value = html.unescape(value)
    value = re.sub(r'</?style>', '', value, flags=re.IGNORECASE)
    value = re.sub(r'[<>]', '', value)
    return value

@app.route('/')
def index():
    return 'Hello, Local World!'

@app.route('/flag')
def flag():
    access_token = request.cookies.get('access_token')
    if access_token != SECRET_TOKEN:
        abort(403)
    
    color = unquote(request.args.get('color', 'white'))
    color = sanitize_css_value(color) 
    flag = os.getenv('FLAG', 'FLAG{dummy_flag}')
    return render_template('flag.html', color=color, flag=flag)

if __name__ == '__main__':
    app.run()

