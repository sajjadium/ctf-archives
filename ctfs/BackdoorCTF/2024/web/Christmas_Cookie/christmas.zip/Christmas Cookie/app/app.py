from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, abort, render_template_string
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from functools import wraps
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
import uuid

app = Flask(__name__)
app.secret_key = os.urandom(24)  # Use a strong, randomly generated secret key

# Configuration for file uploads
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'pnm'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB max upload size
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# Ensure the upload folder exists with secure permissions
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.chmod(UPLOAD_FOLDER, 0o700)  # Owner read/write/execute

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User class
class User(UserMixin):
    def __init__(self, id, password_hash):
        self.id = id
        self.password_hash = password_hash

# Load users from JSON
def load_users():
    if not os.path.exists('users.json'):
        with open('users.json', 'w') as f:
            json.dump({}, f)
    with open('users.json', 'r') as f:
        return json.load(f)

# Save users to JSON
def save_users(users):
    with open('users.json', 'w') as f:
        json.dump(users, f)

@login_manager.user_loader
def load_user(user_id):
    users = load_users()
    if user_id in users:
        return User(user_id, users[user_id])
    return None

# Check if the file is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Generate a secure, unique filename
def generate_secure_filename(filename):
    ext = filename.rsplit('.', 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    return unique_name

def generate_admin_user():
    if not 'admin' in load_users():
        users = load_users()
        users['admin'] = generate_password_hash('admin')
        save_users(users)


def admin_required(f):
    print("admin_required")
    @wraps(f)
    @login_required
    def decorated_function(*args, **kwargs):
        if not current_user.id == "admin":
            flash('Admin access required.')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

# Routes

@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('upload_image'))
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('upload_image'))
    if request.method == 'POST':
        users = load_users()
        username = request.form['username']
        password = request.form['password']

        if not username or not password:
            flash('Username and password are required.')
            return redirect(url_for('register'))

        if username in users:
            flash('Username already exists.')
            return redirect(url_for('register'))

        password_hash = generate_password_hash(password)
        users[username] = password_hash
        save_users(users)

        flash('Registration successful. Please log in.')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('upload_image'))
    if request.method == 'POST':
        users = load_users()
        username = request.form['username']
        password = request.form['password']

        if not username or not password:
            flash('Username and password are required.')
            return render_template_string('wrong username and password')

        if username in users and check_password_hash(users[username], password):
            user = User(username, users[username])
            login_user(user)
            flash('Logged in successfully.')
            # return render_template_string('logged in successfully')
            return redirect(url_for('upload_image'))
        else:
            flash('Invalid username or password.')
            return render_template_string('wrong password')

    return render_template('login.html')

@login_required
@app.route('/logout')
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('login'))

@login_required
@app.route('/upload', methods=['GET', 'POST'])
def upload_image():
    if request.method == 'POST':
        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part.')
            print('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file
        if file.filename == '':
            flash('No selected file.')
            print('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            original_filename = secure_filename(file.filename)
            unique_filename = generate_secure_filename(original_filename)
            # user_folder = os.path.join(app.config['UPLOAD_FOLDER'], current_user.id)
            # os.makedirs(user_folder, exist_ok=True)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(filepath)
            os.chmod(filepath, 0o600)  # Owner read/write
            flash('File uploaded successfully.')
            return redirect(url_for('view_image', filename=unique_filename))
        else:
            flash('File type not allowed.')
            print("File type not allowed")
            return redirect(request.url)

    return render_template('upload.html')

@login_required
@app.route('/view/<filename>')
def view_image(filename):
    # Ensure filename is safe
    if not allowed_file(filename):
        flash('Invalid file type.')
        return redirect(url_for('upload_image'))

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    # file_path = os.path.join(user_folder, filename)

    if not os.path.exists(file_path):
        flash('File does not exist.')
        return redirect(url_for('upload_image'))

    return render_template('view.html', filename=filename)

@login_required
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    # Ensure filename is safe
    secure_filename(filename)
    if not allowed_file(filename):
        abort(404)

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    if not os.path.exists(file_path):
        abort(404)

    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@admin_required
@app.route('/admin/view/<filename>')
def admin_view_image(filename):
    # Sanitize inputs
    safe_filename = secure_filename(filename)
    print("Reached here")
    # Validate file extension
    if not allowed_file(safe_filename):
        flash('Invalid file type.')
        return redirect(url_for('index'))

    file_path = os.path.join(app.config['UPLOAD_FOLDER'], safe_filename)

    if not os.path.exists(file_path):
        flash('File does not exist.')
        return redirect(url_for('index'))

    return render_template('view.html', filename=safe_filename, admin_view=True)

# Serve WebAssembly and JavaScript files with correct MIME types
@app.route('/static/<path:filename>')
def static_files(filename):
    if filename.endswith('.wasm'):
        return send_from_directory('static', filename, mimetype='application/wasm')
    return send_from_directory('static', filename)

# Error handler for file size limit
@app.errorhandler(413)
def request_entity_too_large(error):
    flash('File is too large. Maximum upload size is 16 MB.')
    return redirect(request.url), 413

# Handle 404 errors
@app.errorhandler(404)
def page_not_found(error):
    flash('Page not found.')
    return redirect(url_for('upload_image')), 404

generate_admin_user()
# app.run(port=8000, debug=False)