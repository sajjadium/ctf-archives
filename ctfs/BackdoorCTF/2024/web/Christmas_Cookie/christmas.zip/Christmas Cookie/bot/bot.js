const puppeteer = require('puppeteer');

const sleep = ms => new Promise(res => setTimeout(res, ms));

const CONFIG = {
    APPNAME: process.env['APPNAME'] || "Admin",
    APPURLREGEX: process.env['APPURLREGEX'] || "^.*$",
    APPFLAG: process.env['APPFLAG'] || "flag{REDACTED}",
    APPLIMITTIME: Number(process.env['APPLIMITTIME'] || "60"),
    APPLIMIT: Number(process.env['APPLIMIT'] || "5"),
}

const initBrowser = puppeteer.launch({
    executablePath: "/usr/bin/chromium-browser",
    args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-gpu',
        '--no-gpu',
        '--disable-default-apps',
        '--disable-translate',
        '--disable-device-discovery-notifications',
        '--disable-software-rasterizer',
        '--disable-xss-auditor'
    ],
    ipDataDir: '/home/bot/data/',
    ignoreHTTPSErrors: true
});

console.log("Bot started...");

module.exports = {
    name: CONFIG.APPNAME,
    urlRegex: CONFIG.APPURLREGEX,
    rateLimit: {
        windowS: CONFIG.APPLIMITTIME,
        max: CONFIG.APPLIMIT
    },
    bot: async (urlToVisit) => {
        const browser = await initBrowser;
        const context = await browser.createIncognitoBrowserContext()
        try {
            const page = await context.newPage();
            // Clear all cookies
            const cookies = await page.cookies()
            for (const cookie of cookies) {
                await page.deleteCookie(cookie)
            }
            await page.setCookie({
                name: 'flag',
                value: CONFIG.APPFLAG,
                domain: '192.168.1.2', 
                path: '/',
            });

            console.log("login...")
            await page.goto("http://192.168.1.2:8000/login", {
                timeout: 3000,
                waitUntil: 'domcontentloaded'
            }); 
            await page.waitForSelector('input[name="username"]')
            await page.type('input[name="username"]', 'admin')
            await page.waitForSelector('input[name="password"]')
            await page.type('input[name="password"]', 'admin')
            await page.waitForSelector('input[type="submit"]')
            await page.click('input[type="submit"]')

            await page.waitForTimeout(1000);
            console.log("visit...")
            console.log(`bot visiting ${urlToVisit}`)
            await page.goto(urlToVisit, {
                timeout: 10000,
                waitUntil: 'domcontentloaded'
            });
            await page.waitForTimeout(2000);
            await page.evaluate(() => {
                document.querySelector('button[name="render"]').click();
            });
            await page.waitForTimeout(5000);
            console.log("browser close...")
            await context.close()
            return true;
        } catch (e) {
            console.error(e);
            await context.close();
            return false;
        }
    }
}
