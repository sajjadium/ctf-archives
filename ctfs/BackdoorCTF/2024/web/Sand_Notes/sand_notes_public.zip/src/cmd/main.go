package main

import (
	"html/template"
	"log"
	"net/http"

	"github.com/dr4g0n369/sand_notes/internal/auth"
	"github.com/dr4g0n369/sand_notes/internal/home"

	"github.com/dr4g0n369/sand_notes/internal/models"
	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
)

func main() {
	// Initialize database
	models.ConnectDatabase()

	r := chi.NewRouter()
	r.Use(middleware.Logger)
	r.Use(middleware.StripSlashes)
	r.Use(middleware.NoCache)

	r.Get("/", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/auth/login", http.StatusFound)
	})

	// Auth routes
	r.Route("/auth", func(r chi.Router) {
		r.Get("/login", auth.LoginPageHandler)
		r.Get("/register", auth.RegisterPageHandler)
		r.Post("/register", auth.RegisterHandler)
		r.Post("/login", auth.LoginHandler)
		r.Get("/logout", auth.LogoutHandler)
	})

	// Home routes
	r.Route("/home", func(r chi.Router) {
		r.Use(auth.JWTAuthMiddleware)
		r.Get("/", home.HomePageHandler)
		r.Post("/create", home.CreateNoteHandler)
		r.Post("/edit", home.EditNoteHandler)
		r.Get("/view", home.ViewNoteHandler)
		r.Post("/delete", home.DeleteNoteHandler)
	})

	r.Get("/loader.html", func(w http.ResponseWriter, r *http.Request) {

		cookie, err := r.Cookie("admin")
		var adminValue bool
		if err != nil {
			log.Println("Token:", err)
			adminValue = false
		} else {
			token := cookie.Value
			if token == "SUPER_SECRET_ADMIN_TOKEN" {
				log.Println("Token:", token)
				adminValue = true
			}
		}

		templates := template.Must(template.ParseGlob("templates/*.html"))
		templates.ExecuteTemplate(w, "loader.html", struct {
			Admin bool
			Flag  string
		}{Admin: adminValue, Flag: "flag{OBVIOUSLY_FAKE_FLAG}"})
	})

	// Start server
	log.Println("Starting server on :9090")
	log.Fatal(http.ListenAndServe(":9090", r))
}
