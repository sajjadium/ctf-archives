package auth

import (
	"log"
	"net/http"
	"strings"
)

// LocalOnlyMiddleware checks if the request is coming from localhost.
func LocalOnlyMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		remoteAddr := r.RemoteAddr

		log.Println("remoteAddr:", remoteAddr)
		if strings.HasPrefix(remoteAddr, "192.168.92.22") {
			next.ServeHTTP(w, r)
			return
		}

		http.Error(w, "Forbidden: Access is only allowed from localhost", http.StatusForbidden)
	})
}
