package models

import (
	"log"

	"github.com/glebarez/sqlite"
	"gorm.io/gorm"
)

type User struct {
	ID       uint   `gorm:"primaryKey"`
	Username string `gorm:"unique"`
	Password string
}

type Note struct {
	NoteID      uint `gorm:"primaryKey"`
	Title       string
	NoteContent string
	UserID      uint
	User        User `gorm:"constraint:OnDelete:CASCADE"`
}

var DB *gorm.DB

func ConnectDatabase() {
	db, err := gorm.Open(sqlite.Open("sand_notes.db"), &gorm.Config{})

	if err != nil {
		log.Fatal(err)
	}

	db.AutoMigrate(&User{}, &Note{})
	DB = db
}
