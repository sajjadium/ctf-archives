package home

import (
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"strconv"

	"github.com/dr4g0n369/sand_notes/internal/auth"
	"github.com/dr4g0n369/sand_notes/internal/models"
)

var templates = template.Must(template.ParseGlob("templates/*.html"))

func HomePageHandler(w http.ResponseWriter, r *http.Request) {
	var notes []models.Note
	userID := getUserIDFromContext(r)

	models.DB.Where("user_id = ?", userID).Find(&notes)
	templates.ExecuteTemplate(w, "home.html", notes)
}

func CreateNoteHandler(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	userID := getUserIDFromContext(r)
	note := models.Note{
		Title:       r.FormValue("title"),
		NoteContent: r.FormValue("content"),
		UserID:      userID,
	}

	models.DB.Create(&note)
	http.Redirect(w, r, "/home", http.StatusSeeOther)
}

func EditNoteHandler(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseForm(); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	noteID, _ := strconv.Atoi(r.FormValue("note_id"))
	var note models.Note

	if err := models.DB.First(&note, noteID).Error; err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	note.Title = r.FormValue("title")
	note.NoteContent = r.FormValue("content")
	models.DB.Save(&note)

	http.Redirect(w, r, "/home", http.StatusSeeOther)
}

func ViewNoteHandler(w http.ResponseWriter, r *http.Request) {
	noteID, _ := strconv.Atoi(r.URL.Query().Get("note_id"))
	var note models.Note

	if err := models.DB.First(&note, noteID).Error; err != nil {
		http.Error(w, "Note not found", http.StatusNotFound)
		return
	}

	templates.ExecuteTemplate(w, "home.html", note)
}

func DeleteNoteHandler(w http.ResponseWriter, r *http.Request) {
	noteID := struct {
		NoteID int `json:"note_id"`
	}{}
	json.NewDecoder(r.Body).Decode(&noteID)
	fmt.Println("Deleting note", noteID.NoteID)
	models.DB.Delete(&models.Note{}, noteID.NoteID)

	json.NewEncoder(w).Encode(struct {
		Success string `json:"success"`
	}{Success: "Note deleted"})
}

func getUserIDFromContext(r *http.Request) uint {
	claims, ok := r.Context().Value("claims").(*auth.Claims)
	if !ok {
		return 0
	}
	return claims.UserID
}
