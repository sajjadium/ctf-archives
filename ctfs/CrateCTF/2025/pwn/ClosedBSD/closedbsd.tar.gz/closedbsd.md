To run the challenge locally:
- download `disk.qcow2.gz` and decompress it to `disk.qcow2`,
- download `closedbsd.tar.gz` and extract it.
- either execute `run.sh` directly, or in docker with `docker compose up`.

Then you can get a shell in the VM with `ssh -i id_closedbsd -p 22909 ansible@localhost`.

Like on the challenge server, the VM listens on port 2909 and starts a new instance of the program
for each connection.

---

Provided files:
- `disk.qcow2.gz`: A disk containing an openbsd installation including the challenge service.
- `closedbsd.tar.gz`, containing:
  - `closedbsd.md`: this file.

  - `run.sh`, `Dockerfile`, `compose.yaml`: used to run the disk above.

  - `closedbsd.c`, `closedbsd`: the challenge to exploit.

  - `id_closedbsd`, `id_closedbsd.pub`: credentials to access the disk.
