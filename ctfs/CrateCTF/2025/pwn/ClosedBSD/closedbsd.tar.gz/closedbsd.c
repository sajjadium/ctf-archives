// cc -Wall -Wextra -Werror -pedantic -ggdb -O1 -o closedbsd closedbsd.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <assert.h>
#include <stdbool.h>
#include <sys/wait.h>

// Did anyone say C doesn't have coroutines?
#define crb switch (s->loc) { case 0:
#define crl s->loc = __LINE__; return; case __LINE__:
#define cre s->loc = -1; }

typedef struct {
    ssize_t loc;
    ssize_t i;
    char buf[512];
    char *pbuf;
    int sock;
    int len;
} state;

void printhex(char s[], ssize_t len) {
    for (ssize_t i = 0; i < len; i++) {
        printf("%02x", s[i]);
    }
}

void run(state *s) {
    crb s->pbuf = s->buf;
    crl puts("How many times do you want to run?");
    crl for (scanf("%zd", &s->i); s->i > 0; s->i--) {
    crl     scanf("%512s%n", s->pbuf, &s->len);
    crl     s->len -= 1;
    crl     send(s->sock, &s->len, sizeof s->len, 0);
    crl     send(s->sock, s->pbuf, s->len, 0);
    crl     fwrite(s->pbuf, 1, s->len, stdout);
        }
    crl printf("Godbye! Here are some bytes so you don't miss me: ");
    crl { char r[256]; arc4random_buf(r, 256); printhex(r, 256); }
    crl puts("");
    crl s->len = 0;
    crl send(s->sock, &s->len, sizeof s->len, 0);
    cre
}

void child(int sock) {
    pledge("stdio", NULL);
    state s = (state){ .loc = 0, .sock = sock };
    struct timespec start, now;
    clock_gettime(CLOCK_MONOTONIC, &start);
    while (s.loc != -1) {
        run(&s);
        clock_gettime(CLOCK_MONOTONIC, &now);
        if (now.tv_sec * 1000000000 + now.tv_nsec > start.tv_sec * 1000000000 + start.tv_nsec + 30000000000) {
            puts("out of time!");
            break;
        }
    }
}

void parent(int sock) {
    chdir("/srv");
    unveil("/srv", "rwc");
    unveil("/bin", "rx");
    pledge("stdio proc exec", "stdio rpath wpath cpath fattr flock getpw tty proc exec");
    while (true) {
        int len;
        recv(sock, &len, sizeof len, 0);
        if (len == 0) return;
        char script[6 + len + 12 + 1];
        memcpy(script, "echo '", 6);
        memcpy(script + 6 + len, "' >> log.txt", 12 + 1);
        recv(sock, script + 6, 16 * 1024, 0);
        for (int i = 6; i < 6 + len; i++) {
            if (script[i] < ' ' || script[i] > '~' || script[i] == '\'' || script[i] == '\\') {
                script[i] = '?';
            }
        }
        pid_t pid = fork();
        assert(pid != -1);
        if (pid == 0) {
            execlp("sh", "sh", "-c", script, NULL);
            assert(false);
        } else {
            int status;
            do {
                assert(waitpid(pid, &status, 0) == pid);
            } while (!WIFEXITED(status));
        }
    }
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);

    int sv[2];
    assert(socketpair(AF_UNIX, SOCK_SEQPACKET, 0, sv) == 0);
    pid_t child_pid = fork();
    assert(child_pid != -1);
    if (child_pid == 0) {
        child(sv[1]);
        close(sv[1]);
        exit(0);
    }
    parent(sv[0]);
    close(sv[0]);
    int status;
    pid_t res;
    do {
        res = waitpid(child_pid, &status, 0);
        assert(res != -1);
    } while (!(res == child_pid && WIFEXITED(status)));
}
