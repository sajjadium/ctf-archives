#!/bin/sh

qemu-system-x86_64 \
    -enable-kvm \
    -nographic \
    -m 1G \
    -smp cpus=2 \
    -hda disk.qcow2 \
    -nic user,hostfwd=tcp::22909-:22,hostfwd=tcp::2909-:2909 \
    -serial stdio \
    -monitor none \
    -no-reboot
