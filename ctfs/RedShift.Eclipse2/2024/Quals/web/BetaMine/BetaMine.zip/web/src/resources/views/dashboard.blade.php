<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<body>
    <div class="dashboard-container">
        <h2>Welcome, {{ $username }}!</h2>
        <p>You have successfully registered to open our Minecraft server!</p>
        @if ($is_admin)
            <a href="{{ url('/admin') }}">Go to Admin Panel</a>
        @endif
        <form action="{{ route('logout') }}" method="POST" style="margin-top: 20px;">
            <button type="submit">Logout</button>
        </form>
    </div>
</body>
</html>