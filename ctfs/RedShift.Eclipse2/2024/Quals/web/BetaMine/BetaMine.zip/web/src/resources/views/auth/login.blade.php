<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
</head>
<body>
    <div class="form-container">
        <h2>Login</h2>
        <form id="loginForm">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="button" onclick="loginUser()">Login</button>
        </form>
        <p>Don't have an account? <a href="/register">Register</a></p>

        <p id="loginMessage"></p>
    </div>
    <script>
        function loginUser() {
            const formData = new FormData(document.getElementById('loginForm'));
            fetch('/api/user/login', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.message === "Success") {
                    window.location.href = "/dashboard";
                } else {
                    document.getElementById('loginMessage').innerText = data.message;
                }
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
</body>
</html>
