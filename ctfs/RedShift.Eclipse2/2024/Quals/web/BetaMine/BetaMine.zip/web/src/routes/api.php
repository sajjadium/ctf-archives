<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware(['web'])->group(function () {

    Route::prefix('user')->group(function () {
        Route::post('/register', [UserController::class, 'register']);
        Route::post('/login', [UserController::class, 'login']);
        Route::post('/logout', function () {
            Auth::logout();
            return redirect('/login');
        })->name('logout');
    });

    Route::middleware(['auth'])->prefix('admin')->group(function () {
        Route::post('/webhook', [AdminController::class, 'saveWebhook'])->middleware('is_admin');
        Route::post('/test_webhook', [AdminController::class, 'testWebhook'])->middleware('is_admin');
        Route::get('/search_user', [AdminController::class, 'searchUser'])->middleware('is_admin');
        Route::post('/reset_password', [AdminController::class, 'resetPassword']);
    });
});
