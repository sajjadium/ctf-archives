#!/bin/bash

echo "online-mode=false" > server.properties
echo "server-port=25565" >> server.properties

# Optimization
echo "level-type=flat" >> server.properties
echo "allow-nether=false" >> server.properties
echo "allow-end=false" >> server.properties
echo "connection-throttle=-1" >> server.properties
echo "difficulty=peaceful" >> server.properties
echo "spawn-monsters=false" >> server.properties
echo "spawn-animals=false" >> server.properties
echo "spawn-npcs=false" >> server.properties

# Start Minecraft server
exec java -Xmx1024M -Xms1024M -jar server.jar nogui