package com.savsch.zipflagfinder

import com.savsch.zipflagfinder.util.FileTooLargeException
import com.savsch.zipflagfinder.util.readRequestBody
import io.ktor.server.application.*
import io.ktor.server.http.content.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.security.MessageDigest
import java.util.concurrent.TimeoutException
import kotlin.io.path.absolutePathString

fun Application.configureRouting() {
    routing {
        get("/") {
            call.respondRedirect("/public/index.html")
        }
        post("/upload") {
            var zipFolder: File? = null
            var zipFile: File? = null
            try {
                val bytes = readRequestBody(call) ?: throw FileTooLargeException()
                val filename = MessageDigest.getInstance("MD5").digest(bytes).joinToString("") { "%02x".format(it) }

                System.err.println(bytes.size)
                zipFolder = File(Singleton.publicDir, filename)
                zipFile = File(Singleton.publicDir, "$filename.zip")
                if(zipFile.exists()) {
                    throw Exception()
                }
                zipFile.writeBytes(bytes)
                val process = ProcessBuilder()
                    .command("unzip", zipFile.absolutePath, "-d", zipFolder.absolutePath)
                    .redirectError(ProcessBuilder.Redirect.INHERIT)
                    .start()

                val thread = Thread {
                    try {
                        process.waitFor()
                    } catch (e: InterruptedException) {
                        e.printStackTrace()
                    }
                }
                thread.start()
                thread.join(100)
                if (thread.isAlive) {
                    process.destroy()
                    thread.interrupt()
                    throw TimeoutException()
                }
                var fileCount = 0
                var foundFile: String? = null
                val toFind = call.request.queryParameters["toFind"]!!
                Files.walk(zipFolder.toPath()).use { stream ->
                    stream.filter { Files.isRegularFile(it) }
                        .forEach { filePath ->
                            try {
                                if (fileCount++ >= 2000) {
                                    return@forEach
                                }
                                Files.lines(filePath, StandardCharsets.UTF_8).use { lines ->
                                    lines.forEach { line ->
                                        if (line.contains(toFind)) {
                                            foundFile = filePath.absolutePathString()
                                            foundFile =
                                                foundFile?.takeLast(foundFile!!.length - zipFolder.absolutePath.length)
                                        }
                                    }
                                }
                            } catch (_: Exception) {
                                System.err.println("Error parsing the input file: ${filePath.absolutePathString()}")
                            }
                        }
                }
                if (foundFile != null) {
                    call.respondText("FLAG FOUND IN $foundFile")
                } else {
                    call.respondText("No flag found :(")
                }
            } catch (e: FileTooLargeException) {
                call.respondText("ERROR: Zip file too large. Only upto 1KB supported.")
            } catch (e: Exception) {
                e.printStackTrace()
                call.respondText("ERROR: Internal Server Error")
            } finally {
                zipFile?.let { Singleton.cleanupFiles.add(it) }
                zipFolder?.let { Singleton.cleanupFiles.add(it) }
            }

        }
        get("/verifyFlag") {
            if ((call.request.queryParameters["flag"] ?: "") == Singleton.flag) {
                call.respond("Correct flag !!")
            } else {
                call.respond("Incorrect flag :(")
            }
        }
        staticFiles("/public", Singleton.publicDir)
    }
}
