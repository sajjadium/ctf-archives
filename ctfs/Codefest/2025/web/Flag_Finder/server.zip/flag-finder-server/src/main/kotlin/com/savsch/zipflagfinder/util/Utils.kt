package com.savsch.zipflagfinder.util

import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.utils.io.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException

const val MAX_UPLOAD_SIZE = 1024

suspend fun readRequestBody(call: ApplicationCall, maxSize: Int = MAX_UPLOAD_SIZE): ByteArray? {
    return try {
        val channel = call.receiveChannel()
        val byteArray = withContext(Dispatchers.IO) {
            val buffer = ByteArray(maxSize)
            var bytesRead = 0
            while (!channel.isClosedForRead && bytesRead < maxSize) {
                val chunkSize = channel.readAvailable(buffer, bytesRead, maxSize - bytesRead)
                if (chunkSize == -1) break
                bytesRead += chunkSize
            }
            buffer.copyOf(bytesRead)
        }
        if (byteArray.size > maxSize || !channel.isClosedForRead) {
            null
        } else {
            byteArray
        }
    } catch (_: Exception) {
        null
    }
}

class FileTooLargeException : IOException()
