@file:Suppress("OPT_IN_USAGE")

package com.savsch.zipflagfinder

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit

object Singleton {
    val publicDir = File("/app/public")
    val cleanupFiles = CopyOnWriteArrayList<File>()
    val flag = File("/flag.txt").readLines().joinToString(separator = "\n")
    init {
        GlobalScope.launch(Dispatchers.IO) {
            while (true) {
                for (file in cleanupFiles) {
                    try {
                        if (file.deleteRecursively()) {
                            cleanupFiles.remove(file)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                delay(TimeUnit.SECONDS.toMillis(2))
            }
        }
    }
}