rootProject.name = "flag-find-challenge"
