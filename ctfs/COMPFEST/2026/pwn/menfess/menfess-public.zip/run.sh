#!/usr/bin/env bash
qemu-system-aarch64 \
  -machine virt \
  -m 512M \
  -smp 1 \
  -cpu cortex-a57 \
  -kernel Image \
  -initrd initramfs.cpio.gz \
  -drive file=flag.txt,if=none,id=flag,format=raw,readonly=on \
  -device virtio-blk-device,drive=flag \
  -netdev user,id=net0 -device virtio-net-device,netdev=net0 \
  -append "console=ttyAMA0 kaslr oops=panic panic=-1 quiet" \
  -nographic \
  -monitor /dev/null \
  -no-reboot
