#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/miscdevice.h>

#define DEVICE_NAME         "menfess"
#define MENFESS_SIZE        64

#define CMD_CREATE_MENFESS  0x1337
#define CMD_SEND_MENFESS    0x1338
#define CMD_VIEW_MENFESS    0x1339
#define MENFESS_COUNT       8

MODULE_LICENSE("GPL");
MODULE_AUTHOR("kannrisha");
MODULE_DESCRIPTION("Share your thoughts and feelings through this anonymous device.");

struct Menfess {
    char content[MENFESS_SIZE];
    void (*send_func)(char *);
};

struct create_req {
    unsigned long size;
    unsigned long index;
    char data[sizeof(struct Menfess)];
};

struct send_req {
    unsigned long index;
};

struct view_req {
    unsigned long index;
    char data[sizeof(struct Menfess)];
};

static struct Menfess *menfess_list[MENFESS_COUNT];

static void default_func(char *content)
{
    printk(KERN_INFO "Sent menfess with content: %s\n", content);
}

static long menfess_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
    switch (cmd) {
    case CMD_CREATE_MENFESS: {
        struct create_req req;
        
        if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
            return -EFAULT;

        if (req.size > sizeof(struct Menfess))
            return -EINVAL;

        if (req.index >= MENFESS_COUNT)
            return -EINVAL;
        
        struct Menfess *obj = kzalloc(sizeof(struct Menfess), GFP_KERNEL);

        if (!obj)
            return -ENOMEM;
        

        obj->send_func = default_func;
        memcpy(obj->content, req.data, req.size); 

        menfess_list[req.index] = obj;

        return 0;
    }
    case CMD_SEND_MENFESS: {
        struct send_req req;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
            return -EFAULT;

        if (req.index >= MENFESS_COUNT)
            return -EINVAL;
        
        struct Menfess *obj = menfess_list[req.index];

        if (!obj)
            return -EINVAL;

        obj->send_func(obj->content);

        return 0;
    }
    case CMD_VIEW_MENFESS: {
        struct view_req req;

        if (copy_from_user(&req, (void __user *)arg, sizeof(req)))
            return -EFAULT;

        if (menfess_list[req.index] == NULL)
            return -EINVAL;

        struct Menfess *obj = menfess_list[req.index];  


        if (!obj)
            return -EINVAL;

        if (copy_to_user(&((struct view_req __user *)arg)->data,
                      obj, sizeof(*obj)))
            return -EFAULT;

        return 0;
    }

    default:
        return -EINVAL;
    }
}

static const struct file_operations menfess_fops = {
    .unlocked_ioctl = menfess_ioctl,
};

static struct miscdevice menfess_dev = {
    .minor = MISC_DYNAMIC_MINOR,
    .name  = DEVICE_NAME,
    .fops  = &menfess_fops,
    .mode  = 0666,
};

static int __init menfess_init(void)
{
    return misc_register(&menfess_dev);
}

static void __exit menfess_exit(void)
{
    misc_deregister(&menfess_dev);
    for (int i = 0; i < MENFESS_COUNT; i++) {
        kfree(menfess_list[i]);
    }
}

module_init(menfess_init);
module_exit(menfess_exit);
