This version of redis-cli was compiled with MALLOC=libc, as the default jemalloc setting prevented the bug from being exploited. 

Because I'd rather not have you find an actual 0 day to exploit this, the bug is in **clusterManagerNodeLoadInfo**. I don't think this bug is exploitable on default builds, but if you manage to do so dm me (zafirr) on discord cause I want to know how you did it.
