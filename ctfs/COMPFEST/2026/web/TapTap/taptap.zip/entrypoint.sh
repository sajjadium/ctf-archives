#!/bin/sh
set -eu

PGBIN=/usr/lib/postgresql/18/bin
PGDATA="${PGDATA:-/var/lib/postgresql/18/docker}"
export PGHOST=/tmp

if [ -z "${FLAG:-}" ]; then
    FLAG="COMPFEST{local_flag}"
fi
PLAYER_PASSWORD="${PLAYER_PASSWORD:-tap-tap-demo}"
PLAYER_DB_PASSWORD="${PLAYER_DB_PASSWORD:-shop-local-only}"
GAME_WRITER_PASSWORD="${GAME_WRITER_PASSWORD:-game-local-only}"
FORUM_WRITER_PASSWORD="${FORUM_WRITER_PASSWORD:-forum-local-only}"
REGISTRATION_WRITER_PASSWORD="${REGISTRATION_WRITER_PASSWORD:-registration-local-only}"
AUTH_READER_PASSWORD="${AUTH_READER_PASSWORD:-auth-local-only}"

if [ ! -d "$PGDATA" ]; then
    mkdir -p "$PGDATA"
    "$PGBIN/initdb" -D "$PGDATA" -U postgres \
        --auth-local=trust --auth-host=scram-sha-256 --no-instructions
fi

"$PGBIN/pg_ctl" -D "$PGDATA" -w \
    -o "-c listen_addresses=127.0.0.1 -p 5432 -k /tmp" \
    -l /tmp/postgres.log start

if ! "$PGBIN/psql" -U postgres -d postgres -tAc \
        "SELECT 1 FROM pg_database WHERE datname='taptap'" | grep -q 1; then
    "$PGBIN/createdb" -U postgres taptap
    "$PGBIN/psql" -U postgres -d taptap \
        -v ON_ERROR_STOP=1 \
        -v flag="$FLAG" \
        -v player_password="$PLAYER_PASSWORD" \
        -v player_pw="$PLAYER_DB_PASSWORD" \
        -v game_writer_pw="$GAME_WRITER_PASSWORD" \
        -v forum_writer_pw="$FORUM_WRITER_PASSWORD" \
        -v registration_writer_pw="$REGISTRATION_WRITER_PASSWORD" \
        -v auth_reader_pw="$AUTH_READER_PASSWORD" \
        -f /opt/taptap/init.sql
fi


cd /srv/app
PORT=3000 \
DB_HOST=127.0.0.1 \
DB_PORT=5432 \
DB_NAME=taptap \
BOT_URL=http://127.0.0.1:4000 \
SESSION_SECRET="${SESSION_SECRET:-single-image-session-secret}" \
PLAYER_DB_PASSWORD="$PLAYER_DB_PASSWORD" \
GAME_WRITER_PASSWORD="$GAME_WRITER_PASSWORD" \
FORUM_WRITER_PASSWORD="$FORUM_WRITER_PASSWORD" \
REGISTRATION_WRITER_PASSWORD="$REGISTRATION_WRITER_PASSWORD" \
AUTH_READER_PASSWORD="$AUTH_READER_PASSWORD" \
node server.js &

cd /srv/bot
PORT=4000 \
APP_URL="${APP_URL:-http://app.test:3000}" \
FLAG="$FLAG" \
node bot.js &

wait
