const { escapeHTML, decodeStoredText } = require('../lib/security');

const displayText = (value) => escapeHTML(decodeStoredText(value));

function powerupIcon(id) {
  const icons = [
    '<path d="m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z"/>',
    '<path d="M12 20V9.5M12 12.5c-5.5 0-6.5-7.5-2.4-7.5 2.1 0 2.4 2.5 2.4 4.5 0-2 .3-4.5 2.4-4.5 4.1 0 3.1 7.5-2.4 7.5ZM12 16c-3.7 0-5.4 3.5-3 4.7 1.7.8 2.7-1.8 3-4.7 0 2.9 1.3 5.5 3 4.7 2.4-1.2.7-4.7-3-4.7Z"/>',
    '<circle cx="12" cy="12" r="6.5"/><circle cx="12" cy="12" r="2.1" fill="currentColor" stroke="none"/>',
    '<circle cx="12" cy="12" r="3.3"/><path d="M12 2.8v3M5.5 5.5l2.2 2.2M2.8 12h3M5.5 18.5l2.2-2.2M12 21.2v-3M18.5 18.5l-2.2-2.2M21.2 12h-3"/>',
    '<path d="M12 4.1c2.5-3.2 7.2.2 4.6 3.3 3.2-2.5 6.6 2.1 3.3 4.6 3.2 2.5-.1 7.1-3.3 4.6 2.5 3.2-2.1 6.5-4.6 3.3-2.5 3.2-7.1-.1-4.6-3.3-3.2 2.5-6.5-2.1-3.3-4.6-3.2-2.5.1-7.1 3.3-4.6C4.9 4.3 9.5.9 12 4.1Z"/>',
    '<path d="M3.5 12c3.6-4.7 8.4-6.2 13-4.2l4-2.3-1 4.4 1 4.4-4-2.3c-4.6 2-9.4.5-13-4.2 3.6 4.7 8.4 6.2 13 4.2"/><circle cx="9.2" cy="10.2" r=".8" fill="currentColor" stroke="none"/>',
    '<path d="M18.6 15.7A7.5 7.5 0 0 1 8.3 5.4 7.5 7.5 0 1 0 18.6 15.7Z"/><path d="m17.7 4 .5 1.4 1.4.5-1.4.5-.5 1.4-.5-1.4-1.4-.5 1.4-.5.5-1.4Z"/>',
    '<path d="m12 3 6.7 6.2L12 21 5.3 9.2 12 3Z"/><path d="m5.3 9.2 6.7 3 6.7-3M12 12.2V21M8.5 6.2 12 12.2l3.5-6"/>'
  ];
  const index = Number.parseInt(id, 10) - 1;
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[Number.isInteger(index) && index >= 0 ? index % icons.length : 0]}</svg>`;
}

function icon(name) {
  const paths = {
    game: '<path d="M3.5 10.5 12 3l8.5 7.5v8.25a1.25 1.25 0 0 1-1.25 1.25H4.75a1.25 1.25 0 0 1-1.25-1.25v-8.25Z"/><path d="M9 20v-5.5h6V20"/>',
    shop: '<path d="M5.5 9.5h13l-1 10h-11l-1-10Z"/><path d="M8 9.5V7a4 4 0 0 1 8 0v2.5"/>',
    inventory: '<path d="M4 8.25 12 4l8 4.25v8L12 20l-8-3.75v-8Z"/><path d="m4 8.25 8 4.25 8-4.25M12 12.5V20"/>',
    forum: '<path d="M5 5.75h14A1.75 1.75 0 0 1 20.75 7.5v8A1.75 1.75 0 0 1 19 17.25H11l-4.75 3v-3H5A1.75 1.75 0 0 1 3.25 15.5v-8A1.75 1.75 0 0 1 5 5.75Z"/><path d="M8 10h8M8 13h5"/>',
    report: '<path d="M6 21V4m0 1h11l-1.5 3L17 11H6"/>',
    logout: '<path d="M10.5 4H5.75A1.75 1.75 0 0 0 4 5.75v12.5C4 19.22 4.78 20 5.75 20h4.75"/><path d="m14 8 4 4-4 4"/><path d="M8 12h10"/>'
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${paths[name]}</svg>`;
}

function nav(active) {
  const links = [
    ['game', '/game', 'Arena'],
    ['shop', '/shop', 'Shop'],
    ['inventory', '/inventory', 'Inventory'],
    ['forum', '/forum', 'Forum']
  ];
  const items = links.map(([key, href, label]) => `
    <a class="nav-link ${active === key ? 'is-active' : ''}" href="${href}" aria-label="${label}" title="${label}">${icon(key)}<span class="sr-only">${label}</span></a>`).join('');
  return `<nav class="nav-dock" aria-label="Primary navigation">${items}
    <form action="/logout" method="post"><button class="nav-link nav-logout" type="submit" aria-label="Sign out" title="Sign out">${icon('logout')}<span class="sr-only">Sign out</span></button></form>
  </nav>`;
}

function layout({ title, user, active, body, scripts = '' }) {
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHTML(title)} · TapTap Arena</title><link rel="stylesheet" href="/static/styles.css"></head>
<body><div class="ambient ambient-one"></div><div class="ambient ambient-two"></div>
<main class="shell">${body}</main>${nav(active)}${scripts}</body></html>`;
}

module.exports = { displayText, escapeHTML, layout, powerupIcon };
