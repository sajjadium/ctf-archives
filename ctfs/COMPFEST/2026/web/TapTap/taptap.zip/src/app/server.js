const path = require('path');
const Fastify = require('fastify');
const cookie = require('@fastify/cookie');
const formbody = require('@fastify/formbody');
const fastifyStatic = require('@fastify/static');
const bcrypt = require('bcryptjs');
const { pools, closePools } = require('./lib/db');
const { escapeMinimal, safeText, purifyForumText } = require('./lib/security');
const views = require('./views/index');

const app = Fastify({ logger: true });
const port = Number(process.env.PORT || 3000);
const usernamePattern = /^[a-z0-9_]{3,24}$/;
const appCsp = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self'",
  "connect-src 'self'",
  "frame-src 'none'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'self'"
].join('; ');

app.register(cookie, { secret: process.env.SESSION_SECRET || 'development-session-secret-change-me' });
app.register(formbody);
app.register(fastifyStatic, { root: path.join(__dirname, 'public'), prefix: '/static/' });

function session(request) {
  const raw = request.cookies.session;
  if (!raw) return null;
  const unsigned = request.unsignCookie(raw);
  if (!unsigned.valid || !/^[a-z0-9_]{3,24}$/.test(unsigned.value)) return null;
  return { username: unsigned.value };
}

function redirectLogin(reply) {
  return reply.redirect('/login');
}

// Keep ordinary application pages out of the challenge's HTML/CSP trust boundary.
// /forum/:id deliberately does not use this helper: its in-document CSP and srcdoc
// behavior are the intended browser exploitation surface.
function sendAppPage(reply, html) {
  return reply
    .header('Content-Security-Policy', appCsp)
    .header('X-Content-Type-Options', 'nosniff')
    .type('text/html')
    .send(html);
}

function idFrom(value) {
  const id = Number.parseInt(String(value), 10);
  return Number.isSafeInteger(id) && id > 0 ? id : null;
}

async function profileFor(username) {
  const profile = await pools.game.query('SELECT taps, coins FROM game.profiles WHERE username = $1', [username]);
  return profile.rows[0] || { taps: 0, coins: 0 };
}

app.get('/health', async () => ({ ok: true }));

app.get('/', async (request, reply) => session(request) ? reply.redirect('/game') : reply.redirect('/login'));

app.get('/login', async (request, reply) => {
  if (session(request)) return reply.redirect('/game');
  return sendAppPage(reply, views.loginPage(request.query?.error));
});

app.get('/register', async (request, reply) => {
  if (session(request)) return reply.redirect('/game');
  return sendAppPage(reply, views.registerPage(request.query?.error));
});

app.post('/register', async (request, reply) => {
  if (session(request)) return reply.redirect('/game');
  const username = safeText(request.body?.username, 24);
  const password = String(request.body?.password || '');
  if (!usernamePattern.test(username)) {
    return reply.redirect('/register?error=Username%20must%20be%203%E2%80%9324%20lowercase%20letters%2C%20numbers%2C%20or%20underscores');
  }
  if (username === 'admin') return reply.redirect('/register?error=Username%20is%20not%20available');
  if (Buffer.byteLength(password, 'utf8') < 8 || Buffer.byteLength(password, 'utf8') > 72) {
    return reply.redirect('/register?error=Password%20must%20be%208%E2%80%9372%20bytes');
  }

  const client = await pools.registration.connect();
  try {
    const passwordHash = await bcrypt.hash(password, 12);
    await client.query('BEGIN');
    await client.query('INSERT INTO auth.users (username, password_hash) VALUES ($1, $2)', [username, passwordHash]);
    await client.query('INSERT INTO game.profiles (username) VALUES ($1)', [username]);
    await client.query('COMMIT');
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') return reply.redirect('/register?error=Username%20is%20already%20taken');
    request.log.error(error);
    return reply.redirect('/register?error=Registration%20is%20unavailable.%20Try%20again');
  } finally {
    client.release();
  }

  reply.setCookie('session', username, { signed: true, httpOnly: true, sameSite: 'lax', path: '/' });
  return reply.redirect('/game');
});

app.post('/login', async (request, reply) => {
  const username = safeText(request.body?.username, 24);
  const password = String(request.body?.password || '');
  const result = await pools.auth.query('SELECT username, password_hash FROM auth.users WHERE username = $1', [username]);
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return reply.redirect('/login?error=Incorrect%20username%20or%20password');
  }
  reply.setCookie('session', user.username, { signed: true, httpOnly: true, sameSite: 'lax', path: '/' });
  return reply.redirect('/game');
});

app.post('/logout', async (request, reply) => {
  reply.clearCookie('session', { path: '/' });
  return reply.redirect('/login');
});

app.get('/game', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  const profile = await profileFor(user.username);
  return sendAppPage(reply, views.gamePage(user, profile));
});

app.post('/api/game/claim', async (request, reply) => {
  const user = session(request);
  if (!user) return reply.code(401).send({ error: 'login required' });
  const taps = Number(request.body?.taps);
  if (!Number.isInteger(taps) || taps < 1 || taps > 3) return reply.code(400).send({ error: 'invalid tap' });
  const result = await pools.game.query(`UPDATE game.profiles
    SET taps = taps + $1, coins = coins + $1 WHERE username = $2
    RETURNING taps, coins`, [taps, user.username]);
  return result.rows[0];
});

app.get('/shop', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  const sort = typeof request.query?.sort === 'string' ? request.query.sort : 'price ASC';
  const message = typeof request.query?.error === 'string' ? request.query.error : undefined;
  const sql = `SELECT id, name, price, multiplier FROM game.powerups ORDER BY ${sort}`;
  try {
    const result = await pools.shop.query(sql);
    const primary = Array.isArray(result) ? result[0] : result;
    return sendAppPage(reply, views.shopPage(user, primary.rows, sort, message));
  } catch (error) {
    return sendAppPage(reply.code(400), views.shopPage(user, [], sort, error.message));
  }
});

app.post('/shop/buy', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  const itemId = idFrom(request.body?.id);
  if (!itemId) return reply.redirect('/shop');
  const client = await pools.game.connect();
  try {
    await client.query('BEGIN');
    const item = await client.query('SELECT id, price FROM game.powerups WHERE id = $1', [itemId]);
    const profile = await client.query('SELECT coins FROM game.profiles WHERE username = $1 FOR UPDATE', [user.username]);
    if (!item.rows[0] || !profile.rows[0] || profile.rows[0].coins < item.rows[0].price) throw new Error('Not enough coins for that item.');
    await client.query('UPDATE game.profiles SET coins = coins - $1 WHERE username = $2', [item.rows[0].price, user.username]);
    await client.query(`INSERT INTO game.inventory (username, powerup_id, quantity) VALUES ($1, $2, 1)
      ON CONFLICT (username, powerup_id) DO UPDATE SET quantity = game.inventory.quantity + 1`, [user.username, itemId]);
    await client.query('COMMIT');
    return reply.redirect('/shop');
  } catch (error) {
    await client.query('ROLLBACK');
    return reply.redirect(`/shop?error=${encodeURIComponent(error.message)}`);
  } finally {
    client.release();
  }
});

app.get('/inventory', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  const result = await pools.game.query(`SELECT powerups.id, powerups.name, powerups.multiplier,
    inventory.quantity
    FROM game.inventory AS inventory
    JOIN game.powerups AS powerups ON powerups.id = inventory.powerup_id
    WHERE inventory.username = $1 AND inventory.quantity > 0
    ORDER BY powerups.id`, [user.username]);
  return sendAppPage(reply, views.inventoryPage(user, result.rows));
});

app.get('/forum', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  const result = await pools.shop.query('SELECT id, title, content, author_name, created_at FROM game.forum_posts ORDER BY id DESC');
  return sendAppPage(reply, views.forumPage(user, result.rows, request.query?.message));
});

app.post('/forum', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);

  const title = purifyForumText(request.body?.title, 80);
  const content = purifyForumText(request.body?.content, 1600);
  if (!title || !content) return reply.redirect('/forum?message=A%20post%20needs%20a%20title%20and%20body');

  await pools.forum.query(
    'INSERT INTO game.forum_posts (title, content, author_name) VALUES ($1, $2, $3)',
    [title, content, user.username]
  );
  return reply.redirect('/forum?message=Post%20published');
});

app.get('/forum/:id', async (request, reply) => {
  const id = idFrom(request.params.id);
  if (!id) return reply.code(404).send('Post not found');
  const result = await pools.shop.query('SELECT content FROM game.forum_posts WHERE id = $1', [id]);
  if (!result.rows[0]) return reply.code(404).send('Post not found');
  reply.header('Cache-Control', 'no-store');
  const content = escapeMinimal(result.rows[0].content);
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>TapTalk</title>
<style>
  :root { color: #27385f; font-family: Inter, ui-rounded, system-ui, sans-serif; background: #f7f1ff; }
  * { box-sizing: border-box; }
  body { display: grid; min-height: 100vh; margin: 0; padding: 28px; place-items: center; overflow-x: hidden; background: radial-gradient(circle at 10% 8%, #d8f3ff 0 12%, transparent 12.2%), radial-gradient(circle at 93% 90%, #ffe3a6 0 13%, transparent 13.2%), #f7f1ff; }
  .viewer { width: min(920px, 100%); padding: 12px; border: 4px solid rgba(255,255,255,.9); border-radius: 34px; background: linear-gradient(145deg, #b9eaff, #ddd0ff 52%, #ffc9a9); box-shadow: 0 18px 0 #9db4de, 0 34px 64px rgba(64,72,121,.25); }
  .viewer-head { display: flex; align-items: center; justify-content: space-between; gap: 16px; padding: 13px 15px 15px; }
  .viewer-title { display: flex; align-items: center; gap: 10px; min-width: 0; font-size: 13px; font-weight: 900; letter-spacing: -.01em; }
  .viewer-icon { display: grid; width: 34px; height: 34px; flex: 0 0 auto; place-items: center; color: #fff; border: 3px solid rgba(255,255,255,.92); border-radius: 12px 12px 12px 4px; background: #ff8d70; box-shadow: 0 3px 0 #da6d56; transform: rotate(-6deg); }
  .viewer-meta { padding: 7px 10px; color: #6a53a5; font-size: 10px; font-weight: 900; letter-spacing: .08em; text-transform: uppercase; border: 2px solid rgba(255,255,255,.85); border-radius: 99px; background: rgba(255,255,255,.58); }
  .viewer-screen { overflow: hidden; border: 4px solid rgba(255,255,255,.92); border-radius: 24px; background: #fff; box-shadow: inset 0 0 0 2px rgba(83,116,161,.1); }
  iframe { display: block; width: 100%; height: min(68vh, 610px); min-height: 390px; border: 0; background: #fff; }
  @media (max-width: 560px) { body { padding: 14px; }.viewer { padding: 8px; border-radius: 25px; box-shadow: 0 11px 0 #9db4de, 0 24px 42px rgba(64,72,121,.2); }.viewer-head { padding: 10px 8px 12px; }.viewer-meta { padding: 6px 8px; font-size: 9px; }.viewer-screen { border-radius: 18px; } iframe { min-height: calc(100vh - 156px); height: calc(100vh - 156px); } }
</style>
<script>document.head.insertAdjacentHTML("beforeend", \`<meta http-equiv="Content-Security-Policy" content="script-src 'none';">\`);</script>
</head><body><main class="viewer"><header class="viewer-head"><div class="viewer-title"><span class="viewer-icon">💬</span><span>TapTalk</span></div><span class="viewer-meta">Post #${id}</span></header><div class="viewer-screen"><iframe title="TapTalk post ${id}" srcdoc="${content}"></iframe></div></main></body></html>`;
  return reply.type('text/html').send(html);
});

app.get('/report', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  return sendAppPage(reply, views.reportPage(user, request.query?.message));
});

app.post('/report', async (request, reply) => {
  const user = session(request);
  if (!user) return redirectLogin(reply);
  let target;
  try {
    target = new URL(safeText(request.body?.url, 2048));
  } catch (_) {
    return reply.redirect('/report?message=Invalid%20URL');
  }
  if (!['http:', 'https:'].includes(target.protocol)) return reply.redirect('/report?message=Only%20HTTP%2FHTTPS%20URLs%20are%20accepted');
  try {
    const bot = await fetch(`${process.env.BOT_URL}/visit`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ url: target.href }) });
    if (!bot.ok) throw new Error('bot unavailable');
    return reply.redirect('/report?message=A%20moderator%20is%20opening%20your%20report');
  } catch (_) {
    return reply.redirect('/report?message=The%20bot%20is%20not%20ready.%20Try%20again');
  }
});

app.setErrorHandler((error, request, reply) => {
  request.log.error(error);
  if (reply.sent) return;
  reply.code(500).type('text/plain').send('The arena is resting. Try again.');
});

app.addHook('onClose', async () => closePools());
app.listen({ port, host: '0.0.0.0' }).catch((error) => { app.log.error(error); process.exit(1); });
