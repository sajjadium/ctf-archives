const { escapeHTML } = require('./shared');

function authPage({ title, action, fields, button, message, footer }) {
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>TapTap Arena</title><link rel="stylesheet" href="/static/styles.css"></head>
  <body class="login-body"><div class="login-orbit" aria-hidden="true"></div><main class="login-card">
  <div class="auth-controls" aria-hidden="true"><i></i><i></i><i></i></div><h1>${title}</h1>
  ${message ? `<p class="notice is-error">${escapeHTML(message)}</p>` : ''}
  <form method="post" action="${action}" class="stack-form">${fields}<button class="primary-button" type="submit">${button}</button></form>
  <p class="demo-note">${footer}</p></main></body></html>`;
}

function loginPage(message) {
  return authPage({
    title: 'Login',
    action: '/login',
    fields: '<label>Username<input required name="username" autocomplete="username" placeholder="Username"></label><label>Password<input required type="password" name="password" autocomplete="current-password" placeholder="Password"></label>',
    button: 'Login',
    message,
    footer: 'Need an account? <a href="/register">Register</a>'
  });
}

function registerPage(message) {
  return authPage({
    title: 'Register',
    action: '/register',
    fields: '<label>Username<input required name="username" minlength="3" maxlength="24" pattern="[a-z0-9_]+" autocomplete="username" placeholder="Username"></label><label>Password<input required type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" placeholder="Password"></label>',
    button: 'Register',
    message,
    footer: 'Already registered? <a href="/login">Login</a>'
  });
}

module.exports = { loginPage, registerPage };
