const { displayText, escapeHTML, layout } = require('./shared');

const avatars = ['🐱', '🦊', '🐼', '🐸'];
const colors = ['is-sun', 'is-sky', 'is-grape', 'is-mint'];

function dateLabel(value) {
  return new Date(value).toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
}

function forumPage(user, posts, message) {
  const rows = posts.map((post, index) => `<article class="forum-post ${colors[index % colors.length]}">
    <div class="forum-avatar">${avatars[index % avatars.length]}</div>
    <div class="forum-post-copy"><div class="forum-meta"><strong>${escapeHTML(post.author_name)}</strong><span>${escapeHTML(dateLabel(post.created_at))}</span><b>LV ${8 + index}</b></div><h2>${displayText(post.title)}</h2><p>${displayText(post.content).slice(0, 180)}</p></div>
    <a class="forum-open" href="/forum/${encodeURIComponent(String(post.id))}" aria-label="Open post ${displayText(post.title)}">→</a>
  </article>`).join('');
  return layout({ title: 'Forum', user, active: 'forum', body: `<section class="forum-page"><header class="forum-banner"><div class="forum-bubble">💬</div><div><p>TapTalk</p><h1>Forum</h1></div><a class="forum-report-link" href="/report" aria-label="Report a link" title="Report a link">⚑</a></header>${message ? `<p class="notice">${escapeHTML(message)}</p>` : ''}<form class="forum-compose" method="post" action="/forum"><div class="forum-compose-heading"><span>✎</span><strong>New post</strong></div><label class="sr-only" for="forum-title">Post title</label><input id="forum-title" name="title" required maxlength="80" placeholder="Post title"><label class="sr-only" for="forum-content">Post body</label><textarea id="forum-content" name="content" required maxlength="1600" placeholder="Write something..."></textarea><button class="forum-submit" type="submit">Post <span>→</span></button></form><section class="forum-feed">${rows}</section></section>` });
}

function reportPage(user, message) {
  return layout({ title: 'Report', user, active: 'report', body: `<section class="report-page"><article class="report-panel"><div class="report-icon">⚑</div><p>MODERATOR</p><h1>Report a link</h1><span>The moderator will open this URL.</span><p class="report-origin-note">If your page opens a TapTalk post, use the moderator's review origin: <code>http://app.test:3000</code>. This address is available inside the moderator browser only.</p>${message ? `<div class="notice">${escapeHTML(message)}</div>` : ''}<form method="post" action="/report" class="stack-form"><label>URL<input required type="url" name="url" placeholder="https://example.com"></label><button class="primary-button" type="submit">Send <span>→</span></button></form></article></section>` });
}

module.exports = { forumPage, reportPage };
