const { escapeHTML, layout, powerupIcon } = require('./shared');

function inventoryPage(user, items) {
  const collection = items.length
    ? items.map((item, index) => `<article class="inventory-item inventory-shade-${index % 4}">
      <div class="inventory-art"><span class="shop-icon inventory-icon">${powerupIcon(item.id)}</span></div>
      <div class="inventory-copy"><span>POWER-UP · LV ${escapeHTML(item.multiplier)}</span><h2>${escapeHTML(item.name)}</h2></div>
      <b class="inventory-quantity" aria-label="Owned quantity ${escapeHTML(item.quantity)}">×${escapeHTML(item.quantity)}</b>
    </article>`).join('')
    : `<div class="inventory-empty"><span aria-hidden="true">✦</span><h2>No items yet</h2><p>Power-ups you collect in Shop appear here.</p><a href="/shop">Go to Shop</a></div>`;

  return layout({
    title: 'Inventory',
    user,
    active: 'inventory',
    body: `<section class="inventory-page"><header class="inventory-header"><div class="inventory-badge" aria-hidden="true">▣</div><div><p>MY COLLECTION</p><h1>Inventory</h1></div><span class="inventory-total">${items.length} item</span></header><section class="inventory-list" aria-label="Owned items">${collection}</section></section>`
  });
}

module.exports = { inventoryPage };
