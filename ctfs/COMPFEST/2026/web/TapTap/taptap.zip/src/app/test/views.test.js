const assert = require('node:assert/strict');
const test = require('node:test');

const {
  forumPage,
  gamePage,
  inventoryPage,
  shopPage
} = require('../views');

const payload = '\"><script>globalThis.pwned=true</script>';
const escapedPayload = '&quot;&gt;&lt;script&gt;globalThis.pwned=true&lt;/script&gt;';
const user = { username: 'admin' };

function assertPayloadEncoded(html) {
  assert.equal(html.includes(payload), false);
  assert.equal(html.includes('<script>globalThis.pwned=true</script>'), false);
  assert.equal(html.includes(escapedPayload), true);
}

test('game encodes profile values even if editor changes their column types', () => {
  assertPayloadEncoded(gamePage(user, { coins: payload, taps: payload }));
});

test('shop encodes every database-backed scalar', () => {
  assertPayloadEncoded(shopPage(user, [{
    id: payload,
    name: payload,
    price: payload,
    multiplier: payload
  }], 'price ASC'));
});

test('inventory encodes every database-backed scalar', () => {
  assertPayloadEncoded(inventoryPage(user, [{
    id: 1,
    name: payload,
    multiplier: payload,
    quantity: payload
  }]));
});

test('forum index encodes an editor-controlled post id', () => {
  const html = forumPage(user, [{
    id: payload,
    title: 'title',
    content: 'content',
    author_name: 'author',
    created_at: new Date(0)
  }]);
  assert.equal(html.includes(payload), false);
  assert.equal(html.includes(encodeURIComponent(payload)), true);
});
