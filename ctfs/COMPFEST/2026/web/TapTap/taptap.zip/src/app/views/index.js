const { loginPage, registerPage } = require('./login');
const { gamePage } = require('./game');
const { shopPage } = require('./shop');
const { inventoryPage } = require('./inventory');
const { forumPage, reportPage } = require('./forum');

module.exports = { loginPage, registerPage, gamePage, shopPage, inventoryPage, forumPage, reportPage };
