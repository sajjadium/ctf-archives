const { escapeHTML, layout, powerupIcon } = require('./shared');

function shopPage(user, items, sort, error) {
  const cards = items.map((item, index) => `<article class="shop-card shade-${index % 8}"><div class="item-art"><span class="shop-icon">${powerupIcon(item.id)}</span></div><span class="item-level">LV ${escapeHTML(item.multiplier)}</span><h2>${escapeHTML(item.name)}</h2><div class="shop-buy"><span><b>${escapeHTML(item.price)}</b> coin</span><form method="post" action="/shop/buy"><input type="hidden" name="id" value="${escapeHTML(item.id)}"><button type="submit">Get <span>+</span></button></form></div></article>`).join('');
  return layout({ title: 'Shop', user, active: 'shop', body: `<section class="page-heading shop-heading"><h1>Shop</h1><form class="sort-control" method="get"><label for="sort">Sort items</label><select id="sort" name="sort"><option value="price ASC" ${sort === 'price ASC' ? 'selected' : ''}>Price: low to high</option><option value="name ASC" ${sort === 'name ASC' ? 'selected' : ''}>Name: A–Z</option><option value="multiplier DESC" ${sort === 'multiplier DESC' ? 'selected' : ''}>Highest multiplier</option></select></form></section>${error ? `<p class="notice is-error">Shop error: ${escapeHTML(error)}</p>` : ''}<section class="shop-grid">${cards}</section>`, scripts: '<script src="/static/shop.js"></script>' });
}

module.exports = { shopPage };
