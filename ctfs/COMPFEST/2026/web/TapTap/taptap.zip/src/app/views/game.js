const { escapeHTML, layout } = require('./shared');

function gamePage(user, profile) {
  return layout({ title: 'Tap arena', user, active: 'game', body: `
  <section class="game-stage panel">
    <div class="coin-pill"><span>●</span> <strong id="coinCount">${escapeHTML(profile.coins)}</strong> coin</div>
    <div class="tap-scene"><div class="burst burst-a"></div><div class="burst burst-b"></div>
      <button id="tapButton" class="tap-button" type="button" aria-label="Tap Bongo Cat to earn one coin"><img id="tapCat" src="/static/assets/bongo-cat-idle.png" data-idle-src="/static/assets/bongo-cat-idle.png" data-tap-src="/static/assets/bongo-cat-tap.png" alt="Bongo Cat tapping the table"><span class="tap-label">TAP!</span></button>
    </div>
    <div class="tap-caption"><strong id="tapCount">${escapeHTML(profile.taps)}</strong><span>taps</span></div>
  </section>`, scripts: '<script src="/static/game.js"></script>' });
}

module.exports = { gamePage };
