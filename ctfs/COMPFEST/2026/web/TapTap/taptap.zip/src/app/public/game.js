(() => {
  const button = document.querySelector('#tapButton');
  if (!button) return;
  const cat = document.querySelector('#tapCat');
  const coins = document.querySelector('#coinCount');
  const taps = document.querySelector('#tapCount');
  const TAP_FRAME_MS = 65;
  const CLAIM_BATCH_SIZE = 3;
  let queuedTaps = 0;
  let claimInFlight = false;
  let showingTapFrame = false;
  let tapFrameTimer;

  function playTapFrame() {
    if (!cat) return;

    window.clearTimeout(tapFrameTimer);
    showingTapFrame = !showingTapFrame;
    cat.src = showingTapFrame ? cat.dataset.tapSrc : cat.dataset.idleSrc;
    button.classList.toggle('is-tapping', showingTapFrame);

    tapFrameTimer = window.setTimeout(() => {
      showingTapFrame = false;
      cat.src = cat.dataset.idleSrc;
      button.classList.remove('is-tapping');
    }, TAP_FRAME_MS);
  }

  function floatCoin() {
    const coin = document.createElement('span');
    coin.className = 'floating-coin';
    coin.textContent = '+1 ●';
    coin.style.left = `${42 + Math.random() * 16}%`;
    coin.style.top = `${42 + Math.random() * 12}%`;
    button.closest('.tap-scene').append(coin);
    coin.addEventListener('animationend', () => coin.remove());
  }

  async function flushClaims() {
    if (claimInFlight) return;
    claimInFlight = true;

    try {
      while (queuedTaps > 0) {
        const tapsToClaim = Math.min(queuedTaps, CLAIM_BATCH_SIZE);
        queuedTaps -= tapsToClaim;

        const response = await fetch('/api/game/claim', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ taps: tapsToClaim })
        });
        if (!response.ok) throw new Error('claim failed');

        const state = await response.json();
        coins.textContent = state.coins;
        taps.textContent = state.taps;
      }
    } catch (_) {
      queuedTaps = 0;
      button.title = 'Tap connection lost. Try again.';
    } finally {
      claimInFlight = false;
      if (queuedTaps > 0) void flushClaims();
    }
  }

  button.addEventListener('click', () => {
    playTapFrame();
    floatCoin();
    queuedTaps += 1;
    void flushClaims();
  });
})();
