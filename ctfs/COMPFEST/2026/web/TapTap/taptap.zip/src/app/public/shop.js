(() => {
  const sort = document.querySelector('#sort');
  if (sort) sort.addEventListener('change', () => sort.form.submit());
})();
