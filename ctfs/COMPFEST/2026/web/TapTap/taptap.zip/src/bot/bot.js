const http = require('http');
const puppeteer = require('puppeteer-core');

const port = Number(process.env.PORT || 4000);
const appUrl = process.env.APP_URL || 'http://app.test:3000';
const flag = process.env.FLAG || 'COMPFEST{development_flag}';
const chromePath = process.env.CHROME_PATH || '/opt/chrome/chrome-linux64/chrome';
const queue = [];
let busy = false;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function visit(target) {
  const browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: true,
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--host-resolver-rules=MAP app.test 127.0.0.1',
      '--disable-popup-blocking'
    ]
  });
  try {
    const context = await browser.createBrowserContext();
    const page = await context.newPage();
    page.setDefaultNavigationTimeout(12_000);
    await page.goto(`${appUrl}/login`, { waitUntil: 'domcontentloaded' });
    await page.type('input[name="username"]', 'admin');
    await page.type('input[name="password"]', flag);
    await Promise.all([
      page.waitForFunction(() => location.pathname === '/game'),
      page.click('button[type="submit"]')
    ]);
    await context.setCookie({
      name: 'flag', value: flag, url: appUrl,
      httpOnly: false, secure: false, sameSite: 'Lax', path: '/'
    });
    await page.goto(target, { waitUntil: 'domcontentloaded' });
    await sleep(7_000);
  } finally {
    await browser.close();
  }
}

async function drainQueue() {
  if (busy || queue.length === 0) return;
  busy = true;
  const target = queue.shift();
  try {
    await visit(target);
    console.log(`visited ${target}`);
  } catch (error) {
    console.error(`visit failed: ${error.message}`);
  } finally {
    busy = false;
    void drainQueue();
  }
}

const server = http.createServer((request, response) => {
  if (request.method === 'GET' && request.url === '/health') {
    response.writeHead(200, { 'content-type': 'application/json' });
    return response.end(JSON.stringify({ ok: true, busy, queued: queue.length }));
  }
  if (request.method !== 'POST' || request.url !== '/visit') {
    response.writeHead(404); return response.end('not found');
  }
  let body = '';
  request.on('data', (chunk) => { body += chunk; });
  request.on('end', () => {
    try {
      const target = new URL(JSON.parse(body).url);
      if (!['http:', 'https:'].includes(target.protocol)) throw new Error('invalid scheme');
      queue.push(target.href);
      void drainQueue();
      response.writeHead(202, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ queued: true }));
    } catch (_) {
      response.writeHead(400, { 'content-type': 'application/json' });
      response.end(JSON.stringify({ error: 'invalid url' }));
    }
  });
});

server.listen(port, '0.0.0.0', () => console.log(`bot listening on ${port}`));
