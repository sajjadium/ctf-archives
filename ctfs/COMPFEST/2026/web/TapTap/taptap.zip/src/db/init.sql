CREATE EXTENSION IF NOT EXISTS pgcrypto;
REVOKE CREATE ON SCHEMA public FROM PUBLIC;

CREATE ROLE auth_owner NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE editor NOLOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE player LOGIN PASSWORD :'player_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE game_writer LOGIN PASSWORD :'game_writer_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE forum_writer LOGIN PASSWORD :'forum_writer_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE auth_reader LOGIN PASSWORD :'auth_reader_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
CREATE ROLE registration_writer LOGIN PASSWORD :'registration_writer_pw' NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;

CREATE SCHEMA auth AUTHORIZATION auth_owner;
SET ROLE auth_owner;
CREATE TABLE auth.users (
    id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    username text NOT NULL UNIQUE CHECK (username ~ '^[a-z0-9_]{3,24}$'),
    password_hash text NOT NULL
);
INSERT INTO auth.users (username, password_hash) VALUES
    ('admin', crypt(:'flag', gen_salt('bf', 12))),
    ('player', crypt(:'player_password', gen_salt('bf', 12)));
RESET ROLE;

CREATE SCHEMA game AUTHORIZATION editor;
SET ROLE editor;
CREATE TABLE game.powerups (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name text NOT NULL,
    description text NOT NULL,
    asset text NOT NULL,
    price integer NOT NULL CHECK (price >= 0),
    multiplier integer NOT NULL CHECK (multiplier > 0)
);
CREATE TABLE game.forum_posts (
    id integer GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    title text NOT NULL,
    content text NOT NULL,
    author_name text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE game.profiles (
    username text PRIMARY KEY,
    taps bigint NOT NULL DEFAULT 0 CHECK (taps >= 0),
    coins bigint NOT NULL DEFAULT 0 CHECK (coins >= 0)
);
CREATE TABLE game.inventory (
    username text NOT NULL,
    powerup_id integer NOT NULL REFERENCES game.powerups(id),
    quantity integer NOT NULL DEFAULT 0 CHECK (quantity >= 0),
    PRIMARY KEY (username, powerup_id)
);

INSERT INTO game.powerups (name, description, asset, price, multiplier) VALUES
    ('Paw Punch', 'A paw strike that makes each tap feel faster.', 'paw-punch.png', 40, 2),
    ('Lucky Bell', 'A lucky bell for your daily coin collection.', 'lucky-bell.png', 75, 3),
    ('Pixel Drum', 'A mini bongo for players who love combos.', 'pixel-drum.png', 120, 5),
    ('Cosmic Treat', 'A galactic snack for explosive streaks.', 'cosmic-treat.png', 240, 8),
    ('Combo Clover', 'A paw clover that keeps combos going longer.', 'combo-clover.png', 360, 10),
    ('Turbo Tuna', 'A rocket tuna for the next tapping session.', 'turbo-tuna.png', 540, 13),
    ('Moon Mochi', 'Moon mochi for a coin bonus after resting.', 'moon-mochi.png', 780, 16),
    ('Prism Paws', 'A rare paw crystal for sparkling taps.', 'prism-paws.png', 1100, 20);
INSERT INTO game.forum_posts (title, content, author_name) VALUES
    ('Welcome to TapTap Arena!', 'Tap Bongo to collect coins, then find a power-up in Shop.', 'moderator'),
    ('Weekend tournament', 'This week’s top 10 tappers earn a special purple badge.', 'moderator');
INSERT INTO game.profiles (username, taps, coins) VALUES
    ('player', 0, 250),
    ('admin', 0, 250);
RESET ROLE;

CREATE SCHEMA player AUTHORIZATION player;

GRANT SELECT (id, username, password_hash) ON auth.users TO auth_reader;
GRANT INSERT (username, password_hash) ON auth.users TO registration_writer;
GRANT USAGE ON SEQUENCE auth.users_id_seq TO registration_writer;

GRANT USAGE ON SCHEMA game TO player, game_writer, forum_writer, registration_writer;
REVOKE ALL ON game.forum_posts FROM PUBLIC, player, game_writer, registration_writer;
REVOKE ALL ON SEQUENCE game.forum_posts_id_seq FROM PUBLIC, player, game_writer, registration_writer;
GRANT SELECT ON game.powerups, game.forum_posts TO player;
GRANT REFERENCES (id) ON game.powerups TO player;
GRANT INSERT (title, content, author_name) ON game.forum_posts TO forum_writer;
GRANT USAGE ON SEQUENCE game.forum_posts_id_seq TO forum_writer;

GRANT SELECT ON game.powerups, game.profiles, game.inventory TO game_writer;
GRANT UPDATE (taps, coins) ON game.profiles TO game_writer;
GRANT INSERT, UPDATE (quantity) ON game.inventory TO game_writer;
GRANT INSERT (username) ON game.profiles TO registration_writer;

GRANT USAGE ON SCHEMA player TO editor;

REVOKE ALL ON SCHEMA auth FROM PUBLIC, player, editor, game_writer, forum_writer, registration_writer;
GRANT USAGE ON SCHEMA auth TO auth_reader, registration_writer;
