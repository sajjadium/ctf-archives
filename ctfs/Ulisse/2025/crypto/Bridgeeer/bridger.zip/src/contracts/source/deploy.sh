#!/bin/sh
forge script script/Signer.s.sol --rpc-url $1 --private-key $ETH_PRIVATE_KEY --broadcast
