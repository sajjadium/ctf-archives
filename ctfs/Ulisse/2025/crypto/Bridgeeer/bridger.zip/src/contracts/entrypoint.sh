#!/bin/bash

curl -L https://foundry.paradigm.xyz | bash
export PATH="$HOME/.foundry/bin:$PATH"
~/.foundry/bin/foundryup

cd /app/source

./deploy.sh http://anvil-signer:8545

exit
