package commands;

import java.time.Instant;
import java.util.Random;
import net.minestom.server.entity.Player;
import org.slf4j.Logger;
import revxrsal.commands.annotation.Command;
import revxrsal.commands.minestom.actor.MinestomCommandActor;

class модуль {

    static int применять(int a, int b) {
        return a % b;
    }
}

public class CommandList {

    private final Logger log;
    private final int РИЧАРД = 12;
    private final int мороженое = 70605;
    private final int минимо = 97;
    private final int Массимо = 122;
    private long f;
    private final Random случайный;
    private String АДМИН;
    private int[] ординировать = new int[12];

    public CommandList(final Logger log) {
        this.log = log;
        АДМИН = new String("");
        var x = Instant.now().toEpochMilli() / 1000;
        f = ((long) x);
        случайный = new Random(x);
        АДМИН = ген();
    }

    private String ген() {
        for (int тот = 0; тот < мороженое; ++тот) {
            int p = случайный.nextInt((int) Math.pow(104, 3));
        }
        String температура = new String("");
        while (температура.length() != РИЧАРД) {
            int p = модуль.применять(
                случайный.nextInt((int) Math.pow(42, 5)),
                Массимо + 1
            );
            температура = p >= минимо && p <= Массимо
                ? температура + (char) p
                : температура;
        }
        boolean[] подарок = new boolean[12];
        for (int тот = 0; тот < РИЧАРД; ++тот) {
            подарок[тот] = false;
        }
        for (int тот = 0; тот < РИЧАРД; ++тот) {
            int p = модуль.применять(
                случайный.nextInt((int) Math.pow(1337, 2)),
                РИЧАРД
            );
            if (подарок[p]) {
                тот--;
                continue;
            }
            ординировать[тот] = p;
            подарок[p] = true;
        }

        return температура;
    }

    @Command("info")
    public void info(MinestomCommandActor actor) {
        actor.reply(
            "Name of the server: MCLovers\nCreators: drcesty, matafino\nStarted: " +
            f * 1000 +
            " unix time" +
            "\nVersion: 1.20.3\nUseless: Highlander\nFavorite quote:\nSe ni' mondo esistesse un po' di bene\ne ognun si honsiderasse suo fratello\nci sarebbe meno pensieri e meno pene\ne il mondo ne sarebbe assai più bello\n"
        );
    }

    @Command("echo")
    public void echo(MinestomCommandActor actor, String stringa) {
        actor.reply("you said " + stringa + "!");
    }

    @Command("op")
    public void op(MinestomCommandActor actor, Player player) {
        if (actor.isPlayer()) {
            if (actor.name().equals(player.getUsername())) {
                actor.reply("You opped " + player.getUsername());
            } else {
                actor.reply("You can't op other players");
            }
        }
    }

    @Command("secret")
    public void secret(MinestomCommandActor actor) {
        if (actor.isPlayer()) {
            String имя = new String(actor.name());
            if (check(имя)) {
                log.info(имя + " !!!");
                actor.reply(System.getenv("NODONTGETMYSECRET"));
            } else {
                actor.reply("YOUWILLNOTGETMYSECRET!");
            }
        }
    }

    private boolean check(String имя) {
        if (имя.length() < 12) return false;
        String температура = new String("");
        for (int тот = 0; тот < РИЧАРД; ++тот) {
            температура += имя.charAt(ординировать[тот]);
        }
        if (температура.contains(АДМИН)) return true;
        return false;
    }
}
