#!/bin/sh

# Load admin password from environment variable
ADMIN_PASSWORD=${ADMIN_PASSWORD:-default_password}

# MySQL Command
echo "
INSERT INTO USERS (id, username, password)
VALUES (UUID(), 'admin', '${ADMIN_AUTH_TOKEN}')
ON DUPLICATE KEY UPDATE password=VALUES(password);
" | mysql -u root -p"$MYSQL_ROOT_PASSWORD" -D chall && echo "Admin user initialized."

