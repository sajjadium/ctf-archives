package main

import (
	"gin-mvc/client"
	"gin-mvc/router"

	"github.com/robfig/cron"
)

func main() {
	// run bot every minute
	cron := cron.New()
	cron.AddFunc("0 * * * * *", func() {
		client.CheckProducts()
	})
	cron.Start()

	r := router.InitRouter()
	r.Run()
}
