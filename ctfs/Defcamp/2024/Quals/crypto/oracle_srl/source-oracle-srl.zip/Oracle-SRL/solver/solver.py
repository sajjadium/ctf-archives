#!/usr/bin/env python3
from pwn import *
import json
from requests import *
import requests

BLOCK_SIZE = 16


def oracle(iv, ct_block, r: Session):
    ciphertext = iv + ct_block
    print(ciphertext)

    result = requests.get("http://localhost:8080/", cookies={"session_token": ciphertext.hex()})
    # print(result.url)

    return 'invalid%20padding' not in result.url

def single_block_attack(block, r):
    """Returns the decryption of the given ciphertext block"""

    # zeroing_iv starts out nulled. each iteration of the main loop will add
    # one byte to it, working from right to left, until it is fully populated,
    # at which point it contains the result of DEC(ct_block)
    zeroing_iv = [0] * BLOCK_SIZE

    for pad_val in range(1, BLOCK_SIZE+1):
        padding_iv = [pad_val ^ b for b in zeroing_iv]

        for candidate in range(256):
            padding_iv[-pad_val] = candidate
            iv = bytes(padding_iv)
            if oracle(iv, block, r):
                if pad_val == 1:
                    # make sure the padding really is of length 1 by changing
                    # the penultimate block and querying the oracle again
                    padding_iv[-2] ^= 1
                    iv = bytes(padding_iv)
                    if not oracle(iv, block, r):
                        continue  # false positive; keep searching
                break
        else:
            this = xor(padding_iv, _iv)
            print(xor(this, ciphertext))
            raise Exception("no valid padding byte found (is the oracle working correctly?)")

        zeroing_iv[-pad_val] = candidate ^ pad_val

    return zeroing_iv


def full_attack(iv, ct, r):
    """Given the iv, ciphertext, and a padding oracle, finds and returns the plaintext"""
    assert len(iv) == BLOCK_SIZE and len(ct) % BLOCK_SIZE == 0

    msg = iv + ct
    blocks = [msg[i:i+BLOCK_SIZE] for i in range(0, len(msg), BLOCK_SIZE)]
    result = b''

    # loop over pairs of consecutive blocks performing CBC decryption on them
    iv = blocks[0]
    for ct in blocks[1:]:
        dec = single_block_attack(ct, r)
        pt = bytes(iv_byte ^ dec_byte for iv_byte, dec_byte in zip(iv, dec))
        # pt = xor(iv, dec)
        result += pt
        print(result)
        iv = ct

    return result

_iv = ""
if __name__ == '__main__':

    cipher = "a18ff65cf07aa8bedc0734f3e16a84bd77f7cf0344580acb3fab71ffb7e28f9cb8b899d73eec276dfdc87dbdcd0a99b4ea8652c588369f79b8a423afe552d0713e38528750035f18fb194f51ac9a40e69fddd724f9d7afe4209746aed348c6ff2e26c371f7bb3eef96f768e09a56fd9bbb9bed3e0df5bd86ae899e35b1622f6c"

    r = Session()

    iv = bytes.fromhex(cipher[:32])
    _iv = iv
    ciphertext = bytes.fromhex(cipher[32:])

    pt = full_attack(iv, ciphertext, r)
    print(pt.decode())
