package models

import (
	"time"

	"gorm.io/gorm"
)

type Account struct {
	gorm.Model
	ID        uint       `gorm:"primaryKey;autoIncrement"`
	Name      string     `gorm:"not null;size:255"`
	Email     string     `gorm:"not null;unique;size:255"`
	Password  string     `gorm:"not null;size:255"` // This should be hashed
	CreatedAt time.Time  `gorm:"autoCreateTime"`
	UpdatedAt time.Time  `gorm:"autoCreateTime;autoUpdateTime"`
	DeletedAt *time.Time `gorm:"index"`
}

// CreateAccount creates a new account in the database
func CreateAccount(db *gorm.DB, account *Account) error {
	return db.Create(account).Error
}

// GetAccountByEmail retrieves an account by email from the database
func GetAccountByEmail(db *gorm.DB, email string) (*Account, error) {
	var account Account
	if err := db.Where("email = ?", email).First(&account).Error; err != nil {
		return nil, err
	}
	return &account, nil
}

// DeleteAccount soft deletes an account from the database
func DeleteAccount(db *gorm.DB, account *Account) error {
	return db.Delete(account).Error
}
