pub const UMA_PER_ROUND: usize = 16;
pub const ROUNDS_REQUIRED: usize = 50;
pub const TREE_DEPTH: usize = 4;
pub const RACE_DISTANCE_MIN: u32 = 1200;
pub const RACE_DISTANCE_MAX: u32 = 3200;
