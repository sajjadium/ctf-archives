#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Type definitions
typedef unsigned int Event_size_t;
typedef unsigned int Event_type_t;
typedef struct Event Event_t;
typedef struct User User_t;
typedef struct Msg Msg_t;

// App structures
struct Event {
    Event_type_t type;    // Type of event
    Event_size_t size;    // Size of event data
    char * data;        // Pointer to event data
};

struct User {
    char username[0x20];
    char password[0x20];
    unsigned int logged_in;
    unsigned int vip;
    char * details;
};

struct Msg {
    char from[0x20];
    char to[0x20];
    unsigned int msg_size;
    char * msg;
};