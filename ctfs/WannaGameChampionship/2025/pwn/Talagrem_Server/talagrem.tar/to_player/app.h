#include "app_structs.h"

// Event constants
#define MAGIC               0xbeef1337
#define EVENT_MAX_SIZE      0x300
#define DETAILS_MAX_SIZE    0x200
#define MESSAGE_MAX_SIZE    0x200

// Event categories
#define SERVER_EVENT         0x1000
#define CLIENT_EVENT         0x2000

// Server events
#define SERVER_FORWARD_MSG          0x0001
#define SERVER_RETURN_DETAILS       0x0002

// Client events
#define CLIENT_REGISTER         0x0001
#define CLIENT_LOGIN            0x0002
#define CLIENT_GET_DETAILS      0x0003
#define CLIENT_UPDATE_DETAILS   0x0004
#define CLIENT_DELETE_ACCOUNT   0x0005
#define CLIENT_SEND_MSG         0x0006

// Buffer mode
#define DEF_BUFFER          0x0010
#define VIP_BUFFER          0x0020

// Return values
#define INVALID_POINTER     -0x0001
#define INVALID_SIZE        -0x0002
#define INVALID_MAGIC       -0x0003
#define INVALID_EVENT_TYPE  -0x0004
#define SERIALIZATION_ERROR -0x0005

// Macros for event type extraction
#define event_type(type)    (type & 0x000F)
#define buffer_mode(type)   ((type >> 4) & 0x000F) << 4
#define debug_mode(type)    ((type >> 8) & 0x000F) << 8
#define event_cat(type)     ((type >> 12) & 0x000F) << 12

// Function prototypes
int event_to_buff(Event_t * event, char * buffer);
int buff_to_event(char * buffer, Event_t * event);
int user_to_buff(User_t * user, char * buffer);
int buff_to_user(char * buffer, User_t * user);
int msg_to_buff(Msg_t * msg, char * buffer);
int buff_to_msg(char * buffer, Msg_t * msg);

int event_to_buff(Event_t * event, char * buffer) {
    if(buffer == NULL || event == NULL) {
        perror("Invalid buffer or event pointer");
        return INVALID_POINTER;
    }

    // Allocate memory for event data based on buffer mode
    switch(buffer_mode(event->type)) {
        case DEF_BUFFER:
            if (event->size > EVENT_MAX_SIZE) {
                perror("Event size exceeds maximum limit for DEF user");
                return INVALID_SIZE;
            }
            break;
        case VIP_BUFFER:
            if (event->size > EVENT_MAX_SIZE * 2) {
                perror("Event size exceeds maximum limit for VIP user");
                return INVALID_SIZE;
            }
            break;
        default:
            perror("Invalid buffer mode");
            return INVALID_EVENT_TYPE;
    }

    // Serialize the event structure into a buffer
    memcpy(buffer, &event->type, sizeof(Event_type_t));
    memcpy(buffer + sizeof(Event_type_t), &event->size, sizeof(Event_size_t));
    memcpy(buffer + sizeof(Event_type_t) + sizeof(Event_size_t), event->data, event->size);
    return 0;
}

int buff_to_event(char * buffer, Event_t * event) {
    if(buffer == NULL || event == NULL) {
        perror("Invalid buffer or event pointer");
        return INVALID_POINTER;
    }
    
    // Allocate memory for event data based on buffer mode
    unsigned int size = *((Event_size_t *)(buffer + sizeof(Event_type_t)));
    switch(buffer_mode(*((Event_type_t *)buffer))) {
        case DEF_BUFFER:
            if (size > EVENT_MAX_SIZE) {
                perror("Event size exceeds maximum limit for DEF user");
                return INVALID_SIZE;
            }
            event->data = (char *)malloc(size + 0x10);
            if (event->data == NULL) {
                perror("Memory allocation failed");
                return SERIALIZATION_ERROR;
            }
            memset(event->data, 0, size + 0x10);
            break;
        case VIP_BUFFER:
            if (size > EVENT_MAX_SIZE * 2) {
                perror("Event size exceeds maximum limit for VIP user");
                return INVALID_SIZE;
            }
            event->data = (char *)malloc(size + 0x10);
            if (event->data == NULL) {
                perror("Memory allocation failed");
                return SERIALIZATION_ERROR;
            }
            memset(event->data, 0, size + 0x10);
            break;
        default:
            perror("Invalid buffer mode");
            return INVALID_EVENT_TYPE;
    }
    // Deserialize the buffer into an event structure
    memcpy(&event->type, buffer, sizeof(Event_type_t));
    memcpy(&event->size, buffer + sizeof(Event_type_t), sizeof(Event_size_t));
    memcpy(event->data, buffer + sizeof(Event_type_t) + sizeof(Event_size_t), event->size);
    return 0;
}

int user_to_buff(User_t * user, char * buffer) {
    if(buffer == NULL || user == NULL) {
        perror("Invalid buffer or user pointer");
        return INVALID_POINTER;
    }
    // Serialize the user structure into a buffer
    memcpy(buffer, &user->username, sizeof(user->username));
    memcpy(buffer + sizeof(user->username), &user->password, sizeof(user->password));
    memcpy(buffer + sizeof(user->username) + sizeof(user->password), &user->logged_in, sizeof(user->logged_in));
    memcpy(buffer + sizeof(user->username) + sizeof(user->password) + sizeof(user->logged_in), &user->vip, sizeof(user->vip));
    return 0;
}

int buff_to_user(char * buffer, User_t * user) {
    if(buffer == NULL || user == NULL) {
        perror("Invalid buffer or user pointer");
        return INVALID_POINTER;
    }
    
    // Deserialize the buffer into a user structure
    memcpy(&user->username, buffer, sizeof(user->username));
    memcpy(&user->password, buffer + sizeof(user->username), sizeof(user->password));
    memcpy(&user->logged_in, buffer + sizeof(user->username) + sizeof(user->password), sizeof(user->logged_in));
    memcpy(&user->vip, buffer + sizeof(user->username) + sizeof(user->password) + sizeof(user->logged_in), sizeof(user->vip));
    user->details = NULL;
    return 0;
}

/*
This function only used by app - please make sure buffer size is enough for msg->size
*/
int msg_to_buff(Msg_t * msg, char * buffer) {
    if(buffer == NULL || msg == NULL) {
        perror("Invalid buffer or msg pointer");
        return INVALID_POINTER;
    }
    // Serialize the msg structure into a buffer
    memcpy(buffer, &msg->from, sizeof(msg->from));
    memcpy(buffer + sizeof(msg->from), &msg->to, sizeof(msg->to));
    memcpy(buffer + sizeof(msg->from) + sizeof(msg->to), &msg->msg_size, sizeof(msg->msg_size));
    memcpy(buffer + sizeof(msg->from) + sizeof(msg->to) + sizeof(msg->msg_size), msg->msg, msg->msg_size);
    return 0;
}

/*
Might be heap read overflow here but not a problem if there is no writer
*/
int buff_to_msg(char * buffer, Msg_t * msg) {
    if(buffer == NULL || msg == NULL) {
        perror("Invalid buffer or msg pointer");
        return INVALID_POINTER;
    }
    
    // Deserialize the buffer into a msg structure
    memcpy(&msg->from, buffer, sizeof(msg->from));
    memcpy(&msg->to, buffer + sizeof(msg->from), sizeof(msg->to));
    memcpy(&msg->msg_size, buffer + sizeof(msg->from) + sizeof(msg->to), sizeof(msg->msg_size));
    
    if (msg->msg_size > MESSAGE_MAX_SIZE * 2) {
        printf("Exceeding size: %u\n", msg->msg_size);
        perror("Message size exceeds maximum limit");
        return INVALID_SIZE;
    }

    msg->msg = (char *)malloc(msg->msg_size + 0x10);
    if (msg->msg == NULL) {
        perror("Memory allocation failed");
        return SERIALIZATION_ERROR;
    }
    memcpy(msg->msg, buffer + sizeof(msg->from) + sizeof(msg->to) + sizeof(msg->msg_size), msg->msg_size);
    return 0;
}