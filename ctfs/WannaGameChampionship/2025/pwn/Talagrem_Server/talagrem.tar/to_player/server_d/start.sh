#!/bin/sh
while true
do
./server $PORT $SECRET ;
echo "Server exit with exit code $?.  Respawning..." >&2 ;
sleep 10 ;
done