#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "app.h"

typedef struct Users_list Users_list_t;
typedef struct Client Client_t;

struct Client {
    int fd;
    pthread_t thread_id;
    int connected;
    User_t * user;
};

struct Users_list {
    Users_list_t * next;
    User_t * user;
};

Client_t clients[0x100];
User_t bot_user = {0};
Users_list_t * users;

int read_from_client(int fd, char * buffer, size_t size);
int send_to_client(int fd, char * buffer, size_t size);
int read_event_from_client(int fd, Event_t * event);
int send_event_to_client(int fd, Event_t * event);

int read_from_client(int fd, char * buffer, size_t size)
{
    int offset = 0;
    while(offset < size)
    {
        int bytes_read = recv(fd, buffer + offset, size - offset, 0);
        if(bytes_read < 0)
        {
            if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                usleep(1000);
                continue;
            }
            perror("recv");
            close(fd);
            return EXIT_FAILURE;
        }
        offset += bytes_read;
    }
    return 0;
}

int send_to_client(int fd, char * buffer, size_t size)
{
    int offset = 0;
    while(offset < size)
    {
        int bytes_sent = send(fd, buffer + offset, size - offset, 0);
        if(bytes_sent < 0)
        {
            if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                usleep(1000);
                continue;
            }
            perror("send");
            close(fd);
            return EXIT_FAILURE;
        }
        offset += bytes_sent;
    }
    return 0;
}

int read_event_from_client(int fd, Event_t * event)
{
    unsigned int magic = 0;
    if (read_from_client(fd, &magic, 4) || magic != MAGIC)
    {
        perror("Failed to recv magic from client");
        close(fd);
        return EXIT_FAILURE;
    }
    unsigned int size = 0;
    if (read_from_client(fd, &size, 4))
    {
        perror("Failed to recv size from client");
        close(fd);
        return EXIT_FAILURE;
    }

    char * buffer = (char *)malloc(size + 0x10);
    memset(buffer, 0, size + 0x10);

    if (read_from_client(fd, buffer, size))
    {
        perror("Failed to recv event data from client");
        free(buffer);
        close(fd);
        return EXIT_FAILURE;
    }

    if(buff_to_event(buffer, event))
    {
        perror("Malicious payload detected");
        free(buffer);
        close(fd);
        return EXIT_FAILURE;
    }
    free(buffer);
    return 0;
}

int send_event_to_client(int fd, Event_t * event)
{
    unsigned int size = sizeof(unsigned int) * 2 + sizeof(Event_type_t) + sizeof(Event_size_t) + event->size;
    char * buffer = (char *)malloc(size + 0x10);
    memset(buffer, 0, size + 0x10);
    if (event_to_buff(event, buffer + sizeof(unsigned int) * 2))
    {
        perror("Failed to serialize event");
        free(buffer);
        return EXIT_FAILURE;
    }
    *(unsigned int *)(buffer) = MAGIC;
    *(unsigned int *)(buffer + sizeof(unsigned int)) = size - sizeof(unsigned int) * 2;

    if (send_to_client(fd, buffer, size))
    {
        perror("Failed to send event data to client");
        free(buffer);
        return EXIT_FAILURE;
    }
    free(buffer);
    return 0;
}