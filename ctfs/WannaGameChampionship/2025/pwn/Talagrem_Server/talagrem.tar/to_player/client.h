#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <semaphore.h>
#include "app.h"

#define MODE(x) ((x) | (current_user.logged_in << 4))

#define REGISTER        0x0001
#define LOGIN           0x0002
#define BUY_VIP         0x0003

#define VIEW_DETAILS    0x0011
#define UPDATE_DETAILS  0x0012
#define VIEW_INBOX      0x0013
#define LOGOUT          0x0014

#define MAX_INBOX_MSGS  0x10

typedef struct Inbox Inbox_t;

struct Inbox
{
    Inbox_t * next;
    char name[0x20];
    Msg_t ** messages;
    unsigned long msg_count;
};

int sockfd = -1;
int current_vip = 0;
User_t current_user = (User_t){0};
char bot_cred[0x20] = {0};
Inbox_t * inbox_head = NULL;
sem_t mutex;
pthread_t worker_thread;

int read_from_server(char * buffer, size_t size);
int send_to_server(char * buffer, size_t size);
int read_event_from_server(Event_t * event);
int send_event_to_server(Event_t * event);
Inbox_t * find_inbox(char * name);
void clean_inbox();
int create_inbox(char * name);
int delete_inbox(char * name);
int register_account(char * username, char * password);
int login(char * username, char * password);
int get_details(char * details);
Msg_t * send_message(char * message, char * from, char * to, unsigned int size);
void push_msg(Inbox_t * inbox, Msg_t * msg);
void pop_msg(Inbox_t * inbox);

int read_from_server(char * buffer, size_t size)
{
    int offset = 0;
    while(offset < size)
    {
        int bytes_read = recv(sockfd, buffer + offset, size - offset, 0);
        if(bytes_read < 0)
        {
            if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                usleep(1000);
                continue;
            }
            perror("recv");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        offset += bytes_read;
    }
    return 0;
}

int send_to_server(char * buffer, size_t size)
{
    int offset = 0;
    while(offset < size)
    {
        int bytes_sent = send(sockfd, buffer + offset, size - offset, 0);
        if(bytes_sent < 0)
        {
            if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                usleep(1000);
                continue;
            }
            perror("send");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        offset += bytes_sent;
    }
    return 0;
}

int read_event_from_server(Event_t * event)
{
    unsigned int magic = 0;
    if (read_from_server(&magic, 4) || magic != MAGIC)
    {
        perror("Failed to recv magic from server");
        close(sockfd);
        return EXIT_FAILURE;
    }
    unsigned int size = 0;
    if (read_from_server(&size, 4))
    {
        perror("Failed to recv size from server");
        close(sockfd);
        return EXIT_FAILURE;
    }
    char * buffer = (char *)malloc(size + 0x10);
    memset(buffer, 0, size + 0x10);
    if (read_from_server(buffer, size))
    {
        perror("Failed to recv event data from server");
        free(buffer);
        close(sockfd);
        return EXIT_FAILURE;
    }

    if(buff_to_event(buffer, event))
    {
        perror("Malicious payload detected");
        free(buffer);
        close(sockfd);
        return EXIT_FAILURE;
    }
    
    free(buffer);
    return 0;
}

int send_event_to_server(Event_t * event)
{
    unsigned int size = sizeof(unsigned int) * 2 + sizeof(Event_type_t) + sizeof(Event_size_t) + event->size;
    char * buffer = (char *)malloc(size + 0x10);
    memset(buffer, 0, size + 0x10);

    if (event_to_buff(event, buffer + sizeof(unsigned int) * 2))
    {
        perror("Failed to serialize event");
        free(buffer);
        close(sockfd);
        return EXIT_FAILURE;
    }

    *(unsigned int *)(buffer) = MAGIC;
    *(unsigned int *)(buffer + sizeof(unsigned int)) = size - sizeof(unsigned int) * 2;

    if (send_to_server(buffer, size))
    {
        perror("Failed to send event data to server");
        free(buffer);
        close(sockfd);
        return EXIT_FAILURE;
    }
    free(buffer);
    return 0;
}

Inbox_t * find_inbox(char * name)
{
    Inbox_t * current = inbox_head;
    while (current)
    {
        if (strncmp(current->name, name, 0x20) == 0)
            return current;
        current = current->next;
    }
    return NULL;
}

void clean_inbox()
{
    Inbox_t * current = inbox_head;
    while (current)
    {
        for (unsigned int i = 0; i < current->msg_count; i++)
        {
            if(current->messages[i] == NULL)
                continue;
            free(current->messages[i]->msg);
            free(current->messages[i]);
        }
        free(current->messages);
        Inbox_t * temp = current;
        current = current->next;
        free(temp);
    }
}

int create_inbox(char * name)
{
    Inbox_t * new_inbox = malloc(sizeof(Inbox_t));
    memset(new_inbox, 0, sizeof(Inbox_t));
    strncpy(new_inbox->name, name, 0x20);
    new_inbox->messages = malloc(sizeof(Msg_t *) * MAX_INBOX_MSGS);
    memset(new_inbox->messages, 0, sizeof(Msg_t *) * MAX_INBOX_MSGS);
    if (new_inbox->messages == NULL)
    {
        free(new_inbox);
        return EXIT_FAILURE;
    }
    new_inbox->msg_count = 0;
    new_inbox->next = inbox_head;
    inbox_head = new_inbox;
    printf("New inbox %s created.\n", name);
    return 0;
}

int delete_inbox(char * name)
{
    Inbox_t * current = inbox_head;
    Inbox_t * prev = NULL;
    while (current)
    {
        if (strncmp(current->name, name, 0x20) == 0)
        {
            if (prev)
                prev->next = current->next;
            else
                inbox_head = current->next;
            for (unsigned int i = 0; i < current->msg_count; i++)
            {
                if(current->messages[i] == NULL)
                    continue;
                free(current->messages[i]->msg);
                free(current->messages[i]);
            }
            free(current->messages);
            free(current);
            return 0;
        }
        prev = current;
        current = current->next;
    }
    return EXIT_FAILURE;
}

int register_account(char * username, char * password)
{
    username[strcspn(username, "\n")] = 0;
    password[strcspn(password, "\n")] = 0;
    User_t user = (User_t){0};
    memset(&user, 0, sizeof(User_t));
    strncpy(user.username, username, 0x20);
    strncpy(user.password, password, 0x20);
    user.logged_in = 0;
    user.details = NULL;
    user.vip = current_vip;
    Event_t register_event = {0};
    register_event.type = CLIENT_EVENT | CLIENT_REGISTER | (current_vip ? VIP_BUFFER : DEF_BUFFER);
    register_event.size = sizeof(User_t);
    register_event.data = (char *)&user;
    if(send_event_to_server(&register_event))
    {
        puts("Failed to send register event to server");
        close(sockfd);
        return EXIT_FAILURE;
    }
    return 0;
}

int login(char * username, char * password)
{
    username[strcspn(username, "\n")] = 0;
    password[strcspn(password, "\n")] = 0;
    User_t user = (User_t){0};
    memset(&user, 0, sizeof(User_t));
    strncpy(user.username, username, 0x20);
    strncpy(user.password, password, 0x20);
    user.logged_in = 1;
    user.vip = current_vip;
    user.details = NULL;
    Event_t login_event = {0};
    login_event.type = CLIENT_EVENT | CLIENT_LOGIN | (current_vip ? VIP_BUFFER : DEF_BUFFER);
    login_event.size = sizeof(User_t);
    login_event.data = (char *)&user;
    if (send_event_to_server(&login_event))
    {
        puts("Failed to send login event to server");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    current_user = user;
    current_user.details = (char *)malloc(DETAILS_MAX_SIZE + 0x10);
    memset(current_user.details, 0, DETAILS_MAX_SIZE + 0x10);
    return 0;
}

int get_details(char * details)
{
    Event_t get_details_event = {0};
    get_details_event.type = CLIENT_EVENT | CLIENT_GET_DETAILS | (current_user.vip ? VIP_BUFFER : DEF_BUFFER);
    get_details_event.size = 0;
    get_details_event.data = NULL;
    sem_wait(&mutex);
    if (send_event_to_server(&get_details_event))
    {
        puts("Failed to send get details event to server");
        close(sockfd);
        exit(EXIT_FAILURE); 
    }
    sem_wait(&mutex);
    strncpy(details, current_user.details, 0x100);
    sem_post(&mutex);
    return 0;
}

Msg_t * str_to_msg(char * message, char * from, char * to, unsigned int size)
{
    Msg_t * msg = malloc(sizeof(Msg_t));
    memset(msg, 0, sizeof(Msg_t));
    strncpy(msg->from, from, 0x20);
    strncpy(msg->to, to, 0x20);
    char * msg_content = malloc(size + 0x10);
    memset(msg_content, 0, size + 0x10);
    memcpy(msg_content, message, size);
    msg->msg = msg_content;
    msg->msg_size = size;
    return msg;
}

Msg_t * send_message(char * message, char * from, char * to, unsigned int size)
{   
    Msg_t * msg = str_to_msg(message, from, to, size);

    char * buffer = (char *)malloc(sizeof(Msg_t) - sizeof(char *) + msg->msg_size + 0x10);
    memset(buffer, 0, sizeof(Msg_t) - sizeof(char *) + msg->msg_size + 0x10);
    msg_to_buff(msg, buffer);

    Event_t send_msg_event = {0};
    send_msg_event.type = CLIENT_EVENT | CLIENT_SEND_MSG | (current_user.vip ? VIP_BUFFER : DEF_BUFFER);
    send_msg_event.size = sizeof(Msg_t) - sizeof(char *) + msg->msg_size;
    send_msg_event.data = buffer;

    if (send_event_to_server(&send_msg_event))
    {
        puts("Failed to send message event to server");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    free(buffer);
    return msg;
}

void push_msg(Inbox_t * inbox, Msg_t * msg)
{
    if(msg->msg_size != 0)
        inbox->messages[inbox->msg_count] = msg;
        inbox->msg_count++;
}

void pop_msg(Inbox_t * inbox)
{
    if (inbox->msg_count == 0)
        return;
    if (inbox->messages[inbox->msg_count - 1] == NULL)
        return;
    free(inbox->messages[inbox->msg_count - 1]->msg);
    free(inbox->messages[inbox->msg_count - 1]);
    inbox->messages[inbox->msg_count - 1] = NULL;
    inbox->msg_count--;
}