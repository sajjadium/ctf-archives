#include "server.h"

int setup_server(int port);
void handle_client(int index);
int handle_client_event(Event_t * event, int index);
Users_list_t * find_user(User_t * user);
int register_user(User_t * new_user);
int login_user(User_t * user, int index);
void cleanup_client();

int main(int argc, char *argv[]) 
{
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <port> [bot_id]\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    if (argc == 3)
    {
        printf("New bot with bot ID: %s\n", argv[2]);
        memset(&bot_user, 0, sizeof(User_t));
        snprintf(&bot_user.username, 0x20, "bot_%s", argv[2]);
        snprintf(&bot_user.password, 0x20, "bot_%s_pass", argv[2]);
        bot_user.vip = 1;
        bot_user.logged_in = 0;
        if (register_user(&bot_user))
        {
            printf("Failed to register bot user\n");
            exit(EXIT_FAILURE);
        }
    }
    
    int server_fd = setup_server(atoi(argv[1]));
    if (server_fd < 0) {
        perror("setup_server");
        exit(EXIT_FAILURE);
    }
    
    printf("Server is listening on port %s\n", argv[1]);

    while(1)
    {
        int client_fd = accept(server_fd, (struct sockaddr*)NULL, NULL);
        if(client_fd >= 0)
        {
            cleanup_client();
            int found = 0;
            for (int i = 0; i < 0x100; i++)
            {
                if(!clients[i].connected)
                {
                    clients[i].fd = client_fd;
                    clients[i].connected = 1;
                    pthread_create(&clients[i].thread_id, NULL, (void *(*)(void *))handle_client, i);
                    found = 1;
                    break;
                }
            }
            if (found)
                continue;
            send(client_fd, "Server is full. Try again later.\n", 33, 0);
            close(client_fd);
            usleep(1000);
            continue;
        }
        else
        {
            if(errno == EAGAIN || errno == EWOULDBLOCK)
            {
                usleep(1000);
                continue;
            }
            perror("accept");
        }
    }
}

int setup_server(int port)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    int server_fd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK, 0);
    struct sockaddr_in serv_addr = { .sin_family = AF_INET, .sin_addr = {.s_addr = htonl(INADDR_ANY)}, .sin_port = htons(port) };

    int yes = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes) == -1)
    {
        perror("setsockopt");
        return -1;
    }

    if (bind(server_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) != 0)
    {
        perror("bind");
        return -1;
    }
    if (listen(server_fd, 10) != 0)
    {
        perror("listen");
        return -1;
    }
    if (fcntl(server_fd, F_SETFL, fcntl(server_fd, F_GETFL, 0) | O_NONBLOCK) == -1)
    {
        perror("fcntl");
        return -1;
    }

    return server_fd;
}

void handle_client(int index)
{
    int client_fd = clients[index].fd;
    printf("Handling client on fd %d\n", client_fd);
    while(1)
    {
        Event_t event = {0};
        if (read_event_from_client(client_fd, &event))
        {
            printf("Failed to read client event on fd %d\n", client_fd);
            close(client_fd);
            clients[index].connected = 0;
            clients[index].fd = 0;
            return;
        }
        int err = handle_client_event(&event, index);
        free(event.data);
        event.data = NULL;
        usleep(1000);
        if (err)
            break;
        continue;
    }
    printf("Client on fd %d disconnected\n", client_fd);
    close(client_fd);
    clients[index].connected = 0;
    clients[index].fd = 0;
    return;
}

int handle_client_event(Event_t * event, int index)
{
    if (event_cat(event->type) == CLIENT_EVENT)
    {
        switch(event_type(event->type))
        {
            case CLIENT_REGISTER:
                User_t new_user;
                if (buff_to_user(event->data, &new_user))
                {
                    printf("Malicious payload detected in register event\n");
                    return EXIT_FAILURE;
                }
                if (register_user(&new_user))
                {
                    printf("Failed to register new user\n");
                    return EXIT_FAILURE;
                }
                break;
            case CLIENT_LOGIN:
                User_t user;
                if (buff_to_user(event->data, &user))
                {
                    printf("Malicious payload detected in login event\n");
                    return EXIT_FAILURE;
                }
                if(login_user(&user, index))
                {
                    printf("Failed to login user %s on fd %d\n", user.username, clients[index].fd); 
                    return EXIT_FAILURE;
                }
                break;
            case CLIENT_UPDATE_DETAILS:
                if (clients[index].user == NULL)
                {
                    printf("Unauthorized update details attempt\n");
                    return EXIT_FAILURE;
                }
                if (clients[index].user->details == NULL)
                    clients[index].user->details = (char *)malloc(DETAILS_MAX_SIZE + 0x10);
                memcpy(clients[index].user->details, event->data, event->size > DETAILS_MAX_SIZE ? DETAILS_MAX_SIZE : event->size);
                break;
            case CLIENT_GET_DETAILS:
                if (clients[index].user == NULL)
                {
                    printf("Unauthorized get details attempt\n");
                    return EXIT_FAILURE;
                }
                if (clients[index].user->details == NULL)
                {
                    printf("No details available for user\n");
                    return EXIT_FAILURE;
                }
                Event_t details_event = {0};
                details_event.type = SERVER_EVENT | SERVER_RETURN_DETAILS | (clients[index].user->vip ? VIP_BUFFER : DEF_BUFFER);
                details_event.size = DETAILS_MAX_SIZE;
                details_event.data = clients[index].user->details;
                if (send_event_to_client(clients[index].fd, &details_event))
                {
                    printf("Failed to send user details to client\n");
                    return EXIT_FAILURE;
                }
                break;
            case CLIENT_DELETE_ACCOUNT:
                if (clients[index].user == NULL)
                {
                    printf("Unauthorized delete account attempt\n");
                    return EXIT_FAILURE;
                }
                Users_list_t * prev = NULL;
                for (Users_list_t * curr = users; curr != NULL; curr = curr->next)
                    if (curr->user == clients[index].user)
                    {
                        if (prev == NULL)
                            users = curr->next;
                        else
                            prev->next = curr->next;
                        free(curr->user->details);
                        free(curr->user);
                        free(curr);
                        clients[index].user = NULL;
                        break;
                    }
                    else
                        prev = curr;
                break;
            case CLIENT_SEND_MSG:
                Msg_t tmp_msg = {0};
                if(buff_to_msg(event->data, &tmp_msg))
                {
                    printf("Malicious payload detected in send message event\n");
                    return EXIT_FAILURE;
                }
                for (int i = 0; i < 0x100; i++)
                {
                    if (clients[i].user && strcmp(clients[i].user->username, tmp_msg.to) == 0 && clients[i].user->logged_in)
                    {
                        Event_t forward_event = {0};
                        forward_event.type = SERVER_EVENT | SERVER_FORWARD_MSG | (clients[i].user->vip ? VIP_BUFFER : DEF_BUFFER);
                        forward_event.size = sizeof(Msg_t) - sizeof(char *) + tmp_msg.msg_size;
                        forward_event.data = event->data;
                        if (send_event_to_client(clients[i].fd, &forward_event))
                        {
                            printf("Failed to forward message to user %s\n", tmp_msg.to);
                            continue;
                        }
                        break;
                    }
                }
                break;
            default:
                return EXIT_FAILURE;
        }
    }
    else
        return EXIT_FAILURE;
    return 0;
}

Users_list_t * find_user(User_t * user)
{
    for (Users_list_t * curr = users; curr != NULL; curr = curr->next)
    {
        if (strcmp(curr->user->username, user->username) == 0 && strcmp(curr->user->password, user->password) == 0)
            return curr;    
    }
    return NULL;
}

int register_user(User_t * new_user)
{
    Users_list_t * new_node = find_user(new_user);
    if (new_node != NULL)
    {
        perror("User already exists");
        return EXIT_FAILURE;
    }
    new_node = (Users_list_t *)malloc(sizeof(Users_list_t));
    if (new_node == NULL)
    {
        perror("Memory allocation failed");
        return EXIT_FAILURE;
    }
    new_node->user = (User_t *)malloc(sizeof(User_t));
    if (new_node->user == NULL)
    {
        perror("Memory allocation failed");
        free(new_node);
        return EXIT_FAILURE;
    }
    memcpy(new_node->user, new_user, sizeof(User_t));
    new_node->user->logged_in = 0;
    new_node->user->details = NULL;
    new_node->next = users;
    users = new_node;
    printf("User %s registered successfully\n", new_user->username);
    return 0;
}

int login_user(User_t * user, int index)
{
    Users_list_t * found_user = find_user(user);
    if (found_user && (found_user->user->logged_in == 0 || found_user->user->vip == 1))
    {
        clients[index].user = found_user->user;
        clients[index].user->logged_in = 1;
        return 0;
    }
    printf("User %s login failed\n", user->username);
    printf("Password %s\n", user->password);
    return EXIT_FAILURE;
}

void cleanup_client()
{
    for (int i = 0; i < 0x100; i++)
        if(clients[i].fd && clients[i].connected && recv(clients[i].fd, NULL, 0, MSG_PEEK | MSG_DONTWAIT) && errno != EAGAIN && errno != EWOULDBLOCK)
        {
            printf("Cleaning up client on fd %d\n", clients[i].fd);
            close(clients[i].fd);
            clients[i].connected = 0;
            clients[i].fd = 0;
        }
}