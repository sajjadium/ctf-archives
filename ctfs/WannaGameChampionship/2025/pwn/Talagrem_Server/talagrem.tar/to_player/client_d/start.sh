#!/bin/sh
while true
do
./client $SERVER_ADDRESS $SERVER_PORT $SECRET ;
echo "Client exit with exit code $?.  Respawning..." >&2 ;
sleep 10 ;
done