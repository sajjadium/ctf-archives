#!/bin/sh
gcc -o ./client_d/client ./client.c -lpthread
gcc -o ./server_d/server ./server.c -lpthread

SECRET_HEX=$(head -c 8 /dev/urandom | xxd -p)
echo "SECRET_HEX=$SECRET_HEX" > .env

docker compose up --build