#include "client.h"

int init(char * addr, char * port);
void init_bot(char * bot_cred);
void user_mode();
void menu();
void Inboxing();
void active_bot();
void render_inboxes();
void render_inbox(Inbox_t * inbox);
void handle_server();
int handle_server_event(Event_t * event);
void get_param(char * input, char * output, unsigned int max_len);

int main(int argc, char *argv[])
{
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <server_ip> <server_port> [bot_id]\n", argv[0]);
        return 1;
    }

    if(init(argv[1], argv[2]))
    {
        puts("Failed to initialize client");
        return EXIT_FAILURE;
    }
    
    strncpy(bot_cred, argc >= 4 ? argv[3] : "", 0x20);

    if (argc >= 4)
        init_bot(bot_cred);
    pthread_create(&worker_thread, NULL, (void *)handle_server, NULL);
    user_mode();
}

int init(char * addr, char * port)
{
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    struct addrinfo hints, * res, * p;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;  // Use AF_INET for IPv4 addresses.
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(addr, port, &hints, &res)) {
        perror("getaddrinfo");
        exit(EXIT_FAILURE);
    }

    // Loop through the results and use the first one we can.
    struct sockaddr_in serv_addr;
    for (p = res; p != NULL; p = p->ai_next) {
        memcpy(&serv_addr, p->ai_addr, sizeof(struct sockaddr_in));
        break;
    }
    freeaddrinfo(res);

    // Now serv_addr.sin_addr contains the resolved IP address.
    char ip_str[INET_ADDRSTRLEN];
    if (!inet_ntop(AF_INET, &serv_addr.sin_addr, ip_str, sizeof(ip_str))) {
        perror("inet_ntop");
        exit(EXIT_FAILURE);
    }

    if (connect(sockfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)) < 0)
    {
        perror("connect");
        exit(EXIT_FAILURE);
    }

    sem_init(&mutex, 0, 1);

    return 0;
}

void active_bot()
{
    char bot_name[0x20] = {0};
    snprintf(bot_name, "bot_%s", bot_cred);
    Inbox_t * inbox = find_inbox(bot_name);
    if (inbox == NULL)
    {
        if (create_inbox(bot_name))
        {
            puts("Failed to create bot inbox");
            exit(EXIT_FAILURE);
        }
        inbox = find_inbox(bot_name);
    }
}

void init_bot(char * bot_cred)
{
    char username[0x20] = {0};
    char password[0x20] = {0};
    snprintf(username, 0x20, "bot_%s", bot_cred);
    snprintf(password, 0x20, "bot_%s_pass", bot_cred);
    if (login(username, password))
    {
        puts("Bot login failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    current_vip = 1;
    current_user.vip = 1;
    return;
}

void user_mode()
{
    while(1)
    {
        menu();
        int choice = 0;
        char username[0x20] = {0};
        char password[0x20] = {0};
        while(scanf("%d", &choice) == -1);
        switch(MODE(choice))
        {
            case REGISTER:
                printf("Username: ");
                scanf("%32s", username);
                printf("Password: ");
                scanf("%32s", password);
                if (register_account(username, password))
                {
                    puts("Registration failed");
                    close(sockfd);
                    exit(EXIT_FAILURE);
                }
                puts("Registration successful");
                break;
            case LOGIN:
                printf("Username: ");
                scanf("%32s", username);
                printf("Password: ");
                scanf("%32s", password);
                if (login(username, password))
                {
                    puts("Login failed");
                    close(sockfd);
                    exit(EXIT_FAILURE);
                }
                puts("Login successful");
                break;
            case BUY_VIP:
                puts("Implementing VIP purchase is not available at the moment.");
                break;
            case VIEW_DETAILS:
                if (!current_user.logged_in)
                {
                    puts("You must be logged in to view details.");
                    break;
                }
                get_details(current_user.details);
                printf("Your details: %s\n", current_user.details);
                break;
            case UPDATE_DETAILS:
                if (!current_user.logged_in)
                {
                    puts("You must be logged in to update details.");
                    break;
                }
                printf("Enter new details: ");
                read(0, current_user.details, DETAILS_MAX_SIZE);
                Event_t update_event = {0};
                update_event.type = CLIENT_EVENT | CLIENT_UPDATE_DETAILS | (current_vip ? DEF_BUFFER : VIP_BUFFER);
                update_event.size = strlen(current_user.details);
                update_event.data = current_user.details;
                if (send_event_to_server(&update_event))
                {
                    puts("Failed to send update details event to server");
                    close(sockfd);
                    exit(EXIT_FAILURE);
                }
                puts("Details updated successfully.");
                break;
            case VIEW_INBOX:
                Inboxing();
                break;
            case LOGOUT:
                current_user = (User_t){0};
                printf("User logged out.\n");
                if (current_vip)
                {
                    snprintf(username, 0x20, "bot_%s", bot_cred);
                    snprintf(password, 0x20, "bot_%s_pass", bot_cred);
                    if (login(username, password))
                    {
                        puts("Bot login failed");
                        close(sockfd);
                        exit(EXIT_FAILURE);
                    }
                }
                else
                    clean_inbox();
                puts("Logged out successfully.");
                break;
            default:
                puts("Invalid choice. Please try again.");
                break;
        }
    }
}

void menu()
{
    puts("TALAGREM");
    if (current_user.logged_in)
    {
        if (current_vip)
            printf("Welcome VIP user: %s\n", current_user.username);
            
        puts("1) View Details");
        puts("2) Update Details");
        puts("3) View inbox");
        puts("4) Log out");
    }
    else
    {
        puts("1) Register");
        puts("2) Login");
        puts("3) Buy VIP");
        puts("4) Exit");
    }
    printf(">> ");
}

void Inboxing()
{
    if (current_user.vip)
        active_bot();

    while(1)
    {
        render_inboxes();
        printf("!help for commands\n");
        printf(">> ");
        char command[0x300] = {0};
        char inbox_name[0x20] = {0};
        command[read(0, command, sizeof(command) - 1) - 1] = 0;
        if (strncmp(command, "!help", 5) == 0)
        {
            puts("Commands:");
            puts("  !help                           - Show this help message");
            puts("  !read <inbox_name>              - Read messages from the specified inbox");
            puts("  !send <inbox_name> <message>    - Send a message to the specified inbox");
            puts("  !new  <inbox_name>              - Create a new inbox of specified type");
            puts("  !delete <inbox_name>            - Delete the specified inbox");
            puts("  !exit                           - Exit inbox");
        }
        else if (strncmp(command, "!read ", 6) == 0)
        {
            get_param(command + 6, inbox_name, 0x20);
            render_inbox(find_inbox(inbox_name));
        }
        else if (strncmp(command, "!send ", 6) == 0)
        {
            char message[MESSAGE_MAX_SIZE * 2] = {0};
            get_param(command + 6, inbox_name, 0x20);
            strncpy(message, strstr(command + 6, inbox_name) + strlen(inbox_name) + 1, MESSAGE_MAX_SIZE * 2 - 1);
            Inbox_t * inbox = find_inbox(inbox_name);
            if (inbox == NULL)
            {
                puts("Inbox not found");
                continue;
            }
            Msg_t * msg = send_message(message, current_user.username, inbox->name, strlen(message));
            push_msg(inbox, msg);
            puts("Message sent successfully.");
        }
        else if (strncmp(command, "!new ", 5) == 0)
        {
            get_param(command + 5, inbox_name, 0x20);
            if (find_inbox(inbox_name))
            {
                puts("Inbox with this name already exists");
                continue;
            }
            if (create_inbox(inbox_name))
            {
                puts("Failed to create user inbox");
                continue;
            }
            puts("User inbox created successfully.");
        }
        else if (strncmp(command, "!delete ", 8) == 0)
        {
            char inbox_name[0x20] = {0};
            get_param(command + 8, inbox_name, 0x20);
            if (find_inbox(inbox_name) == NULL)
            {
                puts("Inbox not found");
                continue;
            }
            if (delete_inbox(inbox_name))
            {
                puts("Failed to delete inbox");
                continue;
            }
        }
        else if (strncmp(command, "!exit", 5) == 0)
        {
            break;
        }
        else
        {
            puts("Unknown command. Type !help for a list of commands.");
        }
    }
}

void render_inboxes()
{
    printf("+------------------ INBOX ------------------+\n");
    Inbox_t * current = inbox_head;
    for (int i = 0; i < MAX_INBOX_MSGS && current; i++, current = current->next)
    {
        printf("| %-40s  |\n", current->name);
        printf("|   %-40s|\n", current->msg_count && current->messages[current->msg_count - 1] ? current->messages[current->msg_count - 1]->msg : "(No messages)");
        printf("+-------------------------------------------+\n");
    }
    return;
}

void render_inbox(Inbox_t * inbox)
{
    if (inbox == NULL)
    {
        puts("Inbox not found");
        return;
    }
    printf("+ %-40s  +\n", inbox->name);
    for (unsigned int i = 0; i < inbox->msg_count; i++)
    {
        Msg_t * msg = inbox->messages[i];
        if(msg == NULL)
            continue;
        printf("| From: %-20s To: %-20s |\n", msg->from, msg->to);
        printf("| Message: %s |\n", msg->msg);
        printf("+-----------------------------------------------+\n");
    }
}

void handle_server()
{
    while(1)
    {
        Event_t event = {0};
        if(read_event_from_server(&event))
        {
            printf("Failed to read event from server\n");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
        int err = handle_server_event(&event);
        free(event.data);
        event.data = NULL;
        if (err)
        {
            printf("Error handling server event\n");
            close(sockfd);
            exit(EXIT_FAILURE);
        }
    }
}

int handle_server_event(Event_t * event)
{
    if (event_cat(event->type) == SERVER_EVENT)
    {
        switch(event_type(event->type))
        {
            case SERVER_RETURN_DETAILS:
                strncpy(current_user.details, event->data, DETAILS_MAX_SIZE);
                sem_post(&mutex);
                break;
            case SERVER_FORWARD_MSG:
                Msg_t * msg = malloc(sizeof(Msg_t));
                memset(msg, 0, sizeof(Msg_t));
                if(buff_to_msg(event->data, msg))
                {
                    puts("Failed to deserialize message from buffer");
                    free(msg);
                    return EXIT_FAILURE;
                }
                
                Inbox_t * inbox = find_inbox(msg->from);

                if (inbox == NULL)
                {
                    if(create_inbox(msg->from))
                    {
                        puts("Failed to create inbox for incoming message");
                        return EXIT_FAILURE;
                    }
                    inbox = find_inbox(msg->from);
                }

                push_msg(inbox, msg);

                if (strncmp(msg->from + 4, bot_cred, strlen(bot_cred)) == 0 || strncmp(msg->to + 4, bot_cred, strlen(bot_cred)) == 0)
                {
                    if (msg->msg[0] == '/')
                    {
                        char command[0x20] = {0};
                        char * return_data = NULL;

                        get_param(msg->msg + 1, command, 0x20);

                        if (strncmp(command, "ls", 2) == 0)
                        {
                            return_data = (char *)malloc(MAX_INBOX_MSGS * 0x20 + 0x10);
                            memset(return_data, 0, MAX_INBOX_MSGS * 0x20 + 0x10);
                            Inbox_t * list = inbox_head;
                            for (int i = 0; i < MAX_INBOX_MSGS && list; i++, list = list->next)
                            {
                                strncat(return_data, list->name, 0x20);
                                strncat(return_data, "\n", 1);
                            }
                            push_msg(inbox, send_message(return_data, current_user.username, msg->from, strlen(return_data)));
                        }
                        else if (strncmp(command, "read", 4) == 0)
                        {
                            memset(command, 0, 0x20);
                            get_param(msg->msg + 6, command, 0x20);
                            return_data = malloc(MESSAGE_MAX_SIZE * 2 + 0x10);
                            memset(return_data, 0, MESSAGE_MAX_SIZE * 2 + 0x10);
                            unsigned int offset = 0;
                            Inbox_t * target_inbox = find_inbox(command);
                            if (target_inbox == inbox)
                            {
                                memcpy(return_data, "Cannot read from bot inbox.\n", 29);
                            }
                            else
                                if (target_inbox)
                                {
                                    for (unsigned long i = 0; i < target_inbox->msg_count; i++)
                                    {
                                        Msg_t * message = target_inbox->messages[i];
                                        if(message == NULL)
                                            continue;
                                        memcpy(return_data + offset, "From: ", 6);
                                        offset += 6;
                                        memcpy(return_data + offset, message->from, 0x20);
                                        offset += 0x20;
                                        memcpy(return_data + offset, "\nMessage: ", 10);
                                        offset += 10;
                                        memcpy(return_data + offset, message->msg, message->msg_size);
                                        offset += message->msg_size;
                                        memcpy(return_data + offset, "\n", 2);
                                        offset += 2;
                                        if (offset >= MESSAGE_MAX_SIZE)
                                        {
                                            push_msg(inbox, send_message(return_data, current_user.username, msg->from, offset));
                                            memset(return_data, 0, MESSAGE_MAX_SIZE * 2 + 0x10);
                                            offset = 0;
                                        }
                                    }
                                }
                                else
                                    memcpy(return_data, "Inbox not found.\n", 18);
                            
                            if(offset > 0)
                            {
                                return_data[offset - 1] = '\0';
                                push_msg(inbox, send_message(return_data, current_user.username, msg->from, offset));
                            }
                        }
                        else if (strncmp(command, "unsend", 6) == 0)
                        {
                            memset(command, 0, 0x20);
                            get_param(msg->msg + 8, command, 0x20);
                            return_data = malloc(0x40);
                            Inbox_t * target_inbox = find_inbox(command);
                            if (target_inbox && target_inbox != inbox)
                            {
                                pop_msg(target_inbox);
                            }
                            else
                            {
                                memcpy(return_data, "Can't unsend from requested inbox\n", 35);
                            }
                        }

                        else if (strncmp(command, "delete", 6) == 0)
                        {
                            memset(command, 0, 0x20);
                            get_param(msg->msg + 8, command, 0x20);
                            if (delete_inbox(command))
                            {
                                puts("Failed to delete inbox");
                            }
                        }
                        else if (strncmp(command, "help", 4) == 0)
                        {
                            return_data = malloc(MESSAGE_MAX_SIZE * 2 + 0x10);
                            memset(return_data, 0, MESSAGE_MAX_SIZE * 2 + 0x10);
                            strcat(return_data, "Bot commands:\n");
                            strcat(return_data, "  /ls                             - List inboxes\n");
                            strcat(return_data, "  /read <inbox_name>              - Read messages from specified inbox\n");
                            strcat(return_data, "  /unsend <inbox_name>            - Unsend the lastest message from specified inbox\n");
                            strcat(return_data, "  /delete <inbox_name>            - Delete specified inbox\n");
                            strcat(return_data, "  /help                           - Show this help message\n");
                            push_msg(inbox, send_message(return_data, current_user.username, msg->from, strlen(return_data)));
                        }
                        else
                        {
                            puts("Unknown bot command");
                        }
                        if (return_data != NULL)
                        {
                            free(return_data);
                            return_data = NULL;
                        }
                    }
                }
                break;
            default:
                return EXIT_FAILURE;
        }
    }
    else
        return EXIT_FAILURE;
    return 0;
}

void get_param(char * input, char * output, unsigned int max_len)
{
    char *p = input;
    while (*p == ' ' || *p == '\t') p++;
    strncpy(output, p, strcspn(p, " \n\t") < max_len - 1 ? strcspn(p, " \n\t") : max_len - 1);
    output[max_len - 1] = '\0';
    return;
}