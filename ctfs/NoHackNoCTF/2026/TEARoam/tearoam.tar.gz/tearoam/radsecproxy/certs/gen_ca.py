from pathlib import Path

from Crypto.PublicKey import RSA
from Crypto.Util.number import getPrime, inverse


D = 5
E = 65537
B = 1 << 508
T = [
    (3479563657816283399, 2539913980693826862),
    (4228815597459416039, 2364509653476625849),
    (3272022215089538759, 2944274362599979846),
    (2799144711469676399, 1528608805895707935),
    (4244782457572091879, 3122591611700766280),
    (3877145544493762019, 9426172573759572),
    (2447479596424601339, 2125885281691931302),
    (3378115876069012439, 3123676070373929296),
    (4089193790493321899, 384079311063125399),
]


def mul(x, y, p):
    a, b = x
    c, d = y
    return (a * c + D * b * d) % p, (a * d + b * c) % p


def f(x, n, p):
    r = (1, 0)
    y = (x, 1)
    while n:
        if n & 1:
            r = mul(r, y, p)
        y = mul(y, y, p)
        n >>= 1
    return r[0] * inverse(r[1], p) % p


def main():
    p = getPrime(1024)
    q = getPrime(1024)
    n = p * q
    s = p // B
    w = [(r, a, f(a, s, r)) for r, a in T]
    key = RSA.construct((n, E, inverse(E, (p - 1) * (q - 1)), p, q))
    Path("public.pem").write_bytes(key.public_key().export_key("PEM") + b"\n")
    Path("private.pem").write_bytes(key.export_key("PEM") + b"\n")
    Path("log.txt").write_text(
        "\n".join(
            [
                f"n = {n}",
                f"e = {E}",
                f"w = {w!r}",
                "",
            ]
        )
    )


if __name__ == "__main__":
    main()
