#!/bin/sh
set -e

PATH=/usr/sbin:/usr/bin:$PATH
export PATH

if [ "$#" -eq 0 ] || [ "${1#-}" != "$1" ]; then
    set -- freeradius "$@"
fi

if [ "$1" = "radiusd" ] || [ "$1" = "freeradius" ]; then
    daemon="$1"
    shift
    exec "$daemon" -f "$@"
fi

exec "$@"
