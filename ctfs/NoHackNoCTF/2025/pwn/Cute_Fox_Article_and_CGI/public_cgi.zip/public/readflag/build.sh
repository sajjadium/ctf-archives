gcc readflag.c -o readflag -static 
