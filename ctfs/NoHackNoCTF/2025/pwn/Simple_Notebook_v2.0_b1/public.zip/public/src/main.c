/*
 * Version 2 release note:
 *     - Patched integer overflow in read_note, which can lead to code execution
 *     - Introduce offline saving feature with password protection
 *     - In response to the serious vulnerability in the last version, we thoroughly
 *        reviewed the whole codebase and we promise this won't happen again.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <malloc.h>
#include <openssl/aes.h>


#define	OP_NEW		1
#define	OP_EDIT		2
#define	OP_DELETE	3
#define	OP_DISPLAY	4
#define	OP_EXIT		5
#define OP_SAVE		6
#define OP_LOAD		7
#define OP_DEBUG    100


#define	NOTES_NR	10
char *notes[NOTES_NR] = {0};
size_t note_size[NOTES_NR] = {0};


#define MAX_PASSWD_SIZE 256

#define _str(x) #x
#define str(x) _str(x)


char *get_password_from_user() {
	static char user_input[MAX_PASSWD_SIZE] = {0};

	printf("[INFO] Password for your save data\n> ");
	memset(&user_input, 0x00, sizeof user_input);

	/* We accept binary input -- as always! */
	read(0, user_input, MAX_PASSWD_SIZE);
	return user_input;
}



/* Also perform sanity checks */
size_t get_index_input() {
	size_t idx = 0;

	printf("[INFO] Index\n> ");
	scanf("%lu", &idx);

	if (idx >= NOTES_NR) {
		puts("[ERR] Invalid index");
		exit(-1);
	}

	return idx;
}


/* Sanity check will be performed in read_note() */
size_t get_size_input() {
	size_t size = 0;

	printf("[INFO] Size\n> ");
	scanf("%lu", &size);
	return size;
}

/* We accept binary except null bytes */
void read_note(size_t idx, size_t size) {
	size_t usable_size = size - 1;

	if (notes[idx] && usable_size <= note_size[idx]) {
		/*
		 * We need to leave room for null bytes, if null terminator
		 * is not set properly, OOB read could occur when printing
		 * the buffer out.
		 */
		memset(notes[idx], 0x00, size);
		printf("[INFO] Your note\n> ");
		read(0, notes[idx], usable_size);
	} else {
		puts("[ERR] Invalid parameters detected");
	}

	return;
}

/* Return server encryption key (SEK) with detail abstracted to the caller */
void *get_sek() {
	static char sek[32];
	static int initialized = 0;
	int fd;

	if (initialized) {
		return &sek;
	} else {
		fd = open("notebook.sek", O_RDONLY);
		if (fd < 0) {
			puts("[ERR] server encryption key not found, exiting");
			exit(-1);
		}
		read(fd, sek, sizeof sek);
		close(fd);

		initialized = 1;
		return &sek;
	}
}

#ifdef OP_DEBUG
#define DEV_TOKEN_SIZE 0x100

void *get_developer_auth_token() {
	static char token[DEV_TOKEN_SIZE];
	static int initialized = 0;
	int fd;

	if (initialized) {
		return &token;
	} else {
		fd = open("token.txt", O_RDONLY);
		if (fd < 0) {
			puts("[ERR] developer token not found, exiting");
			exit(-1);
		}
		read(fd, token, sizeof token);
		close(fd);

		initialized = 1;
		return &token;
	}
}

void debug_interface() {
	static char authenticated = 0;
	char user_input[DEV_TOKEN_SIZE] = {0};
	unsigned int val;

	puts("[DEBUG] You are now operating builtin debugger interface. For security reason, you must first enter your token");
	printf("[DEBUG] You may enter your developer token now\n> ");
	read(0, user_input, DEV_TOKEN_SIZE);

	if (memcmp(user_input, get_developer_auth_token(), DEV_TOKEN_SIZE)) {
		puts("[DEBUG] Access denied (invalid credential)");
		exit(-1);
	} else {
		puts("[DEBUG] Authentication successful, you may inspect raw memory data now");
	}
	
	puts("[DEBUG] Summary of note entries:");
	puts("-----------------------------");	
	for (size_t idx = 0; idx < NOTES_NR; idx++) {
		printf("notes[%lu] \n", idx);
		printf("location = %p\n", notes[idx]);
		printf("size = %lu\n", note_size[idx]);
		printf("malloc chunk size = %lu\n", malloc_usable_size(notes[idx]));
		if (notes[idx]) {
			printf("> %s\n", notes[idx]);
		} else {
			printf("(empty)\n");
		}
		puts("-----------------------------");
	}

	do {
		char cmd;
		size_t len = 0;
		unsigned char *addr = 0;
		unsigned char byte = 0;

		printf("debugger> ");
		/*
		 * r [addr] [len]: dump memory content
		 * w [addr] [len]: write to memory
		 * l: logout and return
		 * q: return
		 */
		scanf(" %c", &cmd);

		if (cmd == 'r') {
			scanf("%p %lu", &addr, &len);
			for (size_t i = 0; i < len; ++i)
				printf("%02x", addr[i]);
			printf("\n");

		} else if (cmd == 'w') {
			scanf("%p %lu", &addr, &len);
			for (size_t i = 0; i < len; ++i) {
				if (scanf("%2x", &val) != 1) {
					puts("[ERROR] Failed to read byte");
					while (getchar() != '\n') ;
					break;
				}
				addr[i] = (unsigned char)val;
			}
		} else if (cmd == 'q') {
			puts("[DEBUG] Debug session was terminated");
			return;
		} else if (cmd == 'l') {
			puts("[DEBUG] Debug session was terminated and privileges are removed");
			authenticated = 0;
			return;
		} else {
			puts("[DEBUG] Invalid command, usage: `[r|w] [location] [size]`");
		}

	} while (1);
}
#endif

void encrypt_session(void *buffer, int buffer_len) {
	/* AES has block size of 16 (bytes) */
	char encrypted_block[16];
	AES_KEY aes_key;

	/* We're using AES with key length of 256, secure! */
	if (AES_set_encrypt_key(get_sek(), 256, &aes_key) < 0) {
		puts("[ERR] Encryption somehow failed, existing");
		exit(-1);
	}

	for (int idx = 0; idx < buffer_len; idx += 16) {
		AES_encrypt(buffer + idx, encrypted_block, &aes_key);
		memcpy(buffer + idx, encrypted_block, 16);
	}

	return;
}

void decrypt_session(void *buffer, int buffer_len) {
	/* AES block size is 16 bytes */
	char decrypted_block[16];
	AES_KEY aes_key;

	/* Use the same 256-bit key from get_sek() */
	if (AES_set_decrypt_key(get_sek(), 256, &aes_key) < 0) {
		puts("[ERR] Decryption somehow failed, exiting");
		exit(-1);
	}

	for (int idx = 0; idx < buffer_len; idx += 16) {
		AES_decrypt(buffer + idx, decrypted_block, &aes_key);
		memcpy(buffer + idx, decrypted_block, 16);
	}

	return;
}

void hex_dump(void *data, int len) {
    for (int i = 0; i < len; i++) {
        printf("%02x ", *(unsigned char *)(data + i));
        if ((i + 1) % 16 == 0)
            printf("\n");
    }
    if (len % 16 != 0) printf("\n");
}


/* 16-byte alignment, which is required for AES to operate successfully */
#define align_aes_pad(x) (((x) + 0b1111) & ~0b1111)

/*
 * We use size and offset table instead of linear storage
 * becuase it offers constant time randome access, which is
 * necessaryfor effiecient batch processing feature in next
 * release
 */
struct session {
	char password[MAX_PASSWD_SIZE];
	size_t note_size[NOTES_NR];
	size_t offset[NOTES_NR];
	/* This member has size of zero */
	char data[];
};


int main() {
	size_t op = OP_EXIT;
	size_t size = 0;
	size_t idx = 0;

	/*
	 * Some caveats:
	 * - It must be 16-byte aligned, as we're using AES to encrypt it
	 * - Instead of deriving the key from ASCII password, we use a universal
	 *    Server Sncryption Key to protect user from offline bruteforce cracking
	 * - We'll verify the password upon recieving it, and the user has to
	 *    prove the ownership by providig correct password
	 */
	size_t session_size = 0;
	struct session *session_data = NULL;


	/*
	 * This is my note-taking app.
	 * Non-printable char is accepted (designed for cool geeks like you!),
	 * just make sure they don't contain null bytes (and you're okay with
	 * those garbled text on your screen)
	 */

	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);



	do {
		puts("+--------- Options ---------+");
		puts("| 1. Create a new note      |");
		puts("| 2. Edit an existing note  |");
		puts("| 3. Discard a note         |");
		puts("| 4. Display a note         |");
		puts("| 5. Exit the app           |");
		puts("| 6. Save data and quit     |");
		puts("| 7. Load from offline data |");
		puts("+---------------------------+");
		printf("Your choice: ");
		scanf("%lu", &op);

		switch (op) {
		case OP_NEW:
			idx = get_index_input();
			size = get_size_input();

			if (!notes[idx]) {
				notes[idx] = malloc(size);
				note_size[idx] = size;
				read_note(idx, size);
			} else {
				puts("[WARN] Note at that location have already been allocated");
			}

			break;

		case OP_EDIT:
			idx = get_index_input();
			size = get_size_input();
			read_note(idx, size);
			break;

		case OP_DELETE:
			idx = get_index_input();

			if (!notes[idx])
				puts("[WARN] Just a warning, nothing was there");

			free(notes[idx]);
			notes[idx] = NULL;
			note_size[idx] = 0;

			break;

		case OP_DISPLAY:
			idx = get_index_input();

			if (notes[idx])
				printf("> %s", notes[idx]);
			else
				puts("[INFO] Nothing to display...");

			break;

		case OP_EXIT:
			puts("[INFO] See you later in the day~");
			break;

		case OP_SAVE:
			session_size = sizeof(struct session);
			for (size_t idx = 0; idx < NOTES_NR; idx++)
				session_size += note_size[idx];
			session_size = align_aes_pad(session_size);

			session_data = malloc(session_size);
			if (!session_data) {
				puts("[ERR] Failed to allocate memory, report this to us via <team@ic3dt3a.org>");
			} else {
				memset(session_data, 0x00, session_size);
			}

			memcpy(&session_data->password, get_password_from_user(), MAX_PASSWD_SIZE);

			for (size_t idx = 0; idx < NOTES_NR; idx++)
				session_data->note_size[idx] = note_size[idx];

			for (size_t idx = 0, data_area_offset = offsetof(struct session, data);
				idx < NOTES_NR;
				data_area_offset += note_size[idx], idx++)
			{
				session_data->offset[idx] = data_area_offset;
				if (note_size[idx])
					memcpy((void *)session_data + data_area_offset, notes[idx], note_size[idx]);
			}

			encrypt_session(session_data, session_size);

			puts("[INFO] Here's your session ");
			printf("%lu,", session_size);
			for (int idx = 0; idx < session_size; idx++)
				printf("%02x", *((unsigned char *)session_data + idx));
			printf("\n");

			puts("[INFO] Do *NOT* share your passwor with others!");
			exit(0);
			break;
		case OP_LOAD:
			/* We must clear every single entry to avoid memory leak */
			for (int idx = 0; idx < NOTES_NR; idx++) {
				if (note_size[idx]) {
					free(notes[idx]);
					notes[idx] = NULL;
					note_size[idx] = 0;
				}
			}

			puts("[INFO] Now, paste your session data below");
			printf("> ");
			scanf("%lu,", &session_size);
			if (session_size % 16) {
				puts("[ERR] Invalid block cipher padding, exiting now");
				exit(-1);
			}

			session_data = malloc(session_size);
			if (!session_data) {
				puts("[ERR] Failed to allocate memory, report this to us via <team@ic3dt3a.org>");
			} else {
				memset(session_data, 0x00, session_size);
			}

			for (int idx = 0; idx < session_size; idx++) {
				scanf("%2hhx", (unsigned char *)session_data + idx);
			}

			decrypt_session(session_data, session_size);

			if (memcmp(get_password_from_user(), session_data->password, MAX_PASSWD_SIZE)) {
				puts("[ERR] Access denied (invalid credential)");
				exit(-1);
			}

			for (size_t idx = 0; idx < NOTES_NR; idx++) {
				note_size[idx] = session_data->note_size[idx];

				if (note_size[idx]) {
					notes[idx] = malloc(note_size[idx]);
					if (notes[idx]) {
						memcpy(notes[idx], (void *)session_data + session_data->offset[idx], note_size[idx]);
					} else {
						puts("[ERR] Failed to allocate memory, report this to us via <team@ic3dt3a.org>");
						exit(-1);
					}
				} else {
					notes[idx] = NULL;
				}
			}

			break;

#ifdef OP_DEBUG
		case OP_DEBUG:
			/*
			 * Our notebook application encounters strange memory errors during development, therefore
			 * a builtin interface for runtime memory inspection is added -- we can check memory
			 * contents and make modifications without intervention of a bloat external debugger.
			 */
			debug_interface();
			break;

#endif
		default:
			puts("[ERR] Are you still sane? You just selected some non-existent option...");
			break;
		}

	} while (op != OP_EXIT);

	return 0;
}
