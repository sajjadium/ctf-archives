#include <stdio.h>
#include <stdlib.h>

int main() {
	size_t size, idx;
	char *ptr, val;


	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stdout, NULL, _IONBF, 0);

	printf("Size: ");
	scanf(" %zu", &size);

	ptr = malloc(size);

	while (1) {
		printf("Index: ");
		scanf(" %zu", &idx);

		printf("Val: ");
		scanf(" %hhx", &val);

		if (idx > size) {
			free(ptr);
			exit(0);
		} else {
			ptr[idx] = val;
		}

	}

	return 0;
}
