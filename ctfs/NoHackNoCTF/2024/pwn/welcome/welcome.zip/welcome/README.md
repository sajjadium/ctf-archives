# 題目名稱：welcome
- **出題者**: raymond
- **難度**：初級
- **分數**：300
- **分類**：PWN
- **描述**：
  - （無）
- **預計解題時間**：15 分鐘

## 解法思路
1. **基本思路**：沒有檢查 `malloc()` 的回傳值，導致輸入很大的數值的時候函式回傳 0，而造成 OOB write
2. **步驟**：
   - 步驟 1：輸入超大的值，讓 `malloc()` 回傳 0
   - 步驟 2：OOB write + one gadget（需要猜 4 bit 的 ASLR）
   - 步驟 3：蓋 `free@got`，之後輸入超大的值觸發 `free()`，拿 shell 讀 flag
（還沒驗題）

## 解答
- **Flag 格式**：`NHNC{malloc_returned_null}`
