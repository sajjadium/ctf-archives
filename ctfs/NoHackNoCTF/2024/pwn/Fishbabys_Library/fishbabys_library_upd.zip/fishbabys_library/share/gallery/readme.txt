Welcome to art section of the library.
Enjoy your visit, have a good time!
