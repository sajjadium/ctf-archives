Cold Start

Lifted from a hostile launch silo out past Nereid's survey line: the
arming controller's flight computer plus its mission ROM.

Files:
- flightcomp:  Linux x86_64 ELF (the flight computer)
- mission.rom: the mission program it loads at cold start

Goal:
- Find the launch code that releases the arming gate.
- Submit the value in the format uctf{...}.

Notes:
- Run it locally: printf '%s' '<launch code>' | ./flightcomp mission.rom
- A correct code prints "GO for launch"; anything else holds.
