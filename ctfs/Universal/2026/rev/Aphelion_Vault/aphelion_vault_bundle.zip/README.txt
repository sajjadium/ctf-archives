Aphelion Vault

Recovered from a Nereid survey relay.

Files:
- aphelion_vault: Linux x86_64 ELF

Goal:
- Recover the vault's archive key.
- Submit the value in the format uctf{...}.

Notes:
- The binary runs locally and prompts for an alignment phrase.
- Standard Linux reverse engineering tooling is sufficient.