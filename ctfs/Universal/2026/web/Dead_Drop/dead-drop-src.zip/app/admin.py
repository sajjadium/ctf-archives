import base64
import pickle

from flask import Blueprint, abort, jsonify, request, session

from . import ALLOWED_EXTENSIONS, MAX_ENTRY_BYTES, MAX_ZIP_BYTES, get_db, template_env

bp = Blueprint("admin", __name__)


@bp.get("/admin")
def admin_panel():
    if session.get("role") != "admin":
        abort(403, "admin access required")

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM reports")
    report_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM users")
    user_count = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM messages")
    message_count = cur.fetchone()[0]
    cur.close()

    template = template_env.get_template("admin.html")
    return template.render(
        report_count=report_count,
        user_count=user_count,
        message_count=message_count,
    )


@bp.get("/admin/export-config")
def admin_export_config():
    if session.get("role") != "admin":
        abort(403, "admin access required")

    config_data = {
        "allowed_extensions": list(ALLOWED_EXTENSIONS),
        "max_zip_bytes": MAX_ZIP_BYTES,
        "max_entry_bytes": MAX_ENTRY_BYTES,
    }
    encoded = base64.b64encode(pickle.dumps(config_data)).decode()
    return jsonify({"config": encoded})


@bp.post("/admin/import-config")
def admin_import_config():
    if session.get("role") != "admin":
        abort(403, "admin access required")

    body = request.get_json(silent=True)
    if not body or "config" not in body:
        abort(400, "missing config field")

    try:
        raw = base64.b64decode(body["config"])
    except Exception:
        abort(400, "invalid base64")

    config_data = pickle.loads(raw)

    return jsonify({"status": "ok", "keys": list(config_data.keys())})
