import uuid

from flask import Blueprint, abort, redirect, request, session, url_for

from . import UPLOAD_BASE, get_db, template_env

bp = Blueprint("routes", __name__)


def _ensure_session():
    if "uid" not in session:
        session["uid"] = uuid.uuid4().hex[:12]
        session["role"] = "user"


@bp.before_app_request
def before_request():
    _ensure_session()


@bp.app_context_processor
def inject_nav():
    unread = 0
    username = session.get("username")
    if username:
        try:
            conn = get_db()
            cur = conn.cursor()
            cur.execute(
                "SELECT COUNT(*) FROM messages WHERE recipient=%s AND read=false",
                (username,),
            )
            unread = cur.fetchone()[0]
            cur.close()
        except Exception:
            pass
    return dict(
        current_user=username,
        unread_count=unread,
        session_role=session.get("role", "user"),
    )


@bp.get("/")
def home():
    uid = session["uid"]
    upload_dir = UPLOAD_BASE / uid
    files = sorted(f.name for f in upload_dir.iterdir()) if upload_dir.exists() else []
    template = template_env.get_template("index.html")
    return template.render(files=files, username=session.get("username"))


@bp.get("/login")
def login_page():
    template = template_env.get_template("login.html")
    return template.render(error=None)


@bp.post("/login")
def login():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    if not username or not password:
        template = template_env.get_template("login.html")
        return template.render(error="All fields are required."), 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, role FROM users WHERE username=%s AND password=%s",
        (username, password),
    )
    row = cur.fetchone()
    cur.close()

    if not row:
        template = template_env.get_template("login.html")
        return template.render(error="Invalid credentials."), 401

    session["user_id"] = row[0]
    session["username"] = username
    session["role"] = row[1]
    return redirect(url_for("routes.home"))


@bp.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("routes.home"))


@bp.get("/inbox")
def inbox():
    username = session.get("username")
    if not username:
        return redirect(url_for("routes.login_page"))

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, sender, subject, sent_at, read FROM messages "
        "WHERE recipient=%s ORDER BY sent_at DESC",
        (username,),
    )
    messages = cur.fetchall()
    cur.close()

    template = template_env.get_template("inbox.html")
    return template.render(messages=messages)


@bp.get("/message/<int:msg_id>")
def view_message(msg_id):
    username = session.get("username")
    if not username:
        return redirect(url_for("routes.login_page"))

    conn = get_db()
    cur = conn.cursor()
    cur.execute(
        "SELECT id, sender, recipient, subject, body, sent_at FROM messages "
        "WHERE id=%s AND (recipient=%s OR sender=%s)",
        (msg_id, username, username),
    )
    msg = cur.fetchone()
    if not msg:
        cur.close()
        abort(404, "Message not found")

    if msg[2] == username:
        cur.execute("UPDATE messages SET read=true WHERE id=%s", (msg_id,))
        conn.commit()
    cur.close()

    template = template_env.get_template("message.html")
    return template.render(msg=msg)


@bp.get("/compose")
def compose_page():
    username = session.get("username")
    if not username:
        return redirect(url_for("routes.login_page"))
    template = template_env.get_template("compose.html")
    return template.render(error=None, success=False)


@bp.post("/compose")
def compose():
    username = session.get("username")
    if not username:
        return redirect(url_for("routes.login_page"))

    recipient = request.form.get("recipient", "").strip()
    subject = request.form.get("subject", "").strip()
    body = request.form.get("body", "").strip()

    if not recipient or not subject:
        template = template_env.get_template("compose.html")
        return template.render(error="Recipient and subject are required.", success=False), 400

    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE username=%s", (recipient,))
    if not cur.fetchone():
        cur.close()
        template = template_env.get_template("compose.html")
        return template.render(error="Recipient not found.", success=False), 400

    cur.execute(
        "INSERT INTO messages (sender, recipient, subject, body) VALUES (%s,%s,%s,%s)",
        (username, recipient, subject, body),
    )
    conn.commit()
    cur.close()

    template = template_env.get_template("compose.html")
    return template.render(error=None, success=True)
