import os
from pathlib import Path

import psycopg2
from flask import Flask, current_app, g
from jinja2 import FileSystemLoader
from jinja2.sandbox import SandboxedEnvironment

UPLOAD_BASE = Path("/app/uploads")
TEMPLATE_DIR = Path("/app/templates")
MAX_ZIP_BYTES = 2 * 1024 * 1024
MAX_ENTRY_BYTES = 256 * 1024
ALLOWED_EXTENSIONS = {".txt", ".md", ".csv"}

template_env = SandboxedEnvironment(
    loader=FileSystemLoader(str(TEMPLATE_DIR)),
    auto_reload=True,
)


def get_db():
    if "db" not in g:
        g.db = psycopg2.connect(
            host=current_app.config["DB_HOST"],
            port=current_app.config["DB_PORT"],
            dbname=current_app.config["DB_NAME"],
            user=current_app.config["DB_USER"],
            password=current_app.config["DB_PASS"],
        )
    return g.db


def create_app():
    app = Flask(__name__, template_folder=str(TEMPLATE_DIR))
    app.secret_key = os.urandom(32).hex()

    app.config["DB_HOST"] = os.environ.get("DB_HOST", "db")
    app.config["DB_PORT"] = int(os.environ.get("DB_PORT", "5432"))
    app.config["DB_NAME"] = os.environ.get("DB_NAME", "deadrop")
    app.config["DB_USER"] = os.environ.get("DB_USER", "deadrop")
    app.config["DB_PASS"] = os.environ.get("DB_PASS", "deadrop")

    from . import routes, upload, admin
    app.register_blueprint(routes.bp)
    app.register_blueprint(upload.bp)
    app.register_blueprint(admin.bp)

    @app.teardown_appcontext
    def close_db(exc):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    return app
