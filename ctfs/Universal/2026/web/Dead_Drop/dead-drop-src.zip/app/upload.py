import io
import zipfile
from pathlib import Path

from flask import Blueprint, abort, jsonify, request, session

from . import ALLOWED_EXTENSIONS, MAX_ENTRY_BYTES, MAX_ZIP_BYTES, UPLOAD_BASE, get_db, template_env

bp = Blueprint("upload", __name__)


@bp.post("/api/upload")
def upload():
    f = request.files.get("bundle")
    if not f or not f.filename.endswith(".zip"):
        abort(400, "zip file required")

    raw = f.read(MAX_ZIP_BYTES + 1)
    if len(raw) > MAX_ZIP_BYTES:
        abort(413, "zip file too large")

    uid = session["uid"]
    upload_dir = UPLOAD_BASE / uid
    upload_dir.mkdir(parents=True, exist_ok=True)

    extracted = []
    buf = io.BytesIO(raw)
    with zipfile.ZipFile(buf) as zf:
        for entry in zf.infolist():
            if entry.is_dir():
                continue

            ext = Path(entry.filename).suffix.lower()
            if ext not in ALLOWED_EXTENSIONS:
                continue

            if entry.file_size > MAX_ENTRY_BYTES:
                continue

            dest = upload_dir / entry.filename
            dest.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(entry) as src, open(dest, "wb") as dst:
                dst.write(src.read())

            extracted.append(entry.filename)

    conn = get_db()
    cur = conn.cursor()
    for name in extracted:
        cur.execute(
            "INSERT INTO reports (uid, filename) VALUES (%s, %s)",
            (uid, Path(name).name),
        )
    conn.commit()
    cur.close()

    return jsonify({"status": "ok", "extracted": extracted})


@bp.get("/report")
def report():
    uid = session["uid"]
    upload_dir = UPLOAD_BASE / uid
    files = sorted(f.name for f in upload_dir.iterdir()) if upload_dir.exists() else []

    from flask import current_app
    template = template_env.get_template("report.html")
    return template.render(files=files, uid=uid, config=current_app.config)
