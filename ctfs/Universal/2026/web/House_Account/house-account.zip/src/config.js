export const startingCredits = 5;
export const flagPrice = 670;
export const cratePayout = 95;
export const crateCooldownMs = 60 * 60 * 1000;
export const sessionCookieName = "house_account_session";
export const sessionTtlMs = 1000 * 60 * 60 * 8;
export const defaultTimeZone = "UTC";
export const safeTimeZones = [
  {
    id: "UTC",
    label: "UTC",
  },
  {
    id: "Europe/Paris",
    label: "Europe/Paris",
  },
  {
    id: "America/New_York",
    label: "America/New_York",
  },
  {
    id: "Asia/Tokyo",
    label: "Asia/Tokyo",
  },
  {
    id: "Asia/Tehran",
    label: "Asia/Tehran",
  },
];
export const crateName = "scrap crate";
export const games = {
  toss: {
    minimumBet: 2,
    maximumBet: 5,
  },
  roulette: {
    minimumBet: 1,
    maximumBet: 5,
  },
};
