import crypto from "node:crypto";
import { games } from "./config.js";

const redNumbers = new Set([1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]);

function validateBet(gameKey, amount) {
  const config = games[gameKey];
  if (!config) {
    throw new Error("Unknown game");
  }

  if (!Number.isInteger(amount)) {
    throw new Error("Bets must be whole credits");
  }

  if (amount < config.minimumBet || amount > config.maximumBet) {
    throw new Error(`Bets must be between ${config.minimumBet} and ${config.maximumBet}`);
  }
}

export function playToss(amount, pick) {
  validateBet("toss", amount);

  if (!["heads", "tails"].includes(pick)) {
    throw new Error("Choose heads or tails");
  }

  const outcome = crypto.randomInt(2) === 0 ? "heads" : "tails";
  const won = outcome === pick;
  const delta = won ? amount - 1 : -amount;

  return {
    game: "toss",
    outcome,
    won,
    delta,
  };
}

export function playRoulette(amount, pick) {
  validateBet("roulette", amount);

  if (!["red", "black"].includes(pick)) {
    throw new Error("Choose red or black");
  }

  const slot = crypto.randomInt(37);
  const color = slot === 0 ? "green" : redNumbers.has(slot) ? "red" : "black";
  const won = color === pick;
  const delta = won ? amount : -amount;

  return {
    game: "roulette",
    slot,
    color,
    pick,
    won,
    delta,
  };
}
