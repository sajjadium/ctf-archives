import cookieParser from "cookie-parser";
import express from "express";
import path from "node:path";
import { sessionCookieName } from "./config.js";
import { getSession } from "./db.js";
import { clearFlash, formatCredits, parseFlashCookie } from "./http.js";
import authRouter from "./routes/auth.js";
import homeRouter from "./routes/home.js";
import marketRouter from "./routes/market.js";

const app = express();

app.set("view engine", "ejs");
app.set("views", path.join(process.cwd(), "views"));

app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use("/public", express.static(path.join(process.cwd(), "public")));

app.use((req, res, next) => {
  const token = req.cookies[sessionCookieName];
  const session = token ? getSession(token) : null;

  req.session = session;
  res.locals.flash = parseFlashCookie(req.cookies.flash);
  res.locals.formatCredits = formatCredits;

  if (req.cookies.flash) {
    clearFlash(res);
  }

  next();
});

app.use(homeRouter);
app.use(authRouter);
app.use(marketRouter);

export default app;