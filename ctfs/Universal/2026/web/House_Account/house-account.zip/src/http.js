import { sessionCookieName } from "./config.js";

export function formatCredits(value) {
  return `${value}Ⱡ`;
}

export function parseFlashCookie(rawValue) {
  if (!rawValue) {
    return null;
  }

  try {
    return JSON.parse(rawValue);
  } catch {
    return null;
  }
}

export function setFlash(res, type, message) {
  res.cookie("flash", JSON.stringify({ type, message }), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
  });
}

export function clearFlash(res) {
  res.clearCookie("flash", { path: "/" });
}

export function setSessionCookie(res, token) {
  res.cookie(sessionCookieName, token, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
  });
}

export function clearSessionCookie(res) {
  res.clearCookie(sessionCookieName, { path: "/" });
}

export function parseStake(rawValue) {
  const value = Number(rawValue);
  if (!Number.isInteger(value)) {
    throw new Error("Bets must be whole credits");
  }

  return value;
}

export function requireSession(req, res, next) {
  if (!req.session) {
    setFlash(res, "error", "Login to access the stall ledger.");
    return res.redirect("/?login=1");
  }

  next();
}