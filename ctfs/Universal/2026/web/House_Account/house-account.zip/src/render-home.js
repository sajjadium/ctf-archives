import { crateName, cratePayout, flagPrice, games, safeTimeZones } from "./config.js";
import { getCooldownState } from "./cooldown.js";
import { getLedger } from "./db.js";
import { buildShopInventory } from "./shop.js";

function getGuestCooldown() {
  return {
    nextAt: 0,
    remainingMs: 0,
    canOpen: true,
  };
}

export function buildHomeModel(req, options = {}) {
  const session = options.sessionOverride ?? req.session;
  const user = session?.user ?? null;
  const ledger = user ? getLedger(user.id, 12) : [];
  const cooldown = user
    ? getCooldownState({ lastCrateAt: user.lastCrateAt })
    : getGuestCooldown();
  const shopItems = options.shopItems ?? buildShopInventory(user);

  return {
    session,
    user,
    ledger,
    cooldown,
    shopItems,
    claimedFlag: options.claimedFlag ?? null,
    registerModalOpen: options.registerModalOpen ?? req.query.register === "1",
    loginModalOpen: options.loginModalOpen ?? req.query.login === "1",
    profileModalOpen: options.profileModalOpen ?? req.query.profile === "1",
    crateName,
    cratePayout,
    flagPrice,
    games,
    safeTimeZones,
  };
}

export function renderHome(req, res, options = {}) {
  return res.render("home", buildHomeModel(req, options));
}