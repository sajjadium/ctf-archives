const body = document.body;
const registerModal = document.querySelector("[data-register-modal]");
const loginModal = document.querySelector("[data-login-modal]");
const profileModal = document.querySelector("[data-profile-modal]");
const stage = document.querySelector("[data-stage]");

function replaceQueryFlag(key, isOpen) {
  const url = new URL(window.location.href);

  if (isOpen) {
    url.searchParams.set(key, "1");
  } else {
    url.searchParams.delete(key);
  }

  window.history.replaceState({}, "", `${url.pathname}${url.search}${url.hash}`);
}

function initStage() {
  if (!stage) {
    return;
  }

  const views = {
    hub: { x: 0, y: 0 },
    shop: { x: 0, y: -1 },
    roulette: { x: -1, y: 0 },
    crate: { x: 1, y: 0 },
    toss: { x: 0, y: 1 },
  };
  const screens = document.querySelectorAll("[data-view]");

  function normalizeView(view) {
    return Object.hasOwn(views, view) ? view : "hub";
  }

  function renderView(view) {
    const nextView = normalizeView(view);
    stage.dataset.activeView = nextView;
    stage.style.setProperty("--stage-x", String(views[nextView].x));
    stage.style.setProperty("--stage-y", String(views[nextView].y));

    for (const screen of screens) {
      screen.classList.toggle("is-active", screen.dataset.view === nextView);
    }
  }

  function updateUrl(view, replace = false) {
    const url = new URL(window.location.href);

    if (view === "hub") {
      url.hash = "";
    } else {
      url.hash = view;
    }

    if (replace) {
      window.history.replaceState({}, "", url);
    } else {
      window.history.pushState({}, "", url);
    }
  }

  function navigateTo(view, replace = false) {
    const nextView = normalizeView(view);
    renderView(nextView);
    updateUrl(nextView, replace);
  }

  document.addEventListener("click", (event) => {
    const link = event.target.closest("[data-view-link]");
    if (!link) {
      return;
    }

    event.preventDefault();
    navigateTo(link.dataset.viewLink);
  });

  window.addEventListener("popstate", () => {
    renderView(window.location.hash.slice(1) || "hub");
  });

  renderView(window.location.hash.slice(1) || "hub");
}

if (body && registerModal) {
  const openers = document.querySelectorAll("[data-open-register]");
  const closers = document.querySelectorAll("[data-close-register]");

  function openRegisterModal() {
    body.classList.remove("profile-open");
    body.classList.remove("login-open");
    body.classList.add("register-open");
    replaceQueryFlag("register", true);
  }

  function closeRegisterModal() {
    body.classList.remove("register-open");
    replaceQueryFlag("register", false);
  }

  for (const opener of openers) {
    opener.addEventListener("click", openRegisterModal);
  }

  for (const closer of closers) {
    closer.addEventListener("click", closeRegisterModal);
  }

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeRegisterModal();
    }
  });
}

if (body && loginModal) {
  const openers = document.querySelectorAll("[data-open-login]");
  const closers = document.querySelectorAll("[data-close-login]");

  function openLoginModal() {
    body.classList.remove("profile-open");
    body.classList.remove("register-open");
    body.classList.add("login-open");
    replaceQueryFlag("login", true);
  }

  function closeLoginModal() {
    body.classList.remove("login-open");
    replaceQueryFlag("login", false);
  }

  for (const opener of openers) {
    opener.addEventListener("click", openLoginModal);
  }

  for (const closer of closers) {
    closer.addEventListener("click", closeLoginModal);
  }

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeLoginModal();
    }
  });
}

if (body && profileModal) {
  const openers = document.querySelectorAll("[data-open-profile]");
  const closers = document.querySelectorAll("[data-close-profile]");

  function openProfileModal() {
    body.classList.remove("register-open");
    body.classList.remove("login-open");
    body.classList.add("profile-open");
    replaceQueryFlag("profile", true);
  }

  function closeProfileModal() {
    body.classList.remove("profile-open");
    replaceQueryFlag("profile", false);
  }

  for (const opener of openers) {
    opener.addEventListener("click", openProfileModal);
  }

  for (const closer of closers) {
    closer.addEventListener("click", closeProfileModal);
  }

  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeProfileModal();
    }
  });
}

initStage();