import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import Database from "better-sqlite3";
import { crateName, cratePayout, defaultTimeZone, sessionTtlMs, startingCredits } from "./config.js";
import { formatCrateTimestamp } from "./cooldown.js";

const legacyTimeZoneMap = new Map([
  ["Arachne Standard", defaultTimeZone],
]);

function normalizeTimeZone(value) {
  const trimmed = (value ?? "").trim();
  return legacyTimeZoneMap.get(trimmed) ?? (trimmed || defaultTimeZone);
}

const dataDir = path.join(process.cwd(), ".sqlite");
const dbPath = path.join(dataDir, "house-account.db");

fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      balance INTEGER NOT NULL DEFAULT ${startingCredits},
      clock_style TEXT NOT NULL DEFAULT '${defaultTimeZone}',
      timezone_label TEXT NOT NULL DEFAULT '${defaultTimeZone}',
      crate_label TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL,
      cached_clock_style TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS ledger (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      kind TEXT NOT NULL,
      amount INTEGER NOT NULL,
      detail TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  db.prepare(`
    UPDATE users
    SET timezone_label = ?
    WHERE timezone_label = ?
  `).run(defaultTimeZone, "Arachne Standard");

  db.prepare(`
    UPDATE sessions
    SET cached_clock_style = ?
    WHERE cached_clock_style = ?
  `).run(defaultTimeZone, "Arachne Standard");
}

migrate();

function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex");
}

function makeSessionToken() {
  return crypto.randomBytes(32).toString("hex");
}

function getUserById(userId) {
  const user = db.prepare(`
    SELECT id, username, balance, timezone_label AS timeZone, crate_label AS lastCrateAt, created_at AS createdAt
    FROM users
    WHERE id = ?
  `).get(userId);

  if (!user) {
    return null;
  }

  user.timeZone = normalizeTimeZone(user.timeZone);
  return user;
}

function addLedgerEntry(userId, kind, amount, detail) {
  db.prepare(`
    INSERT INTO ledger (user_id, kind, amount, detail)
    VALUES (?, ?, ?, ?)
  `).run(userId, kind, amount, detail);
}

export function createUser(username, password) {
  const statement = db.prepare(`
    INSERT INTO users (username, password_hash)
    VALUES (?, ?)
  `);

  const result = statement.run(username.trim(), hashPassword(password));
  addLedgerEntry(result.lastInsertRowid, "opening", startingCredits, "Opening float from the stall.");
  return getUserById(result.lastInsertRowid);
}

export function authenticateUser(username, password) {
  const row = db.prepare(`
    SELECT id, password_hash AS passwordHash
    FROM users
    WHERE username = ?
  `).get(username.trim());

  if (!row || row.passwordHash !== hashPassword(password)) {
    return null;
  }

  return getUserById(row.id);
}

export function createSession(userId) {
  const user = getUserById(userId);
  const token = makeSessionToken();
  const expiresAt = Date.now() + sessionTtlMs;

  db.prepare(`
    INSERT INTO sessions (token, user_id, cached_clock_style, expires_at)
    VALUES (?, ?, ?, ?)
  `).run(token, userId, user.timeZone, expiresAt);

  return { token, expiresAt };
}

export function getSession(token) {
  const session = db.prepare(`
    SELECT token, user_id AS userId, cached_clock_style AS cachedTimeZone, expires_at AS expiresAt
    FROM sessions
    WHERE token = ?
  `).get(token);

  if (!session) {
    return null;
  }

  if (session.expiresAt <= Date.now()) {
    deleteSession(token);
    return null;
  }

  const user = getUserById(session.userId);
  if (!user) {
    deleteSession(token);
    return null;
  }

  return {
    ...session,
    cachedTimeZone: normalizeTimeZone(session.cachedTimeZone),
    user,
  };
}

export function deleteSession(token) {
  db.prepare(`DELETE FROM sessions WHERE token = ?`).run(token);
}

export function updateProfile(userId, { username, timezoneLabel }) {
  const nextUsername = username.trim();
  const timeZone = normalizeTimeZone(timezoneLabel);

  if (!nextUsername) {
    throw new Error("Name cannot be empty");
  }

  db.prepare(`
    UPDATE users
    SET username = ?, timezone_label = ?
    WHERE id = ?
  `).run(nextUsername, timeZone, userId);

  return getUserById(userId);
}

export function getLedger(userId, limit = 20) {
  return db.prepare(`
    SELECT kind, amount, detail, created_at AS createdAt
    FROM ledger
    WHERE user_id = ?
    ORDER BY id DESC
    LIMIT ?
  `).all(userId, limit);
}

export function applyGameResult(userId, result, detail) {
  const user = getUserById(userId);
  const nextBalance = user.balance + result.delta;

  if (nextBalance < 0) {
    throw new Error("You do not have enough credits for that stake");
  }

  db.prepare(`
    UPDATE users
    SET balance = ?
    WHERE id = ?
  `).run(nextBalance, userId);

  addLedgerEntry(userId, result.game, result.delta, detail);
  return getUserById(userId);
}

export function openCrate(userId, cachedTimeZone) {
  const user = getUserById(userId);
  const lastCrateAt = formatCrateTimestamp(new Date(), cachedTimeZone);
  const nextBalance = user.balance + cratePayout;

  db.prepare(`
    UPDATE users
    SET balance = ?, crate_label = ?
    WHERE id = ?
  `).run(nextBalance, lastCrateAt, userId);

  addLedgerEntry(userId, "crate", cratePayout, `Opened a ${crateName}.`);
  return getUserById(userId);
}

export function purchaseShopItem(userId, item, flagValue) {
  const user = getUserById(userId);
  if (user.balance < item.price) {
    throw new Error("You cannot cover the price yet");
  }

  const nextBalance = user.balance - item.price;
  db.prepare(`
    UPDATE users
    SET balance = ?
    WHERE id = ?
  `).run(nextBalance, userId);

  addLedgerEntry(userId, "purchase", -item.price, `Bought ${item.name}.`);

  return {
    user: getUserById(userId),
    flag: item.kind === "flag" ? flagValue : null,
    item,
  };
}
