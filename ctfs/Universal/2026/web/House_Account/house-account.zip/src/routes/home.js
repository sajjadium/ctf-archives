import { Router } from "express";
import { renderHome } from "../render-home.js";

const router = Router();

router.get("/", (req, res) => {
  renderHome(req, res);
});

export default router;