import { Router } from "express";
import { defaultTimeZone, sessionCookieName } from "../config.js";
import {
  authenticateUser,
  createSession,
  createUser,
  deleteSession,
  updateProfile,
} from "../db.js";
import {
  clearSessionCookie,
  requireSession,
  setFlash,
  setSessionCookie,
} from "../http.js";

const router = Router();

router.post("/register", (req, res) => {
  const username = (req.body.username ?? "").trim();
  const password = req.body.password ?? "";

  if (!username || !password) {
    setFlash(res, "error", "Pick a handle and a password.");
    return res.redirect("/?register=1");
  }

  try {
    const user = createUser(username, password);
    const session = createSession(user.id);
    setSessionCookie(res, session.token);
    setFlash(res, "success", "Account opened.");
  } catch {
    setFlash(res, "error", "That handle is already on the board.");
    return res.redirect("/?register=1");
  }

  return res.redirect("/");
});

router.post("/login", (req, res) => {
  const user = authenticateUser(req.body.username ?? "", req.body.password ?? "");
  if (!user) {
    setFlash(res, "error", "Credentials rejected.");
    return res.redirect("/?login=1");
  }

  const session = createSession(user.id);
  setSessionCookie(res, session.token);
  setFlash(res, "success", "Session restored.");
  return res.redirect("/");
});

router.post("/logout", requireSession, (req, res) => {
  deleteSession(req.cookies[sessionCookieName]);
  clearSessionCookie(res);
  setFlash(res, "success", "Till next shift.");
  return res.redirect("/");
});

router.post("/profile", requireSession, (req, res) => {
  const username = (req.body.username ?? "").trim();
  const timeZone = (req.body.timeZone ?? defaultTimeZone).trim() || defaultTimeZone;

  if (!username || username.length > 20) {
    setFlash(res, "error", "Keep the account name between 1 and 20 characters.");
    return res.redirect("/?profile=1");
  }

  if (timeZone.length > 64) {
    setFlash(res, "error", "Keep the region tag under 64 characters.");
    return res.redirect("/?profile=1");
  }

  try {
    updateProfile(req.session.user.id, {
      username,
      timezoneLabel: timeZone,
    });
    setFlash(res, "success", "House register updated.");
    return res.redirect("/");
  } catch (error) {
    setFlash(res, "error", error.message.includes("UNIQUE") ? "That name is already on the board." : error.message);
    return res.redirect("/?profile=1");
  }
});

export default router;