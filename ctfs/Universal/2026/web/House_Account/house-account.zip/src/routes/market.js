import { Router } from "express";
import { crateName, cratePayout } from "../config.js";
import { getCooldownState } from "../cooldown.js";
import { applyGameResult, openCrate, purchaseShopItem } from "../db.js";
import { parseStake, requireSession, setFlash } from "../http.js";
import { playRoulette, playToss } from "../games.js";
import { renderHome } from "../render-home.js";
import { buildShopInventory, getShopItem } from "../shop.js";

const router = Router();

router.post("/games/roulette", requireSession, (req, res) => {
  try {
    const amount = parseStake(req.body.amount);
    const result = playRoulette(amount, req.body.pick);
    const detail = result.won
      ? `Roulette hit ${result.color} ${result.slot}; paid out ${result.delta}Ⱡ.`
      : `Roulette stopped on ${result.color} ${result.slot}; the stake stayed with the house.`;
    applyGameResult(req.session.user.id, result, detail);
    setFlash(res, "success", detail);
  } catch (error) {
    setFlash(res, "error", error.message);
  }

  return res.redirect("/#roulette");
});

router.post("/games/toss", requireSession, (req, res) => {
  try {
    const amount = parseStake(req.body.amount);
    const result = playToss(amount, req.body.pick);
    const detail = result.won
      ? `Coin toss landed on ${result.outcome}; paid out ${result.delta}Ⱡ.`
      : `Coin toss landed on ${result.outcome}; the stake stayed with the house.`;
    applyGameResult(req.session.user.id, result, detail);
    setFlash(res, "success", detail);
  } catch (error) {
    setFlash(res, "error", error.message);
  }

  return res.redirect("/#toss");
});

router.post("/crate", requireSession, (req, res) => {
  const cooldown = getCooldownState({ lastCrateAt: req.session.user.lastCrateAt });
  if (!cooldown.canOpen) {
    const minutes = Math.ceil(cooldown.remainingMs / 60000);
    setFlash(res, "error", `The crate runner is not due back for another ${minutes} minute(s).`);
    return res.redirect("/#crate");
  }

  openCrate(req.session.user.id, req.session.cachedTimeZone);
  setFlash(res, "success", `You cracked open a ${crateName} and found ${cratePayout}Ⱡ inside.`);
  return res.redirect("/#crate");
});

router.post("/buy-item", requireSession, (req, res) => {
  try {
    const item = getShopItem(req.body.itemId ?? "", req.session.user);
    if (!item) {
      throw new Error("That shelf tag is no longer on this counter.");
    }

    const purchase = purchaseShopItem(
      req.session.user.id,
      item,
      process.env.FLAG ?? "uctf{dev-house-account}",
    );

    if (purchase.flag) {
      return renderHome(req, res, {
        claimedFlag: purchase.flag,
        shopItems: buildShopInventory(purchase.user),
        sessionOverride: {
          ...req.session,
          user: purchase.user,
        },
      });
    }

    setFlash(res, "success", `The clerk slides over ${purchase.item.name}.`);
    return res.redirect("/#shop");
  } catch (error) {
    setFlash(res, "error", error.message);
    return res.redirect("/#shop");
  }
});

export default router;