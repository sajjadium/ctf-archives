import { crateCooldownMs, defaultTimeZone } from "./config.js";

const displayLocale = "en-US";

function formatWithTimeZone(date, timeZone) {
  new Intl.DateTimeFormat(displayLocale, {
    timeZone,
    hour12: false,
  });

  return date.toISOString();
}

function formatWithLocaleFallback(date, timeZone) {
  return date.toLocaleString(timeZone, {
    hour12: false,
  });
}

export function formatCrateTimestamp(date, timeZone = defaultTimeZone) {
  try {
    return formatWithTimeZone(date, timeZone);
  } catch {
    try {
      return formatWithLocaleFallback(date, timeZone);
    } catch {
      return formatWithTimeZone(date, defaultTimeZone);
    }
  }
}

export function rebuildCrateCooldown(lastCrateAt) {
  if (!lastCrateAt) {
    return 0;
  }

  const lastOpenedAt = new Date(lastCrateAt);
  const nextOpenedAt = new Date(lastOpenedAt);
  nextOpenedAt.setMilliseconds(nextOpenedAt.getMilliseconds() + crateCooldownMs);
  return +nextOpenedAt || 0;
}

export function getCooldownState({ lastCrateAt, now = Date.now() }) {
  const nextAt = rebuildCrateCooldown(lastCrateAt);
  const remainingMs = Math.max(0, nextAt - now);

  return {
    nextAt,
    remainingMs,
    canOpen: now >= nextAt,
  };
}
