import crypto from "node:crypto";
import { flagPrice } from "./config.js";

const fillerItems = [
  {
    id: "scrap-ledger",
    name: "scrap ledger",
    price: 36,
    description: "A hand-stitched credit book with three names scratched out of the cover.",
  },
  {
    id: "quiet-radio",
    name: "quiet radio",
    price: 58,
    description: "Still warm from the counter shelf, tuned to a channel nobody admits to using.",
  },
  {
    id: "burner-slate",
    name: "burner slate",
    price: 74,
    description: "A disposable planning slate with half a route still burned into the glass.",
  },
  {
    id: "custom-dice",
    name: "weighted dice",
    price: 42,
    description: "Sold as decorative. The clerk does not laugh when they say that.",
  },
  {
    id: "seal-ring",
    name: "seal ring",
    price: 113,
    description: "Stamped brass from a shuttered port office, useful only if nobody looks closely.",
  },
  {
    id: "silk-map",
    name: "silk map",
    price: 89,
    description: "A fold-out route sketch printed on silk and annotated in three incompatible hands.",
  },
  {
    id: "proxy-badge",
    name: "proxy badge",
    price: 51,
    description: "Last shift's access badge, polished just enough to pass at a distance.",
  },
  {
    id: "crate-key",
    name: "crate key",
    price: 67,
    description: "A rack key that probably fits something valuable somewhere else in the city.",
  },
];

export const flagItem = {
  id: "flag",
  name: "flag",
  price: flagPrice,
  description: "Folded flat, tagged plain, and kept where everyone can see it but not afford it.",
  kind: "flag",
};

function score(seed, itemId) {
  const digest = crypto.createHash("sha256").update(`${seed}:${itemId}`).digest();
  return digest.readUInt32BE(0);
}

function sortBySeed(items, seed) {
  return [...items].sort((left, right) => {
    return score(seed, left.id) - score(seed, right.id);
  });
}

function getSeed(user) {
  if (!user) {
    return "guest-shelf";
  }

  return `user:${user.id}:${user.username}`;
}

export function buildShopInventory(user) {
  const seed = getSeed(user);
  const selectedFiller = sortBySeed(fillerItems, `${seed}:select`).slice(0, 5);
  const inventory = [flagItem, ...selectedFiller.map((item) => ({ ...item, kind: "misc" }))];
  return sortBySeed(inventory, `${seed}:order`);
}

export function getShopItem(itemId, user) {
  return buildShopInventory(user).find((item) => item.id === itemId) ?? null;
}