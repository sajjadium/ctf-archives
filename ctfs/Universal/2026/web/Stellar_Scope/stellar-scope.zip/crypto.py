import numpy as np

def hash(thing_to_hash: str):
    characters = np.frombuffer(thing_to_hash.encode("utf-8"), dtype=np.uint8)

    zero_or_one = characters[0] % 2

    interlaced = np.empty(characters.size * 2, dtype=np.uint8)
    interlaced[zero_or_one::2] = characters
    unknown_lane = interlaced[1 - zero_or_one::2].copy()

    mask = _mask_from_input(characters)
    payload = unknown_lane ^ mask

    mixing = np.triu(np.ones((payload.size, payload.size), dtype=np.uint8))
    digest = ((mixing.astype(np.uint16) @ payload.astype(np.uint16)) & 0xFF).astype(np.uint8)

    return digest.tolist()

def _mask_from_input(characters: np.ndarray) -> np.ndarray:
    if characters.size == 0:
        return np.zeros(0, dtype=np.uint8)

    side = int(np.ceil(np.sqrt(characters.size)))
    padding = (side * side) - characters.size
    pad_value = int(((characters.sum(dtype=np.uint16) * 7) + (characters.size * 13) + 41) % 256)
    padded = np.pad(characters, (0, padding), constant_values=pad_value)

    matrix = padded.reshape(side, side)
    rotated = np.rot90(matrix)
    zigzag = np.roll(matrix, 1, axis=1) ^ np.roll(rotated, -1, axis=0)
    gram = (matrix.astype(np.uint16) @ ((rotated ^ 0xA5).astype(np.uint16).T)) & 0xFF
    diagonal = np.diag(gram).astype(np.uint8)

    stream = np.concatenate(
        [
            zigzag.ravel(),
            diagonal,
            gram.astype(np.uint8).ravel(),
            np.flipud(matrix).ravel(),
        ]
    )
    return np.resize(stream, characters.size).astype(np.uint8)
