import os
import sqlite3

from flask import g

DB_PATH = "/tmp/stellar_scope.db"
ASSETS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
FLAG = os.environ.get("FLAG", "uctf{test_flag_placeholder}")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


def close_db(exc):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS users (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            username    TEXT    UNIQUE NOT NULL,
            password_hash TEXT  NOT NULL,
            password_len  INTEGER NOT NULL,
            created_at  TEXT    NOT NULL,
            api_key     TEXT    NOT NULL,
            bio         TEXT    DEFAULT '',
            is_admin    INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS photos (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            title       TEXT    NOT NULL,
            description TEXT    DEFAULT '',
            image       TEXT    DEFAULT '',
            created_at  TEXT    NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
        """
    )
    db.commit()
    db.close()
