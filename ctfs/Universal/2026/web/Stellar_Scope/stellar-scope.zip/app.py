import os

from flask import Flask

from db import FLAG, close_db, init_db
from routes.api import bp as api_bp
from routes.web import bp as web_bp

app = Flask(__name__)
app.secret_key = os.urandom(32)

app.teardown_appcontext(close_db)

app.register_blueprint(web_bp)
app.register_blueprint(api_bp)

init_db()

from provision import provision_admin, provision_default_users

provision_default_users()
provision_admin(username="admin", password=FLAG)
