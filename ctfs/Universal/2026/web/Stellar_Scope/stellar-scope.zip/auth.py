from functools import wraps

from flask import flash, g, jsonify, redirect, request, session, url_for

from crypto import hash as crypto_hash
from db import get_db


def generate_api_key(username: str, created_at: str, password: str) -> str:
    raw = f"{username}:{created_at}:{password}"
    digest = crypto_hash(raw)
    return bytes(digest).hex()


def get_current_user():
    uid = session.get("user_id")
    if uid is None:
        return None
    return get_db().execute("SELECT * FROM users WHERE id = ?", (uid,)).fetchone()


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if get_current_user() is None:
            flash("Please log in first.", "warning")
            return redirect(url_for("web.login"))
        return f(*args, **kwargs)
    return wrapper


def api_auth_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return jsonify({"error": "Missing or invalid Authorization header"}), 401
        token = auth[7:]
        user = get_db().execute("SELECT * FROM users WHERE api_key = ?", (token,)).fetchone()
        if user is None:
            return jsonify({"error": "Invalid API key"}), 401
        g.api_user = user
        return f(*args, **kwargs)
    return wrapper
