import hashlib
import re
from datetime import datetime

from flask import (
    Blueprint,
    abort,
    flash,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)

from auth import generate_api_key, get_current_user, login_required
from db import ASSETS_DIR, get_db

bp = Blueprint("web", __name__)


@bp.route("/")
def index():
    db = get_db()
    photos = db.execute(
        "SELECT photos.*, users.username FROM photos "
        "JOIN users ON photos.user_id = users.id "
        "ORDER BY photos.created_at DESC"
    ).fetchall()
    return render_template("index.html", photos=photos, user=get_current_user())


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html", user=get_current_user())

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")

    if not username or not password:
        flash("Username and password are required.", "error")
        return redirect(url_for("web.login"))

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()

    if user is None:
        flash("User not found.", "error")
        return redirect(url_for("web.login"))

    if len(password) < user["password_len"]:
        flash("Password too short.", "error")
        return redirect(url_for("web.login"))

    if len(password) > user["password_len"]:
        flash("Password too long.", "error")
        return redirect(url_for("web.login"))

    if hashlib.sha256(password.encode()).hexdigest() != user["password_hash"]:
        flash("Invalid credentials.", "error")
        return redirect(url_for("web.login"))

    session["user_id"] = user["id"]
    flash(f"Welcome back, {user['username']}!", "success")
    return redirect(url_for("web.settings"))


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "GET":
        return render_template("register.html", user=get_current_user())

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    bio = request.form.get("bio", "").strip()

    if not username or not password:
        flash("Username and password are required.", "error")
        return redirect(url_for("web.register"))

    if not re.match(r"^[a-zA-Z0-9_]{2,32}$", username):
        flash("Username must be 2-32 alphanumeric characters or underscores.", "error")
        return redirect(url_for("web.register"))

    if len(password) < 4 or len(password) > 128:
        flash("Password must be between 4 and 128 characters.", "error")
        return redirect(url_for("web.register"))

    db = get_db()
    if db.execute("SELECT id FROM users WHERE username = ?", (username,)).fetchone():
        flash("Username already taken.", "error")
        return redirect(url_for("web.register"))

    created_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    api_key = generate_api_key(username, created_at, password)
    pw_hash = hashlib.sha256(password.encode()).hexdigest()

    db.execute(
        "INSERT INTO users (username, password_hash, password_len, created_at, api_key, bio) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (username, pw_hash, len(password), created_at, api_key, bio),
    )
    db.commit()

    user = db.execute("SELECT * FROM users WHERE username = ?", (username,)).fetchone()
    session["user_id"] = user["id"]
    flash("Account created! Your API key is available in Settings.", "success")
    return redirect(url_for("web.settings"))


@bp.route("/profile/<username>")
def profile(username):
    db = get_db()
    prof = db.execute(
        "SELECT id, username, created_at, bio, is_admin FROM users WHERE username = ?",
        (username,),
    ).fetchone()
    if prof is None:
        abort(404)

    photos = db.execute(
        "SELECT * FROM photos WHERE user_id = ? ORDER BY created_at DESC",
        (prof["id"],),
    ).fetchall()

    return render_template("profile.html", profile=prof, photos=photos, user=get_current_user())


@bp.route("/members")
def members():
    db = get_db()
    users = db.execute(
        "SELECT username, created_at, bio, is_admin FROM users ORDER BY created_at ASC"
    ).fetchall()
    return render_template("members.html", members=users, user=get_current_user())


@bp.route("/settings")
@login_required
def settings():
    return render_template("settings.html", user=get_current_user())


@bp.route("/settings/password", methods=["POST"])
@login_required
def change_password():
    user = get_current_user()
    current_pw = request.form.get("current_password", "")
    new_pw = request.form.get("new_password", "")

    if hashlib.sha256(current_pw.encode()).hexdigest() != user["password_hash"]:
        flash("Current password is incorrect.", "error")
        return redirect(url_for("web.settings"))

    if len(new_pw) < 4 or len(new_pw) > 128:
        flash("New password must be between 4 and 128 characters.", "error")
        return redirect(url_for("web.settings"))

    db = get_db()
    new_hash = hashlib.sha256(new_pw.encode()).hexdigest()
    new_api_key = generate_api_key(user["username"], user["created_at"], new_pw)

    db.execute(
        "UPDATE users SET password_hash = ?, password_len = ?, api_key = ? WHERE id = ?",
        (new_hash, len(new_pw), new_api_key, user["id"]),
    )
    db.commit()

    flash("Password updated. Your API key has been regenerated.", "success")
    return redirect(url_for("web.settings"))


@bp.route("/assets/<path:filename>")
def serve_asset(filename):
    return send_from_directory(ASSETS_DIR, filename)


@bp.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("web.index"))
