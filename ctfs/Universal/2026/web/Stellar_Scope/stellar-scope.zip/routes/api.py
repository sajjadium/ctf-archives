from datetime import datetime

from flask import Blueprint, g, jsonify, request

from auth import api_auth_required
from db import get_db

bp = Blueprint("api", __name__, url_prefix="/api")


@bp.route("/me")
@api_auth_required
def me():
    u = g.api_user
    return jsonify({
        "id": u["id"],
        "username": u["username"],
        "created_at": u["created_at"],
        "bio": u["bio"],
        "api_key": u["api_key"],
    })


@bp.route("/gallery")
@api_auth_required
def gallery():
    rows = get_db().execute(
        "SELECT photos.id, photos.title, photos.description, photos.image, photos.created_at, users.username "
        "FROM photos JOIN users ON photos.user_id = users.id "
        "ORDER BY photos.created_at DESC"
    ).fetchall()
    return jsonify([dict(r) for r in rows])


@bp.route("/photos", methods=["POST"])
@api_auth_required
def upload_photo():
    data = request.get_json(silent=True) or {}
    title = data.get("title", "").strip()
    description = data.get("description", "").strip()

    if not title:
        return jsonify({"error": "Title is required"}), 400

    db = get_db()
    created_at = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        "INSERT INTO photos (user_id, title, description, created_at) VALUES (?, ?, ?, ?)",
        (g.api_user["id"], title, description, created_at),
    )
    db.commit()
    return jsonify({"message": "Photo uploaded"}), 201


@bp.route("/profile/<username>")
@api_auth_required
def profile(username):
    db = get_db()
    prof = db.execute(
        "SELECT id, username, created_at, bio, is_admin FROM users WHERE username = ?",
        (username,),
    ).fetchone()
    if prof is None:
        return jsonify({"error": "User not found"}), 404

    photos = db.execute(
        "SELECT id, title, description, image, created_at FROM photos WHERE user_id = ?",
        (prof["id"],),
    ).fetchall()

    return jsonify({
        "username": prof["username"],
        "created_at": prof["created_at"],
        "bio": prof["bio"],
        "is_admin": bool(prof["is_admin"]),
        "photos": [dict(p) for p in photos],
    })
