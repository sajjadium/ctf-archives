#define EXIT 0
#define WRITE 64
#define READ 63
#define MMAP 222
#define MUNMAP 215
#define OPEN 56
#define CLOSE 57
#define EXECVE 221

// #define DEBUG 2

static inline long long unsigned ecall(unsigned long long a7, unsigned long long a0, unsigned long long a1, unsigned long long a2, unsigned long long a3, unsigned long long a4, unsigned long long a5, unsigned long long a6)
{
    register unsigned long long int syscall_id asm("a7") = a7;
    register unsigned long long int arg0 asm("a0") = a0;
    register unsigned long long int arg1 asm("a1") = a1;
    register unsigned long long int arg2 asm("a2") = a2;
    register unsigned long long int arg3 asm("a3") = a3;
    register unsigned long long int arg4 asm("a4") = a4;
    register unsigned long long int arg5 asm("a5") = a5;
    register unsigned long long int arg6 asm("a6") = a6;
    register unsigned long long int a0_out asm("a0");
    asm volatile ("ecall"
        : "=r"(a0_out)
        : "r"(syscall_id), "r"(arg0), "r"(arg1), "r"(arg2), "r"(arg3), "r"(arg4), "r"(arg5), "r"(arg6)
    );

    return a0_out;
}

static inline long long unsigned Uread(int fd, char *buf, long long unsigned size)
{
    return ecall(READ, fd, (unsigned long long)buf, size, 0, 0, 0, 0);
}

static inline long long unsigned Uwrite(int fd, char *buf, long long unsigned size)
{
    return ecall(WRITE, fd, (unsigned long long)buf, size, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Uexit(unsigned status)
{
    ecall(EXIT, status, 0, 0, 0, 0, 0, 0);
}

static inline void *__attribute__((always_inline)) Ummap(void *addr, unsigned long long length, unsigned long long prot, unsigned long long flags, unsigned long long fd, unsigned long long offset)
{
    return (void *)ecall(MMAP, (unsigned long long)addr, length, prot, flags, fd, offset, 0);
}

static inline void __attribute__((always_inline)) Umunmap(void *addr, unsigned long long length)
{
    ecall(MUNMAP, (unsigned long long)addr, length, 0, 0, 0, 0, 0);
}

static inline int __attribute__((always_inline)) Uopen(char *path, unsigned long long flags)
{
    return ecall(OPEN, (unsigned long long)path, flags, 0, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Uclose(unsigned long long fd)
{
    ecall(CLOSE, fd, 0, 0, 0, 0, 0, 0);
}

static inline int __attribute__((always_inline)) Uexecve(char *path)
{
    return ecall(EXECVE, (unsigned long long)path, 0, 0, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Umprotect(void *addr, unsigned long long length, unsigned long long prot)
{
    ecall(MMAP, (unsigned long long)addr, length, prot, 0, 0, 0, 0);
}

#define NULL 0

static inline int strcmp(const char *s1, const char *s2)
{
    while (*s1 && *s2 && *s1 == *s2) {
        s1++;
        s2++;
    }
    return *s1 - *s2;
}

static inline long long unsigned strlen(const char *s)
{
    long long unsigned len = 0;
    while (*s) {
        len++;
        s++;
    }
    return len;
}

static inline char *strchr(const char *s, int c)
{
    while (*s) {
        if (*s == c) {
            return (char *)s;
        }
        s++;
    }
    return NULL;
}

static inline char *strtok(char *str, const char *delim)
{
    static char *last = NULL;
    if (str) {
        last = str;
    } else {
        if (!last) {
            return NULL;
        }
    }

    while (*last && strchr(delim, *last)) {
        last++;
    }

    if (!*last) {
        return NULL;
    }

    char *start = last;
    while (*last && !strchr(delim, *last)) {
        last++;
    }

    if (*last) {
        *last = '\0';
        last++;
    }

    return start;
}

static inline void *memcpy(void *dest, const void *src, unsigned long long n)
{
    char *d = (char *)dest;
    const char *s = (const char *)src;
    for (unsigned long long i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

static inline void printHex(int fd, unsigned long long int x)
{
    char buf[17];
    buf[16] = 0;
    for(int i = 15; i >= 0; i--) {
        buf[i] = "0123456789abcdef"[x & 0xf];
        x >>= 4;
    }
    Uwrite(fd, "0x", 2);
    Uwrite(fd, buf, 16);
    Uwrite(fd, "\n", 1);
}

typedef struct HeapAllocState {
    unsigned long long size;
    char data[];
};

typedef struct HeapFreeState {
    unsigned long long size;
    struct HeapFreeState *next, *prev;
};

typedef struct HeapChunk {
    union {
        struct HeapAllocState alloc;
        struct HeapFreeState free;
    };
};

typedef struct HeapHeader {
    void *heapSection;
    struct HeapFreeState *freeChunk;
}HeapHeader;

HeapHeader heap;

#define PROT_READ 1
#define PROT_WRITE 2
#define PROT_EXEC 4

void heap_alloc(unsigned long long size)
{
    heap.heapSection = Ummap(NULL, size, PROT_READ | PROT_WRITE, 0x22, -1, 0);
    if(heap.heapSection == (void *)-1) {
        Uwrite(2, "heap alloc failed\n", 18);
        Uexit(1);
    }
    heap.freeChunk = (struct HeapFreeState *)heap.heapSection;
    heap.freeChunk->size = size;
    heap.freeChunk->next = heap.freeChunk;
    heap.freeChunk->prev = heap.freeChunk;
}

void *malloc(unsigned long long size)
{
    size = (size + sizeof(struct HeapAllocState) + 0xf) & ~0xf;
    struct HeapFreeState *chunk = heap.freeChunk;
    struct HeapFreeState *victim = NULL;
    struct HeapAllocState *returnChunk = NULL;
    do {
        #if DEBUG > 1
            Uwrite(1, "chunk = ", 8);
            printHex(1, (unsigned long long int)chunk);
            Uwrite(1, "chunk->size = ", 14);
            printHex(1, chunk->size);
            Uwrite(1, "size = ", 7);
            printHex(1, size);
        #endif
        if(chunk->size >= size) {
            victim = chunk;
            break;
        }
        chunk = chunk->next;
    } while(chunk != heap.freeChunk);
    
    if(victim == NULL) {
        return NULL;
    }

    if(victim->size - size < sizeof(struct HeapFreeState) + 0x10) {
        victim->prev->next = victim->next;
        victim->next->prev = victim->prev;
        returnChunk = (struct HeapAllocState *)victim;
    } else {
        returnChunk = (struct HeapAllocState *)((char *)victim + victim->size - size);

        #if DEBUG > 1
            Uwrite(1, "victim = ", 9);
            printHex(1, (unsigned long long int)victim);
            Uwrite(1, "victim->size = ", 15);
            printHex(1, victim->size);
            Uwrite(1, "returnChunk = ", 14);
            printHex(1, (unsigned long long int)returnChunk);
        #endif
        
        returnChunk->size = size;
        victim->size -= size;
    }

    #if DEBUG > 1
        Uwrite(1, "returnChunk = ", 14);
        printHex(1, (unsigned long long int)returnChunk);
        Uwrite(1, "returnChunk->size = ", 20);
        printHex(1, returnChunk->size);
    #endif
    
    return (void *)(&returnChunk->data);
}

void free(void *ptr)
{
    if(ptr == NULL) {
        return;
    }
    struct HeapFreeState *chunk = (struct HeapFreeState *)((char *)ptr - sizeof(struct HeapAllocState));
    chunk->next = heap.freeChunk;
    chunk->prev = heap.freeChunk->prev;
    heap.freeChunk->prev->next = chunk;
    heap.freeChunk->prev = chunk;
}

void *realloc(void *ptr, unsigned long long size)
{
    struct HeapFreeState *chunk = (struct HeapFreeState *)((char *)ptr - sizeof(struct HeapAllocState));
    if(size == 0) {
        free(ptr);
        return NULL;
    }

    size = (size + sizeof(struct HeapAllocState) + 0xf) & ~0xf;
    if (chunk->size >= size) {
        return ptr;
    }

    void *newPtr = malloc(size);
    if(newPtr == NULL) {
        return NULL;
    }
    memcpy(newPtr, ptr, chunk->size);
    free(ptr);
    return newPtr;
}

#define ull unsigned long long int
#define STDIN 0
#define STDOUT 1
#define STDERR 2

typedef struct Note {
    ull size;
    char *data;
} Note;

Note *notes[0x100] = {0, };

ull strtoull(const char *nptr, char **endptr, int base) {
    ull result = 0;
    while(*nptr) {
        if(*nptr >= '0' && *nptr <= '9') {
            result = result * base + *nptr - '0';
        } else if(*nptr >= 'a' && *nptr <= 'f') {
            result = result * base + *nptr - 'a' + 10;
        } else if(*nptr >= 'A' && *nptr <= 'F') {
            result = result * base + *nptr - 'A' + 10;
        } else {
            break;
        }
        nptr++;
    }
    if(endptr) {
        *endptr = (char *)nptr;
    }
    return result;
}

ull readull() {
    char buf[0x10];
    Uread(STDIN, buf, 0x10);
    return strtoull(buf, NULL, 10);
}

void make_note()
{
    ull idx = 0;
    Uwrite(STDOUT, "idx: ", 5);
    idx = readull();

    if (idx >= 0x100) {
        Uwrite(STDOUT, "invalid idx\n", 12);
        return;
    }

    if (notes[idx]) {
        Uwrite(STDOUT, "already exist\n", 14);
        return;
    }

    ull size = 0;
    Uwrite(STDOUT, "size: ", 6);
    size = readull();
    if (size > 0x1000) {
        Uwrite(STDOUT, "too big\n", 8);
        return;
    }

    notes[idx] = (Note *)malloc(sizeof(Note));
    notes[idx]->size = size;
    notes[idx]->data = (char *)malloc(size);

    Uwrite(STDOUT, "data: ", 6);
    Uread(STDIN, notes[idx]->data, size);
}

void view_note()
{
    ull idx = 0;
    Uwrite(STDOUT, "idx: ", 5);
    idx = readull();

    if (idx >= 0x100) {
        Uwrite(STDOUT, "invalid idx\n", 12);
        return;
    }

    if (!notes[idx]) {
        Uwrite(STDOUT, "not exist\n", 10);
        return;
    }

    Uwrite(STDOUT, "data: ", 6);
    Uwrite(STDOUT, notes[idx]->data, notes[idx]->size);
}

void delete_note()
{
    ull idx = 0;
    Uwrite(STDOUT, "idx: ", 5);
    idx = readull();

    if (idx >= 0x100) {
        Uwrite(STDOUT, "invalid idx\n", 12);
        return;
    }

    if (!notes[idx]) {
        Uwrite(STDOUT, "not exist\n", 10);
        return;
    }

    free(notes[idx]->data);
    free(notes[idx]);
    notes[idx] = NULL;
}

void edit_note()
{
    ull idx = 0, size;
    Uwrite(STDOUT, "idx: ", 5);
    idx = readull();

    if (idx >= 0x100) {
        Uwrite(STDOUT, "invalid idx\n", 12);
        return;
    }

    if (!notes[idx]) {
        Uwrite(STDOUT, "not exist\n", 10);
        return;
    }

    Uwrite(STDOUT, "size: ", 6);
    size = readull();

    if (size > 0x1000) {
        Uwrite(STDOUT, "too big\n", 8);
        return;
    }

    if(size > notes[idx]->size) {
        notes[idx]->data = (char *)realloc(notes[idx]->data, size);
    }
    notes[idx]->size = size;
    Uwrite(STDOUT, "data: ", 6);
    Uread(STDIN, notes[idx]->data, size);
}

void dump_addr(int fd)
{
    Uwrite(STDOUT, "start: ", 7);
    ull start = readull();
    Uwrite(STDOUT, "end: ", 5);
    ull end = readull();
    for (ull i = start; i < end; i+=8) {
        printHex(fd, *(unsigned long long *)i);
    }
}

void __attribute__((section (".text.startup_code"))) _start() 
{
    heap_alloc(0x100000);

    Uwrite(STDOUT, "usual note challenge!\n", 22);
    Uwrite(STDOUT, "but... careful about the architecture!\n", 39);

    while(1) {
        ull cmd = 0;
        Uwrite(STDOUT, "1. make note\n", 13);
        Uwrite(STDOUT, "2. view note\n", 13);
        Uwrite(STDOUT, "3. delete note\n", 15);
        Uwrite(STDOUT, "4. edit note\n", 13);
        Uwrite(STDOUT, "5. exit\n", 8);
        Uwrite(STDOUT, "> ", 2);
        cmd = readull();

        switch(cmd) {
            case 1: 
                make_note();
                break;
            case 2:
                view_note();
                break;
            case 3:
                delete_note();
                break;
            case 4:
                edit_note();
                break;
            case 5:
                Uexit(0);
                break;
            default:
                Uwrite(STDOUT, "invalid cmd\n", 12);
                return;
            #if DEBUG
            case 1337:
                dump_addr(STDOUT);
            #endif
        }
    }
}