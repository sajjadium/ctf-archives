#include <bits/stdc++.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>

#include "vapa.hpp"

using namespace std;

typedef long long int ll;
typedef long long unsigned int ull;

class MTAlloc : public VaMemory {
private:
    #if DEBUG
        int debugLogLevel = 0;
    #endif

    void fatal(ostringstream &oss, int exitCode = 1) {
        cerr << "MTAlloc::Fatal: ";
        cerr << oss.str() << endl;
        _exit(1);
    }

    void warn(ostringstream &oss) {
        cerr << "MTAlloc::Warn: ";
        cerr << oss.str() << endl;
    }

    #if DEBUG
    void debugLogTab() {
        for (int i = 0; i < debugLogLevel; i++) {
            cout << "    ";
        }
    }

    void prefix(const char *msg = "") {
        debugLogTab();
        cout << "MTAlloc::" << msg << ": " << endl;
        debugLogLevel++;
    }

    void debugLog(ostringstream &oss) {
        debugLogTab();
        cout << oss.str();
    }

    void suffix(const char *msg = "") {
        debugLogTab();
        cout << msg << endl;
        debugLogLevel--;
    }
    #endif

public:
    MTAlloc() {
    }

    ~MTAlloc() {
    }

    void *mmap(void *va, uint64_t length, int prot, int flags, int fd, int offset, uint64_t map_level=1) {
        return VaMemoryAlloc(va, length, (Flags::Permission)prot, map_level);
    }

    void munmap(void *va, uint64_t length) {
        VaMemoryFree(va, length);
    }

    void mprotect(void *va, uint64_t length, int prot) {
        VaMemoryPermissionChange(va, length, (Flags::Permission)prot);
    }

    void read(void *va, uint64_t size, char *data, bool isHiLevel = false, bool isExec = false) {
        for(int i = 0; i < size; i++) {
            data[i] = VaMemoryRead(va + i, 1, isExec ? (Flags::Permission::EXEC | Flags::Permission::READ) : Flags::Permission::READ, isHiLevel);
        }
    }

    void write(void *va, uint64_t size, char *data, bool isHiLevel = false) {
        for(int i = 0; i < size; i++) {
            VaMemoryWrite((VirtualAddress)va + i, data[i], 1, Flags::Permission::WRITE, isHiLevel);
        }
    }
};

namespace VMInsts {
    typedef enum OpcodeMap {
        LUI = 0b0110111,
        AUIPC = 0b0010111,
        JAL = 0b1101111,
        JALR = 0b1100111,
        BRANCH = 0b1100011,
        LOAD = 0b0000011,
        STORE = 0b0100011,
        OP_IMM = 0b0010011,
        OP = 0b0110011,
        MISC_MEM = 0b0001111,
        SYSTEM = 0b1110011,

        OP_IMM_32 = 0b0011011,
        OP_32 = 0b0111011,
    };

    typedef enum OpType {
        R = 0, I, S, B, U, J
    };

    typedef enum SyscallOp {
        READ = 63,
        WRITE = 64,
        EXIT = 93,
        MMAP = 222,
        MUNMAP = 215,
        MPROTECT = 226,
    };

    class Instruction {
    private:
        typedef struct RType {
            uint32_t opcode : 7;
            uint32_t rd : 5;
            uint32_t funct3 : 3;
            uint32_t rs1 : 5;
            uint32_t rs2 : 5;
            uint32_t funct7 : 7;
        } RType;

        typedef struct IType {
            uint32_t opcode : 7;
            uint32_t rd : 5;
            uint32_t funct3 : 3;
            uint32_t rs1 : 5;
            uint32_t imm : 12;
        } IType;

        typedef struct SType {
            uint32_t opcode : 7;
            uint32_t imm_04_00 : 5;
            uint32_t funct3 : 3;
            uint32_t rs1 : 5;
            uint32_t rs2 : 5;
            uint32_t imm_11_05 : 7;
        } SType;

        typedef struct BType {
            uint32_t opcode : 7;
            uint32_t imm_11 : 1;
            uint32_t imm_04_01 : 4;
            uint32_t funct3 : 3;
            uint32_t rs1 : 5;
            uint32_t rs2 : 5;
            uint32_t imm_10_05 : 6;
            uint32_t imm_12 : 1;
        };

        typedef struct UType {
            uint32_t opcode : 7;
            uint32_t rd : 5;
            uint32_t imm_12_31 : 20;
        };

        typedef struct JType {
            uint32_t opcode : 7;
            uint32_t rd : 5;
            uint32_t imm_19_12 : 8;
            uint32_t imm_11 : 1;
            uint32_t imm_10_01 : 10;
            uint32_t imm_20 : 1;
        };

        typedef union Inst {
            RType R;
            IType I;
            SType S;
            BType B;
            UType U;
            JType J;
        };

        Inst inst;

    public:
        Instruction (uint32_t inst) {
            this->inst = *(Inst *)&inst;
        }

        OpcodeMap getOpcode() {
            return (OpcodeMap)inst.R.opcode;
        }

        OpType getOpType() {
            switch (inst.R.opcode) {
                case LUI:
                case AUIPC:
                    return U;
                case JAL:
                    return J;
                case JALR:
                    return I;
                case BRANCH:
                    return B;
                case LOAD:
                    return I;
                case STORE:
                    return S;
                case OP_IMM:
                    return I;
                case OP:
                    return R;
                case MISC_MEM:
                    return I;
                case SYSTEM:
                    return I;
                case OP_IMM_32:
                    return I;
                case OP_32:
                    return R;
                default:
                    return I;
            }
        }

        uint64_t getFunct7() {
            return inst.R.funct7;
        }

        uint64_t getFunct3() {
            switch (getOpType()) {
                case R:
                case I:
                case S:
                case B:
                    return inst.R.funct3;
                default:
                    return 0;
            }
        }

        uint64_t getImm() {
            uint64_t imm = 0;
            switch (getOpType()) {
                case I:
                    imm = inst.I.imm;
                    if (imm & 0x800) {
                        imm |= 0xfffffffffffff000;
                    }
                    break;
                case S:
                    imm = (inst.S.imm_11_05 << 5) | inst.S.imm_04_00;
                    if (imm & 0x800) {
                        imm |= 0xfffffffffffff000;
                    }
                    break;
                case B:
                    imm = (inst.B.imm_12 << 12) | (inst.B.imm_11 << 11) | (inst.B.imm_10_05 << 5) | (inst.B.imm_04_01 << 1);
                    if (imm & 0x1000) {
                        imm |= 0xffffffffffffe000;
                    }
                    break;
                case U:
                    imm = inst.U.imm_12_31 << 12;
                    break;
                case J:
                    imm = (inst.J.imm_20 << 20) | (inst.J.imm_19_12 << 12) | (inst.J.imm_11 << 11) | (inst.J.imm_10_01 << 1);
                    if (imm & 0x100000) {
                        imm |= 0xfffffffffff00000;
                    }
                    break;
            }
            return imm;
        }

        uint64_t getRD() {
            switch (getOpType()) {
                case R:
                case I:
                case U:
                case J:
                    return inst.R.rd;
                case S:
                case B:
                    return -1;
            }
        }

        uint64_t getRS1() {
            switch (getOpType()) {
                case R:
                case I:
                case S:
                case B:
                    return inst.R.rs1;
                default:
                    return -1;
            }
        }

        uint64_t getRS2() {
            switch (getOpType()) {
                case R:
                case S:
                case B:
                    return inst.R.rs2;
                default:
                    return -1;
            }
        }
    };
}

class ELFParser {
public:
    typedef uint16_t Elf64_Half;
    typedef int16_t Elf64_SHalf;
    typedef uint32_t Elf64_Word;
    typedef int32_t Elf64_Sword;
    typedef uint64_t Elf64_Xword;
    typedef int64_t Elf64_Sxword;

    typedef uint64_t Elf64_Off;
    typedef uint64_t Elf64_Addr;
    typedef uint16_t Elf64_Section;

    // 64bit ELF Header
    struct ELFHEADER {
        uint8_t ident[16];
        uint16_t type;
        uint16_t machine;
        uint32_t version;
        uint64_t entry;
        uint64_t phoff;
        uint64_t shoff;
        uint32_t flags;
        uint16_t ehsize;
        uint16_t phentsize;
        uint16_t phnum;
        uint16_t shentsize;
        uint16_t shnum;
        uint16_t shstrndx;
    } __attribute__((packed)) ELFHeader;

    struct Elf64_Phdr {
        Elf64_Word p_type;   
        Elf64_Word p_flags;  
        Elf64_Off p_offset;  
        Elf64_Addr p_vaddr;  
        Elf64_Addr p_paddr;  
        Elf64_Xword p_filesz;
        Elf64_Xword p_memsz; 
        Elf64_Xword p_align; 
    } __attribute__((packed));

    typedef struct Elf64_Shdr {
        Elf64_Word sh_name;
        Elf64_Word sh_type;
        Elf64_Xword sh_flags;
        Elf64_Addr sh_addr;
        Elf64_Off sh_offset;
        Elf64_Xword sh_size;
        Elf64_Word sh_link;
        Elf64_Word sh_info;
        Elf64_Xword sh_addralign;
        Elf64_Xword sh_entsize;
    } __attribute__((packed));

private:
    string data;

    typedef enum EL {
        EL_MAG = 0, EL_MAG1, EL_MAG2, EL_MAG3, // 4
        EL_CLASS = 4, // 1
        EL_DATA = 5, // 1
        EL_VERSION = 6, // 1
        EL_OSABI = 7, // 1
        EL_ABIVERSION = 8, // 1
        EL_PAD = 9, // 7
    };

    vector<Elf64_Phdr> ELFProgramHeaders;
    vector<Elf64_Shdr> ELFSectionHeaders;

    void fatal(ostringstream &oss) {
        cerr << "ELFParser::Fatal: ";
        cerr << oss.str();
        cerr << endl;
        _exit(1);
    }

public:
    void parse() {
        if (data.size() < sizeof(ELFHeader)) {
            ostringstream oss;
            oss << "Invalid ELF file";
            fatal(oss);
        }

        memcpy(&ELFHeader, &data[0], sizeof(ELFHeader));
        if (ELFHeader.ident[EL::EL_MAG] != 0x7f || ELFHeader.ident[EL::EL_MAG1] != 'E' || ELFHeader.ident[EL::EL_MAG2] != 'L' || ELFHeader.ident[EL::EL_MAG3] != 'F') {
            ostringstream oss;
            oss << "Invalid ELF file";
            fatal(oss);
        }

        if (ELFHeader.ident[EL::EL_CLASS] != 2) {
            ostringstream oss;
            oss << "Invalid ELF file: Not 64-bit";
            fatal(oss);
        }

        if (ELFHeader.ident[EL::EL_DATA] != 1) {
            ostringstream oss;
            oss << "Invalid ELF file: Not little endian";
            fatal(oss);
        }

        if (ELFHeader.type != 2) {
            ostringstream oss;
            oss << "Invalid ELF file: Not executable";
            fatal(oss);
        }

        if (ELFHeader.machine != 0xf3) {
            ostringstream oss;
            oss << "Invalid ELF file: Not RISC-V";
            fatal(oss);
        }

        if (ELFHeader.version != 1) {
            ostringstream oss;
            oss << "Invalid ELF file: Not version 1";
            fatal(oss);
        }

        if (ELFHeader.phentsize != sizeof(Elf64_Phdr)) {
            ostringstream oss;
            oss << "Invalid ELF file: Program header size mismatch";
            fatal(oss);
        }

        if (ELFHeader.shentsize != sizeof(Elf64_Shdr)) {
            ostringstream oss;
            oss << "Invalid ELF file: Section header size mismatch";
            fatal(oss);
        }

        if (ELFHeader.shstrndx >= ELFHeader.shnum) {
            ostringstream oss;
            oss << "Invalid ELF file: Invalid section header string table index";
            fatal(oss);
        }

        #if ELFPARSER_DEBUG
        cout << hex;
        cout << "ELF Header:" << endl;
        cout << "Type: 0x" << ELFHeader.type << endl;
        cout << "Machine: 0x" << ELFHeader.machine << endl;
        cout << "Version: 0x" << ELFHeader.version << endl;
        cout << "Entry: 0x" << ELFHeader.entry << endl;
        cout << "Phoff: 0x" << ELFHeader.phoff << endl;
        cout << "Shoff: 0x" << ELFHeader.shoff << endl;
        cout << "Flags: 0x" << ELFHeader.flags << endl;
        cout << "Ehsize: 0x" << ELFHeader.ehsize << endl;
        cout << "Phentsize: 0x" << ELFHeader.phentsize << endl;
        cout << "Phnum: 0x" << ELFHeader.phnum << endl;
        cout << "Shentsize: 0x" << ELFHeader.shentsize << endl;
        cout << "Shnum: 0x" << ELFHeader.shnum << endl;
        cout << "Shstrndx: 0x" << ELFHeader.shstrndx << endl;
        #endif

        ELFProgramHeaders.resize(ELFHeader.phnum);
        for(int i = 0; i < ELFHeader.phnum; i++) {
            memcpy(&ELFProgramHeaders[i], &data[ELFHeader.phoff + i * sizeof(Elf64_Phdr)], sizeof(Elf64_Phdr));
        }

        ELFSectionHeaders.resize(ELFHeader.shnum);
        for(int i = 0; i < ELFHeader.shnum; i++) {
            memcpy(&ELFSectionHeaders[i], &data[ELFHeader.shoff + i * sizeof(Elf64_Shdr)], sizeof(Elf64_Shdr));
        }

        #if ELFPARSER_DEBUG
        cout << hex << endl << endl;
        cout << "ELF Program Headers:" << endl;
        for(int i = 0; i < ELFHeader.phnum; i++) {
            cout << "Type: 0x" << ELFProgramHeaders[i].p_type << endl;
            cout << "Flags: 0x" << ELFProgramHeaders[i].p_flags << endl;
            cout << "Offset: 0x" << ELFProgramHeaders[i].p_offset << endl;
            cout << "Vaddr: 0x" << ELFProgramHeaders[i].p_vaddr << endl;
            cout << "Paddr: 0x" << ELFProgramHeaders[i].p_paddr << endl;
            cout << "Filesz: 0x" << ELFProgramHeaders[i].p_filesz << endl;
            cout << "Memsz: 0x" << ELFProgramHeaders[i].p_memsz << endl;
            cout << "Align: 0x" << ELFProgramHeaders[i].p_align << endl;
            cout << endl;
        }
        #endif

        #if ELFPARSER_DEBUG
        cout << hex << endl << endl;
        cout << "ELF Section Headers:" << endl;
        for(int i = 0; i < ELFHeader.shnum; i++) {
            cout << "Name: " << &data[ELFSectionHeaders[i].sh_name] << endl;
            cout << "Type: 0x" << ELFSectionHeaders[i].sh_type << endl;
            cout << "Flags: 0x" << ELFSectionHeaders[i].sh_flags << endl;
            cout << "Addr: 0x" << ELFSectionHeaders[i].sh_addr << endl;
            cout << "Offset: 0x" << ELFSectionHeaders[i].sh_offset << endl;
            cout << "Size: 0x" << ELFSectionHeaders[i].sh_size << endl;
            cout << "Link: 0x" << ELFSectionHeaders[i].sh_link << endl;
            cout << "Info: 0x" << ELFSectionHeaders[i].sh_info << endl;
            cout << "Addralign: 0x" << ELFSectionHeaders[i].sh_addralign << endl;
            cout << "Entsize: 0x" << ELFSectionHeaders[i].sh_entsize << endl;
            cout << endl;
        }
        #endif
    }

    ELFParser(ifstream &bin) {
        bin.seekg(0, ios::end);
        data.resize(bin.tellg());
        bin.seekg(0, ios::beg);
        bin.read(&data[0], data.size());
    }

    uint64_t getProgramHeaderSize() {
        return ELFHeader.phnum;
    }

    uint64_t getSectionHeaderSize() {
        return ELFHeader.shnum;
    }

    Elf64_Phdr getProgramHeaderAt(uint64_t index) {
        return ELFProgramHeaders[index];
    }

    Elf64_Shdr getSectionHeaderAt(uint64_t index) {
        return ELFSectionHeaders[index];
    }

    string getProgramAt(uint64_t index) {
        return data.substr(ELFProgramHeaders[index].p_offset, ELFProgramHeaders[index].p_filesz);
    }

    string getSectionAt(uint64_t index) {
        return data.substr(ELFSectionHeaders[index].sh_offset, ELFSectionHeaders[index].sh_size);
    }
};

class VM {
private:
    MTAlloc mtalloc;

    uint64_t kbase;
    uint64_t pc;
    uint64_t *reg, *csr;

    typedef enum Reg {
        x0 = 0, ra, sp, gp, tp, 
        t0, t1, t2,
        s0, s1,
        a0, a1, a2, a3, a4, a5, a6, a7, 
        s2, s3, s4, s5, s6, s7, s8, s9, s10, s11,
        t3, t4, t5, t6
    };

    typedef enum CSR {
        mstatus = 0x300,
        mtvec = 0x305,
        mepc = 0x341,
        mcause = 0x342,
        mtval = 0x343,
        mip = 0x344,
        mie = 0x304,
        mscratch = 0x340,

        mmmioread = 0x7c0,
        mmmiowrite = 0x7c1,
        mmap = 0x7c2,
        munmap = 0x7c3,
        mopen = 0x7c4,
        mclose = 0x7c5,
        mprotect = 0x7c6,
    };

    typedef enum Privilege {
        M = 3,
        H = 2,
        S = 1,
        U = 0
    };

    typedef struct MTVEC {
        uint64_t mode: 6;
        uint64_t base: 64 - 6;
    };

    typedef struct MEPC {
        uint64_t base: 64;
    };

    typedef struct MCAUSE {
        uint64_t execptionCode: 12;
        uint64_t reserved1: 16 - 12;
        uint64_t mpil: 24 - 16;
        uint64_t reserved2: 27 - 24;
        uint64_t mpie: 28 - 27;
        uint64_t mpp: 30 - 28;
        uint64_t minhv: 31 - 30;
        uint64_t interrupt: 32 - 31;
    };

    void fatal(ostringstream &oss) {
        cerr << "VM::Fatal: ";
        cerr << oss.str();
        _exit(1);
    }

    #if DEBUG
    string printRegName(int i) {
        if(i == Reg::x0) return "x0";
        if(i == Reg::ra) return "ra";
        if(i == Reg::sp) return "sp";
        if(i == Reg::gp) return "gp";
        if(i == Reg::tp) return "tp";
        if(i == Reg::t0) return "t0";
        if(i == Reg::t1) return "t1";
        if(i == Reg::t2) return "t2";
        if(i == Reg::s0) return "s0";
        if(i == Reg::s1) return "s1";
        if(i == Reg::a0) return "a0";
        if(i == Reg::a1) return "a1";
        if(i == Reg::a2) return "a2";
        if(i == Reg::a3) return "a3";
        if(i == Reg::a4) return "a4";
        if(i == Reg::a5) return "a5";
        if(i == Reg::a6) return "a6";
        if(i == Reg::a7) return "a7";
        if(i == Reg::s2) return "s2";
        if(i == Reg::s3) return "s3";
        if(i == Reg::s4) return "s4";
        if(i == Reg::s5) return "s5";
        if(i == Reg::s6) return "s6";
        if(i == Reg::s7) return "s7";
        if(i == Reg::s8) return "s8";
        if(i == Reg::s9) return "s9";
        if(i == Reg::s10) return "s10";
        if(i == Reg::s11) return "s11";
        if(i == Reg::t3) return "t3";
        if(i == Reg::t4) return "t4";
        if(i == Reg::t5) return "t5";
        if(i == Reg::t6) return "t6";
        return "unknown";
    }
    #endif

    uint64_t randRange(uint64_t start, uint64_t end) {
        ifstream urandom("/dev/urandom", ios::in | ios::binary);
        if (!urandom) {
            ostringstream oss;
            oss << "Failed to open /dev/urandom";
            fatal(oss);
        }

        uint64_t r;
        urandom.read((char *)&r, sizeof(r));
        urandom.close();

        return (start + r % (end - start))&(~0xfff);
    }

    void interruptHandlerCallFromECALL() {
        csr[CSR::mepc] = pc;
        *(struct MCAUSE *)(&csr[CSR::mcause]) = {0x80000007, 0, 0, 0, 0, csr[CSR::mstatus], 0, 0};
        csr[CSR::mstatus] = Privilege::M;

        pc = csr[CSR::mtvec];
        swap(reg[Reg::sp], csr[CSR::mscratch]);

        #if DEBUG
            cout << "Interrupt Handler Called" << endl;
            cout << "MEPC: " << hex << csr[CSR::mepc] << endl;
            cout << "MCAUSE: " << hex << csr[CSR::mcause] << endl;
            cout << "MSTATUS: " << hex << csr[CSR::mstatus] << endl;
            cout << "MSCRATCH: " << hex << csr[CSR::mscratch] << endl;
            cout << "SP: " << hex << reg[Reg::sp] << endl;
            cout << "PC: "  << hex << pc << endl;
        #endif
    }

    void runCSRR(VMInsts::Instruction &inst) {
        uint64_t imm = inst.getImm();
        uint64_t csrPr = (imm >> 8) & 0x3;

        #if DEBUG
            cout << "CSRR: " << printRegName(inst.getRS1()) << ", 0x" << hex << imm << endl;
        #endif

        if(csr[CSR::mstatus] < csrPr) {
            ostringstream oss;
            oss << "Privilege level is less than CSR privilege level";
            fatal(oss);
        }

        // general purpose CSR
        if(imm == CSR::mmmioread) {
            uint64_t cnt = 0;
            char c;
            for(int i=0; i<reg[Reg::a2]; i++) {
                if(mtalloc.VaMemoryExist((void *)reg[Reg::a1] + i)) {
                    if(::read(reg[Reg::a0], &c, 1) <= 0) {
                        break;
                    }
                    mtalloc.write((void *)reg[Reg::a1] + i, 1, &c, csr[CSR::mstatus] > 0);
                    cnt++;
                } else {
                    break;
                }
            }
            reg[Reg::a0] = cnt;
            return;
        } else if(imm == CSR::mmmiowrite) {
            uint64_t cnt = 0;
            char c;
            for(int i=0; i<reg[Reg::a2]; i++) {
                if(mtalloc.VaMemoryExist((void *)reg[Reg::a1] + i)) {
                    mtalloc.read((void *)reg[Reg::a1] + i, 1, &c, csr[CSR::mstatus] > 0);
                    if(::write(reg[Reg::a0], &c, 1) <= 0) {
                        break;
                    }
                    cnt++;
                } else {
                    break;
                }
            }
            reg[Reg::a0] = cnt;
            return;
        } else if(imm == CSR::mmap) {
            if(reg[Reg::a0] == 0) {
                reg[Reg::a0] = randRange(0xffff000000000000, 0xffff800000000000);
            }
            // ignore flags, fd and offset for security
            reg[Reg::a0] = (uint64_t)mtalloc.mmap((void *)reg[Reg::a0], reg[Reg::a1], reg[Reg::a2], MAP_PRIVATE | MAP_ANONYMOUS, -1, 0, reg[Reg::a6]);
            #if DEBUG
                cout << "MMAP: 0x" << hex << reg[Reg::a0] << ", size: 0x" << reg[Reg::a1] << ", prot: 0x" << reg[Reg::a2] << endl;
            #endif
            return;
        } else if(imm == CSR::munmap) {
            #if DEBUG
                cout << "MUNMAP: 0x" << hex << reg[Reg::a0] << ", size: 0x" << reg[Reg::a1] << endl;
            #endif
            if(mtalloc.VaMemoryExist((void *)reg[Reg::a0])) {
                mtalloc.munmap((void *)reg[Reg::a0], reg[Reg::a1]);
            }
            return;
        } else if(imm == CSR::mopen) {
            #if DEBUG
                cout << "MOPEN: " << reg[Reg::a0] << ", flags: 0x" << hex << reg[Reg::a1] << ", mode: 0x" << hex << reg[Reg::a2] << endl;
            #endif
            string path;
            for(int i=0; i<0x1000; i++) {
                char c;
                mtalloc.read((void *)reg[Reg::a0] + i, 1, &c, csr[CSR::mstatus] > 0);
                path += c;
                if(path.back() == '\0') {
                    reg[Reg::a0] = ::open(path.c_str(), reg[Reg::a1], reg[Reg::a2]);
                    return;
                }
            }
            reg[Reg::a0] = -1;
            return;
        } else if(imm == CSR::mclose) {
            #if DEBUG
                cout << "MCLOSE: 0x" << hex << reg[Reg::a0] << endl;
            #endif
            ::close(reg[Reg::a0]);
            return;
        } else if(imm == CSR::mprotect) {
            #if DEBUG
                cout << "MPROTECT: 0x" << hex << reg[Reg::a0] << ", size: 0x" << reg[Reg::a1] << ", prot: 0x" << hex << reg[Reg::a2] << endl;
            #endif
            if(mtalloc.VaMemoryExist((void *)reg[Reg::a0])) {
                mtalloc.mprotect((void *)reg[Reg::a0], reg[Reg::a1], reg[Reg::a2]);
            }
            return;
        }

        // others
        uint64_t rs1v = reg[inst.getRS1()];
        reg[inst.getRD()] = csr[imm];
        switch (inst.getFunct3()) {
            case 0b001: // CSRRW
                csr[imm] = rs1v;
                break;
            case 0b010: // CSRRS
                csr[imm] |= rs1v;
                break;
            case 0b011: // CSRRC
                csr[imm] &= ~rs1v;
                break;
        }
    }

    void runCSRRI(VMInsts::Instruction &inst) {
        uint64_t imm = inst.getImm();
        uint64_t csrPr = (imm >> 8) & 0x3;

        #if DEBUG
            cout << "CSRRI: " << printRegName(inst.getRS1()) << ", 0x" << hex << imm << endl;
        #endif

        if(csr[CSR::mstatus] < csrPr) {
            ostringstream oss;
            oss << "Privilege level is less than CSR privilege level";
            fatal(oss);
        }

        // others
        uint64_t rs1v = reg[inst.getRS1()];
        reg[inst.getRD()] = csr[imm];
        switch (inst.getFunct3()) {
            case 0b101: // CSRRWI
                csr[imm] = rs1v;
                break;
            case 0b110: // CSRRSI
                csr[imm] |= rs1v;
                break;
            case 0b111: // CSRRCI
                csr[imm] &= ~rs1v;
                break;
        }
    }

    void runSRET() {
        if (csr[CSR::mstatus] >= Privilege::S) {
            pc = csr[CSR::mepc];
            csr[CSR::mstatus] = (csr[CSR::mcause] >> 28) & 0x3;
            swap(reg[Reg::sp], csr[CSR::mscratch]);
        } else {
            ostringstream oss;
            oss << "Privilege level is less than S";
            fatal(oss);
        }
    }

    void runMRET() {
        if (csr[CSR::mstatus] >= Privilege::M) {
            pc = csr[CSR::mepc];
            csr[CSR::mstatus] = (csr[CSR::mcause] >> 28) & 0x3;
            swap(reg[Reg::sp], csr[CSR::mscratch]);

            #if DEBUG
                cout << "MRET: PC: 0x" << hex << pc << endl;
                cout << "MSTATUS: 0x" << hex << csr[CSR::mstatus] << endl;
                cout << "MSCRATCH: 0x" << hex << csr[CSR::mscratch] << endl;
                cout << "SP: 0x" << hex << reg[Reg::sp] << endl;
            #endif
        } else {
            ostringstream oss;
            oss << "Privilege level is less than M";
            fatal(oss);
        }
    }

    void runLUI(VMInsts::Instruction &inst) {
        #if DEBUG
            cout << "LUI: " << printRegName(inst.getRD()) << " = 0x" << inst.getImm() << endl;
        #endif
        reg[inst.getRD()] = inst.getImm();
    }

    void runAUIPC(VMInsts::Instruction &inst) {
        #if DEBUG
            cout << "AUIPC: " << printRegName(inst.getRD()) << " = 0x" << pc + inst.getImm() << endl;
        #endif
        reg[inst.getRD()] = pc + inst.getImm() - 4;
    }

    void runJAL(VMInsts::Instruction &inst) {
        #if DEBUG
            cout << "JAL: " << printRegName(inst.getRD()) << " = 0x" << pc + 4 << ", PC = 0x" << pc + inst.getImm() - 4 << endl;
        #endif
        reg[inst.getRD()] = pc;
        pc += inst.getImm() - 4;
    }

    void runJALR(VMInsts::Instruction &inst) {
        #if DEBUG
            cout << "JALR: " << printRegName(inst.getRD()) << " = 0x" << pc + 4 << ", PC = 0x" << (reg[inst.getRS1()] + inst.getImm()) << endl;
        #endif
        reg[inst.getRD()] = pc;
        pc = reg[inst.getRS1()] + inst.getImm();
    }

    void runBRANCH(VMInsts::Instruction &inst) {
        uint64_t rs1 = reg[inst.getRS1()];
        uint64_t rs2 = reg[inst.getRS2()];
        switch (inst.getFunct3()) {
            case 0b000: // BEQ
                if (rs1 == rs2) {
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BEQ: 0x" << rs1 << " == 0x" << rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
            case 0b001: // BNE
                if (rs1 != rs2) {
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BNE: 0x" << rs1 << " != 0x" << rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
            case 0b100: // BLT
                if ((int64_t)rs1 < (int64_t)rs2) {
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BLT: 0x" << (int64_t)rs1 << " < 0x" << (int64_t)rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
            case 0b101: // BGE
                if ((int64_t)rs1 >= (int64_t)rs2) {
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BGE: 0x" << (int64_t)rs1 << " >= 0x" << (int64_t)rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
            case 0b110: // BLTU
                if (rs1 < rs2){
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BLTU: 0x" << rs1 << " < 0x" << rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
            case 0b111: // BGEU
                if (rs1 >= rs2) {
                    pc += inst.getImm() - 4;
                    #if DEBUG
                        cout << "BGEU: 0x" << rs1 << " >= 0x" << rs2 << " -> Taken to 0x" << pc << endl;
                    #endif
                }
                break;
        }
        #if DEBUG
            cout << "BRANCH: Fin" << endl;
        #endif
    }
    
    void runLOAD(VMInsts::Instruction &inst) {
        // reg[inst.getRD()] = 0x0;
        uint64_t data = 0;
        switch(inst.getFunct3()) {
            case 0b000: // LB
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 1, (char *)&data, csr[CSR::mstatus] > 0);
                if(data & 0x80) {
                    data |= 0xffffffffffffff00;
                }
                break;
            case 0b001: // LH
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 2, (char *)&data, csr[CSR::mstatus] > 0);
                if(data & 0x8000) {
                    data |= 0xffffffffffff0000;
                }
                break;
            case 0b010: // LW
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 4, (char *)&data, csr[CSR::mstatus] > 0);
                if(data & 0x80000000) {
                    data |= 0xffffffff00000000;
                }
                break;
            case 0b011: // LD
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 8, (char *)&data, csr[CSR::mstatus] > 0);
                break;
            case 0b100: // LBU
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 1, (char *)&data, csr[CSR::mstatus] > 0);
                break;
            case 0b101: // LHU
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 2, (char *)&data, csr[CSR::mstatus] > 0);
                break;
            case 0b110: // LWU
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 4, (char *)&data, csr[CSR::mstatus] > 0);
                break;
            case 0b111: // LDU
                mtalloc.read((void *)(reg[inst.getRS1()] + inst.getImm()), 8, (char *)&data, csr[CSR::mstatus] > 0);
                break;
        }
        reg[inst.getRD()] = data;
        #if DEBUG
            cout << "LOAD: " << printRegName(inst.getRD()) << " = 0x" << data << " from 0x" << (reg[inst.getRS1()] + inst.getImm()) << endl;
        #endif
    }

    void runSTORE(VMInsts::Instruction &inst) {
        switch(inst.getFunct3()) {
            case 0b000: // SB
                mtalloc.write((void *)(reg[inst.getRS1()] + inst.getImm()), 1, (char *)&reg[inst.getRS2()], csr[CSR::mstatus] > 0);
                break;
            case 0b001: // SH
                mtalloc.write((void *)(reg[inst.getRS1()] + inst.getImm()), 2, (char *)&reg[inst.getRS2()], csr[CSR::mstatus] > 0);
                break;
            case 0b010: // SW
                mtalloc.write((void *)(reg[inst.getRS1()] + inst.getImm()), 4, (char *)&reg[inst.getRS2()], csr[CSR::mstatus] > 0);
                break;
            case 0b011: // SD
            case 0b100:
                mtalloc.write((void *)(reg[inst.getRS1()] + inst.getImm()), 8, (char *)&reg[inst.getRS2()], csr[CSR::mstatus] > 0);
                break;
        }
        #if DEBUG
            cout << "STORE: ";
            switch(inst.getFunct3()) {
                case 0b000: 
                    cout << "byte"; break;
                case 0b001: 
                    cout << "word"; break;
                case 0b010: 
                    cout << "dword"; break;
                case 0b011:
                case 0b100: 
                    cout << "qword"; break; 
            }
            cout << "ptr [0x" << (reg[inst.getRS1()] + inst.getImm()) << "] = 0x" << reg[inst.getRS2()] << endl;
        #endif
    }

    void runOP_IMM(VMInsts::Instruction &inst) {
        int64_t imm = inst.getImm();
        uint64_t rs1 = reg[inst.getRS1()]; 
        switch (inst.getFunct3()) {
            case 0b000: // ADDI
                #if DEBUG
                    cout << "ADDI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " + 0x" << hex << imm << endl;
                #endif
                reg[inst.getRD()] = rs1 + imm;
                break;
            case 0b010: // SLTI
                #if DEBUG
                    cout << "SLTI: " << printRegName(inst.getRD()) << " = 0x" << (int64_t)rs1 << " < 0x" << (int64_t)imm << endl;
                #endif
                reg[inst.getRD()] = (int64_t)rs1 < (int64_t)imm;
                break;
            case 0b011: // SLTIU
                #if DEBUG
                    cout << "SLTIU: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " < 0x" << imm << endl;
                #endif
                reg[inst.getRD()] = rs1 < imm;
                break;
            case 0b100: // XORI
                #if DEBUG
                    cout << "XORI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " ^ 0x" << imm << endl;
                #endif
                reg[inst.getRD()] = rs1 ^ imm;
                break;
            case 0b110: // ORI
                #if DEBUG
                    cout << "ORI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " | 0x" << imm << endl;
                #endif
                reg[inst.getRD()] = rs1 | imm;
                break;
            case 0b111: // ANDI
                #if DEBUG
                    cout << "ANDI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " & 0x" << imm << endl;
                #endif
                reg[inst.getRD()] = rs1 & imm;
                break;
            case 0b001: // SLLI
                #if DEBUG
                    cout << "SLLI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " << 0x" << (imm & 0x3F) << endl;
                #endif
                reg[inst.getRD()] = rs1 << (imm & 0x3F);
                break;
            case 0b101:
                if (imm & 0x400) { // SRAI
                    #if DEBUG
                        cout << "SRAI: " << printRegName(inst.getRD()) << " = 0x" << (int64_t)rs1 << " >> 0x" << (imm & 0x3F) << endl;
                    #endif
                    reg[inst.getRD()] = (int64_t)rs1 >> (imm & 0x3F);
                }
                else { // SRLI
                    #if DEBUG
                        cout << "SRLI: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " >> 0x" << (imm & 0x3F) << endl;
                    #endif
                    reg[inst.getRD()] = rs1 >> (imm & 0x3F);
                }
                break;
        }
    }

    void runOP(VMInsts::Instruction &inst) {
        uint64_t rs1 = reg[inst.getRS1()];
        uint64_t rs2 = reg[inst.getRS2()];
        switch (inst.getFunct3()) {
            case 0b000:
                if (inst.getFunct7() == 0b0000000) { // ADD
                    reg[inst.getRD()] = rs1 + rs2;
                    #if DEBUG
                        cout << "ADD: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " + 0x" << rs2 << endl;
                    #endif
                }
                else if (inst.getFunct7() == 0b0100000) { // SUB
                    reg[inst.getRD()] = rs1 - rs2;
                    #if DEBUG
                        cout << "SUB: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " - 0x" << rs2 << endl;
                    #endif
                }
                break;
            case 0b001: // SLL
                reg[inst.getRD()] = rs1 << (rs2 & 0x3F);
                #if DEBUG
                    cout << "SLL: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " << 0x" << (rs2 & 0x3F) << endl;
                #endif
                break;
            case 0b010: // SLT
                reg[inst.getRD()] = (int64_t)rs1 < (int64_t)rs2;
                #if DEBUG
                    cout << "SLT: " << printRegName(inst.getRD()) << " = 0x" << (int64_t)rs1 << " < 0x" << (int64_t)rs2 << endl;
                #endif
                break;
            case 0b011: // SLTU
                reg[inst.getRD()] = rs1 < rs2;
                #if DEBUG
                    cout << "SLTU: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " < 0x" << rs2 << endl;
                #endif
                break;
            case 0b100: // XOR
                reg[inst.getRD()] = rs1 ^ rs2;
                #if DEBUG
                    cout << "XOR: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " ^ 0x" << rs2 << endl;
                #endif
                break;
            case 0b101:
                if (inst.getFunct7() == 0b0000000) { // SRL
                    reg[inst.getRD()] = rs1 >> (rs2 & 0x3F);
                    #if DEBUG
                        cout << "SRL: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " >> 0x" << (rs2 & 0x3F) << endl;
                    #endif
                }
                else if (inst.getFunct7() == 0b0100000) { // SRA
                    reg[inst.getRD()] = (int64_t)rs1 >> (rs2 & 0x3F);
                    #if DEBUG
                        cout << "SRA: " << printRegName(inst.getRD()) << " = 0x" << (int64_t)rs1 << " >> 0x" << (rs2 & 0x3F) << endl;
                    #endif
                }
                break;
            case 0b110: // OR
                reg[inst.getRD()] = rs1 | rs2;
                #if DEBUG
                    cout << "OR: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " | 0x" << rs2 << endl;
                #endif
                break;
            case 0b111: // AND
                reg[inst.getRD()] = rs1 & rs2;
                #if DEBUG
                    cout << "AND: " << printRegName(inst.getRD()) << " = 0x" << rs1 << " & 0x" << rs2 << endl;
                #endif
                break;
        }
    }

    void runMISC_MEM(VMInsts::Instruction &inst) {
        // not implemented
    }

    void runSYSTEM(VMInsts::Instruction &inst) {
        ostringstream oss;
        #if DEBUG
            cout << "SYSTEM: " << hex << inst.getFunct3() << " " << inst.getImm() << endl;
        #endif
        switch(inst.getFunct3()) {
            case 0b000:
                if(!inst.getRS1() && !inst.getRD()) { // ECALL
                    switch (inst.getImm()) {
                        case 0b0: // ECALL
                            interruptHandlerCallFromECALL();
                            break;
                        case 0b1: // EBREAK
                            _exit(0);
                            break;
                        case 0b000100000010: // SRET
                            runSRET();
                            break;
                        case 0b001100000010: // MRET
                            runMRET();
                            break;
                        default: // EFENCE
                            break;
                    }
                }
                break;
            case 0b001:
            case 0b010:
            case 0b011:
                runCSRR(inst);
                break;
            case 0b101:
            case 0b110:
            case 0b111:
                runCSRRI(inst);
                break;
        }
    }

    void runOP_IMM_32(VMInsts::Instruction &inst) {
        switch(inst.getFunct3()) {
            case 0b000: // ADDIW
                reg[inst.getRD()] = (int32_t)(reg[inst.getRS1()] + inst.getImm());
                #if DEBUG
                    cout << "ADDIW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)(reg[inst.getRS1()] + inst.getImm()) << endl;
                #endif
                break;
            case 0b001: // SLLIW
                reg[inst.getRD()] = (int32_t)(reg[inst.getRS1()] << (inst.getImm() & 0x1F));
                #if DEBUG
                    cout << "SLLIW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)(reg[inst.getRS1()] << (inst.getImm() & 0x1F)) << endl;
                #endif
                break;
            case 0b101:
                if (inst.getFunct7() == 0b0000000) { // SRLIW
                    reg[inst.getRD()] = (int32_t)((uint32_t)reg[inst.getRS1()] >> (inst.getImm() & 0x1F));
                    #if DEBUG
                        cout << "SRLIW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)((uint32_t)reg[inst.getRS1()] >> (inst.getImm() & 0x1F)) << endl;
                    #endif
                } else if (inst.getFunct7() == 0b0100000) { // SRAIW
                    reg[inst.getRD()] = (int32_t)((int32_t)reg[inst.getRS1()] >> (inst.getImm() & 0x1F));
                    #if DEBUG
                        cout << "SRAIW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)((int32_t)reg[inst.getRS1()] >> (inst.getImm() & 0x1F)) << endl;
                    #endif
                }
                break;
        }
    }

    void runOP_32(VMInsts::Instruction &inst) {
        uint64_t rs1 = reg[inst.getRS1()];
        uint64_t rs2 = reg[inst.getRS2()];
        switch (inst.getFunct3()) {
            case 0b000:
                if (inst.getFunct7() == 0b0000000) { // ADDW
                    reg[inst.getRD()] = (int32_t)(rs1 + rs2);
                    #if DEBUG
                        cout << "ADDW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)(rs1 + rs2) << endl;
                    #endif
                }
                else if (inst.getFunct7() == 0b0100000) { // SUBW
                    reg[inst.getRD()] = (int32_t)(rs1 - rs2);
                    #if DEBUG
                        cout << "SUBW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)(rs1 - rs2) << endl;
                    #endif
                }
                break;
            case 0b001: // SLLW
                reg[inst.getRD()] = (int32_t)(rs1 << (rs2 & 0x1F));
                #if DEBUG
                    cout << "SLLW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)(rs1 << (rs2 & 0x1F)) << endl;
                #endif
                break;
            case 0b101:
                if (inst.getFunct7() == 0b0000000) { // SRLW
                    reg[inst.getRD()] = (int32_t)((uint32_t)rs1 >> (rs2 & 0x1F));
                    #if DEBUG
                        cout << "SRLW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)((uint32_t)rs1 >> (rs2 & 0x1F)) << endl;
                    #endif
                }
                else if (inst.getFunct7() == 0b0100000) { // SRAW
                    reg[inst.getRD()] = (int32_t)((int32_t)rs1 >> (rs2 & 0x1F));
                    #if DEBUG
                        cout << "SRAW: " << printRegName(inst.getRD()) << " = 0x" << (int32_t)((int32_t)rs1 >> (rs2 & 0x1F)) << endl;
                    #endif
                }
                break;
        }
    }

public:
    VM(ifstream &bin) {
        reg = (uint64_t *)calloc(32, sizeof(uint64_t));
        csr = (uint64_t *)calloc(0x1000, sizeof(uint64_t));
        
        csr[CSR::mstatus] = Privilege::M;
        
        kbase = (uint64_t)mtalloc.mmap((void *)randRange(0xffffffff80000000, 0xffffffffa0000000), 0x1000000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        reg[Reg::sp] = (uint64_t)mtalloc.mmap((void *)randRange(0xffffff0000000000, 0xffffff1000000000), 0x100000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0) + 0x100000;
        
        ELFParser elfParser(bin);
        elfParser.parse();

        // This CPU Load ELF when start, so it can support kaslr on CPU
        for(int i = 0; i < elfParser.getProgramHeaderSize(); i++) {
            ELFParser::Elf64_Phdr phdr = elfParser.getProgramHeaderAt(i);
            string program = elfParser.getProgramAt(i);

            switch (phdr.p_type) {
                case 1: // PT_LOAD
                    switch(phdr.p_vaddr) {
                        case 0xffffffff80000000: // text
                            mtalloc.write((void *)kbase, phdr.p_filesz, (char *)&program[0], csr[CSR::mstatus] > 0);
                            mtalloc.mprotect((void *)kbase, 0x100000, PROT_READ | PROT_EXEC);
                            break;
                    }
            }
        }
        pc = kbase;
        csr[CSR::mtvec] = kbase + 0x10000 + 0x10; // wrong stack alignment (because of function, not asm)
    }

    void run() {
        #if DEBUG
            cout << hex;
        #endif
        while(true) {
            reg[Reg::x0] = 0;
            uint32_t inst;
            
            mtalloc.read((void *)pc, 4, (char *)&inst, csr[CSR::mstatus] > 0, true);
            VMInsts::Instruction instruction(inst);
            pc += 4;

            #if DEBUG
                cout << "Instruction: 0x" << inst << endl;
            #endif

            switch (instruction.getOpcode()) {
                case VMInsts::LUI:
                    runLUI(instruction);
                    break;
                case VMInsts::AUIPC:
                    runAUIPC(instruction);
                    break;
                case VMInsts::JAL:
                    runJAL(instruction);
                    break;
                case VMInsts::JALR:
                    runJALR(instruction);
                    break;
                case VMInsts::BRANCH:
                    runBRANCH(instruction);
                    break;
                case VMInsts::LOAD:
                    runLOAD(instruction);
                    break;
                case VMInsts::STORE:
                    runSTORE(instruction);
                    break;
                case VMInsts::OP_IMM:
                    runOP_IMM(instruction);
                    break;
                case VMInsts::OP:
                    runOP(instruction);
                    break;
                case VMInsts::MISC_MEM:
                    runMISC_MEM(instruction);
                    break;
                case VMInsts::SYSTEM:
                    runSYSTEM(instruction);
                    break;
                case VMInsts::OP_IMM_32:
                    runOP_IMM_32(instruction);
                    break;
                case VMInsts::OP_32:
                    runOP_32(instruction);
                    break;
                default:
                    ostringstream oss;
                    oss << "Unknown opcode" << endl;
                    fatal(oss);
            }
        }
    }
};
                
int main(int argc, char *argv[]) {

    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    if(argc != 2) {
        cerr << "Usage: " << argv[0] << " <kernel>" << endl;
        return 1;
    }

    ifstream bin;
    bin.open(argv[1], ios::in | ios::binary);
    if (!bin) {
        cerr << "Failed to open kernel" << endl;
        return 1;
    }
    
    VM vm(bin);
    bin.close();

    vm.run();
    return 0;
}