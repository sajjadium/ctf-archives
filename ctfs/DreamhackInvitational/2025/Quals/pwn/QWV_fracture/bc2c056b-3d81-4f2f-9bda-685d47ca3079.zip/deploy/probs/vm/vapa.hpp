#include <bits/stdc++.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>

using namespace std;

typedef long long int ll;
typedef long long unsigned int ull;

// #define VAPA_DEBUG 1
// #define VAPA_DEBUG_PANIC 1
// #define VAPA_DEBUG_WARN 1

class TypeConvertor {
public:
    ll vp2ll(void *v)
    {
        return (ll)v;
    }

    ull vp2ull(void *v)
    {
        return (ull)v;
    }

    void *ull2vp(ull u)
    {
        return (void *)u;
    }

    char *vp2chp(void *v)
    {
        return (char *)v;
    }
};

class VirtualAddress : public TypeConvertor {
private:
    void *va;
    void panic(string s, int err)
    {
        #ifdef VAPA_DEBUG_PANIC
            cout << "*** PANIC: VirtualAddress: " << s << " ***" << endl;
        #endif
        _exit(-err);
    }

public:
    VirtualAddress() { va = nullptr; }

    template <typename T>
    VirtualAddress(T i)
    {
        va = (void *)(ull)i;
    }

    template <typename T>
    bool operator<(T i)
    {
        return vp2ull(va) < (ull)i;
    }

    template <typename T>
    bool operator>(T i)
    {
        return vp2ull(va) > (ull)i;
    }

    template <typename T>
    bool operator==(T i)
    {
        return vp2ull(va) == (ull)i;
    }

    template <typename T>
    bool operator!=(T i)
    {
        return vp2ull(va) != (ull)i;
    }

    template <typename T>
    operator T()
    {
        return T(va);
    }

    template <typename T>
    VirtualAddress operator=(T i)
    {
        va = (void *)(ull)i;
        return *this;
    }

    template <typename T>
    VirtualAddress operator%(T i)
    {
        return VirtualAddress(vp2ull(va) % i);
    }

    template <typename T>
    VirtualAddress operator+(T i)
    {
        return VirtualAddress(vp2ull(va) + i);
    }

    template <typename T>
    VirtualAddress operator+=(T i)
    {
        va = ull2vp(vp2ull(va) + i);
        return *this;
    }

    template <typename T>
    VirtualAddress operator-(T i)
    {
        return VirtualAddress(vp2ull(va) - i);
    }

    template <typename T>
    VirtualAddress operator-=(T i)
    {
        va = ull2vp(vp2ull(va) - i);
        return *this;
    }
};

class PhysicalAddress : public TypeConvertor {
private:
    void *pa;
public:
    PhysicalAddress() { pa = nullptr; }
    PhysicalAddress(void *v): pa(v) {};

    template <typename T>
    PhysicalAddress(T i)
    {
        pa = (void *)i;
    }

    template <typename T>
    operator T()
    {
        return T((ull)pa);
    }

    template <typename T>
    bool operator<(T i)
    {
        return vp2ull(pa) < (ull)i;
    }

    template <typename T>
    bool operator>(T i)
    {
        return vp2ull(pa) > (ull)i;
    }

    template <typename T>
    bool operator==(T i)
    {
        return vp2ull(pa) == (ull)i;
    }

    template <typename T>
    PhysicalAddress operator+(T i)
    {
        return PhysicalAddress(vp2ull(pa) + i);
    }

    template <typename T>
    PhysicalAddress operator+=(T i)
    {
        pa = ull2vp(vp2ull(pa) + i);
        return *this;
    }

    template <typename T>
    PhysicalAddress operator-(T i)
    {
        return PhysicalAddress(vp2ull(pa) - i);
    }

    template <typename T>
    PhysicalAddress operator>>(T i)
    {
        return PhysicalAddress(vp2ull(pa) >> i);
    }

};

class Bitmap : public TypeConvertor {
private:
    void *bitmap_start;

public:
    Bitmap() {};
    Bitmap(void *v): bitmap_start(v) 
    {
        memset(bitmap_start, 0, 0x1000);
    };

    void *GetBitmapStart()
    {
        return bitmap_start;
    }

    void SetBitmapStart(void *v)
    {
        bitmap_start = v;
    }

    void SetBit(int bit)
    {
        ull *bitmap = (ull *)bitmap_start;
        bitmap[bit / 64] |= (1 << (bit % 64));
    }

    void ClearBit(int bit)
    {
        ull *bitmap = (ull *)bitmap_start;
        bitmap[bit / 64] &= ~(1 << (bit % 64));
    }

    bool IsBitSet(int bit)
    {
        ull *bitmap = (ull *)bitmap_start;
        return (bitmap[bit / 64] & (1 << (bit % 64)));
    }
};

class PaMemory : public PhysicalAddress {
public:
    typedef enum {
        GFP_ZERO = 0,
    } FLAGS;

private:
    void *physical_frame;
    void *physical_frame_alloc_start;
    void *physical_frame_alloc_end;
    Bitmap bitmap;

    const ull FrameBitSize = 12;
    const ull FrameSize = 0x1000;
    const ull FrameCount = 0x8000;

    [[noreturn]] void panic(string s, int err)
    {
        #ifdef VAPA_DEBUG_PANIC
            cout << "*** PANIC: PaMemory: " << s << " ***" << endl;
        #endif
        _exit(-err);
    }

    ull AlignSize(ull size)
    {
        return (size + FrameSize - 1) & ~(FrameSize - 1);
    }

    ull PaMemoryGetRandAddress()
    {
        int fd = open("/dev/urandom", O_RDONLY);
        if(fd == -1)
            panic("open failed", 1);
        
        ull val;
        read(fd, &val, sizeof(val));
        return (val & 0xfffffff000);
    }

    bool PaMemoryGetBit(PhysicalAddress pa)
    {
        #ifdef VAPA_DEBUG
            cout << "PaMemoryGetBit: pa: " << hex << (ull)pa << ", bit: " << (ull)((pa - (ull)physical_frame_alloc_start) >> FrameBitSize) << endl;
        #endif
        return bitmap.IsBitSet((pa - (ull)physical_frame_alloc_start) >> FrameBitSize);
    }

    void PaMemorySetBit(PhysicalAddress pa)
    {
        bitmap.SetBit( (pa - (ull)physical_frame_alloc_start) >> FrameBitSize);
    }

    void PaMemoryClearBit(PhysicalAddress pa)
    {
        bitmap.ClearBit((pa - (ull)physical_frame_alloc_start) >> FrameBitSize);
    }

    PhysicalAddress PaMemoryAllocInternal(ull size, FLAGS flags) {
        PhysicalAddress start = physical_frame_alloc_start, curr = start;
        while(curr < start + size && curr < physical_frame_alloc_end)
        {
            if(!PaMemoryGetBit(curr))
                curr += FrameSize;
            else
            {
                start = curr + FrameSize;
                curr = start;
            }
        }

        if(curr == start + size)
        {
            for(PhysicalAddress i = start; i < curr; i += FrameSize)
                PaMemorySetBit(i);
            return start;
        }
        else
            panic("PaMemoryAlloc: out of memory", 1);
    }

public:
    PaMemory() {
        physical_frame = (void *)PaMemoryGetRandAddress();
        physical_frame = mmap((void *)physical_frame, FrameSize * FrameCount, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
        if(physical_frame == MAP_FAILED)
            panic("mmap failed", 1);
        bitmap.SetBitmapStart(physical_frame);
        physical_frame_alloc_start = ull2vp(vp2ull(physical_frame) + (1 << 20));
        physical_frame_alloc_end = ull2vp(vp2ull(physical_frame) + FrameSize * FrameCount);
    }

    PhysicalAddress PaMemoryAlloc(ull size, FLAGS flags)
    {
        size = AlignSize(size);
        PhysicalAddress pa = PaMemoryAllocInternal(size, flags);

        if(pa == nullptr)
            panic("PaMemoryAlloc: out of memory", 1);
        
        if(flags == GFP_ZERO)
            memset(pa, 0, size);
        
        return pa;
    }

    void PaMemoryFree(PhysicalAddress start, ull size)
    {
        size = AlignSize(size);
        for(PhysicalAddress i = start; i < start + size; i += FrameSize)
            PaMemoryClearBit(i);
    }

    ull PaMemoryRead(PhysicalAddress pa, ull size)
    {
        if(size == 1)
            return *(unsigned char *)pa;
        else
            panic("PaMemoryRead: invalid size", 1);
    }

    void PaMemoryWrite(PhysicalAddress pa, ull data, ull size)
    {
        if(size == 1)
            *(unsigned char *)pa = data;
        else
            panic("PaMemoryWrite: invalid size", 1);
    }
};

namespace Flags{
    enum class Mask : uint8_t {
        VALID = 0b001,
        DIRTY = 0b010,
        HILEVEL = 0b100,
    };

    enum class Permission : uint8_t {
        NONE = 0b000,
        READ = 0b001,
        WRITE = 0b010,
        EXEC = 0b100,
    };

    inline Mask operator |(const Mask &a, const Mask &b)
    {
        return (Mask)((ull)a | (ull)b);
    }

    inline Permission operator |(const Permission &a, const Permission &b)
    {
        return (Permission)((ull)a | (ull)b);
    }

    inline Mask operator &(const Mask &a, const Mask &b)
    {
        return (Mask)((ull)a & (ull)b);
    }

    inline Permission operator &(const Permission &a, const Permission &b)
    {
        return (Permission)((ull)a & (ull)b);
    }

    inline Mask operator ^(const Mask &a, const Mask &b)
    {
        return (Mask)((ull)a ^ (ull)b);
    }

    inline Permission operator ^(const Permission &a, const Permission &b)
    {
        return (Permission)((ull)a ^ (ull)b);
    }
}


class VaMemory : public TypeConvertor {
private:
    typedef struct {
        ull perm: 3;
        ull mask: 3;
        ull pa: 58;
    }PTE;
    
    PaMemory pma;
    PTE ****pml4_base;

    [[noreturn]] void panic(string s, int err)
    {
        #ifdef VAPA_DEBUG_PANIC
            cout << "*** PANIC: VaMemory: " << s << " ***" << endl;
        #endif
        _exit(-err);
    }

    void warn(string s)
    {
        #ifdef VAPA_DEBUG_WARN
            cout << "*** WARN: VaMemory: " << s << " ***" << endl;
        #endif
    }
    
    PTE ***VaMemoryGetPML4E(VirtualAddress va)
    {
        return pml4_base[(ull(va) >> 39) & 0x1ff];
    }

    PTE **VaMemoryGetPDPE(VirtualAddress va, PTE ***pml4e)
    {
        return pml4e[(ull(va) >> 30) & 0x1ff];
    }

    PTE *VaMemoryGetPDE(VirtualAddress va, PTE **pdpe)
    {
        return pdpe[(ull(va) >> 21) & 0x1ff];
    }

    PTE VaMemoryGetPTE(VirtualAddress va, PTE *pde)
    {
        return pde[(ull(va) >> 12) & 0x1ff];
    }

    PTE VaMemoryGetPTEOnce(VirtualAddress va)
    {
        PTE ***pml4e = VaMemoryGetPML4E(va);
        if(pml4e == nullptr)
            panic("VaMemoryGetPTEOnce: invalid PML4E", 1);
        PTE **pdpe = VaMemoryGetPDPE(va, pml4e);
        if(pdpe == nullptr)
            panic("VaMemoryGetPTEOnce: invalid PDPE", 1);
        PTE *pde = VaMemoryGetPDE(va, pdpe);
        if(pde == nullptr)
            panic("VaMemoryGetPTEOnce: invalid PDE", 1);
        return VaMemoryGetPTE(va, pde);
    }

    PTE VaMemorySetPTEOnce(VirtualAddress va, PTE pte)
    {
        PTE ***pml4e = VaMemoryGetPML4E(va);
        if(pml4e == nullptr)
            panic("VaMemorySetPTEOnce: invalid PML4E", 1);
        PTE **pdpe = VaMemoryGetPDPE(va, pml4e);
        if(pdpe == nullptr)
            panic("VaMemorySetPTEOnce: invalid PDPE", 1);
        PTE *pde = VaMemoryGetPDE(va, pdpe);
        if(pde == nullptr)
            panic("VaMemorySetPTEOnce: invalid PDE", 1);
        return VaMemorySetPTE(va, pde, pte);
    }

    PTE ***VaMemorySetPML4E(VirtualAddress va, PTE ***pml4e)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemorySetPML4E: va: " << hex << (ull)va << ", pml4e: " << (ull)pml4e << endl;
        #endif
        return pml4_base[(ull(va) >> 39) & 0x1ff] = pml4e;
    }

    PTE **VaMemorySetPDPE(VirtualAddress va, PTE ***pml4e, PTE **pdpe)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemorySetPDPE: va: " << hex << (ull)va << ", pdpe: " << (ull)pdpe << endl;
        #endif
        return pml4e[(ull(va) >> 30) & 0x1ff] = pdpe;
    }

    PTE *VaMemorySetPDE(VirtualAddress va, PTE **pdpe, PTE *pde)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemorySetPDE: va: " << hex << (ull)va << ", pde: " << (ull)pde << endl;
        #endif
        return pdpe[(ull(va) >> 21) & 0x1ff] = pde;
    }

    PTE VaMemorySetPTE(VirtualAddress va, PTE *pde, PTE pte)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemorySetPTE: va: " << hex << (ull)va << ", pte: " << (ull)pte.pa << endl;
        #endif
        return pde[(ull(va) >> 12) & 0x1ff] = pte;
    }

    void *VaMemoryGetPTEPa(VirtualAddress va)
    {
        return (void *)(ull)VaMemoryGetPTEOnce(va).pa;
    }

    Flags::Permission VaMemoryGETPTEPerm(VirtualAddress va)
    {
        return (Flags::Permission)(VaMemoryGetPTEOnce(va).perm);
    }

    Flags::Mask VaMemoryGETPTEMask(VirtualAddress va)
    {
        return (Flags::Mask)(VaMemoryGetPTEOnce(va).mask);
    }

    PhysicalAddress VaMemoryVa2Pa(VirtualAddress va)
    {
        return PhysicalAddress((ull)VaMemoryGetPTEPa(va) + ((ull)va & 0xfff));
    }

    VirtualAddress VaMemoryRegisterPa(VirtualAddress va, ull size, Flags::Permission perm, bool himap)
    {
        PTE ***pml4e = VaMemoryGetPML4E(va), **pdpe, *pde, pte;
        if(pml4e == nullptr)
        {
            pml4e = VaMemorySetPML4E(va, pma.PaMemoryAlloc(0x1000, PaMemory::GFP_ZERO));
            pml4e = VaMemorySetPML4E(va, pml4e);
        }
        pdpe = VaMemoryGetPDPE(va, pml4e);
        if(pdpe == nullptr)
        {
            pdpe = VaMemorySetPDPE(va, pml4e, pma.PaMemoryAlloc(0x1000, PaMemory::GFP_ZERO));
            pdpe = VaMemorySetPDPE(va, pml4e, pdpe);
        }
        pde = VaMemoryGetPDE(va, pdpe);
        if(pde == nullptr)
        {
            pde = VaMemorySetPDE(va, pdpe, pma.PaMemoryAlloc(0x1000, PaMemory::GFP_ZERO));
            pde = VaMemorySetPDE(va, pdpe, pde);
        }
        pte = VaMemoryGetPTE(va, pde);

        if((bool)(Flags::Mask(pte.mask) & Flags::Mask::VALID))
        {
            warn("VaMemoryRegisterPa: Tried to allocate on same va more than once");
            return VirtualAddress(-1);
        }

        PTE newpte;
        newpte.pa = (ull)pma.PaMemoryAlloc(size, PaMemory::GFP_ZERO);
        newpte.perm = (ull)perm;
        newpte.mask = (ull)Flags::Mask::VALID | (himap ? (ull)Flags::Mask::HILEVEL : 0);
        VaMemorySetPTE(va, pde, newpte);

        #ifdef VAPA_DEBUG
            cout << "VaMemoryRegisterPa: va: " << hex << (ull)va << ", pa: " << (ull)newpte.pa << endl;
        #endif

        return va;
    }   

    void VaMemoryErasePa(VirtualAddress va)
    {
        PTE newpte;
        newpte.pa = 0;
        newpte.perm = (ull)Flags::Permission::NONE;
        newpte.mask |= ~(ull)Flags::Mask::VALID;
        VaMemorySetPTEOnce(va, newpte);
    }

public:
    VaMemory() 
    {
        pml4_base = pma.PaMemoryAlloc(0x1000, PaMemory::GFP_ZERO);
    };

    bool VaMemoryExist(VirtualAddress va)
    {
        PTE ***pml4e = VaMemoryGetPML4E(va), **pdpe, *pde;
        if(pml4e == nullptr)
            return false;
        pdpe = VaMemoryGetPDPE(va, pml4e);
        if(pdpe == nullptr)
            return false;
        pde = VaMemoryGetPDE(va, pdpe);
        if(pde == nullptr)
            return false;
        return (bool)(Flags::Mask(VaMemoryGetPTE(va, pde).mask) & Flags::Mask::VALID);
    }

    VirtualAddress VaMemoryAlloc(VirtualAddress va, ull size, Flags::Permission perm, uint64_t map_level)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemoryAlloc: va: " << hex << (ull)va << ", size: " << size << ", perm: " << (ull)perm << endl;
        #endif
        for(ull i = 0; i < size; i += 0x1000)
            if(VaMemoryRegisterPa(va + i, 0x1000, perm, map_level) == -1)
            {
                for(ull j = 0; j < i; j += 0x1000)
                    VaMemoryErasePa(va + j);
                return VirtualAddress(-1);
            }
        return va;
    }

    void VaMemoryFree(VirtualAddress va, ull size)
    {
        #ifdef VAPA_DEBUG
            cout << "VaMemoryFree: va: " << hex << (ull)va << ", size: " << size << endl;
        #endif
        for(ull i = 0; i < size; i += 0x1000)
        {
            if(!VaMemoryExist(va + i))
                panic("VaMemoryFree: invalid va", 1);
            
            PhysicalAddress pa = VaMemoryVa2Pa(va + i);
            VaMemoryErasePa(va + i);
            pma.PaMemoryFree(pa, 0x1000);
        }
    }

    void VaMemoryPermissionChange(VirtualAddress va, ull size, Flags::Permission perm)
    {
        for(VirtualAddress i = va; i < va + size; i += 0x1000)
        {
            if(!VaMemoryExist(i))
                panic("VaMemoryPermissionChange: invalid va", 1);

            PTE pte = VaMemoryGetPTEOnce(i);
            pte.perm = (ull)perm;
            VaMemorySetPTEOnce(i, pte);
        }
    }

    ull VaMemoryRead(VirtualAddress va, ull size, Flags::Permission perm = Flags::Permission::READ, bool isHiLevel = false)
    {
        if(!isHiLevel && (bool)(VaMemoryGETPTEMask(va) & Flags::Mask::HILEVEL))
            panic("VaMemoryRead: invalid permission HILEVEL", 1);
        Flags::Permission pa_perm = VaMemoryGETPTEPerm(va);
        if((perm & pa_perm) != perm)
        {
            if(((perm ^ pa_perm) & perm & Flags::Permission::READ) != Flags::Permission::NONE)
                panic("VaMemoryRead: invalid permission READ", 1);
            if(((perm ^ pa_perm) & perm & Flags::Permission::WRITE) != Flags::Permission::NONE)
                panic("VaMemoryRead: invalid permission WRITE", 1);
            if(((perm ^ pa_perm) & perm & Flags::Permission::EXEC) != Flags::Permission::NONE)
                panic("VaMemoryRead: invalid permission EXEC", 1);
        }
        PhysicalAddress pa = VaMemoryVa2Pa(va);
        return pma.PaMemoryRead(pa, size);
    }

    void VaMemoryWrite(VirtualAddress va, ull data, ull size, Flags::Permission perm = Flags::Permission::WRITE, bool isHiLevel = false)
    {
        Flags::Permission pa_perm = VaMemoryGETPTEPerm(va);
        #ifdef VAPA_DEBUG
            cout << "VaMemoryWrite: va: " << hex << (ull)va << ", data: " << data << ", size: " << size << ", perm: " << (ull)perm << ", pa_perm: " << (ull)pa_perm << endl;
        #endif
        if(!isHiLevel && (bool)(VaMemoryGETPTEMask(va) & Flags::Mask::HILEVEL))
            panic("VaMemoryWrite: invalid permission HILEVEL", 1);
        if((perm & pa_perm) != perm)
        {
            if(((perm ^ pa_perm) & perm & Flags::Permission::READ) != Flags::Permission::NONE)
                panic("VaMemoryWrite: invalid permission READ", 1);
            if(((perm ^ pa_perm) & perm & Flags::Permission::WRITE) != Flags::Permission::NONE)
                panic("VaMemoryWrite: invalid permission WRITE", 1);
            if(((perm ^ pa_perm) & perm & Flags::Permission::EXEC) != Flags::Permission::NONE)
                panic("VaMemoryWrite: invalid permission EXEC", 1);
        }
        PhysicalAddress pa = VaMemoryVa2Pa(va);
        pma.PaMemoryWrite(pa, data, size);
    }

    PhysicalAddress VaMemoryVa2PaUser(VirtualAddress va)
    {
        return VaMemoryVa2Pa(va);
    }
};