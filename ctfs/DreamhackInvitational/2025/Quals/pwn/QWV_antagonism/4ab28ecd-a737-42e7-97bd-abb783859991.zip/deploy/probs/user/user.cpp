#define EXIT 0
#define WRITE 64
#define READ 63
#define MMAP 222
#define MUNMAP 215
#define OPEN 56
#define CLOSE 57
#define EXECVE 221

// #define DEBUG 2

static inline long long unsigned ecall(unsigned long long a7, unsigned long long a0, unsigned long long a1, unsigned long long a2, unsigned long long a3, unsigned long long a4, unsigned long long a5, unsigned long long a6)
{
    register unsigned long long int syscall_id asm("a7") = a7;
    register unsigned long long int arg0 asm("a0") = a0;
    register unsigned long long int arg1 asm("a1") = a1;
    register unsigned long long int arg2 asm("a2") = a2;
    register unsigned long long int arg3 asm("a3") = a3;
    register unsigned long long int arg4 asm("a4") = a4;
    register unsigned long long int arg5 asm("a5") = a5;
    register unsigned long long int arg6 asm("a6") = a6;
    register unsigned long long int a0_out asm("a0");
    asm volatile ("ecall"
        : "=r"(a0_out)
        : "r"(syscall_id), "r"(arg0), "r"(arg1), "r"(arg2), "r"(arg3), "r"(arg4), "r"(arg5), "r"(arg6)
    );

    return a0_out;
}

static inline long long unsigned Uread(int fd, char *buf, long long unsigned size)
{
    return ecall(READ, fd, (unsigned long long)buf, size, 0, 0, 0, 0);
}

static inline long long unsigned Uwrite(int fd, char *buf, long long unsigned size)
{
    return ecall(WRITE, fd, (unsigned long long)buf, size, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Uexit(unsigned status)
{
    ecall(EXIT, status, 0, 0, 0, 0, 0, 0);
}

static inline void *__attribute__((always_inline)) Ummap(void *addr, unsigned long long length, unsigned long long prot, unsigned long long flags, unsigned long long fd, unsigned long long offset)
{
    return (void *)ecall(MMAP, (unsigned long long)addr, length, prot, flags, fd, offset, 0);
}

static inline void __attribute__((always_inline)) Umunmap(void *addr, unsigned long long length)
{
    ecall(MUNMAP, (unsigned long long)addr, length, 0, 0, 0, 0, 0);
}

static inline int __attribute__((always_inline)) Uopen(char *path, unsigned long long flags, unsigned long long mode)
{
    return ecall(OPEN, (unsigned long long)path, flags, mode, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Uclose(unsigned long long fd)
{
    ecall(CLOSE, fd, 0, 0, 0, 0, 0, 0);
}

static inline int __attribute__((always_inline)) Uexecve(char *path)
{
    return ecall(EXECVE, (unsigned long long)path, 0, 0, 0, 0, 0, 0);
}

static inline void __attribute__((always_inline)) Umprotect(void *addr, unsigned long long length, unsigned long long prot)
{
    ecall(MMAP, (unsigned long long)addr, length, prot, 0, 0, 0, 0);
}

#define NULL 0

#define ull unsigned long long int
#define STDIN 0
#define STDOUT 1
#define STDERR 2

ull strtoull(const char *nptr, char **endptr, int base) {
    ull result = 0;
    while(*nptr) {
        if(*nptr >= '0' && *nptr <= '9') {
            result = result * base + *nptr - '0';
        } else if(*nptr >= 'a' && *nptr <= 'f') {
            result = result * base + *nptr - 'a' + 10;
        } else if(*nptr >= 'A' && *nptr <= 'F') {
            result = result * base + *nptr - 'A' + 10;
        } else {
            break;
        }
        nptr++;
    }
    if(endptr) {
        *endptr = (char *)nptr;
    }
    return result;
}

ull readull() {
    char buf[0x10];
    Uread(STDIN, buf, 0x10);
    return strtoull(buf, NULL, 10);
}

#define O_RDONLY 0
#define O_WRONLY 1
#define O_RDWR 2
#define O_CREAT 0x40

void __attribute__((section (".text.startup_code"))) _start() 
{
    Uwrite(STDOUT, "usual kernel exploit challenge!\n", 32);
    Uwrite(STDOUT, "but... careful about the architecture!\n", 39);

    int fd = Uopen("program", O_WRONLY | O_CREAT, 00666);
    if(fd < 0) {
        Uwrite(STDOUT, "open failed\n", 12);
        Uexit(1);
    }
    
    char bin[0x10000];
    int size = Uread(STDIN, bin, 0x10000);
    if(size < 0) {
        Uwrite(STDOUT, "read failed\n", 12);
        Uexit(1);
    }

    Uwrite(fd, bin, size);
    Uexecve("program");
}