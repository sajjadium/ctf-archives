// Type your code here, or load an example.

#include <bits/stdc++.h>
using namespace std;

#define STDIN 0
#define STDOUT 1
#define STDERR 2

#define NULL 0

#define ELFPARSER_DEBUG 0

#define PROT_READ 1
#define PROT_WRITE 2
#define PROT_EXEC 4

#define MAP_PRIVATE 2
#define MAP_ANONYMOUS 0x20

static inline void __attribute__((always_inline)) Mexit(unsigned status)
{
    register unsigned long long int a0 asm("a0") = status;
    asm volatile("ebreak");
}

static inline void *__attribute__((always_inline)) Mmmap(void *addr, unsigned long long length, unsigned long long prot, unsigned long long flags, unsigned long long fd, unsigned long long offset, unsigned long long level)
{
    register unsigned long long int a0 asm("a0") = (unsigned long long int)addr;
    register unsigned long long int a1 asm("a1") = length;
    register unsigned long long int a2 asm("a2") = prot;
    register unsigned long long int a3 asm("a6") = level;
    asm volatile("csrrw a7, 0x7c2, a7");
    return (void *)a0;
}

static inline void __attribute__((always_inline)) Mmunmap(void *addr, unsigned long long length)
{
    register unsigned long long int a0 asm("a0") = (unsigned long long int)addr;
    register unsigned long long int a1 asm("a1") = length;
    asm volatile("csrrw a7, 0x7c3, a7");
}

static inline int __attribute__((always_inline)) Mopen(char *path, unsigned long long flags, unsigned long long mode)
{
    register unsigned long long int a0 asm("a0") = (unsigned long long int)path;
    register unsigned long long int a1 asm("a1") = flags;
    register unsigned long long int a2 asm("a2") = mode;
    asm volatile("csrrw a7, 0x7c4, a7");
    return a0;
}

static inline void __attribute__((always_inline)) Mclose(unsigned long long fd)
{
    register unsigned long long int a0 asm("a0") = fd;
    asm volatile("csrrw a7, 0x7c5, a7");
}

static inline uint64_t __attribute__((always_inline)) Mread(int fd, char *buf, long long unsigned size)
{
    register unsigned long long int a0 asm("a0") = fd;
    register unsigned long long int a1 asm("a1") = (unsigned long long int)buf;
    register unsigned long long int a2 asm("a2") = size;
    asm volatile("csrrw a7, 0x7c0, a7");
    return a0;
}

static inline uint64_t __attribute__((always_inline)) Mwrite(int fd, char *buf, long long unsigned size)
{
    register unsigned long long int a0 asm("a0") = fd;
    register unsigned long long int a1 asm("a1") = (unsigned long long int)buf;
    register unsigned long long int a2 asm("a2") = size;
    asm volatile("csrrw a7, 0x7c1, a7");
    return a0;
}

static inline void __attribute__((always_inline)) Mmprotect(void *va, uint64_t length, int prot)
{
    register unsigned long long int a0 asm("a0") = (unsigned long long int)va;
    register unsigned long long int a1 asm("a1") = length;
    register unsigned long long int a2 asm("a2") = prot;
    asm volatile("csrrw a7, 0x7c6, a7");
}

static inline void __attribute__((always_inline)) printHex(unsigned long long int x)
{
    char buf[17];
    buf[16] = 0;
    for(int i = 15; i >= 0; i--) {
        buf[i] = "0123456789abcdef"[x & 0xf];
        x >>= 4;
    }
    Mwrite(1, "0x", 2);
    Mwrite(1, buf, 16);
    Mwrite(1, "\n", 1);
}


typedef uint16_t Elf64_Half;
typedef int16_t Elf64_SHalf;
typedef uint32_t Elf64_Word;
typedef int32_t Elf64_Sword;
typedef uint64_t Elf64_Xword;
typedef int64_t Elf64_Sxword;

typedef uint64_t Elf64_Off;
typedef uint64_t Elf64_Addr;
typedef uint16_t Elf64_Section;

// 64bit ELF Header
struct ELFHEADER {
    uint8_t ident[16];
    uint16_t type;
    uint16_t machine;
    uint32_t version;
    uint64_t entry;
    uint64_t phoff;
    uint64_t shoff;
    uint32_t flags;
    uint16_t ehsize;
    uint16_t phentsize;
    uint16_t phnum;
    uint16_t shentsize;
    uint16_t shnum;
    uint16_t shstrndx;
} __attribute__((packed));

struct Elf64_Phdr {
    Elf64_Word p_type;   
    Elf64_Word p_flags;  
    Elf64_Off p_offset;  
    Elf64_Addr p_vaddr;  
    Elf64_Addr p_paddr;  
    Elf64_Xword p_filesz;
    Elf64_Xword p_memsz; 
    Elf64_Xword p_align; 
} __attribute__((packed));

typedef struct Elf64_Shdr {
    Elf64_Word sh_name;
    Elf64_Word sh_type;
    Elf64_Xword sh_flags;
    Elf64_Addr sh_addr;
    Elf64_Off sh_offset;
    Elf64_Xword sh_size;
    Elf64_Word sh_link;
    Elf64_Word sh_info;
    Elf64_Xword sh_addralign;
    Elf64_Xword sh_entsize;
} __attribute__((packed));

typedef enum EL {
    EL_MAG = 0, EL_MAG1, EL_MAG2, EL_MAG3, // 4
    EL_CLASS = 4, // 1
    EL_DATA = 5, // 1
    EL_VERSION = 6, // 1
    EL_OSABI = 7, // 1
    EL_ABIVERSION = 8, // 1
    EL_PAD = 9, // 7
};

static inline void __attribute__((always_inline)) fatal() {
    Mwrite(STDERR, "Fatal error when ELF parsing\n", 30);
    asm volatile("ebreak");
}

static inline void __attribute__((always_inline)) parse(char data[], ELFHEADER &ELFHeader, Elf64_Phdr ELFProgramHeaders[], Elf64_Shdr ELFSectionHeaders[]) {

    memcpy(&ELFHeader, &data[0], sizeof(ELFHeader));
    if (ELFHeader.ident[EL::EL_MAG] != 0x7f || ELFHeader.ident[EL::EL_MAG1] != 'E' || ELFHeader.ident[EL::EL_MAG2] != 'L' || ELFHeader.ident[EL::EL_MAG3] != 'F') {
        fatal();
    }

    if (ELFHeader.ident[EL::EL_CLASS] != 2) {
        fatal();
    }

    if (ELFHeader.ident[EL::EL_DATA] != 1) {
        fatal();
    }

    if (ELFHeader.type != 2) {
        fatal();
    }

    if (ELFHeader.machine != 0xf3) {
        fatal();
    }

    if (ELFHeader.version != 1) {
        fatal();
    }

    if (ELFHeader.phentsize != sizeof(Elf64_Phdr)) {
        fatal();
    }

    if (ELFHeader.shentsize != sizeof(Elf64_Shdr)) {
        fatal();
    }

    if (ELFHeader.shstrndx >= ELFHeader.shnum) {
        fatal();
    }

    if (ELFHeader.shnum > 0x100 ||  ELFHeader.phnum > 0x100) {
        fatal();
    }

    #if ELFPARSER_DEBUG
    cout << hex;
    cout << "ELF Header:" << endl;
    cout << "Type: 0x" << ELFHeader.type << endl;
    cout << "Machine: 0x" << ELFHeader.machine << endl;
    cout << "Version: 0x" << ELFHeader.version << endl;
    cout << "Entry: 0x" << ELFHeader.entry << endl;
    cout << "Phoff: 0x" << ELFHeader.phoff << endl;
    cout << "Shoff: 0x" << ELFHeader.shoff << endl;
    cout << "Flags: 0x" << ELFHeader.flags << endl;
    cout << "Ehsize: 0x" << ELFHeader.ehsize << endl;
    cout << "Phentsize: 0x" << ELFHeader.phentsize << endl;
    cout << "Phnum: 0x" << ELFHeader.phnum << endl;
    cout << "Shentsize: 0x" << ELFHeader.shentsize << endl;
    cout << "Shnum: 0x" << ELFHeader.shnum << endl;
    cout << "Shstrndx: 0x" << ELFHeader.shstrndx << endl;
    #endif

    for(int i = 0; i < ELFHeader.phnum; i++) {
        memcpy(&ELFProgramHeaders[i], &data[ELFHeader.phoff + i * sizeof(Elf64_Phdr)], sizeof(Elf64_Phdr));
    }

    for(int i = 0; i < ELFHeader.shnum; i++) {
        memcpy(&ELFSectionHeaders[i], &data[ELFHeader.shoff + i * sizeof(Elf64_Shdr)], sizeof(Elf64_Shdr));
    }

    #if ELFPARSER_DEBUG
    cout << hex << endl << endl;
    cout << "ELF Program Headers:" << endl;
    for(int i = 0; i < ELFHeader.phnum; i++) {
        cout << "Type: 0x" << ELFProgramHeaders[i].p_type << endl;
        cout << "Flags: 0x" << ELFProgramHeaders[i].p_flags << endl;
        cout << "Offset: 0x" << ELFProgramHeaders[i].p_offset << endl;
        cout << "Vaddr: 0x" << ELFProgramHeaders[i].p_vaddr << endl;
        cout << "Paddr: 0x" << ELFProgramHeaders[i].p_paddr << endl;
        cout << "Filesz: 0x" << ELFProgramHeaders[i].p_filesz << endl;
        cout << "Memsz: 0x" << ELFProgramHeaders[i].p_memsz << endl;
        cout << "Align: 0x" << ELFProgramHeaders[i].p_align << endl;
        cout << endl;
    }
    #endif

    #if ELFPARSER_DEBUG
    cout << hex << endl << endl;
    cout << "ELF Section Headers:" << endl;
    for(int i = 0; i < ELFHeader.shnum; i++) {
        cout << "Name: " << &data[ELFSectionHeaders[i].sh_name] << endl;
        cout << "Type: 0x" << ELFSectionHeaders[i].sh_type << endl;
        cout << "Flags: 0x" << ELFSectionHeaders[i].sh_flags << endl;
        cout << "Addr: 0x" << ELFSectionHeaders[i].sh_addr << endl;
        cout << "Offset: 0x" << ELFSectionHeaders[i].sh_offset << endl;
        cout << "Size: 0x" << ELFSectionHeaders[i].sh_size << endl;
        cout << "Link: 0x" << ELFSectionHeaders[i].sh_link << endl;
        cout << "Info: 0x" << ELFSectionHeaders[i].sh_info << endl;
        cout << "Addralign: 0x" << ELFSectionHeaders[i].sh_addralign << endl;
        cout << "Entsize: 0x" << ELFSectionHeaders[i].sh_entsize << endl;
        cout << endl;
    }
    #endif
}

static inline uint64_t __attribute__((always_inline)) getProgramHeaderSize(ELFHEADER ELFHeader) {
    return ELFHeader.phnum;
}

static inline uint64_t __attribute__((always_inline)) getSectionHeaderSize(ELFHEADER ELFHeader) {
    return ELFHeader.shnum;
}

unsigned long long int ecall(unsigned long long a7, unsigned long long a0, unsigned long long a1, unsigned long long a2, unsigned long long a3, unsigned long long a4, unsigned long long a5, unsigned long long a6)
{
    register unsigned long long int syscall_id asm("a7") = a7;
    register unsigned long long int arg0 asm("a0") = a0;
    register unsigned long long int arg1 asm("a1") = a1;
    register unsigned long long int arg2 asm("a2") = a2;
    register unsigned long long int arg3 asm("a3") = a3;
    register unsigned long long int arg4 asm("a4") = a4;
    register unsigned long long int arg5 asm("a5") = a5;
    register unsigned long long int arg6 asm("a6") = a6;
    register unsigned long long int a0_out asm("a0");
    asm volatile ("ecall"
        : "=r"(a0_out)
        : "r"(syscall_id), "r"(arg0), "r"(arg1), "r"(arg2), "r"(arg3), "r"(arg4), "r"(arg5), "r"(arg6)
    );

    return a0_out;
}

static inline void __attribute__((always_inline)) __memcpy(void *dest, void *src, unsigned long long size) {
    char *d = (char *)dest;
    char *s = (char *)src;
    for(int i = 0; i < size; i++) {
        d[i] = s[i];
    }
}

static inline void __attribute__((always_inline)) chpl(uint64_t pl)
{
    register unsigned long long int a0 asm("a0") = pl;
    asm volatile("csrw mstatus, %0" : : "r"(a0));
}

static inline void __attribute__((always_inline)) chmepc(uint64_t epc)
{
    register unsigned long long int a0 asm("a0") = epc;
    asm volatile("csrw mepc, %0" : : "r"(a0));
}

static inline void __attribute__((always_inline)) chmcause(uint64_t cause)
{
    register unsigned long long int a0 asm("a0") = cause;
    asm volatile("csrw mcause, %0" : : "r"(a0));
}

static inline void __attribute__((always_inline)) chmstatus(uint64_t status)
{
    register unsigned long long int a0 asm("a0") = status;
    asm volatile("csrw mstatus, %0" : : "r"(a0));
}

static inline void chmscratch(uint64_t scratch)
{
    register unsigned long long int a0 asm("a0") = scratch;
    asm volatile("csrw mscratch, %0" : : "r"(a0));
}

__attribute__((section(".text.start"))) int _start()
{
    int fd = Mopen("./user", 0, 0);
    if (fd < 0) {
        Mwrite(2, "Failed to open file\n", 20);
        Mexit(1);
    }

    char bin[0x10000];
    int size = Mread(fd, bin, 0x10000);
    if (size < 0) {
        Mwrite(2, "Failed to read file\n", 20);
        Mexit(1);
    }
    
    ELFHEADER ELFHeader;
    Elf64_Phdr ELFProgramHeaders[0x100];
    Elf64_Shdr ELFSectionHeaders[0x100];
    
    parse(bin, ELFHeader, ELFProgramHeaders, ELFSectionHeaders);

    for(int i = 0; i< ELFHeader.phnum; i++) {
        Elf64_Phdr phdr = ELFProgramHeaders[i];
        switch(phdr.p_type) {
            case 1:
                switch(phdr.p_vaddr) {
                    case 0x400000: // text
                        Mmmap((void *)phdr.p_vaddr, ((phdr.p_filesz + 0xfff)&~0xfff), PROT_READ | PROT_WRITE, 0, 0, 0, 0);
                        memcpy((void *)phdr.p_vaddr, &bin[phdr.p_offset], phdr.p_filesz);
                        Mmprotect((void *)phdr.p_vaddr, ((phdr.p_filesz + 0xfff)&~0xfff), PROT_READ | PROT_EXEC);
                        break;
                    case 0x600000: // data
                        Mmmap((void *)phdr.p_vaddr, ((phdr.p_filesz + 0xfff)&~0xfff), PROT_READ | PROT_WRITE, 0, 0, 0, 0);
                        memcpy((void *)phdr.p_vaddr, &bin[phdr.p_offset], phdr.p_filesz);
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    Mmmap((void *)0x1000000, 0x100000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0, 0); // heap
    Mmmap((void *)0x2100000 - 0x200000, 0x200000, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0, 0); // stack

    chmepc(0x400000);
    chmscratch(0x2000000);
    chmcause(0);

    // cleanup all regs
    asm volatile(
        "li t0, 0\n"
        "li t1, 0\n"
        "li t2, 0\n"
        "li t3, 0\n"
        "li t4, 0\n"
        "li t5, 0\n"
        "li t6, 0\n"
        "li s0, 0\n"
        "li s1, 0\n"
        "li s2, 0\n"
        "li s3, 0\n"
        "li s4, 0\n"
        "li s5, 0\n"
        "li s6, 0\n"
        "li s7, 0\n"
        "li s8, 0\n"
        "li s9, 0\n"
        "li s10, 0\n"
        "li s11, 0\n"
        "li a0, 0\n"
        "li a1, 0\n"
        "li a2, 0\n"
        "li a3, 0\n"
        "li a4, 0\n"
        "li a5, 0\n"
        "li a6, 0\n"
        "li a7, 0\n"
        "li ra, 0\n"
        "li gp, 0\n"
        "li tp, 0\n"
        "mret\n"
    );
}

// ========================================
// ========================================
// ========================================
// ========================================
// ========================================
// ========================================

#define UMMAP_MIN 0x10000
#define UMMAP_MAX 0x0000800000000000

char cmap[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', '\n'};

long long unsigned Uread(int fd, char *buf, long long unsigned size)
{
    if((long long unsigned)buf < UMMAP_MIN || (long long unsigned)buf + size >= UMMAP_MAX) {
        return -EINVAL;
    }
    return Mread(fd, buf, size);
}

long long unsigned Uwrite(int fd, char *buf, long long unsigned size)
{
    if((long long unsigned)buf < UMMAP_MIN || (long long unsigned)buf + size >= UMMAP_MAX) {
        return -EINVAL;
    }
    return Mwrite(fd, buf, size);
}

void Uexit(unsigned status)
{
    Mexit(status);
}

void *Ummap(void *addr, unsigned long long length, unsigned long long prot, unsigned long long flags, unsigned long long fd, unsigned long long offset)
{
    if(addr == NULL) {
        int fd = Mopen("/dev/urandom", 0, 0);
        if(fd < 0) {
            return (void *)EACCES;
        }
        long long unsigned naddr;
        Mread(fd, (char *)&naddr, 8);

        naddr |= 0x0000700000000000; // prevent too low address (over 0x0000700000000000, usual libc address)
        naddr &= (UMMAP_MAX-1) & ~0xfff; // remove low 12 bits

        Mclose(fd);
        addr = (void *)naddr;
    } else {
        if((unsigned long long)addr & 0xfff) {
            return (void *)EINVAL;
        } if(length & 0xfff) {
            return (void *)EINVAL;
        } if((long long unsigned)addr < UMMAP_MIN || (long long unsigned)addr + length >= UMMAP_MAX) {
            return (void *)EINVAL;
        } if(length > 0x10000000) {
            return (void *)ENOMEM;
        }
    }
    return Mmmap(addr, length, prot, flags, fd, offset, 0);
}

void Umunmap(void *addr, unsigned long long length)
{
    if((unsigned long long)addr & 0xfff) {
        return;
    } if(length & 0xfff) {
        return;
    } if((long long unsigned)addr < 0x10000 || (long long unsigned)addr + length >= 0x0000800000000000) {
        return;
    }
    Mmunmap(addr, length);
}

int Uopen(char *path, unsigned long long flags, unsigned long long mode)
{
    char *p = path;
    while(*p) {
        if(*p == '.' || *p == '/')
            return -EINVAL;
        if(*p == '\0')
            break;
        p++;
    }
    return Mopen(path, flags, mode);
}

void Uclose(unsigned long long fd)
{
    Mclose(fd);
}

void Umprotect(void *addr, unsigned long long length, unsigned long long prot)
{
    if((unsigned long long)addr & 0xfff) {
        return;
    } if(length & 0xfff) {
        return;
    } if((long long unsigned)addr < 0x10000 || (long long unsigned)addr + length >= 0x0000800000000000) {
        return;
    }
    Mmprotect(addr, length, prot);
}

int Uexecve(char *path)
{
}

#define EXIT 0
#define WRITE 64
#define READ 63
#define MMAP 222
#define MUNMAP 215
#define OPEN 56
#define CLOSE 57
#define EXECVE 221
#define MPROTECT 226

void __attribute__((section (".text.trap"))) __attribute__((noreturn)) trap_handler()
{
    // push all registers to stack
    asm volatile (
        "addi sp, sp, -256\n"
        "sd ra, 0(sp)\n"
        "sd gp, 16(sp)\n"
        "sd tp, 24(sp)\n"
        "sd t0, 32(sp)\n"
        "sd t1, 40(sp)\n"
        "sd t2, 48(sp)\n"
        "sd s0, 56(sp)\n"
        "sd s1, 64(sp)\n"
        "sd a1, 80(sp)\n"
        "sd a2, 88(sp)\n"
        "sd a3, 96(sp)\n"
        "sd a4, 104(sp)\n"
        "sd a5, 112(sp)\n"
        "sd a6, 120(sp)\n"
        "sd a7, 128(sp)\n"
        "sd s2, 136(sp)\n"
        "sd s3, 144(sp)\n"
        "sd s4, 152(sp)\n"
        "sd s5, 160(sp)\n"
        "sd s6, 168(sp)\n"
        "sd s7, 176(sp)\n"
        "sd s8, 184(sp)\n"
        "sd s9, 192(sp)\n"
        "sd s10, 200(sp)\n"
        "sd s11, 208(sp)\n"
        "sd t3, 216(sp)\n"
        "sd t4, 224(sp)\n"
        "sd t5, 232(sp)\n"
        "sd t6, 240(sp)\n"
    );

    register unsigned long long int a0 asm("a0");
    register unsigned long long int a1 asm("a1");
    register unsigned long long int a2 asm("a2");
    register unsigned long long int a3 asm("a3");
    register unsigned long long int a4 asm("a4");
    register unsigned long long int a5 asm("a5");
    register unsigned long long int a6 asm("a6");
    register unsigned long long int a7 asm("a7");

    switch(a7) {
        case EXIT:
            Uexit(a0);
            break;
        case WRITE:
            a0 = Uwrite(a0, (char *)a1, a2);
            break;
        case READ:
            a0 = Uread(a0, (char *)a1, a2);
            break;
        case MMAP:
            a0 = (uint64_t)Ummap((void *)a0, a1, a2, a3, a4, a5);
            break;
        case MUNMAP:
            Umunmap((void *)a0, a1);
            break;
        case OPEN:
            a0 = Uopen((char *)a0, a1, a2);
            break;
        case CLOSE:
            Uclose(a0);
            break;
        case EXECVE:
            a0 = Uexecve((char *)a0);
            break;
        case MPROTECT:
            Umprotect((void *)a0, a1, a2);
            break;
    }

    // pop all registers from stack
    asm volatile (
        "ld ra, 0(sp)\n"
        "ld gp, 16(sp)\n"
        "ld tp, 24(sp)\n"
        "ld t0, 32(sp)\n"
        "ld t1, 40(sp)\n"
        "ld t2, 48(sp)\n"
        "ld s0, 56(sp)\n"
        "ld s1, 64(sp)\n"
        "ld a1, 80(sp)\n"
        "ld a2, 88(sp)\n"
        "ld a3, 96(sp)\n"
        "ld a4, 104(sp)\n"
        "ld a5, 112(sp)\n"
        "ld a6, 120(sp)\n"
        "ld a7, 128(sp)\n"
        "ld s2, 136(sp)\n"
        "ld s3, 144(sp)\n"
        "ld s4, 152(sp)\n"
        "ld s5, 160(sp)\n"
        "ld s6, 168(sp)\n"
        "ld s7, 176(sp)\n"
        "ld s8, 184(sp)\n"
        "ld s9, 192(sp)\n"
        "ld s10, 200(sp)\n"
        "ld s11, 208(sp)\n"
        "ld t3, 216(sp)\n"
        "ld t4, 224(sp)\n"
        "ld t5, 232(sp)\n"
        "ld t6, 240(sp)\n"
        "addi sp, sp, 256\n"
    );

    asm volatile(
        "mret"
    );
}