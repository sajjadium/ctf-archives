package com.ctf.invitation.invitation.exception;

import ognl.Ognl;
import ognl.OgnlContext;
import ognl.OgnlException;

public class InvalidKeyException {

    private String message;
    private static char[] denyCharList = {'@', '+', '~', '!','<', '%', 'j', 'T'};
    private static String[] denyKeywordList = {"\\u", "\\x", "0x", "not", "true", "false", "null", "Runtime", "Process", "File", "Path", "concat", "charAt", "parseInt", "toChars", "toString", "invoke", "start", "eval"};

    private static boolean detectUnsafeInput(String msg){
        for(char c : denyCharList){
            if(msg.indexOf(c) != -1){
                return true;
            }
        }

        for(String k : denyKeywordList){
            if(msg.indexOf(k) != -1){
                return true;
            }
        }

        return false;
    }

    public void setMessage(String msg) {
        try{
            this.message = msg;
            if (detectUnsafeInput(msg)){
                this.message = "#e=\"Invalid Key Exception\"";
            }
            OgnlContext ctx = new OgnlContext();
            Object expr = Ognl.parseExpression(this.message);
            Object value = Ognl.getValue(expr, ctx);
            System.out.println("Value: " + value);

        }catch (OgnlException e){
            e.printStackTrace();
        }
    }

    public String getMessage() {
        return this.message;
    }

}
