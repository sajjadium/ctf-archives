package com.ctf.invitation.invitation.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Invitation {

    private String host;
    private String date;
    private String location;
    private String description;


}
