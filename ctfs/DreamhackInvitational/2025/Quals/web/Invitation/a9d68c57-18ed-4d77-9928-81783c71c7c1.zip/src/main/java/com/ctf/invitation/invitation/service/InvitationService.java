package com.ctf.invitation.invitation.service;

import org.springframework.stereotype.Service;

@Service
public class InvitationService {

}
