package com.ctf.invitation.invitation.controller;

import com.alibaba.fastjson.JSONObject;
import com.ctf.invitation.invitation.exception.InvalidDateFormatException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.alibaba.fastjson.JSON;

import java.text.ParseException;
import java.text.SimpleDateFormat;

@Controller
public class InvitationController {

    private String validateDateFormat(String date) throws InvalidDateFormatException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(date);
            return date;
        } catch (ParseException e) {
            throw new InvalidDateFormatException("Invalid date format: " + date);
        }
    }

    @GetMapping("/")
    public String index(Model model) {
        return "redirect:/write";
    }

    @GetMapping("/write")
    public String writeForm(Model model) {
        return "write";
    }

    @PostMapping("/write")
    public String write(@RequestParam("host") String host,
                        @RequestParam("date") String date,
                        @RequestParam("location") String location,
                        @RequestParam("description") String description,
                        Model model) {
        try {
            String object = String.format("{\"host\": \"%s\", \"date\": \"%s\", \"location\": \"%s\", \"description\": \"%s\"}", host, date, location, description);
            JSONObject obj = JSON.parseObject(object);
            model.addAttribute("host", obj.get("host"));
            model.addAttribute("date", validateDateFormat(obj.get("date").toString()));
            model.addAttribute("location", obj.get("location"));
            model.addAttribute("description", obj.get("description"));

        } catch(InvalidDateFormatException e){
            model.addAttribute("host", "Error");
            model.addAttribute("date", "Error");
            model.addAttribute("location", e.getClass().getSimpleName());
            model.addAttribute("description", e.getMessage());
            return "invitation";
        } catch(Exception e) {
            e.printStackTrace();
            model.addAttribute("host", "Error");
            model.addAttribute("date", "Error");
            model.addAttribute("location", e.getClass().getName());
            model.addAttribute("description", e.getMessage());
            return "invitation";
        }

        return "invitation";
    }


}
