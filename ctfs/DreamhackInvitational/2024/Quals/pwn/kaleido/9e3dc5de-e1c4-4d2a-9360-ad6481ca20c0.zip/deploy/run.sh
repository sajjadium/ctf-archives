#!/bin/sh

timeout --foreground 300 qemu-system-x86_64 \
    -m 64M \
    -nographic \
    -kernel bzImage \
    -initrd rootfs.cpio.gz \
    -hda flag \
    -append "console=ttyS0 quiet oops=panic loglevel=3 panic=-1 panic_on_warn=1 pti=on kaslr page_alloc.shuffle=1 root=/dev/sda" \
    -no-reboot \
    -cpu kvm64,+smap,+smep \
    -monitor /dev/null \
    -net nic,model=virtio \
    -net user \

