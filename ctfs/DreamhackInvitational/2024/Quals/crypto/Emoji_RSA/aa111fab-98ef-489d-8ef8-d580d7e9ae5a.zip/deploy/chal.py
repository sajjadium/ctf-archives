from Crypto.Util.number import *
import random

EMOJIS = "🤣😅😇😍🤪🤑🤔🙄🥵🥶"
FLAG = open('flag', 'r').read()
MENU = """1. Encrypt your input
2. Change e
3. Encrypt the flag"""

def get_e(p, q):
    while True:
        t = random.randint(2 ** 16 + 1, 2 ** 18 + 1) | 1
        if GCD(t, (p - 1) * (q - 1)) == 1:
            return t

def emojify(emojis, s):
    return ''.join(emojis[int(ch)] for ch in str(s))

def main():
    emojis = list(EMOJIS)
    random.shuffle(emojis)

    p = getStrongPrime(512)
    q = getStrongPrime(512)
    n = p * q
    e = get_e(p, q)

    print(f"e: {e}")

    while True:
        print(MENU)
        inp = int(input('choice > ').strip())

        if inp == 1:
            inp = int(input('input > ').strip())
            print(emojify(emojis, pow(inp, e, n)))
        elif inp == 2:
            e = get_e(p, q)
            print(f"e: {e}")
        elif inp == 3:
            print(emojify(emojis, pow(bytes_to_long(FLAG.encode()), e, n)))

if __name__ == "__main__":
    main()
