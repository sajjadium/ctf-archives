#include <stdio.h>

int main()
{
    puts("DH{**fake_flag**}");
}