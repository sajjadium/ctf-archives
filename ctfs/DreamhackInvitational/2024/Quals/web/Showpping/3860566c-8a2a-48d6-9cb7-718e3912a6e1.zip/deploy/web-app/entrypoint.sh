#!/bin/sh
export HOST="coupon-app"
export PORT="8000"

exec "$@"