#!/bin/sh
export PORT=3000
export FLAG='DH{fake_flag}'
export NONCE='30502580d81f844336d204b5f6ff1a84'

exec "$@"