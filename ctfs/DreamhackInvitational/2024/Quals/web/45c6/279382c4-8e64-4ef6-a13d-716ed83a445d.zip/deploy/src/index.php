<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Lottery system</title>
</head>

<body>
    <h1>Lottery system</h1>
    <h2>Win to get FLAG!</h2>

    <a href="/draw.php">Click here to draw ticket</a>
    <br>
    <a href="/result.php">Click here to check if you won</a>
    <br>
</body>

</html>