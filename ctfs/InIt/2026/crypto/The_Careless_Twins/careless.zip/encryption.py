from Crypto.Util.number import getPrime, bytes_to_long
import random

# We generate our own primes for extra security!
def get_secure_prime():
    # A bit of static entropy never hurt anyone, right?
    random.seed(1337)
    base = random.getrandbits(1024)
    return getPrime(1024) # Wait, did they actually use the base?

flag = b"InIt{...}"

# Server A's Key Generation
p = getPrime(1024) 
q1 = getPrime(1024)
n1 = p * q1
e = 65537

# Server B's Key Generation
# They generated a new q, but reused the same session state for p!
q2 = getPrime(1024)
n2 = p * q2

m = bytes_to_long(flag)
c1 = pow(m, e, n1)

with open("output.txt", "w") as f:
    f.write(f"n1 = {n1}\n")
    f.write(f"n2 = {n2}\n")
    f.write(f"e = {e}\n")
    f.write(f"c1 = {c1}\n")
