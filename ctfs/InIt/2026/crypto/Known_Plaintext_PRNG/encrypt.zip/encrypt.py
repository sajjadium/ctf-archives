"""Generate flag.enc for the Known Plaintext PRNG challenge.

The organizer supplies the secret through the FLAG environment variable. The
player-facing copy intentionally does not contain the challenge flag.
"""

import os
from pathlib import Path


def next_key(key: int) -> int:
    """Advance the 32-bit linear congruential generator."""
    return (key * 1103515245 + 12345) & 0xFFFFFFFF


def encrypt_flag(flag: bytes, output_path: str | os.PathLike[str] = "flag.enc") -> None:
    """Encrypt *flag* and write the result to *output_path*."""
    key = int.from_bytes(os.urandom(4), "big")
    encrypted = bytearray()

    for offset in range(0, len(flag), 4):
        chunk = flag[offset : offset + 4]
        actual_len = len(chunk)

        if actual_len < 4:
            chunk += b"\x00" * (4 - actual_len)

        cipher_int = int.from_bytes(chunk, "big") ^ key
        encrypted.extend(cipher_int.to_bytes(4, "big")[:actual_len])
        key = next_key(key)

    Path(output_path).write_bytes(encrypted)


def main() -> None:
    flag = os.environ.get("FLAG")
    if not flag:
        raise SystemExit("Set FLAG in the environment before generating flag.enc")

    encrypt_flag(flag.encode("utf-8"))
    print("[+] Flag encrypted.")


if __name__ == "__main__":
    main()
