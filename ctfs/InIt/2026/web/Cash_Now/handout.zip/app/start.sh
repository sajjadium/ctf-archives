#!/bin/sh
node ./archive-service.js &
exec node server.js
