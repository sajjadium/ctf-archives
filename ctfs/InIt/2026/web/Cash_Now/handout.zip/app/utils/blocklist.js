const ipaddr = require("ipaddr.js");

const BLOCKED_RANGES = [
  "unspecified", "loopback", "linkLocal", "private",
  "uniqueLocal", "linkLocal", "carrierGradeNat",
  "reserved", "broadcast", "multicast",
];

function isReserved(address) {
  let parsed;
  try {
    parsed = ipaddr.parse(address);
  } catch {
    return true;
  }
  if (parsed.kind() === "ipv6" && parsed.range() === "ipv4Mapped") {
    parsed = parsed.toIPv4Address();
  }
  return BLOCKED_RANGES.includes(parsed.range());
}

function normalize(address) {
  let parsed;
  try {
    parsed = ipaddr.parse(address);
  } catch {
    return null;
  }
  if (parsed.kind() === "ipv6" && parsed.range() === "ipv4Mapped") {
    parsed = parsed.toIPv4Address();
  }
  return parsed.toString();
}

module.exports = { isReserved, normalize };
