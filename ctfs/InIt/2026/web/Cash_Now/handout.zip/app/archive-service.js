const express = require("express");
const crypto = require("crypto");

const app = express();

const UPLOAD_DIR = `/data/uploads/enc-${crypto.randomBytes(6).toString("hex")}/`;

app.get("/archive/config", (req, res) => {
  res.json({ upload_dir: UPLOAD_DIR });
});

app.get("/archive/health", (req, res) => res.json({ ok: true }));

app.get("/archive/stats", (req, res) => {
  res.json({
    uptime_s: Math.floor(process.uptime()),
    heap_used_mb: +(process.memoryUsage().heapUsed / 1048576).toFixed(1),
    region: "ap-southeast-3",
  });
});

app.use((req, res) => res.status(404).json({ error: "not found" }));

const PORT = 39417;
app.listen(PORT, "127.0.0.1", () => {
  console.log("[archive-service] ready");
});
