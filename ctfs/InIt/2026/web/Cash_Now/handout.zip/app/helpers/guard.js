const dns = require("dns");
const { isReserved, normalize } = require("../utils/blocklist");

const SCHEMES = ["http:", "https:"];

const TRUSTED_HOSTS = new Set(
  (process.env.TRUSTED_IMAGE_HOSTS || "").split(",").map((s) => s.trim()).filter(Boolean)
);

function parseTarget(raw) {
  if (typeof raw !== "string" || /[\x00-\x20\x7f]/.test(raw.trim())) {
    throw new Error("invalid url (control characters)");
  }
  let u;
  try {
    u = new URL(raw);
  } catch {
    throw new Error("invalid url");
  }
  if (!SCHEMES.includes(u.protocol)) {
    throw new Error("only http/https allowed");
  }
  if (!u.hostname) {
    throw new Error("invalid url (no host)");
  }
  const hostname = u.hostname.replace(/^\[/, "").replace(/\]$/, "");
  return {
    hostname,
    host: u.host.replace(/^\[/, "").replace(/\]$/, ""),
    port: u.port,
    protocol: u.protocol,
    pathname: u.pathname,
    search: u.search,
  };
}

function lookup(hostname) {
  return new Promise((resolve, reject) => {
    dns.lookup(hostname, { all: true, verbatim: true }, (err, addrs) => {
      if (err) return reject(new Error("dns lookup failed: " + err.code));
      if (!addrs || !addrs.length) return reject(new Error("no addresses"));
      resolve(addrs.map((a) => a.address));
    });
  });
}

async function resolvePinned(hostname) {
  const ipaddr = require("ipaddr.js");
  if (ipaddr.isValid(hostname)) {
    if (isReserved(hostname)) {
      return Promise.reject(new Error(
        `Blocked: '${hostname}' is a private/reserved address (${normalize(hostname)})`
      ));
    }
    return Promise.resolve(normalize(hostname));
  }
  const addrs = await lookup(hostname);
  for (const a of addrs) {
    if (isReserved(a)) {
      return Promise.reject(new Error(
        `Blocked: '${hostname}' resolves to private/reserved address ${a}`
      ));
    }
  }
  return addrs[0];
}

function lookupRaw(hostname) {
  return lookup(hostname).then((addrs) => addrs[0]);
}

async function resolveAddress(target) {
  return TRUSTED_HOSTS.has(target.hostname)
    ? lookupRaw(target.hostname)
    : resolvePinned(target.hostname);
}

module.exports = { parseTarget, resolveAddress, resolvePinned, lookupRaw };
