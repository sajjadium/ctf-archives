const axios = require("axios");
const https = require("https");
const http = require("http");
const net = require("net");

const BLOCK_REDIRECT = [301, 302];

function pinnedUrl(target, address) {
  const port = target.port || (target.protocol === "https:" ? 443 : 80);
  const hostPart = net.isIPv6(address) ? `[${address}]` : address;
  return `${target.protocol}//${hostPart}:${port}${target.pathname}${target.search}`;
}

async function fetchAvatar(rawUrl, target, address) {
  const response = await axios.get(pinnedUrl(target, address), {
    timeout: 8000,
    responseType: "arraybuffer",
    maxContentLength: 2 * 1024 * 1024,
    validateStatus: null,
    headers: { Host: target.host },
    httpsAgent: new https.Agent({
      servername: target.hostname,
      rejectUnauthorized: false,
    }),
    httpAgent: new http.Agent({ keepAlive: false }),

    beforeRedirect: (_options, { statusCode }) => {
      if (BLOCK_REDIRECT.includes(statusCode)) {
        throw new Error(`redirect ${statusCode} not followed`);
      }
    },
  });

  return response;
}

module.exports = { fetchAvatar };
