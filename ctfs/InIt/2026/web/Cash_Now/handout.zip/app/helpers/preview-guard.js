const fs = require("fs");
const path = require("path");
const { getConfig } = require("./config");

const IMG_MIME = {
  ".png": "image/png",
  ".txt": "text/plain",
};

function checkPreviewPath(raw) {
  const resolved = path.resolve(String(raw || ""));
  if (!resolved.startsWith(getConfig().upload_dir)) {
    return { status: 403, error: "preview is restricted to the verification storage area" };
  }
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile()) {
    return { status: 404, error: "document not found" };
  }
  return { resolved };
}

module.exports = { IMG_MIME, checkPreviewPath };
