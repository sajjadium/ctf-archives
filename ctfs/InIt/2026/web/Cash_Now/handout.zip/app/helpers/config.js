const http = require("http");
const fs = require("fs");
const path = require("path");

let config = null;

function fetchConfig() {
  return new Promise((resolve, reject) => {
    http
      .get("http://127.0.0.1:39417/archive/config", (res) => {
        let body = "";
        res.on("data", (c) => (body += c));
        res.on("end", () => resolve(JSON.parse(body)));
      })
      .on("error", reject);
  });
}

async function loadConfig(retries = 20) {
  for (let i = 0; i < retries; i++) {
    try {
      const data = await fetchConfig();
      if (data.upload_dir) {
        config = data;
        fs.mkdirSync(path.join(config.upload_dir, "tmp"), { recursive: true });
        return config;
      }
    } catch {}
    await new Promise((r) => setTimeout(r, 500));
  }
  throw new Error("internal config unavailable");
}

function getConfig() {
  return config;
}

module.exports = { loadConfig, getConfig };
