const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { archiveDir } = require("./docstore");

const KEY = crypto.randomBytes(32);
const FORBIDDEN_NAME_CHARS = /[#%&{}<>*?/$!'"@+`|=]/;

class ArchiveNameError extends Error {}

function encrypt(buf) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", KEY, iv);
  return Buffer.concat([cipher.update(buf), cipher.final(), cipher.getAuthTag()]);
}

function encryptAndStore(buf, docId, base) {
  if (FORBIDDEN_NAME_CHARS.test(base)) {
    throw new ArchiveNameError("filename contains forbidden characters");
  }
  const out = path.join(archiveDir(), `${docId}-${base}.enc`);
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, encrypt(buf));
  return out;
}

module.exports = { ArchiveNameError, encryptAndStore };
