const fs = require("fs");
const path = require("path");
const { getConfig } = require("./config");

const TMP_TTL_MS = 4000;

function tmpDir() {
  return path.join(getConfig().upload_dir, "tmp");
}

function archiveDir() {
  return path.join(path.dirname(getConfig().upload_dir), "private");
}

function tmpPath(base, ext) {
  return path.join(tmpDir(), base + ext);
}

function writeTmp(buf, ...parts) {
  const out = tmpPath(...parts);
  fs.writeFileSync(out, buf);
  return out;
}

function removeTmp(...files) {
  for (const f of files) fs.promises.unlink(f).catch(() => {});
}

function cleanupLater(...files) {
  setTimeout(() => removeTmp(...files), TMP_TTL_MS);
}

module.exports = { TMP_TTL_MS, tmpDir, archiveDir, tmpPath, writeTmp, removeTmp, cleanupLater };
