const crypto = require("crypto");

const users = new Map();
const sessions = new Map();

function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie || "";
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function currentUser(req) {
  const token = parseCookies(req).session;
  return token && sessions.has(token) ? sessions.get(token) : null;
}

function register(username, password) {
  if (!username || !password || typeof username !== "string" || typeof password !== "string") {
    throw new Error("username and password are required");
  }
  if (!/^[a-zA-Z0-9_.-]{3,24}$/.test(username)) {
    throw new Error("username must be 3-24 chars (letters, digits, _ . -)");
  }
  if (users.has(username)) throw new Error("username already taken");
  users.set(username, { password });
}

function login(username, password) {
  const u = users.get(username);
  if (!u || u.password !== password) throw new Error("invalid username or password");
  const token = crypto.randomBytes(24).toString("hex");
  sessions.set(token, username);
  if (sessions.size > 5000) {
    const oldest = sessions.keys().next().value;
    sessions.delete(oldest);
  }
  return token;
}

function logout(token) {
  sessions.delete(token);
}

function requireLogin(message) {
  return (req, res, next) => {
    if (!currentUser(req)) {
      return res.status(401).json({ error: message });
    }
    next();
  };
}

module.exports = { parseCookies, currentUser, register, login, logout, requireLogin };
