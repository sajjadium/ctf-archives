const express = require("express");
const auth = require("../helpers/auth");

const router = express.Router();

router.post("/api/register", (req, res) => {
  try {
    const { username, password } = req.body || {};
    auth.register(username, password);
    res.json({ ok: true, message: "account created — you can log in now" });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.post("/api/login", (req, res) => {
  try {
    const { username, password } = req.body || {};
    const token = auth.login(username, password);
    res.setHeader("set-cookie", `session=${token}; HttpOnly; Path=/; SameSite=Lax`);
    res.json({ ok: true, username });
  } catch (e) {
    res.status(401).json({ error: e.message });
  }
});

router.post("/api/logout", (req, res) => {
  const token = auth.parseCookies(req).session;
  auth.logout(token);
  res.setHeader("set-cookie", "session=; Max-Age=0; Path=/");
  res.json({ ok: true });
});

router.get("/api/me", (req, res) => {
  const user = auth.currentUser(req);
  res.json({ user });
});

module.exports = router;
