const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");
const auth = require("../helpers/auth");
const { tmpPath, writeTmp, removeTmp, cleanupLater } = require("../helpers/docstore");
const { ArchiveNameError, encryptAndStore } = require("../helpers/doccrypto");
const { IMG_MIME, checkPreviewPath } = require("../helpers/preview-guard");

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });
const router = express.Router();

function makeThumbnail(rawPath, thumbPath) {
  return new Promise((resolve) => {
    execFile("convert", [rawPath, "-resize", "256x256", thumbPath], (err) => resolve(err));
  });
}

router.post("/documents/upload", auth.requireLogin("log in to submit documents"),
  upload.single("document"), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: "missing 'document' (multipart)" });

  const owner = auth.currentUser(req);
  const docId = crypto.randomBytes(6).toString("hex");
  const thumbPath = tmpPath(owner, ".png");

  let rawPath;
  try {
    rawPath = writeTmp(req.file.buffer, owner, ".orig.png");
  } catch (e) {
    return res.status(500).json({ error: "storage write failed: " + e.message });
  }

  await makeThumbnail(rawPath, thumbPath);
  removeTmp(rawPath);

  let thumb;
  try {
    thumb = fs.readFileSync(thumbPath);
  } catch (e) {
    return res.status(400).json({ error: "verification failed: not a valid image" });
  }

  cleanupLater(thumbPath);

  try {
    const base = path.basename(req.file.originalname).replace(/\.[^.]+$/, "");
    const stored = encryptAndStore(thumb, docId, base);
    removeTmp(thumbPath);
    return res.json({
      status: "verified",
      document_id: docId,
      archive: path.basename(stored),
      message: "document verified and archived (encrypted)",
    });
  } catch (e) {
    if (e instanceof ArchiveNameError) {
      removeTmp(thumbPath);
      return res.status(400).json({ error: "invalid document name" });
    }
    throw e;
  }
});

router.get("/documents/preview", (req, res) => {
  const check = checkPreviewPath(req.query.path);
  if (check.error) {
    return res.status(check.status).json({ error: check.error });
  }

  res.setHeader("content-type", IMG_MIME[path.extname(check.resolved)] || "application/octet-stream");
  fs.createReadStream(check.resolved).pipe(res);
});

module.exports = router;
