const express = require("express");
const auth = require("../helpers/auth");
const { parseTarget, resolveAddress } = require("../helpers/guard");
const { fetchAvatar } = require("../helpers/fetcher");

const router = express.Router();

router.post("/profile/avatar", auth.requireLogin("log in to manage your profile"), async (req, res) => {
  const url = req.body && req.body.url;
  if (!url || typeof url !== "string") {
    return res.status(400).json({ error: "missing 'url'" });
  }

  let target, address;
  try {
    target = parseTarget(url);
    address = await resolveAddress(target);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }

  try {
    const r = await fetchAvatar(url, target, address);
    const ctype = String(r.headers["content-type"] || "");
    if (!ctype.startsWith("image/")) {
      const body = Buffer.from(r.data).toString("utf8", 0, 500);
      return res.status(400).json({
        error: `unexpected content-type '${ctype || "none"}', body: ${body}`,
      });
    }
    return res.json({
      ok: true,
      message: "avatar updated",
      content_type: ctype,
      size: r.data.length,
    });
  } catch (e) {
    return res.status(502).json({ error: "fetch failed: " + e.message });
  }
});

module.exports = router;
