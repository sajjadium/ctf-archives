const express = require("express");
const indexRoutes = require("./routes/index");
const authRoutes = require("./routes/auth");
const avatarRoutes = require("./routes/avatar");
const documentRoutes = require("./routes/documents");
const { loadConfig } = require("./helpers/config");

const app = express();
app.use(express.json());
app.use(indexRoutes);
app.use(authRoutes);
app.use(avatarRoutes);
app.use(documentRoutes);

loadConfig()
  .then(() => {
    app.listen(3000, () => console.log("[app] listening on :3000"));
  })
  .catch((e) => {
    console.error("[app] fatal:", e.message);
    process.exit(1);
  });
