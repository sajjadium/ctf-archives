import os

from flask import Flask

import db
from routes.auth import bp as auth_bp
from routes.profile import bp as profile_bp
from routes.invoices import bp as invoices_bp
from routes.reports import bp as reports_bp


def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ["SECRET_KEY"]
    app.config["MAX_CONTENT_LENGTH"] = 64 * 1024
    db.init(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(profile_bp)
    app.register_blueprint(invoices_bp)
    app.register_blueprint(reports_bp)

    from routes.auth import current_user

    @app.context_processor
    def inject_user():
        return {"current_user": current_user}

    @app.route("/")
    def index():
        from flask import render_template
        return render_template("index.html")

    @app.errorhandler(Exception)
    def on_error(e):
        from flask import render_template
        return render_template("error.html", message="Something went wrong. Please try again."), 500

    return app


app = create_app()
