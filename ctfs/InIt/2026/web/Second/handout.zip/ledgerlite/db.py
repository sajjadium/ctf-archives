import os

import pymysql


_pool = None


def init(app):
    global _pool
    _pool = pymysql.connect(
        host=os.environ["DB_HOST"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        autocommit=True,
        cursorclass=pymysql.cursors.DictCursor,
    )
    with _pool.cursor() as cur:
        cur.execute("SELECT 1")


def query_all(sql, args=()):
    with _pool.cursor() as cur:
        cur.execute(sql, args)
        return cur.fetchall()


def query_one(sql, args=()):
    with _pool.cursor() as cur:
        cur.execute(sql, args)
        return cur.fetchone()


def execute(sql, args=()):
    with _pool.cursor() as cur:
        cur.execute(sql, args)
