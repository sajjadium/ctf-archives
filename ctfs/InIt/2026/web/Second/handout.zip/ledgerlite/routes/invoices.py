from flask import Blueprint, redirect, render_template, request

import db
from routes.auth import current_user, login_required

bp = Blueprint("invoices", __name__)


@bp.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    stats = db.query_one(
        "SELECT COUNT(*) AS total, COALESCE(SUM(amount), 0) AS volume "
        "FROM invoices WHERE user_id = %s",
        (user["id"],),
    )
    return render_template("dashboard.html", user=user, stats=stats)


@bp.route("/invoices")
@login_required
def invoices():
    user = current_user()
    rows = db.query_all(
        "SELECT id, label, amount, status, created_at FROM invoices "
        "WHERE user_id = %s ORDER BY created_at DESC",
        (user["id"],),
    )
    return render_template("invoices.html", user=user, rows=rows)


@bp.route("/invoices/add", methods=["POST"])
@login_required
def add_invoice():
    user = current_user()
    label = request.form.get("label", "").strip()[:120]
    status = request.form.get("status", "").strip()[:16]
    try:
        amount = round(float(request.form.get("amount", "0")), 2)
    except ValueError:
        amount = 0.00

    if label:
        db.execute(
            "INSERT INTO invoices (user_id, label, amount, status) VALUES (%s, %s, %s, %s)",
            (user["id"], label, amount, status or "draft"),
        )
    return redirect("/invoices")


@bp.route("/search")
@login_required
def search():
    user = current_user()
    term = request.args.get("q", "").strip()
    rows = []
    if term:
        rows = db.query_all(
            "SELECT id, label, amount, status, created_at FROM invoices "
            "WHERE user_id = %s AND label LIKE %s",
            (user["id"], f"%{term}%"),
        )
    return render_template("search.html", user=user, term=term, rows=rows)
