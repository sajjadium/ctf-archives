from flask import Blueprint, redirect, render_template, request

import db
from routes.auth import current_user, login_required

bp = Blueprint("reports", __name__)


@bp.route("/reports")
@login_required
def reports():
    user = current_user()
    rows = db.query_all(
        "SELECT id, title, sort_key, created_at FROM reports "
        "WHERE user_id = %s ORDER BY id DESC",
        (user["id"],),
    )
    return render_template("reports.html", user=user, rows=rows)


@bp.route("/reports/new", methods=["GET", "POST"])
@login_required
def new_report():
    user = current_user()
    title = ""
    sort_key = ""

    if request.method == "POST":
        title = request.form.get("title", "").strip()[:60]
        sort_key = request.form.get("sort_key", "").strip()[:100]

        if not title:
            return render_template("report_new.html", user=user,
                                   error="Give the report a title.", title=title, sort_key=sort_key)

        db.execute(
            "INSERT INTO reports (user_id, title, sort_key) VALUES (%s, %s, %s)",
            (user["id"], title, sort_key),
        )
        return redirect("/reports")

    return render_template("report_new.html", user=user, error=None, title=title, sort_key=sort_key)


@bp.route("/reports/<int:report_id>/run")
@login_required
def run_report(report_id):
    user = current_user()
    report = db.query_one(
        "SELECT id, title, sort_key FROM reports WHERE id = %s AND user_id = %s",
        (report_id, user["id"]),
    )
    if report is None:
        return redirect("/reports")

    try:
        rows = db.query_all(
            "SELECT id, label, amount, status, created_at FROM invoices "
            f"WHERE user_id = {user['id']} ORDER BY {report['sort_key']}"
        )
    except Exception as e:
        return render_template("report_run.html", user=user, report=report, rows=[], error=str(e))

    return render_template("report_run.html", user=user, report=report, rows=rows, error=None)
