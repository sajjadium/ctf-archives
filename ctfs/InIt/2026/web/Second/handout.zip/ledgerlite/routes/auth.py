import hashlib
import re

from flask import Blueprint, redirect, render_template, request, session

import db

bp = Blueprint("auth", __name__)


def current_user():
    if "uid" not in session:
        return None
    return db.query_one(
        "SELECT id, username, display_name FROM users WHERE id = %s",
        (session["uid"],),
    )


def login_required(fn):
    from functools import wraps

    @wraps(fn)
    def wrapper(*a, **kw):
        if current_user() is None:
            return redirect("/login")
        return fn(*a, **kw)

    return wrapper


@bp.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        display_name = request.form.get("display_name", "").strip()[:64]

        if not re.fullmatch(r"[a-z0-9_]{4,20}", username):
            return render_template("register.html",
                error="Username must be 4-20 characters: lowercase letters, numbers, underscores.")
        if len(password) < 8:
            return render_template("register.html", error="Password must be at least 8 characters.")

        if db.query_one("SELECT id FROM users WHERE username = %s", (username,)):
            return render_template("register.html", error="That username is already taken.")

        db.execute(
            "INSERT INTO users (username, password_hash, display_name) VALUES (%s, %s, %s)",
            (username, hashlib.sha256(password.encode()).hexdigest(), display_name),
        )
        uid = db.query_one("SELECT id FROM users WHERE username = %s", (username,))
        session["uid"] = uid["id"]
        return redirect("/dashboard")

    return render_template("register.html")


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        row = db.query_one(
            "SELECT id, password_hash FROM users WHERE username = %s", (username,)
        )
        if row is None or row["password_hash"] != hashlib.sha256(password.encode()).hexdigest():
            return render_template("login.html", error="Invalid username or password.")
        session["uid"] = row["id"]
        return redirect("/dashboard")

    return render_template("login.html")


@bp.route("/logout")
def logout():
    session.clear()
    return redirect("/")
