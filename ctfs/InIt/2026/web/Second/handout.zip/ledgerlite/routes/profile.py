from flask import Blueprint, render_template, request

import db
from routes.auth import current_user, login_required

bp = Blueprint("profile", __name__)


@bp.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = current_user()
    saved = False

    if request.method == "POST":
        display_name = request.form.get("display_name", "").strip()[:64]
        db.execute(
            "UPDATE users SET display_name = %s WHERE id = %s",
            (display_name, user["id"]),
        )
        saved = True
        user = current_user()

    return render_template("settings.html", user=user, saved=saved)
