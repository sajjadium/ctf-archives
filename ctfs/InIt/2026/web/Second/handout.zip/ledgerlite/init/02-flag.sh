#!/bin/bash
set -e
mysql -uroot -p"${MYSQL_ROOT_PASSWORD}" ledgerlite \
  -e "UPDATE flags SET flag_value='${FLAG:-flag_not_set}' WHERE id = 1;"
