# tanvoro-deploy

Deployment tooling for the Tanvoro web tier.

## Usage
    ./deploy/deploy.sh staging

## Notes
Secrets are injected by CI from the vault; see deploy/.env.example.
