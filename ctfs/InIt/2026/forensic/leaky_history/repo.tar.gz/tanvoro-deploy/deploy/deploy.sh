#!/usr/bin/env bash
set -euo pipefail
ENVIRON="${1:-staging}"
echo "deploying to $ENVIRON ..."
# loads deploy/secrets.env in CI
