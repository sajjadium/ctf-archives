#!/usr/bin/env python3
# Found under /opt/agent/ during IR on the instance. Reviewed as evidence.
# Decrypts its local config vault using a key tied to the EC2 instance identity.
import hashlib, json, sys
from pathlib import Path
from Crypto.Cipher import AES

SALT = "s4lt_"

def instance_id() -> str:
    # On the live host this read the instance metadata service (IMDS).
    # Offline, it would use a cached id -- but that cache is not present here.
    cache = Path(__file__).with_name("instance-id.cache")
    if cache.exists():
        return cache.read_text().strip()
    import urllib.request
    url = "http://169.254.169.254/latest/meta-data/instance-id"
    return urllib.request.urlopen(url, timeout=1).read().decode()

def derive_key(iid: str) -> bytes:
    # 256-bit key = SHA-256 of the salt concatenated with the instance-id.
    return hashlib.sha256((SALT + iid).encode()).digest()

def open_vault(path: str) -> dict:
    blob = Path(path).read_bytes()
    iv, ciphertext = blob[:16], blob[16:]          # IV is prepended
    key = derive_key(instance_id())
    plain = AES.new(key, AES.MODE_CBC, iv).decrypt(ciphertext)
    plain = plain[:-plain[-1]]                      # strip PKCS#7 padding
    return json.loads(plain)

if __name__ == "__main__":
    vault = sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).with_name("vault.bin"))
    print(json.dumps(open_vault(vault), indent=2))
