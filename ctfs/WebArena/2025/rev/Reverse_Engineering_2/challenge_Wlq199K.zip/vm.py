#!/usr/bin/env python3
"""
vm.py - Custom obfuscated VM interpreter (challenge binary)
Usage: python3 vm.py prog.bin

Notes:
 - The interpreter expects an encrypted prog.bin (encryption as used by the generator).
 - For the challenge distribution, the file given to participants is vm.py + prog.bin.
 - The decryption routine is intentionally not obvious: it's the inverse of the generator encryption.
"""

import sys
import struct

def decrypt_bytes(enc_bytes):
    # The decryption must invert: enc = ((b ^ KEY) + (i*37)) & 0xff
    # We'll attempt to locate KEY by scanning for plausible opcodes after decrypting with a guessed key.
    # For challenge distribution, we intentionally embed the KEY inside this interpreter in a shuffled form,
    # but here for clarity the program will try to auto-detect KEY by testing small values that map the first
    # opcodes into a valid opcode set.
    # Valid opcodes (raw before encryption): 0x10,0x11,0x20-0x24,0x30-0x31,0x40,0x50,0x60,0xFF
    VALID = set([0x10,0x11,0x20,0x21,0x22,0x23,0x24,0x30,0x31,0x40,0x50,0x60,0xFF])

    def try_key(k):
        raw = bytearray()
        for i, ev in enumerate(enc_bytes):
            rv = ((ev - ((i * 37) & 0xFF)) & 0xFF) ^ k
            raw.append(rv)
        # quick check: first opcode must be 0x10 (we pushed a const)
        if raw and raw[0] == 0x10:
            # also ensure some other opcodes appear
            cnt_valid = sum(1 for x in raw[:8] if x in VALID)
            return True, bytes(raw)
        return False, None

    # try all keys 0..255 (fast). We pick first that looks valid.
    for k in range(256):
        ok, raw = try_key(k)
        if ok:
            return raw, k
    raise RuntimeError("Failed to auto-detect decryption key")

def run_vm(raw):
    pc = 0
    stack = []
    data = [0] * 256
    out = bytearray()
    while pc < len(raw):
        op = raw[pc]
        pc += 1
        if op == 0x10:  # PUSH_CONST u8
            v = raw[pc]; pc += 1
            stack.append(v)
        elif op == 0x11:  # PUSH_CONST16 u16
            v = raw[pc] | (raw[pc+1] << 8); pc += 2
            stack.append(v & 0xFF)
        elif op == 0x20:  # ADD
            a = stack.pop(); b = stack.pop(); stack.append((a + b) & 0xFF)
        elif op == 0x21:  # SUB
            a = stack.pop(); b = stack.pop(); stack.append((a - b) & 0xFF)
        elif op == 0x22:  # XOR
            a = stack.pop(); b = stack.pop(); stack.append((a ^ b) & 0xFF)
        elif op == 0x23:  # SHL
            a = stack.pop(); stack.append((a << 1) & 0xFF)
        elif op == 0x24:  # SHR
            a = stack.pop(); stack.append((a >> 1) & 0xFF)
        elif op == 0x30:  # STORE_IDX <u8>
            idx = raw[pc]; pc += 1
            data[idx] = stack.pop() & 0xFF
        elif op == 0x31:  # LOAD_IDX <u8>
            idx = raw[pc]; pc += 1
            stack.append(data[idx] & 0xFF)
        elif op == 0x40:  # JNZ <s8>
            off = struct.unpack('b', bytes([raw[pc]]))[0]; pc += 1
            v = stack.pop()
            if v != 0:
                pc += off
        elif op == 0x50:  # APPEND_OUT
            v = stack.pop()
            out.append(v & 0xFF)
        elif op == 0x60:  # NOP
            pass
        elif op == 0xFF:  # HALT
            break
        else:
            # unknown opcode: abort
            raise RuntimeError(f\"Unknown opcode 0x{op:02x} at pc {pc-1}\")
    return bytes(out)

def main():
    if len(sys.argv) < 2:
        print(\"Usage: vm.py prog.bin\")
        return
    fn = sys.argv[1]
    enc = open(fn, 'rb').read()
    raw, key = decrypt_bytes(enc)
    print(f\"[vm] detected key=0x{key:02x}, raw_len={len(raw)} bytes\")
    out = run_vm(raw)
    try:
        s = out.decode('utf-8')
    except:
        s = out
    print(\"--- VM output ---\\n\" + str(s))

if __name__ == '__main__':
    main()
