const express = require('express');
const bodyParser = require('body-parser');
const cheerio = require('cheerio');
const { v4: uuidv4 } = require('uuid');
const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URL || 'mongodb://localhost:27017/';
const client = new MongoClient(uri);
const app = express();
const port = process.env.PORT || 3001;
const regex = /^[a-zA-Z0-9]+$/;

app.set('view engine', 'ejs');

app.use(express.static('public'));

app.use(bodyParser.urlencoded({ extended: true }));

// got this from https://portswigger.net/web-security/cross-site-scripting/cheat-sheet now no XSS script kiddies :)
const blacklist = "xss a abbr acronym address applet area article aside audio b base bdi bdo big blink blockquote br button canvas caption center cite code col colgroup command content data datalist dd del details dfn dialog dir div dl dt element em embed fieldset figcaption figure font footer form frame frameset h1 head header hgroup hr html i iframe image img input ins kbd keygen label legend li link listing main map mark marquee menu menuitem meta meter multicol nav nextid nobr noembed noframes noscript object ol optgroup p output p param picture plaintext pre progress q rb rp rt rtc ruby s samp script section select shadow slot small source spacer span strike strong sub summary sup svg table tbody td template textarea tfoot th thead time title tr track tt u ul var video wbr xmp".split(" ")
const attrs = "onafterprint onafterscriptexecute onanimationcancel onanimationend onanimationiteration onanimationstart onauxclick onbeforecopy autofocus onbeforecut onbeforeinput onbeforeprint onbeforescriptexecute onbeforetoggle onbeforeunload onbegin onblur oncanplay oncanplaythrough onchange onclick onclose oncontextmenu oncopy oncuechange oncut ondblclick ondrag ondragend ondragenter ondragexit ondragleave ondragover ondragstart ondrop ondurationchange onend onended onerror onfocus onfocus onfocusin onfocusout onformdata onfullscreenchange onhashchange oninput oninvalid onkeydown onkeypress onkeyup onload onloadeddata onloadedmetadata onloadstart onmessage onmousedown onmouseenter onmouseleave onmousemove onmouseout onmouseover onmouseup onmousewheel onmozfullscreenchange onpagehide onpageshow onpaste onpause onplay onplaying onpointercancel onpointerdown onpointerenter onpointerleave onpointermove onpointerout onpointerover onpointerrawupdate onpointerup onpopstate onprogress onratechange onrepeat onreset onresize onscroll onscrollend onsearch onseeked onseeking onselect onselectionchange onselectstart onshow onsubmit onsuspend ontimeupdate ontoggle ontoggle(popover) ontouchend ontouchmove ontouchstart ontransitioncancel ontransitionend ontransitionrun ontransitionstart onunhandledrejection onunload onvolumechange onwebkitanimationend onwebkitanimationiteration onwebkitanimationstart onwebkitmouseforcechanged onwebkitmouseforcedown onwebkitmouseforceup onwebkitmouseforcewillbegin onwebkitplaybacktargetavailabilitychanged onwebkittransitionend onwebkitwillrevealbottom onwheel".split(" ")

function removeXSS(html) {
    const unsafe = cheerio.load(html);
    for (const tag of blacklist) {
        unsafe(tag, "body").remove();
    }
    unsafe('*').each((i, el) => {
        for (const attr of attrs) {
            unsafe(el).removeAttr(attr);
        }
    });
    return unsafe("body").html();

}

function analyzeHTML(html) {
    const $ = cheerio.load(html);

    const personalityTraits = [];

    const divCount = $('div').length;
    const commentCount = $('*').contents().filter(function () {
        return this.type === 'comment';
    }).length;

    const h1Count = $('h1').length;
    const inlineStyleCount = $('[style]').length;

    if (divCount > 5) {
        personalityTraits.push("You're a minimalist at heart, using `div` to simplify everything!");
    }

    if (commentCount > 0) {
        personalityTraits.push("You're a planner! You leave notes in your code, thinking ahead.");
    }

    if (h1Count > 1) {
        personalityTraits.push("You're ambitious, more than one `h1` shows your desire to stand out.");
    }

    if (inlineStyleCount > 0) {
        personalityTraits.push("You like immediate results - inline styles show you're a doer, not a planner.");
    }

    if (personalityTraits.length === 0) {
        personalityTraits.push("Your HTML is balanced and thoughtful!");
    }

    return personalityTraits;
}

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).render('display', { error: true, message: 'Something went wrong!' });
});

app.get('/', (_, res) => {
    res.render('index', { result: null });
});

app.post('/analyze', async (req, res, next) => {
    try {
        const badhtml = req.body.html;
        const name = req.body.name;
        if (!regex.test(name)) {
            res.render('display', { error: true, message: "Invalid name" });
        }
        if (badhtml.length > 80) {
            res.render('display', { error: true, message: "Input too large" });
        }
        const database = client.db('html-personality-analyzer');
        const collection = database.collection('users-data');
        const analysis = analyzeHTML(badhtml);
        const goodhtml = removeXSS(badhtml);
        const data = {
            "html": goodhtml,
            "analysis": analysis,
            "postId": uuidv4(),
            "name": name
        };
        await collection.insertOne(data);
        res.redirect(`/result/${data.postId}`);
    } catch (err) {
        next(err);
    }
});

app.get('/result/:post_id', async (req, res, next) => {
    try {
        const database = client.db('html-personality-analyzer');
        const collection = database.collection('users-data');
        const postId = req.params.post_id;
        const updatedDoc = await collection.findOne({ "postId": postId });

        if (!updatedDoc) {
            res.render('display', { error: true, message: "Not found!" });
        }
        res.render('display', { name: updatedDoc.name, analysis: updatedDoc.analysis.join("|"), html: updatedDoc.html, error: false });
    } catch (err) {
        next(err);
    }
});

app.listen(port, async () => {
    try {
        await client.connect();
        console.log(`HTML Personality Analyzer running at http://localhost:${port}`);
        console.log("Connected to MongoDB");
    } catch (err) {
        console.error("Failed to connect to MongoDB", err);
    }
});
