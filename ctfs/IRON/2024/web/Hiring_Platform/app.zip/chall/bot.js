// Just for reference

await page.goto(`${CONFIG.APPURL}/login`, { waitUntil: 'domcontentloaded' });
await page.focus('input[name=email]');
await page.keyboard.type(CONFIG.ADMIN_USERNAME);
await page.focus('input[name=password]');
await page.keyboard.type(CONFIG.ADMIN_PASS);
await page.click('input[type="submit"]');
// check urlToVisit matches the challenge domain regex
await page.goto(urlToVisit, {
    waitUntil: 'domcontentloaded',
    timeout: CONFIG.TIMEOUT
});
await page.close()
