`npm run dev`

[http://localhost:3000](http://localhost:3000)
