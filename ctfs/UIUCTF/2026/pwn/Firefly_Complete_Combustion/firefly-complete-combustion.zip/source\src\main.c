#include "lauxlib.h"
#include "lua.h"
#include "lualib.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHUNK_SIZE (64U * 1024U)

typedef struct Library {
  const char *name;
  lua_CFunction open;
} Library;

static const Library libraries[] = {
    {LUA_GNAME, luaopen_base},
    {LUA_COLIBNAME, luaopen_coroutine},
    {LUA_TABLIBNAME, luaopen_table},
    {LUA_STRLIBNAME, luaopen_string},
    {LUA_MATHLIBNAME, luaopen_math},
    {LUA_UTF8LIBNAME, luaopen_utf8},
    {NULL, NULL},
};

static int read_exact(void *destination, size_t length) {
  unsigned char *cursor = destination;

  while (length != 0) {
    size_t received = fread(cursor, 1, length, stdin);
    if (received == 0)
      return 0;
    cursor += received;
    length -= received;
  }
  return 1;
}

static void remove_global(lua_State *L, const char *name) {
  lua_pushnil(L);
  lua_setglobal(L, name);
}

static void open_libraries(lua_State *L) {
  const Library *library;

  for (library = libraries; library->name != NULL; ++library) {
    luaL_requiref(L, library->name, library->open, 1);
    lua_pop(L, 1);
  }

  remove_global(L, "dofile");
  remove_global(L, "load");
  remove_global(L, "loadfile");
}

static int report_lua_error(lua_State *L, const char *stage) {
  const char *message = lua_tostring(L, -1);
  fprintf(stderr, "ignition %s failed: %s\n", stage,
          message != NULL ? message : "unknown Lua error");
  return EXIT_FAILURE;
}

int main(void) {
  unsigned char encoded_length[4];
  unsigned char *chunk;
  uint32_t chunk_length;
  lua_State *L;
  int status;

  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);

  puts("      FYREFLY TYPE-IV // COMPLETE COMBUSTION");
  puts("  GLAMOTH IRON CAVALRY // LUA 5.5.0");
  puts("  Elio's script is not the one loaded today.");
  puts("send 4-byte big-endian length + Lua chunk:");

  if (!read_exact(encoded_length, sizeof(encoded_length))) {
    fputs("combat script never arrived\n", stderr);
    return EXIT_FAILURE;
  }

  chunk_length = ((uint32_t)encoded_length[0] << 24) |
                 ((uint32_t)encoded_length[1] << 16) |
                 ((uint32_t)encoded_length[2] << 8) |
                 (uint32_t)encoded_length[3];
  if (chunk_length < 4 || chunk_length > MAX_CHUNK_SIZE) {
    fputs("combat script length rejected\n", stderr);
    return EXIT_FAILURE;
  }

  chunk = malloc(chunk_length);
  if (chunk == NULL) {
    fputs("combat simulator exhausted\n", stderr);
    return EXIT_FAILURE;
  }
  if (!read_exact(chunk, chunk_length)) {
    free(chunk);
    fputs("combat script was truncated\n", stderr);
    return EXIT_FAILURE;
  }
  if (memcmp(chunk, LUA_SIGNATURE, sizeof(LUA_SIGNATURE) - 1) != 0) {
    free(chunk);
    fputs("only Lua binary combat scripts are accepted\n", stderr);
    return EXIT_FAILURE;
  }

  L = luaL_newstate();
  if (L == NULL) {
    free(chunk);
    fputs("combat simulator initialization failed\n", stderr);
    return EXIT_FAILURE;
  }
  open_libraries(L);

  status = luaL_loadbufferx(L, (const char *)chunk, chunk_length,
                            "@complete-combustion", "b");
  free(chunk);
  if (status != LUA_OK) {
    status = report_lua_error(L, "loading");
    lua_close(L);
    return status;
  }

  status = lua_pcall(L, 0, 0, 0);
  if (status != LUA_OK) {
    status = report_lua_error(L, "execution");
    lua_close(L);
    return status;
  }

  puts("combat script complete");
  lua_close(L);
  return EXIT_SUCCESS;
}
