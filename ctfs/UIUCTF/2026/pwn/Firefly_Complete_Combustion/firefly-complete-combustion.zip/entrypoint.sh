#!/bin/bash
set -Eeuo pipefail

kctf_setup
exec kctf_drop_privs socat "TCP-LISTEN:1337,reuseaddr,fork" "EXEC:kctf_pow nsjail --config /home/user/nsjail.cfg -- /home/user/firefly"
