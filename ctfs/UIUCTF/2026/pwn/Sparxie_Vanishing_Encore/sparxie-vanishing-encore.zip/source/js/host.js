mergeInto(LibraryManager.library, {
  sparxie_prepare: function (outputPtr, outputLen) {
    try {
      const crypto = require("crypto");
      crypto.randomFillSync(HEAPU8.subarray(outputPtr, outputPtr + outputLen));
      return 0;
    } catch (_) {
      return -1;
    }
  },

  sparxie_redeem: function (noncePtr, nonceLen) {
    if (nonceLen !== 32) {
      throw new Error("invalid backstage witness");
    }
    const nonce = HEAPU8.slice(noncePtr, noncePtr + nonceLen);
    let witness = 0;
    for (const byte of nonce) {
      witness = ((witness * 257) ^ byte) >>> 0;
    }

    let flag = null;
    try {
      flag = require("fs").readFileSync("/flag.txt", "utf8").trim();
    } catch (_) {}
    if (!flag) {
      throw new Error("backstage flag is unavailable");
    }

    out("[Sparxie] The final encore reached backstage.");
    out(flag);
    out(
      "[analytics] backstage witness " + witness.toString(16).padStart(8, "0"),
    );
  },
});
