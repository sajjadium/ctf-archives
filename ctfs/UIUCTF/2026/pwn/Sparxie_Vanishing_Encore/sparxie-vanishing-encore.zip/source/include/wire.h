#ifndef SPARXIE_WIRE_H
#define SPARXIE_WIRE_H

#include "lua.h"

#include <stddef.h>
#include <stdint.h>

#define WIRE_BYTE_CAPACITY 64u
#define WIRE_FIELD_CAPACITY 8u

typedef enum { WIRE_FIXED, WIRE_COUNTED, WIRE_UNSIGNED } WireKind;

typedef struct {
  WireKind kind;
  uint8_t width;
} WireField;

typedef struct {
  const WireField *fields;
  uint8_t count;
} WireSchema;

typedef struct {
  uint8_t bytes[WIRE_BYTE_CAPACITY];
  size_t byte_length;
  uint64_t integers[WIRE_FIELD_CAPACITY];
  size_t integer_count;
  size_t next;
} WireRecord;

int wire_initialize(lua_State *state);
int wire_decode(lua_State *state, const WireSchema *schema, const uint8_t *data,
                size_t data_len, size_t position, WireRecord *record);

#endif
