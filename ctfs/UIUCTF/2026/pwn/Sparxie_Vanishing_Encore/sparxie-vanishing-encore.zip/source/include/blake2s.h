#ifndef SPARXIE_BLAKE2S_H
#define SPARXIE_BLAKE2S_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
  uint32_t h[8];
  uint32_t t[2];
  uint32_t f[2];
  uint8_t buffer[64];
  size_t buffer_len;
  size_t output_len;
} Blake2s;

int blake2s_init(Blake2s *state, size_t output_len);
int blake2s_update(Blake2s *state, const void *input, size_t input_len);
int blake2s_final(Blake2s *state, void *output, size_t output_len);

#endif
