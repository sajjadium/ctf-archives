#ifndef SPARXIE_BANNER_H
#define SPARXIE_BANNER_H

static const char sparxie_banner[] =
    "+--------------------------------------------------+\n"
    "|        SPARXICLE LIVE - VANISHING ENCORE         |\n"
    "|            PARTY TILL THE WORLD ENDS!            |\n"
    "+--------------------------------------------------+\n";

#endif
