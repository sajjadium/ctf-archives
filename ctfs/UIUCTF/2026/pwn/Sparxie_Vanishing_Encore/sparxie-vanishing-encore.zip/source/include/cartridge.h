#ifndef SPARXIE_CARTRIDGE_H
#define SPARXIE_CARTRIDGE_H

#include <stddef.h>
#include <stdint.h>

int cartridge_unpack(const uint8_t *input, size_t input_len, uint8_t **output,
                     size_t *output_len, char *error, size_t error_len);

#endif
