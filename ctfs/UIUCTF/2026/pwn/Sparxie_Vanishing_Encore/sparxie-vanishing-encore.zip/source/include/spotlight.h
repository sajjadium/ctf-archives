#ifndef SPARXIE_SPOTLIGHT_H
#define SPARXIE_SPOTLIGHT_H

#include "lua.h"

#include <stdint.h>

#define PERMIT_MT "sparxie.review-result"

typedef struct {
  uint8_t policy[16];
  uint64_t edition;
  uint32_t operation;
  uint32_t quota;
  uint32_t consumed;
  uint32_t cookie;
} Permit;

int spotlight_initialize(lua_State *state);
int spotlight_review(lua_State *state);
Permit *spotlight_check_permit(lua_State *state, int index);
int spotlight_permit_valid(const Permit *permit);
void spotlight_consume_permit(Permit *permit);
const uint8_t *spotlight_catalogue_seal(void);
uint64_t spotlight_campaign(void);

#endif
