#ifndef SPARXIE_SPARXIE_H
#define SPARXIE_SPARXIE_H

#include "lua.h"

int luaopen_sparxie(lua_State *state);
int sparxie_install_authority(lua_State *state);

#endif
