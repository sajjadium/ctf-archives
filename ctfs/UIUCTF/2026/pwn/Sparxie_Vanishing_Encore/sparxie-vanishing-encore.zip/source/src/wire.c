#include "wire.h"

#include "lauxlib.h"

#include <string.h>

static char decoder_registry_key;

static size_t append_width(char *format, size_t length, uint8_t width) {
  if (width >= 10)
    format[length++] = (char)('0' + width / 10);
  format[length++] = (char)('0' + width % 10);
  return length;
}

static void push_format(lua_State *state, const WireSchema *schema) {
  static const char options[] = {'c', 's', 'I'};
  char format[48] = {'<', '!', '1'};
  size_t length = 3;
  for (uint8_t i = 0; i < schema->count; ++i) {
    const WireField *field = &schema->fields[i];
    format[length++] = options[field->kind];
    length = append_width(format, length, field->width);
  }
  lua_pushlstring(state, format, length);
}

int wire_initialize(lua_State *state) {
  lua_getglobal(state, "string");
  if (!lua_istable(state, -1)) {
    lua_pop(state, 1);
    return -1;
  }
  lua_getfield(state, -1, "unpack");
  if (!lua_isfunction(state, -1)) {
    lua_pop(state, 2);
    return -1;
  }
  lua_rawsetp(state, LUA_REGISTRYINDEX, &decoder_registry_key);
  lua_pop(state, 1);
  return 0;
}

int wire_decode(lua_State *state, const WireSchema *schema, const uint8_t *data,
                size_t data_len, size_t position, WireRecord *record) {
  if (schema == NULL || schema->count == 0 ||
      schema->count > WIRE_FIELD_CAPACITY)
    return -1;

  int base = lua_gettop(state);
  memset(record, 0, sizeof(*record));
  lua_rawgetp(state, LUA_REGISTRYINDEX, &decoder_registry_key);
  if (!lua_isfunction(state, -1)) {
    lua_settop(state, base);
    return -1;
  }
  push_format(state, schema);
  lua_pushlstring(state, (const char *)data, data_len);
  lua_pushinteger(state, (lua_Integer)position);
  if (lua_pcall(state, 3, schema->count + 1, 0) != LUA_OK) {
    lua_settop(state, base);
    return -1;
  }

  for (uint8_t i = 0; i < schema->count; ++i) {
    const WireField *field = &schema->fields[i];
    int index = base + i + 1;
    if (field->kind == WIRE_FIXED || field->kind == WIRE_COUNTED) {
      size_t length = 0;
      const char *bytes = lua_tolstring(state, index, &length);
      if (bytes == NULL || record->byte_length != 0 ||
          length > WIRE_BYTE_CAPACITY) {
        lua_settop(state, base);
        return -1;
      }
      memcpy(record->bytes, bytes, length);
      record->byte_length = length;
    } else {
      int is_integer = 0;
      lua_Integer value = lua_tointegerx(state, index, &is_integer);
      if (!is_integer || record->integer_count == WIRE_FIELD_CAPACITY) {
        lua_settop(state, base);
        return -1;
      }
      record->integers[record->integer_count++] = (uint64_t)value;
    }
  }

  int is_integer = 0;
  lua_Integer next =
      lua_tointegerx(state, base + schema->count + 1, &is_integer);
  if (!is_integer || next < 1) {
    lua_settop(state, base);
    return -1;
  }
  record->next = (size_t)next;
  lua_settop(state, base);
  return 0;
}
