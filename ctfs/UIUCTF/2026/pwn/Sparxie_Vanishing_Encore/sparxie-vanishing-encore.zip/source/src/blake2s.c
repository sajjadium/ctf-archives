#include "blake2s.h"

#include <string.h>

static const uint32_t iv[8] = {UINT32_C(0x6a09e667), UINT32_C(0xbb67ae85),
                               UINT32_C(0x3c6ef372), UINT32_C(0xa54ff53a),
                               UINT32_C(0x510e527f), UINT32_C(0x9b05688c),
                               UINT32_C(0x1f83d9ab), UINT32_C(0x5be0cd19)};

static const uint8_t sigma[10][16] = {
    {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
    {14, 10, 4, 8, 9, 15, 13, 6, 1, 12, 0, 2, 11, 7, 5, 3},
    {11, 8, 12, 0, 5, 2, 15, 13, 10, 14, 3, 6, 7, 1, 9, 4},
    {7, 9, 3, 1, 13, 12, 11, 14, 2, 6, 5, 10, 4, 0, 15, 8},
    {9, 0, 5, 7, 2, 4, 10, 15, 14, 1, 11, 12, 6, 8, 3, 13},
    {2, 12, 6, 10, 0, 11, 8, 3, 4, 13, 7, 5, 15, 14, 1, 9},
    {12, 5, 1, 15, 14, 13, 4, 10, 0, 7, 6, 3, 9, 2, 8, 11},
    {13, 11, 7, 14, 12, 1, 3, 9, 5, 0, 15, 4, 8, 6, 2, 10},
    {6, 15, 14, 9, 11, 3, 0, 8, 12, 2, 13, 7, 1, 4, 10, 5},
    {10, 2, 8, 4, 7, 6, 1, 5, 15, 11, 9, 14, 3, 12, 13, 0}};

static uint32_t load32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static void store32(uint8_t *p, uint32_t value) {
  p[0] = (uint8_t)value;
  p[1] = (uint8_t)(value >> 8);
  p[2] = (uint8_t)(value >> 16);
  p[3] = (uint8_t)(value >> 24);
}

static uint32_t rotr32(uint32_t value, unsigned count) {
  return (value >> count) | (value << (32u - count));
}

#define G(r, i, a, b, c, d)                                                    \
  do {                                                                         \
    a = a + b + message[sigma[r][2u * (i)]];                                   \
    d = rotr32(d ^ a, 16);                                                     \
    c = c + d;                                                                 \
    b = rotr32(b ^ c, 12);                                                     \
    a = a + b + message[sigma[r][2u * (i) + 1u]];                              \
    d = rotr32(d ^ a, 8);                                                      \
    c = c + d;                                                                 \
    b = rotr32(b ^ c, 7);                                                      \
  } while (0)

#define ROUND(r)                                                               \
  do {                                                                         \
    G(r, 0, work[0], work[4], work[8], work[12]);                              \
    G(r, 1, work[1], work[5], work[9], work[13]);                              \
    G(r, 2, work[2], work[6], work[10], work[14]);                             \
    G(r, 3, work[3], work[7], work[11], work[15]);                             \
    G(r, 4, work[0], work[5], work[10], work[15]);                             \
    G(r, 5, work[1], work[6], work[11], work[12]);                             \
    G(r, 6, work[2], work[7], work[8], work[13]);                              \
    G(r, 7, work[3], work[4], work[9], work[14]);                              \
  } while (0)

static void compress(Blake2s *state, const uint8_t block[64]) {
  uint32_t message[16];
  uint32_t work[16];

  for (size_t i = 0; i < 16; ++i)
    message[i] = load32(block + i * 4);
  for (size_t i = 0; i < 8; ++i) {
    work[i] = state->h[i];
    work[i + 8] = iv[i];
  }
  work[12] ^= state->t[0];
  work[13] ^= state->t[1];
  work[14] ^= state->f[0];
  work[15] ^= state->f[1];

  ROUND(0);
  ROUND(1);
  ROUND(2);
  ROUND(3);
  ROUND(4);
  ROUND(5);
  ROUND(6);
  ROUND(7);
  ROUND(8);
  ROUND(9);

  for (size_t i = 0; i < 8; ++i)
    state->h[i] ^= work[i] ^ work[i + 8];
}

static void increment_counter(Blake2s *state, uint32_t amount) {
  state->t[0] += amount;
  state->t[1] += state->t[0] < amount;
}

int blake2s_init(Blake2s *state, size_t output_len) {
  if (state == NULL || output_len == 0 || output_len > 32)
    return -1;
  memset(state, 0, sizeof(*state));
  memcpy(state->h, iv, sizeof(iv));
  state->h[0] ^= UINT32_C(0x01010000) ^ (uint32_t)output_len;
  state->output_len = output_len;
  return 0;
}

int blake2s_update(Blake2s *state, const void *input, size_t input_len) {
  const uint8_t *bytes = (const uint8_t *)input;
  if (state == NULL || (bytes == NULL && input_len != 0))
    return -1;

  size_t left = state->buffer_len;
  size_t fill = sizeof(state->buffer) - left;
  if (input_len > fill) {
    memcpy(state->buffer + left, bytes, fill);
    increment_counter(state, (uint32_t)sizeof(state->buffer));
    compress(state, state->buffer);
    state->buffer_len = 0;
    bytes += fill;
    input_len -= fill;
    while (input_len > sizeof(state->buffer)) {
      increment_counter(state, (uint32_t)sizeof(state->buffer));
      compress(state, bytes);
      bytes += sizeof(state->buffer);
      input_len -= sizeof(state->buffer);
    }
  }
  if (input_len != 0)
    memcpy(state->buffer + state->buffer_len, bytes, input_len);
  state->buffer_len += input_len;
  return 0;
}

int blake2s_final(Blake2s *state, void *output, size_t output_len) {
  uint8_t full[32];
  if (state == NULL || output == NULL || output_len != state->output_len)
    return -1;

  increment_counter(state, (uint32_t)state->buffer_len);
  state->f[0] = UINT32_MAX;
  memset(state->buffer + state->buffer_len, 0,
         sizeof(state->buffer) - state->buffer_len);
  compress(state, state->buffer);
  for (size_t i = 0; i < 8; ++i)
    store32(full + i * 4, state->h[i]);
  memcpy(output, full, output_len);
  memset(full, 0, sizeof(full));
  return 0;
}

#undef ROUND
#undef G
