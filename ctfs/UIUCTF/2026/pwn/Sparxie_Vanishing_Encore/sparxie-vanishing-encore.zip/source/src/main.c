#include "banner.h"
#include "cartridge.h"
#include "sparxie.h"

#include "lauxlib.h"
#include "lualib.h"

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INPUT_LIMIT (96u * 1024u)
#define CARTRIDGE_HEADER_SIZE 32u
#define CARTRIDGE_MAGIC "SPX2LIVE"
#define CARTRIDGE_MAGIC_SIZE 8u

static void open_sandbox(lua_State *state) {
  static const luaL_Reg safe_libraries[] = {{LUA_GNAME, luaopen_base},
                                            {LUA_COLIBNAME, luaopen_coroutine},
                                            {LUA_TABLIBNAME, luaopen_table},
                                            {LUA_STRLIBNAME, luaopen_string},
                                            {LUA_MATHLIBNAME, luaopen_math},
                                            {LUA_UTF8LIBNAME, luaopen_utf8},
                                            {NULL, NULL}};
  for (const luaL_Reg *library = safe_libraries; library->func != NULL;
       ++library) {
    luaL_requiref(state, library->name, library->func, 1);
    lua_pop(state, 1);
  }
  lua_pushnil(state);
  lua_setglobal(state, "dofile");
  lua_pushnil(state);
  lua_setglobal(state, "load");
  lua_pushnil(state);
  lua_setglobal(state, "loadfile");
  lua_pushnil(state);
  lua_setglobal(state, "print");
  lua_pushnil(state);
  lua_setglobal(state, "tostring");
  lua_getglobal(state, LUA_STRLIBNAME);
  lua_pushnil(state);
  lua_setfield(state, -2, "format");
  lua_pop(state, 1);
}

static int read_exact(uint8_t *buffer, size_t length) {
  while (length != 0) {
    size_t received = fread(buffer, 1, length, stdin);
    if (received == 0)
      return 0;
    buffer += received;
    length -= received;
  }
  return 1;
}

static uint32_t load32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static uint8_t *read_cartridge(size_t *length) {
  uint8_t *buffer = (uint8_t *)malloc(INPUT_LIMIT);
  if (buffer == NULL)
    return NULL;

  if (!read_exact(buffer, CARTRIDGE_HEADER_SIZE)) {
    free(buffer);
    return NULL;
  }

  size_t packed_len = CARTRIDGE_HEADER_SIZE;
  if (memcmp(buffer, CARTRIDGE_MAGIC, CARTRIDGE_MAGIC_SIZE) == 0) {
    uint32_t plain_len = load32(buffer + CARTRIDGE_MAGIC_SIZE);
    if (plain_len > INPUT_LIMIT - CARTRIDGE_HEADER_SIZE ||
        !read_exact(buffer + CARTRIDGE_HEADER_SIZE, plain_len)) {
      free(buffer);
      return NULL;
    }
    packed_len += plain_len;
  }

  if (ferror(stdin)) {
    free(buffer);
    return NULL;
  }
  *length = packed_len;
  return buffer;
}

int main(void) {
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
  fputs(sparxie_banner, stdout);
  puts("[catalogue] one Spotlight Pass remains");
  puts("[studio] upload one SPX2 creator cartridge:");

  size_t packed_len = 0;
  uint8_t *packed = read_cartridge(&packed_len);
  if (packed == NULL) {
    puts("[moderation] upload too large");
    return 1;
  }

  uint8_t *chunk = NULL;
  size_t chunk_len = 0;
  char error[160];
  if (cartridge_unpack(packed, packed_len, &chunk, &chunk_len, error,
                       sizeof(error)) != 0) {
    printf("[moderation] %s\n", error);
    free(packed);
    return 1;
  }
  free(packed);

  lua_State *state = luaL_newstate();
  if (state == NULL) {
    free(chunk);
    return 1;
  }
  open_sandbox(state);
  luaL_requiref(state, "sparxie", luaopen_sparxie, 1);
  lua_setglobal(state, "sparxie");
  if (sparxie_install_authority(state) != 0) {
    puts("[studio] backstage initialization failed");
    lua_close(state);
    free(chunk);
    return 1;
  }

  int status = luaL_loadbufferx(state, (const char *)chunk, chunk_len,
                                "@vanishing-encore", "t");
  free(chunk);
  if (status == LUA_OK)
    status = lua_pcall(state, 0, 0, 0);
  if (status != LUA_OK) {
    const char *detail = lua_tostring(state, -1);
    printf("[chat] %s\n", detail != NULL ? detail : "the stream glitched");
    lua_close(state);
    return 1;
  }

  lua_close(state);
  puts("[studio] stream ended");
  return 0;
}
