#include "spotlight.h"

#include "blake2s.h"
#include "lauxlib.h"
#include "wire.h"

#include <stdint.h>
#include <string.h>

#define BASE_HEADER_SIZE 16u
#define ROUTE_SIZE 16u
#define ENVELOPE_HEADER_SIZE (BASE_HEADER_SIZE + ROUTE_SIZE)
#define BODY_SIZE 28u
#define SEAL_SIZE 32u
#define ROUTE_ARCHIVE 0x11u
#define ROUTE_RELAY 0x27u
#define RELAY_EDITION 0x05u
#define CATALOGUE_ID UINT32_C(0x4d97a12b)
#define CAMPAIGN_ID UINT64_C(0x5a31c89e72d40b6f)
#define PERMIT_COOKIE_DOMAIN UINT32_C(0x71c5a29e)

typedef enum { MIGRATE_ROUTE, MIGRATE_BODY } MigrationSource;

typedef struct {
  MigrationSource source;
  uint8_t source_offset;
  uint8_t output_offset;
  uint8_t length;
} MigrationStep;

static uint8_t relay_issued;

static const uint8_t envelope_magic[8] = {'S', 'P', 'X', 'P',
                                          'A', 'S', 'S', '!'};

static const uint8_t seal_domain[] = "SPARXIE::CATALOGUE::ARCHIVE";
static const uint8_t relay_domain[] = "SPARXIE::CATALOGUE::RELAY";
static const uint8_t policy_domain[] = "SPARXIE::CATALOGUE::ITEM";

static const MigrationStep relay_migration[] = {
    {MIGRATE_ROUTE, 8, 0, 4},
    {MIGRATE_ROUTE, 12, 4, 4},
    {MIGRATE_BODY, 0, 8, BODY_SIZE}};

static const WireField relay_fields[] = {{WIRE_COUNTED, 8},
                                         {WIRE_UNSIGNED, 4},
                                         {WIRE_UNSIGNED, 4},
                                         {WIRE_UNSIGNED, 8}};

static const WireSchema relay_schema = {
    relay_fields, sizeof(relay_fields) / sizeof(relay_fields[0])};

static const uint8_t allowed_seal[SEAL_SIZE] = {
    0xc4, 0xda, 0xb9, 0xe2, 0x7f, 0x93, 0xba, 0x5c, 0x9f, 0xf1, 0x43,
    0x22, 0x30, 0xdc, 0xfb, 0x68, 0x71, 0xf3, 0x3b, 0x31, 0x89, 0x60,
    0x65, 0xf7, 0xaa, 0xf4, 0x35, 0xc4, 0x42, 0x25, 0xcd, 0x98};

static const uint8_t allowed_policy[SEAL_SIZE] = {
    0x22, 0x8b, 0xe0, 0x87, 0x5c, 0xc3, 0x5c, 0xcd, 0x10, 0x0f, 0x6f,
    0x91, 0x80, 0x87, 0x07, 0x7c, 0xee, 0x8d, 0xda, 0x8a, 0x28, 0x8c,
    0x53, 0x6f, 0x0e, 0xb5, 0x1d, 0x59, 0xcc, 0xe7, 0x83, 0x1a};

static uint32_t load32(const uint8_t *p) {
  uint32_t value;
  memcpy(&value, p, sizeof(value));
  return value;
}

static void store32(uint8_t *p, uint32_t value) {
  memcpy(p, &value, sizeof(value));
}

static void store64(uint8_t *p, uint64_t value) {
  memcpy(p, &value, sizeof(value));
}

static int constant_time_equal(const uint8_t *left, const uint8_t *right,
                               size_t length) {
  uint8_t difference = 0;
  for (size_t i = 0; i < length; ++i)
    difference |= left[i] ^ right[i];
  return difference == 0;
}

static int compute_seal(uint8_t output[SEAL_SIZE], const uint8_t *header,
                        const uint8_t *body, size_t body_len) {
  Blake2s hash;
  if (blake2s_init(&hash, SEAL_SIZE) != 0 ||
      blake2s_update(&hash, seal_domain, sizeof(seal_domain) - 1) != 0 ||
      blake2s_update(&hash, header + 8, 8) != 0 ||
      blake2s_update(&hash, body, body_len) != 0)
    return -1;
  return blake2s_final(&hash, output, SEAL_SIZE);
}

static int compute_relay(uint8_t output[SEAL_SIZE], const uint8_t *header,
                         const uint8_t route[ROUTE_SIZE],
                         const uint8_t seal[SEAL_SIZE]) {
  Blake2s hash;
  if (blake2s_init(&hash, SEAL_SIZE) != 0 ||
      blake2s_update(&hash, relay_domain, sizeof(relay_domain) - 1) != 0 ||
      blake2s_update(&hash, seal, SEAL_SIZE) != 0 ||
      blake2s_update(&hash, header + 8, 8) != 0 ||
      blake2s_update(&hash, route, 2) != 0 ||
      blake2s_update(&hash, route + 8, 4) != 0)
    return -1;
  return blake2s_final(&hash, output, SEAL_SIZE);
}

static int compute_policy(uint8_t output[SEAL_SIZE], const WireRecord *record) {
  uint8_t number[8];
  store32(number, (uint32_t)record->byte_length);

  Blake2s hash;
  if (blake2s_init(&hash, SEAL_SIZE) != 0 ||
      blake2s_update(&hash, policy_domain, sizeof(policy_domain) - 1) != 0 ||
      blake2s_update(&hash, number, 4) != 0 ||
      blake2s_update(&hash, record->bytes, record->byte_length) != 0)
    return -1;
  for (size_t i = 0; i < 3; ++i) {
    store64(number, record->integers[i]);
    if (blake2s_update(&hash, number, sizeof(number)) != 0)
      return -1;
  }
  return blake2s_final(&hash, output, SEAL_SIZE);
}

static int route_valid(const uint8_t *header, const uint8_t route[ROUTE_SIZE],
                       const uint8_t seal[SEAL_SIZE]) {
  uint8_t expected[SEAL_SIZE];
  if (compute_relay(expected, header, route, seal) != 0)
    return 0;
  return constant_time_equal(route + 2, expected, 6) &&
         constant_time_equal(route + 12, expected + 8, 4);
}

static void migrate_record(uint8_t *output, const uint8_t *route,
                           const uint8_t *body) {
  memset(output, 0, 8 + BODY_SIZE);
  for (size_t i = 0; i < sizeof(relay_migration) / sizeof(relay_migration[0]);
       ++i) {
    const MigrationStep *step = &relay_migration[i];
    const uint8_t *source = step->source == MIGRATE_ROUTE ? route : body;
    memcpy(output + step->output_offset, source + step->source_offset,
           step->length);
  }
}

static uint32_t permit_cookie(const Permit *permit) {
  return (uint32_t)(uintptr_t)permit ^ load32(permit->policy) ^
         (uint32_t)permit->edition ^ (uint32_t)(permit->edition >> 32) ^
         permit->operation ^ permit->quota ^ permit->consumed ^
         PERMIT_COOKIE_DOMAIN;
}

int spotlight_initialize(lua_State *state) { return wire_initialize(state); }

Permit *spotlight_check_permit(lua_State *state, int index) {
  return (Permit *)luaL_checkudata(state, index, PERMIT_MT);
}

int spotlight_permit_valid(const Permit *permit) {
  return permit != NULL && permit->consumed == 0 &&
         constant_time_equal(permit->policy, allowed_policy,
                             sizeof(permit->policy)) &&
         permit->cookie == permit_cookie(permit);
}

void spotlight_consume_permit(Permit *permit) {
  permit->consumed = 1;
  permit->cookie = permit_cookie(permit);
}

const uint8_t *spotlight_catalogue_seal(void) { return allowed_seal; }

uint64_t spotlight_campaign(void) { return CAMPAIGN_ID; }

static int issue_result(lua_State *state, const WireRecord *record,
                        const uint8_t policy[SEAL_SIZE]) {
  Permit *permit = (Permit *)lua_newuserdatauv(state, sizeof(*permit), 0);
  memcpy(permit->policy, policy, sizeof(permit->policy));
  permit->operation = (uint32_t)record->integers[0];
  permit->quota = (uint32_t)record->integers[1];
  permit->edition = record->integers[2];
  permit->consumed = 0;
  permit->cookie = permit_cookie(permit);
  luaL_setmetatable(state, PERMIT_MT);
  return 1;
}

int spotlight_review(lua_State *state) {
  size_t input_len = 0;
  const uint8_t *input =
      (const uint8_t *)luaL_checklstring(state, 1, &input_len);
  if (input_len != ENVELOPE_HEADER_SIZE + BODY_SIZE + SEAL_SIZE ||
      memcmp(input, envelope_magic, sizeof(envelope_magic)) != 0 ||
      load32(input + 8) != CATALOGUE_ID || load32(input + 12) != BODY_SIZE)
    return luaL_error(state, "the catalogue rejected that pass");

  const uint8_t *route = input + BASE_HEADER_SIZE;
  const uint8_t *body = input + ENVELOPE_HEADER_SIZE;
  const uint8_t *supplied_seal = body + BODY_SIZE;
  uint8_t seal[SEAL_SIZE];
  if (compute_seal(seal, input, body, BODY_SIZE) != 0 ||
      !constant_time_equal(seal, supplied_seal, SEAL_SIZE) ||
      !constant_time_equal(seal, allowed_seal, SEAL_SIZE))
    return luaL_error(state, "the catalogue rejected that pass");

  if (route[0] == ROUTE_ARCHIVE) {
    static const uint8_t empty_route[ROUTE_SIZE - 1] = {0};
    if (!constant_time_equal(route + 1, empty_route, sizeof(empty_route)))
      return luaL_error(state, "the catalogue rejected that pass");
    lua_pushboolean(state, 1);
    return 1;
  }

  if (route[0] != ROUTE_RELAY || route[1] != RELAY_EDITION || relay_issued)
    return luaL_error(state, "the catalogue rejected that pass");
  relay_issued = 1;

  uint8_t migrated[8 + BODY_SIZE];
  migrate_record(migrated, route, body);
  WireRecord record;
  if (!route_valid(input, route, supplied_seal) ||
      wire_decode(state, &relay_schema, migrated, sizeof(migrated), 1,
                  &record) != 0)
    return luaL_error(state, "the catalogue rejected that pass");

  uint8_t policy[SEAL_SIZE];
  if (record.integer_count != 3 || record.next != sizeof(migrated) + 1 ||
      compute_policy(policy, &record) != 0 ||
      !constant_time_equal(policy, allowed_policy, SEAL_SIZE))
    return luaL_error(state, "the catalogue rejected that pass");
  return issue_result(state, &record, policy);
}
