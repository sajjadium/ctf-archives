#include "cartridge.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HEADER_SIZE 32u
#define MAX_CHUNK (64u * 1024u)

static uint32_t load32(const uint8_t *p) {
  return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static uint32_t rotl32(uint32_t value, unsigned count) {
  return (value << count) | (value >> (32u - count));
}

static uint32_t mix(uint32_t value) {
  value ^= value >> 16;
  value *= UINT32_C(0x7feb352d);
  value ^= value >> 15;
  value *= UINT32_C(0x846ca68b);
  return value ^ (value >> 16);
}

static uint32_t checksum(const uint8_t *data, size_t length, uint32_t seed) {
  uint32_t state = seed ^ UINT32_C(0x53505849);
  for (size_t i = 0; i < length; ++i)
    state = rotl32(state ^ data[i], 5) * UINT32_C(0x045d9f3b) + (uint32_t)i;
  return mix(state ^ (uint32_t)length);
}

int cartridge_unpack(const uint8_t *input, size_t input_len, uint8_t **output,
                     size_t *output_len, char *error, size_t error_len) {
  if (input_len < HEADER_SIZE || memcmp(input, "SPX2LIVE", 8) != 0) {
    snprintf(error, error_len, "that clip is not part of today's stream");
    return -1;
  }

  uint32_t plain_len = load32(input + 8);
  uint32_t nonce = load32(input + 12);
  uint32_t claimed = load32(input + 16);
  uint32_t header_tag = load32(input + 20);
  uint32_t lanes = load32(input + 24);
  uint32_t encore = load32(input + 28);

  if (plain_len == 0 || plain_len > MAX_CHUNK ||
      input_len != HEADER_SIZE + (size_t)plain_len) {
    snprintf(error, error_len, "the engagement numbers do not add up (%zu/%zu)",
             input_len, HEADER_SIZE + (size_t)plain_len);
    return -1;
  }
  if (lanes != 4 ||
      header_tag != mix(nonce ^ plain_len ^ UINT32_C(0xa11ce5ed))) {
    snprintf(error, error_len, "the broadcast mask slipped");
    return -1;
  }

  uint8_t *plain = (uint8_t *)malloc(plain_len);
  if (plain == NULL) {
    snprintf(error, error_len, "Planarcadia ran out of bandwidth");
    return -1;
  }

  uint32_t state[4] = {
      mix(nonce ^ UINT32_C(0x243f6a88)), mix(nonce ^ UINT32_C(0x85a308d3)),
      mix(nonce ^ UINT32_C(0x13198a2e)), mix(nonce ^ UINT32_C(0x03707344))};
  for (uint32_t i = 0; i < plain_len; ++i) {
    unsigned lane = (i + (nonce & 3u)) & 3u;
    state[lane] = mix(state[lane] + UINT32_C(0x9e3779b9) + i);
    uint8_t key = (uint8_t)(state[lane] >> ((i & 3u) * 8u));
    plain[i] = input[HEADER_SIZE + i] ^ key ^ (uint8_t)(i * 29u);
  }

  uint32_t actual = checksum(plain, plain_len, nonce);
  uint32_t expected_encore = mix(claimed ^ nonce ^ UINT32_C(0xe1a7104e));
  if (actual != claimed || encore != expected_encore) {
    free(plain);
    snprintf(error, error_len, "the audience rejected this cut (%08x/%08x)",
             actual, claimed);
    return -1;
  }

  *output = plain;
  *output_len = plain_len;
  return 0;
}
