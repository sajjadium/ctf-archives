#!/usr/bin/env python3

import struct
import sys
from pathlib import Path


MASK = 0xFFFFFFFF


def mix(value):
    value &= MASK
    value ^= value >> 16
    value = value * 0x7FEB352D & MASK
    value ^= value >> 15
    value = value * 0x846CA68B & MASK
    return (value ^ (value >> 16)) & MASK


source = Path(sys.argv[1]).read_bytes()
output = Path(sys.argv[2])
nonce = 0x051A7C1E
states = [
    mix(nonce ^ 0x243F6A88),
    mix(nonce ^ 0x85A308D3),
    mix(nonce ^ 0x13198A2E),
    mix(nonce ^ 0x03707344),
]
encrypted = bytearray(len(source))

for index, byte in enumerate(source):
    lane = (index + nonce) & 3
    states[lane] = mix(states[lane] + 0x9E3779B9 + index)
    key = states[lane] >> ((index & 3) * 8) & 0xFF
    encrypted[index] = byte ^ key ^ (index * 29 & 0xFF)

checksum = nonce ^ 0x53505849
for index, byte in enumerate(source):
    checksum ^= byte
    checksum = ((checksum << 5) | (checksum >> 27)) & MASK
    checksum = (checksum * 0x045D9F3B + index) & MASK
checksum = mix(checksum ^ len(source))

header = b"SPX2LIVE" + struct.pack(
    "<6I",
    len(source),
    nonce,
    checksum,
    mix(nonce ^ len(source) ^ 0xA11CE5ED),
    4,
    mix(checksum ^ nonce ^ 0xE1A7104E),
)
output.write_bytes(header + encrypted)
