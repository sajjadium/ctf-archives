#!/usr/bin/python3

import base64
import fcntl
import os
import pwd
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile

COMPILER_ROOT = "/opt/compiler-root"
COMPILER_JOBS = f"{COMPILER_ROOT}/jobs"
MAX_SUBMISSION = 256 * 1024
MAX_ENCODED_SUBMISSION = 4 * (MAX_SUBMISSION // 3) + 4096
MAX_ARTIFACT = 64 * 1024 * 1024
FAILED = "Submission Failed."
NO_CHEATING = "No Cheating!"
REVIEW = "Submission Recieved! We will check correctness of the statement and send the flag in 3-5 business days."

FORBIDDEN = re.compile("|".join((
    r"#\s*eval", r"#\s*reduce\b", r"\bnative_decide\b",
    r"\brun_cmd\b", r"\brun_elab\b", r"\brun_meta\b", r"\brun_tac\b",
    r"\bby_elab\b", r"\binclude_str\b", r"\bmeta\b", r"\bmacro\b",
    r"\bmacro_rules\b", r"\belab\b", r"\belab_rules\b",
    r"\bcommand_elab\b", r"\bterm_elab\b", r"\bsyntax\b", r"\bsimproc\b",
    r"\binitialize\b", r"\bbuiltin_[A-Za-z0-9_]*\b", r"\battribute\b",
    r"@\[[^\]]*\btactic\b", r"\bextern\b", r"\bimplemented_by\b",
    r"\bcsimp\b", r"\bexport\b", r"\binit\b", r"\bunsafe\b",
    r"\bpartial\b", r"\bpartial_fixpoint\b", r"\binductive_fixpoint\b",
    r"\bcoinductive_fixpoint\b", r"\bopaque\b", r"\bunsafeCast\b",
    r"\bwithPtrEq\b", r"\bsorry\b",
)))

MAIN = """import Submission

def main : IO Unit := do
  IO.println "[jail] calling entry..."
  let r := entry 0
  IO.println s!"[jail] entry returned: {r}"
"""

WELCOME = """
State and prove the Riemann hypothesis in Lean.

Submit your proof as a single base64-encoded line, then press Enter. For example:
(base64 -w0 RH.lean; echo) | ncat --ssl HOST PORT
"""


def kill_uid_processes(uid):
    for entry in os.scandir("/proc"):
        if not entry.name.isdigit():
            continue
        try:
            with open(f"{entry.path}/status") as status:
                for line in status:
                    if line.startswith("Uid:"):
                        if uid in map(int, line.split()[1:]):
                            os.kill(int(entry.name), 9)
                        break
        except (FileNotFoundError, PermissionError, ProcessLookupError, ValueError):
            pass


def run_compiler(uid, work, *args):
    sandbox_work = f"/jobs/{os.path.basename(work)}"
    env = {
        "PATH": "/opt/lean/bin",
        "HOME": sandbox_work,
        "TMPDIR": sandbox_work,
        "LEAN_PATH": f"{sandbox_work}:/opt/lean/lib/lean",
        "LANG": "C",
    }
    with tempfile.TemporaryFile() as log:
        process = subprocess.Popen(
            ["/usr/local/bin/compiler-sandbox", str(uid), "-M=1024", *args],
            env=env, stdout=log, stderr=subprocess.STDOUT,
        )
        try:
            returncode = process.wait(timeout=300)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise
        finally:
            kill_uid_processes(uid)
            shutil.rmtree(
                f"{COMPILER_ROOT}/proc/{process.pid}", ignore_errors=True
            )
        log.seek(0)
        output = log.read(1024 * 1024).decode("utf-8", errors="replace")
    return returncode, output


def copy_artifacts(work, runtime, uid):
    for name in ("Submission.c", "Main.c"):
        source = f"{work}/{name}"
        before = os.lstat(source)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != uid or
                before.st_nlink != 1 or before.st_size > MAX_ARTIFACT):
            raise ValueError("invalid compiler artifact")

        source_fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            current = os.fstat(source_fd)
            if ((current.st_dev, current.st_ino, current.st_size) !=
                    (before.st_dev, before.st_ino, before.st_size)):
                raise ValueError("compiler artifact changed")
            destination_fd = os.open(
                f"{runtime}/{name}",
                os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW,
                0o600,
            )
            try:
                remaining = current.st_size
                while remaining:
                    chunk = os.read(source_fd, min(1024 * 1024, remaining))
                    if not chunk:
                        raise ValueError("short compiler artifact")
                    view = memoryview(chunk)
                    while view:
                        view = view[os.write(destination_fd, view):]
                    remaining -= len(chunk)
            finally:
                os.close(destination_fd)
        finally:
            os.close(source_fd)


def run_submission(source):
    if len(source) > MAX_SUBMISSION:
        return FAILED
    if FORBIDDEN.search(source):
        return NO_CHEATING

    lock = None
    work = None
    runtime = None
    try:
        for uid in range(20000, 20032):
            candidate = open(f"{COMPILER_JOBS}/.{uid}.lock", "a")
            try:
                fcntl.flock(candidate, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                candidate.close()
            else:
                lock = candidate
                break
        else:
            return FAILED

        work = tempfile.mkdtemp(prefix="job-", dir=COMPILER_JOBS)
        os.chmod(work, 0o700)
        submission = f"{work}/Submission.lean"
        with open(submission, "x") as output:
            output.write(source)
        os.chown(submission, uid, uid)
        os.chown(work, uid, uid)

        sandbox_work = f"/jobs/{os.path.basename(work)}"
        returncode, _ = run_compiler(
            uid, work, f"--root={sandbox_work}",
            "-o", f"{sandbox_work}/Submission.olean",
            f"--c={sandbox_work}/Submission.c", f"{sandbox_work}/Submission.lean",
        )
        if returncode:
            return FAILED

        returncode, output = run_compiler(uid, work, "/server/Check.lean")
        if returncode:
            return NO_CHEATING if "JAIL_FAIL" in output else FAILED

        main = f"{work}/Main.lean"
        with open(main, "x") as output:
            output.write(MAIN)
        os.chmod(main, 0o444)
        returncode, _ = run_compiler(
            uid, work, f"--root={sandbox_work}",
            f"--c={sandbox_work}/Main.c", f"{sandbox_work}/Main.lean",
        )
        if returncode:
            return FAILED

        runtime = tempfile.mkdtemp(prefix="run-", dir="/tmp")
        os.chmod(runtime, 0o700)
        copy_artifacts(work, runtime, uid)
        runner = pwd.getpwnam("runner")
        for name in ("Submission.c", "Main.c"):
            os.chown(f"{runtime}/{name}", runner.pw_uid, runner.pw_gid)
        os.chown(runtime, runner.pw_uid, runner.pw_gid)

        env = {
            "PATH": "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin",
            "HOME": "/tmp", "TMPDIR": "/tmp", "LANG": "C",
        }
        process = subprocess.run(
            ["/usr/sbin/runuser", "-u", "runner", "--", "/usr/bin/timeout",
             "-k", "2", "300", "/opt/compiler-root/opt/lean/bin/leanc",
             "-O2", "-o", "jail", "Submission.c", "Main.c"],
            cwd=runtime, env=env, stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, timeout=330,
        )
        if process.returncode:
            return FAILED

        process = subprocess.run(
            ["/usr/sbin/runuser", "-u", "runner", "--", "/usr/bin/timeout",
             "-k", "2", "10", "./jail"],
            cwd=runtime, env=env, input="C\n" * 4096,
            capture_output=True, text=True, timeout=40,
        )
        if process.returncode:
            return FAILED
        separator = "" if not process.stdout or process.stdout.endswith("\n") else "\n"
        return f"{process.stdout}{separator}{REVIEW}"
    except subprocess.TimeoutExpired:
        return FAILED
    except (OSError, ValueError):
        return FAILED
    finally:
        if work is not None:
            shutil.rmtree(work, ignore_errors=True)
        if runtime is not None:
            shutil.rmtree(runtime, ignore_errors=True)
        if lock is not None:
            lock.close()


def main():
    print(WELCOME, end="", flush=True)
    signal.alarm(60)
    encoded = sys.stdin.buffer.readline(MAX_ENCODED_SUBMISSION + 2)
    signal.alarm(0)
    if len(encoded.rstrip(b"\r\n")) > MAX_ENCODED_SUBMISSION:
        print(FAILED)
        return
    try:
        source = base64.b64decode(b"".join(encoded.split()), validate=True).decode()
    except ValueError:
        print("Invalid base64.")
        return
    print(run_submission(source))


if __name__ == "__main__":
    main()
