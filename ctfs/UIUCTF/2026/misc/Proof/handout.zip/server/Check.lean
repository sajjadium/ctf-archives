import Lean
import Submission

open Lean

def forbiddenRoots : List Name :=
  [`IO, `EIO, `BaseIO, `ST, `EST, `System, `Task, `Runtime, `Lean]

def forbiddenNames : List Name :=
  [`unsafeCast, `withPtrEq, `sorryAx]

def badName (n : Name) : Bool :=
  forbiddenRoots.any (fun r => r.isPrefixOf n) || forbiddenNames.contains n

def dependencies (info : ConstantInfo) : List Name :=
  let used := info.type.getUsedConstants
  let used := if let some value := info.value? true then
    used ++ value.getUsedConstants
  else
    used
  used.toList

partial def hasBadDependency (env : Environment) : List Name → NameSet → Bool
  | [], _ => false
  | n :: todo, seen =>
    if seen.contains n then
      hasBadDependency env todo seen
    else if badName n then
      true
    else
      let todo := match env.find? n with
        | some info => dependencies info ++ todo
        | none => todo
      hasBadDependency env todo (seen.insert n)

def hasBadCompilerAttribute (env : Environment) (n : Name) : Bool :=
  (getExternAttrData? env n).isSome ||
  (Compiler.getImplementedBy? env n).isSome ||
  (getExportNameFor? env n).isSome ||
  hasInitAttr env n ||
  Compiler.hasCSimpAttribute env n

run_cmd do
  let env ← getEnv
  let some midx := env.header.moduleNames.findIdx? (· == `Submission)
    | throwError "JAIL_FAIL"
  let some entry := env.find? `entry
    | throwError "JAIL_FAIL"
  unless env.getModuleIdxFor? `entry == some midx do
    throwError "JAIL_FAIL"
  match entry.type with
  | .forallE _ domain body .default =>
    unless domain == mkConst ``Nat && body == mkConst ``Nat do
      throwError "JAIL_FAIL"
  | _ => throwError "JAIL_FAIL"
  match entry with
  | .defnInfo v =>
    match v.safety with
    | .safe => pure ()
    | _ => throwError "JAIL_FAIL"
  | _ => throwError "JAIL_FAIL"
  let all := env.constants.map₁.toList ++ env.constants.map₂.toList
  let mut roots : List Name := []
  for (n, info) in all do
    if env.getModuleIdxFor? n != some midx then continue
    if info.isUnsafe || info.isPartial || hasBadCompilerAttribute env n then
      throwError "JAIL_FAIL"
    roots := dependencies info ++ roots
  if hasBadDependency env roots {} then
    throwError "JAIL_FAIL"
