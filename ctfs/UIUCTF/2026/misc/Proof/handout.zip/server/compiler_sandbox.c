#define _GNU_SOURCE

#include <errno.h>
#include <grp.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>

#define ROOT "/opt/compiler-root"
#define LEAN "/opt/lean/bin/lean"

static void fail(const char *message) {
  perror(message);
  _exit(127);
}

static void set_limit(int resource, rlim_t value) {
  struct rlimit limit = {value, value};
  if (setrlimit(resource, &limit) != 0)
    fail("setrlimit");
}

int main(int argc, char **argv) {
  if (argc < 2) {
    fputs("usage: compiler-sandbox UID [ARG ...]\n", stderr);
    return 127;
  }

  char *end;
  errno = 0;
  unsigned long id = strtoul(argv[1], &end, 10);
  if (errno || !argv[1][0] || *end || id > UINT_MAX) {
    fputs("invalid sandbox user id\n", stderr);
    return 127;
  }

  char proc_dir[PATH_MAX];
  char proc_exe[PATH_MAX];
  int length = snprintf(proc_dir, sizeof(proc_dir), ROOT "/proc/%ld",
                        (long)getpid());
  if (length < 0 || (size_t)length >= sizeof(proc_dir)) {
    errno = ENAMETOOLONG;
    fail("sandbox proc path");
  }
  if (mkdir(proc_dir, 0555) != 0 && errno != EEXIST)
    fail("mkdir sandbox proc entry");
  length = snprintf(proc_exe, sizeof(proc_exe), "%s/exe", proc_dir);
  if (length < 0 || (size_t)length >= sizeof(proc_exe)) {
    errno = ENAMETOOLONG;
    fail("sandbox proc executable path");
  }
  if (symlink(LEAN, proc_exe) != 0 && errno != EEXIST)
    fail("symlink sandbox executable");

  set_limit(RLIMIT_AS, 4ULL * 1024 * 1024 * 1024);
  set_limit(RLIMIT_CPU, 305);
  set_limit(RLIMIT_FSIZE, 64ULL * 1024 * 1024);
  set_limit(RLIMIT_NOFILE, 512);
  set_limit(RLIMIT_NPROC, 128);
  set_limit(RLIMIT_CORE, 0);

  if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) != 0)
    fail("prctl");
  if (setenv("LD_LIBRARY_PATH", "/opt/lean/lib:/opt/lean/lib/lean", 1) != 0 ||
      setenv("LEAN_SYSROOT", "/opt/lean", 1) != 0)
    fail("setenv");
  if (chroot(ROOT) != 0 || chdir("/") != 0)
    fail("chroot");
  if (setgroups(0, NULL) != 0 || setresgid(id, id, id) != 0 ||
      setresuid(id, id, id) != 0)
    fail("drop privileges");

  argv[1] = LEAN;
  execv(LEAN, &argv[1]);
  fail("execv");
}
