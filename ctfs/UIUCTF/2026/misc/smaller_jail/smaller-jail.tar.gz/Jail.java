import java.io.*;
import java.net.*;
import java.security.Permission;
import java.util.*;

public class Jail {
    public static void main(String[] args) {
        System.out.println("Starting the jail...");
        System.setSecurityManager(new JailSecurityManager());
        UserClass.run();
    }
}

class JailSecurityManager extends SecurityManager {
    public void checkAccept(String host, int port) {
        throw new SecurityException();
    }

    public void checkAccess(Thread t) {
        throw new SecurityException();
    }

    public void checkAccess(ThreadGroup g) {
        throw new SecurityException();
    }

    public void checkAwtEventQueueAccess() {
        throw new SecurityException();
    }

    public void checkConnect(String host, int port) {
        throw new SecurityException();
    }

    public void checkConnect(String host, int port, Object context) {
        throw new SecurityException();
    }

    public void checkCreateClassLoader() {
        throw new SecurityException();
    }

    public void checkDelete(String file) {
        throw new SecurityException();
    }

    public void checkExec(String cmd) {
        throw new SecurityException();
    }

    public void checkLink(String lib) {
        throw new SecurityException();
    }

    public void checkListen(int port) {
        throw new SecurityException();
    }

    public void checkMulticast(InetAddress maddr) {
        throw new SecurityException();
    }

    public void checkMulticast(InetAddress maddr, byte ttl) {
        throw new SecurityException();
    }

    public void checkPermission(Permission perm) {
        if (perm.getName().equals("setSecurityManager") || perm.implies(new RuntimePermission("setSecurityManager"))) {
            throw new SecurityException();
        }
    }

    public void checkPermission(Permission perm, Object context) {
        if (perm.getName().equals("setSecurityManager") || perm.implies(new RuntimePermission("setSecurityManager"))) {
            throw new SecurityException();
        }
    }

    public void checkPrintJobAccess() {
        throw new SecurityException();
    }

    public void checkRead(FileDescriptor fd) {
        throw new SecurityException();
    }

    public void checkRead(String file) {
        // allow the loader to load the class
        if (file.equals("/tmp/UserClass.class")) {
            return;
        }
        throw new SecurityException();
    }

    public void checkRead(String file, Object context) {
        throw new SecurityException();
    }

    public void checkSecurityAccess(String target) {
        throw new SecurityException();
    }

    public void checkSetFactory() {
        throw new SecurityException();
    }

    public void checkSystemClipboardAccess() {
        throw new SecurityException();
    }

    public void checkWrite(FileDescriptor fd) {
        throw new SecurityException();
    }

    public void checkWrite(String file) {
        throw new SecurityException();
    }

    public void checkPackageAccess(String pkg) {
        if (pkg.startsWith("sun")) {
            throw new SecurityException();
        }
    }
}