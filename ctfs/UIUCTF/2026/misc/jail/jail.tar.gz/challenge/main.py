import os, shutil, torch

from safetensors.torch import load_file

from model import MaliciousDetection

BANNER = """Java Sandbox Runner: type code in line by line and then type DONE. UserClass.run is invoked, e.g:

public class UserClass {
    public static void run() {
        System.out.println(1 + 1);
    }
}
DONE
"""

print(BANNER)

source = ""

while True:
    line = input()
    if line == "DONE":
        break

    source += line + "\n"

with torch.no_grad():
    model = MaliciousDetection()
    model.eval()
    model.load_state_dict(load_file("model.safetensors"))

    source_tensor = torch.tensor(list(source.encode("utf8")), dtype=torch.long).unsqueeze(0)
    logits = model(source_tensor)

    if torch.sigmoid(logits) >= 0.1:
        print("malicious code detected")
        exit()


os.chdir("/tmp")
shutil.copy("/Jail.java", "Jail.java")

with open("UserClass.java", "w") as f:
    f.write(source)

os.system("javac UserClass.java 2>&1")
os.system("javac Jail.java 2>&1")
os.system("java Jail 2>&1")
