import torch
import torch.nn as nn
import torch.nn.functional as F


class MaliciousDetection(nn.Module):
    def __init__(self, vocab_size=257, embed_dim=32, num_filters=64, dropout_rate=0.5):
        super(MaliciousDetection, self).__init__()

        self.num_filters = num_filters

        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=256)

        self.conv1 = nn.Conv1d(embed_dim, num_filters, kernel_size=3)
        self.conv2 = nn.Conv1d(embed_dim, num_filters, kernel_size=5)
        self.conv3 = nn.Conv1d(embed_dim, num_filters, kernel_size=10)
        self.conv4 = nn.Conv1d(embed_dim, num_filters, kernel_size=20)

        self.pool = nn.AdaptiveMaxPool1d(1)

        self.dropout = nn.Dropout(dropout_rate)

        self.fc = nn.Linear(num_filters * 4, 1)

    def forward(self, x):
        # x shape: (batch_size, sequence_length)
        x_emb = self.embedding(x).permute(0, 2, 1) 

        act1 = F.relu(self.conv1(x_emb))
        act2 = F.relu(self.conv2(x_emb))
        act3 = F.relu(self.conv3(x_emb))
        act4 = F.relu(self.conv4(x_emb))

        c1, idx1 = torch.max(act1, dim=2)
        c2, idx2 = torch.max(act2, dim=2)
        c3, idx3 = torch.max(act3, dim=2)
        c4, idx4 = torch.max(act4, dim=2)

        merged = torch.cat((c1, c2, c3, c4), dim=1)

        flat = self.dropout(merged)

        logits = self.fc(flat)

        return logits