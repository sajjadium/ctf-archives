#!/bin/sh

export PATH=$PATH:/bin

emacs --version
emacs -nl -nw -Q --batch -l challenge.el 2>&1
