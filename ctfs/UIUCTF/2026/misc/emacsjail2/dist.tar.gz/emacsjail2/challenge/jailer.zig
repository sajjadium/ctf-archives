const std = @import("std");

const CapstoneInstIterator = struct {
    const cap = @cImport({
        @cInclude("capstone.h");
    });
    const Self = @This();

    fn cap_do(f: anytype, args: anytype) !void {
        if (@call(.auto, f, args) != cap.CS_ERR_OK) {
            return error.CapstoneFail;
        }
    }
    fn cap_malloc(csh: cap.csh) ![*c]cap.cs_insn {
        if (cap.cs_malloc(csh)) |ret| {
            return ret;
        } else {
            return error.OutOfMemory;
        }
    }

    pub fn controlFlowP(insn: cap.cs_insn) bool {
        for (insn.detail.*.groups[0..insn.detail.*.groups_count]) |g| {
            switch (g) {
                cap.CS_GRP_CALL, cap.CS_GRP_JUMP => return true,
                else => {},
            }
        } else return false;
    }

    csh: cap.csh,
    insn: [*c]cap.cs_insn,
    code: [*c]const u8,
    address: u64,
    size: usize,

    pub fn init(func: []const u8) !Self {
        var cs_handle: cap.csh = 0;
        try cap_do(cap.cs_open, .{ cap.CS_ARCH_X86, cap.CS_MODE_64, &cs_handle });
        try cap_do(cap.cs_option, .{ cs_handle, cap.CS_OPT_DETAIL, cap.CS_OPT_ON });
        const buf = try cap_malloc(cs_handle);

        return .{
            .csh = cs_handle,
            .insn = buf,
            .code = @ptrCast(func.ptr),
            .address = @intFromPtr(func.ptr),
            .size = func.len,
        };
    }
    pub fn deinit(self: *Self) void {
        cap.cs_free(self.insn, 1);
        _ = cap.cs_close(&self.csh);
    }
    pub fn next(self: *Self) ?cap.cs_insn {
        return if (cap.cs_disasm_iter(self.csh, &self.code, &self.size, &self.address, self.insn)) self.insn.* else null;
    }
};

const DlHandle = struct {
    const Self = @This();

    fn dl_do(f: anytype, args: anytype) !*anyopaque {
        return @call(.auto, f, args) orelse {
            std.debug.print("{s}\n", .{std.c.dlerror().?});
            return error.DlFail;
        };
    }

    _handle: *anyopaque,
    pub fn init(filename: [:0]const u8) !Self {
        return .{
            ._handle = try dl_do(std.c.dlopen, .{ filename.ptr, std.c.RTLD{ .NOW = true } }),
        };
    }
    pub fn deinit(self: *const Self) void {
        _ = std.c.dlclose(self._handle);
    }
    pub fn getSymbolAddress(self: *const Self, symbol: [:0]const u8) ![*]const u8 {
        const ret = try dl_do(std.c.dlsym, .{ self._handle, symbol });
        return @ptrCast(ret);
    }
};

const Emacs = struct {
    const emacs = @cImport({
        @cInclude("emacs-module.h");
    });

    var env: *emacs.emacs_env = undefined;
    var Qnil: emacs.emacs_value = undefined;
    var Qt: emacs.emacs_value = undefined;

    fn intern(name: [:0]const u8) emacs.emacs_value {
        return env.make_global_ref.?(env, env.*.intern.?(env, name));
    }

    fn copyString(gpa: std.mem.Allocator, str: emacs.emacs_value) ![:0]u8 {
        var len: c_long = undefined;
        if (!env.copy_string_contents.?(env, str, null, &len)) return error.CopyStringFailed;
        var buf = try gpa.alloc(u8, @intCast(len));

        if (env.copy_string_contents.?(env, str, buf.ptr, &len)) {
            return buf[0..@intCast(len - 1) :0];
        } else return error.CopyStringFailed;
    }

    fn Function(comptime f: anytype) type {
        const params = @typeInfo(@TypeOf(f)).@"fn".params;
        const arity = params.len;

        return struct {
            pub fn defun(name: [:0]const u8) !void {
                var args = [_]emacs.emacs_value{
                    env.intern.?(env, name),
                    env.make_function.?(env, arity, arity, _call, null, null),
                };

                _ = env.funcall.?(env, env.intern.?(env, "defalias"), args.len, &args);
            }

            fn _call(env_: ?*emacs.emacs_env, nargs: c_long, args_: ?[*]emacs.emacs_value, _: ?*anyopaque) callconv(.c) emacs.emacs_value {
                env = env_.?;
                if (nargs != arity) return Qnil;

                var buf: [512]u8 = undefined;
                var fba: std.heap.FixedBufferAllocator = .init(&buf);
                const alloc = fba.allocator();

                const ArgsT = comptime blk: {
                    var ret: []const type = &.{};
                    for (params) |p| {
                        ret = ret ++ [_]type{p.type.?};
                    }
                    break :blk ret;
                };
                var args: @Tuple(ArgsT) = undefined;
                inline for (params, 0..) |p, i| {
                    args[i] = switch (p.type.?) {
                        [:0]const u8 => copyString(alloc, args_.?[i]) catch return Qnil,
                        else => @compileError("unimplemented"),
                    };
                }

                const ret = @call(.auto, f, args) catch unreachable;
                return switch (@typeInfo(@TypeOf(ret))) {
                    .bool => if (ret) Qt else Qnil,
                    .void => Qnil,
                    else => @compileError("unimplemented"),
                };
            }
        };
    }

    pub fn moduleInit(rt: ?*emacs.emacs_runtime) callconv(.c) i32 {
        if (rt.?.size < @sizeOf(emacs.emacs_runtime)) return 1;

        env = rt.?.get_environment.?(rt);
        if (env.size < @sizeOf(emacs.emacs_env)) return 2;

        Qnil = intern("nil");
        Qt = intern("t");

        Function(check).defun("jailer-check") catch return 3;

        return 0;
    }
};

export fn plugin_is_GPL_compatible() void {}
comptime {
    @export(&Emacs.moduleInit, .{ .name = "emacs_module_init", .linkage = .strong });
}

fn findFunction(filename: [:0]const u8, function_name: [:0]const u8) !struct { []const u8, DlHandle } {
    const dl: DlHandle = try .init(filename);
    const start_addr = try dl.getSymbolAddress(function_name);

    const size = blk: {
        var threaded: std.Io.Threaded = .init_single_threaded;
        defer threaded.deinit();
        const io = threaded.io();
        const alloc = std.heap.page_allocator;

        const fd = try std.Io.Dir.cwd().openFile(io, filename, .{});
        defer fd.close(io);
        var elf = try std.debug.ElfFile.load(alloc, io, fd, null, &.none);
        defer elf.deinit(alloc);

        const syms: []align(1) const std.elf.Elf64_Sym = @ptrCast(elf.symtab.?.bytes);

        for (syms) |sym| {
            if (std.mem.eql(u8, function_name, std.mem.sliceTo(elf.strtab.?[sym.st_name..], 0)))
                break :blk sym.st_size;
        } else return error.SymbolNotFound;
    };

    return .{ start_addr[0..size], dl };
}

fn check(filename: [:0]const u8, function_name: [:0]const u8) !bool {
    const target, const dl = try findFunction(filename, function_name);
    defer dl.deinit();

    var insns: CapstoneInstIterator = try .init(target);
    defer insns.deinit();

    while (insns.next()) |insn| {
        if (CapstoneInstIterator.controlFlowP(insn)) return false;
    }
    return true;
}
