const std = @import("std");

pub fn build(b: *std.Build) !void {
    const target = b.standardTargetOptions(.{
        .default_target = .{
            .cpu_arch = .x86_64,
            .os_tag = .linux,
            .abi = .gnu,
        },
    });
    const optimize = b.standardOptimizeOption(.{});

    const mod = b.addModule("jailer", .{
        .root_source_file = b.path("jailer.zig"),
        .target = target,
        .optimize = optimize,
    });
    mod.linkSystemLibrary("capstone", .{ .preferred_link_mode = .static });
    {
        const emacs_path = try b.findProgram(&.{"emacs"}, &.{});
        mod.addSystemIncludePath(.{ .cwd_relative = b.pathResolve(&.{ emacs_path, "../../include" }) });
    }
    mod.link_libc = true;

    const lib = b.addLibrary(.{
        .name = "jailer",
        .root_module = mod,
        .linkage = .dynamic,
    });
    lib.out_filename = try std.fmt.allocPrint(b.allocator, "jailer{s}", .{lib.rootModuleTarget().dynamicLibSuffix()});
    b.installArtifact(lib);
}
