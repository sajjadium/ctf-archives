;;; -*- lexical-binding:t -*-

(require 'comp)
(require 'cl-lib)

(defun check (input)
  (when-let* (((native-comp-function-p input))
              (libjailer (expand-file-name (file-name-with-extension "jailer" module-file-suffix)))
              (eln-file (native-comp-unit-file (subr-native-comp-unit input)))
              (func-name (comp-c-func-name (subr-name input) "F" t)))
    (module-load libjailer)
    (jailer-check eln-file func-name)))

(defun panic (str &rest fmt)
  (message str fmt)
  (kill-emacs))

(let ((input (read-string "Input: ")))
  (unless (length< input 4096)
    (panic "input is too long"))
  (let ((code (read-from-string input)))
    (setq code (car code))

    (let ((macro-whitelist '(comp--prepare-args-for-top-level lambda cl-declare)))
      (mapatoms (lambda (a) (when (and (macrop a) (not (memq a macro-whitelist)))
                              (push (cons a #'ignore) byte-compile-initial-macro-environment)))))

    (let ((compilation-safety 0)
          (compiled (native-compile code (make-temp-file "emacsjail2"))))
      (unless (check compiled) (panic "jailer does not approve of your program"))
      (message "%s" (funcall compiled)))
    (kill-emacs)))
