{
  description = "emacsjail2";
  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

  outputs =
    { self, nixpkgs }:
    let
      inherit (nixpkgs) lib;
      system = "x86_64-linux";
      devSystem = "aarch64-darwin";
      pkgs = import nixpkgs {
        localSystem = devSystem;
        crossSystem = system;
      };
      # emacs does not cleanly cross compile
      emacs' = (import nixpkgs { inherit system; }).emacs30;
    in
    {
      packages.${system} = {
        jailer = pkgs.callPackage (
          {
            lib,
            stdenv,
            pkgsStatic,
            zig_0_16,
            pkg-config,
          }:
          stdenv.mkDerivation {
            name = "emacsjail2";
            src = lib.filterSource (path: _type: lib.strings.hasSuffix ".zig" path) ./challenge;

            nativeBuildInputs = [
              zig_0_16
              pkg-config
              emacs'
            ];
            buildInputs = with pkgsStatic; [ capstone ];

            dontSetZigDefaultFlags = true;
            preInstall = ''
              zigInstallFlagsArray+=("--prefix-lib-dir" "")
            '';
          }
        ) { };

        challenge =
          with pkgs.dockerTools;
          let
            kctf = pullImage {
              imageName = "gcr.io/kctf-docker/challenge";
              imageDigest = "sha256:9f15314c26bd681a043557c9f136e7823414e9e662c08dde54d14a6bfd0b619f";
              hash = "sha256-diCM/PjhNyjkCbDD+Rsh6+iDRdu0yd9tbDQj5DnAlbA=";
            };
          in
          buildLayeredImage {
            name = "emacsjail2";
            tag = "latest";

            fromImage = kctf;

            contents = [
              (pkgs.buildEnv {
                name = "chroot";
                extraPrefix = "/chroot";
                postBuild = "mkdir -p $out$extraPrefix/{tmp,proc,dev,nix/store}";
                paths = [
                  binSh
                  emacs'
                  self.packages.${system}.jailer

                  (lib.fileset.toSource {
                    root = ./challenge;
                    fileset = lib.fileset.unions [
                      ./challenge/entry.sh
                      ./challenge/challenge.el
                      ./challenge/flag.txt
                    ];
                  })
                ];
              })
              (pkgs.buildEnv {
                name = "nsjail";
                extraPrefix = "/home/user";
                paths = [
                  (lib.fileset.toSource {
                    root = ./challenge;
                    fileset = lib.fileset.unions [
                      ./challenge/nsjail.cfg
                    ];
                  })
                ];
              })
            ];

            config.Cmd = [
              "/bin/sh"
              "-c"
              ''
                kctf_setup && \
                kctf_drop_privs \
                socat \
                  TCP-LISTEN:1337,reuseaddr,fork \
                  EXEC:"kctf_pow nsjail --config /home/user/nsjail.cfg -- ./entry.sh",pty,sane
              ''
            ];
          };
        healthcheck =
          with pkgs.dockerTools;
          let
            kctf-healthcheck = pullImage {
              imageName = "gcr.io/kctf-docker/healthcheck";
              imageDigest = "sha256:66b34a47e7bbb832012905e229da0bbed80c5c3cddd4703127ca4026ba528cfc";
              hash = "sha256-AyDpyEiQA4vCulgOknVz0C1Cdc6xFnOQX5sfWUr+qTQ=";
            };
          in
          buildLayeredImage {
            name = "emacsjail2-healthcheck";
            tag = "latest";

            fromImage = kctf-healthcheck;

            contents = [
              (pkgs.buildEnv {
                name = "healthcheck";
                extraPrefix = "/home/user";
                paths = [
                  ./healthcheck
                ];
              })
            ];

            config.Cmd = [
              "/bin/sh"
              "-c"
              ''
                kctf_drop_privs /home/user/healthcheck_loop.sh & /home/user/healthz_webserver.py
              ''
            ];
          };
      };

      devShells.${devSystem}.default =
        with pkgs;
        mkShellNoCC {
          inputsFrom = [ self.packages.${system}.jailer ];

          packages = [
            zls_0_16
          ];
        };
      apps.${devSystem}.default = {
        type = "app";
        program = lib.getExe (
          with pkgs.buildPackages;
          writeShellScriptBin "make-dist" ''
            mkdir -p emacsjail2/challenge
            trap 'rm -rf emacsjail2' EXIT
            install -m 0644 ${./.}/flake.* emacsjail2/
            install -m 0644 ${./challenge}/* emacsjail2/challenge/
            echo "uiuctf{foobar}" > emacsjail2/challenge/flag.txt
            ${lib.getExe gnutar} --owner=0 --group=0 -czf dist.tar.gz emacsjail2
          ''
        );
      };
    };
}
