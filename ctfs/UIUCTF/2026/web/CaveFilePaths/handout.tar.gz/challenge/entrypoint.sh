#!/bin/sh
set -eu

FLAG_VALUE="${FLAG:-}"
if [ -z "$FLAG_VALUE" ]; then
    FLAG_VALUE='uiuctf{redacted}'
fi
printf 'The ancient chest opens. Inside rests the Sword of Mastery.\n\n%s\n' "$FLAG_VALUE" > /app/private/secret_chest.txt
chown ctf:ctf /app/private/secret_chest.txt
chmod 0444 /app/private/secret_chest.txt

exec gunicorn --user ctf --group ctf --bind 0.0.0.0:${PORT:-5000} --workers 2 --threads 4 app:app
