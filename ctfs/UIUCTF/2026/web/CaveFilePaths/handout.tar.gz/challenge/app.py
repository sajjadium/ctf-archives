from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, abort, render_template, request, send_file

app = Flask(__name__)

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_CAVE_DIR = BASE_DIR / "cave_files"


@app.get("/")
def index():
    visible_files = sorted(path.name for path in PUBLIC_CAVE_DIR.iterdir() if path.is_file())
    return render_template("index.html", visible_files=visible_files)


@app.get("/read")
def read_cave_file():
    filename = request.args.get("file", "torch.txt")

    if os.path.isabs(filename):
        abort(400, description="The cave map only understands relative paths.")

    filename = filename.replace("../", "")
    requested_path = PUBLIC_CAVE_DIR / filename

    if not requested_path.is_file():
        abort(404, description="That passage does not seem to exist.")

    return send_file(requested_path, mimetype="text/plain")


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.errorhandler(400)
@app.errorhandler(404)
def cave_error(error):
    return (
        render_template(
            "error.html",
            status=error.code,
            message=error.description,
        ),
        error.code,
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "1337")))
