#include "jsi.h"
#include "jsvalue.h"
#include "jsbuiltin.h"

#ifndef __APPLE__
#include <bsd/stdlib.h>
#endif

#include <sys/mman.h>

static uint8_t* read_buffer = NULL;
static uint16_t read_offset = 0;

static uint8_t* write_buffer_check = NULL;
static uint8_t* write_buffer = NULL;
static uint16_t write_offset = 0;

static char* flag = NULL;

static void ch_read(js_State *J)
{
	if (read_buffer == NULL) {
		read_buffer = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
		if (read_buffer == NULL) {
			perror("Failed to mmap buffer for Challenge.");
			exit(1);
		}

		arc4random_buf(read_buffer, 0x1000);
		read_offset = arc4random_uniform(0xF00);

		mprotect(read_buffer, 0x1000, PROT_READ);
	}

	js_pushnumber(J, (uint64_t)&read_buffer[read_offset]);
}

static void ch_write(js_State *J)
{
	if (write_buffer == NULL) {
		write_buffer = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
		if (write_buffer == NULL) {
			perror("Failed to mmap buffer for Challenge.");
			exit(1);
		}
		write_buffer_check = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
		if (write_buffer_check == NULL) {
			perror("Failed to mmap buffer for Challenge.");
			exit(1);
		}

		arc4random_buf(write_buffer, 0x1000);
		write_offset = arc4random_uniform(0xF00);

		memcpy(write_buffer_check, write_buffer, 0x1000);

		mprotect(write_buffer_check, 0x1000, PROT_READ);
	}

	js_pushnumber(J, (uint64_t)&write_buffer[write_offset]);
}

static void exec() {
	if (memcmp(write_buffer + write_offset, read_buffer + read_offset, 4) != 0) {
		return;
	}

	if (memcmp(write_buffer, write_buffer_check, write_offset) != 0) {
		return;
	}

	if (memcmp(write_buffer+write_offset+4, write_buffer_check+write_offset+4, 0x1000-4-write_offset) != 0) {
		return;
	}

	FILE* fp = fopen("flag.txt", "r");
	if (fp == NULL) {
		fprintf(stderr, "Error no flag.txt.");
		exit(1);
	}
	flag = calloc(32, 1);
	if (flag == NULL) {
		fprintf(stderr, "Failed to allocate space to read in flag.");
		exit(1);
	}
	if (fread(flag, 1, 32, fp) == 0) {
		fprintf(stderr, "Failed to read anything from flag file.");
		exit(1);
	}
}

static void ch_exec(js_State *J) {
	js_pushnumber(J, (uint64_t)exec);
}

static void ch_getFlag(js_State *J) {
	if (flag != NULL) {
		js_pushstring(J, flag);
	} else {
		js_pushundefined(J);
	}
}

void jsB_initchallenge(js_State *J)
{
	js_pushobject(J, jsV_newobject(J, JS_COBJECT, J->Object_prototype));
	{
		jsB_propf(J, "Challenge.read", ch_read, 2);
		jsB_propf(J, "Challenge.write", ch_write, 1);
		jsB_propf(J, "Challenge.exec", ch_exec, 1);
		jsB_propf(J, "Challenge.getFlag", ch_getFlag, 1);
	}
	js_defglobal(J, "Challenge", JS_DONTENUM);
}
