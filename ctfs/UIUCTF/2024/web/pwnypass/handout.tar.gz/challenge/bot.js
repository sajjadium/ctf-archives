const puppeteer = require('puppeteer');
const fs = require('fs');
const net = require('net');

const DOMAIN = process.env.DOMAIN;
if (DOMAIN == undefined) throw 'domain undefined'
const REGISTERED_DOMAIN = process.env.REGISTERED_DOMAIN;
const BLOCK_SUBORIGINS = process.env.BLOCK_SUBORIGINS == "1";
const BOT_TIMEOUT = process.env.BOT_TIMEOUT || 120*1000;

// will only be used if BLOCK_SUBORIGINS is enabled
const PAC_B64 = Buffer.from(`
function FindProxyForURL (url, host) {
  if (host == "${DOMAIN}") {
    return 'DIRECT';
  }
  if (host == "${REGISTERED_DOMAIN}" || dnsDomainIs(host, ".${REGISTERED_DOMAIN}")) {
    return 'PROXY 127.0.0.1:1';
  }
  return 'DIRECT';
}
`).toString('base64');

const FLAG1 = fs.readFileSync('flag1.txt', {encoding: 'utf8'}).trim();

(async function(){
  function ask_for_url(socket) {
      socket.state = 'URL';
      socket.write('Please send me a URL to open.\n');
  }

  async function load_url(socket, data) {
    let url = data.toString().trim();
    console.log(`checking url: ${url}`);
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      socket.state = 'ERROR';
      socket.write('Invalid scheme (http/https only).\n');
      socket.destroy();
      return;
    }
    socket.state = 'LOADED';
    const tmpDir = `/tmp/chrome-userdata-${(Math.random() + 1).toString(36).substring(2)}`;
    const puppeter_args = {
      headless: false,
      //channel: 'chrome',
      args: [
        `--user-data-dir=${tmpDir}`,
        '--breakpad-dump-location=/tmp/chrome-crashes',
        '--proxy-pac-url=data:application/x-ns-proxy-autoconfig;base64,'+PAC_B64,
        `--disable-extensions-except=${__dirname}/ext`,
        `--load-extension=${__dirname}/ext`,
        '--no-sandbox'
      ]
    }
    socket.write(`Setting up...\n`);
    const browser = await puppeteer.launch(puppeter_args);
    let page = await browser.newPage();
    await page.goto('https://pwnypass.c.hc.lc/login.php', {waitUntil: 'networkidle2'});
    await new Promise((res)=>setTimeout(res, 500));
    await page.type('input[name="username"]', 'sigpwny');
    await page.type('input[name="password"]', FLAG1);
    await page.click('body');
    await new Promise((res)=>setTimeout(res, 500));
    await page.click('input[type="submit"]');
    await new Promise((res)=>setTimeout(res, 500));
    await page.close();
    page = await browser.newPage();
    socket.write(`Loading page ${url}.\n`);


    socket.write(`Loading page ${url}.\n`);
    setTimeout(()=>{
      try {
        browser.close();
        fs.rmSync(tmpDir, { recursive: true, force: true });
        socket.write('timeout\n');
        socket.destroy();
      } catch (err) {
        console.log(`err: ${err}`);
      }
    }, BOT_TIMEOUT);
    await page.goto(url);
  }

  var server = net.createServer();
  server.listen(1338);
  console.log('listening on port 1338');

  server.on('connection', socket=>{
    socket.on('data', data=>{
      try {
        if (socket.state == 'URL') {
          load_url(socket, data);
        }
      } catch (err) {
        console.log(`err: ${err}`);
      }
    });

    try {
      ask_for_url(socket);
    } catch (err) {
      console.log(`err: ${err}`);
    }
  });
})();

