#include "picsim.h"
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

#define PROG_FILE "prog.hex"

#define CPU "PIC16F628A"

static _pic pic1;

void exitcc(int sig) {
  pic_end(&pic1);
  exit(0);
}

int main() {
  (void)signal(SIGINT, exitcc);
  (void)signal(SIGTERM, exitcc);
  (void)signal(SIGALRM, exitcc);

  alarm(3);

  int proc = getprocbyname(CPU);
  int family = getfprocbyname(CPU);

  pic_set_serial(&pic1, 0, "/tmp/pic_rx", "/tmp/pic_tx", 0, 0, 0);
  pic_set_serial(&pic1, 1, "", "", 0, 0, 0);

  if (pic_init(&pic1, proc, PROG_FILE, 1, 20e6)) {
    return 0;
  }

  pic1.print = 0;
  while (1) {
    pic_step(&pic1);
  }
  return 0;
}
