const sqlite3 = require("sqlite3").verbose();
const databaseFilename = "./sqlite.db";

const db = new sqlite3.Database(databaseFilename);
const csrfTokenValid = 10*60; // How long the csrfToken is valid for in seconds


db.exec(`CREATE TABLE IF NOT EXISTS users (
  profileId int NOT NULL PRIMARY KEY,
  customCSS TEXT,
  customHTML TEXT,
  flagger int NOT NULL DEFAULT 0
  );
`);

db.exec(`REPLACE INTO users (profileId, customCSS, customHTML)  VALUES (0, "background-color: red;", "Oh a visitor looking at my page. Would to you like to SMILE TO ME ;) for a picture?");`);


db.exec(`CREATE TABLE IF NOT EXISTS csrfTokens (
      csrfToken int NOT NULL,
      profileId int NOT NULL,
      createdAt DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
      primary key (csrfToken, profileId)
)`);


async function createUser(profileId){
    return new Promise((resolve, reject) => {
        db.run('INSERT INTO users (profileId, customCSS, customHTML)  VALUES (?, ?, ?)', [profileId, "main {background-color: pink;}", "<h2>Welcome on my dice page</h2><p>I like to paint my dice in the color orange. Just like the clothes in prison after you get your \"Go to Jail\" card. But do you have a \"Get out of Jail Free\" card.</p>"], (err, rows) => {
          if (err) reject(err);
          resolve();
        });
    });
}


async function updateProfile(profileId, customCSS, customHTML){
    return new Promise((resolve, reject) => {
        db.run('UPDATE users SET customCSS=?, customHTML=? where profileId=?', [customCSS, customHTML, profileId], (err, rows) => {
          if (err) reject(err);
          resolve();
        });
    });
}


async function getProfile(profileId) {
    return new Promise((resolve, reject) => {
      db.get('SELECT customCSS, customHTML FROM users WHERE profileId=?', [profileId], (err, rows) => {
        if (err) reject(err);
        resolve(rows);
      });
    });
};

async function upgradeProfile(profileId) {
    return new Promise((resolve, reject) => {
      db.get('UPDATE users SET flagger = 1 WHERE profileId=?', [profileId], (err, rows) => {
        if (err) reject(err);
        resolve(rows);
      });
    });
};

async function hasFlag(profileId) {
    return new Promise((resolve, reject) => {
      db.get('SELECT flagger FROM users WHERE profileId=?', [profileId], (err, rows) => {
        if (err) reject(err);
        if (rows.flagger === 1) resolve(true);
        resolve(false);
      });
    });
};

async function writeCSRFToken(profileId, csrfToken) {
    return new Promise((resolve, reject) => {
      db.run('REPLACE INTO csrfTokens (csrfToken, profileId) VALUES (?, ?)', [csrfToken, profileId], function(err, rows) {
        if (err) reject(err);
        resolve();
      });
    });
};

async function isCSRFTokenToOld(profileId, csrfToken) {
    return new Promise((resolve, reject) => {
      db.get(`SELECT csrfToken, profileId, createdAt, CURRENT_TIMESTAMP FROM csrfTokens where profileId=? AND csrfToken=? AND (unixepoch(\'now\') - unixepoch(createdAt)) < ${csrfTokenValid}`, [profileId, csrfToken], function (err, rows) {
        if (err) reject(err);
        if (!rows) resolve(true);
        resolve(false);
      });
    });
};

module.exports = { createUser, updateProfile, getProfile, upgradeProfile, hasFlag, writeCSRFToken, isCSRFTokenToOld };
