const express = require('express'); 
const exphbs  = require('express-handlebars');
const session = require('express-session') 
const puppeteer = require('puppeteer');
const crypto = require('crypto');
const fs = require('fs')
const db = require('./db');

const SAFE_INTEGER = 2**48-1
const flag = process.env.FLAG || require('fs').readFileSync('/flag', 'utf8') || "GPNCTF{fake_flag}";
const adminToken = crypto.randomBytes(64).toString('hex');

const DOMPurify = require('dompurify')(new (require('jsdom').JSDOM)('').window);
const app = express();
const sessionRouter = express.Router();
const noSessionRouter = express.Router();
app.use(express.urlencoded({ extended: true }));

app.use(function(err, req, res, next) {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

function fileHash(filename, algorithm = 'sha256') {
    let file_buffer = fs.readFileSync(filename);
    let sum = crypto.createHash(algorithm);
    sum.update(file_buffer);
    const base64 = sum.digest('base64');
    return `${algorithm}-${base64}`;
}

const cspHash = {
    'forms.js': fileHash(__dirname + "/static/forms.js"),
}
const scriptSrcCSP = `script-src '${cspHash["forms.js"]}';`


app.use(function (req, res, next){
    res.setHeader("Content-Security-Policy", `default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; ${scriptSrcCSP}`);
    res.setHeader("X-Content-Type-Options", "nosniff");
    next();
});

app.use(session({ 
    // It holds the secret key for session 
    secret: crypto.randomBytes(16),
  
    // Forces the session to be saved 
    // back to the session store 
    resave: true, 
  
    // Forces a session that is "uninitialized" 
    // to be saved to the store 
    saveUninitialized: true,
})) 

app.use(express.static(__dirname + '/static'));
app.use(noSessionRouter);
app.use(sessionRouter);

const hbs = exphbs.create({
    helpers: {
        getCSRFToken() { return this.csrfToken.toString(); },
        cspHash: function(file) { return cspHash[file] || "noHashFound" },
        selfProfileId() { return this.session.profileId.toString()}
    }
});
app.engine('handlebars', hbs.engine);
app.set('view engine', 'handlebars');
app.set('views', './views');


sessionRouter.use(async function(req, res, next) {
    if (!req.session.returning) {
        // session was just created
        req.session.returning = true;
        let id = crypto.randomInt(1, SAFE_INTEGER);
        req.session.profileId = id;
        await db.createUser(id);
    }

    res.locals.session = req.session;
    res.locals.csrfToken = crypto.randomInt(2**30, 2**31-1);
    await db.writeCSRFToken(req.session.profileId, res.locals.csrfToken);
    next();
})


sessionRouter.get('/', (req, res) => {
    res.render('index');
});


sessionRouter.get("/profile/me", async (req, res) => {
    res.redirect(`/profile/${req.session.profileId}`);
});

sessionRouter.get("/profile/me/edit", async (req, res) => {
    res.redirect(`/profile/${req.session.profileId}/edit`);
});

async function requireCSRF(req, res, next){
    let csrfToken = req.query.csrfToken || req.body.csrfToken;
    if (!csrfToken) return res.render('error', { errorMsg: "No csrfToken found."});
    if (await db.isCSRFTokenToOld(req.session.profileId, csrfToken)) return res.render('error', { errorMsg: 'csrfToken not found in db or too old' });

    next();
}

function adminOrSelf(req, res, next){
    let profileId = req.session.profileId;
    let profileIdParam = parseInt(req.params.profileId);

    if (profileId !== profileIdParam && req.session.profileId !== 0) return res.render('error', { errorMsg: "You are not allowed to access this resource." });
    next();    
}

function noAdmin(req, res, next){
    if (req.session.profileId === 0) return res.render('error', { errorMsg: "The admin can't view this page"});
    next();
}

sessionRouter.get("/profile/:profileId", adminOrSelf, async (req, res) => {
    let profileIdParam = parseInt(req.params.profileId);

    let profileData = await db.getProfile(profileIdParam);
    if(!profileData) return res.render('error', { errorMsg: "No user found" });


    let customHTML = profileData.customHTML || "";
    let customCSS = profileData.customCSS || "";
    res.render('profile', { profileId: profileIdParam, customHTML, customCSS });
});

function onlySelf(req, res, next){
    let profileId = req.session.profileId;
    let profileIdParam = parseInt(req.params.profileId);
    
    if (profileId !== profileIdParam) return res.render('error', { errorMsg: "You are not allowed to access this resource."});
    next();
}


sessionRouter.get("/profile/:profileId/edit", onlySelf, noAdmin, async (req, res) => {
    let profileIdParam = parseInt(req.params.profileId);
    let profileData = await db.getProfile(profileIdParam);
    if(!profileData) return res.render('error', { errorMsg: "No user found" });


    let customHTML = profileData.customHTML || "";
    let customCSS = profileData.customCSS || "";
    res.render('profile-edit', { profileId: profileIdParam, customHTML, customCSS });
});


sessionRouter.get("/api/profile/:profileId/edit", onlySelf, requireCSRF, noAdmin, async (req, res) => {
    let { style, html } = req.query;
    let customCSS = style ? String(style) : "";
    let customHTML = html ? String(html) : "";

    if (customCSS.match(/content/i)) customCSS = ""; // I don't like css ::before and ::after content
    if (customCSS.match(/<\s*\//i)) customCSS = ""; // Don't close the style tag

    customHTML = DOMPurify.sanitize(customHTML, {FORBID_TAGS: ['style']});
    if (customHTML.length > 2000 || customCSS.length > 2000) return res.render('error', {errorMsg: "Your html or style is to long."});


    await db.updateProfile(req.session.profileId, customCSS, customHTML);
    res.redirect(`/profile/${req.session.profileId}`);
});


sessionRouter.get('/upgrade/:profileId', async (req, res, next) => {
    let profileIdParam = parseInt(req.params.profileId);
    return res.render('upgrade-profile.handlebars', {profileId: profileIdParam});
})

sessionRouter.get('/api/upgrade/:profileId', requireCSRF, async (req, res, next) => {
    if (req.session.profileId !== 0) return res.render('error', { errorMsg: "You aren't a admin"});
    let profileIdParam = parseInt(req.params.profileId);
    if (profileIdParam === 0) return res.render('error', { errorMsg: "Can't upgrade the admin."});

    await db.upgradeProfile(profileIdParam);
    console.log("Profile upgraded")
    res.send("Profile upgraded.");
});


sessionRouter.get('/flag', noAdmin, async (req, res, next) => {
    let profileId = parseInt(req.session.profileId);
    if(!(await db.hasFlag(profileId))) return res.render('error', {errorMsg: "Sorry you don't have access to the flag."});

    res.send(flag);
});



noSessionRouter.get('/admin/login', async (req, res, next) => {
    let adminToken = req.query.adminToken;

    if (req.query.adminToken !== adminToken) {
        res.send("Token is wrong");
        return;
    }

    req.session.returning = true;
    req.session.profileId = 0;
    res.sendStatus(200);
});


noSessionRouter.get('/admin/:profileId', async (req, res) => {
    try {
        let profileId = parseInt(req.params.profileId);

        
        profileId = req.params.profileId;
        const browser = await puppeteer.launch({ executablePath: process.env.BROWSER, args: process.env.BROWSER_ARGS.split(',') });
        const page = await browser.newPage();
        await page.goto(`http://localhost:1337/admin/login?adminToken=${adminToken}`);
        await new Promise(resolve => setTimeout(resolve, 1000));
        // make sure js execution isn't blocked
        await page.waitForFunction('true');
        
        
        await page.goto('http://localhost:1337/profile/' + profileId);
        await new Promise(resolve => setTimeout(resolve, 1000));
        // make sure js execution isn't blocked
        await page.waitForFunction('true');
        // take a screenshot
        const screenshot = await page.screenshot();
        await browser.close();
        res.setHeader("Content-Type", "image/png");
        res.send(screenshot);
    } catch(e) {console.error(e); res.send("internal error :( pls report to admins")}
});

app.listen(1337, () => console.log('listening on http://localhost:1337'));
