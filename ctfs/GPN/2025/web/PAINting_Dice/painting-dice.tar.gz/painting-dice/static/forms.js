console.log("Please no hacki hacki!!!!!");
console.log("Shhh! In secret we paint the dice to have better odds against our opponents in board games. Please keep it a secret, if you want to become a secret member you need to get the right color.")

// DEBUG
const csrfToken = document.currentScript.getAttribute('data-csrf');
console.debug(`csrfToken: ${csrfToken}`);

function formListener(event){
  event.preventDefault();

  let formData = new FormData(this);
  formData.append('csrfToken', csrfToken);

  let url = new URL(this.action);
  
  formData.forEach((value, key) => {
    url.searchParams.set(key, value);
  });

  fetch(url, {
    method: this.method
  })
  .then(response => response.text())
  .then(html => {
    window.document.body.innerHTML = html
  })
  .catch(error => {
    console.error("We don't care about errors on the client side, because everything here is secure.", error);
  });
}

function csrfProtection(){
    let forms = document.querySelectorAll("form");
    for (form of forms){
        form.addEventListener("submit", formListener)
    }
}

csrfProtection();