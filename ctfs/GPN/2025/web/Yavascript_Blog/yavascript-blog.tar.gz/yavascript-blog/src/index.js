let yaml = require('js-yaml');
let express = require('express');
let dp = require('dompurify');
let { JSDOM } = require('jsdom');
let crypto = require('crypto');

let DOMPurify = dp(new JSDOM('').window);

let sha256 = (data) => crypto.createHash('sha256').update(data).digest('hex');

let flag = process.env.FLAG || "GPNCTF{no_flags_given}";

let app = express();
let bodyParser = require('body-parser');
app.use(bodyParser.text({ type: 'application/x-yaml' }));
app.use((req, res, next) => {
    if (req.headers['content-type'] === 'application/x-yaml') {
        req.body = yaml.load(req.body, {});
    }
    next();
})

let users = {
    admin: {
        // password: "494a715f7e9b4071aca61bac42ca858a309524e5864f0920030862a4ae7589be",
        blogs: {
            [flag]: {
                posts: {
                    'my-beautiful-flag': "Look at my flag! Isn't it beautiful?",
                }
            }
        }
    }
}


app.post('/register', (req, res) => {
    if (typeof req.body?.username !== "string" || typeof req.body?.password !== "string") {
        return res.status(400).send("Invalid input");
    }
    if (users[req.body.username]) {
        return res.status(400).send("Username already taken");
    }
    users[req.body.username] = {
        password: sha256(req.body.password),
        blogs: {}
    };
    res.send("OK")
})

app.post('/edit-blogs', (req, res) => {
    console.log(req.body);
    if (typeof req.body?.username !== "string" || typeof req.body?.password !== "string" || typeof req.body?.blogs !== "object") {
        return res.status(400).send("Invalid input");
    }
    let user = users[req.body.username];
    console.log({user, pw: user.password, sha: sha256(req.body.password)})
    if (!user || user.password !== sha256(req.body.password)) return res.status(403).send("Invalid credentials");
    for (let blogName in req.body.blogs) {
        let taken = false;
        for (let username in users) {
            if (Object.keys(users[username]?.blogs?.[blogName] || {}).length > 0 && username !== req.body.username) {
                taken = true;
            }
        }
        if (taken) continue // user cannot write to this blog
        let blog = user.blogs[blogName] ??= {}
        let newPosts = req.body.blogs[blogName].posts || [];

        for (let post of newPosts) {
            if (post.slug !== undefined && !post.slug.match(/\d\d-\d\d-\d\d-.*/)) {
                return res.status(400).send("Invalid post slug");
            }
        }

        // set to both ID and slug for posts without slugs
        for (let postId in newPosts) {
            if (postId === "__proto__") return res.status(400).send("Invalid post slug");
            let post = newPosts[postId];
            if (typeof post.content !== "string") return res.status(400).send("Invalid post content");
            blog[postId] = blog[post.slug] = post.content
        }
    }
    res.json(user);
})

app.get('/:blogName/:postId', (req, res) => {
    let post = Object.values(users).find(x => x.blogs[req.params.blogName]?.[req.params.postId])
    if (!post) return res.status(404).send("Post not found");
    res.send(DOMPurify.sanitize(post.blogs[req.params.blogName][req.params.postId]));
})

app.get('/', (req, res) => {
    res.send(`
<h1>Yavascript Blog Host</h1>
<p>Welcome to the Yavascript Blog Host!</p>
<p>To get started, <code>POST /register</code> with a payload like:</p>
<pre>
username: test
password: test
</pre>
<p>Then, you can <code>POST /edit-blogs</code> with a payload like:</p>
<pre>
username: test
password: test
blogs:
  my-cool-blog:
    posts:
      - slug: 2025-06-16-my-first-post
        content: just setting up my bloggr
      - slug: 2025-06-16-my-writeup
        content: |
          This is how I solved the challenge:
          <ul>
            <li>Guess the other team's password</li>
            <li>Steal their exploit</li>
            <li>Submit the flag</li>
          </ul>
</pre>
<p>Then visit /my-cool-blog/2025-06-16-my-writeup to see your post!</p>
<p>You can save this object to a file and then post it to the server after editing!</p>

<p><small>Make sure to set the content type to <code>application/x-yaml</code> though. JSON is NOT accepted here.</small></p>
    `)
})

app.listen(1337)