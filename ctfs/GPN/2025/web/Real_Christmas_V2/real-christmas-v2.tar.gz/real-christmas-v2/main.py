def main():
    print("Hello from web-graphql-injection!")


if __name__ == "__main__":
    main()
