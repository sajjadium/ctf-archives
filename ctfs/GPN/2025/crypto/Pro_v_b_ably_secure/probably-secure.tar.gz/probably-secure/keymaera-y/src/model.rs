use anyhow::Result;
use serde::{Deserialize, Serialize};

pub struct Model {
    pub name: String,
    pub problem_text: String,
}

#[derive(Deserialize, Serialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct UploadResponse {
    error_text: String,
    model_id: String,
    success: bool,
}

#[derive(Deserialize, Serialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct ModelInfo {
    pub id: String,
    pub name: String,
    pub key_file: String
}

impl Model {
    fn serialize(&self) -> String {
        format!(
            r#"
        ArchiveEntry "{}"

        Problem
        {}
        End.
        End.
        "#,
            self.name, self.problem_text
        )
    }

    pub async fn upload(
        &self,
        host: &str,
        username: &str,
        session_token: &str,
    ) -> Result<UploadResponse> {
        let url = format!("{host}/user/{username}/modelupload/undefined");
        let request = reqwest::Client::new()
            .post(url)
            .header("x-session-token", session_token)
            .body(self.serialize());

        let response = request.send().await?.json().await?;

        Ok(response)
    }
}

pub async fn get_models(host: &str, username: &str, session_token: &str) -> Result<Vec<ModelInfo>> {
    let url = format!("{host}/models/users/{username}/");
    let request = reqwest::Client::new()
        .get(url)
        .header("x-session-token", session_token);

    let response = request.send().await?.json().await?;

    Ok(response)
}
