use crate::SendSyncWhatever;
use serde::{Deserialize, Serialize};
use snafu::ResultExt;

// {"askUseDefaultUser":false,"key":"userId","sessionToken":"[B@669956fd","success":true,"type":"LoginResponse","userAuthLevel":0,"value":"abc"}
#[derive(Deserialize, Serialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct LoginResponse {
    ask_use_default_user: bool,
    key: String,
    pub session_token: String,
    success: bool,
    #[serde(rename = "type")]
    response_type: String,
    user_auth_level: i32,
    value: String,
}

pub async fn login(host: &str, username: &str, password: &str) -> Result<LoginResponse, SendSyncWhatever> {
    let url = format!("{host}/user/{username}/{password}/mode/0");

    Ok(reqwest::get(url).await.whatever_context("Could not request login")?.json().await.whatever_context("Could parse login response")?)
}

pub async fn register(host: &str, username: &str, password: &str) -> Result<LoginResponse, SendSyncWhatever> {
    let url = format!("{host}/user/{username}/{password}/mode/0");

    Ok(reqwest::Client::new().post(url).send().await.whatever_context("Could not register")?.json().await.whatever_context("Could not parse register response")?)
}
