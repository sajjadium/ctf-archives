use snafu::Snafu;

pub mod auth;
pub mod model;

#[derive(Debug, Snafu)]
#[snafu(whatever, display("Error was: {message}"))]
pub struct SendSyncWhatever {
    message: String,
    #[snafu(source(from(Box<dyn std::error::Error + Send + Sync>, Some)))]
    source: Option<Box<dyn std::error::Error + Send + Sync>>,
}

pub async fn check_connection(host: &str) -> bool {
    let response = reqwest::get(host)
        .await;
    match response { 
        Ok(response) => response.status().is_success(),
        Err(_) => false,
    }
}
