use axum::extract::{Request, State};
use axum::http::StatusCode;
use axum::middleware::Next;
use axum::response::Response;
use axum::routing::post;
use axum::{debug_middleware, Router};
use axum_proxy::Identity;
use keymaera_y::auth::register;
use keymaera_y::{auth, check_connection, model::Model, SendSyncWhatever};
use snafu::{report, ResultExt};
use tokio::select;
use tokio::signal::unix::{signal, SignalKind};
use std::env::args;
use std::fs;
use std::sync::Arc;
use tokio::sync::Mutex;

#[derive(Clone)]
struct AppState {
    pub host: String,
    pub username: String,
    pub password: String,
    pub flag: String,
    pub triggered: Arc<Mutex<bool>>,
    pub remaining: Arc<Mutex<usize>>,
}

#[tokio::main]
#[report]
async fn main() -> Result<(), SendSyncWhatever> {
    let args: Vec<_> = args().collect();
    let host = args[1].to_string();

    let username = "admin".to_string();

    let password = fs::read_to_string("/password").whatever_context("Cannot read password file")?;
    let flag = fs::read_to_string("/flag").whatever_context("Cannot read flag file")?;

    /*let keymaera_command = &args[4];
    let keymaera_args = &args[5..];

    tokio::process::Command::new(keymaera_command)
        .args(keymaera_args)
        .spawn()
        .whatever_context("Failed to spawn keymaera")?;*/

    // Wait for keymaera to start
    for _ in 0..60 {
        if check_connection(&host).await {
            break;
        }
        tokio::time::sleep(tokio::time::Duration::from_secs(1)).await;
    }

    println!("Keymaera started");

    register(&host, &username, &password).await?;

    println!("Registered");

    let keymaera_proxy = axum_proxy::builder_http(&host[7..])
        .whatever_context("Could not connect to keymaera proxy")?;

    let state = AppState {
        host,
        username,
        password,
        flag,
        triggered: Arc::new(Mutex::new(false)),
        remaining: Arc::new(Mutex::new(20)),
    };

    let app = Router::new()
        .route("/place_flag", post(place_flag))
        .route("/kill", post(graceful_shutdown))
        .route_service("/{*path}", keymaera_proxy.build(Identity))
        .route_service("/", keymaera_proxy.build(Identity))
        .with_state(state.clone())
        .layer(axum::middleware::from_fn_with_state(
            state,
            limiter_middleware,
        ));

    let listener = tokio::net::TcpListener::bind("0.0.0.0:1337")
        .await
        .whatever_context("Could not bind to port")?;

    axum::serve(listener, app)
        .await
        .whatever_context("Could not start server")?;

    Ok(())
}

#[debug_middleware]
async fn limiter_middleware(state: State<AppState>, req: Request, next: Next) -> Response {
    {
        let triggered = state.triggered.lock().await;
        let mut remaining = state.remaining.lock().await;
        println!("Remaining: {}; triggered: {}", remaining, triggered);
        if *triggered {
            if *remaining == 0 {
                // Deny the request
                return Response::builder()
                    .status(StatusCode::TOO_MANY_REQUESTS)
                    .body(axum::body::Body::from("Limit reached"))
                    .unwrap();
            } else {
                // Decrement remaining (but not below 0)
                println!("Decrementing remaining by 1");
                *remaining -= 1;
            }
        }
    }

    next.run(req).await
}

async fn place_flag(app_state: State<AppState>) {
    {
        let mut triggered = app_state.triggered.lock().await;
        *triggered = true;
        println!("Flag triggered");
    }

    let login_data = auth::login(&app_state.host, &app_state.username, &app_state.password)
        .await
        .unwrap();

    let flag_model = Model {
        name: "FLAG".to_string(),
        problem_text: format!("1 = 1 /* {} */", app_state.flag),
    };

    flag_model
        .upload(
            &app_state.host,
            &app_state.username,
            &login_data.session_token,
        )
        .await
        .unwrap();
}

async fn graceful_shutdown() {
    let mut sigterm = signal(SignalKind::terminate()).unwrap();
    let interrupt = tokio::signal::ctrl_c();
    select! {
        _ = sigterm.recv() => println!("Received SIGTERM"),
        _ = interrupt => println!("Received SIGINT")
    }
}
