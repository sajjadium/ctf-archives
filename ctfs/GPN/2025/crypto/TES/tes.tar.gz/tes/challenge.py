#!/usr/bin/env python3
import os
from tes import TES, pad


with open("/flag") as file:
    FLAG = file.read().strip()
QUOTA = 2**16


def main():
    KEY = os.urandom(16)
    
    tes = TES(KEY)
    remaining_quota = QUOTA

    try:
        while remaining_quota > 0:
            plaintext = bytes.fromhex(input("Give me something to encrypt (hex):"))
            if len(plaintext) == 0: 
                break
            else:
                remaining_quota -= len(pad(plaintext))
            if remaining_quota < 0:
                raise ValueError("nah")
            
            ciphertext = tes.encrypt_ecb(pad(plaintext))
            print(ciphertext.hex())

        key_guess = bytes.fromhex(input("Guess the key (hex):"))
        if key_guess == KEY:
            print(FLAG)
        else:
            print("Running on my toaster AND secure, hah")
    except EOFError:
        pass # remote terminated, exit
    except:
        print("terminated due to error")

if __name__ == "__main__":
    main()
