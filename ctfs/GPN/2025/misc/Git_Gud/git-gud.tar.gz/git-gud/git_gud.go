package main

import (
	"fmt"
	"net/http"
	"os"
	"os/exec"

	"github.com/go-git/go-git/v5"
)

func main() {
    _, err := git.PlainClone("/tmp/lazygit", false, &git.CloneOptions {
        URL: "https://github.com/kdheepak/lazygit.nvim.git",
    })
    os.Setenv("VIMRUNTIME", "/tmp/lazygit")

    if err != nil {
        fmt.Println("Error: ", err)
        return
    }

    http.HandleFunc("/register", register)
    http.Handle("/", http.FileServer(http.Dir("./pages")))

    err = http.ListenAndServe(":1337", nil)
    fmt.Println(err)
}

func register(w http.ResponseWriter, r *http.Request) {
    username := r.URL.Query().Get("username")

    if len(username) <= 0 {
        http.Error(w, "Bad username", 400)
        return
    }

    fmt.Printf("Cloning for user %s\n", username)

    targetPath := fmt.Sprintf("/tmp/%s", username)

    _, err := git.PlainClone(targetPath, false, &git.CloneOptions {
        URL: "https://github.com/Mr-Pine/scaling-octo-invention",
    })

    if err != nil {
        fmt.Println("An error occured while cloning: ", err)
        return
    } else {
        fmt.Println("Cloned repository")
    }

    cmd := exec.Command("nvim", "--headless", "-u", "/init.vim", "flag.txt")
    cmd.Dir = targetPath
    cmd.Stdout = os.Stdout
    cmd.Stderr = os.Stderr

    cmd.Run()
    fmt.Println("\nHandled user ", username)

    http.Redirect(w, r, "/landing.html", http.StatusFound)
}
