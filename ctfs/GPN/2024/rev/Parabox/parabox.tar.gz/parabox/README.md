# README

Your goal is to finish the game. You can use any emulator or real hardware as you like. 

The flag is not in the distributed material. Send the inputs you needed to the remote to get the flag. Everything but the `parabox.gbc` is information about the remote setup. 

## Acknowledgements

Thanks to Patrick Traynor for the permission to use his game idea for this challenge. If you enjoy playing this challenge, check out the original. It is even better. There is a demo on steam to try it out.

Thank you to the author of the "baba is you" challenge from hxp CTF 2021 for inspiring me to try writing a GBC game as CTF challenge. 

The font used in the game can be found at https://de.fonts2u.com/modern-dos-8x8.schriftart
