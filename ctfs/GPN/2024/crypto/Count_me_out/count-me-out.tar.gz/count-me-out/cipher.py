from Crypto.Cipher import AES
#remember pycryptodome
import sys
import secrets
class Counter:
    def __init__(self,length):
        self.bytes = secrets.token_bytes(length)
        self.len = length
    def pp(self):
        p = (int.from_bytes(self.bytes,"big")+1) % 2**(8*self.len)
        self.bytes = p.to_bytes(self.len,"big")

    def gInc(self):
        o = self.bytes
        self.pp()
        return o

def xor(b1:bytes, b2:bytes):
    assert len(b1) == len(b2),"bytes have unequal length"
    return bytes([a ^ b for a, b in zip(b1, b2)])

class Sequential_Advanced_Flipping_Enumeration:

    def __init__(self,key):
        self.ecb = AES.new(key,AES.MODE_ECB)
        self.ctr = Counter(16)

    def _encryptBlock(self,block):
        assert len(block) == 16,"invalid block length"
        iv = self.ctr.gInc()
        return self.ecb.encrypt(xor(block,iv))

    def encrypt(self,message):
        blocks = [message[i:i+16] for i in range(0,len(message),16)]
        blocks[-1] = blocks[-1].ljust(16,b"\x00")
        encrypted = [self._encryptBlock(i) for i in blocks]
        return b"".join(encrypted)

def indcpa():
    SAFE_MODE= Sequential_Advanced_Flipping_Enumeration(secrets.token_bytes(32))
    #if it is called safe it must be safe 
    while (k:=bytes.fromhex(input("oracle:").strip()))!=b"challenge":
        print(SAFE_MODE.encrypt(k).hex())

    c0 =  bytes.fromhex(input("first challenge plaintext:").strip())
    c1 =  bytes.fromhex(input("second challenge plaintext:").strip())
    c_star = secrets.choice([c1,c0])
    b = 1 if c_star == c1 else 0 
    print(SAFE_MODE.encrypt(c_star).hex())
    b_u = int(input("b = ?:").strip())
    return b_u == b

if __name__ == '__main__':
    rounds = 1000
    failed = False
    for i in range(rounds):
        if not indcpa():
            failed = True
            break 
    if failed:
        print("skill issue sorry")
        sys.exit(0)
    print("Good job you won here is your flag")
    print(open("flag.txt").readline())
