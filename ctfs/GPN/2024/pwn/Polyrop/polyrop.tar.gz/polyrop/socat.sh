#!/bin/sh

socat -v TCP-LISTEN:4140,reuseaddr,fork EXEC:"./composer.py",stderr
