#!/bin/sh
# run
/usr/bin/stdbuf -i0 -o0 -e0 ./song_rater
