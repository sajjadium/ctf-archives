#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    while (1) {
        char date[256];
        printf("Guess when I was encrypted ([YYYY]-[MM]-[DD]T[HH]:[MM]:[SS]+[HH]:[MM]): ");
        if (fgets(date, sizeof(date), stdin) == NULL) {
            printf("Error reading input.\n");
            return 1;
        }
        date[strcspn(date, "\n")] = '\0';
        pid_t pid = fork();
        if (pid == -1) {
            printf("Error forking process.\n");
            return 1;
        } else if (pid == 0) {
            // Child process
            char* argv[] = {"openssl", "enc", "-d", "-aes-256-cbc", "-k", date, "-pbkdf2", "-base64", "-in", "flag.enc", "-out", "/dev/null", NULL};
            execvp("openssl", argv);
            printf("Error running openssl.\n");
            return 1;
        } else {
            // Parent process
            int status;
            waitpid(pid, &status, 0);
            if (WIFEXITED(status) && WEXITSTATUS(status) == 0) {
                printf("The guessed date is correct!\n");
                return 0;
            } else {
                printf("The guessed date is incorrect. Try again!\n");
            }
        }
    }
}
