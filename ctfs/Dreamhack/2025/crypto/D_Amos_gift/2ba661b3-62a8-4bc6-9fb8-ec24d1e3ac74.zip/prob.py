from Crypto.Util.number import *

FLAG = b"DH{FAKE_FLAG}"
FLAG = bytes_to_long(FLAG)

while True:
    p = getPrime(1024)
    q = getPrime(1024)
    N = p * q
    e = 0x10001
    if GCD(e, (p - 1) * (q - 1)) == 1:
        break

# Here is amo's gift for you!
gifts = []
for i in range(800):
    if isPrime(i):
        gift = [p % i, q % i]
        gift = sorted(gift) # What's wrong with you, AMO?
        gifts.append(gift)

FLAG_enc = pow(FLAG, e, N)

print(f"{N = }")
print(f"{e = }")
print(f"{FLAG_enc = }")
print(f"{gifts = }")