while true; do flask run -h 0.0.0.0 ; done
