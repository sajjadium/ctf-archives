#!/bin/bash

cd /app || exit
bun /app/server.js
