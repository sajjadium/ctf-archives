from cubesat_upstream_driver import handle_command


def process_command(cmd: str) -> str:
    """F'-style command dispatcher with telemetry-like output."""
    cmd = (cmd or "").strip()
    if not cmd:
        return "TM|WARN|EMPTY_COMMAND"

    driver_reply = handle_command(cmd)
    if driver_reply:
        return f"TM|EVENT|COMMAND_ACK|{driver_reply}"

    if cmd == "PING":
        return "TM|HEALTH|OK"
    if cmd == "STATUS":
        return "TM|BUS|NOMINAL"

    return f"TM|CMD|IGNORED|{cmd}"
