"""Flight app package."""
