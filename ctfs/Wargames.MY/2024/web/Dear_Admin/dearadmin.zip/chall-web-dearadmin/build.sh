#!/bin/sh

docker build . -t web-dear-admin
docker run --rm --name=web-dear-admin -p 8080:80 web-dear-admin