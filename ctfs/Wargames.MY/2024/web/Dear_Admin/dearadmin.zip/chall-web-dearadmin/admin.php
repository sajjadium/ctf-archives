<?php

// Check if request is from localhost
if ($_SERVER['REMOTE_ADDR'] !== '127.0.0.1' && $_SERVER['REMOTE_ADDR'] !== '::1') {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Forbidden: Access only allowed from localhost'
    ]);
    exit;
}

require_once 'config.php';

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

header('Content-Type: application/json');

if (!isset($_GET['poem'])) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request'
    ]);
    exit;
}

$poem = trim($_GET['poem']);
$uniqueId = uniqid('poem_', true);
$evaluation = [
    'length' => strlen($poem),
    'lines' => count(explode("\n", $poem)),
    'words' => str_word_count($poem)
];

$isAcceptable = $evaluation['words'] >= 10 && $evaluation['lines'] >= 3;

if ($isAcceptable) {
    try {

        if (!function_exists('renderTemplate')) {
            throw new Exception("renderTemplate function is not defined");
        }
        
        $htmlContent = renderTemplate('admin_review', [
            'poem' => [
                'content' => htmlspecialchars($poem),
                'id' => htmlspecialchars($uniqueId),
                'evaluation' => [
                    'length' => (int)$evaluation['length'],
                    'lines' => (int)$evaluation['lines'], 
                    'words' => (int)$evaluation['words']
                ],
                'status' => 'pending',
                'submitted_at' => date('Y-m-d H:i:s')
            ]
        ]);

        if (empty($htmlContent)) {
            throw new Exception("Template rendering produced empty content");
        }

        $reviewPath = __DIR__ . '/reviews'; 
        if (!is_dir($reviewPath)) {
            mkdir($reviewPath, 0755, true);
        }
        
        $filePath = $reviewPath . '/' . $uniqueId . '.html';

        file_put_contents($filePath, $htmlContent);

        $response = [
            'status' => 'success',
            'message' => 'Thank you! Your poem has been accepted for review.',
            'review_link' => '/reviews/' . $uniqueId . '.html' 
        ];
    } catch (Exception $e) {
        
        $response = [
            'status' => 'error',
            'message' => 'An error occurred while processing your poem. Debug: ' . $e->getMessage()
        ];
        
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode($response);
        exit;
    }
} else {
    $response = [
        'status' => 'error',
        'message' => 'Your poem is too short. Please ensure it has at least 10 words and 3 lines.'
    ];
}

echo json_encode($response);
