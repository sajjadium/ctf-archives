<?php
session_start();

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$status = isset($_SESSION['status']) ? $_SESSION['status'] : '';
unset($_SESSION['message'], $_SESSION['status']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['poem'])) {
    $poem = trim($_POST['poem']);
    
    if (empty($poem)) {
        $_SESSION['message'] = 'Please enter a poem.';
        $_SESSION['status'] = 'error';
    } else {
        $ch = curl_init('http://localhost/admin.php?poem=' . urlencode($poem));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        
        if ($response === false) {
            $_SESSION['message'] = 'Connection error: ' . curl_error($ch);
            $_SESSION['status'] = 'error';
        } else {
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $result = json_decode($response, true);
            
            if ($result === null) {
                $_SESSION['message'] = 'Invalid response from server: ' . $response;
                $_SESSION['status'] = 'error';
            } else if ($httpCode === 200) {
                $_SESSION['message'] = $result['message'];
                $_SESSION['status'] = $result['status'];
                if (isset($result['review_link'])) {
                    $_SESSION['review_link'] = $result['review_link'];
                }
            } else {
                $_SESSION['message'] = 'Server error (HTTP ' . $httpCode . ')';
                $_SESSION['status'] = 'error';
            }
        }
        curl_close($ch);
    }
    
    if (headers_sent()) {
        echo "<script>window.location.href='index.php';</script>";
        exit;
    }
    
    header('Location: index.php');
    exit;
}

$review_link = isset($_SESSION['review_link']) ? $_SESSION['review_link'] : '';
unset($_SESSION['review_link']); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Submit Your Poem</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem 20px;
            background-color: #f5f5f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }

        .container {
            background: white;
            padding: 3rem;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
            width: 100%;
        }

        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 2.5rem;
            font-size: 2.2rem;
        }

        .poem-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            max-width: 800px;
            margin: 0 auto;
        }

        textarea {
            width: 100%;
            min-height: 300px;
            padding: 1.2rem;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 16px;
            line-height: 1.8;
            resize: vertical;
            transition: all 0.3s ease;
            box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
        }

        textarea:focus {
            outline: none;
            border-color: #3498db;
            box-shadow: 0 0 8px rgba(52,152,219,0.2);
        }

        button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 14px 32px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
            align-self: center;
            min-width: 200px;
        }

        button:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(52,152,219,0.2);
        }

        .alert {
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            text-align: center;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .info {
            color: #666;
            text-align: center;
            margin-top: 1rem;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Submit Your Poem</h1>
        
        <?php if ($message): ?>
            <div class="alert <?php echo htmlspecialchars($status); ?>">
                <?php echo htmlspecialchars($message); ?>
                <?php if ($review_link): ?>
                    <br><br>
                    <a href="<?php echo htmlspecialchars($review_link); ?>" target="_blank">View your submission</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <form class="poem-form" action="index.php" method="POST">
            <textarea 
                name="poem" 
                required 
                placeholder="Type your poem here..."
            ></textarea>
            <button type="submit">Submit Poem</button>
        </form>

        <p class="info">
            Your poem will be reviewed before publication.
        </p>
    </div>
</body>
</html>