<?php

error_reporting(E_ERROR | E_PARSE);

require_once __DIR__ . '/vendor/autoload.php';

// Site configuration
define('SITE_URL', '');
define('REVIEW_DIR', __DIR__ . '/reviews');
define('CACHE_DIR', __DIR__ . '/cache');

$templatePath = getCliOption('templatesPath');

if ($templatePath) {
    try {
        $templatePath = validatePath($templatePath);
        $loader = new \Twig\Loader\ArrayLoader([
            'dynamic_template' => $templatePath
        ]);
        $twig = new \Twig\Environment($loader, [
            'auto_reload' => true
        ]);
    } catch (InvalidArgumentException $e) {
        die('Invalid template file: ' . $e->getMessage());
    }
} else {
    $loader = new \Twig\Loader\FilesystemLoader(__DIR__ . '/templates');
    $twig = new \Twig\Environment($loader, [
        'auto_reload' => true
    ]);
}

function renderTemplate($template, $data) {
    global $twig, $templatePath;
    if ($templatePath) {
        return $twig->render('dynamic_template', $data);
    }
    return $twig->render($template . '.twig', $data);
}

function getCliOption($name) {
    if (!ini_get('register_argc_argv')) {
        return null;
    }

    if (!empty($_SERVER['argv'])) {
        foreach ($_SERVER['argv'] as $i => $arg) {
            $arg = urldecode($arg);
            
            if ($arg === $name || $arg === "-$name" || $arg === "--$name") {
                return isset($_SERVER['argv'][$i + 1]) ? urldecode($_SERVER['argv'][$i + 1]) : true;
            }
            
            if (strpos($arg, "$name=") === 0 || 
                strpos($arg, "-$name=") === 0 || 
                strpos($arg, "--$name=") === 0) {
                $value = substr($arg, strpos($arg, '=') + 1);
                return urldecode($value);
            }
        }
    }
    
    return null;
}

function validatePath($path) {
    if (!file_exists($path . "/admin_review.twig")) {
        throw new InvalidArgumentException("Template file does not exist: $path");
    }
    
    $content = @file_get_contents($path . "/admin_review.twig");
    if ($content === false) {
        throw new InvalidArgumentException("Cannot read template file: $path");
    }
    
    checkTemplateContent($content, $path . "/admin_review.twig", 'template');
    
    return $content;
}

function checkTemplateContent($content, string $path, string $type): void {
    $forbidden = [
        'system', 'exec', 'shell_exec', 'passthru', 'popen', 'proc_open',
        'assert', 'pcntl_exec', 'eval', 'call_user_func', 'ReflectionFunction','filter','~'
    ];

    foreach ($forbidden as $word) {
        if (stripos($content, $word) !== false) {
            http_response_code(403);
            die("Oh no! 😭 You tried to use the forbidden word '$word'! The admin is very sad now... 😢");
        }
    }
}


