package com.example.chamber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChamberApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChamberApplication.class, args);
    }
}