<?php

/**
 * Plugin Name: Wargames.MY Functions
 * Plugin URI: https://wargames.local/wgmy-functions/
 * Description: WooCommerce plugin only for Wargames Users
 * Version: 1.0.1
 * Author: h0j3n
*/

add_action( 'rest_api_init', function () {
    register_rest_route( 'wgmy/v1', '/add_user', array(
      'methods' => 'POST',
      'callback' => 'user_creation_menu',
      'permission_callback' => '__return_true',
    ) );
  } );
  

function user_creation_menu(){
    if (isset($_POST["role"]) && isset($_POST["login"]) && isset($_POST["password"]) && isset($_POST["email"]) && isset($_POST["secret"])) {

        if (get_option('wgmy_secret') == $_POST["secret"]){
            $login = sanitize_user($_POST['login']);
            $password = sanitize_text_field($_POST['password']);
            $email = sanitize_email($_POST['email']);
            $role = sanitize_text_field($_POST['role']);

            if (in_array($role, array("shop_manager", "customer", "subscriber"))) {

                $user_id = wp_create_user($login, $password, $email);
        
                if (is_wp_error($user_id)) {
                    $result['message'] = $user_id->get_error_message();
                    echo json_encode($result);
                } else {
                    
                        $user = new WP_User($user_id);
                        $user->set_role($role);
        
                        $result['message'] = 'User created successfully!';
                        $result['user_id'] = $user_id;
        
                        echo json_encode($result);
                }
            } else {
                $result['message'] = 'Only shop_manager, customer, and subscriber roles are allowed.';
                echo json_encode($result);
            }
               
        }
        else {
            $result['message'] = 'Invalid secret provided.';
            echo json_encode($result);
        }
        
    } else {
        $result['message'] = 'Required fields: role, login, password, email, and secret.';
        echo json_encode($result);
    }
}

add_action("wp_ajax_get_config", "get_config");
add_action("wp_ajax_nopriv_get_config", "get_config");

function get_config(){
    if (isset($_POST["switch"]) && $_POST["switch"] === "1") {
        $secret_value = get_option('wgmy_secret');
        if ($secret_value) {
            echo json_encode(array('secret' => $secret_value));
        } else {
            echo json_encode(array('error' => 'Secret not found.'));
        }
    }
}
