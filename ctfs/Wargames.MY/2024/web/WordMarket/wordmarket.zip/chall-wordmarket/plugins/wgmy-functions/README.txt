=== Wargames.MY Functions ===
Author: h0j3n
