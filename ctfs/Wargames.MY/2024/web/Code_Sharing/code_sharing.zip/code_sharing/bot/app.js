const CF_TURNSTILE_BASE_URL = "https://challenges.cloudflare.com/turnstile/v0";
const CF_TURNSTILE_API_JS_URL = `${CF_TURNSTILE_BASE_URL}/api.js`;
const CF_TURNSTILE_VERIFY_URL = `${CF_TURNSTILE_BASE_URL}/siteverify`;
const CF_TURNSTILE_SITEKEY = process.env.CF_TURNSTILE_SITEKEY || "1x00000000000000000000AA";
const CF_TURNSTILE_SECRET = process.env.CF_TURNSTILE_SECRET || "1x0000000000000000000000000000000AA";

const WGMY_FLAG = process.env.WGMY_FLAG || "flag{test}";

const INDEX_HTML = `<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Code Sharing Bot</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simpledotcss/2.3.3/simple.min.css" integrity="sha512-rdDUVTXxEhS8tMTAZfbN/vADCfDW7wRFlvWLQEG6OElbwzH/6v4Df+6PfwYfwZ72Pj5XAoXUWadq101DpmxopA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script async src="${CF_TURNSTILE_API_JS_URL}"></script>
  </head>
  <body>
    <header>
      <h1>Code Sharing Bot</h1>
    </header>
    <main style="text-align: center;">
      <form method="post">
        <p>
          <input type="url" name="url" placeholder="URL" required style="width: 100%;">
        </p>
        <div class="cf-turnstile" data-sitekey="${CF_TURNSTILE_SITEKEY}"></div>
        <p>
          <button>Submit</button>
        </p>
      </form>
    </main>
  </body>
</html>`;

import { serve, sleep } from "bun";
import { launch } from "puppeteer";

const verify = async (token) => {
  try {
    const body = new FormData();
    body.append("secret", CF_TURNSTILE_SECRET);
    body.append("response", token);
    const res = await fetch(CF_TURNSTILE_VERIFY_URL, { method: "POST", body });
    const json = await res.json();
    return json.success;
  } catch {
    return false;
  }
};

let browser;

const visit = async (url) => {
  let context;
  try {
    if (!browser) {
      browser = await launch({
        headless: true,
        args: ["--js-flags=--jitless,--no-expose-wasm", "--disable-gpu", "--disable-dev-shm-usage"],
      });
    }
    context = await browser.createBrowserContext();
    const page = await context.newPage();
    await page.setCookie({ name: "flag", value: WGMY_FLAG, domain: "web.wgmy" });
    await page.goto(url);
    await sleep(3000);
    await page.close();
  } catch (e) {
    console.error(e);
  } finally {
    if (context) {
      await context.close();
    }
  }
};

const server = serve({
  async fetch(req) {
    switch (req.method) {
      case "GET":
        return new Response(INDEX_HTML, { headers: new Headers({ "content-type": "text/html" }) });
      case "POST":
        const formData = await req.formData();
        const url = formData.get("url");
        const token = formData.get("cf-turnstile-response");
        if (!url || !url.startsWith("http://web") || !token || !(await verify(token))) {
          return new Response("400 Bad Request", { status: 400 });
        }
        console.info(`Visiting ${url}`);
        visit(url);
        return new Response("Bot will take a look at your code shortly!");
    }
    return new Response("405 Method Not Allowed", { status: 405 });
  },
});

console.info(`Listening on ${server.url}`);
