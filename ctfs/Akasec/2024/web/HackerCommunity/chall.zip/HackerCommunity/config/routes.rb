Rails.application.routes.draw do
  root to: redirect('/join')
  get '/users/latest', to: "users#latest"
  get '/flag', to: "users#flag"
  get '/join', to: 'join#index'
  post '/join', to: 'join#create'
  get '/home', to: 'home#index'
end
