docker rmi -f hackercommunity
docker build . -t hackercommunity
docker run -p 3000:3000 hackercommunity
