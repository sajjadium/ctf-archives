class JoinController < ApplicationController
  def index
    redirect_to home_path if session[:user_id]
  end

  def create
    redirect_to home_path if session[:user_id]
    begin
      @user = User.new(user_params)
      if @user.save
        session[:user_id] = @user.id
        redirect_to home_path
      else
        render :index
      end
    rescue ActiveModel::UnknownAttributeError => e
        render plain: e, status: :forbidden
    end
  end

  private
  def user_params
    params.delete_if {|k,v| !k.is_a?(String) || !v.is_a?(String) || !k.ascii_only? || ["authenticity_token", "controller", "action", "admin"].include?(k)}.permit!
  end
end
