class HomeController < ApplicationController
  def index
    if session[:user_id]
      @username = User.find_by(id: session[:user_id]).username
      if User.find_by(id: session[:user_id]).admin?
        begin
          response = HTTP.follow.get(users_latest_url)
          @users = JSON.parse(response.body)
        rescue Exception => e
          render plain: "Error: #{e}", status: 500
        end
      else
        @users = User.order(created_at: :desc).limit(5).as_json
      end
    else
      redirect_to(join_url)
    end
  end
end
