class UsersController < ApplicationController
  before_action :restrict_access

  def latest
    @users = User.order(created_at: :desc).limit(10)
    render json: @users
  end

  def flag
    render plain: File.open("/rails/flag.txt").read
  end

  private
  def restrict_access
    render plain: "Access Denied", status: :forbidden unless request.env['REMOTE_ADDR'] == '127.0.0.1'
  end
end
