module JoinHelper
end
