#!/bin/bash

timeout 60 /home/pyjail/jail.py
