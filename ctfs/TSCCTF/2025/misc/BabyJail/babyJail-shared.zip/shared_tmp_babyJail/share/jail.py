#!/usr/local/bin/python3

print(eval(input('> '), {"__builtins__": {}}, {}))
