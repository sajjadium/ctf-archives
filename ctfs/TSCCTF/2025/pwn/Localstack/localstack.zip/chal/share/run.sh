#!/bin/sh

exec 2>/dev/null
cd /home/localstack
timeout 60 /home/localstack/localstack