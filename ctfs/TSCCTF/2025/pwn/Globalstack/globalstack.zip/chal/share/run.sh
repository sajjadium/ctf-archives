#!/bin/sh

exec 2>/dev/null
cd /home/globalstack
timeout 60 /home/globalstack/globalstack