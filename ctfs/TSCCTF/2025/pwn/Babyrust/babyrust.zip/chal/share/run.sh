#!/bin/sh

exec 2>/dev/null
cd /home/babyrust
timeout 60 /home/babyrust/babyrust