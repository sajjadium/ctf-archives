#!/bin/bash

ulimit -Hn 100000
ulimit -n 100000
socat VSOCK-LISTEN:9000 EXEC:"/root/chal $(cat /root/flag)"
