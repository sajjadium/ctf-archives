#!/usr/bin/bash

/home/user/template_server/nodejs.sh &
/home/user/heaven_server/nodejs.sh

