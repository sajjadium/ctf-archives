#!/bin/bash

# Start node web server


while true; do
    node /home/user/heaven_server/index.js
done
