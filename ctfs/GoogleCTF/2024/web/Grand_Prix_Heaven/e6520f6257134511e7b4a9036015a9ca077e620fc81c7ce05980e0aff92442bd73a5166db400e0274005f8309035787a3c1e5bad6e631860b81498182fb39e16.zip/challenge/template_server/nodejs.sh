#!/bin/bash

# Start node web server


while true; do
    node /home/user/template_server/index.js
done
