<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="flag" tilewidth="28" tileheight="32" tilecount="6" columns="3">
 <image source="flag.png" width="84" height="64"/>
 <tile id="0">
  <properties>
   <property name="animation" value="flag"/>
   <property name="loop" type="bool" value="true"/>
  </properties>
  <animation>
   <frame tileid="0" duration="125"/>
   <frame tileid="1" duration="125"/>
   <frame tileid="2" duration="125"/>
   <frame tileid="3" duration="125"/>
   <frame tileid="4" duration="125"/>
   <frame tileid="5" duration="125"/>
  </animation>
 </tile>
</tileset>
