<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="water_tileset" tilewidth="16" tileheight="16" tilecount="1200" columns="60">
 <image source="water.png" width="960" height="320"/>
</tileset>
