<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="key_red" tilewidth="28" tileheight="26" tilecount="1" columns="1">
 <image source="magnet.png" width="28" height="26"/>
</tileset>
