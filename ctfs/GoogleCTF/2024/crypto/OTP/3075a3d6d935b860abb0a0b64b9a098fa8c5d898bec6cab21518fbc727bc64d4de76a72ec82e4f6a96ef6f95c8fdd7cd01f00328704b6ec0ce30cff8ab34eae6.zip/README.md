# OTP

I encrypted all my pictures using this fancy cipher.
Unfortunately I lost my key, can you help me recover my data?
