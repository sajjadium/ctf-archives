#!/usr/bin/bash

export PORT=$1
export XSSBOT_HOST=$2
export XSSBOT_PORT=$3

while true; do 
    /server
done

