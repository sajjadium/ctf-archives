#!/bin/bash

while true; do
  cd /home/ && java -mx4g -cp "CoreNLP-4.5.8/*" "edu.stanford.nlp.pipeline.StanfordCoreNLPServer" -port 1337 -timeout 15000
done
