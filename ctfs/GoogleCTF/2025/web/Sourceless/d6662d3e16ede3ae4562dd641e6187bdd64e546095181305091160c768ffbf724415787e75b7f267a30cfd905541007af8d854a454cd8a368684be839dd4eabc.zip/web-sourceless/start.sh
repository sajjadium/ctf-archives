#!/bin/bash
while true; do
  node /home/user/app.mjs;
  pkill firefox;
done
