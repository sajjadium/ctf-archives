I have created a bunch of message/ciphertext pairs with this new technique.

I gave you the "key" to decrypt the flag, is that enough?
