#![no_std]

mod anim;
mod flag;
pub mod game;
mod map;
mod map_data;
mod palettes;
mod physics;
mod sonk;
mod spike;
mod tiles;
mod wasp;

pub use game::Game;
