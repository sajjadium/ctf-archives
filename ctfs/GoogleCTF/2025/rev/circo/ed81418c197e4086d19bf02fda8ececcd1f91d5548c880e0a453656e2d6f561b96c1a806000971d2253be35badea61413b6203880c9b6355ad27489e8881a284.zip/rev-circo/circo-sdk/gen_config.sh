#!/bin/bash
openssl genrsa -f4 1024 | openssl rsa -traditional | openssl asn1parse -item RSAPrivateKey > private_key.yaml
openssl rand -out random.key 16
./signer gen_config > config.circo
