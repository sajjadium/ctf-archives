A game I found in a developer's drawer, it looks like an unfinished game about a character jumping rocks or something?

I don't have a console with me, but you can emulate it with [MAME](https://www.mamedev.org/):

```sh
$ /usr/games/mame -hashpath hash -window -rp roms gbcolor gctf
```
