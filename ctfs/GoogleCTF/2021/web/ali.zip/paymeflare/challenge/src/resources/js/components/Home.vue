<template>
  <div class="bg-light p-5 rounded">
    <h1>paymepal</h1>
    <p class="lead">We make paying easy.</p>
  </div>
</template>

