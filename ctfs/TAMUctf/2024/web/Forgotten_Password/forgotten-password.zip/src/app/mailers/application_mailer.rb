class ApplicationMailer < ActionMailer::Base
  default from: "ForgottenPassword@tamuctf.com"
  layout "mailer"
end
