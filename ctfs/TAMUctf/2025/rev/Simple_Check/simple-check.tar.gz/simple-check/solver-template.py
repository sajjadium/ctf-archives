from pwn import *

context.log_level = "debug"
io = remote("fuzzbox.addisoncrump.info", 41337)
io.interactive(prompt="")
