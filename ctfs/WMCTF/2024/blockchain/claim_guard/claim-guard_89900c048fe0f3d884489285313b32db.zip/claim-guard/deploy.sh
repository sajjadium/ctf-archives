docker pull ghcr.io/foundry-rs/foundry:latest
cd bot && cargo build -r && rm -rf ./claim-guard && mv target/release/claim-guard . && docker build -t claim-guard-bot . && cd ..
docker-compose up --build