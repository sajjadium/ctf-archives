from typing import Dict

from ctf_launchers.pwn_launcher import PwnChallengeLauncher
from ctf_server.types import (
    get_additional_account,
    get_privileged_web3,
    DaemonInstanceArgs,
    LaunchAnvilInstanceArgs,
    UserData,
)

BLOCK_TIME = 12

def check_error(resp):
    if "error" in resp:
        raise Exception("rpc exception", resp["error"])

def anvil_setBalance(
    web3,
    addr: str,
    balance: str,
):
    check_error(web3.provider.make_request("anvil_setBalance", [addr, balance]))

class Challenge(PwnChallengeLauncher):
    def deploy(self, user_data: UserData, mnemonic: str) -> str:
        web3 = get_privileged_web3(user_data, "main")

        web3.provider.make_request("evm_setAutomine", [True])
        challenge_addr = super().deploy(user_data, mnemonic)
        web3.provider.make_request("evm_setIntervalMining", [BLOCK_TIME])

        mev_guard = get_additional_account(mnemonic, 0)
        anvil_setBalance(web3, mev_guard.address, hex(1000 * 10 ** 18))

        return challenge_addr

    def get_anvil_instances(self) -> Dict[str, LaunchAnvilInstanceArgs]:
        return {
            "main": self.get_anvil_instance(
                fork_url=None,
                accounts=3,
                block_time=BLOCK_TIME,
                balance=0.1
            ),
        }

    def get_daemon_instances(self) -> Dict[str, DaemonInstanceArgs]:
        return {
            "daemon": DaemonInstanceArgs(
                image="claim-guard-bot:latest",
            )
        }

Challenge().run()
