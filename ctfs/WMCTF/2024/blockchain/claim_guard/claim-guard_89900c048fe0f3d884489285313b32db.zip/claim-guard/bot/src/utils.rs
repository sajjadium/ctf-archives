use alloy::{
    providers::{ProviderBuilder, ReqwestProvider},
    rpc::types::{Block, Transaction},
};
use eyre::Context;
use revm::primitives::{BlobExcessGasAndPrice, BlockEnv, TransactTo, TxEnv, B256, U256};

pub fn new_http_provider<T: AsRef<str>>(url: T) -> eyre::Result<ReqwestProvider> {
    let url = url.as_ref().parse().context("invalid RPC url")?;
    let provider = ProviderBuilder::new().on_http(url);

    Ok(provider)
}

pub fn block_to_block_env(block: &Block) -> BlockEnv {
    let block_number = U256::from(block.header.number.unwrap());

    BlockEnv {
        number: block_number,
        timestamp: U256::from(block.header.timestamp),
        coinbase: block.header.miner,
        difficulty: block.header.difficulty,
        prevrandao: Some(block.header.mix_hash.unwrap_or_default()),
        basefee: block
            .header
            .base_fee_per_gas
            .map(U256::from)
            .unwrap_or_default(),
        gas_limit: U256::from(block.header.gas_limit),
        blob_excess_gas_and_price: Some(BlobExcessGasAndPrice::new(
            block.header.excess_blob_gas.unwrap_or_default() as u64,
        )),
    }
}

pub fn tx_to_tx_env(tx: &Transaction) -> TxEnv {
    TxEnv {
        caller: tx.from,
        gas_limit: tx.gas as u64,
        gas_price: match tx.transaction_type {
            Some(2) | Some(3) => U256::from(tx.max_fee_per_gas.unwrap_or_default()),
            _ => U256::from(tx.gas_price.unwrap_or_default()),
        },
        gas_priority_fee: tx.max_priority_fee_per_gas.map(U256::from),
        nonce: None,
        access_list: tx.access_list.clone().unwrap_or_default().0,
        value: tx.value,
        data: tx.input.clone(),
        transact_to: tx.to.map(TransactTo::Call).unwrap_or(TransactTo::Create),

        chain_id: None,
        blob_hashes: vec![],
        max_fee_per_blob_gas: None,
        authorization_list: None,
    }
}

pub fn b256_to_u256(b: B256) -> U256 {
    U256::from_be_slice(b.as_slice())
}
