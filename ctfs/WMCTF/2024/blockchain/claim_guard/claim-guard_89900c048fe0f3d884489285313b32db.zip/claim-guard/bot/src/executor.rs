use std::sync::Arc;

use alloy::network::{eip2718::Encodable2718, EthereumWallet, TransactionBuilder};
use alloy::providers::Provider;
use alloy::signers::local::PrivateKeySigner;
use alloy::{rpc::types::TransactionRequest, transports::Transport};
use async_trait::async_trait;
use burberry::Executor;
use eyre::Result;
use tracing::info;

pub struct SimpleExecutor<T> {
    pub provider: Arc<dyn Provider<T>>,
    pub wallet: EthereumWallet,
}

impl<T: Clone + Transport> SimpleExecutor<T> {
    pub fn new(provider: Arc<dyn Provider<T>>, signer: PrivateKeySigner) -> Self {
        let wallet = EthereumWallet::new(signer);
        Self { provider, wallet }
    }
}

#[async_trait]
impl<T: Clone + Transport> Executor<TransactionRequest> for SimpleExecutor<T> {
    fn name(&self) -> &str {
        "SimpleExecutor"
    }

    async fn execute(&self, action: TransactionRequest) -> Result<()> {
        info!("tx: {:?}", action);
        let raw_tx = action.build(&self.wallet).await?.encoded_2718();
        let h = self.provider.send_raw_transaction(&raw_tx).await?;
        info!("tx hash: {:?}", h.tx_hash());

        Ok(())
    }
}
