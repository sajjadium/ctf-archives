use std::{collections::HashMap, sync::Arc};

use alloy::{
    eips::BlockNumberOrTag,
    hex,
    primitives::Address,
    providers::Provider,
    rpc::types::{Block, Transaction, TransactionInput, TransactionRequest},
    transports::Transport,
};

use burberry::{ActionSubmitter, Strategy};
use revm::{
    db::{AlloyDB, CacheDB},
    primitives::{
        b256, keccak256, ruint::UintTryTo, BlockEnv, Bytes, ExecutionResult, Log, TransactTo,
        TxEnv, TxKind, U256,
    },
    EvmBuilder,
};
use tracing::info;

use crate::{
    utils::{b256_to_u256, block_to_block_env, new_http_provider, tx_to_tx_env},
    CollectorEvent,
};

pub struct SimpleStrategy<T> {
    pub provider: Arc<dyn Provider<T>>,
    pub http_url: String,
    pub sender_addr: Address,
    pub chall_addr: Address,
    pub nonce_map: HashMap<u64, u64>,
}

#[async_trait::async_trait]
impl<T: Clone + Transport> Strategy<CollectorEvent, TransactionRequest> for SimpleStrategy<T> {
    async fn sync_state(
        &mut self,
        submitter: Arc<dyn ActionSubmitter<TransactionRequest>>,
    ) -> eyre::Result<()> {
        info!("initializing SimpleStrategy");
        let balance = self.provider.get_balance(self.sender_addr).await?;
        info!("self balance: {}", balance);

        let current_block = self
            .provider
            .get_block_by_number(BlockNumberOrTag::Latest, false)
            .await?
            .unwrap();
        let bn = current_block.header.number.unwrap();
        self.process_new_block(current_block, submitter).await;

        Ok(())
    }

    fn name(&self) -> &str {
        "SimpleStrategy"
    }

    async fn process_event(
        &mut self,
        event: CollectorEvent,
        submitter: Arc<dyn ActionSubmitter<TransactionRequest>>,
    ) {
        match event {
            CollectorEvent::NewBlock(block) => {
                self.process_new_block(block, submitter).await;
            }
            CollectorEvent::PendingTx(tx) => {
                self.process_pending_tx(tx, submitter).await;
            }
        }
    }
}

impl<T: Clone + Transport> SimpleStrategy<T> {
    async fn process_new_block(
        &mut self,
        block: Block,
        submitter: Arc<dyn ActionSubmitter<TransactionRequest>>,
    ) {
        let bn = block.header.number.unwrap();
        let nonce = self
            .provider
            .get_transaction_count(self.sender_addr)
            .await
            .unwrap();
        self.nonce_map.insert(bn, nonce);

        // register the block
        let tx_receipt = TransactionRequest {
            from: Some(self.sender_addr),
            to: Some(TxKind::Call(self.chall_addr)),
            gas_price: Some(110000000000000000 / 100_0000),
            gas: Some(100_0000),
            chain_id: Some(self.provider.get_chain_id().await.unwrap()),
            nonce: Some(nonce),
            input: hex::decode("0xccac0007").unwrap().into(),
            ..Default::default()
        };

        submitter.submit(tx_receipt);
        self.nonce_map.insert(bn, nonce + 1);

        info!("registered block {:?}", block.header.number);
    }

    async fn process_pending_tx(
        &mut self,
        tx: Transaction,
        submitter: Arc<dyn ActionSubmitter<TransactionRequest>>,
    ) {
        if tx.from == self.sender_addr {
            return;
        }

        info!(
            tx_hash = ?tx.hash,
            from = ?tx.from,
            to = ?tx.to,
            calldata = ?tx.input,
            gas_price = ?tx.gas_price,
        );

        // try replay the tx and get log
        let finalized_block = self
            .provider
            .get_block_by_number(BlockNumberOrTag::Latest, false)
            .await
            .unwrap()
            .unwrap();

        let pending_block_env = {
            let mut e = block_to_block_env(&finalized_block);
            e.timestamp += U256::from(12);
            e.number += U256::from(1);
            e
        };

        let mut logs = self
            .try_extract(&tx, &finalized_block, &pending_block_env, false)
            .await;
        if logs.is_empty() {
            logs = self
                .try_extract(&tx, &finalized_block, &pending_block_env, true)
                .await;
        }

        if logs.is_empty() {
            return;
        }

        for log in logs {
            let event_sig = log.topics().first().unwrap_or_default();

            // event workProved(bytes32 indexed pow, uint256 indexed blockNumber);
            let expected_sig =
                b256!("43b47a556e2df626381786abf27f56c33c1b03959d388c745cb9f6651a6215a0");
            if *event_sig != expected_sig || log.address != self.chall_addr {
                continue;
            }

            let pow = log.topics().get(1).unwrap_or_default();
            let bn = log.topics().get(2).unwrap_or_default();

            if pending_block_env.number != b256_to_u256(*bn) {
                continue;
            }

            let h = {
                // abi.encodePacked(pow, block.number)
                let mut h = [0u8; 64];
                h[..32].copy_from_slice(&b256_to_u256(*pow).to_be_bytes_vec());
                h[32..].copy_from_slice(&pending_block_env.number.to_be_bytes_vec());

                Bytes::from(h)
            };

            let hash = b256_to_u256(keccak256(&h));

            if hash >> 0xf0 != U256::ZERO {
                continue;
            }

            // we can submit the proof
            info!("valid proof: {:?}", pow);

            // 0x27d4563e
            let sig: [u8; 4] = [0x27, 0xd4, 0x56, 0x3e];
            // concat sig and pow
            let mut data = Vec::with_capacity(4 + 32);
            data.extend_from_slice(&sig);
            data.extend_from_slice(pow.as_slice());
            let bytes = Bytes::from(data);

            let bn = finalized_block.header.number.unwrap();
            let nonce = *self.nonce_map.get(&bn).unwrap();

            let effective_gas_price = tx.gas_price.or(tx.max_fee_per_gas).unwrap_or_default();
            let chain_id = self.provider.get_chain_id().await.unwrap();
            let tx_receipt = TransactionRequest {
                from: Some(self.sender_addr),
                to: Some(TxKind::Call(self.chall_addr)),
                gas_price: Some(effective_gas_price * 2),
                gas: Some(100_0000),
                input: TransactionInput::new(bytes),
                chain_id: Some(chain_id),
                nonce: Some(nonce),

                ..Default::default()
            };

            submitter.submit(tx_receipt);
        }
    }

    async fn try_extract(
        &self,
        tx: &Transaction,
        finalized_block: &Block,
        pending_block_env: &BlockEnv,
        register: bool,
    ) -> Vec<Log> {
        let alloy_db = AlloyDB::new(
            new_http_provider(&self.http_url).unwrap(),
            finalized_block.header.number.unwrap().into(),
        )
        .unwrap();

        let db = CacheDB::new(alloy_db);
        let chain_id = self.provider.get_chain_id().await.unwrap();

        let mut evm = EvmBuilder::default()
            .with_db(db)
            .modify_env(|env| {
                env.tx.chain_id = Some(chain_id);
                env.cfg.chain_id = chain_id;
                env.cfg.disable_balance_check = true;
                env.cfg.disable_eip3607 = true;
                env.cfg.disable_block_gas_limit = true;
                env.block = pending_block_env.clone();
            })
            .build();

        if register {
            let tx_env = TxEnv {
                caller: tx.from,
                gas_limit: pending_block_env
                    .gas_limit
                    .uint_try_to()
                    .unwrap_or(u64::MAX),
                gas_price: pending_block_env.basefee,
                transact_to: TransactTo::Call(self.chall_addr),
                value: tx.value,
                data: hex::decode("0xccac0007").unwrap().into(),
                nonce: None,
                chain_id: Some(chain_id),
                access_list: vec![],
                gas_priority_fee: None,
                blob_hashes: vec![],
                max_fee_per_blob_gas: None,
                authorization_list: None,
            };

            evm.context.evm.env.tx = tx_env;
            match evm.transact_commit() {
                Ok(_) => {}
                Err(_) => return Default::default(),
            }
        }

        let tx_env = tx_to_tx_env(tx);
        evm.context.evm.env.tx = tx_env;

        match evm.transact() {
            Ok(r) => match r.result {
                ExecutionResult::Success { logs, .. } => logs,
                _ => Default::default(),
            },
            Err(_) => Default::default(),
        }
    }
}
