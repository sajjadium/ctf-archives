use alloy::rpc::types::Block;
use alloy::signers::Signer;
use alloy::{
    primitives::{Address, B256},
    providers::{Provider, ProviderBuilder, WsConnect},
    rpc::types::Transaction,
    signers::local::PrivateKeySigner,
};
use burberry::{
    collector::{BlockCollector, MempoolCollector},
    CollectorMap, Engine,
};
use clap::Parser;
use executor::SimpleExecutor;
use std::sync::Arc;
use tracing::{info, Level};
use tracing_subscriber::filter;
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;

pub mod executor;
pub mod strategy;
pub mod utils;

#[derive(Parser, Debug)]
struct Args {
    #[arg(long = "private-key", short = 'p')]
    pub sender_private_key: B256,

    #[arg(long = "entrypoint", short = 'e')]
    pub entrypoint: Address,

    #[arg(long = "rpc-url", short = 'r')]
    pub rpc_url: String,
}

#[derive(Debug, Clone)]
pub enum CollectorEvent {
    NewBlock(Block),
    PendingTx(Transaction),
}

#[tokio::main]
async fn main() -> eyre::Result<()> {
    let filter = filter::Targets::new()
        .with_target("claim_guard", Level::DEBUG)
        .with_target("burberry", Level::DEBUG);

    tracing_subscriber::registry()
        .with(tracing_subscriber::fmt::layer())
        .with(filter)
        .init();

    let args = Args::parse();

    let http_url = args
        .rpc_url
        .clone()
        .replace("ws://", "http://")
        .replace("/ws", "");

    info!("starting bot");

    let ws_provider = Arc::new(
        ProviderBuilder::new()
            .on_ws(WsConnect::new(args.rpc_url))
            .await?,
    );

    info!("connected to provider");

    let mut engine = Engine::default();

    engine.add_collector(Box::new(CollectorMap::new(
        Box::new(BlockCollector::new(ws_provider.clone())),
        CollectorEvent::NewBlock,
    )));

    engine.add_collector(Box::new(CollectorMap::new(
        Box::new(MempoolCollector::new(ws_provider.clone())),
        CollectorEvent::PendingTx,
    )));

    let chain_id = ws_provider.get_chain_id().await?;
    let signer = PrivateKeySigner::from_bytes(&args.sender_private_key)
        .expect("fail to parse private key")
        .with_chain_id(Some(chain_id));
    let sender_addr = signer.address();
    let executor = Box::new(SimpleExecutor::new(ws_provider.clone(), signer));
    engine.add_executor(executor);

    let strategy = Box::new(strategy::SimpleStrategy {
        http_url,
        provider: ws_provider.clone(),
        sender_addr,
        chall_addr: args.entrypoint,
        nonce_map: Default::default(),
    });

    engine.add_strategy(strategy);

    engine.run_and_join().await.unwrap();

    Ok(())
}
