import signal
import subprocess
import sys
import time

from ctf_server.types import UserData, get_privileged_web3, get_additional_account
from ctf_launchers.daemon import Daemon

def exit_handler(signal, frame):
    print("Terminating the process")
    exit(-1)

class BotDaemon(Daemon):
    def __init__(self):
        super().__init__(required_properties=["mnemonic", "challenge_address"])

    def _run(self, user_data: UserData):
        challenge_addr = user_data["metadata"]["challenge_address"]

        claim_guard = get_additional_account(user_data["metadata"]["mnemonic"], 0)
        web3 = get_privileged_web3(user_data, "main")

        anvil_instance = user_data["anvil_instances"]["main"]

        chall_inner_addr = web3.eth.call({ "to": challenge_addr,  "data": "0x2b8786a7" })[-20:].hex()   # chall()

        signal.signal(signal.SIGINT, exit_handler)
        signal.signal(signal.SIGTERM, exit_handler)

        proc = subprocess.Popen(
            args=[
                "/home/user/claim-guard",
                "--rpc-url",
                f"ws://{anvil_instance['ip']}:{anvil_instance['port']}",
                "--private-key",
                claim_guard.key.hex(),
                "--entrypoint",
                chall_inner_addr,
            ],
            text=True,
            encoding="utf8",
            stdout=sys.stdout,
            stderr=sys.stderr,
        )

        pass # allow signal handlers to catch signals
        proc.wait()

        if proc.poll() is not None:
            print("bot terminated")

signal.signal(signal.SIGINT, exit_handler)
signal.signal(signal.SIGTERM, exit_handler)
BotDaemon().start()