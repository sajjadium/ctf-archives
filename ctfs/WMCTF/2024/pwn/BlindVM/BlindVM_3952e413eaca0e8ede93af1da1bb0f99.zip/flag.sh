#!/bin/bash

echo $1 > /home/ctf/flag
