import socket
import tensorflow as tf
import numpy as np


model = tf.keras.models.load_model('model.h5')

def predict(input_data):
    processed_data = np.array(input_data).reshape(1, 20, 1) 
    prediction = model.predict(processed_data)

    if prediction[0][0] > 0.99 and np.mean(input_data) > 0.5:
        return "FLAG{}"
    
    return f"模型预测输出: {prediction[0][0]}"

def start_server(host='0.0.0.0', port=12345):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind((host, port))
    server_socket.listen(1)
    print(f"服务器正在 {host}:{port} 等待连接...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"连接来自: {addr}")
        client_socket.sendall(b"welcome\n")

        while True:
            data = client_socket.recv(1024)
            if not data:
                break

            # 处理输入数据
            input_values = list(map(float, data.decode('utf-8').strip().split()))
            if len(input_values) != 20:
                client_socket.sendall("wong\n")
                continue

            response = predict(input_values)
            client_socket.sendall(response.encode('utf-8') + b'\n')

        client_socket.close()

if __name__ == "__main__":
    start_server()
