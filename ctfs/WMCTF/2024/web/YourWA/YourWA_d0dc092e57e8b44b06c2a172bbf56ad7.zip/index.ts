// ! part of index.ts

import { $ } from "bun"


await import('node:fs').then(async fs => {
    await $`echo $FLAG > ./flag.txt`.quiet()
    fs.openSync('./flag.txt', 'r')
    await $`rm ./flag.txt`.quiet()
})

const server = Bun.serve({
    port: 3031,
    async fetch(req) {
        // ... Collapsed
        return Res.NotFound()
    },
    error(e) {
        console.error(e)
        return Res.NotFound()
    },
})