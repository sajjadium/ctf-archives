package constants

import (
	"wmctf2024/jvm-go/instructions/base"
	"wmctf2024/jvm-go/rtda"
)

// Do nothing
type NOP struct{ base.NoOperandsInstruction }

func (instr *NOP) Execute(frame *rtda.Frame) {
	// really do nothing
}
