package heap

import (
	"wmctf2024/jvm-go/vmutils"
)

// java.lang.String -> go string
func (obj *Object) JStrToGoStr() string {
	charArr := obj.GetFieldValue("value", "[C").Ref
	return vmutils.UTF16ToUTF8(charArr.GetChars())
}
