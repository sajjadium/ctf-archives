package io

import (
	"io"
	"os"
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_fis(available, "available0", "()I")
	_fis(close0, "close0", "()V")
	_fis(readBytes, "readBytes", "([BII)I")
	_fis(open0, "open0", "(Ljava/lang/String;)V")
}

func _fis(method native.Method, name, desc string) {
	native.Register("java/io/FileInputStream", name, desc, method)
}

// public native int available() throws IOException;
// ()I
func available(frame *rtda.Frame) {
	this := frame.GetThis()
	info, err := this.Extra.(*os.File).Stat()
	if err != nil {
		frame.Thread.ThrowIOException(err.Error())
	} else {
		frame.PushInt(int32(info.Size()))
	}
}

// private native void close0() throws IOException;
// ()V
func close0(frame *rtda.Frame) {
	this := frame.GetThis()

	if this.Extra != nil {
		this.Extra = nil
	} else {
		frame.Thread.ThrowIOException("file closed")
	}
}

// private native void open0(String name) throws FileNotFoundException;
// (Ljava/lang/String;)V
func open0(frame *rtda.Frame) {
	this := frame.GetThis()
	name := frame.GetRefVar(1)

	goName := name.JStrToGoStr()
	goFile, err := os.Open(goName)
	if err != nil {
		frame.Thread.ThrowFileNotFoundException(err.Error())
	} else {
		this.Extra = goFile
	}
}

// private native int readBytes(byte b[], int off, int len) throws IOException;
// ([BII)I
func readBytes(frame *rtda.Frame) {
	this := frame.GetThis()
	buf := frame.GetRefVar(1)
	off := frame.GetIntVar(2)
	_len := frame.GetIntVar(3)

	goFile := this.Extra.(*os.File)
	goBuf := buf.GetGoBytes()
	goBuf = goBuf[off : off+_len]

	// func (f *File) Read(b []byte) (n int, err error)
	n, err := goFile.Read(goBuf)
	if err == nil || n > 0 || err == io.EOF {
		frame.PushInt(int32(n))
	} else {
		frame.Thread.ThrowIOException(err.Error())
	}
}
