package lang

import (
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_string(intern, "intern", "()Ljava/lang/String;")
}

func _string(method native.Method, name, desc string) {
	native.Register("java/lang/String", name, desc, method)
}

// public native String intern();
// ()Ljava/lang/String;
func intern(frame *rtda.Frame) {
	jStr := frame.GetThis()

	goStr := jStr.JStrToGoStr()
	internedStr := frame.GetRuntime().JSIntern(goStr, jStr)

	frame.PushRef(internedStr)
}
