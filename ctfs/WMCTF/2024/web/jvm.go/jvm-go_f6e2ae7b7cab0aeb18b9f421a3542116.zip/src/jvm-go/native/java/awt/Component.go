package awt

import (
	"wmctf2024/jvm-go/native"
)

func init() {
}

func _comp(method native.Method, name, desc string) {
	native.Register("java/awt/Component", name, desc, method)
}
