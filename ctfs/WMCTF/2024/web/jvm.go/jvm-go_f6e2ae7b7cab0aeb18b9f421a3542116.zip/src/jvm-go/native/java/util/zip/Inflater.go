package zip

import (
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_inflater(inflater_initIDs, "initIDs", "()V")
}

func _inflater(method native.Method, name, desc string) {
	native.Register("java/util/zip/Inflater", name, desc, method)
}

// private static native void initIDs();
// ()V
func inflater_initIDs(frame *rtda.Frame) {
	// todo
}
