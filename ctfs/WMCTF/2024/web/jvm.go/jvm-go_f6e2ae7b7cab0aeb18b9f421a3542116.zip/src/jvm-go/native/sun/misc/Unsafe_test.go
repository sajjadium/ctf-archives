package misc

import "testing"

func TestUnsafeMem(t *testing.T) {
	// TODO
}
