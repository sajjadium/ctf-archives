package references

import (
	"wmctf2024/jvm-go/instructions/base"
	"wmctf2024/jvm-go/rtda"
)

// ArrayLength Get length of array
type ArrayLength struct{ base.NoOperandsInstruction }

func (instr *ArrayLength) Execute(frame *rtda.Frame) {
	arrRef := frame.PopRef()

	if arrRef == nil {
		frame.Thread.ThrowNPE()
		return
	}

	arrLen := arrRef.ArrayLength()
	frame.PushInt(arrLen)
}
