package references

import (
	"wmctf2024/jvm-go/instructions/base"
	"wmctf2024/jvm-go/rtda"
	"wmctf2024/jvm-go/rtda/heap"
)

// GetField Fetch field from object
type GetField struct {
	base.Index16Instruction
	field *heap.Field
}

func (instr *GetField) Execute(frame *rtda.Frame) {
	if instr.field == nil {
		cp := frame.GetConstantPool()
		kFieldRef := cp.GetConstantFieldRef(instr.Index)
		instr.field = kFieldRef.GetField(false)
	}

	ref := frame.PopRef()
	if ref == nil {
		frame.Thread.ThrowNPE()
		return
	}

	val := instr.field.GetValue(ref)
	frame.PushL(val, instr.field.IsLongOrDouble)
}
