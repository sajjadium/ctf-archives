package heap

import (
	"wmctf2024/jvm-go/classfile"
)

type ConstantMethodType struct {
	// todo
}

func newConstantMethodType(mtInfo classfile.ConstantMethodTypeInfo) *ConstantMethodType {
	return &ConstantMethodType{
		// todo
	}
}
