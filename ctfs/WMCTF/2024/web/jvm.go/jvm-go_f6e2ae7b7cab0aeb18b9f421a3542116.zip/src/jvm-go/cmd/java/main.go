package main

import (
	"flag"
	"fmt"
	"os"
	"runtime/pprof"
	"strings"

	"wmctf2024/jvm-go/classpath"
	"wmctf2024/jvm-go/cpu"
	_ "wmctf2024/jvm-go/native/all"
	"wmctf2024/jvm-go/rtda"
	"wmctf2024/jvm-go/rtda/heap"
	"wmctf2024/jvm-go/vm"
	"wmctf2024/jvm-go/vmutils"
)

const usage = `
Usage: {java} [options] class [args...]
`

var (
	versionFlag bool
	helpFlag    bool
)

func main() {
	opts, args := parseOptions()
	if helpFlag {
		printUsage()
	} else if versionFlag {
		printVersion()
	} else {
		startJVM8(opts, args)
	}
}

func parseOptions() (*vm.Options, []string) {
	options := &vm.Options{}
	flag.BoolVar(&versionFlag, "version", false, "Displays version information and exit.")
	flag.BoolVar(&helpFlag, "help", false, "Displays usage information and exit.")
	flag.BoolVar(&helpFlag, "h", false, "Displays usage information and exit.")
	flag.BoolVar(&helpFlag, "?", false, "Displays usage information and exit.")
	flag.StringVar(&options.ClassPath, "classpath", "", "Specifies a list of directories, JAR files, and ZIP archives to search for class files.")
	flag.StringVar(&options.ClassPath, "cp", "", "Specifies a list of directories, JAR files, and ZIP archives to search for class files.")
	flag.BoolVar(&options.VerboseClass, "verbose:class", false, "Displays information about each class loaded.")
	flag.BoolVar(&options.VerboseJNI, "verbose:jni", false, "Displays information about the use of native methods and other Java Native Interface (JNI) activity.")
	flag.StringVar(&options.Xss, "Xss", "", "Sets the thread stack size.")
	flag.StringVar(&options.Xjre, "Xjre", "", "Specifies JRE path.")
	flag.BoolVar(&options.XUseJavaHome, "XuseJavaHome", false, "Uses JAVA_HOME to find JRE path.")
	flag.BoolVar(&options.XDebugInstr, "Xdebug:instr", false, "Displays executed instructions.")
	flag.StringVar(&options.XCPUProfile, "Xprofile:cpu", "", "")
	flag.Parse()

	args := flag.Args()
	options.Init()

	if len(args) > 0 {
		options.MainClass = args[0]
		args = args[1:]
	}

	return options, args
}

func printUsage() {
	fmt.Println(strings.ReplaceAll(strings.TrimSpace(usage), "{java}", os.Args[0]))
	flag.PrintDefaults()
}

func printVersion() {
	fmt.Println("jvm.go 0.1.8.0")
}

func startJVM8(opts *vm.Options, args []string) {
	if opts.XCPUProfile != "" {
		f, err := os.Create(opts.XCPUProfile)
		if err != nil {
			panic(err)
		}
		_ = pprof.StartCPUProfile(f)
		defer pprof.StopCPUProfile()
	}

	mainThread := createMainThread(opts, args)
	cpu.Loop(mainThread)
	cpu.KeepAlive()
}

func createMainThread(opts *vm.Options, args []string) *rtda.Thread {
	cp := classpath.Parse(opts)
	rt := heap.NewRuntime(cp, opts.VerboseClass)

	mainClass := vmutils.DotToSlash(opts.MainClass)
	bootArgs := []heap.Slot{heap.NewHackSlot(mainClass), heap.NewHackSlot(args)}
	mainThread := rtda.NewThread(nil, opts, rt)
	mainThread.InvokeMethodWithShim(rtda.ShimBootstrapMethod, bootArgs)
	return mainThread
}
