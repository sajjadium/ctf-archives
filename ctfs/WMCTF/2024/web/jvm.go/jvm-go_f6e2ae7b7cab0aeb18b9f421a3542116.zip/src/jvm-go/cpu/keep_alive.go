package cpu

import (
	"sync"
)

var (
	mu sync.Mutex
	wg sync.WaitGroup
)

func nonDaemonThreadStart() {
	mu.Lock()
	defer mu.Unlock()

	wg.Add(1)
}

func nonDaemonThreadStop() {
	mu.Lock()
	defer mu.Unlock()

	wg.Done()
}

func KeepAlive() {
	mu.Lock()
	defer mu.Unlock()

	wg.Wait()
}
