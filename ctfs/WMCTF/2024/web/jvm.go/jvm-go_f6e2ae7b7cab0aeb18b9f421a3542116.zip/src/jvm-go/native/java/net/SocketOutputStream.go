package io

import (
	"net"
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_sos(sos_init, "init", "()V")
	_sos(sos_socketWrite0, "socketWrite0", "(Ljava/io/FileDescriptor;[BII)V")
}

func _sos(method native.Method, name, desc string) {
	native.Register("java/net/SocketOutputStream", name, desc, method)
}

// native java/net/SocketOutputStream~init~()V
func sos_init(frame *rtda.Frame) {
}

//	private native void socketWrite0(FileDescriptor fd, byte[] b, int off,
//	                                 int len) throws IOException;
//
// java/net/SocketOutputStream~socketWrite0~(Ljava/io/FileDescriptor;
func sos_socketWrite0(frame *rtda.Frame) {
	// this := frame.GetThis()
	fd := frame.GetRefVar(1)
	buf := frame.GetRefVar(2)
	off := frame.GetIntVar(3)
	_len := frame.GetIntVar(4)
	if fd.Extra != nil {
		bufArray := buf.GetGoBytes()
		bufArray = bufArray[off : off+_len]

		_, err := fd.Extra.(net.Conn).Write(bufArray)
		if err != nil {
			frame.Thread.ThrowIOException(err.Error())
		}
	} else {
		frame.Thread.ThrowIOException("socket closed")
	}
}
