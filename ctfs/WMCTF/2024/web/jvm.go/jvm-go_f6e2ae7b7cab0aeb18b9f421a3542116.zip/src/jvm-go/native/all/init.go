package all

import (
	_ "wmctf2024/jvm-go/native/java/awt"
	_ "wmctf2024/jvm-go/native/java/io"
	_ "wmctf2024/jvm-go/native/java/lang"
	_ "wmctf2024/jvm-go/native/java/lang/invoke"
	_ "wmctf2024/jvm-go/native/java/lang/reflect"
	_ "wmctf2024/jvm-go/native/java/net"
	_ "wmctf2024/jvm-go/native/java/security"
	_ "wmctf2024/jvm-go/native/java/util"
	_ "wmctf2024/jvm-go/native/java/util/concurrent/atomic"
	_ "wmctf2024/jvm-go/native/java/util/jar"
	_ "wmctf2024/jvm-go/native/java/util/zip"
	_ "wmctf2024/jvm-go/native/sun/awt"
	_ "wmctf2024/jvm-go/native/sun/io"
	_ "wmctf2024/jvm-go/native/sun/java2d/opengl"
	_ "wmctf2024/jvm-go/native/sun/management"
	_ "wmctf2024/jvm-go/native/sun/misc"
	_ "wmctf2024/jvm-go/native/sun/nio/ch"
	_ "wmctf2024/jvm-go/native/sun/reflect"
)
