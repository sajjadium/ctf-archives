package io

import (
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_fd(set, "set", "(I)J")
}

func _fd(method native.Method, name, desc string) {
	native.Register("java/io/FileDescriptor", name, desc, method)
}

func set(frame *rtda.Frame) {
	frame.PushLong(0)
}
