package io

import (
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_osc(initNative, "initNative", "()V")
}

func _osc(method native.Method, name, desc string) {
	native.Register("java/io/ObjectStreamClass", name, desc, method)
}

// private static native void initNative();
// ()V
func initNative(frame *rtda.Frame) {
	// todo
}
