package io

import (
	"wmctf2024/jvm-go/native"
	"wmctf2024/jvm-go/rtda"
)

func init() {
	_ia(ia_init, "init", "()V")
}

func _ia(method native.Method, name, desc string) {
	native.Register("java/net/InetAddress", name, desc, method)
}

func ia_init(frame *rtda.Frame) {

}
