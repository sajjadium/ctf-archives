import '../stylesheets/code-view.scss';
import './components/event.mjs';