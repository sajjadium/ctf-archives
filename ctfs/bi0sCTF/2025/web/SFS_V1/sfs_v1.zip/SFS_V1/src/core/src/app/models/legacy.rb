class Legacy < ApplicationRecord
end
