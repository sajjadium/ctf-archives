from Crypto.Cipher import DES, AES
from passlib.crypto import des
from flask import Flask, jsonify, request, render_template, redirect, session, flash
import os
from functools import wraps
import sqlite3

app = Flask(__name__,static_folder='./templates')
app.secret_key = os.urandom(24)


def password_hash(pw):
    s = bytes((75, 71, 83, 33, 64, 35, 36, 37))
    MAX_LEN = 23
    if len(pw) > MAX_LEN:
        return 0
    pw = bytes(pw.upper().ljust(MAX_LEN, '\x00'),'utf-8')
    pw_1,pw_2 = pw[:7],pw[7:]
    h1 = DES.new(des.expand_des_key(pw_1), DES.MODE_ECB).encrypt(s).hex()
    h2 = AES.new(pw_2, AES.MODE_ECB).encrypt(s.ljust(len(pw_2),b'\x00')).hex()
    return (h1 + h2).upper()

def logged_in(f):
    @wraps(f)
    def decorated_func(*args, **kwargs):
        if session.get("user"):
            return f(*args, **kwargs)
        else:
            return redirect("/login")
    return decorated_func

@app.route('/login', methods = ['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        db = sqlite3.connect('./templates/users.db')
        cursor = db.cursor()
        pw_hash = cursor.execute("SELECT password FROM users WHERE username = ?",(username,)).fetchone()
        db.close()
        if pw_hash == None:
            return render_template('login.html',error='Authentication Error')
        if password_hash(request.form.get('password')) == pw_hash[0]:

            session['user']=username
            return redirect('/')
        else:
            return render_template('login.html',error='Authentication Error')
    else:
        return render_template('login.html',error='')

@app.route('/', methods = ['GET'])
@logged_in
def home():
    return render_template('home.html')


app.run(debug=False,host='0.0.0.0',port=5000)