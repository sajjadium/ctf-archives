#!/bin/sh
set -ex

while ! pg_isready; do
    echo "wait pg..."
    sleep 1
done

cd /var/www/fusionpbx && php /var/www/fusionpbx/core/upgrade/upgrade_schema.php

domain_name=example.com
domain_uuid=$(/usr/bin/php /var/www/fusionpbx/resources/uuid.php);
psql -c "insert into v_domains (domain_uuid, domain_name, domain_enabled) values('$domain_uuid', '$domain_name', 'true');"

cd /var/www/fusionpbx && /usr/bin/php /var/www/fusionpbx/core/upgrade/upgrade_domains.php

user_uuid=$(/usr/bin/php /var/www/fusionpbx/resources/uuid.php);
user_salt=$(/usr/bin/php /var/www/fusionpbx/resources/uuid.php);
user_name=public
user_password=public
password_hash=$(/usr/bin/php -r "echo md5('$user_salt$user_password');");

psql -t -c "insert into v_users (user_uuid, domain_uuid, username, password, salt, user_enabled) values('$user_uuid', '$domain_uuid', '$user_name', '$password_hash', '$user_salt', 'true');"

group_name=public
group_uuid=$(psql -qtAX -c "select group_uuid from v_groups where group_name = '$group_name';");
user_group_uuid=$(/usr/bin/php /var/www/fusionpbx/resources/uuid.php);
psql -c "insert into v_user_groups (user_group_uuid, domain_uuid, group_name, group_uuid, user_uuid) values('$user_group_uuid', '$domain_uuid', '$group_name', '$group_uuid', '$user_uuid');"

cd /var/www/fusionpbx && /usr/bin/php /var/www/fusionpbx/core/upgrade/upgrade.php

exec supervisord
