#! /bin/sh
#
# run.sh
#

set -eu

exec ./qemu-system-riscv64 \
  -m 1G -smp 2 -nographic \
  -machine virt,rom=bootrom.bin \
  -bios fw_jump.elf \
  -kernel Image \
  -initrd rootfs.cpio \
  -device virtio-rng-pci \
  -monitor none \
  -chardev stdio,id=char0,signal=off \
  -serial chardev:char0 \
  -append "console=ttyS0 quiet loglevel=3 init=/init"
