#! /bin/sh
#
# entrypoint.sh
#

set -eu

PORT="${PORT:-4444}"

echo "[*] listen on :${PORT}, TIMEOUT_SECS=${TIMEOUT_SECS:-120}"

exec socat -T 300 \
  TCP-LISTEN:${PORT},reuseaddr,fork \
  EXEC:"./qemu_wrap.sh",pty,stderr,setsid,sane,raw,echo=0
