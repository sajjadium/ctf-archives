#! /bin/sh
#
# qemu_wrap.sh
#

set -eu

TIMEOUT_SECS="${TIMEOUT_SECS:-120}"

exec timeout --signal=KILL "${TIMEOUT_SECS}" ./run.sh

