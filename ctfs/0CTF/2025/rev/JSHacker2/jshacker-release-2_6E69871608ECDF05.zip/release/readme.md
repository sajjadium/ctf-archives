
run with:
```
cd chall
./d8 --enable-inspector --no-wasm-tier-up obfuscated.js
```
