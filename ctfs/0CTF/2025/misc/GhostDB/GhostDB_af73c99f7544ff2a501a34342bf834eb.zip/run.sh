#!/bin/sh

ulimit -s 16384
./chall