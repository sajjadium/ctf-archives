#pragma once

#include <cstddef>
#include <cstdint>

// Read `len` bytes from Linux /dev/urandom into `dst`.
void urandom_read(void* dst, size_t len);

// Uniform random 64-bit value.
uint64_t urandom_u64();

// Uniform random value in [0, modulus) (unbiased via rejection sampling).
uint64_t urandom_uniform_u64(uint64_t modulus);

// Sample from Normal(0, stdev) using /dev/urandom as entropy source.
double urandom_normal(double stdev);

