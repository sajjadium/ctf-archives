#include "urandom.h"

#include <cerrno>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fcntl.h>
#include <unistd.h>

namespace {

[[noreturn]] void urandom_die() { std::abort(); }

int urandom_fd() {
    static int fd = -1;
    if (fd != -1) return fd;
    fd = ::open("/dev/urandom", O_RDONLY | O_CLOEXEC);
    if (fd < 0) urandom_die();
    return fd;
}

double urandom_uniform_01() {
    // Use 53 random bits to fill IEEE-754 mantissa.
    uint64_t x = 0;
    // Inline a fast read to avoid recursion into urandom_read().
    int fd = urandom_fd();
    size_t len = sizeof(x);
    unsigned char* out = reinterpret_cast<unsigned char*>(&x);
    while (len > 0) {
        ssize_t n = ::read(fd, out, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            urandom_die();
        }
        if (n == 0) urandom_die();
        out += static_cast<size_t>(n);
        len -= static_cast<size_t>(n);
    }
    x >>= 11;
    return static_cast<double>(x) * (1.0 / 9007199254740992.0); // 2^53
}

} // namespace

void urandom_read(void* dst, size_t len) {
    auto* out = static_cast<unsigned char*>(dst);
    int fd = urandom_fd();
    while (len > 0) {
        ssize_t n = ::read(fd, out, len);
        if (n < 0) {
            if (errno == EINTR) continue;
            urandom_die();
        }
        if (n == 0) urandom_die();
        out += static_cast<size_t>(n);
        len -= static_cast<size_t>(n);
    }
}

uint64_t urandom_u64() {
    uint64_t v = 0;
    urandom_read(&v, sizeof(v));
    return v;
}

uint64_t urandom_uniform_u64(uint64_t modulus) {
    if (modulus == 0) urandom_die();
    const uint64_t limit = UINT64_MAX - (UINT64_MAX % modulus);
    while (true) {
        uint64_t x = urandom_u64();
        if (x < limit) return x % modulus;
    }
}

double urandom_normal(double stdev) {
    if (!(stdev > 0.0)) return 0.0;

    // Box-Muller transform.
    double u1 = 0.0;
    do {
        u1 = urandom_uniform_01();
    } while (u1 <= 0.0);
    const double u2 = urandom_uniform_01();

    const double r = std::sqrt(-2.0 * std::log(u1));
    const double theta = 6.283185307179586476925286766559 * u2; // 2*pi
    return (r * std::cos(theta)) * stdev;
}

