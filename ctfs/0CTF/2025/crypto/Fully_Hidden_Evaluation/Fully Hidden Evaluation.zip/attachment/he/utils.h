#pragma once

#include "types.h"

uint64_t get_log2(uint64_t num);
int64_t exgcd(int64_t a, int64_t b, int64_t &x, int64_t &y);
int64_t mod_inverse(int64_t a, int64_t modulus);
uint64_t sample_gauss(float st_dev, uint64_t modulus);
void sample_gauss(vector<uint64_t>& err, float st_dev, uint64_t modulus);
void sample_random(uint64_t* a, uint64_t modulus, int32_t size);
