#pragma once
#include <iostream>
#include <vector>
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <chrono>
#include "hexl/hexl.hpp"
#include "types.h"
using namespace std;

void bfv_encode(vector<uint64_t> pt, RlweCiphertext& ct, Secret sk, uint64_t mod_inv, float sig);
void bfv_decrypt(RlweCiphertext ct, vector<uint64_t>& pt, Secret sk, uint64_t pMod);

void lwe_encrypt(uint64_t pt, LweCiphertext& ct, Secret& sk, uint64_t pmod, float sig);

void ksk_setup(Secret& sk, vector<ApproximateKeySwitchKey>& ksk, float sig);
void apply_auto_coef_form(vector<uint64_t>& result, vector<uint64_t> input, int32_t idx, uint64_t modulus);
void keyswitch_keygen(vector<uint64_t> new_key, ApproximateKeySwitchKey& ksk, Secret& sk, float sig);
