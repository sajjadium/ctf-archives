#include "utils.h"
#include "urandom.h"


uint64_t get_log2(uint64_t num){
    uint64_t result = 0;
    while (num > 1){
        num >>= 1;
        ++result;
    }
    return result;
}

int64_t exgcd(int64_t a, int64_t b, int64_t &x, int64_t &y){
    if (b == 0){
        x = 1;
        y = 0;
        return a;
    }
    int64_t x1, y1;
    int64_t d = exgcd(b, a % b, x1, y1);
    x = y1;
    y = x1 - (a / b) * y1;
    return d;
}

int64_t mod_inverse(int64_t a, int64_t modulus){
    int64_t x, y;
    int64_t g = exgcd(a, modulus, x, y);
    if (g != 1){
        cout << "error: mod inverse error" << endl;
        return -1;
    } 
    else{
        return (x % modulus + modulus) % modulus;
    }
}

void sample_random(uint64_t* a, uint64_t modulus, int32_t size){
    for (size_t i = 0; i < size; i++){
        a[i] = urandom_uniform_u64(modulus);
    }
}


void sample_gauss(vector<uint64_t>& err, float st_dev, uint64_t modulus){
    uint64_t length = err.size();
    for(size_t i = 0; i < length; i++){
        err[i] = static_cast<int>(round(urandom_normal(st_dev)));
        if (err[i] != 1 && err[i] != 0){
            err[i] = modulus - 1;
        }
    }
}

uint64_t sample_gauss(float st_dev, uint64_t modulus){
    uint64_t err = static_cast<int>(round(urandom_normal(st_dev)));
    if (err != 1 && err != 0){
        err = modulus - 1;
    }
    return err;
}
