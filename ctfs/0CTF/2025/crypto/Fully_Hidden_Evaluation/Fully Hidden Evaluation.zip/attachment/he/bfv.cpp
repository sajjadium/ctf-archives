#include "bfv.h"
#include "utils.h"

void bfv_encode(vector<uint64_t> pt, RlweCiphertext& ct, Secret sk, uint64_t mod_inv, float sig){
    uint64_t modulus = sk.getModulus();
    uint64_t length = sk.getLength();

    sample_random(ct.a.data(), modulus, length);
    if (!sk.isNttForm()){
        sk.toNttForm();
    }

    intel::hexl::EltwiseMultMod(ct.b.data(), ct.a.data(), sk.getData().data(), length, modulus, 1);
    
    intel::hexl::NTT ntts = sk.getNTT();
    std::vector<uint64_t> err(length);
    sample_gauss(err, sig, modulus);

    intel::hexl::EltwiseFMAMod(pt.data(), pt.data(), mod_inv, nullptr, length, modulus, 1);
    intel::hexl::EltwiseFMAMod(err.data(), err.data(), mod_inv, nullptr, length, modulus, 1);

    ntts.ComputeInverse(ct.b.data(), ct.b.data(), 1, 1);
    intel::hexl::EltwiseAddMod(ct.b.data(), ct.b.data(), err.data(), length, modulus);
    intel::hexl::EltwiseAddMod(ct.b.data(), ct.b.data(), pt.data(), length, modulus);
    ntts.ComputeForward(ct.b.data(), ct.b.data(), 1, 1);
}


void bfv_decrypt(RlweCiphertext ct, vector<uint64_t>& pt, Secret sk, uint64_t pMod){
    uint64_t modulus = sk.getModulus();
    uint64_t length = sk.getLength();
    uint64_t delta = (uint64_t)floor((double)modulus / (double) pMod);

    if (!sk.isNttForm()){
        sk.toNttForm();
    }

    intel::hexl::EltwiseMultMod(pt.data(), ct.a.data(), sk.getData().data(), length, modulus, 1);
    intel::hexl::EltwiseSubMod(pt.data(), ct.b.data(), pt.data(), length, modulus);
    intel::hexl::NTT ntts = sk.getNTT();
    ntts.ComputeInverse(pt.data(), pt.data(), 1, 1);

    for (int i = 0; i < length; ++i){
        if (pt[i] > (modulus >> 1)){
            pt[i] = (uint64_t)round(((long double)pt[i] - modulus) / delta) % pMod;
        }
        else {
            pt[i] = (uint64_t)round((long double)pt[i] / delta) % pMod;
        }
    }
}

void lwe_encrypt(uint64_t pt, LweCiphertext& ct, Secret& sk, uint64_t pmod, float sig){
    if (sk.isNttForm()){
        sk.toCoeffForm();
    }
    uint64_t len = sk.getLength(), modulus = sk.getModulus();
    sample_random(ct.a.data(), modulus, len);
    uint64_t result = 0;
    for (uint64_t i = 0; i < len; ++i){
        if (sk.data[i] == 1){
            result = (result + ct.a[i]) % modulus;
        }
        else if (sk.data[i] == modulus - 1){
            result = (result - ct.a[i] + modulus) % modulus;
        }
    }

    uint64_t delta = (uint64_t)floor((double)modulus / pmod);
    uint64_t err = sample_gauss(sig, modulus);

    result += pt * delta;
    result += err;

    ct.b = (result % (int64_t)modulus + modulus) % modulus;
}

void keyswitch_keygen(vector<uint64_t> new_key, ApproximateKeySwitchKey& ksk, Secret& sk, float sig){
    uint64_t base = (1 << ksk.get_z());
    uint64_t length = sk.getLength(), modulus = sk.getModulus();
    intel::hexl::EltwiseFMAMod(new_key.data(), new_key.data(), (1 << ksk.get_b()), nullptr, length, modulus, 1);
    
    for (int i = 0; i < ksk.get_t(); ++i){
        bfv_encode(new_key, ksk.ksk[i], sk, 1, sig);
        intel::hexl::EltwiseFMAMod(new_key.data(), new_key.data(), base, nullptr, length, modulus, 1);
    }
}


void apply_auto_coef_form(vector<uint64_t>& result, vector<uint64_t> input, int32_t idx, uint64_t modulus){
    uint64_t length = input.size();
    for (size_t i = 0; i < length; i++){
        uint64_t destination = (i * idx) % (2 * length);
        if (destination >= length){
            result[destination - length] = (modulus - input[i]) % modulus;
        } 
        else {
            result[destination] = input[i];
        }
    }
}


void ksk_setup(Secret& sk, vector<ApproximateKeySwitchKey>& ksk, float sig){
    uint64_t modulus = sk.getModulus();
    uint64_t length = sk.getLength();
    uint64_t expo = get_log2(length);
    if (sk.isNttForm()){
        sk.toCoeffForm();
    }
    for (int i = 0; i < expo-1; ++i){
        vector<uint64_t> new_key(length, 0);
        copy(sk.data.begin(), sk.data.end(), new_key.begin());
        uint64_t tag = (1 << (expo - i)) + 1;
        apply_auto_coef_form(new_key, new_key, tag, modulus);
        keyswitch_keygen(new_key, ksk[i], sk, sig);
    }
}
