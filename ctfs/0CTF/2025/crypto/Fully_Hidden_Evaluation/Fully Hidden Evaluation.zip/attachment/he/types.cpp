#include "types.h"
#include <assert.h>
#include <cstdlib>
#include "urandom.h"

Secret::Secret(uint64_t len, uint64_t module, bool ntt, float sig): length(len), modulus(module), nttform(ntt){
    if (modulus == crtMod){
        intel::hexl::NTT ntts(length, modulus, root_of_unity_crt);
        this->ntts = ntts;
    } else {
        
    }

    for(size_t i = 0; i < length; i++){
        int64_t tmp = static_cast<int>(round(urandom_normal(sig)));
        if (tmp != 1 && tmp != 0){
            tmp = modulus - 1;
            tmp = 1;
        }
        this->data.push_back(tmp); 
    }

    if (ntt){
        this->ntts.ComputeForward(data.data(), data.data(), 1, 1);
    }
}

uint64_t Secret::getModulus(){
    return this->modulus;
}

int32_t Secret::getLength(){
    return this->length;
}

vector<uint64_t> Secret::getData(){
    return this->data;
}

bool Secret::isNttForm(){
    return this->nttform;
}

intel::hexl::NTT& Secret::getNTT(){
    return ntts;
}

void Secret::toCoeffForm(){
    ntts.ComputeInverse(data.data(), data.data(), 1, 1);
    this->nttform = false;
}

void Secret::toNttForm(){
    ntts.ComputeForward(data.data(), data.data(), 1, 1);
    this->nttform = true;
}

Secret::~Secret(){}


LweCiphertext::LweCiphertext(){}

LweCiphertext::LweCiphertext(int32_t len, uint64_t module) : length(len), modulus(module) {
    this->a.resize(len);
}

vector<uint64_t> LweCiphertext::getA(){
    return a;
}

uint64_t LweCiphertext::getModulus(){
    return modulus;
}

int32_t LweCiphertext::getLength(){
    return length;
}

LweCiphertext::~LweCiphertext(){}


RlweCiphertext::RlweCiphertext(/* args */){
    this->a.resize(length);
    this->b.resize(length);
}

RlweCiphertext::RlweCiphertext(uint64_t len, uint64_t module) : length(len), modulus(module) 
{
    this->a.resize(len, 0);
    this->b.resize(len, 0);
}

RlweCiphertext::RlweCiphertext(std::vector<uint64_t>& a, std::vector<uint64_t>& b, bool isn): isntt(isn)
{
    uint64_t length = this->a.size();
    assert(length == a.size());
    assert(length == b.size());

    copy(a.begin(), a.end(), this->a.begin());
    copy(b.begin(), b.end(), this->b.begin());
}

uint64_t RlweCiphertext::getModulus() const
{
    return this->modulus;
}

void RlweCiphertext::setModulus(uint64_t module)
{
    this->modulus = module;
}

int32_t RlweCiphertext::getLength() const
{
    return this->length;
}

bool RlweCiphertext::getIsNtt() const
{
    return this->isntt;
}

void RlweCiphertext::setIsNtt(bool is)
{
    this->isntt = is;
}

Secret sample_binary_secret(uint64_t len, uint64_t modulus, bool ntt) {
    Secret sk(len, modulus, false, /*sig*/ 1.0f);
    for (uint64_t i = 0; i < len; ++i) {
        sk.data[i] = urandom_uniform_u64(2);
    }
    if (ntt) {
        if (modulus != crtMod) {
            std::cerr << "error: NTT only initialized for crtMod in this codebase" << std::endl;
            std::abort();
        }
        sk.toNttForm();
    }
    return sk;
}

Secret sample_ternary_secret(uint64_t len, uint64_t modulus, bool ntt) {
    Secret sk(len, modulus, false, /*sig*/ 1.0f);
    for (uint64_t i = 0; i < len; ++i) {
        uint64_t r = urandom_uniform_u64(4);
        if (r == 0 || r == 3) {
            sk.data[i] = 0;
        } else if (r == 1) {
            sk.data[i] = 1;
        } else {
            sk.data[i] = modulus - 1;
        }
    }
    if (ntt) {
        if (modulus != crtMod) {
            std::cerr << "error: NTT only initialized for crtMod in this codebase" << std::endl;
            std::abort();
        }
        sk.toNttForm();
    }
    return sk;
}
