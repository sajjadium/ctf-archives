#pragma once
#include <iostream>
#include <vector>
#include <stdint.h>
#include <stddef.h>
#include "hexl/hexl.hpp"
#include <chrono>
#include <assert.h>
#include <random>
using namespace std;

#define crtq1 268369921 // 2^28 - 2^16 + 1
#define crtq2 249561089UL // 266334209; // 2^28 - 2^21 - 2^12 + 1
#define crtMod (crtq1 * crtq2)
 constexpr uint64_t root_of_unity_crt = 3375402822066082UL;
//constexpr uint64_t root_of_unity_crt = 38878761190133527UL;
constexpr uint64_t cr1_p = 68736257792UL;
constexpr uint64_t cr1_b = 73916747789UL;

class Secret{
private:
    uint64_t length;
    uint64_t modulus;
    bool nttform;
    intel::hexl::NTT ntts;

public:
    vector<uint64_t> data;

    Secret(uint64_t len, uint64_t module, bool ntt, float sig);
    vector<uint64_t> getData();
    uint64_t getModulus();
    int32_t getLength();
    bool isNttForm();
    intel::hexl::NTT& getNTT();
    void toCoeffForm();
    void toNttForm();
    ~Secret();
};

class LweCiphertext{
public:
    int32_t length;
    uint64_t modulus;
    vector<uint64_t> a;
    uint64_t b;

public:
    LweCiphertext();
    LweCiphertext(int32_t len, uint64_t module);
    vector<uint64_t> getA();
    uint64_t getModulus();
    int32_t getLength();
    ~LweCiphertext();
};


class RlweCiphertext{
public:
    uint64_t length = 4096;
    uint64_t modulus = crtMod;
    bool isntt = false;

public:
    vector<uint64_t> a;
    vector<uint64_t> b;

    RlweCiphertext(/* args */);

    RlweCiphertext(uint64_t len, uint64_t module); 

    RlweCiphertext(std::vector<uint64_t>& a, std::vector<uint64_t>& b, bool isn = false);

    uint64_t getModulus() const;

    void setModulus(uint64_t module);

    int32_t getLength() const;

    bool getIsNtt() const;

    void setIsNtt(bool is);
    
};


class ApproximateKeySwitchKey{
private:
    uint64_t degree;
    uint64_t modulus;
    uint64_t b, z, t;
    bool isntt = false;
public:
    vector<RlweCiphertext> ksk;

    ApproximateKeySwitchKey() { }

    ApproximateKeySwitchKey(uint64_t len, uint64_t modulus, uint64_t b, uint64_t z, uint64_t t){
        this->degree = len;
        this->modulus = modulus;
        this->b = b, this->z = z, this->t = t;
        this->ksk.resize(this->t);
        this->isntt = false;
    }

    uint64_t get_degree() const {
        return this->degree;
    }

    uint64_t get_modulus() const {
        return this->modulus;
    }

    uint64_t get_b() const {
        return this->b;
    }

    uint64_t get_z() const {
        return this->z;
    }

    uint64_t get_t() const {
        return this->t;
    }

    bool get_isntt() const {
        return this->isntt;
    }
};

Secret sample_binary_secret(uint64_t len, uint64_t modulus, bool ntt = false);
Secret sample_ternary_secret(uint64_t len, uint64_t modulus, bool ntt = false);

