FLAG = b"0ctf{test_flag}"
