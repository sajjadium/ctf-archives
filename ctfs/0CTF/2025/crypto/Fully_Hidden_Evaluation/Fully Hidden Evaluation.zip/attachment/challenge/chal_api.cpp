#include "chal_api.h"

#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include <utility>
#include <vector>

#include "he/types.h"
#include "he/utils.h"
#include "keyword/boot.h"
#include "keyword/utils.h"

namespace {

constexpr uint64_t kRlweDegree = 4096;
constexpr uint64_t kLweDim = 256;
constexpr uint64_t kPmod = 32;

bool is_power_of_two(uint64_t x) { return x != 0 && ((x & (x - 1)) == 0); }

void append_u64_le(std::vector<uint8_t>& out, uint64_t v) {
    for (int i = 0; i < 8; ++i) out.push_back(static_cast<uint8_t>((v >> (8 * i)) & 0xff));
}

bool read_u64_le(const uint8_t*& p, const uint8_t* end, uint64_t* out) {
    if (end - p < 8) return false;
    uint64_t v = 0;
    for (int i = 0; i < 8; ++i) v |= (static_cast<uint64_t>(p[i]) << (8 * i));
    p += 8;
    *out = v;
    return true;
}

std::vector<uint8_t> serialize_lwe(const LweCiphertext& ct) {
    std::vector<uint8_t> out;
    out.reserve(16 + (static_cast<size_t>(ct.length) + 1) * 8);
    append_u64_le(out, static_cast<uint64_t>(ct.length));
    append_u64_le(out, ct.modulus);
    for (int32_t i = 0; i < ct.length; ++i) append_u64_le(out, ct.a[static_cast<size_t>(i)]);
    append_u64_le(out, ct.b);
    return out;
}

std::vector<uint8_t> serialize_rlwe(const RlweCiphertext& ct) {
    std::vector<uint8_t> out;
    const uint64_t len = static_cast<uint64_t>(ct.getLength());
    out.reserve(16 + static_cast<size_t>(len) * 16);
    append_u64_le(out, len);
    append_u64_le(out, ct.getModulus());
    for (uint64_t i = 0; i < len; ++i) append_u64_le(out, ct.a[static_cast<size_t>(i)]);
    for (uint64_t i = 0; i < len; ++i) append_u64_le(out, ct.b[static_cast<size_t>(i)]);
    return out;
}

std::vector<uint8_t> serialize_ksk(const ApproximateKeySwitchKey& ksk) {
    std::vector<uint8_t> out;
    append_u64_le(out, ksk.get_degree());
    append_u64_le(out, ksk.get_modulus());
    append_u64_le(out, ksk.get_b());
    append_u64_le(out, ksk.get_z());
    append_u64_le(out, ksk.get_t());
    for (uint64_t i = 0; i < ksk.get_t(); ++i) {
        std::vector<uint8_t> ct = serialize_rlwe(ksk.ksk[static_cast<size_t>(i)]);
        out.insert(out.end(), ct.begin(), ct.end());
    }
    return out;
}

std::vector<uint8_t> serialize_ksk_vec(const std::vector<ApproximateKeySwitchKey>& ksk_vec) {
    std::vector<uint8_t> out;
    append_u64_le(out, static_cast<uint64_t>(ksk_vec.size()));
    for (const auto& k : ksk_vec) {
        std::vector<uint8_t> blob = serialize_ksk(k);
        out.insert(out.end(), blob.begin(), blob.end());
    }
    return out;
}

bool parse_rlwe(const uint8_t* data, size_t len, RlweCiphertext* out_ct) {
    const uint8_t* p = data;
    const uint8_t* end = data + len;
    uint64_t n = 0, modulus = 0;
    if (!read_u64_le(p, end, &n)) return false;
    if (!read_u64_le(p, end, &modulus)) return false;
    if (n == 0) return false;
    const size_t needed = 16 + static_cast<size_t>(n) * 16;
    if (len != needed) return false;

    RlweCiphertext ct(n, modulus);
    for (uint64_t i = 0; i < n; ++i) {
        uint64_t v = 0;
        if (!read_u64_le(p, end, &v)) return false;
        ct.a[static_cast<size_t>(i)] = v;
    }
    for (uint64_t i = 0; i < n; ++i) {
        uint64_t v = 0;
        if (!read_u64_le(p, end, &v)) return false;
        ct.b[static_cast<size_t>(i)] = v;
    }
    if (p != end) return false;
    *out_ct = std::move(ct);
    return true;
}

bool parse_lwe(const uint8_t* data, size_t len, LweCiphertext* out_ct) {
    const uint8_t* p = data;
    const uint8_t* end = data + len;
    uint64_t n64 = 0, modulus = 0;
    if (!read_u64_le(p, end, &n64)) return false;
    if (!read_u64_le(p, end, &modulus)) return false;
    if (n64 == 0 || n64 > (1ULL << 20)) return false;
    const size_t n = static_cast<size_t>(n64);
    const size_t needed = 16 + (n + 1) * 8;
    if (len != needed) return false;

    LweCiphertext ct(static_cast<int32_t>(n64), modulus);
    for (size_t i = 0; i < n; ++i) {
        uint64_t v = 0;
        if (!read_u64_le(p, end, &v)) return false;
        ct.a[i] = v;
    }
    uint64_t b = 0;
    if (!read_u64_le(p, end, &b)) return false;
    ct.b = b;
    if (p != end) return false;
    *out_ct = std::move(ct);
    return true;
}

bool parse_ksk(const uint8_t*& p, const uint8_t* end, ApproximateKeySwitchKey* out) {
    uint64_t degree = 0, modulus = 0, b = 0, z = 0, t = 0;
    if (!read_u64_le(p, end, &degree)) return false;
    if (!read_u64_le(p, end, &modulus)) return false;
    if (!read_u64_le(p, end, &b)) return false;
    if (!read_u64_le(p, end, &z)) return false;
    if (!read_u64_le(p, end, &t)) return false;
    if (degree == 0 || t == 0) return false;

    ApproximateKeySwitchKey ksk(degree, modulus, b, z, t);
    for (uint64_t i = 0; i < t; ++i) {
        if (end - p < 16) return false;
        const uint8_t* p2 = p;
        uint64_t n = 0, mod2 = 0;
        if (!read_u64_le(p2, end, &n)) return false;
        if (!read_u64_le(p2, end, &mod2)) return false;
        const size_t rlwe_len = 16 + static_cast<size_t>(n) * 16;
        if (end - p < static_cast<ptrdiff_t>(rlwe_len)) return false;

        RlweCiphertext ct;
        if (!parse_rlwe(p, rlwe_len, &ct)) return false;
        if (ct.getModulus() != modulus) return false;
        if (static_cast<uint64_t>(ct.getLength()) != degree) return false;
        ksk.ksk[static_cast<size_t>(i)] = std::move(ct);
        p += rlwe_len;
    }
    *out = std::move(ksk);
    return true;
}

bool parse_ksk_vec(const uint8_t* data, size_t len, std::vector<ApproximateKeySwitchKey>* out) {
    const uint8_t* p = data;
    const uint8_t* end = data + len;
    uint64_t count = 0;
    if (!read_u64_le(p, end, &count)) return false;
    if (count == 0 || count > 64) return false;
    std::vector<ApproximateKeySwitchKey> keys;
    keys.reserve(static_cast<size_t>(count));
    for (uint64_t i = 0; i < count; ++i) {
        ApproximateKeySwitchKey k;
        if (!parse_ksk(p, end, &k)) return false;
        keys.push_back(std::move(k));
    }
    if (p != end) return false;
    *out = std::move(keys);
    return true;
}

bool parse_ksk_blob(const uint8_t* data, size_t len, ApproximateKeySwitchKey* out) {
    const uint8_t* p = data;
    const uint8_t* end = data + len;
    if (!parse_ksk(p, end, out)) return false;
    return p == end;
}

int alloc_blob(const std::vector<uint8_t>& blob, uint8_t** out, size_t* out_len) {
    if (!out || !out_len) return -1;
    *out = nullptr;
    *out_len = 0;
    if (blob.empty()) return -1;
    void* p = std::malloc(blob.size());
    if (!p) return -1;
    std::memcpy(p, blob.data(), blob.size());
    *out = static_cast<uint8_t*>(p);
    *out_len = blob.size();
    return 0;
}

} 

struct ChalContext {
    uint64_t pmod = kPmod;
    uint64_t rlwe_degree = kRlweDegree;
    uint64_t rlwe_qmod = crtMod;
    uint64_t lwe_dim = kLweDim;
    uint64_t lwe_qmod = 2 * kRlweDegree;

    float rlwe_sig = 0.35f;
    float lwe_sig = 31.37f;

    uint64_t b0 = 8, z0 = 8, t0 = 6;
    uint64_t b1 = 0, z1 = 8, t1 = 7;
    uint64_t b2 = 8, z2 = 8, t2 = 6;

    uint64_t m = 0;

    Secret lwe_sk;
    Secret rlwe_sk;
    intel::hexl::NTT ntts;

    std::vector<ApproximateKeySwitchKey> ksk;
    ApproximateKeySwitchKey relinkey;

    RlweCiphertext ct_lwe_sk;
    LweCiphertext ct_lwe;

    ChalContext()
        : lwe_sk(sample_binary_secret(lwe_dim, lwe_qmod, false)),
          rlwe_sk(sample_ternary_secret(rlwe_degree, rlwe_qmod, false)),
          ntts(rlwe_sk.getNTT()),
          ksk(get_log2(rlwe_degree), ApproximateKeySwitchKey(rlwe_degree, rlwe_qmod, b0, z0, t0)),
          relinkey(rlwe_degree, rlwe_qmod, b1, z1, t1),
          ct_lwe_sk(rlwe_degree, rlwe_qmod),
          ct_lwe(static_cast<int32_t>(lwe_dim), lwe_qmod) {
        sample_random(&m, pmod, 1);
        lwe_encrypt(m, ct_lwe, lwe_sk, pmod * 2, lwe_sig);

        ksk_setup(rlwe_sk, ksk, rlwe_sig);
        relin_keygen(relinkey, rlwe_sk, rlwe_sig);

        std::vector<uint64_t> pt(rlwe_degree, 0);
        uint64_t ptr = 0;
        const uint64_t coef_num = get_ceil_power_of_two(lwe_dim * t2);
        const uint64_t mod_inv = mod_inverse(coef_num, rlwe_qmod);
        for (uint64_t i = 0; i < lwe_dim; ++i) {
            for (uint64_t j = 0; j < t2; ++j) {
                pt[ptr] = get_pow_approximate(z2, b2, j) * lwe_sk.data[static_cast<size_t>(i)];
                ++ptr;
            }
        }
        intel::hexl::EltwiseFMAMod(pt.data(), pt.data(), mod_inv, nullptr, rlwe_degree, rlwe_qmod, 1);
        bfv_encode(pt, ct_lwe_sk, rlwe_sk, 1, rlwe_sig);
    }
};

int chal_create(ChalContext** out) {
    if (!out) return -1;
    *out = nullptr;
    if (!is_power_of_two(kPmod)) return -2;
    if ((kRlweDegree % kPmod) != 0) return -3;
    if ((kRlweDegree % (2 * kPmod)) != 0) return -4;
    try {
        *out = new ChalContext();
        return 0;
    } catch (...) {
        return -5;
    }
}

void chal_destroy(ChalContext* chal) { delete chal; }

void chal_free(void* p) { std::free(p); }

int chal_export_ct_lwe(ChalContext* chal, uint8_t** out, size_t* out_len) {
    if (!chal) return -1;
    return alloc_blob(serialize_lwe(chal->ct_lwe), out, out_len);
}

int chal_export_ct_lwe_sk(ChalContext* chal, uint8_t** out, size_t* out_len) {
    if (!chal) return -1;
    return alloc_blob(serialize_rlwe(chal->ct_lwe_sk), out, out_len);
}

int chal_export_ksk(ChalContext* chal, uint8_t** out, size_t* out_len) {
    if (!chal) return -1;
    return alloc_blob(serialize_ksk_vec(chal->ksk), out, out_len);
}

int chal_export_relinkey(ChalContext* chal, uint8_t** out, size_t* out_len) {
    if (!chal) return -1;
    return alloc_blob(serialize_ksk(chal->relinkey), out, out_len);
}

int chal_verify_submission(ChalContext* chal, const uint8_t* submission, size_t submission_len) {
    if (!chal || !submission) return 0;
    RlweCiphertext ct;
    if (!parse_rlwe(submission, submission_len, &ct)) return 0;
    if (static_cast<uint64_t>(ct.getLength()) != chal->rlwe_degree) return 0;
    if (ct.getModulus() != chal->rlwe_qmod) return 0;

    size_t zero_cnt = 0;
    uint64_t first_a = ct.a.empty() ? 0 : ct.a[0];
    uint64_t first_b = ct.b.empty() ? 0 : ct.b[0];
    bool all_a_same = true, all_b_same = true;

    for (uint64_t v : ct.a) {
        if (v == 0 && ++zero_cnt > 16) return 0;
        if (v != first_a) all_a_same = false;
    }
    for (uint64_t v : ct.b) {
        if (v == 0 && ++zero_cnt > 16) return 0;
        if (v != first_b) all_b_same = false;
    }

    if (all_a_same || all_b_same) return 0;

    std::vector<uint64_t> vec_dec(chal->rlwe_degree, 0);
    bfv_decrypt(ct, vec_dec, chal->rlwe_sk, chal->pmod);
    const uint64_t expected = g(chal->m, chal->pmod);
    return vec_dec[0] == expected ? 1 : 0;
}
