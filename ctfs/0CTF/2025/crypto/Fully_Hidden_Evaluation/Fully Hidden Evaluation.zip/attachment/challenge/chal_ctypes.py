import base64
import ctypes
from ctypes import c_int, c_size_t, c_uint64, c_void_p, POINTER, byref


class ChalLib:
    def __init__(self, lib_path: str):
        self.lib = ctypes.CDLL(lib_path)

        self.lib.chal_create.argtypes = [POINTER(c_void_p)]
        self.lib.chal_create.restype = c_int

        self.lib.chal_destroy.argtypes = [c_void_p]
        self.lib.chal_destroy.restype = None

        self.lib.chal_free.argtypes = [c_void_p]
        self.lib.chal_free.restype = None

        for name in [
            "chal_export_ct_lwe",
            "chal_export_ct_lwe_sk",
            "chal_export_ksk",
            "chal_export_relinkey",
        ]:
            fn = getattr(self.lib, name)
            fn.argtypes = [c_void_p, POINTER(ctypes.POINTER(ctypes.c_uint8)), POINTER(c_size_t)]
            fn.restype = c_int

        self.lib.chal_verify_submission.argtypes = [c_void_p, ctypes.c_void_p, c_size_t]
        self.lib.chal_verify_submission.restype = c_int


    def create_challenge(self) -> "Challenge":
        chal_ptr = c_void_p()
        rc = self.lib.chal_create(byref(chal_ptr))
        if rc != 0 or not chal_ptr.value:
            raise RuntimeError(f"chal_create failed: rc={rc}")
        return Challenge(self, chal_ptr)


class Challenge:
    def __init__(self, api: ChalLib, ptr: c_void_p):
        self.api = api
        self.ptr = ptr

    def close(self):
        if self.ptr and self.ptr.value:
            self.api.lib.chal_destroy(self.ptr)
            self.ptr = c_void_p()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass

    def _export_blob(self, fn_name: str) -> bytes:
        out_ptr = ctypes.POINTER(ctypes.c_uint8)()
        out_len = c_size_t()
        fn = getattr(self.api.lib, fn_name)
        rc = fn(self.ptr, byref(out_ptr), byref(out_len))
        if rc != 0:
            raise RuntimeError(f"{fn_name} failed: rc={rc}")
        try:
            return ctypes.string_at(out_ptr, out_len.value)
        finally:
            self.api.lib.chal_free(out_ptr)

    def export_public(self) -> dict:
        ct_lwe = self._export_blob("chal_export_ct_lwe")
        ct_lwe_sk = self._export_blob("chal_export_ct_lwe_sk")
        ksk = self._export_blob("chal_export_ksk")
        relinkey = self._export_blob("chal_export_relinkey")

        return {
            "ct_lwe_b64": base64.b64encode(ct_lwe).decode(),
            "ct_lwe_sk_b64": base64.b64encode(ct_lwe_sk).decode(),
            "ksk_b64": base64.b64encode(ksk).decode(),
            "relinkey_b64": base64.b64encode(relinkey).decode(),
        }

    def verify(self, submission: bytes) -> bool:
        buf = ctypes.create_string_buffer(submission)
        rc = self.api.lib.chal_verify_submission(self.ptr, ctypes.cast(buf, ctypes.c_void_p), len(submission))
        return rc == 1
