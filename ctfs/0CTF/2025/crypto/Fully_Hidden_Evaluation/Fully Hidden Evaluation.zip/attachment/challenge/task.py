#!/usr/bin/env python3
import base64
import json
import sys

from chal_ctypes import ChalLib
from secret import FLAG


def main() -> int:
    from pathlib import Path
    lib_path = str(Path(__file__).resolve().parent.parent / "build" / "libchal.so")
    api = ChalLib(lib_path)

    print("=== Fully Hidden Evaluation ===")
    print("Send back a base64-encoded RLWE ciphertext for each round.")
    sys.stdout.flush()

    for idx in range(16):
        chal = api.create_challenge()
        public = chal.export_public()
        print(f"[Round {idx+1}/16] Here is your public data:")
        print(json.dumps(public, sort_keys=True))
        sys.stdout.flush()

        line = sys.stdin.readline()
        if not line:
            return 1
        submission_b64 = line.strip()
        try:
            submission = base64.b64decode(submission_b64, validate=True)
        except Exception:
            print("wrong")
            sys.stdout.flush()
            return 0

        if not chal.verify(submission):
            print("wrong")
            sys.stdout.flush()
            return 0

    print(FLAG)
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
