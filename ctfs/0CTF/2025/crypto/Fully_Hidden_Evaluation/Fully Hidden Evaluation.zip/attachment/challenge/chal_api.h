#pragma once

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ChalContext ChalContext;

int chal_create(ChalContext** out);

void chal_destroy(ChalContext* chal);

void chal_free(void* p);

int chal_export_ct_lwe(ChalContext* chal, uint8_t** out, size_t* out_len);
int chal_export_ct_lwe_sk(ChalContext* chal, uint8_t** out, size_t* out_len);
int chal_export_ksk(ChalContext* chal, uint8_t** out, size_t* out_len);
int chal_export_relinkey(ChalContext* chal, uint8_t** out, size_t* out_len);

int chal_verify_submission(ChalContext* chal, const uint8_t* submission, size_t submission_len);

#ifdef __cplusplus
}
#endif
