#pragma once
#include "utils.h"

void relin_keygen(ApproximateKeySwitchKey& relinkey, Secret sk, float sig);

uint64_t mod_pow(uint64_t a, uint64_t b, uint64_t mod);
uint64_t g(uint64_t x, uint64_t p);
