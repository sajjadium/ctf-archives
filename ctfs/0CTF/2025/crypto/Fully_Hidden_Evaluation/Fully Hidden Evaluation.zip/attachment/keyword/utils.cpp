#include "utils.h"

uint64_t get_ceil_power_of_two(uint64_t num){
    uint64_t res = 0;
    while(num != 0){
        res++;
        num = num >> 1;
    }
    return (1ULL << res);
}

uint64_t get_pow_approximate(uint64_t z, uint64_t b, uint64_t times){
    uint64_t res = (1ULL << b);
    for (uint64_t i = 0; i < times; ++i){
        res = (res << z);
    }
    return res;
}
