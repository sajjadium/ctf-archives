#include "boot.h"

void relin_keygen(ApproximateKeySwitchKey& relinkey, Secret sk, float sig) {
    uint64_t modulus = sk.getModulus(), length = sk.getLength();

    vector<uint64_t> new_key(length, 0);
    if (!sk.isNttForm()) {
        sk.toNttForm();
    }
    intel::hexl::EltwiseMultMod(new_key.data(), sk.data.data(), sk.data.data(), length, modulus, 1);
    sk.getNTT().ComputeInverse(new_key.data(), new_key.data(), 1, 1);
    keyswitch_keygen(new_key, relinkey, sk, sig);
}


uint64_t mod_pow(uint64_t a, uint64_t b, uint64_t mod) {
    uint64_t r = 1 % mod;
    a %= mod;
    while (b) {
        if (b & 1) r = (uint64_t)((__int128)r * a % mod);
        a = (uint64_t)((__int128)a * a % mod);
        b >>= 1;
    }
    return r;
}

uint64_t g(uint64_t x, uint64_t p) {
    return (uint64_t)(
        x
        + 2 * mod_pow(x, 2,  p)
        + 2 * mod_pow(x, 3,  p)
        + 2 * mod_pow(x, 4,  p)
        + 2 * mod_pow(x, 5,  p)
        + 2 * mod_pow(x, 6,  p)
        + 2 * mod_pow(x, 7,  p)
        + 2 * mod_pow(x, 8,  p)
        + 2 * mod_pow(x, 9,  p)
        + 2 * mod_pow(x, 10, p)
        + 2 * mod_pow(x, 11, p)
        + 2 * mod_pow(x, 12, p)
        + 2 * mod_pow(x, 13, p)
        + 2 * mod_pow(x, 14, p)
        + 2 * mod_pow(x, 15, p)
    ) % p;
}
