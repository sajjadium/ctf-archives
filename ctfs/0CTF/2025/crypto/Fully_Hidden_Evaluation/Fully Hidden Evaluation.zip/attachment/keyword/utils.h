#pragma once
#include "he/bfv.h"
#include "he/utils.h"
#include <string.h>
#include <utility>
using namespace std;

uint64_t get_ceil_power_of_two(uint64_t num);
uint64_t get_pow_approximate(uint64_t z, uint64_t b, uint64_t times);

