flag="FAKEGTF{:boom:}"
