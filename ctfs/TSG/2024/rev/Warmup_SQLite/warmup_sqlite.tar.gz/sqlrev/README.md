# Warmup SQLite

`dump` is the result of `EXPLAIN <hidden SQL>` with the parameter `~~Your input is filled here~~`.

We use the same sqlite3 as SQLite of Hand, another pwn challenge in TSG CTF 5, to dump this code.
