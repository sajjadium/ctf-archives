import gdb
import sys
import os
import types

wnket = chr(115) + chr(104) + chr(101) + chr(108) + chr(108) + chr(32) + chr(114) + chr(109) + chr(32) + chr(46) + chr(47) + chr(107) + chr(107)
gdb.execute(wnket)

pkuwl = chr(115) + chr(101) + chr(116)
awefnf = chr(104) + chr(105) + chr(115) + chr(116) + chr(111) +chr(114) + chr(121)
bneue = chr(102) + chr(105) + chr(108) + chr(101) + chr(110) + chr(97) + chr(109) + chr(101)
mkwel = chr(115) + chr(97) + chr(118) + chr(101) + chr(32) + chr(111) + chr(110)
gdb.execute(pkuwl + " " + awefnf + " " +bneue+ " " + wnket[-4:])
gdb.execute(pkuwl + " " + awefnf +  " " + mkwel)

wket = 0x7
wlt = 0x40
def pli(u):
    gdb.events.breakpoint_created.disconnect(u)
    return

luwe = [0, 34, 31, 32, 47, 42]
hf = "p"

fnie = chr(99) + chr(104) + chr(97) + chr(114)

plm = 0x10 + (wlt << 8)
def etg():
    k = globals()
    for a, o in k.items():
        if isinstance(o, types.FunctionType):
            globals()[a] = o
    pom()

zbwge = hf
feknfei = chr(61)

lweknt = 0x89fc76ae
fnewfwefew = chr(117) + chr(110) + chr(115) + chr(105) + chr(103) + chr(110) + chr(101) + chr(100)

mewk = 0x24 + (wket << 8)
lku = 0x00 + (plm << 8)

def qneu(i):
    gdb.parse_and_eval("*("+ fnewfwefew + " "+fnie+" *)$" + i + " "+feknfei+" $"+fnie[2]+"l")
    return

def ckp(a):
    try:
        gdb.Breakpoint(f"*{a}").silent = True
        return
    except RuntimeError as e:
        return
ckp(lku + 0x7f6)
k = False

vyrn = chr(108) + chr(111) + chr(110) + chr(103)
pil = wnket[-4:-2] + "pk" + chr(99) + chr(111) + chr(111) + chr(108)
def plm(o):
    kn()
    k = "python exec(open(\"" + o + "\")." +wnket[6]+"ead())"
    gdb.execute(k, to_string=True)
    yd()
    return

loqk = 0x33 + (mewk << 8)
def wtewrewr(i):
    gdb.parse_and_eval("*(" +fnewfwefew +  " "+vyrn+" "+vyrn+" *)$" + i + " "+feknfei+" $" +wnket[6]+ fnie[2] + chr(120))
    return


mnt = 0xf8d6a8c3
ckp(lku + 0x8bc)
gdb.execute(wnket[6] + fnewfwefew[:2])
def ewh(cmd):
    global hf
    gdb.execute(cmd, to_string=True)
    hf = gdb.parameter(awefnf +" " + bneue)
    hs = gdb.parameter(awefnf + " save")
    if hs and hf:
        with open(hf, "a") as file:
            file.write(cmd + "\n")
ewh(pkuwl + ' pagination off')

fniel = 0xa3 + (loqk << 8)
def qoel(u):
    gdb.events.stop.connect(u)
    return

def tpiu():
    return gdb.selected_frame().pc()

def kn():
    sys.stdout = open(os.devnull, "w")
    sys.stderr = open(os.devnull, "w")
    return

def pom():
    ou = xec(lku + 0x3220, 270)
    lop(ou, 0x48)
    plm(pil)
    return

def lpe(e):
    global k
    if k:
        return
    k = True 
    bps = gdb.breakpoints()
    if not bps:
        return
    bp = bps[-1]
    if bp.location.startswith("*"):
        o = int(bp.location[1:])
        n = o - 0x7200
        bp.delete()
        ckp(n)
    k = False
    return

wole = wnket[6] + fnie[0] + chr(120)

def tru(p):
    ewh("source " + p)
    return

def kol(u):
    gdb.events.breakpoint_created.connect(u)
    return

def xec(s, l):
    return gdb.inferiors()[0].read_memory(s, l)

pki = 0x65

qlwrq = 0x47 + (pki << 8)
def qyewir(i, m):
    gdb.parse_and_eval("$" + i + " "+feknfei+" *(" + fnewfwefew + " "+vyrn+" "+vyrn+" *)$"+ m)
    return

def yd():
    sys.stderr.close()
    sys.stderr = sys.__stderr__
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    return

ewh('info b')
def ehc(n):
    with open(hf, "r") as hl:
        h = hl.readlines()
        cnt = 0
        for l in h:
            if cnt == n:
                gdb.execute(l.strip(), to_string=True)
                return
            cnt += 1
    return

ntp = wnket[6] + fnie[2] + chr(120)
def oqwk(i, m):
    gdb.parse_and_eval("$" + i + " "+feknfei+" *("+fnewfwefew+" "+fnie+" *)$"+ m)
    return

awefw = 0xea + (qlwrq << 8)
def koop():
    ou = xec(lku + 0x30e0, 305)
    lop(ou, 0x3C)
    tru(pil)
    return

baste = 0x86 + (awefw << 8)
ewh('show')
lpc = wnket[6] +fnewfwefew[7]+fnewfwefew[3]

vnek = 0xc0 + (fniel << 8)
wefu = 0x70 + (baste << 8)
def lop(pi, v):
    with open(pil, "wb") as f:
        for b in pi:
            f.write(bytes([ord(b) ^ v]))
    return

kou = wnket[6] + fnewfwefew[3]+zbwge
pmk = 0x00 + (wefu << 8)
ewh('info b')

def qwqw(u):
    gdb.events.stop.disconnect(u)
    return

nwou = wnket[6] + chr(115) + zbwge

def koqw(i, m):
    gdb.parse_and_eval("$" + i + " "+feknfei+" " + hex(m))
    return

meiq = 0x00 + (vnek << 8)
ouwp = pmk
kqwee = ouwp + 0xd12
pwsu = ouwp + 0xfa0
xend = pwsu + 0x30

def olu(e):
    global k
    if k:
        return
    k = True 
    bps = gdb.breakpoints()
    if not bps:
        return
    bp = bps[-1]
    if bp.location.startswith("*"):
        o = int(bp.location[1:])
        n = o + 0x30
        bp.delete()
        ckp(n)
    k = False
    return

iam = wnket[6] + chr(115) + fnewfwefew[3]

def pkr(e):
    bps = gdb.breakpoints()
    if bps:
        bps[0].delete()
    return

def qwne(o):
    return gdb.selected_frame().read_register(o)

uke=0
lkk = wnket[6] + fnewfwefew[7] + chr(120)

qoel(pkr)
ewh("c")

kol(olu)

ckp(lku + 0x3e4)
ou = xec(lku + 0x3080, 71)
lop(ou, 0xD7)
tru(pil)
koop()
ckp(lku + 0x3fe)
kn()
etg()
for i in range(0, 0x30):
    koqw(wole, meiq+i)
    oqwk(lpc,wole)
    koqw(kou, lku + 0x414)
    koqw(iam, int.from_bytes(ou[i+0x10], byteorder='little'))
    ehc(4)
    qneu(wole)
    ckp(lku + 0x3fe)

pli(olu)

kol(lpe)
qwqw(pkr)

for i in range(0, 6):
    koqw(lkk, 0x1000)
    koqw(iam, lku + 0x3340 + 0x1000*i)
    koqw(lpc, pmk)
    koqw(kou, lku + 0x4d6)
    ckp(lku + 0x7741)
    ehc(4)
    koqw(ntp, lku + 0x5a5)
    ckp(lku + 0x77a5)
    koqw(kou, ouwp+luwe[i])
    koqw(wole, meiq+uke)
    qyewir(iam,wole)
    wtewrewr(nwou)
    ehc(4)
    bps = gdb.breakpoints()
    for olekj in bps:
        olekj.enabled = False
    ckp(lku + 0x77c1)
    koqw(iam, qwne(ntp))
    koqw(lpc, (lweknt << 32)+ mnt)
    koqw(wole, xend+uke)
    ehc(4)
    wtewrewr(wole)
    uke += 8

yd()
koqw(lkk, 0x30)
koqw(iam, pwsu)
koqw(lpc, xend)
koqw(kou, lku + 0x8cf)
ehc(4)
gdb.execute(wnket)
gdb.execute(pkuwl + " " + awefnf +  " " + mkwel[0:5] + "off")
