sudo gdb --nx -x ./tsgdbinary.py ./tsgdbinary
