#include <sqlite3.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/mman.h>

#define MAP_ADDR 0x2000000000
#define N_OPs 0x100
#define SIZE_OP 24

void readn(char *buf, unsigned size)
{
    unsigned cnt = 0;
    for (unsigned i = 0; i < size; i++)
    {
        unsigned x = read(0, buf + i, 1);
        cnt += x;
    }
    if (buf[cnt - 1] == '\n')
        buf[cnt - 1] = '\x00';
}

int read_int()
{
    char buf[32];
    read(0, buf, 31);
    return atoi(buf);
}

int main()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    sqlite3 *db;
    sqlite3_stmt *stmt;

    char *buf = mmap((void *)MAP_ADDR, 0x2000, PROT_READ | PROT_WRITE, MAP_ANONYMOUS | MAP_PRIVATE | MAP_FIXED, -1, 0);
    if (buf == MAP_FAILED)
    {
        perror("mmap");
        return 1;
    }

    if (sqlite3_open("hello.db", &db) != SQLITE_OK)
    {
        fprintf(stderr, "Cannot open database: %s\n", sqlite3_errmsg(db));
        return 1;
    }

    if (sqlite3_prepare_v2(db, "select 1;", -1, &stmt, NULL) != SQLITE_OK)
    {
        fprintf(stderr, "Failed to prepare statement: %s\n", sqlite3_errmsg(db));
        sqlite3_close(db);
        return 1;
    }

    printf("size> ");
    unsigned n = read_int();
    if (n >= (N_OPs * SIZE_OP))
    {
        puts("too long");
        return 1;
    }
    printf("your bytecode> ");
    readn(buf, n);

    char *target = malloc(N_OPs * SIZE_OP);
    memcpy(target, buf, n);

    // adhoc: stmt->aOp = target
    void **aOp = (void **)((unsigned long long)stmt + 136);
    *aOp = target;

    sqlite3_step((sqlite3_stmt *)stmt);
    sqlite3_close(db);
    return 0;
}
