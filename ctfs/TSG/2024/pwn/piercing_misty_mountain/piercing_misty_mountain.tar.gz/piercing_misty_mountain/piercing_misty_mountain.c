// gcc -o piercing_misty_mountain piercing_misty_mountain.c -no-pie
// -fno-stack-protector -static
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <unistd.h>

void read_n(char *buf, int n) {
  char tmp[1];
  for (int i = 0; i < n; i++) {
    read(STDIN_FILENO, tmp, 1);
    if (tmp[0] == '\n') {
      memset(&buf[i], 0,
             (((unsigned long long)&buf[i] + 7) & ~7) -
                 (unsigned long long)&buf[i]);
      break;
    }
    buf[i] = tmp[0];
  }
  return;
}

int read_int() {
  char buf[0x20];
  read_n(buf, 0x20);
  return atoi(buf);
}

int profile() {
  char job[0x8] = "Job:";
  char age[0x8];
  printf("Job > ");
  read_n(job + 4, 0x18 - 4);
  printf("Age > ");
  read_n(age, 0x8);
  return atoi(age);
}

void auth() {
  int age;
  char input[8];
  char buf[0x4000];
  printf("Generating Binary Password...\n");
  getrandom(buf, 0x4000, GRND_NONBLOCK);
  while (1) {
    printf("1. Show Password\n2. Generate New Password\n3. Enter Your Age and "
           "Job\n");
    printf("> ");
    int num = read_int();
    switch (num) {
    case 1:
      printf("%s", buf);
      continue;
    case 2:
      getrandom(buf, 0x4000, GRND_NONBLOCK);
      continue;
    case 3:
      age = profile();
      if (age < 18) {
        printf("Too young!.\n");
        return;
      }
      printf("Confirm Password > ");
      read_n(input, 8);
      if (memcmp(input, buf, 8)) {
        printf("Incorrect password.\n");
        continue;
      } else {
        printf("Password confirmed!.\n");
        return;
      }
      continue;
    default:
      continue;
    }
  }
}

int main() {
  char buf[0x1000];
  setvbuf(stdout, (char *)NULL, _IONBF, 0);
  printf("Name > ");
  read_n(buf, 0x1000);
  auth();
  exit(0);
}
