// g++ -o fl_support_center main.cpp
#include <iostream>
#include <limits>
#include <map>

#define MAX_CONTACT 2
#define MAX_SUPPORT_CONTACT 2

unsigned int contact = 0;
unsigned int support_contact = 0;

void add(std::map<std::string, std::string> &friends_list,
         std::map<std::string, std::string> &black_list) {
  std::string name;
  std::cout << "Name: ";
  std::cin >> name;

  if (auto it = black_list.find(name); it != black_list.end()) {
    if (black_list[name] != "") {
      std::cout << "Reported user" << std::endl;
      return;
    }
  }

  if (name.size() >= 0x100) {
    std::cout << "Too long" << std::endl;
  } else {
    friends_list[name] = "";
  }
  return;
}

void message(std::map<std::string, std::string> &friends_list) {
  std::string name;
  std::string message;

  contact++;
  if (contact > MAX_CONTACT) {
    std::cout << "The trial ends here." << std::endl;
    return;
  }

  std::cout << "Name: ";
  std::cin >> name;

  std::cout << "Message: ";
  std::cin >> message;

  if (message.size() >= 0x100) {
    std::cout << "Too long" << std::endl;
    return;
  }

  try {
    std::string old = friends_list.at(name);
    if (old != "") {
      std::string yon;
      std::cout << "Do you want to delete the sent message: " << old
                << "(yes or no)" << std::endl;
      std::cout << "> ";
      std::cin >> yon;
      if (yon == "yes") {
        friends_list.at(name) = message;
      }
    } else {
      friends_list.at(name) = message;
    }
  } catch (const std::out_of_range &ex) {
    std::cout << "Invalid Name" << std::endl;
  }
  return;
}

void list(std::map<std::string, std::string> &friends_list) {
  for (auto it : friends_list) {
    std::cout << "----------------------------------------------" << std::endl;
    std::cout << "Name: " << it.first << std::endl;
    std::cout << "Sent Message: " << it.second << std::endl;
  }
  std::cout << "----------------------------------------------" << std::endl;
  return;
}

void remove(std::map<std::string, std::string> &friends_list,
            std::map<std::string, std::string> &black_list) {
  std::string yon;
  std::string name;
  std::string message;
  std::cout << "Name: ";
  std::cin >> name;

  for (auto it = friends_list.begin(); it != friends_list.end();) {
    auto next = std::next(it);

    if (it->first == name) {
      if (it->first != "FL*Support*Center@fl.support.center") {
        friends_list.erase(it);
        if (auto it = black_list.find(name); it != black_list.end()) {
          std::cout << "Already blacklisted" << std::endl;
          std::cout << "Report: ";
          std::cin >> message;
          if (message.size() >= 0x100) {
            std::cout << "Too long" << std::endl;
          } else {
            black_list[name] = message;
          }
        } else {
          black_list[name] = "";
        }
      }

      if (it->first == "FL*Support*Center@fl.support.center") {
        support_contact++;
        if (contact > MAX_SUPPORT_CONTACT) {
          std::cout << "Too many contacts" << std::endl;
          return;
        }
        std::cout << "Thank you for contacting FL*Support*Center." << std::endl;
        std::cout << "Is there anything that didn't meet your expectations?"
                  << std::endl;
        std::cout << "Please let us know." << std::endl;

        if (it->second != "") {
          std::cout << "Do you want to delete the sent message: " << it->second
                    << "(yes or no)" << std::endl;
          std::cout << "> ";
          std::cin >> yon;
          if (yon != "yes") {
            break;
          }
        }

        std::cout << "Message: " << std::endl;
        std::cin >> message;
        if (message.size() >= 0x100) {
          std::cout << "Too long" << std::endl;
        } else {
          it->second = message;
        }
      }
    }
    it = next;
  }
  return;
}

int main() {
  int choice;
  std::map<std::string, std::string> friends_list = {
      {"FL*Support*Center@fl.support.center", ""}};
  std::map<std::string, std::string> black_list = {};

  while (1) {
    std::cout << "1. Add\n2. Message\n3. List\n4. Remove\n5. Exit" << std::endl;
    std::cout << "> ";
    std::cin >> choice;

    if (std::cin.eof()) {
      exit(0);
    }
    if (std::cin.fail()) {
      std::cout << "Invalid Option" << std::endl;
      std::cin.clear();
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      continue;
    }

    switch (choice) {
    case 1:
      add(friends_list, black_list);
      break;
    case 2:
      message(friends_list);
      break;
    case 3:
      list(friends_list);
      break;
    case 4:
      remove(friends_list, black_list);
      break;
    case 5:
      exit(0);

    default:
      std::cout << "Invalid Option" << std::endl;
      break;
    }
  }
  return 0;
}
