import crypto from 'node:crypto'
import { readFile } from 'node:fs/promises'
import bodyParser from 'body-parser'
import * as htmlEntities from 'html-entities'
import { nanoid } from 'nanoid'
import mongodb from 'mongodb'
import Mustache from 'mustache'
import polka from 'polka'
import { createClient } from 'redis'

const redisClient = createClient({
  url: process.env.REDIS_URL
})
redisClient.on('error', err => console.log('Redis Client Error', err))
await redisClient.connect()

const mongoClient = new mongodb.MongoClient(process.env.MONGO_URL)
const appDb = mongoClient.db('app_db')
const presetsCollection = appDb.collection('presets')

function sendJson(res, obj, status = 200) {
  res.statusCode = status
  res.setHeader('Content-Type', 'application/json')
  res.end(JSON.stringify(obj))
}

function cspMiddleware(req, res, next) {
  const nonce = crypto.randomBytes(16).toString('base64')
  res.nonce = nonce
  res.setHeader('Content-Security-Policy', `script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; child-src 'self'; object-src 'none'`)
  next()
}

function sanitizeHtml(str) {
  // tags for metadata
  if (/meta|link/i.test(str)) {
    return htmlEntities.encode(str)
  }
  return str
}

function guardError(handler) {
  return async (req, res) => {
    try {
      await handler(req, res)
    } catch {
      res.status = 500
      res.setHeader('Content-Type', 'text/plain')
      res.end('internal error')
    }
  }
}

polka()
  .use(bodyParser.json(), cspMiddleware)
  .get('/', guardError(async (req, res) => {
    const template = await readFile('./index.tpl', 'utf-8')
    const html = Mustache.render(template, {
      nonce: res.nonce
    })
    res.setHeader('Content-Type', 'text/html')
    res.end(html)
  }))
  .get('/presets/:id', guardError(async (req, res) => {
    const preset = await presetsCollection.findOne({ id: req.params.id })
    if (!preset) {
      res.statusCode = 404
      res.setHeader('Content-Type', 'text/plain')
      res.end('not found')
      return
    }
    const template = await readFile('./preset.tpl', 'utf-8')
    const titleElem = `<title>${sanitizeHtml(preset.name)} - preset</title>`
    const html = Mustache.render(template, {
      titleElem,
      name: preset.name,
      prefix: preset.prefix,
      jsStr: JSON.stringify(preset.prefix).replaceAll('<', '\\x3c'),
      nonce: res.nonce
    })
    res.setHeader('Content-Type', 'text/html')
    res.end(html)
  }))
  .post('/preset', guardError(async (req, res) => {
    const { name, prefix } = req.body ?? {}
    if (typeof name !== 'string' || typeof prefix !== 'string') {
      sendJson(res, { message: 'invalid params' }, 400)
      return
    }
    if (name.length === 0) {
      sendJson(res, { message: 'name is empty' }, 400)
      return
    }
    if (prefix.length > 25) {
      sendJson(res, { message: 'prefix too long' }, 400)
      return
    }
    const id = nanoid()
    await presetsCollection.insertOne({ id, name, prefix })
    sendJson(res, { id })
  }))
  .post('/result', guardError((req, res) => {
    // TODO: save users' result
    sendJson(res, {})
  }))
  .post('/report', guardError(async (req, res) => {
    const targetPath = req.body?.path
    if (typeof targetPath !== 'string' || !targetPath.startsWith('/presets')) {
      sendJson(res, { message: 'specify path' }, 400)
      return
    }
    await redisClient.rPush('query', targetPath)
    await redisClient.incr('queued_count')
    sendJson(res, { message: 'Reported. Admin will check the page.' })
  }))
  .listen(7891, '0.0.0.0')
