async function sendRequest(form) {
	const body = JSON.stringify(Object.fromEntries(new FormData(form).entries()));
	const response = await fetch("/", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
		},
		body,
	});
	return response.text();
}

function displayMessage(message) {
	document.querySelector("#message").textContent = message;
}

document.querySelector("#form").addEventListener("submit", (e) => {
	e.preventDefault();
	sendRequest(e.currentTarget)
		.then((message) => displayMessage(message))
		.catch((e) => displayMessage(e.message));
});
