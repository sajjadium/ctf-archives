import cv2
import numpy as np
import open3d as o3d
from scipy.stats import special_ortho_group, norm
import string

alphabet = string.ascii_uppercase + "{}_"
print(len(alphabet))

patchsize = 64
shift = 64
patches = np.zeros((len(alphabet)+1, patchsize, patchsize), np.uint8)

offset = 8
for i in range(len(alphabet)):
    cv2.putText(patches[i], alphabet[i], (offset, patchsize-offset), cv2.FONT_HERSHEY_SIMPLEX, 2.0, 255, 4)
cv2.imwrite("sample.png", patches.reshape(5, 6, patchsize, patchsize).transpose(0,2,1,3).reshape(patchsize * 5, patchsize * 6))

flag = "TSGCTF{_______________________________________________________}"  # secret!
assert len(flag) == 63
radii = (len(flag) - 1) / 2

coords = []
for i in range(len(flag)):
    index = alphabet.index(flag[i])
    img = patches[index]
    xmap, ymap = np.meshgrid(np.arange(patchsize), np.arange(patchsize))
    xs = xmap[np.where(img == 255)].astype(np.float32)[:, None]
    ys = ymap[np.where(img == 255)].astype(np.float32)[:, None]
    zs = np.full_like(xs, shift * (i - radii))

    s = 16 * norm.pdf((i - radii), loc=0, scale=11) / norm.pdf(0, loc=0, scale=11)
    noise_xs = np.round(np.random.normal(0, scale=s, size=xs.shape)) * shift
    noise_ys = np.round(np.random.normal(0, scale=s, size=ys.shape)) * shift

    coords.append(np.concatenate([xs + noise_xs, ys + noise_ys, zs], axis=1))

coords = np.concatenate(coords, axis=0)

# random rotate
rot = special_ortho_group.rvs(3)
coords = coords @ rot

# random translate
trl = np.random.normal(0, scale=100, size=3)
coords += trl

# shuffle order
coords = coords[np.random.permutation(len(coords))]
np.save("problem.npy", coords)

# for visualization
# pcd = o3d.t.geometry.PointCloud(coords)
# o3d.visualization.draw_geometries([pcd.to_legacy()])