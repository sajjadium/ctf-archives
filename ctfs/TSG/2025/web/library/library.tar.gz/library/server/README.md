# server

```sh
bun install --frozen-lockfile
FLAG=TSGDUMMYFLAG{} bun serve.ts
```
