import { Hono } from "hono";
import { serveStatic } from "hono/deno";

const FLAG = Deno.env.get("FLAG") ?? "TSGCTF{REDACTED}";

const app = new Hono();

app.get("/", serveStatic({ path: "./index.html" }));

app.get("/challenge", (c) => {
  const time = c.req.query("time");
  if (typeof time !== "string") {
    return c.text("time should be string", 400);
  }
  const original = Temporal.ZonedDateTime.from(time);
  const copy = Temporal.ZonedDateTime.from(original.toString());
  if (!original.equals(copy)) {
    return c.text(`Congratulations! flag: ${FLAG}`);
  }
  return c.text("try again!");
});

export default app;
