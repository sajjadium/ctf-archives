package tsg.book;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Controller
public class PagesController {

  private static final Set<String> CATEGORIES =
      Set.of("pwn", "reversing", "crypto", "web", "misc");

  private static final Map<String, List<String>> MEMBERS = Map.of(
      "pwn", List.of("moratorium08", "smallkirby", "iwashiira", "LLUUIIGGEE", "sashiming", "peloeil"),
      "reversing", List.of("satos","matsumatsu", "liesegang", "mikanami"),
      "crypto", List.of("JP3BGY", "naan", "settyan117", "jiei-univ"),
      "web", List.of("hakatashi", "fabon", "aster-void"),
      "misc", List.of("mikit", "dai")
  );


  @GetMapping("/")
  public String index(Model model) {
    model.addAttribute("categories", CATEGORIES);
    return "index";
  }

  @GetMapping("/entry")
    public String entry(Model model) {
      model.addAttribute("msg", "Since you are a member of TSG, you should already know the flag.");
    
      List<String> allNames = MEMBERS.values().stream()
                                   .flatMap(List::stream)
                                   .sorted().toList();
      model.addAttribute("allNames", allNames);
      model.addAttribute("targetUrl", "/flag-app");

      return "entry";
    }

  @GetMapping("/{category}")
  public void category(@PathVariable String category, Model model) {
    String category_dec = URLDecoder.decode(category, StandardCharsets.UTF_8);
    model.addAttribute("category", category_dec);
    model.addAttribute("members", MEMBERS.getOrDefault(category, List.of()));
  }

  @GetMapping("/{category}/members")
  public String members(@PathVariable String category,
                        @RequestParam(name = "q", required = false) String q,
                        Model model) {
    var members = MEMBERS.getOrDefault(category, List.of());
    String query = (q == null) ? "" : q.trim();

    if (!query.isEmpty()) {
      final String needle = query.toLowerCase();
      members = members.stream()
          .filter(m -> m.toLowerCase().contains(needle))
          .toList();
    }

    model.addAttribute("category", category);
    model.addAttribute("members", members);
    model.addAttribute("q", query);
    return "members";
  }

  @GetMapping("/{category}/members/{name}")
  public String member(@PathVariable String category,
                       @PathVariable String name,
                       Model model) {
    if (!MEMBERS.getOrDefault(category, List.of()).contains(name)) {
      throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    }

    model.addAttribute("category", category);
    model.addAttribute("name", name);
    return "member";
  }

  @GetMapping("/members")
  public String allMembers(@RequestParam(name = "q", required = false) String q,
                           Model model) {
    String query = (q == null) ? "" : q.trim();
    model.addAttribute("q", query);

    record Hit(String category, String name) {}
    List<Hit> hits = new ArrayList<>();

    String needle = query.toLowerCase();
    for (String cat : CATEGORIES) {
      for (String name : MEMBERS.getOrDefault(cat, List.of())) {
        if (query.isEmpty() || name.toLowerCase().contains(needle)) {
          hits.add(new Hit(cat, name));
        }
      }
    }

    hits.sort(Comparator.comparing(Hit::category).thenComparing(Hit::name));
    model.addAttribute("hits", hits);
    return "members_all";
  }
}

