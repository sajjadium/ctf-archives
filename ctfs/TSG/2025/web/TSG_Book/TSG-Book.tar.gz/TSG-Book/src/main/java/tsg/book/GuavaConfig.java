package tsg.book;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.util.AbstractMap;
import java.util.Set;

@Configuration
public class GuavaConfig {

    @Bean(name = "guava")
    public Object guava() {
        return new ForNameProxy("com.google.common");
    }

    public static class ForNameProxy extends AbstractMap<String, Object> {
        private final String currentPath;

        public ForNameProxy(String path) {
            this.currentPath = path;
        }

        @Override
        public Object get(Object key) {
            String next = (String) key;
            String target = currentPath + "." + next;

            try {
                return Class.forName(target);
            } catch (ClassNotFoundException e) {
                return new ForNameProxy(target);
            }
        }

        @Override public Set<Entry<String, Object>> entrySet() { return java.util.Collections.emptySet(); }
        @Override public boolean containsKey(Object key) { return true; }
    }
}
