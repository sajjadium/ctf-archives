package tsg.book;

import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.io.File;

@Configuration
public class TomcatConfig {

    private static final Logger logger = LoggerFactory.getLogger(TomcatConfig.class);

    @Bean
    public TomcatServletWebServerFactory servletContainer() {
        return new TomcatServletWebServerFactory() {
            @Override
            protected void postProcessContext(Context context) {
                if (context.getPath().isEmpty() || "/".equals(context.getPath())) {
                    context.setCrossContext(true);
                }
            }
            @Override
            protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
                try {
                    String expandedPath = "/app/flag-app-expanded";
                    File docBase = new File(expandedPath);

                    if (docBase.exists() && docBase.isDirectory()) {
                        logger.info("Deploying flag-app from: {}", expandedPath);
                        
                        Context ctx = tomcat.addWebapp("/flag-app", docBase.getAbsolutePath());
                        ctx.setParentClassLoader(getClass().getClassLoader());
                        
                        logger.info("Successfully registered /flag-app context");
                    } else {
                        logger.warn("Directory not found at: {}", expandedPath);
                    }
                } catch (Exception e) {
                    logger.error("Deployment failed", e);
                }
                return super.getTomcatWebServer(tomcat);
            }
        };
    }
}
