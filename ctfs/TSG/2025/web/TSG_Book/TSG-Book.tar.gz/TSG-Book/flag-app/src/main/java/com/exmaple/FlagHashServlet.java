package com.example;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.HexFormat;

@WebServlet("/")
public class FlagHashServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // mv ./flag ./flag-$(md5sum flag | awk '{print $1}')
        try (InputStream is = getServletContext().getResourceAsStream("/WEB-INF/flag-9ddcd04fc05b1cf20db817ebb1860bca")) {
            if (is == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "Flag file not found in WEB-INF/");
                return;
            }

            byte[] hash = MessageDigest.getInstance("SHA-256").digest(is.readAllBytes());
            String hexHash = HexFormat.of().formatHex(hash);

            resp.setContentType("text/plain");
            resp.getWriter().write(hexHash);
        } catch (Exception e) {
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        }
    }
}
