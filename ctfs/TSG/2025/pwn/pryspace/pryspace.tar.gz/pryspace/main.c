#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NOTE 16
#define NOTE_SIZE 0xe0

int one_time_chk = 0;
char *note[MAX_NOTE];

void print_menu() {
  printf("1. make\n2. copy\n3. show\n4. merge\n5. delete\n6. exit\n");
}

int read_int(int *n) {
  int c = scanf("%d", n);
  getchar();
  return c;
}

int check_index(int index) {
  if (index >= MAX_NOTE || index < 0) {
    return 1;
  }
  return 0;
}

void make_note() {
  int index;
  size_t size = NOTE_SIZE;
  printf("index > ");
  if (read_int(&index) != 1 || check_index(index)) {
    printf("Invalid index\n");
    return;
  }

  note[index] = malloc(size);
  assert(note[index] != NULL);
  memset(note[index], 0, size);
  fgets(note[index], size, stdin);
  return;
}

void copy_note() {
  int src, dst;
  printf("src > ");
  if (read_int(&src) != 1 || check_index(src)) {
    printf("Invalid index\n");
    return;
  }

  printf("dst > ");
  if (read_int(&dst) != 1 || check_index(dst)) {
    printf("Invalid index\n");
    return;
  }

  if (note[src] == NULL) {
    printf("Note does not exist\n");
    return;
  }

  note[dst] = strdup(note[src]);
  assert(note[dst] != NULL);
  return;
}

void show_note() {
  int index;
  printf("index > ");
  if (read_int(&index) != 1 || check_index(index)) {
    printf("Invalid index\n");
    return;
  }
  if (note[index] == NULL) {
    printf("Note does not exist\n");
    return;
  }

  printf("%s", note[index]);
  return;
}

void merge_note() {
  int index = 0, count, src;
  size_t size = NOTE_SIZE * MAX_NOTE;
  if (one_time_chk == 0) {
    one_time_chk = 1;
  } else {
    printf("Only one merge is allowed\n");
    return;
  }
  note[index] = malloc(size);
  assert(note[index] != NULL);
  memset(note[index], 0, size);

  printf("count > ");
  if (read_int(&count) != 1 || count > MAX_NOTE || count < 0) {
    printf("Invalid count\n");
    return;
  }

  for (int i = 0; i < count; i++) {
    printf("src > ");
    if (read_int(&src) != 1 || check_index(src)) {
      printf("Invalid index\n");
      return;
    }
    if (note[src] == NULL) {
      printf("Note does not exist\n");
      continue;
    }
    memmove(note[index] + strlen(note[index]), note[src],
            strlen(note[src]) + 1);
  }
  return;
}

void delete_note() {
  int index;
  printf("index > ");
  if (read_int(&index) != 1 || check_index(index)) {
    printf("Invalid index\n");
    return;
  }
  if (note[index] == NULL) {
    printf("Note does not exist\n");
    return;
  }

  free(note[index]);
  note[index] = NULL;
  return;
}

int main() {
  int c, num;
  setvbuf(stdout, (char *)NULL, _IONBF, 0);
  while (1) {
    print_menu();
    printf("> ");
    if (read_int(&num) != 1) {
      printf("Invalid input\n");
      continue;
    }
    switch (num) {
    case 1:
      make_note();
      break;
    case 2:
      copy_note();
      break;
    case 3:
      show_note();
      break;
    case 4:
      merge_note();
      break;
    case 5:
      delete_note();
      break;
    case 6:
      return 0;
    default:
      printf("Invalid number\n");
      break;
    }
  }
}
