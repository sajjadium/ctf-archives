# build

As the project is still in development, we are using a debug build.
