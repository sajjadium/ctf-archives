#pragma once
#include "xml_node.hpp"
#include <string>

class XmlParser {
public:
  explicit XmlParser(const std::string &input);

  XmlNode parse_document();

private:
  const std::string &s;
  std::size_t i;
  XmlDecl *xml_decl_loc;

  bool eof() const { return i >= s.size(); }
  char peek() const { return eof() ? '\0' : s[i]; }
  char get() { return eof() ? '\0' : s[i++]; }

  void skip_ws();
  void expect(char c);

  bool start_with_root();
  std::string parse_name();
  std::string parse_quoted_value();
  XmlDecl &parse_xml_decl();
  std::string decode_entities(const std::string &);

  XmlNode parse_element();

  std::string parse_text();
  std::vector<std::variant<XmlNode, XmlDecl>> originals;
};
