#pragma once
#include <string>
#include <variant>
#include <vector>

struct XmlNode;
struct XmlDecl;
using XmlText = std::string;
using XmlChild = XmlNode;
using XmlContent = std::variant<XmlText, XmlChild>;
using OrgContent = std::variant<XmlNode, XmlDecl>;

struct XmlNode {
  std::string name;
  std::vector<XmlContent> content;
};

struct XmlDecl {
  std::string version;
  std::string encoding;
};
