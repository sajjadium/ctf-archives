#include "xml_parser.hpp"
#include <cctype>
#include <sstream>
#include <stdexcept>

XmlParser::XmlParser(const std::string &input) : s(input), i(0) {
  xml_decl_loc = new XmlDecl();
  xml_decl_loc->version = "1.0";
  xml_decl_loc->encoding = "UTF-8";
  originals.reserve(10);
}

static inline bool start_with_at(const std::string &s, std::size_t pos,
                                 const char *lit) {
  const std::size_t len = std::char_traits<char>::length(lit);
  return pos + len <= s.size() && s.compare(pos, len, lit) == 0;
}

bool XmlParser::start_with_root() { return start_with_at(s, 0, "<root>"); }

void XmlParser::skip_ws() {
  while (!eof() && std::isspace(static_cast<unsigned char>(peek()))) {
    ++i;
  }
}

void XmlParser::expect(char c) {
  if (eof()) {
    throw std::runtime_error(std::string("Expected '") + c +
                             "' but reached EOF at pos " + std::to_string(i));
  }
  if (get() != c) {
    std::ostringstream oss;
    oss << "Expected '" << c << "' at pos " << (i ? i - 1 : i);
    throw std::runtime_error(oss.str());
  }
}

std::string XmlParser::parse_name() {
  if (eof()) {
    throw std::runtime_error("Unexpected EOF while reading name");
  }

  char c = peek();
  auto is_name_start = [](char ch) {
    return std::isalpha(static_cast<unsigned char>(ch)) || ch == '_' ||
           ch == ':';
  };
  auto is_name_char = [&](char ch) {
    return is_name_start(ch) || std::isdigit(static_cast<unsigned char>(ch)) ||
           ch == '-' || ch == '.';
  };

  if (!is_name_start(c)) {
    std::ostringstream oss;
    oss << "Invalid name start at pos " << i;
    throw std::runtime_error(oss.str());
  }

  std::size_t start = i++;
  while (!eof() && is_name_char(peek())) {
    ++i;
  }
  return s.substr(start, i - start);
}

std::string XmlParser::parse_quoted_value() {
  skip_ws();
  char q = peek();
  if (q != '"' && q != '\'') {
    throw std::runtime_error("Attribute value must be quoted at pos " +
                             std::to_string(i));
  }
  get();

  std::string v;
  while (!eof() && peek() != q) {
    v.push_back(get());
  }
  if (eof()) {
    throw std::runtime_error("Unterminated attribute value starting at pos " +
                             std::to_string(i));
  }
  get();
  return v;
}

XmlDecl &XmlParser::parse_xml_decl() {
  XmlDecl xml_decl;
  skip_ws();
  if (peek() != '<' || !start_with_at(s, i, "<?xml")) {
    throw std::runtime_error("invalid xml decl at pos " + std::to_string(i));
  }
  i += 6;
  while (!eof()) {
    if (i + 2 <= s.size() && s[i] == '?' && s[i + 1] == '>') {
      break;
    }
    skip_ws();
    if (start_with_at(s, i, "version=")) {
      i += 8;
      xml_decl.version = parse_quoted_value();
    } else if (start_with_at(s, i, "encoding=")) {
      i += 9;
      xml_decl.encoding = parse_quoted_value();
    } else {
      i += 1;
    }
  }
  expect('?');
  expect('>');
  originals.push_back(std::move(xml_decl));
  return std::get<XmlDecl>(originals.back());
}

std::string XmlParser::decode_entities(const std::string &in) {
  std::string out;
  out.reserve(in.size());

  if (xml_decl_loc->version == "1.1") {
    throw std::runtime_error("XML version 1.1 is not supported yet");
    // TODO: Implement XML 1.1 entity decoding rules
  }

  for (std::size_t j = 0; j < in.size();) {
    if (in[j] != '&') {
      out.push_back(in[j++]);
      continue;
    }

    std::size_t k = in.find(';', j + 1);
    if (k == std::string::npos) {
      out.append(in.substr(j));
      break;
    }

    std::string ent = in.substr(j, k - j + 1);
    if (ent == "&lt;")
      out.push_back('<');
    else if (ent == "&gt;")
      out.push_back('>');
    else if (ent == "&amp;")
      out.push_back('&');
    else if (ent == "&apos;")
      out.push_back('\'');
    else if (ent == "&quot;")
      out.push_back('"');
    else
      out.append(ent);

    j = k + 1;
  }
  return out;
}

std::string XmlParser::parse_text() {
  std::size_t start = i;
  std::size_t pos = s.find('<', i);
  if (pos == std::string::npos) {
    i = s.size();
    return decode_entities(s.substr(start));
  }
  i = pos;
  return decode_entities(s.substr(start, pos - start));
}

XmlNode XmlParser::parse_element() {
  skip_ws();
  expect('<');

  if (peek() == '/') {
    throw std::runtime_error("Unexpected end tag at pos " + std::to_string(i));
  }

  std::string name = parse_name();

  skip_ws();

  if (peek() == '/') {
    get();
    expect('>');
    XmlNode node;
    node.name = std::move(name);
    return node;
  }

  expect('>');

  XmlNode node;
  node.name = std::move(name);
  if (node.name == "root") {
    originals.push_back(node);
  }

  while (!eof()) {
    skip_ws();
    if (peek() == '<') {
      if (start_with_at(s, i, "</")) {
        i += 2;
        std::string end_name = parse_name();
        if (end_name != node.name) {
          throw std::runtime_error("Mismatched end tag: expected </" +
                                   node.name + "> but got </" + end_name + ">");
        }
        skip_ws();
        expect('>');
        return node;
      } else {
        if (start_with_at(s, i, "<?xml")) {
          if (xml_decl_loc != nullptr) {
            delete (xml_decl_loc);
            xml_decl_loc = nullptr;
          }
          xml_decl_loc = &parse_xml_decl();
          XmlChild child;
          child.name = "?xml";
          child.content.push_back(xml_decl_loc->version);
          child.content.push_back(xml_decl_loc->encoding);
          node.content.push_back(std::move(child));
        } else {
          XmlChild child = parse_element();
          node.content.push_back(std::move(child));
        }
      }
    } else {
      XmlText text = parse_text();
      node.content.push_back(std::move(text));
    }
  }
  throw std::runtime_error("End tag not found for element <" + node.name + ">");
}

XmlNode XmlParser::parse_document() {
  if (!start_with_root()) {
    throw std::runtime_error("XML must start with <root> element.");
  }
  XmlNode root = parse_element();
  skip_ws();
  if (!eof()) {
    throw std::runtime_error("Extra content after root element at pos " +
                             std::to_string(i));
  }
  return root;
}
