mkdir build -p && cd build
cmake .. -DCMAKE_EXE_LINKER_FLAGS="-no-pie -static" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
cmake --build . --config Debug
#cmake .. -DCMAKE_BUILD_TYPE=Release -DCMAKE_EXE_LINKER_FLAGS="-no-pie -static"
#cmake --build . --config Release
