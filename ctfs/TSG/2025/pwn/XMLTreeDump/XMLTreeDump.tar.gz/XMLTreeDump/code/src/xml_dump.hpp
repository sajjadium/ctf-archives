#pragma once
#include "xml_node.hpp"

void dump_tree(const XmlNode &node, int depth = 0);
