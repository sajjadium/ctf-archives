#include "xml_dump.hpp"
#include "xml_parser.hpp"
#include <iostream>
#include <unistd.h>

int main(int argc, char **argv) {
  constexpr std::size_t MAX_BYTES = 0x400 * 100;
  char buf[0x400];
  std::string xml;

  std::cout << "input xml> \n";
  std::cout.flush();
  xml.reserve(MAX_BYTES);

  while (true) {
    std::cin.read(buf, sizeof(buf));
    std::streamsize n = std::cin.gcount();

    if (n > 0) {
      if (xml.size() + static_cast<std::size_t>(n) > MAX_BYTES) {
        std::cerr << "Error: input too large (limit " << MAX_BYTES
                  << " bytes)\n";
        return 1;
      }
      xml.append(buf, static_cast<std::size_t>(n));
    }

    if (std::cin.eof()) {
      break;
    }
    if (std::cin.fail()) {
      std::cerr << "Error: failed while reading stdin\n";
      return 1;
    }
  }

  close(0);

  try {
    XmlParser parser(xml);
    XmlNode root = parser.parse_document();
    dump_tree(root);
  } catch (const std::exception &e) {
    std::cerr << "Parse error: " << e.what() << "\n";
    return 2;
  }

  return 0;
}
