#include "xml_dump.hpp"
#include <iostream>
#include <string>

static std::string indent(int depth) { return std::string(depth * 2, ' '); }

void dump_tree(const XmlNode &node, int depth) {
  if (node.name == "root") {
    std::cout << indent(depth) << "<" << node.name << ">\n";
  } else {
    std::cout << "\n" << indent(depth) << "<" << node.name << ">\n";
  }
  for (const auto &ch : node.content) {
    if (std::holds_alternative<XmlText>(ch)) {
      std::cout << indent(depth + 1) << "\"" << std::get<XmlText>(ch) << "\"";
    } else {
      dump_tree(std::get<XmlChild>(ch), depth + 1);
    }
  }
  std::cout << "\n" << indent(depth) << "</" << node.name << ">\n";
  return;
}
