import numpy as np
import librosa
import gradio as gr
import whisper
from pathlib import Path

MAX_DURATION = 5  # seconds

WHISPER_SR = 16000
N_FFT = 400
FLAG = "TSGCTF{dummy}"

model = whisper.load_model("base.en")

def cut_high_freqs(freq_space, sr, cutoff_freq):
    cutoff_bin = int(cutoff_freq * N_FFT / sr)
    freq_space[cutoff_bin:, :] = 0

def detect_intruder(freq_space, sr):
    cut_high_freqs(freq_space, sr, 10000)  # TODO: Remove this once the strange noise from the exhaust fan is fixed.
    magnitude = np.abs(freq_space).max()
    print("magnitude:", magnitude)
    return magnitude > 0

def recognize(audio):
    if audio is None:
        return "No audio provided."
    sr, wave_int16 = audio
    print(f"Sample rate: {sr}, Audio length: {len(wave_int16)/sr:.2f} seconds, dtype: {wave_int16.dtype}")

    wave = (wave_int16).astype(np.float32) / 32768.0  # to float32
    if len(wave.shape) == 2:
        wave = wave.mean(axis=1)  # to mono
    wave = wave[:MAX_DURATION * sr]

    freq_space = librosa.stft(wave, n_fft=N_FFT)
    freq_space[np.abs(freq_space) < 0.01] = 0  # noise cancellation
    wave = librosa.istft(freq_space)
    
    if detect_intruder(freq_space, sr):
        return "ALERT! Intruder detected!"

    wave = librosa.resample(wave, orig_sr=sr, target_sr=WHISPER_SR, res_type="linear")
    result = whisper.transcribe(model, wave, temperature=0.0)["text"]
    print("Transcription result:", result)
    if "give me the flag" in result.lower():
        return "OK, here is the flag: " + FLAG
    else:
        return "Unknown command."


demo = gr.Interface(
    fn=recognize,
    inputs=gr.Audio(type="numpy", label="Input Audio", sources=["upload", "microphone"]),
    outputs=gr.Textbox(lines=1, label="System Message"),
    title="CIA Vault Terminal",
)
demo.launch(server_name="0.0.0.0", server_port=7860)