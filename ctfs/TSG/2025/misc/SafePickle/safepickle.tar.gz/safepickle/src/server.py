import pickle, pickletools

BANNED_OPS = [
    "EXT1",
    "EXT2",
    "EXT4",
    "REDUCE",
    "INST",
    "OBJ",
    "PERSID",
    "BINPERSID",
]

data = bytes.fromhex(input("input pickle (hex)> "))
try:
    for opcode, arg, pos in pickletools.genops(data):
        if opcode.name in BANNED_OPS:
            print(f"Banned opcode used: {opcode.name}")
            exit(0)
except Exception as e:
    print("Error :(")
    exit(0)

print(pickle.loads(data))
