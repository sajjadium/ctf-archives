docker build -t tsgctf2025-chatbot .
docker run -it --rm -v $(pwd):/app -e XDG_CACHE_HOME=/app/cache tsgctf2025-chatbot python main.py