#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#define MAX_EXEC_REGIONS 128

typedef struct {
  unsigned long start;
  unsigned long end;
} ExecRegion;

static void install_seccomp(void) {
  struct sock_filter filter[] = {
      BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, arch)),
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),

      BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),

      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve, 0, 1),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),

#ifdef __NR_execveat
      BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execveat, 0, 1),
      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
#endif

      BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
  };

  struct sock_fprog prog = {
      .len = (unsigned short)(sizeof(filter) / sizeof(filter[0])),
      .filter = filter,
  };

  if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
    perror("prctl(NO_NEW_PRIVS)");
    exit(1);
  }

  if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog)) {
    perror("prctl(SECCOMP)");
    exit(1);
  }
}

bool is_safe(uint8_t *n) {
  for (int i = 0; i < 0x1000; i++) {
    if (n[i] == 0x0f && n[i + 1] == 0x05) {
      return false;
    }
    if (n[i] == 0x48 && n[i + 1] == 0x8D && (n[i + 2] & 0xC7) == 0x05) {
      return false;
    }
    if (n[i] == 0xF3 && n[i + 1] == 0x0F && n[i + 2] == 0xAE) {
      return false;
    }
    if (n[i] == 0xF3 && n[i + 2] == 0x0F && n[i + 3] == 0xAE) {
      return false;
    }
  }
  return true;
}

void safe_box(uint8_t *shellcode) {
  FILE *fp = fopen("/proc/self/maps", "r");
  if (!fp) {
    perror("fopen");
    return;
  }

  ExecRegion exec_regions[MAX_EXEC_REGIONS];
  int count = 0;

  char line[256];
  while (fgets(line, sizeof(line), fp)) {
    unsigned long start, end;
    char perms[5];

    if (sscanf(line, "%lx-%lx %4s", &start, &end, perms) != 3)
      continue;

    if (strchr(perms, 'x') && strstr(line, "lib") && count < MAX_EXEC_REGIONS) {
      exec_regions[count].start = start;
      exec_regions[count].end = end;
      count++;
    }

    if (strchr(perms, 'x') && strstr(line, "vdso") &&
        count < MAX_EXEC_REGIONS) {
      exec_regions[count].start = start;
      exec_regions[count].end = end;
      count++;
    }
  }

  fclose(fp);
  printf("Secure the Shellbox\n");

  for (int i = 0; i < count; i++) {
    __asm__ volatile("mov $10, %%rax\n\t" // SYS_mprotect = 10 (x86-64)
                     "mov %0, %%rdi\n\t"
                     "mov %1, %%rsi\n\t"
                     "mov $1, %%rdx\n\t"
                     "syscall\n\t"
                     :
                     : "r"(exec_regions[i].start),
                       "r"(exec_regions[i].end - exec_regions[i].start)
                     : "rax", "rdi", "rsi", "rdx");
  }
  return;
}

int main() {
  uint8_t *shellcode = (uint8_t *)0x100000000;
  uint8_t *max_map = (uint8_t *)0xffffffff000;

  srand(time(NULL));
  install_seccomp();

  size_t max_off = (max_map - shellcode) / 0x1000;
  size_t add_off = (rand() % max_off) * 0x1000;
  shellcode += add_off;

  if (mmap(shellcode, 0x1000, PROT_READ | PROT_WRITE,
           MAP_FIXED_NOREPLACE | MAP_ANONYMOUS | MAP_PRIVATE, -1,
           0) == MAP_FAILED) {
    perror("mmap failed");
    exit(EXIT_FAILURE);
  }

  unsigned char code[] = {
      0x48, 0x31, 0xc0,             // xor rax, rax
      0x48, 0x31, 0xdb,             // xor rbx, rbx
      0x48, 0x31, 0xc9,             // xor rcx, rcx
      0x48, 0x31, 0xd2,             // xor rdx, rdx
      0x48, 0x31, 0xf6,             // xor rsi, rsi
      0x48, 0x31, 0xff,             // xor rdi, rdi
      0x48, 0x31, 0xe4,             // xor rsp, rsp
      0x48, 0x31, 0xed,             // xor rbp, rbp
      0x4d, 0x31, 0xc0,             // xor r8,  r8
      0x4d, 0x31, 0xc9,             // xor r9,  r9
      0x4d, 0x31, 0xd2,             // xor r10, r10
      0x4d, 0x31, 0xdb,             // xor r11, r11
      0x4d, 0x31, 0xe4,             // xor r12, r12
      0x4d, 0x31, 0xed,             // xor r13, r13
      0x4d, 0x31, 0xf6,             // xor r14, r14
      0x4d, 0x31, 0xff,             // xor r15, r15
      0xf3, 0x48, 0x0f, 0xae, 0xd0, // wrfsbase rax
  };

  unsigned char endcode[] = {
      0xb8, 0x3c, 0x00, 0x00, 0x00, // mov eax, 60
      0x48, 0x31, 0xff,             // xor rdi, rdi
      0x0f, 0x05                    // syscall
  };

  printf("Please provide about 0x1000 bytes of input:\n");
  size_t max = 0x1000 - sizeof(code);
  size_t off = 0;

  while (off < max) {
    ssize_t n = read(STDIN_FILENO, shellcode + sizeof(code) + off, max - off);
    if (n < 0) {
      perror("read failed");
      exit(1);
    }
    if (n == 0)
      break;
    off += (size_t)n;
  }

  int shell_len = (int)off;
  close(0);

  if (!is_safe(shellcode)) {
    printf("Input is not Safe\n");
    exit(EXIT_FAILURE);
  }

  printf("Safe Input!\n");

  memcpy(shellcode, code, sizeof(code));
  memset(shellcode + sizeof(code) + shell_len, 0x90,
         0x1000 - sizeof(code) - shell_len);
  memcpy(shellcode + 0x1000 - sizeof(endcode), endcode, sizeof(endcode));
  if (mprotect(shellcode, 0x1000, PROT_READ | PROT_EXEC) != 0) {
    perror("mprotect failed");
    exit(EXIT_FAILURE);
  }

  safe_box(shellcode);

  void (*shell)() = (void (*)())shellcode;
  shell();
}
