const express = require('express');
const path = require('path');
const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const net = require('net');

function calculateChecksum(checksum) {
  const bytes = Buffer.from(checksum, 'hex');
  return bytes.reduce((sum, byte) => (sum + byte) % 256, 0).toString(16).padStart(2, '0');
}

app.get('/deliver', (req, res) => {
  const token = req.query.token;
  
  if (!token) {
    return res.status(400).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Error</title><link rel="stylesheet" href="/style.css"></head>
      <body>
        <div class="container">
          <h1>Delivery Failed</h1>
          <p>Missing delivery token.<p>
        </div>
      </body>
      </html>
    `);
  }

  const [pathHex, checksum] = token.split(':');
  if (calculateChecksum(pathHex) !== checksum) {
    return res.status(403).send(`
      <!DOCTYPE html>
      <html>
      <head><title>Error</title><link rel="stylesheet" href="/style.css"></head>
      <body>
        <div class="container">
          <h1>Delivery Failed</h1>
          <p>Invalid checksum.<p>
        </div>
      </body>
      </html>
    `);
  }

  let pathBytes;
  try {
    pathBytes = Buffer.from(token, 'hex');
  } catch (e) {
    return res.status(400).send('Invalid token format - must be hex');
  }

  const socket = net.createConnection(80, 'nginx', () => {
    const request = Buffer.concat([
      Buffer.from('GET ', 'utf8'),
      pathBytes,
      Buffer.from(' HTTP/1.1\r\n', 'utf8'),
      Buffer.from(`Host: warehouse\r\n`, 'utf8'),
      Buffer.from('Connection: close\r\n\r\n', 'utf8')
    ]);
    console.log('Connecting to warehouse with path:', pathBytes.toString('utf8'));
    socket.write(request);
  });

  let responseData = Buffer.alloc(0);
  socket.on('data', (data) => {
    responseData = Buffer.concat([responseData, data]);
  });

  socket.on('end', () => {
    const body = responseData.toString().split('\r\n\r\n')[1] || '';
    res.send(`
      <!DOCTYPE html>
      <html>
      <head><title>Delivery Result</title><link rel="stylesheet" href="/style.css"></head>
      <body>
        <div class="container">
          <h1>Delivery Report</h1>
          <div class="report">${body}</div>
          <p><a href="/">Back to start</a></p>
        </div>
      </body>
      </html>
    `);
  });

  socket.on('error', (err) => {
    res.status(500).send(`Delivery failed: ${err.message}`);
  });
});

app.listen(3000, '0.0.0.0', () => {
  console.log('Delivery system running on port 3000');
});
