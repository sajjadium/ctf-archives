const express = require('express');
const path = require('path');
const app = express();

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/42', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'chocolatecake.html'));
});

app.get('/101', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'vanillacake.html'));
});

app.get('/404', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'redvelvetcake.html'));
});

app.get('/500', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'cheesecake.html'));
});

app.get('/1337', (req, res) => {
  if (req.path == '/1337') {
    res.sendFile(path.join(__dirname, 'public', 'flagcake.html'));
  } else {
    res.status(403).send(`
      <div class="error">
        <h1>REQUEST REJECTED</h1>
        <p>Invalid delivery token format</p>
        <p>Our system detected suspicious activity</p>
      </div>
    `);
  }
});

app.listen(3001, '0.0.0.0', () => {
  console.log('Warehouse system running on port 3001');
});
