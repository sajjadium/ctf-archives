const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const { exec } = require('child_process');

const app = express();
app.use(helmet());
app.use(morgan('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); 
app.use(express.static(path.join(__dirname, 'public')));

app.locals.settings = {
    theme: 'brunsviger',
    glaze: 'brown-sugar',
    exportOptions: {
        timeout: 5000,
        maxBuffer: 1024 * 1024,
    }
};

function deepMerge(t, s) {
    for (const k of Object.keys(s)) {
        const v = s[k];
        if (v && typeof v === 'object' && !Array.isArray(v)) {
            if (!t[k]) t[k] = {};
            deepMerge(t[k], v); 
        } else {
            t[k] = v; 
        }
    }
    return t;
}

function sanitizeName(n) {
    n = String(n || '').toLowerCase();
    if (!/^[a-z0-9_-]{1,32}$/.test(n)) return null;
    return n;
}
function sanitizeFilename(n) {
    n = String(n || 'recipe.txt');
    if (!/^[a-zA-Z0-9_.-]{1,64}$/.test(n)) return null;
    return n;
}

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/api/settings', (req, res) => {
    try {
        deepMerge(app.locals.settings, req.body);

        if (
            app.locals.settings.exportOptions &&
            Object.prototype.hasOwnProperty.call(app.locals.settings.exportOptions, 'env')
        ) {
            delete app.locals.settings.exportOptions.env;
        }

        res.json({ ok: true, settings: app.locals.settings });
    } catch (e) {
        res.status(400).json({ ok: false, error: String(e) });
    }
});

app.post('/api/note', async (req, res) => {
    try {
        const name = sanitizeName(req.body.name);
        const filename = sanitizeFilename(req.body.filename || 'recipe.txt');
        if (!name || !filename) return res.status(400).json({ ok: false, error: 'bad name/filename' });

        const content = String(req.body.content || '');
        const makeExecutable = String(req.body.makeExecutable || '') === 'true';

        const dir = path.join(__dirname, 'data', name);
        await fsp.mkdir(dir, { recursive: true });

        const filePath = path.join(dir, filename);
        await fsp.writeFile(filePath, content, { mode: 0o644 });
        if (makeExecutable) {
            await fsp.chmod(filePath, 0o755); // "helper scripts" are allowed, right? :)
        }

        res.json({ ok: true, path: `data/${name}/${filename}` });
    } catch (e) {
        res.status(500).json({ ok: false, error: String(e) });
    }
});

app.get('/export', async (req, res) => {
    try {
        const name = sanitizeName(req.query.name);
        if (!name) return res.status(400).type('text/plain').send('Bad cake name');

        const dataDir = path.join(__dirname, 'data', name);
        const tmpDir = path.join(__dirname, 'tmp');
        await fsp.mkdir(tmpDir, { recursive: true });

        const quoted = "'" + name.replace(/'/g, "'\\''") + "'";
        const out = path.join('tmp', `${name}.zip`);
        const cmd = `zip -r ${out} ./data/${quoted}`; 

        const baseOpts = Object.assign({}, app.locals.settings.exportOptions || {});

        const envFromSettings = baseOpts.env || {};
        const env = Object.assign({}, process.env, envFromSettings);

        const opts = Object.assign({}, baseOpts, { cwd: __dirname, env });

        exec(cmd, opts, (err, stdout, stderr) => {
            res.type('text/plain').send(
                (stdout || '') + (stderr || '') + (err ? '\nERR\n' : '\nOK\n')
            );
        });
    } catch (e) {
        res.status(500).type('text/plain').send('Internal oven failure: ' + String(e));
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Brunsviger Bakery listening on http://127.0.0.1:${PORT}`);
});
