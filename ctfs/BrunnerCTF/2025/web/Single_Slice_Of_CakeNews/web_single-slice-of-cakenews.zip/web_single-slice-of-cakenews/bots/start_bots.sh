#!/bin/sh
python journalist_bot.py &
python admin_bot.py &
wait
