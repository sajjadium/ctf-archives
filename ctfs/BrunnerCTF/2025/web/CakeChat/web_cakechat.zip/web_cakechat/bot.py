import os
from flask import jsonify
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import time

FLAG = os.getenv('FLAG', 'brunner{test_flag}')

def visit_url(url):
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-extensions')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--disable-software-rasterizer')
    chrome_options.add_argument('--disable-dev-shm-usage')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--js-flags=--noexpose_wasm,--jitless')
    driver = webdriver.Chrome(options=chrome_options)
    try:
        driver.execute_cdp_cmd("Network.setCookie", {
            "name": "flag",
            "value": FLAG,
            "domain": "localhost",
            "path": "/",
            "httpOnly": True,
            "expires": int(time.time()) + 3600
        })

        driver.get(url)
        WebDriverWait(driver, 60).until(
            EC.presence_of_element_located((By.CLASS_NAME, "message")) 
        )
    except Exception as e:
        print("Error visiting page:", e, flush=True)
    finally:
        driver.quit()

def report(url):
    if not url or not isinstance(url, str) or not url.startswith("http"):
        return jsonify({'error': 'Invalid URL'})
    try:
        visit_url(url)
        return jsonify({'success': True})
    except Exception as e:
        print('Error on /report', e)
        return jsonify({'error': 'Failed to visit URL'})
