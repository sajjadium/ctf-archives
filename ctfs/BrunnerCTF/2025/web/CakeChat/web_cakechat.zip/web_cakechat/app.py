from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models import db, User, Chat, Message
from markdown import markdown
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import bot
import secrets 

app = Flask(__name__, instance_path="/tmp/flask_instance")
app.secret_key = secrets.token_hex(16)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:////tmp/app.db"

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

with app.app_context():
    db.create_all()
    if not User.query.filter_by(username='admin').first():
        db.session.add(User(username='admin', password=generate_password_hash(secrets.token_hex(16))))
        db.session.commit()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.template_filter('human_time')
def human_time(dt):
    now = datetime.now()
    delta = now - dt

    if delta.days == 0:
        return dt.strftime("Today at %-I:%M %p")
    elif delta.days == 1:
        return dt.strftime("Yesterday at %-I:%M %p")
    elif delta.days < 7:
        return f"{delta.days} days ago"
    else:
        return dt.strftime("%b %d, %Y at %-I:%M %p")

@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if User.query.filter_by(username=username).first():
            flash('Username already exists')
            return redirect(url_for('signup'))
        user = User(username=username, password=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            nextUrl = request.args.get('next', '')
            if not nextUrl or not nextUrl.startswith('/') or '@' in nextUrl:
                nextUrl = url_for('home')
            return redirect(nextUrl)
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/home')
@login_required
def home():
    chats = Chat.query.filter(
        (Chat.user1_id == current_user.id) | (Chat.user2_id == current_user.id)
    ).all()

    chat_partners = []
    for chat in chats:
        if chat.user1_id == current_user.id:
            other_user = User.query.get(chat.user2_id)
        else:
            other_user = User.query.get(chat.user1_id)
        chat_partners.append({'chat': chat, 'username': other_user.username})

    return render_template('home.html', chats=chat_partners)

@app.route('/new_chat', methods=['GET', 'POST'])
@login_required
def new_chat():
    users = User.query.filter(User.id != current_user.id).all()
    if request.method == 'POST':
        friend_id = int(request.form['friend_id'])
        existing = Chat.query.filter(
            ((Chat.user1_id == current_user.id) & (Chat.user2_id == friend_id)) |
            ((Chat.user1_id == friend_id) & (Chat.user2_id == current_user.id))
        ).first()
        if not existing:
            new = Chat(user1_id=current_user.id, user2_id=friend_id)
            db.session.add(new)
            db.session.commit()
        return redirect(url_for('home'))
    return render_template('new_chat.html', users=users)

@app.route('/chat/<int:chat_id>', methods=['GET', 'POST'])
@login_required
def chat(chat_id):
    chat = Chat.query.get_or_404(chat_id)

    if current_user.id not in [chat.user1_id, chat.user2_id]:
        return "Unauthorized", 403

    if request.method == 'POST':
        raw = request.form['message']
        msg = Message(
            chat_id=chat.id,
            sender_id=current_user.id,
            content=markdown(raw),
            timestamp=datetime.now()
        )
        db.session.add(msg)
        db.session.commit()

    messages = Message.query.filter_by(chat_id=chat.id).order_by(Message.timestamp.asc()).all()

    message_list = []
    for msg in messages:
        sender = User.query.get(msg.sender_id)
        message_list.append({
            'username': sender.username,
            'content': msg.content,
            'timestamp': msg.timestamp,
            'sender_id': msg.sender_id
        })

    return render_template('chat.html', current_user_id=current_user.id, messages=message_list, chat=chat, title=f"Chat with {User.query.get(chat.user2_id if chat.user1_id == current_user.id else chat.user1_id).username}")

@app.get("/report")
@login_required
def report():
    return bot.report(request.args.get('url'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
