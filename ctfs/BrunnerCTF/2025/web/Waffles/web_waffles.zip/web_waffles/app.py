from flask import Flask, send_file, jsonify, request
import os
import secrets

app = Flask(__name__, static_folder='static')

@app.get('/')
def index():
    return send_file('static/index.html')

PRODUCTS = [
    {
        'id': 1,
        'name': 'Wireless Headphones',
        'price': 99.99,
        'description': 'High-quality wireless headphones with noise cancellation',
        'image': '/static/images/headphones.webp',
        'stock': 10
    },
    {
        'id': 2,
        'name': 'Smartphone Case',
        'price': 24.99,
        'description': 'Durable protective case for your smartphone',
        'image': '/static/images/phonecase.webp',
        'stock': 25
    },
    {
        'id': 3,
        'name': 'Bluetooth Speaker',
        'price': 79.99,
        'description': 'Portable Bluetooth speaker with excellent sound quality',
        'image': '/static/images/bluetoothspeaker.webp',
        'stock': 15
    },
    {
        'id': 4,
        'name': 'USB Cable',
        'price': 12.99,
        'description': 'Fast charging USB-C cable, 2 meters long',
        'image': '/static/images/usbc.webp',
        'stock': 50
    },
    {
        'id': 5,
        'name': 'Laptop Stand',
        'price': 45.99,
        'description': 'Adjustable aluminum laptop stand for better ergonomics',
        'image': '/static/images/stand.webp',
        'stock': 8
    },
    {
        'id': 6,
        'name': 'Wireless Mouse',
        'price': 34.99,
        'description': 'Ergonomic wireless mouse with precision tracking',
        'image': '/static/images/mouse.webp',
        'stock': 20
    }
]

# In-memory storage for baskets (in production, use a database)
baskets = {}

# API Routes
@app.route('/api/products', methods=['GET'])
def get_products():
    """Get all products"""
    return jsonify(PRODUCTS)

@app.route('/api/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = next((p for p in PRODUCTS if p['id'] == product_id), None)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    return jsonify(product)

@app.route('/api/basket', methods=['GET', 'POST'])
def get_basket():
    if request.method == "GET":
        session_id = request.headers.get('X-Session-ID', None)
        basket = baskets.get(session_id, None)
        if not session_id or not basket:
            return jsonify({'error': 'Basket not found'}), 404
        return jsonify(basket)
    else:
        session_id = secrets.token_hex(32)
        baskets[session_id] = {'items': [], 'total': 0}
        return jsonify(session_id)

@app.route('/api/basket/add', methods=['POST'])
def add_to_basket():
    data = request.get_json()
    session_id = request.headers.get('X-Session-ID', None)
    basket = baskets.get(session_id, None)
    if not session_id or not basket:
        return jsonify({'error': 'Basket not found'}), 404
    
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    # Find the product
    product = next((p for p in PRODUCTS if p['id'] == product_id), None)
    if not product:
        return jsonify({'error': 'Product not found'}), 404
    
    # Check stock
    if product['stock'] < quantity:
        return jsonify({'error': 'Insufficient stock'}), 400
           
    # Check if item already in basket
    existing_item = next((item for item in basket['items'] if item['product_id'] == product_id), None)
    
    if existing_item:
        existing_item['quantity'] += quantity
    else:
        basket['items'].append({
            'product_id': product_id,
            'name': product['name'],
            'price': product['price'],
            'quantity': quantity
        })
    
    # Recalculate total
    basket['total'] = sum(item['price'] * item['quantity'] for item in basket['items'])
    
    return jsonify(basket)

@app.route('/api/basket/remove', methods=['POST'])
def remove_from_basket():
    data = request.get_json()
    session_id = request.headers.get('X-Session-ID', None)
    basket = baskets.get(session_id, None)
    if not session_id or not basket:
        return jsonify({'error': 'Basket not found'}), 404
    product_id = data.get('product_id')
    
    if session_id not in baskets:
        return jsonify({'error': 'Basket not found'}), 404
    
    basket['items'] = [item for item in basket['items'] if item['product_id'] != product_id]
    
    # Recalculate total
    basket['total'] = sum(item['price'] * item['quantity'] for item in basket['items'])
    
    return jsonify(basket)

@app.route('/api/basket/update', methods=['POST'])
def update_basket_item():
    data = request.get_json()
    session_id = request.headers.get('X-Session-ID', None)
    basket = baskets.get(session_id, None)
    if not session_id or not basket:
        return jsonify({'error': 'Basket not found'}), 404
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    if session_id not in baskets:
        return jsonify({'error': 'Basket not found'}), 404

    item = next((item for item in basket['items'] if item['product_id'] == product_id), None)
    
    if not item:
        return jsonify({'error': 'Item not found in basket'}), 404
    
    if quantity <= 0:
        basket['items'] = [item for item in basket['items'] if item['product_id'] != product_id]
    else:
        item['quantity'] = quantity
    
    # Recalculate total
    basket['total'] = sum(item['price'] * item['quantity'] for item in basket['items'])
    
    return jsonify(basket)

@app.route('/api/checkout', methods=['POST'])
def checkout():
    session_id = request.headers.get('X-Session-ID', None)
    basket = baskets.get(session_id, None)
    if not session_id or not basket:
        return jsonify({'error': 'Basket not found'}), 404
    
    # Check if basket is empty
    if not basket['items']:
        return jsonify({'error': 'Cannot checkout with an empty basket'}), 400
    
    # Check if basket requires payment (total > 0)
    if basket['total'] > 0:
        return jsonify({'error': 'Payment processing failed. Please try again later.'}), 402
    
    order_id = os.environ.get('FLAG', 'brunner{REDACTED}')
    
    # Clear the basket
    baskets[session_id] = None
    
    return jsonify({
        'success': True,
        'order_id': order_id,
        'message': 'Order processed successfully!'
    })

if __name__ == "__main__":
    app.run("0.0.0.0", port=1337)
