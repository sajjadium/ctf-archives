export default function Home() {
    const flag = "brunner{REDACTED}"
  return (
        <span>{flag}</span>
  );
}
