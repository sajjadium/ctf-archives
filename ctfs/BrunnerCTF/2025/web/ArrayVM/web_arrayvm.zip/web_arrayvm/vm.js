const fs = require('node:fs');

class ArrayVM {
	constructor() {
		// All data is here
		this.backing = new Array();
		this.backing[-1] = fs.readFileSync("./flag.txt");
		this.arrays = [];
		this.outBuf = "";

		this.instructions = {
			NEW: (size) => {
				// Calculate new backing array position from size of last array
				let newBacking;
				if (this.arrays.length == 0) {
					newBacking = 0;
				} else {
					const lastBacking = this.arrays.at(-1);
					const lastSize = this.backing[lastBacking];
					newBacking = lastBacking + lastSize + 1;
				}

				// Save backing index
				this.arrays.push(newBacking);
				// Save size in backing
				this.backing[newBacking] = this._parseNumber(size);
			},

			INIT: (refIndex, value) => {
				const [ref, idx] = this._parseRefIndex(refIndex);
				this.backing[this._refIdxToBacking(ref, idx)] = this._parseNumber(value);
			},

			ADD: (src1, src2, dest) => {
				const [ref1, idx1] = this._parseRefIndex(src1);
				const [ref2, idx2] = this._parseRefIndex(src2);
				const [refd, idxd] = this._parseRefIndex(dest);
				this.backing[this._refIdxToBacking(refd, idxd)] =
					this.backing[this._refIdxToBacking(ref1, idx1)] + this.backing[this._refIdxToBacking(ref2, idx2)];
			},

			SUB: (src1, src2, dest) => {
				const [ref1, idx1] = this._parseRefIndex(src1);
				const [ref2, idx2] = this._parseRefIndex(src2);
				const [refd, idxd] = this._parseRefIndex(dest);
				this.backing[this._refIdxToBacking(refd, idxd)] =
					this.backing[this._refIdxToBacking(ref1, idx1)] - this.backing[this._refIdxToBacking(ref2, idx2)];
			},

			PRINT: (refIndex) => {
				const [ref, idx] = this._parseRefIndex(refIndex);
				const val = this.backing[this._refIdxToBacking(ref, idx)];
				this.outBuf += val + "\n";
			}
		};
	}

	_parseRefIndex(refIndex) {
		if (!refIndex.match(/^\d+\.\d+$/)) throw new Error(`Incorrect array reference/index: ${refIndex}`)
		const [refStr, idxStr] = refIndex.split(".");
		return [Number(refStr), Number(idxStr)];
	}

	_parseNumber(number) {
		if (!number.match(/^\d+$/)) throw new Error(`Incorrect number: ${number}`)
		return Number(number);
	}

	_refIdxToBacking(ref, idx) {
		const backingIdx = this.arrays[ref];
		if (backingIdx == undefined) throw new Error(`Array not found: ${ref}`)
		const arrSize = this.backing[backingIdx];

		// Make sure we are within bounds
		if (!(idx < arrSize)) throw new Error(`Array ${ref} is not large enough for indexing ${idx}. Size: ${arrSize}`)

		// Add 1 to skip size of arr as that is stored inline
		return backingIdx + idx + 1;
	}

	run(code) {
		const lines = code
			.split(/\n/)
			.map(l => l.trim())
			.filter(l => l && !l.startsWith("#"));

		if (lines.length > 100) throw new Error("We don't support programs that large at the moment.");

		for (const line of lines) {
			const [op, ...args] = line.split(/\s+/);
			if (!this.instructions.hasOwnProperty(op)) throw new Error(`Unknown instruction: ${op}`);
			const instr = this.instructions[op];
			instr(...args);
		}

		return this.outBuf;
	}
}

module.exports = ArrayVM;
