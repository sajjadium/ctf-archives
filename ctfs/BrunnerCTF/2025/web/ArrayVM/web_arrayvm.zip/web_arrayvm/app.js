const express = require('express');
const bodyParser = require('body-parser');
const ArrayVM = require('./vm');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
	res.sendFile(__dirname + '/index.html');
});

app.post('/run', (req, res) => {
	const code = req.body.code || '';
	const vm = new ArrayVM;
	let result;

	try {
		result = vm.run(code);
	} catch (error) {
		result = error.toString();
	}

	res.send(result);
});

const PORT = 5000;
app.listen(PORT, () => {
	console.log(`Server running at http://localhost:${PORT}`);
});
