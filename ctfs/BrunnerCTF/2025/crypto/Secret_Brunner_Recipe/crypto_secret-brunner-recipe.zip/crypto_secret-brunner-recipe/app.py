from flask import Flask, request
import os
import tenseal as ts

context = ts.context(
    ts.SCHEME_TYPE.BFV,
    poly_modulus_degree=8192,
    plain_modulus=1032193
)

recipe = os.environ.get("SECRET", "one tbsp of flour and a cup of brunner{test_flag}")
assert all(c in "_ abcdefghijklmnopqrstuvwxyz{}" for c in recipe)
recipeenc = ts.bfv_vector(context, [*recipe.encode()])

app = Flask(__name__)

@app.get("/public")
def public():
    public_context = context.copy()
    public_context.make_context_public()
    return public_context.serialize(save_public_key=True, save_secret_key=False, save_galois_keys=False, save_relin_keys=False)

@app.get("/secretrecipe")
def secretrecipe():
    return recipeenc.serialize()

@app.post("/isTerrible")
def isTerrible():
    try:
        input = ts.bfv_vector_from(context, request.get_data())
        return str("flødeskum" in "".join([chr(c) for c in input.decrypt()]))
    except:
        return "False"

if __name__ == "__main__":
    app.run(host="0.0.0.0")
