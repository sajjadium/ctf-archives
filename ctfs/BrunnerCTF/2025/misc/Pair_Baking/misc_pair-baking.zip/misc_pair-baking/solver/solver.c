#include <stdio.h>

int main() {
    printf("Hello World!");
    return 0;
}
