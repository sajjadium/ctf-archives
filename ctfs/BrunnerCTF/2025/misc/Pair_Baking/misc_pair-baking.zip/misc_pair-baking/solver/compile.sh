musl-gcc -static -o solver solver.c
