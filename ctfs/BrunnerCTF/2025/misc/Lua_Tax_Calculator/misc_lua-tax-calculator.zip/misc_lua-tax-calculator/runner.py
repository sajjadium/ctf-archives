#!/usr/bin/env python3
import os
import subprocess
import tempfile

def main():
    print("Tax time! :)")
    print("Math library is available. Example: 2 + math.sqrt(4)")
    while True:
        try:
            print("\nEnter your tax calculation:")
            payload = input()

            if ";" in payload:
                print("\nError: Nuh-uh, you only get ONE expression")
                continue

            with open("main.luau", "r") as f:
                source_code = f.read()

            modified_code = source_code.replace("<INSERT_CODE_HERE>", payload)

            fd, temp_path = tempfile.mkstemp(suffix=".luau")
            os.close(fd)

            with open(temp_path, "w") as f:
                f.write(modified_code)

            try:
                result = subprocess.run(["luau", temp_path], capture_output=True, text=True, timeout=1)
                print("\nResult:")
                print(result.stdout)

                if result.stderr:
                    print("\nErrors:")
                    print(result.stderr)
            except subprocess.TimeoutExpired:
                print("\nError: That takes wayyy too long")
            finally:
                if os.path.exists(temp_path):
                    os.remove(temp_path)

        except (EOFError, KeyboardInterrupt):
            break
        except Exception as e:
            print(f"\nError: {e}")

if __name__ == "__main__":
    main()
