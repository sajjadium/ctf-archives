# Brunnerne are ready to broadcast!
# We share the radio-space with others and all messages get mixed up.
# But don't worry, each transmission is broadcast on a different frequency,
# so the signals can be separated at the receiver end
from secret import transmissions

assert len(transmissions) == 9
assert "brunner{" in "".join(transmissions)
bytelen_transmission = 36
assert all(len(t) == bytelen_transmission for t in transmissions)

# As the baking enthusiasts we are, we couldn't help but partially home cook
# our own simplified broadcasting mechanics, transmitting one bit at a time :-)
bits = [[int(b) for c in t for b in f"{ord(c):08b}"] for t in transmissions]

# Each package is retransmitted multiple times before moving on:
bit_repetition_period = 100
bit_length = bytelen_transmission * 8

# Okay, let's get ready to broadcast:
# Sequential Matrix Of Aggregate Bit-transmissions
smoab = [
    [0 for _ in range(bit_repetition_period)]
    for _ in range(bit_length)
]

for i in range(len(transmissions)):
    wavelength = i + 1
    for j in range(bit_length):
        k = wavelength
        while k <= bit_repetition_period:
            smoab[j][k - 1] += bits[i][j]
            k += wavelength

# ... aaand we're on! :-D
with open("total_broadcast.txt", "w") as f:
    f.write(
        "\n".join(
            "".join(str(sum_of_bits) for sum_of_bits in aggregated_repeated_bits)
            for aggregated_repeated_bits in smoab
        )
    )
