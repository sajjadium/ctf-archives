#!/usr/bin/env python3

import hashlib
import math
import secrets
import struct
from dataclasses import dataclass

import numpy as np
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from secret import FLAG, MASTER_SECRET


MIN_SIDE = 1
MAX_SIDE = 65535
ROUNDS = 8
FIXED_ANGLE = math.atan2(4.0, 3.0)


@dataclass(frozen=True)
class Triangle:
    a: int
    b: int
    c: int

    @classmethod
    def from_input(cls) -> "Triangle":
        return cls(
            a=cls.read_side("A"),
            b=cls.read_side("B"),
            c=cls.read_side("C"),
        )

    @staticmethod
    def read_side(name: str) -> int:
        value = int(input(f"Side {name}: ").strip())

        if not MIN_SIDE <= value <= MAX_SIDE:
            raise ValueError(
                f"Side {name} must be between {MIN_SIDE} and {MAX_SIDE}"
            )

        return value

    @property
    def angles(self) -> tuple[np.float64, np.float64, np.float64]:
        a = np.float64(self.a)
        b = np.float64(self.b)
        c = np.float64(self.c)

        with np.errstate(invalid="ignore"):
            alpha = np.arccos((b * b + c * c - a * a) / (2.0 * b * c))
            beta = np.arccos((a * a + c * c - b * b) / (2.0 * a * c))
            gamma = np.arccos((a * a + b * b - c * c) / (2.0 * a * b))

        return alpha, beta, gamma

    def serialize(self) -> bytes:
        return struct.pack(">III", self.a, self.b, self.c)


def initial_state() -> np.ndarray:
    digest = hashlib.sha512(
        b"TriKDF secret state\x00" + MASTER_SECRET
    ).digest()

    state = []
    for position in range(0, len(digest), 8):
        word = int.from_bytes(digest[position : position + 8], "big")
        value = ((word + 0.5) / 2**64) * 2.0 - 1.0
        state.append(np.float64(value))

    return np.array(state, dtype=np.float64)


def rotate(
    state: np.ndarray,
    first: int,
    second: int,
    angle: np.float64,
) -> None:
    cosine = np.cos(angle)
    sine = np.sin(angle)

    x = state[first]
    y = state[second]

    state[first] = cosine * x - sine * y
    state[second] = sine * x + cosine * y


def triangular_mix(triangle: Triangle) -> np.ndarray:
    alpha, beta, gamma = triangle.angles
    state = initial_state()

    for _ in range(ROUNDS):
        rotate(state, 0, 1, alpha)
        rotate(state, 2, 3, beta)
        rotate(state, 4, 5, gamma)
        rotate(state, 6, 7, alpha + beta + gamma)

        rotate(state, 0, 2, FIXED_ANGLE)
        rotate(state, 1, 3, FIXED_ANGLE)
        rotate(state, 4, 6, FIXED_ANGLE)
        rotate(state, 5, 7, FIXED_ANGLE)

        state[:] = state[[0, 4, 1, 5, 2, 6, 3, 7]]

    return state


def derive_key(triangle: Triangle) -> bytes:
    state = triangular_mix(triangle)

    return hashlib.sha256(
        b"TriKDF-v1 AES-256\x00"
        + triangle.serialize()
        + np.abs(state).astype("<f8", copy=False).tobytes()
    ).digest()


def print_encryption(plaintext: bytes, triangle: Triangle) -> None:
    key = derive_key(triangle)
    nonce = secrets.token_bytes(12)
    ciphertext = AESGCM(key).encrypt(nonce, plaintext, None)

    print()
    print(f"nonce={nonce.hex()}")
    print(f"ciphertext={ciphertext.hex()}")


def read_triangle() -> Triangle:
    print(
        f"Enter three strategic side lengths between "
        f"{MIN_SIDE} and {MAX_SIDE}."
    )

    return Triangle.from_input()


def encrypt_message() -> None:
    triangle = read_triangle()
    message = input("Business-critical data: ").encode()
    print_encryption(message, triangle)


def encrypt_flag() -> None:
    triangle = read_triangle()
    print_encryption(FLAG, triangle)


def main() -> None:
    print("TriKDF Enterprise v1.0")
    print("Triangle-driven cryptographic alignment at scale.")

    while True:
        print()
        print("1) Protect business-critical data")
        print("2) Secure the executive recipe")
        print("3) End session")

        try:
            choice = input("> ").strip()

            if choice == "1":
                encrypt_message()
            elif choice == "2":
                encrypt_flag()
            elif choice == "3":
                return
            else:
                print("Unsupported business requirement")

        except ValueError as error:
            print(f"Input error: {error}")
        except EOFError:
            return
        except KeyboardInterrupt:
            print()
            return


if __name__ == "__main__":
    main()
