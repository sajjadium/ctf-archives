#!/usr/bin/env python3
import base64
import os
import subprocess
import tempfile
import threading

from flask import Flask, render_template, request

RUN = "/opt/ev3/emulator/run.sh"
TIMEOUT = int(os.environ.get("EV3_TIMEOUT", "12"))

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 512 * 1024

lock = threading.Lock()


def run(data, ext):
    with tempfile.TemporaryDirectory() as d:
        prog = os.path.join(d, "prog" + ext)
        out = os.path.join(d, "shot.png")
        with open(prog, "wb") as f:
            f.write(data)
        with lock:
            subprocess.run(
                [RUN, prog, out],
                timeout=TIMEOUT + 20,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        with open(out, "rb") as f:
            return f.read()


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "GET":
        return render_template("index.html", shot=None, error=None)

    f = request.files.get("program")
    if not f or not f.filename:
        return render_template("index.html", shot=None, error="No file?"), 400
    if os.path.splitext(f.filename)[1].lower() not in (".rbf", ".lms"):
        return render_template(
            "index.html", shot=None, error="Upload a .rbf (or .lms)."
        ), 400

    data = f.read()
    if not data:
        return render_template("index.html", shot=None, error="Empty file."), 400

    try:
        png = run(data, os.path.splitext(f.filename)[1].lower())
    except Exception:
        return render_template("index.html", shot=None, error="Couldn't run that."), 500

    return render_template(
        "index.html", shot=base64.b64encode(png).decode(), error=None
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80, threaded=True)
