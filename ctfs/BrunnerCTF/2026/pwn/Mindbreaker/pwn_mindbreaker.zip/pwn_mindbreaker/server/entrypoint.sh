#!/bin/bash
set -e

ROOT=/opt/ev3/rootfs

FLAG="${FLAG:-$(cat /flag.txt 2>/dev/null || echo 'brunner{REDACTED}')}"
printf '%s' "$FLAG" > "$ROOT/flag.txt"
chown 1000:1000 "$ROOT/flag.txt"
chmod 000 "$ROOT/flag.txt"

exec gunicorn --chdir /opt/ev3/server --bind 0.0.0.0:80 \
    --workers 1 --threads 8 --timeout 120 app:app
