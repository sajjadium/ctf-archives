#!/usr/bin/env python3
import sys
import zlib
import struct

W, H, ROW = 178, 128, 60

UNPACK = {
    0x00: 0b000,
    0xE0: 0b001,
    0x1C: 0b010,
    0xFC: 0b011,
    0x03: 0b100,
    0xE3: 0b101,
    0x1F: 0b110,
    0xFF: 0b111,
}


def decode(data):
    rows = []
    for y in range(H):
        base = y * ROW
        row = []
        for bx in range(ROW):
            b = data[base + bx] if base + bx < len(data) else 0
            bits = UNPACK.get(b, 0)
            row += [bits & 1, (bits >> 1) & 1, (bits >> 2) & 1]
        rows.append(row[:W])
    return rows


def write_png(path, rows, scale=3):
    w, h = W * scale, H * scale
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        src = rows[y // scale]
        for x in range(w):
            raw.append(0 if src[x // scale] else 210)
    comp = zlib.compress(bytes(raw), 9)

    def chunk(tag, payload):
        return (
            struct.pack(">I", len(payload))
            + tag
            + payload
            + struct.pack(">I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
        )

    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0)))
        f.write(chunk(b"IDAT", comp))
        f.write(chunk(b"IEND", b""))


if __name__ == "__main__":
    fb, out = sys.argv[1], sys.argv[2]
    with open(fb, "rb") as f:
        write_png(out, decode(f.read()))
