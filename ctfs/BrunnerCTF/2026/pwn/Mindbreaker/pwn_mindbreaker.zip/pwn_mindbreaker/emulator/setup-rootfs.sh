#!/bin/bash
set -e

FW="$1"
ROOT="$2"

binwalk -e --run-as=root -C /tmp/bw "$FW" >/tmp/binwalk.log 2>&1 || true
CRAMFS=$(ls /tmp/bw/_*.extracted/*.cramfs 2>/dev/null | grep -v '\.swap$' | head -1)
[ -n "$CRAMFS" ] || { echo "binwalk found no cramfs in $FW" >&2; exit 1; }
echo "[*] cramfs: $CRAMFS ($(stat -c%s "$CRAMFS") bytes)"

rm -rf "$ROOT"
mkdir -p "$(dirname "$ROOT")"
VM="$ROOT/home/root/lms2012/sys/lms2012"

fsck.cramfs --extract="$ROOT" "$CRAMFS" 2>/tmp/cramfs.log || echo "[i] fsck.cramfs exit $?"
[ -f "$VM" ] || { echo "no lms2012 binary after extract" >&2; exit 1; }
echo "[*] got VM: $VM"

DEV="$ROOT/dev"
mkdir -p "$DEV"
for d in lms_pwm lms_motor lms_analog lms_power lms_ui lms_uart lms_iic \
         lms_dcm lms_sound lms_usbdev lms_usbhost lms_bt lms_update; do
    rm -f "$DEV/$d"; truncate -s 1M "$DEV/$d"; chmod 666 "$DEV/$d"
done
printf '\034\014' | dd of="$DEV/lms_analog" bs=1 seek=30 conv=notrunc status=none
rm -f "$DEV/fb0"; truncate -s 64K "$DEV/fb0"; chmod 666 "$DEV/fb0"
mkdir -p "$ROOT/proc"
printf 'rootfs / rootfs rw 0 0\nproc /proc proc rw,nosuid,nodev,noexec 0 0\n' > "$ROOT/proc/mounts"
mkdir -p "$ROOT/dev/bus/usb" "$ROOT/sys/bus/usb/devices"
[ -e "$DEV/null" ]    || mknod -m 666 "$DEV/null"    c 1 3 2>/dev/null || truncate -s 0 "$DEV/null"
[ -e "$DEV/zero" ]    || mknod -m 666 "$DEV/zero"    c 1 5 2>/dev/null || true
[ -e "$DEV/urandom" ] || mknod -m 666 "$DEV/urandom" c 1 9 2>/dev/null || true

SYS="$ROOT/home/root/lms2012/sys"
LMS="$ROOT/home/root/lms2012"
rm -rf "$SYS/settings"; mkdir -p "$SYS/settings"
printf 'EV3'          > "$SYS/settings/BrickName"
printf '001629c9d3f6' > "$SYS/settings/BTser"
printf 'V1.09H'       > "$SYS/settings/HwId"
rm -rf "$LMS/prjs" "$LMS/apps"
mkdir -p "$LMS/prjs/BrkProg_SAVE" "$LMS/apps" "$ROOT/mnt/ramdisk"

chmod -R a+rX "$ROOT"
chmod 0777 "$LMS/prjs" "$LMS/prjs/BrkProg_SAVE" "$ROOT/mnt/ramdisk"

printf 'brunner{REDACTED}' > "$ROOT/flag.txt"
chown 1000:1000 "$ROOT/flag.txt"
chmod 000 "$ROOT/flag.txt"

echo "[*] done"
