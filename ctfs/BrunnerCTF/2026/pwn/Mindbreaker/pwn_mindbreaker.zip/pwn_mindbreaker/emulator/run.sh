#!/bin/bash
set -e

ROOT=/opt/ev3/rootfs
TIMEOUT="${EV3_TIMEOUT:-12}"

PROG="$1"
OUT="$2"

FB="$ROOT/dev/fb0"
UI="$ROOT/dev/lms_ui"
PRJS="$ROOT/home/root/lms2012/prjs"

case "$PROG" in
  *.lms)
    rbf=$(mktemp /tmp/prog.XXXXXX.rbf)
    lmsasm -output "$rbf" "$PROG" >&2
    PROG="$rbf"
    ;;
esac

cp -f "$PROG" "$PRJS/prog.rbf"
chown 1000:1000 "$PRJS/prog.rbf"
chmod 666 "$PRJS/prog.rbf"

chown 1000:1000 "$ROOT/flag.txt"
chmod 000 "$ROOT/flag.txt"

: > "$FB"; truncate -s 64K "$FB"; chmod 666 "$FB"
printf '\0\0\0\0\0\0' | dd of="$UI" bs=1 conv=notrunc status=none

inner="cd /home/root/lms2012/sys && exec /bin/busybox_x86 timeout -s KILL $TIMEOUT \
  /usr/bin/qemu-arm-static -E LD_PRELOAD=/fbshim.so \
  -E LD_LIBRARY_PATH=/home/root/lms2012/sys/lib ./lms2012 ../prjs/prog"

script -qefc "chroot --userspec=1000:1000 '$ROOT' /bin/busybox_x86 sh -c \"$inner\"" \
  /dev/null >/tmp/vm.log 2>&1 || true

python3 /opt/ev3/emulator/ev3lcd.py "$FB" "$OUT" >/dev/null 2>&1 || true
[ -f "$OUT" ]
