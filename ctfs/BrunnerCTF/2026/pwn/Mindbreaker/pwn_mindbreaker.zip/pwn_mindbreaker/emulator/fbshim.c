#define _GNU_SOURCE
#include <stdint.h>
#include <stdarg.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define SYS_open   5
#define SYS_close  6
#define SYS_ioctl  54

static inline long sys3(long n, long a, long b, long c)
{
    register long r7 __asm__("r7") = n;
    register long r0 __asm__("r0") = a;
    register long r1 __asm__("r1") = b;
    register long r2 __asm__("r2") = c;
    __asm__ volatile("svc #0" : "+r"(r0) : "r"(r7), "r"(r1), "r"(r2) : "memory");
    return r0;
}

#define FB_XRES        178
#define FB_YRES        128
#define FB_LINE_LENGTH 60
#define FB_SMEM_LEN    (FB_YRES * FB_LINE_LENGTH)

#define FBIOGET_VSCREENINFO 0x4600
#define FBIOGET_FSCREENINFO 0x4602

struct sh_fb_bitfield { uint32_t offset, length, msb_right; };
struct sh_fb_var_screeninfo {
    uint32_t xres, yres, xres_virtual, yres_virtual, xoffset, yoffset;
    uint32_t bits_per_pixel, grayscale;
    struct sh_fb_bitfield red, green, blue, transp;
    uint32_t nonstd, activate, height, width, accel_flags, pixclock;
    uint32_t left_margin, right_margin, upper_margin, lower_margin;
    uint32_t hsync_len, vsync_len, sync, vmode, rotate, colorspace, reserved[4];
};
struct sh_fb_fix_screeninfo {
    char id[16];
    unsigned long smem_start;
    uint32_t smem_len, type, type_aux, visual;
    uint16_t xpanstep, ypanstep, ywrapstep;
    uint32_t line_length;
    unsigned long mmio_start;
    uint32_t mmio_len, accel;
    uint16_t capabilities, reserved[2];
};

#define MAX_FB 8
static int fb_fds[MAX_FB];
static int fb_count = 0;

static int streq(const char *a, const char *b)
{
    while (*a && (*a == *b)) { a++; b++; }
    return (*a == 0 && *b == 0);
}
static int is_fb0(const char *p) { return p && streq(p, "/dev/fb0"); }
static int is_fb_fd(int fd)
{
    for (int i = 0; i < fb_count; i++) if (fb_fds[i] == fd) return 1;
    return 0;
}

#define HOST_BUSYBOX "/bin/busybox_x86"

extern char **environ;

static char **strip_ld_env(void)
{
    size_t n = 0;
    while (environ[n]) n++;
    char **out = malloc((n + 1) * sizeof(char *));
    if (!out) return NULL;
    size_t j = 0;
    for (size_t i = 0; i < n; i++) {
        if (!strncmp(environ[i], "LD_PRELOAD=", 11)) continue;
        if (!strncmp(environ[i], "LD_LIBRARY_PATH=", 16)) continue;
        out[j++] = environ[i];
    }
    out[j] = NULL;
    return out;
}

int system(const char *command)
{
    if (command == NULL)
        return syscall(SYS_access, HOST_BUSYBOX, X_OK) == 0;

    char **env = strip_ld_env();
    if (!env) return -1;

    pid_t pid = (pid_t)syscall(SYS_fork);
    if (pid < 0) { free(env); return -1; }

    if (pid == 0) {
        syscall(SYS_dup2, STDOUT_FILENO, STDERR_FILENO);
        char *argv[] = { HOST_BUSYBOX, "sh", "-c", (char *)command, NULL };
        syscall(SYS_execve, HOST_BUSYBOX, argv, env);
        syscall(SYS_exit, 127);
        __builtin_unreachable();
    }

    int status = 0;
    while (syscall(SYS_wait4, pid, &status, 0, NULL) != pid) {
        if (errno != EINTR) { free(env); return -1; }
    }
    free(env);
    return status;
}

int open(const char *path, int flags, ...)
{
    va_list ap; va_start(ap, flags); int mode = va_arg(ap, int); va_end(ap);
    int fd = (int)sys3(SYS_open, (long)path, flags, mode);
    if (fd >= 0 && is_fb0(path) && fb_count < MAX_FB) fb_fds[fb_count++] = fd;
    return fd;
}
int open64(const char *path, int flags, ...)
{
    va_list ap; va_start(ap, flags); int mode = va_arg(ap, int); va_end(ap);
    int fd = (int)sys3(SYS_open, (long)path, flags, mode);
    if (fd >= 0 && is_fb0(path) && fb_count < MAX_FB) fb_fds[fb_count++] = fd;
    return fd;
}
int close(int fd)
{
    for (int i = 0; i < fb_count; i++)
        if (fb_fds[i] == fd) { fb_fds[i] = fb_fds[--fb_count]; break; }
    return (int)sys3(SYS_close, fd, 0, 0);
}

int ioctl(int fd, unsigned long request, ...)
{
    va_list ap; va_start(ap, request); void *arg = va_arg(ap, void *); va_end(ap);
    if (!is_fb_fd(fd))
        return (int)sys3(SYS_ioctl, fd, (long)request, (long)arg);

    if (request == FBIOGET_VSCREENINFO) {
        struct sh_fb_var_screeninfo *v = arg;
        v->xres = v->xres_virtual = FB_XRES;
        v->yres = v->yres_virtual = FB_YRES;
        v->bits_per_pixel = 8;
        return 0;
    }
    if (request == FBIOGET_FSCREENINFO) {
        struct sh_fb_fix_screeninfo *f = arg;
        memcpy(f->id, "ev3fb", 6);
        f->smem_len = FB_SMEM_LEN;
        f->line_length = FB_LINE_LENGTH;
        return 0;
    }
    return 0;
}

int libusb_handle_events_timeout(void *c, void *t) { (void)c;(void)t; return 0; }
int libusb_handle_events_timeout_completed(void *c, void *t, int *x) { (void)c;(void)t;(void)x; return 0; }
int libusb_handle_events(void *c) { (void)c; return 0; }
int libusb_handle_events_completed(void *c, int *x) { (void)c;(void)x; return 0; }
int libusb_get_next_timeout(void *c, void *t) { (void)c;(void)t; return 0; }
long libusb_get_device_list(void *c, void ***l) { (void)c; if (l) *l = 0; return 0; }
void libusb_free_device_list(void **l, int u) { (void)l;(void)u; }

int chmod(const char *path, unsigned int mode)  { (void)path; (void)mode; return 0; }
int fchmod(int fd, unsigned int mode)           { (void)fd; (void)mode; return 0; }
int fchmodat(int dfd, const char *path, unsigned int mode, int flags)
{ (void)dfd; (void)path; (void)mode; (void)flags; return 0; }

int statvfs(const char *path, void *buf)
{
    (void)path;
    unsigned char *p = buf;
    for (int i = 0; i < 56; i++) p[i] = 0;
    ((uint32_t *)buf)[0] = 1024;
    ((uint32_t *)buf)[1] = 1024;
    return 0;
}
int statvfs64(const char *path, void *buf) { return statvfs(path, buf); }
