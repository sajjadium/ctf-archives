<?php get_header(); ?>
<main class="content-wrap">
    <section>
        <div class="eyebrow">Internal knowledge base · v0.1</div>
        <h1>Useful notes for<br>unusual deploys.</h1>
        <?php if (have_posts()): ?>
            <?php while (have_posts()): the_post(); ?>
                <article class="post">
                    <div class="post-meta"><?php echo esc_html(get_the_date('Y-m-d')); ?> · <?php the_author(); ?></div>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <?php the_excerpt(); ?>
                </article>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No documentation yet. This is either a fresh install or a very successful outage.</p>
        <?php endif; ?>
    </section>
    <aside class="sidebar">
        <h3>Quick links</h3>
        <ul>
            <li><a href="<?php echo esc_url(home_url('/')); ?>">Docs home</a></li>
            <li><a href="<?php echo esc_url(home_url('/wp-json/')); ?>">API index</a></li>
            <li>Pager: ask the person who merged it</li>
        </ul>
    </aside>
</main>
<?php get_footer(); ?>
