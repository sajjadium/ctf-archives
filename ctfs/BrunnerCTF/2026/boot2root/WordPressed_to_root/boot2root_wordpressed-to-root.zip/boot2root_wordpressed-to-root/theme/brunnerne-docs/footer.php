<footer class="site-footer">
    <div class="header-inner">
        Brunnerne Platform Team · powered by too much coffee and WordPress
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
