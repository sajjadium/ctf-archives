<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
            <span class="brand-mark">//</span>
            <span class="brand-title">Brunnerne Developer Documentation</span>
        </a>
        <div class="header-aside">
            <p class="tagline">Ship boldly. Document eventually.</p>
            <nav class="site-nav" aria-label="Documentation navigation">
                <a href="<?php echo esc_url(home_url('/')); ?>">Docs</a>
                <a href="<?php echo esc_url(home_url('/wp-json/')); ?>">API</a>
                <a href="<?php echo esc_url(home_url('/?feed=rss2')); ?>">RSS</a>
            </nav>
        </div>
    </div>
</header>
