#!/bin/sh
set -eu

# The official WordPress image normally performs these setup steps for us.
# This image deliberately uses a plain Debian runtime, so keep the equivalent
# small amount of initialization here.
rm -f /var/www/html/index.html

if [ ! -f /var/www/html/wp-load.php ]; then
    cp -a /usr/src/wordpress/. /var/www/html/
fi

cat > /var/www/html/wp-config.php <<'PHP_CONFIG'
<?php
function brunnerne_env(string $name, string $default): string {
    $value = getenv($name);
    return $value === false ? $default : $value;
}

define('DB_NAME', brunnerne_env('WORDPRESS_DB_NAME', 'wordpress'));
define('DB_USER', brunnerne_env('WORDPRESS_DB_USER', 'wordpress'));
define('DB_PASSWORD', brunnerne_env('WORDPRESS_DB_PASSWORD', 'wordpress'));
define('DB_HOST', brunnerne_env('WORDPRESS_DB_HOST', 'db:3306'));
define('DB_CHARSET', 'utf8mb4');
define('DB_COLLATE', '');

define('AUTH_KEY',         'brunnerne-auth-key');
define('SECURE_AUTH_KEY',  'brunnerne-secure-auth-key');
define('LOGGED_IN_KEY',    'brunnerne-logged-in-key');
define('NONCE_KEY',        'brunnerne-nonce-key');
define('AUTH_SALT',        'brunnerne-auth-salt');
define('SECURE_AUTH_SALT', 'brunnerne-secure-auth-salt');
define('LOGGED_IN_SALT',   'brunnerne-logged-in-salt');
define('NONCE_SALT',       'brunnerne-nonce-salt');

$table_prefix = 'wp_';
define('WP_DEBUG', true);

$extra = getenv('WORDPRESS_CONFIG_EXTRA');
if ($extra !== false && $extra !== '') {
    eval($extra);
}

if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}
require_once ABSPATH . 'wp-settings.php';
PHP_CONFIG

find /var/www/html \
    -path /var/www/html/wp-content/themes/brunnerne-docs -prune \
    -o -exec chown www-data:www-data {} +

install_wordpress() {
    admin_user="brunnerne_$(openssl rand -hex 6)"
    admin_password="$(openssl rand -hex 24)"
    export BRUNNERNE_ADMIN_USER="$admin_user"
    export BRUNNERNE_ADMIN_PASSWORD="$admin_password"

    i=0
    while [ "$i" -lt 120 ]; do
        if php -r '
$host = getenv("WORDPRESS_DB_HOST") ?: "db:3306";
$parts = explode(":", $host, 2);
$port = count($parts) === 2 ? (int) $parts[1] : 3306;
$connection = @new mysqli(
    $parts[0],
    getenv("WORDPRESS_DB_USER") ?: "wordpress",
    getenv("WORDPRESS_DB_PASSWORD") ?: "wordpress",
    getenv("WORDPRESS_DB_NAME") ?: "wordpress",
    $port
);
if ($connection->connect_errno || !$connection->query("SELECT 1")) {
    exit(1);
}
exit(0);
' \
            && php /usr/local/src/brunnerne-install.php >/tmp/brunnerne-install.log 2>&1 \
            && php -r '
$host = getenv("WORDPRESS_DB_HOST") ?: "db:3306";
$parts = explode(":", $host, 2);
$port = count($parts) === 2 ? (int) $parts[1] : 3306;
$connection = @new mysqli(
    $parts[0],
    getenv("WORDPRESS_DB_USER") ?: "wordpress",
    getenv("WORDPRESS_DB_PASSWORD") ?: "wordpress",
    getenv("WORDPRESS_DB_NAME") ?: "wordpress",
    $port
);
if ($connection->connect_errno) {
    exit(1);
}
$result = $connection->query("SELECT option_value FROM wp_options WHERE option_name = CHAR(115,105,116,101,117,114,108) LIMIT 1");
$row = $result ? $result->fetch_row() : false;
exit($row && !empty($row[0]) ? 0 : 1);
'; then
            rm -f /tmp/brunnerne-install.log
            return 0
        fi
        i=$((i + 1))
        sleep 1
    done

    cat /tmp/brunnerne-install.log >&2
    return 1
}

if [ ! -f /var/www/html/.brunnerne-bootstrap-complete ]; then
    install_wordpress
    php /usr/local/src/brunnerne-seed.php
    touch /var/www/html/.brunnerne-bootstrap-complete
fi

if [ "$#" -eq 0 ]; then
    set -- apache2ctl -D FOREGROUND
fi
"$@" &
apache_pid=$!

cleanup() {
    kill "$apache_pid" 2>/dev/null || true
}
trap cleanup INT TERM EXIT

wait "$apache_pid"
