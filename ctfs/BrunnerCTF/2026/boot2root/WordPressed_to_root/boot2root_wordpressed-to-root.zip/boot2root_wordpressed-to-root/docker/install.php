<?php
declare(strict_types=1);

define('WP_INSTALLING', true);
require_once '/var/www/html/wp-load.php';
require_once ABSPATH . 'wp-admin/includes/upgrade.php';

$site_url = $wpdb->get_var(
    "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl' LIMIT 1"
);

if (!empty($site_url)) {
    exit(0);
}

$admin_user = getenv('BRUNNERNE_ADMIN_USER') ?: 'brunnerne_admin';
$admin_password = getenv('BRUNNERNE_ADMIN_PASSWORD') ?: bin2hex(random_bytes(24));

$result = wp_install(
    'Brunnerne Developer Documentation',
    $admin_user,
    'devs@brunnerne.invalid',
    false,
    '',
    $admin_password,
    'en_US'
);

if (is_wp_error($result)) {
    fwrite(STDERR, $result->get_error_message() . PHP_EOL);
    exit(1);
}

$site_url = getenv('BRUNNERNE_SITE_URL') ?: 'http://localhost:8080';
update_option('siteurl', $site_url);
update_option('home', $site_url);
update_option('permalink_structure', '/%postname%/');
flush_rewrite_rules();

$site_url = $wpdb->get_var(
    "SELECT option_value FROM {$wpdb->options} WHERE option_name = 'siteurl' LIMIT 1"
);

if (empty($site_url)) {
    fwrite(STDERR, "WordPress installation did not create a site URL\n");
    exit(1);
}
