<?php
declare(strict_types=1);

require_once '/var/www/html/wp-load.php';

if (get_option('brunnerne_seed_version') === '1') {
    exit(0);
}

switch_theme('brunnerne-docs');
update_option('blogname', 'Brunnerne Developer Documentation');
update_option('blogdescription', 'Small docs, sloppy deployments.');
update_option('show_on_front', 'posts');

$posts = [
    [
        'post_title' => 'Welcome, brave deployer',
        'post_name' => 'welcome-brave-deployer',
        'post_content' => '<p>You found the internal documentation portal. Due to a continuous employee rotation, documentation has become a number 0 priority! We encourage you to write documentation for your solutions, just in case you aren\'t with us in the future... :) But remember to keep up your development velocity. Our efficiency initiative monthly eliminates the bottom 20% employees, based on lines of code, the best quality indicator!</p>',
    ],
    [
        'post_title' => 'Break Room Coffee Machine',
        'post_name' => 'break-room-coffee-machine',
        'post_content' => 'This device runs a proprietary embedded system to dispense coffee. The uptime requirement is 100% the past 90 days, to ensure employee efficiency. Maintenance is expected to take place during full functionality of the device. A 10kw UPS is attached to ensure continuous operation in case of power outages.',
    ],
    [
        'post_title' => 'Incident report: the CSS escaped',
        'post_name' => 'incident-report-the-css-escaped',
        'post_content' => '<p>At 03:14 the stylesheet changed itself to Comic Sans. Root cause: nobody reviewed the deployment. Resolution: fired insufficient employee.</p>',
    ],
    [
        'post_title' => 'Flag',
        'post_name' => 'flag',
        'post_content' => 'to-do: write down the flag',
    ],
    [
        'post_title' => 'Documentation Platform Maintenance',
        'post_name' => 'this-platform-maintenance',
        'post_content' => 'At <b>May 20, 2026</b> we updated the previously super old WordPress install, to stay up to date on cybersecurity. We should likely also update the host machine... I think it\'s still running an old Debian Trixie beta',
    ],
];

foreach ($posts as $post) {
    if (!get_page_by_path($post['post_name'], OBJECT, 'post')) {
        wp_insert_post([
            'post_title' => $post['post_title'],
            'post_name' => $post['post_name'],
            'post_content' => $post['post_content'],
            'post_status' => 'publish',
            'post_author' => 1,
            'post_type' => 'post',
        ]);
    }
}

update_option('brunnerne_seed_version', '1');
