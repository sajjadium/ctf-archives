#!/bin/bash
set -euo pipefail

TAR_FILE="$1"
PUB_KEY="/etc/bink_ink_fw_public_key.pem"
WORKDIR="$(mktemp -d)"

tar xf "$TAR_FILE" -C "$WORKDIR"

if openssl pkeyutl -verify -pubin -inkey "$PUB_KEY" \
  -in "$WORKDIR/firmware.bin" \
  -sigfile "$WORKDIR/signature.sig" \
  -rawin 2>/dev/null; then
  rm -rf "$WORKDIR"
  exit 0
else
  rm -rf "$WORKDIR"
  exit 1
fi
