#!/bin/sh
set -eu

MEMORY="${VM_MEMORY:-512}"
CPUS="${VM_CPUS:-4}"

exec qemu-system-x86_64 \
    -accel tcg,thread=multi \
    -smp "$CPUS" \
    -m "$MEMORY" \
    -cpu max \
    -display none \
    -serial stdio \
    -monitor none \
    -drive file=/base.img,if=virtio,format=raw \
    -snapshot \
    -netdev user,id=wan,hostfwd=tcp::80-:80,hostfwd=tcp::22-:22 \
    -device virtio-net-pci,netdev=wan
