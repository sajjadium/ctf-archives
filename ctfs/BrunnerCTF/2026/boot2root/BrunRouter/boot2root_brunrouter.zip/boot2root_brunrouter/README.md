# Author's note to help you. Please read before starting support tickets.

You should have everything available to you to start the server locally. Please test locally before you test on remote.

To set up the image like it is run on remote do the following:

```sh
make build
make up
```

Give it about 30 seconds to spawn. You can check the state by running

```sh
make logs
```

There's a debug build, which opens for SSH access to the openwrt instance. You DO NOT need to rebuild to open for this access. The SSH port will be bridged to `0.0.0.0:2222` on your host

If you want SSH access for testing, debugging etc. run the following after building:

```sh
make debug
``` 

You can then get SSH access to it by running:

```sh
make shell
```

Default password is `brunroute`. If you want to change it, it is set in `files/etc/init.d/99-brunroute`

The flag file in `/opt/flag.txt` is only temporary and WILL NOT exist on a running instance. You get the flag by running the program `/opt/flagreader/readflag`
