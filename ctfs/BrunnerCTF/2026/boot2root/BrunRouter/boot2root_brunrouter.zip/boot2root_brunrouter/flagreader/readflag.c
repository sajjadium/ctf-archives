#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/msg.h>


typedef struct {
    long mtype;
    char mtext[256];
}msgbuf;

int main(void){
    int handle = msgget(0xc0c0ba, 0);
    msgbuf msg = {
        .mtype = 5,
        .mtext = {'G', 'i', 'v', 'e', ' ', 'f', 'l', 'a', 'g', ' ', ':', ')'}
    };
    msgsnd(handle, &msg, strlen(msg.mtext), 0);

    msgbuf recv = {0};

    msgrcv(handle, &recv, sizeof(msgbuf), 4, MSG_NOERROR);

    printf("Flag: %s\n", recv.mtext);
}
