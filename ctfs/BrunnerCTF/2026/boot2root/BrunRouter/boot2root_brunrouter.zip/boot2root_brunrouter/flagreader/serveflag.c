#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/msg.h>

int message_handle = -1;
char flag[256] = {0};
int flag_sz = 0;
typedef struct {
    long mtype;
    char mtext[256];
}msgbuf;


void setup_log_handle(){
    key_t recv_key = 0xc0c0ba;

    int handle = msgget(recv_key, IPC_CREAT | 0666); // Everyone can read and write to the queue

    if(handle == -1){
        fprintf(stderr, "flag server failed to set up daemon");
        exit(1);
    }

    message_handle = handle;
}

void terminate_flag(){
    int fd = open("/opt/flag.txt", O_RDONLY);
    flag_sz = read(fd, flag, 256);
    close(fd);
    remove("/opt/flag.txt");
}


void give_user_flag(){
    msgbuf req = {0};
    msgbuf res = {
        .mtype = 4
    };
    msgrcv(message_handle, &req, sizeof(msgbuf), 5, MSG_NOERROR);
    if(strcmp(req.mtext, "Give flag :)")){
        return;
    }
    strcpy(res.mtext, flag);
    msgsnd(message_handle, &res, flag_sz, 0);
    return;
}

int main(void){
    terminate_flag();
    setup_log_handle();

    while(1){
        give_user_flag();
    }
}
