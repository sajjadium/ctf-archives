% pending = sum(len(lines) for lines in changes.values())
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{title}} - BrunRoute</title>
<link rel="stylesheet" href="/static/style.css">
<script src="/static/app.js" defer></script>
</head>
<body>

<header>
  <a class="brand" href="/">BrunRoute</a>
  <nav>
    % for name in configs:
    <a href="/config/{{name}}" class="{{'active' if name == title.lower() else ''}}">{{name}}</a>
    % end
    <a href="/backup">backup</a>
    <a href="/diagnostics">diagnostics</a>
    <a href="/changes" class="changes">changes<span class="badge {{'live' if pending else ''}}">{{pending}}</span></a>
  </nav>
</header>

% if pending:
<div class="banner">
  {{pending}} staged change(s) not yet applied.
  <a href="/changes">Review</a>
</div>
% end

<main>
<h1>{{title}}</h1>
{{!base}}
</main>

<div id="toast" hidden></div>

</body>
</html>
