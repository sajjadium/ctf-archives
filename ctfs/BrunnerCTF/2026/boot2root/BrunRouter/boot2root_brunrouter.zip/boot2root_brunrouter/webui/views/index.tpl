% rebase('base.tpl', title='Dashboard', configs=configs, changes=changes)

% uptime = int(status['uptime'])
% hours, remainder = divmod(uptime, 3600)
% minutes = remainder // 60
% release = status['release']

<div class="section">
  <h2>System</h2>
  <table>
    <tr><th>Hostname</th><td>{{status['hostname']}}</td></tr>
    <tr><th>Release</th><td>{{release.get('DISTRIB_DESCRIPTION', 'unknown')}}</td></tr>
    <tr><th>Target</th><td>{{release.get('DISTRIB_TARGET', 'unknown')}}</td></tr>
    <tr><th>Uptime</th><td>{{hours}}h {{minutes}}m</td></tr>
    <tr><th>Load</th><td>{{' '.join(status['load'])}}</td></tr>
  </table>
</div>

<div class="section">
  <h2>Addresses</h2>
  <table>
    <tr><th>Device</th><th>Family</th><th>Address</th></tr>
    % for entry in status['addrs']:
    <tr>
      <td>{{entry['dev']}}</td>
      <td>{{entry['family']}}</td>
      <td>{{entry['addr']}}</td>
    </tr>
    % end
  </table>
</div>

<div class="section">
  <h2>Configuration</h2>
  <table>
    <tr><th>Config</th><th>Staged changes</th></tr>
    % for name in configs:
    <tr>
      <td><a href="/config/{{name}}">{{name}}</a></td>
      <td>{{len(changes.get(name, []))}}</td>
    </tr>
    % end
  </table>
</div>
