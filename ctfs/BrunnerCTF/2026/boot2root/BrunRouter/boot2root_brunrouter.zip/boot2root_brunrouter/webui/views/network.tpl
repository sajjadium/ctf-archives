% rebase('base.tpl', title='Network', configs=configs, changes=changes)

% def show(value):
%   if isinstance(value, list):
%     return ', '.join(value)
%   end
%   return value or ''
% end

% interfaces = [s for s in sections.values() if s['.type'] == 'interface']

% for section in interfaces:
% name = section['.name']
% assigned = live.get(section.get('device', ''), [])
<form class="section" data-config="network" data-section="{{name}}">
  <h2>{{name}}</h2>

  % if name == 'lan':
  <p class="warn">Changing the lan address cuts off access to this interface. The device will need a restart to recover.</p>
  % end

  % if assigned:
  <label>
    Assigned
    <input value="{{', '.join(assigned)}}" readonly>
  </label>
  % end

  <label>
    Protocol
    <select name="proto">
      % for choice in ('static', 'dhcp', 'none'):
      <option value="{{choice}}" {{'selected' if section.get('proto') == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>

  <label>
    Device
    <input name="device" value="{{show(section.get('device'))}}">
  </label>

  <label>
    IPv4 address
    <input name="ipaddr" value="{{show(section.get('ipaddr'))}}" placeholder="192.168.1.1/24">
  </label>

  <label>
    Netmask
    <input name="netmask" value="{{show(section.get('netmask'))}}" placeholder="255.255.255.0">
  </label>

  <label>
    Gateway
    <input name="gateway" value="{{show(section.get('gateway'))}}">
  </label>

  <label>
    DNS servers
    <input name="dns" value="{{show(section.get('dns'))}}" placeholder="1.1.1.1, 8.8.8.8">
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<script>
function splitList(raw) {
  const parts = raw.split(',').map((item) => item.trim()).filter(Boolean);
  return parts.length ? parts : null;
}

function networkValues(form) {
  const field = form.elements;
  return {
    proto: field.proto.value,
    device: field.device.value,
    ipaddr: splitList(field.ipaddr.value),
    netmask: field.netmask.value,
    gateway: field.gateway.value,
    dns: splitList(field.dns.value),
  };
}

document.addEventListener('DOMContentLoaded', () => bindSectionForms(networkValues));
</script>
