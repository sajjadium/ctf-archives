import os
import time

from bottle import Bottle
from bottle import TEMPLATE_PATH
from bottle import request
from bottle import response
from bottle import static_file
from bottle import template

import ucilib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VIEWS_DIR = os.path.join(BASE_DIR, "views")
STATIC_DIR = os.path.join(BASE_DIR, "static")

EXPORT_FILENAME_FORMAT = "brunroute-config-%Y-%m-%d-%H%M.txt"

TEMPLATE_PATH.insert(0, VIEWS_DIR)

app = Bottle()


def show_uci_errors(callback):
    def wrapper(*args, **kwargs):
        try:
            return callback(*args, **kwargs)
        except ucilib.UciError as error:
            response.status = 400
            if request.method != "GET":
                return {"error": str(error)}
            return template(
                "error",
                message=str(error),
                configs=ucilib.CONFIGS,
                changes=ucilib.changes(),
            )

    return wrapper


app.install(show_uci_errors)


@app.get("/static/<path:path>")
def serve_static(path):
    return static_file(path, root=STATIC_DIR)


@app.get("/")
def dashboard():
    return template(
        "index",
        status=ucilib.status(),
        configs=ucilib.CONFIGS,
        changes=ucilib.changes(),
    )


@app.get("/config/<config>")
def config_page(config):
    return template(
        config,
        config=config,
        sections=ucilib.read_config(config),
        live=ucilib.live_addresses(),
        configs=ucilib.CONFIGS,
        changes=ucilib.changes(),
    )


@app.post("/config/<config>/<section>")
def save_section(config, section):
    body = request.json or {}
    ucilib.stage(config, section, body.get("values", {}), body.get("type"))
    return {"changes": ucilib.changes()}


@app.delete("/config/<config>/<section>")
def delete_section(config, section):
    ucilib.delete_section(config, section)
    return {"changes": ucilib.changes()}


@app.get("/changes")
def changes_page():
    return template(
        "changes",
        configs=ucilib.CONFIGS,
        changes=ucilib.changes(),
    )


@app.post("/changes/commit")
def commit_changes():
    for config in ucilib.changes():
        ucilib.commit_and_apply(config)
    return {"changes": ucilib.changes()}


@app.post("/changes/revert")
def revert_changes():
    for config in ucilib.changes():
        ucilib.revert(config)
    return {"changes": ucilib.changes()}


@app.get("/backup")
def backup_page():
    return template(
        "backup",
        configs=ucilib.CONFIGS,
        changes=ucilib.changes(),
    )


@app.get("/backup/export")
def export_backup():
    filename = time.strftime(EXPORT_FILENAME_FORMAT)
    response.content_type = "text/plain; charset=utf-8"
    response.set_header("Content-Disposition", "attachment; filename=" + filename)
    return ucilib.export_all()


# These next two become a one-shot


@app.post("/backup/import")
def import_backup():
    packages = ucilib.save_imported_config(request.body)
    ucilib.apply_imported_config()
    return {"packages": packages, "staged_at": ucilib.IMPORT_STAGING_PATH}


@app.post("/backup/factory-reset")
def factory_reset():
    ucilib.factory_reset()
    return {"success": True}


@app.get("/ping")
def ping():
    hosts = ucilib.get_unchecked("brunroute", "internal", "pinghosts")

    # Admin may configure multiple hosts to ping for sanity checks inside of
    # /etc/uci-defaults/99-brunroute
    try:
        ucilib._run("curl", "--fail-early", *hosts.split(" "))
    except ucilib.UciError:
        return {"success": False}

    return {"success": True}


@app.get("/diagnostics")
def diagnostics():
    return template(
        "diagnostics",
        configs=ucilib.CONFIGS,
        changes=ucilib.changes(),
    )


if __name__ == "__main__":
    app.run(
        host=os.environ.get("WEBUI_HOST", "0.0.0.0"),
        port=int(os.environ.get("WEBUI_PORT", "80")),
        reloader=os.environ.get("WEBUI_RELOAD") == "1",
        quiet=True,
    )
