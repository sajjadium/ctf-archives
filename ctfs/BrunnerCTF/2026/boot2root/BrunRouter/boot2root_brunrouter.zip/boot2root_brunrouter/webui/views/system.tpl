% rebase('base.tpl', title='System', configs=configs, changes=changes)

% systems = [s for s in sections.values() if s['.type'] == 'system']

% for section in systems:
% name = section['.name']
<form class="section" data-config="system" data-section="{{name}}">
  <h2>{{section.get('hostname', name)}}</h2>

  <label>
    Hostname
    <input name="hostname" value="{{section.get('hostname', '')}}">
  </label>

  <label>
    Timezone
    <input name="timezone" value="{{section.get('timezone', '')}}" placeholder="UTC">
  </label>

  <label>
    Zone name
    <input name="zonename" value="{{section.get('zonename', '')}}" placeholder="Europe/Copenhagen">
  </label>

  <label>
    Log size (KiB)
    <input name="log_size" value="{{section.get('log_size', '')}}">
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
  </div>
</form>
% end

<script>
function systemValues(form) {
  const field = form.elements;
  return {
    hostname: field.hostname.value,
    timezone: field.timezone.value,
    zonename: field.zonename.value,
    log_size: field.log_size.value,
  };
}

document.addEventListener('DOMContentLoaded', () => bindSectionForms(systemValues));
</script>
