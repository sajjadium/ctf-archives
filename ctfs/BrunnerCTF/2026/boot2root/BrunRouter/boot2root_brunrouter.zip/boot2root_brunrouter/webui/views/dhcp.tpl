% rebase('base.tpl', title='Dhcp', configs=configs, changes=changes)

% pools = [s for s in sections.values() if s['.type'] == 'dhcp']
% hosts = [s for s in sections.values() if s['.type'] == 'host']

<h2>Pools</h2>
% for section in pools:
% name = section['.name']
<form class="section" data-config="dhcp" data-section="{{name}}" data-kind="pool">
  <h2>{{section.get('interface', name)}}</h2>

  <label>
    Interface
    <input name="interface" value="{{section.get('interface', '')}}">
  </label>

  <label>
    Start
    <input name="start" value="{{section.get('start', '')}}">
  </label>

  <label>
    Limit
    <input name="limit" value="{{section.get('limit', '')}}">
  </label>

  <label>
    Lease time
    <input name="leasetime" value="{{section.get('leasetime', '')}}" placeholder="12h">
  </label>

  <label>
    Disable DHCP
    <input type="checkbox" name="ignore" {{'checked' if section.get('ignore') == '1' else ''}}>
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<h2>Static leases</h2>
% for section in hosts:
% name = section['.name']
<form class="section" data-config="dhcp" data-section="{{name}}" data-kind="host">
  <h2>{{section.get('name', name)}}</h2>

  <label>
    Name
    <input name="name" value="{{section.get('name', '')}}">
  </label>

  <label>
    MAC address
    <input name="mac" value="{{section.get('mac', '')}}" placeholder="00:11:22:33:44:55">
  </label>

  <label>
    IPv4 address
    <input name="ip" value="{{section.get('ip', '')}}">
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<form class="section" data-config="dhcp" data-kind="host" id="new-lease">
  <h2>New static lease</h2>

  <label>
    Section name
    <input name="section" placeholder="laptop">
  </label>

  <label>
    Name
    <input name="name">
  </label>

  <label>
    MAC address
    <input name="mac" placeholder="00:11:22:33:44:55">
  </label>

  <label>
    IPv4 address
    <input name="ip">
  </label>

  <div class="actions">
    <button type="submit">Create</button>
  </div>
</form>

<script>
function dhcpValues(form) {
  const field = form.elements;
  if (form.dataset.kind === 'pool') {
    return {
      interface: field.interface.value,
      start: field.start.value,
      limit: field.limit.value,
      leasetime: field.leasetime.value,
      ignore: field.ignore.checked,
    };
  }
  return {
    name: field.name.value,
    mac: field.mac.value,
    ip: field.ip.value,
  };
}

document.addEventListener('DOMContentLoaded', () => {
  bindSectionForms(dhcpValues);

  const newLease = document.getElementById('new-lease');
  newLease.addEventListener('submit', async (event) => {
    event.preventDefault();
    const section = newLease.elements.section.value.trim();
    if (!section) {
      toast('Section name is required', true);
      return;
    }
    try {
      await saveSection('dhcp', section, dhcpValues(newLease), 'host');
      location.reload();
    } catch (error) {
      toast(error.message, true);
    }
  });
});
</script>
