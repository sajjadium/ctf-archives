% rebase('base.tpl', title='Wireless', configs=configs, changes=changes)

% radios = [s for s in sections.values() if s['.type'] == 'wifi-device']
% networks = [s for s in sections.values() if s['.type'] == 'wifi-iface']

% if not radios:
<div class="section">No radios detected.</div>
% end

% for section in radios:
% name = section['.name']
<form class="section" data-config="wireless" data-section="{{name}}" data-kind="device">
  <h2>radio {{name}}</h2>

  <label>
    Channel
    <input name="channel" value="{{section.get('channel', '')}}">
  </label>

  <label>
    HT mode
    <input name="htmode" value="{{section.get('htmode', '')}}">
  </label>

  <label>
    Country
    <input name="country" value="{{section.get('country', '')}}">
  </label>

  <label>
    Disabled
    <input type="checkbox" name="disabled" {{'checked' if section.get('disabled') == '1' else ''}}>
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
  </div>
</form>
% end

% for section in networks:
% name = section['.name']
<form class="section" data-config="wireless" data-section="{{name}}" data-kind="iface">
  <h2>network {{section.get('ssid', name)}}</h2>

  <label>
    SSID
    <input name="ssid" value="{{section.get('ssid', '')}}">
  </label>

  <label>
    Mode
    <select name="mode">
      % for choice in ('ap', 'sta', 'adhoc', 'monitor'):
      <option value="{{choice}}" {{'selected' if section.get('mode') == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>

  <label>
    Encryption
    <select name="encryption">
      % for choice in ('none', 'psk', 'psk2', 'psk-mixed', 'sae', 'sae-mixed'):
      <option value="{{choice}}" {{'selected' if section.get('encryption') == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>

  <label>
    Key
    <input type="password" name="key" value="{{section.get('key', '')}}">
  </label>

  <label>
    Network
    <input name="network" value="{{section.get('network', '')}}">
  </label>

  <label>
    Disabled
    <input type="checkbox" name="disabled" {{'checked' if section.get('disabled') == '1' else ''}}>
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<script>
function wirelessValues(form) {
  const field = form.elements;
  if (form.dataset.kind === 'device') {
    return {
      channel: field.channel.value,
      htmode: field.htmode.value,
      country: field.country.value,
      disabled: field.disabled.checked,
    };
  }
  return {
    ssid: field.ssid.value,
    mode: field.mode.value,
    encryption: field.encryption.value,
    key: field.key.value,
    network: field.network.value,
    disabled: field.disabled.checked,
  };
}

document.addEventListener('DOMContentLoaded', () => bindSectionForms(wirelessValues));
</script>
