async function send(method, url, body) {
    const options = { method: method, headers: {} };
    if (typeof body === 'string') {
        options.headers['Content-Type'] = 'text/plain';
        options.body = body;
    } else if (body !== undefined) {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(body);
    }
    const reply = await fetch(url, options);
    const data = await reply.json();
    if (!reply.ok) {
        throw new Error(data.error || reply.statusText);
    }
    return data;
}

function toast(message, isError) {
    const box = document.getElementById('toast');
    box.textContent = message;
    box.className = isError ? 'error' : 'ok';
    box.hidden = false;
    setTimeout(() => { box.hidden = true; }, 4000);
}

function stagedCount(changes) {
    return Object.values(changes).reduce((total, lines) => total + lines.length, 0);
}

function updateBadge(changes) {
    const badge = document.querySelector('.badge');
    const count = stagedCount(changes);
    badge.textContent = count;
    badge.classList.toggle('live', count > 0);
}

async function saveSection(config, section, values, type) {
    const body = { values: values };
    if (type) {
        body.type = type;
    }
    const data = await send('POST', `/config/${config}/${section}`, body);
    updateBadge(data.changes);
    return data;
}

async function deleteSection(config, section) {
    const data = await send('DELETE', `/config/${config}/${section}`);
    updateBadge(data.changes);
    return data;
}

async function commitChanges() {
    const data = await send('POST', '/changes/commit');
    updateBadge(data.changes);
    return data;
}

async function revertChanges() {
    const data = await send('POST', '/changes/revert');
    updateBadge(data.changes);
    return data;
}

async function importConfig(text) {
    await send('POST', '/backup/import', text);
}

function bindSectionForms(buildValues) {
    document.querySelectorAll('form[data-section]').forEach((form) => {
        const config = form.dataset.config;
        const section = form.dataset.section;

        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            try {
                await saveSection(config, section, buildValues(form), form.dataset.type);
                toast(`Staged ${config}.${section}`);
            } catch (error) {
                toast(error.message, true);
            }
        });

        const removeButton = form.querySelector('[data-delete]');
        if (removeButton) {
            removeButton.addEventListener('click', async () => {
                if (!confirm(`Delete ${config}.${section}?`)) {
                    return;
                }
                try {
                    await deleteSection(config, section);
                    form.remove();
                    toast(`Deleted ${config}.${section}`);
                } catch (error) {
                    toast(error.message, true);
                }
            });
        }
    });
}
