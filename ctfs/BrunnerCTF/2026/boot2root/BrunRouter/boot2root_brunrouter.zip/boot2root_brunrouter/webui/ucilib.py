import os
import re
import shutil
import subprocess
import ubus
from uci import Uci, UciException, UciExceptionNotFound

CONFIGS = ("network", "wireless", "firewall", "dhcp", "system")
UBUS_SOCKET = "/var/run/ubus/ubus.sock"
IMPORT_STAGING_PATH = "/tmp/config"
FACTORY_CONFIG_PATH = "/etc/config.factory"

# For from ucilib import *
__all__ = [
    "CONFIGS",
    "UciError",
    "read_config",
    "sections_of_type",
    "live_addresses",
    "get",
    "get_unchecked",
    "stage",
    "delete_section",
    "changes",
    "has_changes",
    "commit",
    "revert",
    "apply",
    "factory_reset",
    "export_all",
    "save_imported_config",
    "verify_imported_config",
    "read_imported_config",
    "has_imported_config",
    "apply_imported_config",
    "status",
]


class UciError(Exception):
    pass


# Public API


def read_config(config):
    _validate_uci_config(config)
    uci_ctx = Uci()
    try:
        section_names = uci_ctx.get(config)
    except _NOT_FOUND:
        return {}

    sections = {}
    for name in section_names:
        try:
            options = uci_ctx.get_all(config, name)
            section_type = uci_ctx.get(config, name)
        except _NOT_FOUND:
            continue
        section = {k: _uci_list_to_python_list(v) for k, v in options.items()}
        section[".type"] = section_type
        section[".name"] = name
        sections[name] = section
    return sections


def sections_of_type(config, *types):
    return [s for s in read_config(config).values() if s.get(".type") in types]


def live_addresses():
    grouped = {}
    for entry in _interface_addresses():
        grouped.setdefault(entry["dev"], []).append(entry["addr"])
    return grouped


def get(config, section, option, default=None):
    _validate_uci_config(config, section, option)
    return get_unchecked(config, section, option, default)


def get_unchecked(config, section, option, default=None):
    uci_ctx = Uci()
    try:
        value = uci_ctx.get(config, section, option)
    except _NOT_FOUND:
        return default
    return _uci_list_to_python_list(value)


def stage(config, section, values, create_as_type=None):
    _validate_uci_config(config, section, values)
    uci_ctx = Uci()

    if create_as_type and not _section_exists(uci_ctx, config, section):
        uci_ctx.set(config, section, create_as_type)

    for option, value in values.items():
        blank = value is None or value == ""
        if blank:
            uci_ctx.delete(config, section, option)
        elif isinstance(value, bool):
            uci_ctx.set(config, section, option, "1" if value else "0")
        elif isinstance(value, (list, tuple)):
            uci_list = _python_list_to_uci_list(value)
            uci_ctx.set(config, section, option, uci_list)
        else:
            uci_ctx.set(config, section, option, str(value))

    uci_ctx.save(config)


def delete_section(config, section):
    _validate_uci_config(config, section)
    uci_ctx = Uci()
    uci_ctx.delete(config, section)
    uci_ctx.save(config)


def changes(config=None):
    if config is not None:
        _validate_uci_config(config)
    argv = ["uci", "changes"] + ([config] if config else [])
    by_config = {}
    for line in _run(*argv).splitlines():
        line = line.strip()
        if not line:
            continue
        changed_config = line.lstrip("-+").split(".", 1)[0]
        by_config.setdefault(changed_config, []).append(line)
    return by_config


def has_changes(config=None):
    return bool(changes(config))


def commit(config):
    _validate_uci_config(config)
    Uci().commit(config)


def commit_and_apply(config):
    commit(config)
    apply(config)


def revert(config):
    _validate_uci_config(config)
    Uci().revert(config)


def apply(config):
    _validate_uci_config(config)
    reload_owning_service = _RELOADERS.get(config)
    if reload_owning_service:
        reload_owning_service()


def factory_reset():
    _run("uci", "-f", FACTORY_CONFIG_PATH, "import")
    _run("uci", "commit")
    return True


def export_all():
    exported = []
    for config in CONFIGS:
        _validate_uci_config(config)
        exported.append(_run("uci", "export", config))
    return "".join(exported)


def save_imported_config(source):
    with open(IMPORT_STAGING_PATH, "wb") as staged:
        shutil.copyfileobj(source, staged)
    try:
        return verify_imported_config()
    except UciError:
        os.remove(IMPORT_STAGING_PATH)
        raise


def verify_imported_config():
    current_package = None
    staged = open(IMPORT_STAGING_PATH)
    try:
        number = 0
        while True:
            line = staged.readline()
            if not line:
                break
            number += 1
            tmp_package = None
            line_verified, tmp_package = _verify_import_line(
                line, number, current_package
            )
            if tmp_package is not None:
                current_package = tmp_package
            if not line_verified:
                return False
    finally:
        staged.close()

    return True


def has_imported_config():
    return os.path.exists(IMPORT_STAGING_PATH)


def read_imported_config():
    if not has_imported_config():
        raise UciError("no imported config waiting at " + IMPORT_STAGING_PATH)
    staged = open(IMPORT_STAGING_PATH)
    try:
        return staged.read()
    finally:
        staged.close()


def apply_imported_config():
    if not has_imported_config():
        raise UciError("no imported config waiting at " + IMPORT_STAGING_PATH)

    _run("uci", "-f", IMPORT_STAGING_PATH, "import")
    _run("uci", "commit")
    for reloader in _RELOADERS.values():
        reloader()
    os.remove(IMPORT_STAGING_PATH)
    return True


def status():
    return {
        "hostname": _hostname(),
        "uptime": _uptime_seconds(),
        "load": _load_averages(),
        "release": _release_info(),
        "addrs": _interface_addresses(),
    }


# Internals

_SECTION_RE = re.compile(r"^([a-zA-Z0-9_]+|@[a-zA-Z0-9_]+\[-?\d+\])$")
_OPTION_RE = re.compile(r"^[a-zA-Z0-9_]+$")

_NOT_FOUND = (UciException, UciExceptionNotFound)


def _imported_packages():
    packages = {}
    current = None
    with open(IMPORT_STAGING_PATH) as staged:
        for line in staged:
            if line.startswith("package "):
                current = line.split(None, 1)[1].strip().strip("'\"")
                packages[current] = ""
            elif current is not None:
                packages[current] += line
    return packages


def _validate_uci_config(config, section=None, options=()):
    if config not in CONFIGS:
        raise UciError("Invalid config name %r" % config)
    if section is not None and not _SECTION_RE.match(section):
        raise UciError("invalid section name %r" % section)
    if isinstance(options, str):
        options = (options,)
    for option in options:
        if not _OPTION_RE.match(option):
            raise UciError("invalid option name %r" % option)


def _run(*argv, stdin_text=None):
    done = subprocess.run(
        argv, input=stdin_text, capture_output=True, text=True, timeout=30
    )
    if done.returncode != 0:
        message = (done.stderr or done.stdout).strip()
        raise UciError("%s failed: %s" % (argv[0], message))
    return done.stdout


def _uci_list_to_python_list(value):
    return list(value) if isinstance(value, tuple) else value


def _python_list_to_uci_list(value):
    return tuple(str(item) for item in value)


def _verify_import_line(line, number, current_package):
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return True, current_package

    keyword, _, remainder = stripped.partition(" ")
    names = [part.strip("'\"") for part in remainder.split()]
    if not names:
        raise UciError("line %d: %s has no name" % (number, keyword))

    if keyword == "package":
        _validate_uci_config(names[0])
        return True, names[0]

    if keyword == "config":
        section = names[1] if len(names) > 1 else None
        _validate_uci_config(current_package, section)
        return True, current_package

    if keyword in ("option", "list"):
        _validate_uci_config(current_package, None, names[0])
        return True, current_package

    return True, None


def _section_exists(uci_ctx, config, section):
    try:
        uci_ctx.get(config, section)
        return True
    except _NOT_FOUND:
        return False


def _ubus_reload(service):
    ubus.connect(UBUS_SOCKET)
    try:
        ubus.call(service, "reload", {})
    finally:
        ubus.disconnect()


def _reload_network():
    _ubus_reload("network")


def _reload_wireless():
    _run("/sbin/wifi", "reload")


def _reload_firewall():
    _run("/etc/init.d/firewall", "reload")


def _reload_dhcp():
    _run("/etc/init.d/dnsmasq", "reload")


def _reload_system():
    _run("/etc/init.d/system", "reload")


_RELOADERS = {
    "network": _reload_network,
    "wireless": _reload_wireless,
    "firewall": _reload_firewall,
    "dhcp": _reload_dhcp,
    "system": _reload_system,
}


def _hostname():
    try:
        configured = get("system", "@system[0]", "hostname")
        return configured or _run("uname", "-n").strip()
    except Exception:
        return "unknown"


def _uptime_seconds():
    try:
        with open("/proc/uptime") as uptime:
            return float(uptime.read().split()[0])
    except Exception:
        return 0.0


def _load_averages():
    try:
        with open("/proc/loadavg") as loadavg:
            return loadavg.read().split()[:3]
    except Exception:
        return []


def _release_info():
    info = {}
    try:
        with open("/etc/openwrt_release") as release:
            for line in release:
                if "=" in line:
                    key, _, value = line.partition("=")
                    info[key.strip()] = value.strip().strip("'\"")
    except Exception:
        return {}
    return info


def _interface_addresses():
    addresses = []
    try:
        lines = _run("ip", "-o", "addr", "show").splitlines()
    except Exception:
        return []
    for line in lines:
        fields = line.split()
        if len(fields) < 4 or fields[2] not in ("inet", "inet6"):
            continue
        addresses.append({"dev": fields[1], "family": fields[2], "addr": fields[3]})
    return addresses
