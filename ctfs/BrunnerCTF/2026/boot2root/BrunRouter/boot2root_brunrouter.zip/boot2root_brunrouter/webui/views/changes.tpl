% rebase('base.tpl', title='Changes', configs=configs, changes=changes)

% if not changes:
<div class="section">Nothing staged. Config on disk matches what is running.</div>
% else:
% for config, lines in changes.items():
<div class="section">
  <h2>{{config}}</h2>
  <pre>{{'\n'.join(lines)}}</pre>
</div>
% end

<div class="section">
  <p>
    Commit writes /etc/config, then the owning service is reloaded so the
    change actually takes effect. Revert discards the staged delta and leaves
    /etc/config untouched.
  </p>
  <div class="actions">
    <button type="button" id="commit">Commit and apply</button>
    <button type="button" class="danger" id="revert">Revert</button>
  </div>
</div>
% end

<script>
document.addEventListener('DOMContentLoaded', () => {
  const commitButton = document.getElementById('commit');
  const revertButton = document.getElementById('revert');
  if (!commitButton) {
    return;
  }

  commitButton.addEventListener('click', async () => {
    try {
      await commitChanges();
      location.reload();
    } catch (error) {
      toast(error.message, true);
    }
  });

  revertButton.addEventListener('click', async () => {
    if (!confirm('Discard all staged changes?')) {
      return;
    }
    try {
      await revertChanges();
      location.reload();
    } catch (error) {
      toast(error.message, true);
    }
  });
});
</script>
