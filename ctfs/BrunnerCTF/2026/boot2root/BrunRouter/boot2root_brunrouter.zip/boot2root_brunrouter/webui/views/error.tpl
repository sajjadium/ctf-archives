% rebase('base.tpl', title='Error', configs=configs, changes=changes)

<div class="section">
  <h2>Request rejected</h2>
  <pre>{{message}}</pre>
</div>
