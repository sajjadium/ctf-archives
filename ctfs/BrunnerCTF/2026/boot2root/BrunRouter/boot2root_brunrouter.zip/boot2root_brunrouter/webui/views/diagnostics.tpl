% rebase('base.tpl', title='Diagnostics', configs=configs, changes=changes)

<div class="section">
  <h2>Connectivity</h2>
  <p>Checks whether the router can reach the network.</p>
  <div class="actions">
    <button type="button" id="ping">Check connectivity</button>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('ping').addEventListener('click', async () => {
    try {
      const data = await send('GET', '/ping');
      if (data.success) {
        toast('Connected');
      } else {
        toast('Not connected', true);
      }
    } catch (error) {
      toast('Not connected', true);
    }
  });
});
</script>
