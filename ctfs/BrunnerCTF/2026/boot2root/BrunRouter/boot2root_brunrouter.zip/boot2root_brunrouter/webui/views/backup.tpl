% rebase('base.tpl', title='Backup', configs=configs, changes=changes)

<div class="section">
  <h2>Export</h2>
  <p>Downloads every managed config in UCI syntax, timestamped to the minute.</p>
  <div class="actions">
    <a href="/backup/export"><button type="button">Download config</button></a>
  </div>
</div>

<div class="section">
  <h2>Import</h2>
  <p>Replaces the configuration and applies it immediately.</p>

  <label>
    File
    <input type="file" id="import-file" accept=".txt,text/plain">
  </label>

  <textarea id="import-text" placeholder="package 'network'&#10;&#10;config interface 'lan'&#10;    option proto 'dhcp'"></textarea>

  <div class="actions">
    <button type="button" class="danger" id="import">Import and apply</button>
  </div>
</div>

<div class="section">
  <h2>Factory reset</h2>
  <p>Restores every config to the state the device shipped with.</p>
  <div class="actions">
    <button type="button" class="danger" id="factory-reset">Factory reset</button>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
  const fileInput = document.getElementById('import-file');
  const textInput = document.getElementById('import-text');

  fileInput.addEventListener('change', async () => {
    const file = fileInput.files[0];
    if (file) {
      textInput.value = await file.text();
    }
  });

  document.getElementById('import').addEventListener('click', async () => {
    const text = textInput.value.trim();
    if (!text) {
      toast('Nothing to import', true);
      return;
    }
    if (!confirm('Replace the configs named in this text?')) {
      return;
    }
    try {
      await importConfig(text);
      toast('Config imported');
    } catch (error) {
      toast(error.message, true);
    }
  });

  document.getElementById('factory-reset').addEventListener('click', async () => {
    if (!confirm('Restore every config to factory defaults?')) {
      return;
    }
    try {
      await send('POST', '/backup/factory-reset');
      toast('Factory defaults restored');
    } catch (error) {
      toast(error.message, true);
    }
  });
});
</script>
