% rebase('base.tpl', title='Firewall', configs=configs, changes=changes)

% policies = ('ACCEPT', 'REJECT', 'DROP')
% zones = [s for s in sections.values() if s['.type'] == 'zone']
% forwardings = [s for s in sections.values() if s['.type'] == 'forwarding']
% rules = [s for s in sections.values() if s['.type'] == 'rule']

<h2>Zones</h2>
% for section in zones:
% name = section['.name']
% networks = section.get('network', '')
% if isinstance(networks, list):
%     networks = ' '.join(networks)
% end
<form class="section" data-config="firewall" data-section="{{name}}" data-kind="zone">
  <h2>{{section.get('name', name)}}</h2>

  <label>
    Name
    <input name="name" value="{{section.get('name', '')}}">
  </label>

  % for option in ('input', 'output', 'forward'):
  <label>
    {{option.capitalize()}}
    <select name="{{option}}">
      % for choice in policies:
      <option value="{{choice}}" {{'selected' if section.get(option) == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>
  % end

  <label>
    Networks
    <input name="network" value="{{networks}}">
  </label>

  <label>
    Masquerade
    <input type="checkbox" name="masq" {{'checked' if section.get('masq') == '1' else ''}}>
  </label>

  <label>
    MSS clamping
    <input type="checkbox" name="mtu_fix" {{'checked' if section.get('mtu_fix') == '1' else ''}}>
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<h2>Forwardings</h2>
% for section in forwardings:
% name = section['.name']
<form class="section" data-config="firewall" data-section="{{name}}" data-kind="forwarding">
  <h2>{{section.get('src', '?')}} &rarr; {{section.get('dest', '?')}}</h2>

  <label>
    Source zone
    <input name="src" value="{{section.get('src', '')}}">
  </label>

  <label>
    Destination zone
    <input name="dest" value="{{section.get('dest', '')}}">
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<h2>Rules</h2>
% for section in rules:
% name = section['.name']
<form class="section" data-config="firewall" data-section="{{name}}" data-kind="rule">
  <h2>{{section.get('name', name)}}</h2>

  <label>
    Name
    <input name="name" value="{{section.get('name', '')}}">
  </label>

  <label>
    Source zone
    <input name="src" value="{{section.get('src', '')}}">
  </label>

  <label>
    Destination zone
    <input name="dest" value="{{section.get('dest', '')}}">
  </label>

  <label>
    Protocol
    <select name="proto">
      % for choice in ('tcp', 'udp', 'tcpudp', 'icmp', 'all'):
      <option value="{{choice}}" {{'selected' if section.get('proto') == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>

  <label>
    Source port
    <input name="src_port" value="{{section.get('src_port', '')}}">
  </label>

  <label>
    Destination port
    <input name="dest_port" value="{{section.get('dest_port', '')}}">
  </label>

  <label>
    Target
    <select name="target">
      % for choice in policies:
      <option value="{{choice}}" {{'selected' if section.get('target') == choice else ''}}>{{choice}}</option>
      % end
    </select>
  </label>

  <label>
    Enabled
    <input type="checkbox" name="enabled" {{'checked' if section.get('enabled', '1') == '1' else ''}}>
  </label>

  <div class="actions">
    <button type="submit">Stage</button>
    <button type="button" class="danger" data-delete>Delete</button>
  </div>
</form>
% end

<h2>Add</h2>

<form class="section" data-config="firewall" data-kind="zone" data-type="zone" id="new-zone">
  <h2>New zone</h2>
  <label>Section name<input name="section" placeholder="guest"></label>
  <label>Name<input name="name"></label>
  % for option in ('input', 'output', 'forward'):
  <label>
    {{option.capitalize()}}
    <select name="{{option}}">
      % for choice in policies:
      <option value="{{choice}}">{{choice}}</option>
      % end
    </select>
  </label>
  % end
  <label>Networks<input name="network"></label>
  <label>Masquerade<input type="checkbox" name="masq"></label>
  <label>MSS clamping<input type="checkbox" name="mtu_fix"></label>
  <div class="actions"><button type="submit">Create</button></div>
</form>

<form class="section" data-config="firewall" data-kind="forwarding" data-type="forwarding" id="new-forwarding">
  <h2>New forwarding</h2>
  <label>Section name<input name="section" placeholder="guest_wan"></label>
  <label>Source zone<input name="src"></label>
  <label>Destination zone<input name="dest"></label>
  <div class="actions"><button type="submit">Create</button></div>
</form>

<form class="section" data-config="firewall" data-kind="rule" data-type="rule" id="new-rule">
  <h2>New rule</h2>
  <label>Section name<input name="section" placeholder="allow_http"></label>
  <label>Name<input name="name"></label>
  <label>Source zone<input name="src"></label>
  <label>Destination zone<input name="dest"></label>
  <label>
    Protocol
    <select name="proto">
      % for choice in ('tcp', 'udp', 'tcpudp', 'icmp', 'all'):
      <option value="{{choice}}">{{choice}}</option>
      % end
    </select>
  </label>
  <label>Source port<input name="src_port"></label>
  <label>Destination port<input name="dest_port"></label>
  <label>
    Target
    <select name="target">
      % for choice in policies:
      <option value="{{choice}}">{{choice}}</option>
      % end
    </select>
  </label>
  <label>Enabled<input type="checkbox" name="enabled" checked></label>
  <div class="actions"><button type="submit">Create</button></div>
</form>

<script>
function firewallValues(form) {
  const field = form.elements;
  if (form.dataset.kind === 'zone') {
    const networks = field.network.value.trim();
    return {
      name: field.name.value,
      input: field.input.value,
      output: field.output.value,
      forward: field.forward.value,
      network: networks ? networks.split(/\s+/) : null,
      masq: field.masq.checked,
      mtu_fix: field.mtu_fix.checked,
    };
  }
  if (form.dataset.kind === 'forwarding') {
    return {
      src: field.src.value,
      dest: field.dest.value,
    };
  }
  return {
    name: field.name.value,
    src: field.src.value,
    dest: field.dest.value,
    proto: field.proto.value,
    src_port: field.src_port.value,
    dest_port: field.dest_port.value,
    target: field.target.value,
    enabled: field.enabled.checked,
  };
}

function bindCreateForm(id) {
  const form = document.getElementById(id);
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const section = form.elements.section.value.trim();
    if (!section) {
      toast('Section name is required', true);
      return;
    }
    try {
      await saveSection('firewall', section, firewallValues(form), form.dataset.type);
      location.reload();
    } catch (error) {
      toast(error.message, true);
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  bindSectionForms(firewallValues);
  ['new-zone', 'new-forwarding', 'new-rule'].forEach(bindCreateForm);
});
</script>
