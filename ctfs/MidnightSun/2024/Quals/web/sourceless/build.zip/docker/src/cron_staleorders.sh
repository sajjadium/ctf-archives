#!/bin/bash
echo "getting cron to work in docker is a rev 500 point challenge"

while true; do 
    /usr/bin/find /app/application/static/ordersheets -name "*.docx" -type f -amin +1 -delete;
    sleep 60;
done;