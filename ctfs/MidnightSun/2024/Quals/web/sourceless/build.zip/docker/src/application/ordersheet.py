from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH

def generate_sheet(user, avatar_small, filename):
    document = Document()

    title = document.add_heading(f'Order sheet for customer #{user.id}', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    document.add_heading('Customer', level=1)

    par = document.add_paragraph()
    run = par.add_run()
    run.add_picture(avatar_small)
    par.alignment = WD_ALIGN_PARAGRAPH.CENTER
    par = document.add_paragraph()
    par.add_run(user.username).bold = True
    par.alignment = WD_ALIGN_PARAGRAPH.CENTER

    document.add_heading('Orders', level=1)

    table = document.add_table(rows=1, cols=3)
    table.style = 'Light Shading'.replace(' ', '')
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = 'Id'
    hdr_cells[1].text = 'Price'
    hdr_cells[2].text = 'Desc'
    for product in user.products:
        row_cells = table.add_row().cells
        row_cells[0].text = str(product.id)
        row_cells[1].text = str(product.price)
        row_cells[2].text = str(product.description)

    document.add_page_break()

    document.save(filename)