from flask_login import UserMixin
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = "user"
    id = db.Column('user_id', db.Integer, primary_key=True)
    username = db.Column(db.String(128), index=True, unique=True)
    isadmin = db.Column(db.Integer, default=0)
    password = db.Column(db.String(128))
    picture = db.Column(db.Text)
    lastactive = db.Column(db.DateTime, default=datetime.now)
    ispublic = db.Column(db.Integer, default=0)

    wallet = db.relationship("Wallet", back_populates="user", uselist=False)
    products = db.relationship('Product', secondary='user_product', lazy='dynamic')

    def __init__(self, username, password, isadmin, picture, ispublic):
        self.username = username
        self.password = password
        self.isadmin = int(isadmin)
        self.picture = picture
        self.ispublic = int(ispublic)
    
    def is_admin(self):
        return (self.isadmin == 1 and self.products.count() == 2)

    def as_dict(self):
        return {c.name: getattr(self, c.name.replace('user_','')) for c in self.__table__.columns}
    

class Wallet(db.Model):
    __tablename__ = "wallet"
    id = db.Column('wallet_id', db.Integer, primary_key = True)
    username = db.Column(db.String(128))
    amount = db.Column(db.Integer())
    user_name = db.Column(db.String(128), db.ForeignKey("user.username"))
    user = db.relationship("User", back_populates="wallet")

    def __init__(self, username, amount):
        self.username = username
        self.amount = amount

class Product(db.Model):
    __tablename__ = "product"
    id = db.Column('product_id', db.Integer, primary_key = True)
    price = db.Column(db.Integer, default=20)
    name = db.Column(db.String(128))
    description = db.Column(db.Text)
    image = db.Column(db.Text)

    def __init__(self, name, description, price, image):
        self.name = name
        self.description = description
        self.price = price
        self.image = image

class UserProduct(db.Model):
    __tablename__ = 'user_product'

    user_name = db.Column(db.String(128), db.ForeignKey('user.username'), primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.product_id'), primary_key=True)