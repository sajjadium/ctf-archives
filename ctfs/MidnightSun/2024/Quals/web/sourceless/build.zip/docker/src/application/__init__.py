from flask import Flask, redirect, url_for
from application.models import db
import os, hashlib, timeago, datetime
from flask_login import LoginManager
from .api import limiter


def init_app():
    app = Flask(__name__, instance_relative_config=False)
    app.config['SQLALCHEMY_DATABASE_URI'] = f"postgresql://{os.getenv('POSTGRES_USER', None)}:{os.getenv('POSTGRES_PASSWORD', None)}@{os.getenv('POSTGRES_HOST', None)}:5432/{os.getenv('POSTGRES_DB', None)}"
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', os.urandom(64).hex()) + os.urandom(64).hex()

    app.config['SESSION_COOKIE_HTTPONLY'] = False
    app.config['DEBUG'] = bool(os.getenv('DEBUG', False)=="True")
    app.config['TEMPLATES_AUTO_RELOAD'] = bool(os.getenv('DEBUG', False)=="True")
    app.config['DOWNLOAD_PREFIX'] = os.urandom(32).hex()

    with app.app_context():
        db.init_app(app)
        limiter.init_app(app)

        login_manager = LoginManager()
        login_manager.login_view = 'auth.login'
        login_manager.init_app(app)
        from .models import User, Wallet, Product

        @login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))
        
        @login_manager.unauthorized_handler
        def unauthorized_callback():
            return redirect(url_for('auth.login'))

        # Recreate db on restart
        User.metadata.drop_all(bind=db.engine)
        User.metadata.create_all(bind=db.engine)
        Wallet.metadata.drop_all(bind=db.engine)
        Wallet.metadata.create_all(bind=db.engine)
        Product.metadata.drop_all(bind=db.engine)
        Product.metadata.create_all(bind=db.engine)

        # Seed users
        admin = User('admin', hashlib.md5(os.urandom(32).hex().encode('utf-8')).hexdigest(), True, '/static/avatars/admin.png', 1)
        adminwallet = Wallet('admin', 1337)
        admin.wallet = adminwallet
        db.session.add(admin)
        db.session.add(adminwallet)
        count = 1
        for goagubbar in ['lasse', 'ronny', 'benke']:
            gogubbe = User(username=goagubbar, password=hashlib.md5(os.urandom(32).hex().encode('utf-8')).hexdigest(), isadmin=False, picture=f'/static/avatars/{count}.png', ispublic=True)
            fattiglapp = Wallet(goagubbar, 1)
            gogubbe.wallet = fattiglapp
            db.session.add(gogubbe)
            db.session.add(fattiglapp)
            count += 1

        db.session.add(Product('Less', 'sourceless code', 25, '/static/less.png'))
        db.session.add(Product('Full', 'sourceful code', 1337, '/static/full.png'))
        db.session.commit()
        
        from .auth import auth as auth_blueprint
        app.register_blueprint(auth_blueprint)

        from .api import api as api_blueprint
        app.register_blueprint(api_blueprint)

        from .main import main as main_blueprint
        app.register_blueprint(main_blueprint)

        @app.after_request
        def apply_hygiene(response):
            response.headers["X-Frame-Options"] = "DENY"
            response.headers["X-Content-Type-Options"] = "nosniff"
            return response
        
        @app.template_filter('timeago')
        def fromnow(date):
            return timeago.format(date, datetime.datetime.now())

        return app