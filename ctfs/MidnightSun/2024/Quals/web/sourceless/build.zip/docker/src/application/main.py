from flask import Blueprint, render_template
from flask_login import current_user

main = Blueprint('main', __name__)

@main.route('/', defaults={'path': ''})
@main.route('/<path:path>')
def index(path):
    if current_user.is_authenticated:
        return render_template('index.html', page='dashboard')
    else:
        return render_template('index.html', page='haiku')
