
class UserForm():
    username = password = error = ""

    def __init__(self, form):
        self.username = form.get('username', default='')
        self.password = form.get('password', default='')

    def validate(self):
        if not 1 <= len(self.username) <= 128:
            self.error = "Username must be between 1 and 128 characters!"
            return False
        
        if not 16 <= len(self.password) <= 128:
            self.error = "Password must be between 16 and 128 characters!"
            return False
        
        if self.username == self.password:
            self.error = "Username and password must be different!"
            return False
        
        return True

class UserRegistrationForm():
    username = password = password2 = picture = error = ""

    def __init__(self, form):
        self.username = form.get('username', default='')
        self.password = form.get('password', default='')
        self.password2 = form.get('password2', default='')
        self.picture = form.get('picture', default='')

    def validate(self):
        if not 1 <= len(self.username) <= 128:
            self.error = "Username must be between 1 and 128 characters!"
            return False
        
        if not 16 <= len(self.password) <= 128:
            self.error = "Password must be between 16 and 128 characters!"
            return False
        
        if self.username == self.password:
            self.error = "Username and password must be different!"
            return False
        
        if not (self.password == self.password2):
            self.error = "Password fields do not match!"
            return False
        
        if not self.picture:
            self.error = "No avatar selected!"
            return False
        
        if not self.picture.startswith('/static/'):
            self.error = "Invalid avatar selected!"
            return False
        
        return True