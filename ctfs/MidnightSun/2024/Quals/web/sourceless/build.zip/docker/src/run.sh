#!/bin/bash

/app/cron_staleorders.sh &

if [ "$DEBUG" == "True" ]; then
    gunicorn --reload -w 1 --timeout 120 -t 10 -k gevent --bind 0.0.0.0:8001 'application:init_app()'
else
    gunicorn -w 1 --timeout 120 -t 10 -k gevent --bind 0.0.0.0:80 'application:init_app()'
fi