from flask import Blueprint, render_template
from flask_login import login_required
from .decorators import require_admin
import hashlib, glob

auth = Blueprint('auth', __name__)

def hash(text):
    return hashlib.md5(text.encode('utf-8')).hexdigest()

def getavatars():
    avatars = []
    for file in glob.glob('application/static/avatars/*.png'):
        if 'admin' in file or 'unknown' in file:
            continue
        avatars.append(file.replace('application/', '', 1))
    return avatars

@auth.route('/login')
def login():
    return render_template('index.html', page='login')

@auth.route('/register')
def register():
    return render_template('index.html', page='register')

@auth.route('/profile/me')
@login_required
def profileme():
    return render_template('index.html', page='profile/me')

@auth.route('/products')
@login_required
def products():
    return render_template('index.html', page='products')

@auth.route('/profile/<int:userid>')
@login_required
def profile(userid):
    return render_template('index.html', page=f'profile/{userid}')

@auth.route('/ordersheet/<int:userid>')
@login_required
@require_admin
def ordersheet(userid):
    return render_template('index.html', page=f'ordersheet/{userid}')