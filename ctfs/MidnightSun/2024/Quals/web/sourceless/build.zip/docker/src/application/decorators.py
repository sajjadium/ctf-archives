from flask import abort
from flask_login import current_user
from functools import wraps

def require_admin(view_function):
    @wraps(view_function)
    def decorated_function(*args, **kwargs):
        if current_user.is_admin():
            return view_function(*args, **kwargs)
        else:
            abort(401)
    return decorated_function