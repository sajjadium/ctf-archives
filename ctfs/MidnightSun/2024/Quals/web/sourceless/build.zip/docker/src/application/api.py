import datetime, subprocess, requests, tempfile, os
from flask import Blueprint, render_template, request, make_response, abort, current_app
from flask_login import login_user, login_required, logout_user, current_user
from .models import db, User, Wallet, Product
from .forms import UserForm, UserRegistrationForm
from .auth import hash, getavatars
from .decorators import require_admin
from .ordersheet import generate_sheet
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from sqlalchemy import text, or_

api = Blueprint('api', __name__)
limiter = Limiter(
    get_remote_address,
    storage_uri="memory://",
)

@api.route('/api/login', methods=['GET'])
def login():
    return render_template('login.html')

@api.route('/api/login', methods=['POST'])
@limiter.limit("1/second", error_message="Too many requests!")
def loginpost():
    userform = UserForm(request.form)
    if not userform.validate():
        return render_template('login.html', error=userform.error)

    user = User.query.filter_by(username=userform.username).first()

    if not user or not user.password == hash(userform.password):
        return render_template('login.html', error='Wrong username or password.')
    else:
        login_user(user)
    user.lastactive = datetime.datetime.now()
    db.session.add(user)
    db.session.commit()
    response = make_response()
    response.headers['HX-Redirect'] = '/dashboard'
    return response

@api.route('/api/register', methods=['GET'])
def register():
    return render_template('register.html', userform=UserRegistrationForm(request.form), avatars=getavatars())

@api.route('/api/register', methods=['POST'])
@limiter.limit("1/second", error_message="Too many requests!")
def registerpost():
    userform = UserRegistrationForm(request.form)
    if not userform.validate():
        return render_template('register.html', error=userform.error, userform=userform, avatars=getavatars())

    user = User.query.filter_by(username=userform.username).first()
    if user:
        return render_template('register.html', error='User already exists!', userform=userform, avatars=getavatars())

    new_user = User(username=userform.username, password=hash(userform.password), isadmin=False, picture=userform.picture, ispublic=False)
    wallet = Wallet(new_user.username, 25)
    new_user.wallet = wallet
    db.session.add(wallet)
    db.session.add(new_user)
    db.session.commit()
    login_user(new_user)

    response = make_response()
    response.headers['HX-Redirect'] = '/dashboard'
    return response

@api.route('/api/haiku')
def haiku():
    return render_template('haiku.html')

@api.route('/api/profile/me', methods=['GET'])
@login_required
def profileme():
    return render_template('profile.html')

@api.route('/api/profile/<int:userid>', methods=['GET'])
@login_required
def profile(userid):
    user = User.query.get(userid)
    error = None
    if not user:
        user = User('unknown', 'unknown', False, '/static/avatars/unknown.png', False)
        user.lastactive = datetime.datetime.now()
        error = 'No such user!'
    else:
        if not current_user.is_admin():
            if user.ispublic == 0 and user.id != current_user.id:
                user = User('unknown', 'unknown', False, '/static/avatars/unknown.png', False)
                user.lastactive = datetime.datetime.now()
                error = 'User is not public!'
    return render_template('profile.html', user=user, error=error)

@api.route('/api/logout')
@login_required
def logout():
    logout_user()
    response = make_response()
    response.headers['HX-Redirect'] = '/'
    return response

@api.route('/api/dashboard', methods=['GET'])
@login_required
def dashboard():
    if current_user.is_admin():
        users = User.query.all()
    else:
        users = User.query.filter(or_(User.id==current_user.id, User.ispublic==1)).all()
    return render_template('dashboard.html', users=users)

@api.route('/api/products', methods=['GET'])
@login_required
def products():
    products = Product.query.all()
    return render_template('products.html', products=products)

@api.route('/api/products/<int:productid>', methods=['POST'])
@login_required
def postproducts(productid):
    product = Product.query.get(productid)
    current_wealth = current_user.wallet.amount
    hasalready = False
    for myproduct in current_user.products:
        if myproduct.id == productid:
            hasalready = True
    if current_user.wallet.amount == 0 or hasalready:
        success = False
        status = 'Youre either broke or youre trying to be!'
    else:
        current_user.wallet.amount -= product.price
        status = ''
        success = True
        rows = 0
        with db.engine.connect() as connection:
            rows = connection.execute(text(f"SELECT 1 FROM wallet WHERE 0>={int(product.price)}-{int(current_wealth)} AND wallet.user_name=:username LIMIT 1"), {"username": current_user.username}).rowcount
        if rows > 0:
            status = 'Purchased!'
            current_user.products.append(product)
            db.session.add(current_user)
            db.session.commit()
        else:
            if product in current_user.products:
                current_user.products.remove(product)
            db.session.add(current_user)
            db.session.commit()
            status = 'You cant afford that!'
            success = False
    return render_template('status.html', status=status, success=success)

@api.route('/api/ordersheet/<int:userid>', methods=['GET'])
@limiter.limit("1/second", error_message="Too many requests!")
@login_required
@require_admin
def ordersheet(userid):
    user = User.query.get(userid)
    if not user:
        abort(400)
    avatarcontent = requests.get(f"{request.url_root.rstrip('/')}{user.picture}").content
    tmp = tempfile.NamedTemporaryFile(delete=False)
    tmp.write(avatarcontent)
    smallname = tmp.name+'_small.png'
    subprocess.Popen(["/usr/bin/convert", tmp.name, '-resize', '100x100', smallname])
    tmp.close()
    sheetname = f'{current_app.config["DOWNLOAD_PREFIX"]}_{os.urandom(32).hex()}_{user.id}.docx'
    generate_sheet(user, smallname, f'/app/application/static/ordersheets/{sheetname}')
    os.unlink(tmp.name)
    os.unlink(smallname)
    downloadurl = f'{request.url_root}static/ordersheets/{sheetname}'
    sheeturl = f'https://view.officeapps.live.com/op/embed.aspx?src={downloadurl}'  

    return render_template('ordersheet.html', sheeturl=sheeturl, downloadurl=downloadurl)