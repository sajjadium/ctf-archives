#!/bin/sh
python3 /run.py
