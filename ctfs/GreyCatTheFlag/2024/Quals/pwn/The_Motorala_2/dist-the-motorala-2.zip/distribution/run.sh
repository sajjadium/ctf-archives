#!/bin/sh
WASMTIME_NEW_CLI=0 wasmtime --dir=./ --config=./cache.toml ./chall
