package secrets

var Flag = "grey{fake_flag}";
