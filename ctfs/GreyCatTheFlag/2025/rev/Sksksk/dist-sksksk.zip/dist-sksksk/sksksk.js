const s = x => y => z => x(z)(y(z));
const k = x => y => x;
const a = s(s(k(s))(k))
const b = s(k(s))(s(k(s(k(s))(k))))
const c = s(k(s))(k)
const d = s(s(k(s))(k))(s(k)(k))
const e = b(d)(a(d))
const f = s(k(s(s(k)(k))))(s(k(s(k)(k)))(k))
const g = s(k(s(k(s(k(f(s(k)(k))))))))(s(k(s(k(s(k)(k)))))(s(k(s(k(s(s(k(f))(k))))))(s(k(s(k(k))))(s(k(s(s(k(f))(s(k(s(k(s(s(k)(k))))))(s(k(s(k(k))))(f))))))(k)))))
const h = s(k(s(f(g))))(k)
const i = s(s)(k(k(s(k))))
const j = s(k(s(k(s(s(s(k)(k))(k(k(s(k)))))(k(k))))))(h)
const l = s(s(k(s))(s(k(s(k(i))))(j)))(s(k(s(j)))(k))
const flag = s(s(l(b(c(c(d)(e))(c(d)(e)))(a(d))))(k(s(s(l(c(c(d)(a(d)))(g(c(e)(b(d)(d))))))(k(s(s(l(b(c(b(c(d)(h(e)(d)))(e))(c(a(d))(a(d))))(d)))(k(s(s(l(c(b(c(d)(a(d)))(e))(b(c(d)(a(d)))(e))))(k(s(s(l(c(a(d))(a(c(c(c(d)(d))(d))(e)))))(k(s(s(l(c(e)(b(d)(c(a(d))(b(d)(e))))))(k(s(s(l(g(c(b(b(d)(d))(e))(b(d)(c(d)(e))))))(k(s(s(l(c(e)(b(d)(c(a(d))(b(d)(e))))))(k(s(s(l(g(c(b(b(d)(d))(e))(b(d)(c(d)(e))))))(k(s(s(l(c(e)(g(c(b(d)(d))(e)))))(k(s(s(l(c(e)(a(c(d)(e)))))(k(s(s(l(c(a(d))(g(c(e)(c(c(d)(d))(d))))))(k(s(s(l(c(c(d)(a(d)))(g(c(e)(b(d)(d))))))(k(s(s(l(c(b(e)(d))(b(e)(d))))(k(s(s(l(c(c(d)(e))(a(c(d)(e)))))(k(s(s(l(b(c(c(d)(e))(c(d)(e)))(a(d))))(k(s(s(l(c(e)(g(c(b(d)(d))(e)))))(k(s(s(l(c(g(c(d)(e)))(a(c(d)(e)))))(k(s(s(l(c(a(b(d)(e)))(a(e))))(k(s(s(l(g(c(c(d)(e))(a(c(d)(e))))))(k(s(s(l(c(c(c(d)(d))(c(d)(d)))(b(d)(e))))(k(s(s(l(c(b(e)(d))(b(e)(d))))(k(s(s(l(a(c(e)(c(d)(e)))))(k(s(s(l(c(e)(a(c(d)(e)))))(k(s(s(l(a(c(e)(c(d)(e)))))(k(s(s(l(c(b(e)(b(d)(d)))(b(d)(e))))(k(s(s(l(c(e)(g(c(b(d)(d))(e)))))(k(s(s(l(c(e)(b(d)(c(a(d))(b(d)(e))))))(k(s(s(l(g(c(b(b(d)(d))(e))(b(d)(c(d)(e))))))(k(s(s(l(c(e)(b(d)(c(a(d))(b(d)(e))))))(k(s(s(l(g(c(b(b(d)(d))(e))(b(d)(c(d)(e))))))(k(l(c(e)(c(e)(e))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k))))))(k(s(k)))
