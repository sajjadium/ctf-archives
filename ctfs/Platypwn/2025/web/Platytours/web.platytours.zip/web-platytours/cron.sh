#!/bin/bash

while :
do
    python manage.py reward
    sleep 60
done
