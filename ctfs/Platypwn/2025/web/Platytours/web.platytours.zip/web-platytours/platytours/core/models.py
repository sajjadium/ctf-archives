from django.contrib.auth.models import User
from django.db import models


class TimestampMixin(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
        ordering = ["-timestamp"]


class Platypus(User):
    class Meta:
        proxy = True

    @property
    def balance(self):
        return Transaction.objects.filter(user=self).aggregate(
            sum=models.Sum("amount", default=0)
        )["sum"]

    @property
    def rewards(self):
        return Reward.objects.filter(user=self).aggregate(
            sum=models.Sum("amount", default=0)
        )["sum"]

    @property
    def unread_notifications(self):
        return Notification.objects.filter(user=self, read=False).count()


class Tour(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    date = models.DateField()
    price = models.IntegerField()
    reward = models.IntegerField()

    class Meta:
        ordering = ["date"]

    def __str__(self):
        return self.name


class Booking(TimestampMixin, models.Model):
    user = models.ForeignKey(
        Platypus, verbose_name="Bought by", on_delete=models.CASCADE
    )
    tour = models.ForeignKey(Tour, on_delete=models.PROTECT)
    participant_name = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.participant_name} @ {self.tour}"


class Transaction(TimestampMixin, models.Model):
    user = models.ForeignKey(Platypus, on_delete=models.CASCADE)
    amount = models.IntegerField()
    description = models.CharField(max_length=100, null=True)
    booking = models.ForeignKey(
        Booking, blank=True, null=True, on_delete=models.SET_NULL
    )

    def __str__(self):
        return f"${self.amount} by {self.user}"


class Reward(TimestampMixin, models.Model):
    user = models.ForeignKey(Platypus, on_delete=models.CASCADE)
    amount = models.IntegerField()
    description = models.CharField(max_length=100, null=True)
    booking = models.ForeignKey(
        Booking, blank=True, null=True, on_delete=models.SET_NULL
    )

    def __str__(self):
        return f"{self.amount} points for {self.user}"


class Notification(TimestampMixin, models.Model):
    user = models.ForeignKey(Platypus, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    body = models.TextField()
    read = models.BooleanField(default=False)
    editable = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.title} for {self.user}"


class CronRun(TimestampMixin, models.Model):
    pass
