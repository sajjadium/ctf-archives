import os
from datetime import datetime, timedelta, timezone

from platytours.core.models import CronRun


def get_flag_or_raise():
    flag = os.getenv("FLAG")
    if flag is None or not flag.startswith("PP{"):
        raise RuntimeError("No valid flag provided. Exiting")
    return flag


def ensure_cron():
    run = CronRun.objects.first()
    age = datetime.now(timezone.utc) - run.timestamp
    if age > timedelta(minutes=2):
        raise RuntimeError("Cron job did not run for more than 2 minutes")
