from django.urls import include, path

urlpatterns = [
    path("", include("platytours.core.urls")),
]
