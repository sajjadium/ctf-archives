from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.db import transaction
from django.http import (
    Http404,
    HttpResponse,
    HttpResponseForbidden,
    HttpResponseRedirect,
)
from django.shortcuts import render
from django.urls import reverse_lazy
from django.utils import timezone
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from platytours.core.forms import (
    BookingForm,
    NotificationForm,
    NotificationReadForm,
    PlatypusCreationForm,
)
from platytours.core.models import (
    Booking,
    Notification,
    Platypus,
    Reward,
    Tour,
    Transaction,
)
from platytours.core.utils import ensure_cron, get_flag_or_raise


def home_view(request):
    return render(
        request,
        "core/home.html",
        {
            "start_balance": settings.PLATYTOURS_START_BALANCE,
            "tours": Tour.objects.filter(date__gte=timezone.now()),
        },
    )


def health_view(request):
    get_flag_or_raise()
    ensure_cron()
    return HttpResponse("ok")


def about_view(request):
    return render(
        request,
        "core/about.html",
        {
            "start_balance": settings.PLATYTOURS_START_BALANCE,
            "flag_threshold": settings.PLATYTOURS_FLAG_THRESHOLD,
        },
    )


class SignupView(SuccessMessageMixin, CreateView):
    model = Platypus
    form_class = PlatypusCreationForm
    template_name = "core/signup.html"
    success_url = reverse_lazy("core:login")
    success_message = "You registered successfully"


class BookingView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    model = Booking
    form_class = BookingForm
    success_url = reverse_lazy("core:home")

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["initial"] = {"user": self.request.user, "tour": self.tour}
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["tour"] = self.tour
        return context

    def dispatch(self, request, *args, **kwargs):
        try:
            self.tour = Tour.objects.get(pk=kwargs["tour_id"])
        except Tour.DoesNotExist:
            raise Http404(f"Tour {kwargs['tour_id']} does not exist")
        return super().dispatch(request, *args, **kwargs)

    def get_success_message(self, cleaned_data):
        return f"You successfully registered {cleaned_data['participant_name']} for {self.tour}"

    def post(self, request, *args, **kwargs):
        with transaction.atomic():
            return super().post(request, *args, **kwargs)

    def form_valid(self, form):
        self.object: Booking = form.save()
        user = self.object.user
        tour = self.object.tour
        Transaction.objects.create(
            user=user,
            amount=-tour.price,
            description="Tour booked",
            booking=self.object,
        )
        Reward.objects.create(
            user=user,
            amount=tour.reward,
            description="Tour booked",
            booking=self.object,
        )
        user.refresh_from_db()
        assert user.balance >= 0, "You don't have enough money to book this tour."
        return HttpResponseRedirect(self.get_success_url())


@login_required
def account_view(request):
    booked_tours = Booking.objects.filter(user=request.user).count()
    unread_notifications = Notification.objects.filter(
        user=request.user, read=False
    ).count()

    return render(
        request,
        "core/account.html",
        {"booked_tours": booked_tours, "unread_notifications": unread_notifications},
    )


class UserSpecificListView(LoginRequiredMixin, ListView):
    def get_queryset(self):
        return super().get_queryset().filter(user=self.request.user)


class BookingsView(UserSpecificListView):
    model = Booking


class TransactionsView(UserSpecificListView):
    model = Transaction


class RewardsView(UserSpecificListView):
    model = Reward


class NotificationsView(UserSpecificListView):
    model = Notification


class NotificationCreateView(LoginRequiredMixin, CreateView):
    model = Notification
    form_class = NotificationForm
    success_url = reverse_lazy("core:notifications")

    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs["initial"] = {"user": self.request.user, "editable": True}
        return kwargs


class NotificationUpdateView(LoginRequiredMixin, UpdateView):
    model = Notification
    form_class = NotificationForm
    success_url = reverse_lazy("core:notifications")

    def dispatch(self, request, *args, **kwargs):
        notification: Notification = self.get_object()
        if notification.user != self.request.user or not notification.editable:
            return HttpResponseForbidden()
        return super().dispatch(request, *args, **kwargs)


class NotificationDeleteView(LoginRequiredMixin, SuccessMessageMixin, DeleteView):
    model = Notification
    success_url = reverse_lazy("core:notifications")
    success_message = "Notification deleted successfully."

    def dispatch(self, request, *args, **kwargs):
        notification: Notification = self.get_object()
        if notification.user != self.request.user or not notification.editable:
            return HttpResponseForbidden()
        return super().dispatch(request, *args, **kwargs)


class NotificationReadView(LoginRequiredMixin, UpdateView):
    model = Notification
    form_class = NotificationReadForm
    success_url = reverse_lazy("core:notifications")
    http_method_names = ["post"]
