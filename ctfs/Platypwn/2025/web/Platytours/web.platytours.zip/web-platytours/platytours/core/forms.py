from django import forms
from django.contrib.auth.forms import UserCreationForm

from platytours.core.models import Booking, Notification, Platypus, Tour, Transaction


class PlatypusCreationForm(UserCreationForm):
    def save(self, commit=True):
        user = super().save(commit)
        Transaction.objects.create(
            user=user, amount=100, description="Welcome to Platytours"
        )
        return user


class BookingForm(forms.ModelForm):
    user = forms.ModelChoiceField(Platypus.objects.all(), disabled=True)
    tour = forms.ModelChoiceField(Tour.objects.all(), disabled=True)

    class Meta:
        model = Booking
        fields = ["user", "tour", "participant_name"]

    def clean(self):
        cleaned_data = super().clean()
        if cleaned_data["user"].balance - cleaned_data["tour"].price < 0:
            raise forms.ValidationError(
                "You don't have enough money to book this tour."
            )
        return cleaned_data


class NotificationForm(forms.ModelForm):
    user = forms.ModelChoiceField(
        Platypus.objects.all(), disabled=True, widget=forms.HiddenInput
    )
    editable = forms.BooleanField(disabled=True, widget=forms.HiddenInput)

    class Meta:
        model = Notification
        fields = ["user", "title", "body", "editable"]


class NotificationReadForm(forms.ModelForm):
    class Meta:
        model = Notification
        fields = ["read"]
