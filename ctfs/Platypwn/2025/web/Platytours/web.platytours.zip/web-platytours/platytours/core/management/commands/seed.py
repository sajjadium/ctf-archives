import datetime

from django.core.management import BaseCommand
from django.db import transaction

from platytours.core.models import Tour
from platytours.core.utils import get_flag_or_raise


class Command(BaseCommand):
    help = "Check whether the database is empty and seed it if necessary"

    def handle(self, *args, **options):
        # Check whether flag is provided
        # If there is no flag, exit with error so that challenge startup gets canceled
        get_flag_or_raise()

        with transaction.atomic():
            if not Tour.objects.exists():
                print("The database does not contain tours yet. Adding default tours…")
                Tour.objects.create(
                    name="Day trip",
                    description="This is a short tour, taking only a single day.",
                    date=datetime.date(2025, 12, 1),
                    price=30,
                    reward=10,
                )
                Tour.objects.create(
                    name="Week trip",
                    description="This is a long trip, taking a full week.",
                    date=datetime.date(2025, 12, 2),
                    price=50,
                    reward=15,
                )
                print("Default tours added.")
            else:
                print("The database already contains tours. Skipping initialization…")
