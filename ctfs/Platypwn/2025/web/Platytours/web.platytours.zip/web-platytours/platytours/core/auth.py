from django.contrib.auth.backends import ModelBackend

from platytours.core.models import Platypus


class ProxiedModelBackend(ModelBackend):
    def get_user(self, user_id):
        try:
            return Platypus.objects.get(pk=user_id)
        except Platypus.DoesNotExist:
            return None
