from django.conf import settings
from django.core.management import BaseCommand
from django.db import transaction
from django.db.models import Sum

from platytours.core.models import CronRun, Notification, Platypus, Reward
from platytours.core.utils import get_flag_or_raise

FLAG_NOTIFICATION_TITLE = "Here is your flag"


class Command(BaseCommand):
    help = "Hand out flag to all users that have exceeded the reward threshold"

    def handle(self, *args, **options):
        flag = get_flag_or_raise()
        with transaction.atomic():
            for platypus in Platypus.objects.annotate(
                reward_sum=Sum("reward__amount", default=0)
            ).filter(
                reward_sum__gte=settings.PLATYTOURS_FLAG_THRESHOLD,
                notification__title__regex=rf"^(?!{FLAG_NOTIFICATION_TITLE}$)",
            ):
                Notification.objects.create(
                    user=platypus,
                    title=FLAG_NOTIFICATION_TITLE,
                    body=flag,
                )
                Reward.objects.create(
                    user=platypus,
                    amount=-settings.PLATYTOURS_FLAG_THRESHOLD,
                    description="Redeemed for flag",
                )
            CronRun.objects.create()
