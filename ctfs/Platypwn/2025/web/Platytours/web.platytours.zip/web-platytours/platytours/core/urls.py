from django.contrib.auth import views as auth_views
from django.urls import path

from platytours.core.views import (
    BookingsView,
    BookingView,
    NotificationCreateView,
    NotificationDeleteView,
    NotificationReadView,
    NotificationsView,
    NotificationUpdateView,
    RewardsView,
    SignupView,
    TransactionsView,
    about_view,
    account_view,
    health_view,
    home_view,
)

app_name = "core"
urlpatterns = [
    path("", home_view, name="home"),
    path("health/", health_view, name="health"),
    path("about/", about_view, name="about"),
    path("book/<int:tour_id>/", BookingView.as_view(), name="book"),
    path("account/", account_view, name="account"),
    path("account/bookings/", BookingsView.as_view(), name="bookings"),
    path("account/transactions/", TransactionsView.as_view(), name="transactions"),
    path("account/rewards/", RewardsView.as_view(), name="rewards"),
    path("account/notifications/", NotificationsView.as_view(), name="notifications"),
    path(
        "account/notifications/create/",
        NotificationCreateView.as_view(),
        name="notification_create",
    ),
    path(
        "account/notifications/<int:pk>/",
        NotificationUpdateView.as_view(),
        name="notification_update",
    ),
    path(
        "account/notifications/<int:pk>/read/",
        NotificationReadView.as_view(),
        name="notification_read",
    ),
    path(
        "account/notifications/<int:pk>/delete/",
        NotificationDeleteView.as_view(),
        name="notification_delete",
    ),
    path("login/", auth_views.LoginView.as_view(), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path("signup/", SignupView.as_view(), name="signup"),
]
