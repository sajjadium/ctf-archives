#!/bin/sh

set -e

cd /app

python manage.py migrate
python manage.py seed
python manage.py reward

supervisord -c /app/supervisord.conf
