# Platytours

## Bare Metal Development Setup

1. [Install `uv`](https://docs.astral.sh/uv/getting-started/installation/)
1. Create a virtual environment: `uv venv`
1. Install dependencies: `uv sync`
1. Create & migrate database: `DEBUG=true python manage.py migrate`
1. Run server: `DEBUG=true python manage.py runserver`

## Container Setup

You can use the provided `compose.yaml` file to run the challenge in a container. Please note:

- The provided setup uses persistent database storage for your convenience. The remote instance will be reset upon restart.
- File permissions are not preserved in the downloaded zip. Please uncomment line 30 in the Dockerfile before building the container.
