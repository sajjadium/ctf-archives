package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
)

func main() {
	flagValue, ok := os.LookupEnv("FLAG")
	if !ok || flagValue == "" {
		log.Fatalf("required environment variable FLAG is not set")
	}

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "You cannot pass. I am a servant of the secret fire, wielder of the flame of Anor. Your dark magic will not avail you, flame of Udûn. This flag stands under my protection! You cannot pass.")
	})

	http.HandleFunc("/flag", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, flagValue)
	})

	addr := "127.0.0.1:9000"
	log.Printf("Server starting on %s\n", addr)
	if err := http.ListenAndServe(addr, nil); err != nil {
		log.Fatalf("server failed: %v", err)
	}
}
