use anyhow::{Result, anyhow};
use std::{env, io::stdin, path::Path, process::Command};

fn run_command() -> Result<String> {
    let _flag = env::var("FLAG").unwrap();

    let mut line = String::new();
    stdin().read_line(&mut line)?;

    let allowed_binaries = [
        "cat", "cp", "echo", "ll", "ls", "ps", "pwd", "sha1sum", "touch",
    ];

    let args = line
        .trim()
        .split(" ")
        .map(|arg| {
            if !arg.chars().all(|char| match char {
                'a'..='z' | 'A'..='Z' | '0'..='9' => true,
                _ => false,
            }) {
                return Err(anyhow!("Invalid argument: {}", arg));
            }

            if allowed_binaries.contains(&arg) {
                return Ok(Path::new("/bin").join(arg));
            }

            Ok(Path::new("./").join(arg))
        })
        .collect::<Result<Vec<_>, _>>()?;

    let output = Command::new(&args[0]).args(&args[1..]).output()?;
    if !output.status.success() {
        let stderr = String::from_utf8(output.stderr)?;
        return Err(anyhow!(stderr));
    }

    let stdout = String::from_utf8(output.stdout)?;

    if args[0].as_os_str() == "/bin/sha1sum"
        && stdout.starts_with("e80a903c5b91a0481185caa4e07348f7f0aebdac")
    {
        println!("Gah! A copy pasta. You should stay away from it.");
    }

    Ok(stdout)
}

fn main() {
    println!(
        "Welcome to the pasta safari.

There are many types of pasta to explore. However, keep an eye out for the so-called copy pasta.

This pasta is special, because it has been copied a lot of times, and so it is now
present all over this operating system. I've documented it's SHA1 hash somewhere,
so you can identify it. Please, be careful and try to identify the copy pasta before
interacting with it. It really is that dangerous."
    );
    loop {
        match run_command() {
            Ok(output) => println!("Here you go: {}", output),
            Err(err) => println!("Oh no! {}", err),
        };
    }
}
