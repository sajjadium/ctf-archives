import secrets
import os
import sys
from ecdsa.ellipticcurve import Point
from ecdsa import curves
from Crypto.Hash import HMAC, SHA256
from Crypto.Util.number import bytes_to_long as b2l
from Crypto.Util.number import long_to_bytes as l2b

curve = curves.BRAINPOOLP512r1

G = curve.generator
n = int(curve.order)


# A good ROM needs some shuffling and RSA primes!
def ROM(sk: int, msg:bytes) -> bytes:
    p1, p2 = (580978144503409743849549551277363344732712194923864516788206394429365639,651101336038834306152375970124343490846460623408573950428198774918879369)
    x = b2l(HMAC.new(l2b(sk + 1), digestmod=SHA256).update(msg).digest())
    y = b2l(HMAC.new(l2b(sk - 1), digestmod=SHA256).update(msg).digest())

    xx = x % p1
    yy = y % p2

    xxx = b2l(xx.to_bytes(64, "big"))
    yyy = b2l(yy.to_bytes(64, "little"))

    return (xxx + yyy)& ~(1<<n.bit_length())  # microoptmization instead of slow modulo


def H(m: bytes) -> int:
    return b2l(SHA256.new(m).digest()) % n


class ECGDSA:
    def kgen():
        sk = secrets.randbelow(n - 2) + 1
        pk = pow(sk, -1, n) * G
        return sk, pk

    def sign(sk: int, message: bytes):

        ctr = 0

        while True:
            k = ROM(sk + ctr, message)

            Q = k * G
            r = Q.x() % n

            if r == 0:
                continue
            s = ((k * r - H(message)) * sk) % n

            if s == 0:
                continue
            return r, s

    def verify(pk: Point, message: bytes, r: int, s: int):

        if r <= 0 or r >= n:
            return False
        if s <= 0 or s >= n:
            return False

        rinv = pow(r, -1, n)
        u1 = (rinv * H(message)) % n
        u2 = (rinv * s) % n

        Q = u1 * G + u2 * pk
        if Q == n * G:
            return False

        v = Q.x() % n
        return v == r


def main():

    FLAG = os.getenv("FLAG")
    if FLAG is None:
        print("Please set the flag via env variable!")
        sys.exit(1)

    iterations = SHA256.digest_size - 11

    sk, pk = ECGDSA.kgen()
    print(f"Here is my public key ({pk.x():x},{pk.y():x})")
    for _ in range(iterations):

        try:
            command = input(">> ").strip()

            if command.startswith("sign"):
                parts = command.split()
                if len(parts) != 2:
                    print("Usage: sign <hex_msg>")
                    continue
                msg = bytes.fromhex(parts[1])
                if b"Authorize Flag!" in msg:
                    print("Message rejected.")
                    continue
                r, s = ECGDSA.sign(sk, msg)
                print(f"r = {r:x}")
                print(f"s = {s:x}")

            elif command.startswith("flag"):
                parts = command.split()
                if len(parts) != 3:
                    print("Usage: flag <hex_r> <hex_s>")
                    continue
                r = b2l(bytes.fromhex(parts[1]))
                s = b2l(bytes.fromhex(parts[2]))
                msg = b"Authorize Flag!"
                if ECGDSA.verify(pk, msg, r, s):
                    print(FLAG)
                else:
                    print(b"Unauthorized admin! This incident will be reported!")
                    return

            elif command.startswith("quit"):
                print("Bye!")
                return
            else:
                print("Unknown command. Use 'sign' or 'flag' or 'quit'.")

        except Exception as e:
            print(f"Error! (Maybe you did not supply the message as hex?)")
            print(e, file=sys.stderr)
            # raise e
            continue


if __name__ == "__main__":
    main()
