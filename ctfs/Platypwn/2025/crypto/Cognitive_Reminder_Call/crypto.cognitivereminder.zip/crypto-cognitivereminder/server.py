from binascii import crc32
import os
import secrets
import sys
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.hashes import Hash, SHA256
from cryptography.hazmat.primitives.padding import PKCS7


def mac(key, message):
    return crc32(key + message).to_bytes(4)


def send_authenticated(key, used_nonces, message):
    nonce = secrets.token_bytes(4)
    while nonce in used_nonces:
        nonce = secrets.token_bytes(4)
    used_nonces.add(nonce)

    tag = mac(key, nonce + message.encode())
    print(message)
    print(f'Note: This message was sent over an authenticated channel. Its tag is {tag.hex()} with nonce {nonce.hex()}.')


def encrypt(key_parts, message):
    iv = secrets.token_bytes(16)

    hasher = Hash(SHA256())
    for part in key_parts:
        hasher.update(part)
    key = hasher.finalize()

    padder = PKCS7(128).padder()
    plaintext = padder.update(message.encode()) + padder.finalize()

    cipher = Cipher(algorithms.AES256(key),  modes.CBC(iv))
    encryptor = cipher.encryptor()
    return iv + encryptor.update(plaintext) + encryptor.finalize()


def main():
    flag = os.getenv('FLAG')
    if flag is None:
        print('Please set the flag via env variable!')
        sys.exit(1)

    enc_key_parts = [secrets.token_bytes(16) for _ in range(4)]
    mac_key = secrets.token_bytes(16)
    used_nonces = set()

    send_authenticated(mac_key, used_nonces, f'Here is the flag: {encrypt(enc_key_parts, flag).hex()}')

    enc_key_parts_checksums = list(map(lambda kp: crc32(kp), enc_key_parts))
    enc_key_parts = None
    send_authenticated(mac_key, used_nonces, 'I have forgotten my key :(\nBut here are 4 congnitive reminders of my key:')
    send_authenticated(mac_key, used_nonces, str(enc_key_parts_checksums))

    try:
        print('Please remind me of my key:')
        part1 = bytes.fromhex(input('Part 1 (hex): '))
        part2 = bytes.fromhex(input('Part 2 (hex): '))
        part3 = bytes.fromhex(input('Part 3 (hex): '))
        part4 = bytes.fromhex(input('Part 4 (hex): '))
        print('This is an authenticated channel!')
        nonce = bytes.fromhex(input('Please provide your nonce (hex): '))
        tag = bytes.fromhex(input('Please provide the tag of the concatenation of the nonce and the 4 parts (hex): '))
    except ValueError:
        print('Invalid hex!')
        sys.exit(1)

    if len(nonce) != 4:
        print('Nonce must be 4 bytes long!')
        sys.exit(1)
    if nonce in used_nonces:
        print('Nonces must not be reused!')
        sys.exit(1)
    if not secrets.compare_digest(mac(mac_key, nonce + part1 + part2 + part3 + part4), tag):
        print('Invalid tag!')
        sys.exit(1)
    if crc32(part1) != enc_key_parts_checksums[0] or crc32(part2) != enc_key_parts_checksums[1] or crc32(part3) != enc_key_parts_checksums[2] or crc32(part4) != enc_key_parts_checksums[3]:
        print('I cannot remember it!')
        sys.exit(1)
    enc_key_parts = [part1, part2, part3, part4]
    send_authenticated(mac_key, used_nonces, f'Thanks for reminding me! Here is a reward: {encrypt(enc_key_parts, flag).hex()}')


if __name__ == '__main__':
    main()
