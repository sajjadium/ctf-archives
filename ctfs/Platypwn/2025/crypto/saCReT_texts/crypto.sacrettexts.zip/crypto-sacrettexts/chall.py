#!/usr/bin/env python
from base64 import b64encode
from math import gcd, lcm
from pathlib import Path
from os import environ, urandom

from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random.random import getrandbits, randrange
from Crypto.Util.number import getPrime, inverse, size

FLAG = environ["FLAG"]

def EEA(a, b):
    if b == 0:
        return (a, 1, 0)
    g, s, t = EEA(b, a % b)
    return (g, t, s - (a // b) * t)


def CRT(r1, r2, m1, m2):
    g, k1, k2 = EEA(m1, m2)
    assert (r2 - r1) % g == 0, "CRT not possible"
    m = lcm(m1, m2)
    r = (r1 + m1 * k1 * (r2 - r1) // g) % m
    return r, m


# The sacret texts mentioned this problem
# - but not its solution. Can you solve it?

def generate_key(nbits=int("".join(reversed("5202")))):
    p = getPrime(nbits // 2)
    q = getPrime(nbits // 2)
    N = p * q
    φ = (p - 1) * (q - 1)

    d = 0
    while gcd(d, φ) != 1:
        dp = getrandbits(nbits // 2 - 1)
        if size(dp) < nbits // 3:
            continue

        dq = getrandbits((nbits - 1) & ((2 << nbits.bit_length() // 2) - 1))
        if (dp - dq) % gcd(p - 1, q - 1) != 0:
            continue

        d, m = CRT(dp, dq, p - 1, q - 1)
        d += randrange(0, φ // m) * m

    e = inverse(d, φ)
    return RSA.construct((N, e, d, p, q))

file = Path("./key")
try:
    with file.open("rb") as f:
        rsa_key = RSA.import_key(f.read())
except:
    rsa_key = generate_key()
    with file.open("wb") as f:
        f.write(rsa_key.export_key())

aes_key = urandom(32)
nonce = urandom(12)

cipher = PKCS1_OAEP.new(rsa_key)
enc_aes_key = cipher.encrypt(aes_key)

cipher = AES.new(aes_key, AES.MODE_GCM, nonce=nonce)
ciphertext, tag = cipher.encrypt_and_digest(FLAG.encode())

print(rsa_key.public_key().export_key().decode())
print(f"enc_aes_key: {b64encode(enc_aes_key).decode()}")
print(f"nonce: {b64encode(nonce).decode()}")
print(f"ciphertext: {b64encode(ciphertext).decode()}")
print(f"tag: {b64encode(tag).decode()}")
