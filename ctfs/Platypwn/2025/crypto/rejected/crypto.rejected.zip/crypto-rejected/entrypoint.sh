#!/bin/sh
set -e

if [ -e /app/debug ]
then
    chmod 0777 /app/debug
fi

su --preserve-environment app <<EOF
set -e
mkdir -p /data/public
/app/generate_keys /data/sk /data/public/pk
exec $@
EOF
