#!/usr/bin/env python3

import os
import tempfile
from flask import Flask, jsonify, render_template, request, send_from_directory, url_for
from pathlib import Path
from threading import Thread
from multiprocessing import Lock, Manager
import subprocess

app = Flask(__name__)

FLAG = Path('/flags/flag.txt').read_bytes()
assert FLAG

PUBLIC_DIR = Path('/data/public')
SK_FILE = Path('/data/sk')
SIGFILE = Path('/data/sig')


class Signatures():
    def __init__(self):
        self._lock = Lock()

        self.ns = Manager().Namespace()
        self.ns.generated = []
        self.ns.progress = 0
        self.ns.status = 'ready'

        self._limit = int(os.environ.get("GEN_TOTAL", 200_000))
        self._limit_flag2 = int(os.environ.get("GEN_MAX_FLAG2", 20_000))
        self._chunksize = int(os.environ.get("GEN_CHUNK", 10_000))

    def generate(self):
        with self._lock:
            if self.ns.status == 'generating':
                return 403, 'Working on it.'
            if self._chunksize * len(self.ns.generated) >= self._limit:
                return 403, 'That should be enough signatures.'

            self.ns.progress = 0
            self.ns.status = 'generating'
            start = self._chunksize * len(self.ns.generated)

            def gen():
                sigfile = PUBLIC_DIR / f'sigs_{start}_{start+self._chunksize-1}.bin'
                process = subprocess.Popen(
                    ['/app/generate_sigs', SK_FILE, sigfile, f'{min(self._chunksize, self._limit-start)}', f'{start}'],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                )

                while True:
                    output = process.stdout.readline()
                    if output == '' and process.poll() is not None:
                        break
                    if output:
                        with self._lock:
                            self.ns.progress = int(output)

                code = process.wait()
                if code != 0:
                    app.logger.error(f'generate_sigs terminated with code {code}: {process.stderr.read()}')
                with self._lock:
                    self.ns.generated += [sigfile]
                    if self._chunksize * len(self.ns.generated) >= self._limit:
                        self.ns.status = 'enough'
                    else:
                        self.ns.status = 'ready'

            t = Thread(target=gen)
            t.start()
            return 201, 'Started generation.'

    def files(self):
        with self._lock:
            return self.ns.generated[:]

    def status(self):
        with self._lock:
            return self.ns.status, self.ns.progress


@app.get("/")
def index():
    return render_template("index.html", limit=sigs._limit)


@app.get("/data/<path:filename>")
def downloadfile(filename):
    return send_from_directory(PUBLIC_DIR, filename)


@app.get("/data")
def filelist():
    files = sigs.files()
    return jsonify([{
        "path": url_for("downloadfile", filename=f.name),
        "name": f.name
    } for f in files]), 200


@app.get("/status")
def status():
    status, progress = sigs.status()
    return jsonify({
        "status": status,
        "progress": progress,
    }), 200


@app.post("/generate")
def generate_signatures():
    code, desc = sigs.generate()
    return jsonify({
        "msg": desc,
    }), code


@app.post("/flag")
def get_flag():
    if "signature_file" not in request.files:
        return 'missing file', 400
    sigfile = request.files["signature_file"]

    with tempfile.NamedTemporaryFile() as file:
        sigfile.save(file.name)
        try:
            msg = subprocess.check_output(
                ['/app/verify_sig', PUBLIC_DIR/'pk', file.name],
                stderr=subprocess.PIPE,
                text=False
            )
        except subprocess.CalledProcessError as e:
            return f'signature invalid: {e.stderr.decode()}', 400

    if msg != b'forge me for flag':
        return 'wrong message signed', 400

    return FLAG, 200

sigs = Signatures()
if __name__ == "__main__":
    app.run(debug=False, host='0.0.0.0', port=8080)
