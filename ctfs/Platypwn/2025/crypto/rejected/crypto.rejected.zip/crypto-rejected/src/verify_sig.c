#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "sign.h"
#include "debug.h"

int main(int argc, char *argv[])
{
    FILE *pkfile, *sigfile;
    uint8_t pk[CRYPTO_PUBLICKEYBYTES];
    uint8_t *sig_msg = NULL;

    if (argc != 3)
    {
        fprintf(stderr,
                "%s - Verify a signature and print its message.\n"
                "Usage: %s <pk_file> <sig_file>\n",
                argv[0], argv[0]);
        exit(1);
    }

    FILE *debug_file = NULL;
    char *debug = getenv("VERIFY_DEBUG");
    if (debug != NULL) {
        if ((debug_file = fopen(debug, "a")) == NULL)
        {
            perror("open debug file");
            exit(1);
        }
    }

    if ((pkfile = fopen(argv[1], "r")) == NULL)
    {
        perror("open pk_file");
        exit(1);
    }
    if (fread(pk, CRYPTO_PUBLICKEYBYTES, 1, pkfile) != 1)
    {
        perror("read pk_file");
        fclose(pkfile);
        exit(1);
    };
    fclose(pkfile);

    if (debug_file != NULL) {
        fprint_pk(debug_file, pk);
        fprintf(debug_file, "\n");
    }

    if ((sigfile = fopen(argv[2], "r")) == NULL)
    {
        perror("open sig_file");
        exit(1);
    }

    size_t n = 0;
    size_t mlen = 0;
    while (!feof(sigfile))
    {
        sig_msg = realloc(sig_msg, n + 1);
        n += fread(sig_msg + n, sizeof(uint8_t), 1, sigfile);
        if (ferror(sigfile))
        {
            break;
        }
    }
    fclose(sigfile);

    if (debug_file != NULL)
    {
        fprint_sig(debug_file, sig_msg, n);
        fprintf(debug_file, "\n");
        fclose(debug_file);
    }

    if (crypto_sign_open(sig_msg, &mlen, sig_msg, n, NULL, 0, pk) != 0)
    {
        free(sig_msg);
        fprintf(stderr, "signature+message of length %ld invalid\n", n);
        exit(1);
    }
    else

        if (fwrite(sig_msg, 1, mlen, stdout) != mlen)
    {
        perror("write message");
        free(sig_msg);
        exit(1);
    };
    fprintf(stderr, "signature for message of length %ld valid\n", mlen);
    free(sig_msg);
    return 0;
}
