#include <stdio.h>
#include "sign.h"
#include "fips202.h"
#include "packing.h"

#include "debug.h"

void fprint_bytes(FILE * f, uint8_t * buf, size_t len) {
    fprintf(f, "\"");
    for (size_t i = 0; i < len; i++) {
        fprintf(f, "%.2x", buf[i]);
    }
    fprintf(f, "\"");
}

void fprint_poly(FILE * f, poly * p) {
    fprintf(f, "[");
    for (size_t i = 0; i < N; i++) {
        fprintf(f, "%d%s", p->coeffs[i], i == N-1 ? "" : ",");
    }
    fprintf(f, "]");
}

void fprint_polyvec(FILE * f, poly * polys, size_t len) {
    fprintf(f, "[");
    for (size_t i = 0; i < len; i++) {
        fprint_poly(f, &polys[i]);
        fprintf(f, "%s", i == len-1 ? "" : ",");
    }
    fprintf(f, "]");
}

void fprint_sk(FILE * f, uint8_t sk[CRYPTO_SECRETKEYBYTES]) {
    uint8_t rho[SEEDBYTES], key[SEEDBYTES], tr[TRBYTES];
    polyvecl s1;
    polyveck t0, s2;
    unpack_sk(rho, tr, key, &t0, &s1, &s2, sk);

    fprintf(f, "{\"rho\":");
    fprint_bytes(f, rho, SEEDBYTES);
    fprintf(f, ",\"K\":");
    fprint_bytes(f, key, SEEDBYTES);
    fprintf(f, ",\"tr\":");
    fprint_bytes(f, tr, TRBYTES);
    fprintf(f, ",\"s1\":");
    fprint_polyvec(f, s1.vec, L);
    fprintf(f, ",\"s2\":");
    fprint_polyvec(f, s2.vec, K);
    fprintf(f, ",\"t0\":");
    fprint_polyvec(f, t0.vec, K);
    fprintf(f, "}");
}

void fprint_pk(FILE * f, uint8_t pk[CRYPTO_PUBLICKEYBYTES]) {
    uint8_t rho[SEEDBYTES];
    polyveck t1;
    unpack_pk(rho, &t1, pk);

    fprintf(f, "{\"rho\":");
    fprint_bytes(f, rho, SEEDBYTES);
    fprintf(f, ",\"t1\":");
    fprint_polyvec(f, t1.vec, K);
    fprintf(f, "}");
}

void fprint_sig(FILE * f, uint8_t * sig_msg, size_t sig_msg_len) {
    uint8_t ctilde[SEEDBYTES];
    polyvecl z;
    polyveck h;
    poly c;
    unpack_sig(ctilde, &z, &h, sig_msg);
    poly_challenge(&c, ctilde);

    fprintf(f, "{\"msg\":");
    fprint_bytes(f, sig_msg+CRYPTO_BYTES, sig_msg_len - CRYPTO_BYTES);
    fprintf(f, ",\"ctilde\":");
    fprint_bytes(f, ctilde, SEEDBYTES);
    fprintf(f, ",\"c\":");
    fprint_poly(f, &c);
    fprintf(f, ",\"z\":");
    fprint_polyvec(f, z.vec, L);
    fprintf(f, ",\"h\":");
    fprint_polyvec(f, h.vec, K);
    fprintf(f, "}");
}

