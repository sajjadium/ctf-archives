#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "sign.h"
#include "debug.h"

int main(int argc, char *argv[])
{
    FILE *skfile, *out_file;
    uint8_t sk[CRYPTO_SECRETKEYBYTES];
    char *endptr;

    if (argc != 5)
    {
        fprintf(stderr,
                "%s - Generate an array of signatures for uint64_t integers counting from start.\n"
                "Output format: <%u bytes sig><%lu bytes msg: counter little endian>.\n"
                "Usage: %s <sk_file> <output_file> <number of sigs> <start>\n",
                argv[0], CRYPTO_BYTES, sizeof(uint64_t), argv[0]);
        exit(1);
    }

    if ((skfile = fopen(argv[1], "r")) == NULL)
    {
        perror("open sk_file");
        exit(1);
    }
    if (fread(sk, CRYPTO_SECRETKEYBYTES, 1, skfile) != 1)
    {
        perror("read sk_file");
        fclose(skfile);
        exit(1);
    };
    fclose(skfile);

    if ((out_file = fopen(argv[2], "w")) == NULL)
    {
        perror("open output_file");
        exit(1);
    }

    if (*argv[3] == '\0')
    {
        fprintf(stderr, "empty <number of sigs>\n");
        exit(1);
    }
    unsigned long n = strtoul(argv[3], &endptr, 0);
    if (*endptr != '\0')
    {
        fprintf(stderr, "could not parse number of sigs: %s\n", argv[3]);
        exit(1);
    }

    unsigned long start_index;
    if (*argv[4] == '\0')
    {
        start_index = 0;
    }
    else
    {

        start_index = strtoul(argv[4], &endptr, 0);
        if (*endptr != '\0')
        {
            fprintf(stderr, "could not parse start index: %s\n", argv[4]);
            exit(1);
        }
    }

    FILE *debug_file = NULL;
    char *debug = getenv("SIGGEN_DEBUG");
    if (debug != NULL)
    {
        if ((debug_file = fopen(debug, "a")) == NULL)
        {
            perror("open debug file");
            exit(1);
        }
    }

    size_t sig_msg_len;
    uint8_t msg[sizeof(uint64_t)];
    uint8_t sig_msg[CRYPTO_BYTES + sizeof(msg)];
    int prev_percentage = -1;
    for (uint64_t i = start_index; i < start_index + n; i++)
    {
        int percentage = 100 * (i - start_index) / n;
        if (percentage != prev_percentage)
        {
            printf("%d\n", percentage);
            fflush(stdout);
            prev_percentage = percentage;
        }

        *(uint64_t *)msg = i;
        int status = crypto_sign(sig_msg, &sig_msg_len, msg, sizeof(msg), NULL, 0, sk);
        if (status)
        {
            fprintf(stderr, "crypto_sign failed\n");
            fclose(out_file);
            exit(1);
        }

        if (debug_file)
        {
            fprint_sig(debug_file, sig_msg, sig_msg_len);
            fprintf(debug_file, "\n");
        }

        if (fwrite(sig_msg, sizeof(sig_msg), 1, out_file) != 1)
        {
            perror("write signature");
            fclose(out_file);
            exit(1);
        };
    }

    fclose(out_file);
    if (debug_file)
    {
        fclose(debug_file);
    }

    return 0;
}
