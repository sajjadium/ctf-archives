#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include "sign.h"
#include "debug.h"

int main(int argc, char *argv[])
{
    FILE *skfile, *pkfile;
    uint8_t sk[CRYPTO_SECRETKEYBYTES];
    uint8_t pk[CRYPTO_PUBLICKEYBYTES];

    if (argc != 3)
    {
        fprintf(stderr,
                "%s - Generate a dilithium key pair.\n"
                "Usage: %s <sk_file> <pk_file>\n",
                argv[0], argv[0]);
        exit(1);
    }

    if (crypto_sign_keypair(pk, sk))
    {
        fprintf(stderr, "crypto_sign_keypair failed\n");
        exit(1);
    }

    if ((skfile = fopen(argv[1], "w")) == NULL)
    {
        perror("open sk_file");
        exit(1);
    }
    if ((pkfile = fopen(argv[2], "w")) == NULL)
    {
        perror("open pk_file");
        exit(1);
    }

    if (fwrite(sk, CRYPTO_SECRETKEYBYTES, 1, skfile) != 1)
    {
        perror("write sk_file");
        exit(1);
    };
    fclose(skfile);
    if (fwrite(pk, CRYPTO_PUBLICKEYBYTES, 1, pkfile) != 1)
    {
        perror("write pk_file");
        exit(1);
    };
    fclose(pkfile);

    FILE *debug_file;
    char *debug = getenv("KEYGEN_DEBUG");
    if (debug != NULL)
    {
        if ((debug_file = fopen(debug, "a")) == NULL)
        {
            perror("open debug file");
            exit(1);
        }
        fprint_sk(debug_file, sk);
        fprintf(debug_file, "\n");
        fprint_pk(debug_file, pk);
        fprintf(debug_file, "\n");
        fclose(debug_file);
    }

    return 0;
}
