#include <stdio.h>
#include "sign.h"

void fprint_bytes(FILE * f, uint8_t * buf, size_t len);
void fprint_poly(FILE * f, poly * p);
void fprint_polyvec(FILE * f, poly * polys, size_t len);
void fprint_sk(FILE * f, uint8_t sk[CRYPTO_SECRETKEYBYTES]);
void fprint_sig(FILE * f, uint8_t * sig_msg, size_t sig_msg_len);
void fprint_pk(FILE * f, uint8_t pk[CRYPTO_PUBLICKEYBYTES]);
