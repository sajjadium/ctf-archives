#!/bin/bash

if printenv FLAG
then
    cat /browser-state.template.json | jq -c ".cookies[0].value=\"$FLAG\"" > ~/browser-state.json
else
    cp /browser-state.template.json ~/browser-state.json
fi

exec "$@"
