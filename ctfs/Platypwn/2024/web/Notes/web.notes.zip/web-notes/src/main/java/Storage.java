import java.util.*;

public final class Storage {
    private static Storage INSTANCE;

    private Storage() {}

    public static Storage getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Storage();
        }

        return INSTANCE;
    }

    private List<User> users = new ArrayList<>();

    public Optional<User> getUser(String username) {
        return users.stream().filter(u -> u.getUsername().equals(username)).findFirst();
    }

    public Optional<User> checkUser(String username, String password) {
        Optional<User> user = this.getUser(username);

        if (user.isPresent() && !user.get().getPassword().equals(password)) {
            return Optional.empty();
        }

        return user;
    }

    public Optional<User> tryAddUser(String username, String password) {
        if (this.getUser(username).isPresent()) {
            return Optional.empty();
        }

        User user = new User(username, password);
        this.users.add(user);
        return Optional.of(user);
    }
}
