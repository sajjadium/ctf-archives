public enum HttpMethod {
    DELETE("delete"),
    GET("get"),
    HEAD("head"),
    OPTIONS("options"),
    PATCH("patch"),
    POST("post"),
    PUT("put");

    private final String methodName;

    private HttpMethod(String methodName) {
        this.methodName = methodName.toLowerCase();
    }

    @Override
    public String toString() {
        return this.methodName;
    }

    public boolean equals(String otherMethodName) {
        return otherMethodName.toLowerCase().equals(this.methodName);
    }
}
