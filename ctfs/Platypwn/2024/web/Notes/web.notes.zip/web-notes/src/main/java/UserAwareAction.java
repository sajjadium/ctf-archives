import com.opensymphony.xwork2.ActionSupport;

public abstract class UserAwareAction extends ActionSupport {
    private User user;

    public User getUser() {
        return this.user;
    }

    public void setUser(User value) {
        this.user = value;
    }

    public boolean isLoggedIn() {
        return this.user != null;
    }
}
