public class DispatchAction extends UserAwareAction {

    public String getTarget() {
        return this.isLoggedIn() ? "dashboard" : "index";
    }
    
    public String execute() {
        return SUCCESS;
    }

}
