public class IndexAction extends UserAwareAction {

    public String execute() {
        return SUCCESS;
    }

}
