import java.util.Arrays;

import com.opensymphony.xwork2.ActionInvocation;

public class HttpMethodFilterInterceptor extends AnnotationInterceptor {

    @Override
    public String intercept(ActionInvocation invocation) throws Exception {
        AllowMethod[] annotations = this.getActionMethodAnnotations(invocation, AllowMethod.class);
        String requestMethod = invocation.getInvocationContext().getServletRequest().getMethod();

        if (annotations.length == 0) {
            if (HttpMethod.GET.equals(requestMethod)) {
                return invocation.invoke();
            }

            invocation.getInvocationContext().getServletResponse().setStatus(405);
            return "method-not-allowed";
        }

        var allowedMethods = Arrays.asList(annotations).stream().map(allowMethod -> allowMethod.value());

        if (allowedMethods.anyMatch(allowedMethod -> allowedMethod.equals(requestMethod))) {
            return invocation.invoke();
        }

        invocation.getInvocationContext().getServletResponse().setStatus(405);
        return "method-not-allowed";
    }

}
