import com.opensymphony.xwork2.ActionInvocation;

public class LoginInterceptor extends AnnotationInterceptor {

    @Override
    public String intercept(ActionInvocation invocation) throws Exception {
        LoginRequired[] annotations = this.getActionMethodAnnotations(invocation, LoginRequired.class);

        var session = invocation.getInvocationContext().getSession();
        
        if (!session.containsKey("user")) {
            if (annotations.length == 0) {
                return invocation.invoke();
            }

            invocation.getInvocationContext().getServletResponse().setStatus(403);
            return "login";
        }

        if (UserAwareAction.class.isAssignableFrom(invocation.getAction().getClass())) {
            UserAwareAction action = (UserAwareAction)invocation.getAction();
            action.setUser((User)session.get("user"));
        }

        return invocation.invoke();
    }

}
