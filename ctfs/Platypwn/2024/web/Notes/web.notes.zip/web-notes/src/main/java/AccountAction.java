import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.action.ServletRequestAware;
import org.apache.struts2.action.SessionAware;
import org.apache.struts2.interceptor.parameter.StrutsParameter;

public class AccountAction extends UserAwareAction implements SessionAware, ServletRequestAware {

    private Map<String, Object> session;
    private HttpServletRequest request;
    private String username = "";
    private String password = "";

    @StrutsParameter
    public void setUsername(String value) {
        this.username = value;
    }

    @StrutsParameter
    public void setPassword(String value) {
        this.password = value;
    }

    @Override
    public void withSession(Map<String, Object> session) {
        this.session = session;
    }

    @Override
    public void withServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    @AllowMethod(HttpMethod.GET)
    @AllowMethod(HttpMethod.POST)
    public String login() {
        if (HttpMethod.GET.equals(this.request.getMethod())) {
            if (this.isLoggedIn()) {
                return SUCCESS;
            }

            return INPUT;
        }

        Optional<User> user = Storage.getInstance().checkUser(username, password);

        if (user.isPresent()) {
            this.session.put("user", user.get());
            return SUCCESS;
        }

        this.addActionError("User does not exist or password is wrong");
        return INPUT;
    }

    @AllowMethod(HttpMethod.GET)
    @AllowMethod(HttpMethod.POST)
    public String register() {
        if (HttpMethod.GET.equals(this.request.getMethod())) {
            return INPUT;
        }

        Optional<User> user = Storage.getInstance().tryAddUser(username, password);
        if (user.isPresent()) {
            this.session.put("user", user.get());
            return SUCCESS;
        }
        
        this.addFieldError("username", "This name is already taken. Please use another name!");
        return INPUT;
    }

    @LoginRequired
    @AllowMethod(HttpMethod.POST)
    public String logout() {
        this.session.remove("user");
        return SUCCESS;
    }

}
