import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.action.ServletRequestAware;
import org.apache.struts2.interceptor.parameter.StrutsParameter;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.BrowserType.LaunchOptions;
import com.opensymphony.xwork2.ActionSupport;

public class ReportAction extends ActionSupport implements ServletRequestAware {

    private HttpServletRequest request;
    
    private String title;
    private String[] description;
    private String url;
    private byte[] screenshot;

    public String getTitle() {
        return title;
    }

    @StrutsParameter
    public void setTitle(String value) {
        this.title = value;
    }

    public String[] getDescription() {
        return this.description;
    }

    public String getJoinedDescription() {
        return String.join("\n", this.description);
    }

    @StrutsParameter
    public void setDescription(String[] value) {
        this.description = value;
    }

    public String getUrl() {
        return this.url;
    }

    @StrutsParameter
    public void setUrl(String value) {
        this.url = value;
    }

    public String getScreenshotDataUrl() {
        return Base64.getEncoder().encodeToString(this.screenshot);
    }

    public boolean getShowError() {
        return hasActionErrors();
    }

    @AllowMethod(HttpMethod.GET)
    @AllowMethod(HttpMethod.POST)
    public String execute() {
        if (HttpMethod.GET.equals(this.request.getMethod())) {
            return INPUT;
        }

        if (this.isNullOrEmpty(this.title)) {
            addFieldError("title", "Please provide a title");
        }
        if (this.isNullOrEmpty(this.getJoinedDescription())) {
            addFieldError("description", "Please provide a description");
        }
        if (this.isNullOrEmpty(this.url)) {
            addFieldError("url", "Please provide a URL");
        } else {
            try {
                URI uri = new URI(this.url);
                uri.toURL();
            } catch (IllegalArgumentException | URISyntaxException | MalformedURLException ex) {
                addFieldError("url", "Please provide a valid URL");
            }
        }

        if (hasFieldErrors()) {
            return INPUT;
        }

        try (Playwright playwright = Playwright.create()) {
            Browser browser;
            if (System.getenv("DOCKER") != null) {
                browser = playwright.chromium().launch();
            } else {
                browser = playwright.chromium().launch(new LaunchOptions().setExecutablePath(Path.of("/usr/bin/chromium")));
            }

            BrowserContext context;
            if (System.getenv("DOCKER") != null) {
                context = browser.newContext(new Browser.NewContextOptions().setStorageStatePath(Paths.get("/var/lib/jetty/browser-state.json")));
            } else {
                context = browser.newContext(new Browser.NewContextOptions().setStorageStatePath(Paths.get("browser-state.json")));
            }
            context.setDefaultTimeout(10_000);

            Page page = context.newPage();
            if (!page.navigate(this.url).ok()) {
                this.addActionError("Could not reach provided url");
                return ERROR;
            }
            this.screenshot = page.screenshot();
            page.close();
        } catch (Exception ex) {
            this.addActionError("Unknown error: " + ex.getMessage());
            return ERROR;
        }

        return SUCCESS;
    }

    @Override
    public void withServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    private boolean isNullOrEmpty(String string) {
        return string == null || string.isBlank();
    }

}
