import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class User {
    private String username;
    private String password;
    private Map<UUID, Note> notes;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.notes = new HashMap<>();
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String value) {
        this.username = value;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String value) {
        this.password = value;
    }

    public Map<UUID, Note> getNotes() {
        return this.notes;
    }

    public Optional<Note> getNote(UUID id) {
        return Optional.ofNullable(this.notes.get(id));
    }

    public Note createNote() {
        Note note = new Note();
        this.notes.put(note.getId(), note);
        return note;
    }

    public boolean deleteNote(UUID id) {
        if (!this.notes.containsKey(id)) {
            return false;
        }

        this.notes.remove(id);
        return true;
    }
}
