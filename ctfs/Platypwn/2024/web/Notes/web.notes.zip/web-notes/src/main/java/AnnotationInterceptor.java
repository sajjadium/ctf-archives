import java.lang.annotation.Annotation;
import java.lang.reflect.Method;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public abstract class AnnotationInterceptor extends AbstractInterceptor {

    protected <T extends Annotation> T[] getActionMethodAnnotations(ActionInvocation invocation, Class<T> annotationClass) throws Exception {
        Class<?> actionClass = invocation.getAction().getClass();
        String actionMethodName = invocation.getProxy().getMethod();

        Method actionMethod;
        try {
            actionMethod = actionClass.getMethod(actionMethodName);
        } catch (NoSuchMethodException e) {
            throw new Exception(
                new StringBuilder()
                    .append("Could not find method named \"")
                    .append(actionMethodName)
                    .append("\" on Action class \"")
                    .append(actionClass.getTypeName())
                    .append("\".")
                    .toString()
            );
        }

        return actionMethod.getAnnotationsByType(annotationClass);
    }

}
