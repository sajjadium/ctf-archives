import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.action.ServletRequestAware;
import org.apache.struts2.interceptor.parameter.StrutsParameter;

public class NotesAction extends UserAwareAction implements ServletRequestAware {

    private HttpServletRequest request;

    private UUID id;
    private String title;
    private String body;

    public String getId() {
        return this.id.toString();
    }

    @StrutsParameter
    public void setId(String value) {
        this.id = UUID.fromString(value);
    }

    public Map<UUID, Note> getNotes() {
        return this.getUser().getNotes();
    }

    public Note getNote() {
        return this.getUser().getNote(this.id).get();
    }

    public String getTitle() {
        return this.getNote().getTitle();
    }

    @StrutsParameter
    public void setTitle(String value) {
        this.title = value;
    }

    public String[] getBody() {
        return new String[] { this.getNote().getBody() };
    }

    @StrutsParameter
    public void setBody(String[] value) {
        this.body = String.join("\n", value);
    }

    @LoginRequired
    public String list() {
        return "list";
    }

    @LoginRequired
    public String view() {
        if (!this.getUser().getNote(this.id).isPresent()) {
            return "not-found";
        }

        return "view";
    }

    @LoginRequired
    @AllowMethod(HttpMethod.POST)
    public String create() {
        this.id = this.getUser().createNote().getId();

        return INPUT;
    }

    @LoginRequired
    @AllowMethod(HttpMethod.GET)
    @AllowMethod(HttpMethod.POST)
    public String edit() {
        if (!this.getUser().getNote(this.id).isPresent()) {
            return "not-found";
        }

        if (HttpMethod.GET.equals(this.request.getMethod())) {
            return INPUT;
        }

        this.getNote().setTitle(this.title);
        this.getNote().setBody(this.body);

        return "view";
    }

    @LoginRequired
    @AllowMethod(HttpMethod.POST)
    public String delete() {
        if (!this.getUser().getNote(this.id).isPresent()) {
            return "not-found";
        }

        this.getUser().deleteNote(this.id);

        return "list-redir";
    }

    @Override
    public void withServletRequest(HttpServletRequest request) {
        this.request = request;
    }
}
