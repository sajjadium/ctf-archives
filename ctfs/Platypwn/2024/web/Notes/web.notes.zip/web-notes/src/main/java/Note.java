import java.util.UUID;

public class Note {
    private UUID id;
    private String title;
    private String body;

    public Note() {
        this.id = UUID.randomUUID();
        this.title = "New Note";
        this.body = "";
    }

    public UUID getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String value) {
        this.title = value;
    }

    public String getBody() {
        return this.body;
    }

    public void setBody(String value) {
        this.body = value;
    }
}
