from util.mod import Mod
from util.ecc import EccGroup

BaseGroup = EccGroup
G = EccGroup.G
ExponentRing = Mod(EccGroup.Q)
