FLAG = 'PP{TESTFLAG}'
try:
    with open('/flags/flag.txt', 'r') as flag_file:
        FLAG = flag_file.read()
except:
    pass
