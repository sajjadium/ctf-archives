from my_own_crypto import genkey, sign, verify
from os import getenv

BITLEN = 2048
n, d, e = genkey(BITLEN)
listq = set()

max_attempts = 64

print(f"Public modulus (n): {hex(n)[2:]}")
print(f"Public exponent (e): {hex(e)[2:]}")
print(f"Max attempts: {max_attempts}")
print("-----------")

flag = getenv("FLAG", "")
if flag == "":
    print("Please enter the flag as an environment variable!")
    exit(1)

for attempt in range(max_attempts):
    msg = bytes.fromhex(input("Enter a message as hex (max 128 bytes): ")[:256])
    option = input("Enter an option (sign/verify/submit): ").strip().lower()[:6]

    if option == 'sign':
        listq.add(msg)
        signature = sign(d, n, msg)
        print(f"Signature: {signature.hex()}")

    elif option == 'verify' or option == "vf":
        sig = bytes.fromhex(
            input(f"Enter signature as hex (max {BITLEN//8} bytes): ")[:(BITLEN//8)*2])

        if verify(e, n, msg, sig):
            print(f"Verification succeeded")
        else:
            print(f"Verification failed")

    elif option == 'submit':
        sig = bytes.fromhex(
            input(f"Enter signature as hex (max {BITLEN//8} bytes): ")[:(BITLEN//8)*2])

        if msg not in listq and verify(e, n, msg, sig):
            print(flag)
        else:
            print("Message already signed or verification failed. No flag for you!")

    else:
        print("Invalid option.")

print("Out of attempts.")
