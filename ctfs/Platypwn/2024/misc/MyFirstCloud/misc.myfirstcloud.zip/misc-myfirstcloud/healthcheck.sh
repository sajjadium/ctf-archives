#!/bin/sh

wget -qO- http://127.0.0.1:5000 && nc -z 127.0.0.1 25 && pidof crond
