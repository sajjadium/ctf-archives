﻿var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

if (app.Configuration["CLOUD_ROOT"] is null) return;

if (!Directory.Exists(app.Configuration["CLOUD_ROOT"]))
{
    Directory.CreateDirectory(app.Configuration["CLOUD_ROOT"]!);
}

app.Run();
