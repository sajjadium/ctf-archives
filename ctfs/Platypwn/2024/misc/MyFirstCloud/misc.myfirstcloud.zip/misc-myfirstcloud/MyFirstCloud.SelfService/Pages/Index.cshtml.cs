using System.ComponentModel.DataAnnotations;
using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFirstCloud.SelfService.Pages;

public class IndexModel : PageModel
{
    private static readonly char[] PASSWORD_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".ToCharArray();
    private readonly ILogger<IndexModel> _logger;
    private readonly IConfiguration _configuration;

    [BindProperty, Required, MinLength(3), MaxLength(255), RegularExpression("^[^\x00/]+$")]
    public string? CloudName { get; set; }

    public IndexModel(ILogger<IndexModel> logger, IConfiguration configuration)
    {
        _logger = logger;
        _configuration = configuration;
    }

    public void OnGet() {}

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        (string? cloudPath, bool success) = Helpers.GetSafeCloudPath(_configuration, CloudName);

        if (!success)
        {
            ModelState.AddModelError("CloudName", "Invalid name. Please choose another name!");
            return Page();
        }

        if (cloudPath is null)
        {
            // WTF, this should not happen
            return Page();
        }

        if (Directory.Exists(cloudPath))
        {
            ModelState.AddModelError("CloudName", "This name is already in use. Please choose another name!");
            return Page();
        }

        string password = new(Random.Shared.GetItems(PASSWORD_CHARS, 12));
        string metaPath = Path.Join(cloudPath, "meta");
        string filesPath = Path.Join(cloudPath, "files");

        try
        {
            Directory.CreateDirectory(cloudPath);
            Directory.CreateDirectory(metaPath);
            Directory.CreateDirectory(filesPath);

            System.IO.File.WriteAllText(Path.Join(metaPath, "password"), password);
            // System.IO.File.WriteAllText(Path.Join(metaPath, "lifetime"), DateTimeOffset.Now.AddMinutes(1).ToUnixTimeSeconds().ToString());
            System.IO.File.WriteAllText(Path.Join(metaPath, "lifetime"), DateTimeOffset.Now.AddHours(1).ToUnixTimeSeconds().ToString());
        }
        catch
        {
            ModelState.AddModelError("CloudName", "Could not create your cloud. Please try again!");
            return Page();
        }

        return RedirectToPage("/Success", new { CloudName, CloudPassword=password });
    }
}
