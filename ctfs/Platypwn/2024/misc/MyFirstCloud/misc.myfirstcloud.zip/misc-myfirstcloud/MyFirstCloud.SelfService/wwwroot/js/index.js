const placeholders = [
    "Alice's Photos",
    "Bob's Documents",
    "Charlie's Videos",
    "Eve's Music"
];

document.addEventListener("DOMContentLoaded", async () => {
    const textBox = document.getElementById("create_name");

    while (true) {
        for (placeholder of placeholders) {
            await showAndHidePlaceholder(placeholder);
        }
    }

    function showAndHidePlaceholder(placeholder) {
        return new Promise((resolve, reject) => {
            textBox.placeholder = "";

            let charIndex = 0;

            const writeInterval = setInterval(writePlaceholder, 150);
            let deleteInterval;

            function writePlaceholder() {
                if (charIndex > placeholder.length) {
                    clearInterval(writeInterval);
                    deleteInterval = setInterval(deletePlaceholder, 50);
                    return;
                }

                textBox.placeholder = placeholder.substring(0, charIndex + 1);
                charIndex++;
            }

            function deletePlaceholder() {
                if (charIndex === 0) {
                    clearInterval(deleteInterval);
                    resolve();
                    return;
                }

                textBox.placeholder = placeholder.substring(0, charIndex - 1);
                charIndex--;
            }
        });
    }
});
