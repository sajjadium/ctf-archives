namespace MyFirstCloud.SelfService;

public static class Helpers
{
    public static (string?, bool) GetSafeCloudPath(IConfiguration configuration, string? cloudName)
    {
        string rootDirectory = Path.GetFullPath(configuration["CLOUD_ROOT"]!);
        if (!rootDirectory.EndsWith(Path.DirectorySeparatorChar))
        {
            rootDirectory += Path.DirectorySeparatorChar;
        }

        string cloudPath = Path.GetFullPath(Path.Join(rootDirectory, cloudName));

        if (!cloudPath.StartsWith(rootDirectory))
        {
            return (null, false);
        }

        return (cloudPath, true);
    }
}
