using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyFirstCloud.SelfService.Pages;

public class SuccessModel : PageModel
{
    private readonly IConfiguration _configuration;

    public SuccessModel(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    [BindProperty]
    public string? CloudName { get; set; }
    public string? CloudPassword { get; set; }
    public bool CloudExists { get; set; } = true;

    public void OnGet(string? CloudName, string? CloudPassword)
    {
        this.CloudName = CloudName;
        this.CloudPassword = CloudPassword;

        string rootDirectory = _configuration["CLOUD_ROOT"]!;
        string cloudPath = Path.Join(rootDirectory, CloudName);
        if (!Directory.Exists(cloudPath))
        {
            CloudExists = false;
        }
    }

    public IActionResult OnPost()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        (string? cloudPath, bool success) = Helpers.GetSafeCloudPath(_configuration, CloudName);

        if (!success)
        {
            ModelState.AddModelError("CloudName", "Invalid name");
            return Page();
        }

        if (cloudPath is null)
        {
            // WTF, this should not happen
            return Page();
        }

        Directory.Delete(cloudPath, true);

        return RedirectToPage("/Index");
    }
}
