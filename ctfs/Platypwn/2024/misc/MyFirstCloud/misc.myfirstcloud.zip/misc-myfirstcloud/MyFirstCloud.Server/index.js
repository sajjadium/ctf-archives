const fs = require("fs");
const path = require("path");
const FtpSrv = require("ftp-srv");

const IS_DEVELOPMENT = process.env.NODE_ENV === "development";
const CLOUD_ROOT = IS_DEVELOPMENT ? "/tmp/storage/" : "/storage/";

if (!fs.existsSync(CLOUD_ROOT)) {
  fs.mkdirSync(CLOUD_ROOT);
}

const ftpServer = new FtpSrv({
  url: "ftp://0.0.0.0:" + (IS_DEVELOPMENT ? 2525 : 25),
  anonymous: false,
  pasv_min: 2526,
  pasv_max: 2526,
  blacklist: ["EPRT", "LPRT", "PORT"],
  greeting:
    "Welcome to your cloud at MyFirstCloud!\nPLEASE NOTE: You have to use passive mode and there is no support for big address records (RFC 1639)!",
});

ftpServer.on("login", (data, resolve, reject) => {
  try {
    if (/[\x00/]/.test(data.username)) {
      return reject(
        new ftpErrors.GeneralError("Invalid username or password", 430)
      );
    }

    const cloudPath = path.resolve(path.join(CLOUD_ROOT, data.username));

    if (!cloudPath.startsWith(CLOUD_ROOT)) {
      return reject(
        new ftpErrors.GeneralError("Invalid username or password", 430)
      );
    }

    if (!fs.existsSync(cloudPath)) {
      return reject(
        new ftpErrors.GeneralError("Invalid username or password", 430)
      );
    }

    const password = fs.readFileSync(
      path.join(cloudPath, "meta", "password"),
      "utf-8"
    );

    if (data.password !== password) {
      return reject(
        new ftpErrors.GeneralError("Invalid username or password", 430)
      );
    }

    return resolve({ root: path.join(cloudPath, "files") });
  } catch {
    reject("Unexpected error", 400);
  }
});

ftpServer.listen().then(() => {
  console.log("Ftp server is starting...");
});
