#!/bin/bash

if ! printenv CLOUD_ROOT
then
    CLOUD_ROOT=/tmp/storage
fi

now=`date +%s`

for file in "$CLOUD_ROOT"/*
do
    if [ -f $file/meta/lifetime ]
    then
        lifetime=`cat "$file/meta/lifetime"`

        if [ "$now" -gt "$lifetime" ]
        then
            rm -r "$file"
        fi
    fi
done
