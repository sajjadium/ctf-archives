import struct

MASK = 0xFFFFFFFF
STD_IV = (0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476)
K = (0x00000000, 0x5A827999, 0x6ED9EBA1)
SHIFTS = ((3, 7, 11, 19), (3, 5, 9, 13), (3, 9, 11, 15))
ORDER = (
    tuple(range(16)),
    (0, 4, 8, 12, 1, 5, 9, 13, 2, 6, 10, 14, 3, 7, 11, 15),
    (0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15),
)


def rotl(x, s):
    x &= MASK
    return ((x << s) | (x >> (32 - s))) & MASK


def rotr(x, s):
    x &= MASK
    return ((x >> s) | (x << (32 - s))) & MASK


def F(x, y, z):
    return ((x & y) | (~x & z)) & MASK


def G(x, y, z):
    return (x & y) | (x & z) | (y & z)


def H(x, y, z):
    return x ^ y ^ z


ROUND_FUNCS = (F, G, H)


def schedule(iterations=2):
    """List of (round, message word index, shift) for every step."""
    return [(r, ORDER[r][i], SHIFTS[r][i % 4])
            for r in range(3) for i in range(4 * iterations)]


def words(block):
    assert len(block) == 64
    return list(struct.unpack("<16I", block))


def block_from_words(x):
    return struct.pack("<16I", *(w & MASK for w in x))


def permute(iv, block, iterations=2):
    """Step function only (no feed-forward): returns the final (a, b, c, d)."""
    x = words(block)
    a, b, c, d = iv
    for idx, (r, k, s) in enumerate(schedule(iterations)):
        f, t = ROUND_FUNCS[r], idx % 4
        if t == 0:
            a = rotl(a + f(b, c, d) + x[k] + K[r], s)
        elif t == 1:
            d = rotl(d + f(a, b, c) + x[k] + K[r], s)
        elif t == 2:
            c = rotl(c + f(d, a, b) + x[k] + K[r], s)
        else:
            b = rotl(b + f(c, d, a) + x[k] + K[r], s)
    return a, b, c, d


def compress(iv, block, iterations=2):
    """Davies-Meyer compression: IV + permute(IV, block), as 4 words."""
    return tuple((v + w) & MASK for v, w in zip(iv, permute(iv, block, iterations)))


def digest_bytes(state):
    return struct.pack("<4I", *state)


def digest_words(digest):
    return struct.unpack("<4I", digest)


def pad(msg):
    bitlen = (8 * len(msg)) & 0xFFFFFFFFFFFFFFFF
    msg = msg + b"\x80" + b"\x00" * ((55 - len(msg)) % 64)
    return msg + struct.pack("<Q", bitlen)


def md4(msg, iv=STD_IV, iterations=4):
    state = tuple(iv)
    data = pad(msg)
    for i in range(0, len(data), 64):
        state = compress(state, data[i:i + 64], iterations)
    return digest_bytes(state)


if __name__ == "__main__":
    # RFC 1320 test vectors for the base (iterations=4) function
    vectors = {
        b"": "31d6cfe0d16ae931b73c59d7e0c089c0",
        b"abc": "a448017aaf21d8525fc10ae87aa6729d",
        b"message digest": "d9130a8164549fe818874806e1c7014b",
        b"1234567890" * 8: "e33b4ddc9c38f2199c3e7b164fcc0536",
    }
    for m, want in vectors.items():
        assert md4(m).hex() == want, m
    print("RFC 1320 vectors OK")