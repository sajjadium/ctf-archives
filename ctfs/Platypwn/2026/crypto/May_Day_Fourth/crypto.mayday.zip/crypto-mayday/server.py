import os
import random
from os import getenv
from mdfour import md4

flag = getenv("FLAG", "")

if flag == "":
    print("Please set the flag using environment variables!")
    exit(1)

ITER = 2
TRUNCATE_BYTES = int(getenv("TRUNCATE_BYTES", "1"))
VERIFY_QUERY_LIMIT = int(getenv("VERIFY_QUERY_LIMIT", "32000"))

if not 0 <= TRUNCATE_BYTES < 16:
    raise ValueError("TRUNCATE_BYTES must be between 0 and 15")

def observe(key):
    alphabet = bytes(char for char in range(32, 127) if char != ord("!"))
    message = bytes(random.choice(alphabet) for _ in range(30)) + b"."
    payload = key[8:32] + message
    iv = tuple(int.from_bytes(key[i:i + 4], "little")
               for i in range(0, 16, 4))
    tag = md4(payload, iv=iv, iterations=ITER)[TRUNCATE_BYTES:]
    print((payload + tag).hex())


def send(key, msg, tag):
    if len(msg) < 25 or len(msg) > 80 or not msg.endswith(b".") or msg[:24] != key[8:32]:
        print("Authentication failed.")
        return

    iv = tuple(int.from_bytes(key[i:i + 4], "little")
               for i in range(0, 16, 4))
    expected = md4(msg, iv=iv, iterations=ITER)[TRUNCATE_BYTES:]
    if expected != tag:
        print("Authentication failed.")
        return

    if msg[24:].startswith(b"give me a flag!"):
        print(flag)
    else:
        print("Command accepted.")



def main():
    print("Welcome to the emergency debugging utility! You may collect diagonstic data, or issue your own commands.")

    key = os.urandom(32)
    observe_queries = 0
    send_queries = 0

    while True:
        print("\n1) Observe a command")
        print("2) Send a command")
        print("3) Exit")

        choice = input("> ")

        if choice == "1":
            if observe_queries >= 32:
                print("Observe query limit reached.")
                continue
            observe_queries += 1
            observe(key)
        elif choice == "2":
            if send_queries >= VERIFY_QUERY_LIMIT:
                print("Send query limit reached.")
                continue
            send_queries += 1
            encoded = input("Command (hex): ")
            try:
                data = bytes.fromhex(encoded)
            except ValueError:
                print("Invalid hex.")
                continue

            tag_length = 16 - TRUNCATE_BYTES
            if len(data) < 25 + tag_length or len(data) > 80 + tag_length:
                print("Invalid command length.")
                continue

            send(key, data[:-tag_length], data[-tag_length:])

        elif choice == "3":
            break
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()
