import sqlite3

from flask import g

DATABASE = 'pwmanager.db'


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db


def ensure_schema():
    get_db().cursor().executescript('''
    CREATE TABLE IF NOT EXISTS users (
        name            TEXT PRIMARY KEY,
        main_password   TEXT
    );
    CREATE TABLE IF NOT EXISTS password_entries (
        id              INTEGER PRIMARY KEY,
        user_name       TEXT REFERENCES users (name) ON DELETE CASCADE,
        name            TEXT,
        value           TEXT
    );
    ''')


def register_user(name, password):
    cur = get_db().cursor()
    cur.execute("INSERT INTO users (name, main_password) VALUES (?, ?)", (str(name), str(password)))
    return name


def reset_password(name, password):
    cur = get_db().cursor()
    cur.execute("UPDATE users SET main_password = ? WHERE name = ?", (str(password), str(name)))


def login(name, password):
    cur = get_db().cursor()
    db_name = cur.execute("SELECT name FROM users WHERE name = ? AND main_password = ?", (str(name), str(password))).fetchone()
    return db_name


def create_entry(user_name, name, value):
    cur = get_db().cursor()
    cur.execute("INSERT INTO password_entries (user_name, name, value) VALUES (?, ?, ?)", (str(user_name), str(name), str(value)))


def get_entries(user_name):
    cur = get_db().cursor()
    entries = cur.execute("SELECT name, value FROM password_entries WHERE user_name = ?", (str(user_name),)).fetchall()
    return entries
