import os
from subprocess import check_output, check_call
import requests
import secrets
INSPIRE_PATH = 'inspire'
PASSPHRASE_LENGTH = int(os.environ.get('PASSPHRASE_LENGTH', 6))
WORDLISTS_BASE = os.environ.get("WORDLIST_BASE_URL", 'http://localhost:8080')
DEFAULT_WORDLIST = f'{WORDLISTS_BASE}/eff_short_wordlist_1.txt'

DICE = [1, 2, 3, 4, 5, 6]
DICE_COUNT = 4
# tuple of DICE_COUNT elements of DICE
type DiceRolls = tuple[int, int, int, int]
CLIENT_ADMIN = 'admin'
CLIENT_USERS = 'users'


def generate_client(client_name: str):
    check_call([INSPIRE_PATH, 'generate', f'./{client_name}.client.bin', '2048', *(["6"]*DICE_COUNT)])


def look_up_word(client_name: str, rolls: DiceRolls, wordlist: str):
    query = check_output([INSPIRE_PATH, 'query', f'./{client_name}.client.bin', '/dev/stdout', *[str(roll-1) for roll in rolls]])
    with requests.post(wordlist, query, headers={"Content-Type": "X-Application-Private-Information-Retrieval-Request"}) as r:
        if r.status_code != 200:
            raise Exception(f"lookup server returned code {r.status_code}")
        if r.headers["Content-Type"] != "X-Application-Private-Information-Retrieval-Response":
            raise Exception(f"lookup server returned non-PIR response")
        response = r.content
    answer = check_output([INSPIRE_PATH, 'extract', f'./{client_name}.client.bin', '/dev/stdin', '/dev/stdout'], input=response)
    return answer


def generate_password(client_name: str, wordlist: str):
    words = [look_up_word(client_name, [secrets.choice(DICE) for _ in range(DICE_COUNT)], wordlist).decode()
             for _ in range(PASSPHRASE_LENGTH)]
    return ' '.join(words)
