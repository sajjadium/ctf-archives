from datetime import datetime
import os
import secrets
import sqlite3
from flask import Flask, flash, redirect, render_template, g, request, session, url_for

import db
from diceware import CLIENT_ADMIN, CLIENT_USERS, DEFAULT_WORDLIST, WORDLISTS_BASE, generate_client, generate_password

app = Flask(__name__)


@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.commit()
        db.close()


def setup_challenge():
    # Start with fresh database
    with app.app_context():
        FLAG_DIR = os.environ.get('FLAG_DIR', 'flags')

        def getflag(name):
            with open(f'{FLAG_DIR}/{name}.txt') as f:
                return f.read()
        warmup_flag = getflag('warmup')
        user_flag = getflag('user')
        global ADMIN_FLAG
        ADMIN_FLAG = getflag('admin')

        try:
            os.unlink(db.DATABASE)
        except FileNotFoundError:
            pass
        generate_client(CLIENT_ADMIN)
        generate_client(CLIENT_USERS)

        print("Generating Admin Key")
        app_key = generate_password(CLIENT_ADMIN, DEFAULT_WORDLIST)
        app.config['SECRET_KEY'] = app_key

        print("Generating User Key")
        user_pw = generate_password(CLIENT_USERS, DEFAULT_WORDLIST)

        db.ensure_schema()
        db.register_user("FlagUser", user_pw)
        db.create_entry("FlagUser", "user flag", user_flag)

        db.register_user("Warmup User", secrets.token_hex(16))
        db.create_entry("Warmup User", "warmup flag", warmup_flag)


@app.get('/flag')
def flag():
    if session.get("is_admin") == True:
        return ADMIN_FLAG, 200
    return '', 403


@app.get('/')
def index():
    user_name = session.get('user_name')
    if user_name is None:
        return render_template('login.html')
    entries = db.get_entries(user_name)
    return render_template('entries.html', name=user_name, entries=entries, wordlists_base_url=WORDLISTS_BASE)


@app.post('/register')
def register():
    try:
        user = db.register_user(request.form['username'], request.form['password'])
        session['user_name'] = user
    except sqlite3.IntegrityError:
        flash("User already exists")
    return redirect(url_for('index'))


@app.post('/login')
def login():
    try:
        user = db.login(request.form['username'], request.form['password'])
        if user is None:
            flash("Wrong user name or password")
        else:
            session['user_name'] = user[0]
    except sqlite3.IntegrityError:
        flash("User already exists")
    return redirect(url_for('index'))


@app.post('/logout')
def logout():
    del session['user_name']
    return redirect(url_for('index'))


@app.post('/reset_password')
def reset_password():
    user_name = request.form.get('username')
    if (not user_name) or (str(user_name) == "FlagUser"):
        return '', 403

    new_password = generate_password(CLIENT_USERS, str(request.form.get('wordlist', DEFAULT_WORDLIST)))
    now = datetime.now().isoformat(' ', 'seconds')

    entry_name = f'New main password from {now}'
    db.create_entry(user_name, entry_name, new_password)
    db.reset_password(user_name, new_password)
    flash(f"Pasword reset. You can find it in your passwords as '{entry_name}'")

    return redirect(url_for('index'))


@app.post('/_app_key')
def _WIP_app_key():
    generate_password(CLIENT_ADMIN, str(request.form.get('wordlist', DEFAULT_WORDLIST)))
    # Change app password on the go or something...
    raise NotImplementedError("changing the app key not implemented")


setup_challenge()
