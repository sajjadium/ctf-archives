use std::fs;

use clap::{Parser, Subcommand};
use inspire::pir::{Client, Database, Query, Response};

trait Runnable {
    fn run(self) -> Result<(), Box<dyn std::error::Error>>;
}

fn load_client(path: std::path::PathBuf) -> Result<Client, Box<dyn std::error::Error>> {
    Ok(postcard::from_bytes::<Client>(&fs::read(path)?)?)
}

fn store_client(
    client: &Client,
    path: std::path::PathBuf,
) -> Result<(), Box<dyn std::error::Error>> {
    let store_bytes = postcard::to_allocvec(client)?;
    fs::write(path, store_bytes)?;
    Ok(())
}

#[derive(Parser)]
struct GenerateClient {
    client_file: std::path::PathBuf,
    key_size: usize,
    db_shape: Vec<usize>,
}

impl Runnable for GenerateClient {
    fn run(self) -> Result<(), Box<dyn std::error::Error>> {
        let client = Client::new(self.db_shape, self.key_size)?;
        store_client(&client, self.client_file)?;
        Ok(())
    }
}

#[derive(Parser)]
struct GenerateQuery {
    client_file: std::path::PathBuf,
    query_file: std::path::PathBuf,
    coordinates: Vec<usize>,
}

impl Runnable for GenerateQuery {
    fn run(self) -> Result<(), Box<dyn std::error::Error>> {
        let client = load_client(self.client_file)?;
        let query = client.query(self.coordinates)?;
        fs::write(self.query_file, postcard::to_allocvec(&query)?)?;
        Ok(())
    }
}

#[derive(Parser)]
struct ProcessQuery {
    query_file: std::path::PathBuf,
    db_file: std::path::PathBuf,
    response_file: std::path::PathBuf,
}

impl Runnable for ProcessQuery {
    fn run(self) -> Result<(), Box<dyn std::error::Error>> {
        let entries = fs::read_to_string(&self.db_file)?
            .lines()
            .into_iter()
            .map(|l| l.as_bytes().into())
            .collect();
        let db = Database::new(entries);
        let query_bytes = fs::read(&self.query_file)?;
        let query: Query = postcard::from_bytes(&query_bytes)?;

        let response = db.process_fast(query);

        let response_bytes = postcard::to_allocvec(&response)?;
        fs::write(self.response_file, response_bytes)?;
        Ok(())
    }
}

#[derive(Parser)]
struct ExtractResponse {
    client_file: std::path::PathBuf,
    response_file: std::path::PathBuf,
    result_file: std::path::PathBuf,
}

impl Runnable for ExtractResponse {
    fn run(self) -> Result<(), Box<dyn std::error::Error>> {
        let client = load_client(self.client_file)?;
        let response_bytes = fs::read(self.response_file)?;
        let response: Response = postcard::from_bytes(&response_bytes)?;
        match response {
            Response::Err(e) => {
                return Err(Box::new(e));
            }
            Response::Ok(response_vec) => {
                let result: Vec<Vec<u8>> = client
                    .decode(&response_vec)?
                    .into_iter()
                    .map(Into::into)
                    .collect();
                let mut result_str = String::new();
                for chunk in result {
                    result_str.push_str(str::from_utf8(&chunk)?);
                }
                fs::write(self.result_file, result_str)?;
            }
        }
        Ok(())
    }
}

#[derive(Parser)]
struct Inspire {
    #[command(subcommand)]
    commands: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Generate(GenerateClient),
    Query(GenerateQuery),
    Process(ProcessQuery),
    Extract(ExtractResponse),
}

impl Commands {
    fn run(self) -> Result<(), Box<dyn std::error::Error>> {
        match self {
            Commands::Generate(generate) => generate.run(),
            Commands::Query(query) => query.run(),
            Commands::Process(process) => process.run(),
            Commands::Extract(extract) => extract.run(),
        }
    }
}

pub fn main() -> Result<(), Box<dyn std::error::Error>> {
    Inspire::parse().commands.run()
}
