//! Simple implementation of the Pallier cryptosystem
//! https://link.springer.com/content/pdf/10.1007/3-540-48910-X_16.pdf
//!
//! We use g = n+1
//! which implies g^x = 1+nx (mod n^2)
//! and L(g^λ mod n^2) = λ

use std::ops::{Add, Mul};

use num_bigint::{BigRng010 as _, BigUint};
use rand::{
    rngs::{ChaCha20Rng, SysRng},
    SeedableRng, TryRng,
};
use rsa::{
    self,
    rand_core::OsRng,
    traits::{PrivateKeyParts, PublicKeyParts},
    RsaPrivateKey,
};
use serde::{de::Error as _, Deserialize, Serialize};

/// Public key for plaintext space mod n and implicit g=n+1.
#[derive(Debug, Clone)]
pub struct PublicKey {
    n: BigUint,
    /// Precomputed n^2
    n2: BigUint,
}

impl Serialize for PublicKey {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        self.n.serialize(serializer)
    }
}

impl<'de> Deserialize<'de> for PublicKey {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        Self::new(BigUint::deserialize(deserializer)?).map_err(D::Error::custom)
    }
}

impl PartialEq for PublicKey {
    fn eq(&self, other: &Self) -> bool {
        self.n == other.n
    }
}

#[derive(thiserror::Error, Debug)]
pub enum Error {
    #[error("key generation failed")]
    KeyGeneration(#[from] rsa::Error),
    #[error("encryption failed")]
    Encryption(<SysRng as TryRng>::Error),
    #[error("ciphertext is malformed")]
    Decryption,
    #[error("the public key is malformed")]
    PublicKey,
    #[error("ciphertext key mismatch")]
    KeyMismatch,
}

impl PublicKey {
    pub fn new(n: BigUint) -> Result<Self, Error> {
        if n <= BigUint::ONE {
            Err(Error::PublicKey)
        } else {
            Ok(Self {
                n: n.clone(),
                n2: n.clone() * &n,
            })
        }
    }

    pub fn n(&self) -> &BigUint {
        &self.n
    }

    pub fn n2(&self) -> &BigUint {
        &self.n2
    }

    pub fn op<'k>(&'k self, ct: Ciphertext) -> CiphertextOp<'k> {
        CiphertextOp {
            pk: self,
            inner: ct,
        }
    }

    pub fn encrypt<'k>(&'k self, pt: &Plaintext) -> Result<CiphertextOp<'k>, Error> {
        // r in [1, n-1]. Decryption will fail if r is multiple of p or q, which is negligible.
        let mut rng =
            ChaCha20Rng::try_from_rng(&mut SysRng).map_err(|err| Error::Encryption(err))?;
        let r = rng.random_biguint_below(&(&self.n - BigUint::ONE)) + BigUint::ONE;
        Ok(CiphertextOp {
            pk: self,
            inner: Ciphertext {
                // g^m * r^n mod n^2, where g = n+1
                inner: (((&self.n * &pt.inner) + BigUint::ONE) * r.modpow(&self.n, &self.n2))
                    % &self.n2,
            },
        })
    }

    /// Retuns a valid ciphertext encrypting a zero, without any randomness.
    pub fn insecure_zero<'k>(&'k self) -> CiphertextOp<'k> {
        CiphertextOp {
            pk: self,
            inner: Ciphertext {
                inner: BigUint::ONE,
            },
        }
    }

    /// Undo [`CiphertextOp::decompose`]
    pub fn compose<'k>(&'k self, pts: &[Plaintext; 2]) -> CiphertextOp<'k> {
        let [pt_0, pt_1] = pts;
        CiphertextOp {
            pk: self,
            inner: Ciphertext {
                inner: &pt_0.inner + &pt_1.inner * &self.n,
            },
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct PrivateKey {
    n: BigUint,
    phi: BigUint,
    phi_inv: BigUint,
    public: PublicKey,
}

impl PrivateKey {
    pub fn public(&self) -> &PublicKey {
        &self.public
    }

    pub fn new(bits: usize) -> Result<Self, Error> {
        let priv_key = RsaPrivateKey::new(&mut OsRng, bits)?;
        let n = BigUint::from_bytes_le(&priv_key.n().to_bytes_le());
        let phi = priv_key
            .primes()
            .into_iter()
            .map(|p| BigUint::from_bytes_le(&p.to_bytes_le()))
            .fold(BigUint::ONE, |phi_, p| phi_ * (p - BigUint::ONE));
        let phi_inv = phi
            .modinv(&n)
            .ok_or(Error::KeyGeneration(rsa::Error::Internal))?;
        let public = PublicKey {
            n: n.clone(),
            n2: &n * &n,
        };
        Ok(Self {
            n,
            phi,
            phi_inv,
            public,
        })
    }

    pub fn decrypt(&self, ct: &Ciphertext) -> Result<Plaintext, Error> {
        let m_n_phi_1 = ct.inner.modpow(&self.phi, &self.public.n2);
        if (&m_n_phi_1 % &self.n) != BigUint::ONE {
            return Err(Error::Decryption);
        }
        let m_phi = (m_n_phi_1 - BigUint::ONE) / &self.n;
        let m = (m_phi * &self.phi_inv) % &self.n;
        Ok(Plaintext { inner: m })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Plaintext {
    pub(crate) inner: BigUint,
}
impl Into<Plaintext> for BigUint {
    fn into(self) -> Plaintext {
        Plaintext { inner: self }
    }
}
impl Into<Plaintext> for &[u8] {
    fn into(self) -> Plaintext {
        Plaintext {
            inner: BigUint::from_bytes_le(self),
        }
    }
}
impl Into<BigUint> for Plaintext {
    fn into(self) -> BigUint {
        self.inner
    }
}
impl Into<Vec<u8>> for Plaintext {
    fn into(self) -> Vec<u8> {
        self.inner.to_bytes_le()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Ciphertext {
    pub(crate) inner: BigUint,
}

#[derive(Debug, Clone)]
pub struct CiphertextOp<'k> {
    pk: &'k PublicKey,
    inner: Ciphertext,
}

impl CiphertextOp<'_> {
    pub fn plain(self) -> Ciphertext {
        self.inner
    }
}
impl Into<Ciphertext> for CiphertextOp<'_> {
    fn into(self) -> Ciphertext {
        self.inner
    }
}
impl<'a> Into<&'a Ciphertext> for &'a CiphertextOp<'_> {
    fn into(self) -> &'a Ciphertext {
        &self.inner
    }
}

impl<'k> CiphertextOp<'k> {
    /// Represent the ciphertext as series of plaintexts
    pub fn decompose(&self) -> [Plaintext; 2] {
        [
            (&self.inner.inner % &self.pk.n).into(),
            (&self.inner.inner / &self.pk.n).into(),
        ]
    }
}

impl<'k, 'o> Add<&CiphertextOp<'o>> for &CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn add(self, rhs: &CiphertextOp<'o>) -> Self::Output {
        Self::Output {
            pk: self.pk,
            inner: Ciphertext {
                inner: (self.inner.inner.clone() * &rhs.inner.inner) % &self.pk.n2,
            },
        }
    }
}

impl<'k, 'o> Add<&CiphertextOp<'o>> for CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn add(self, rhs: &CiphertextOp<'o>) -> Self::Output {
        Self::Output {
            pk: self.pk,
            inner: Ciphertext {
                inner: (self.inner.inner * &rhs.inner.inner) % &self.pk.n2,
            },
        }
    }
}

impl<'k> Add<&Plaintext> for &CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn add(self, rhs: &Plaintext) -> Self::Output {
        Self::Output {
            pk: self.pk,
            // multiply with encryption where r=1
            inner: Ciphertext {
                inner: (self.inner.inner.clone() * ((&self.pk.n * &rhs.inner) + BigUint::ONE))
                    % &self.pk.n2,
            },
        }
    }
}

impl<'k> Add<&Plaintext> for CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn add(self, rhs: &Plaintext) -> Self::Output {
        Self::Output {
            pk: self.pk,
            // multiply with encryption where r=1
            inner: Ciphertext {
                inner: (self.inner.inner * ((&self.pk.n * &rhs.inner) + BigUint::ONE))
                    % &self.pk.n2,
            },
        }
    }
}

impl<'k> Mul<&Plaintext> for &CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn mul(self, rhs: &Plaintext) -> Self::Output {
        Self::Output {
            pk: self.pk,
            inner: Ciphertext {
                inner: self.inner.inner.modpow(&rhs.inner, &self.pk.n2),
            },
        }
    }
}

impl<'k> Mul<&Plaintext> for CiphertextOp<'k> {
    type Output = CiphertextOp<'k>;
    fn mul(self, rhs: &Plaintext) -> Self::Output {
        Self::Output {
            pk: self.pk,
            inner: Ciphertext {
                inner: self.inner.inner.modpow(&rhs.inner, &self.pk.n2),
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_bigint::BigUint;
    use std::str::FromStr;

    #[test]
    fn test_generate_encrypt_decrypt() {
        let sk = PrivateKey::new(2048).unwrap();
        let pk = sk.public();

        let m = "Hello, world!";
        let ct = pk.encrypt(&m.as_bytes().into()).unwrap();
        let pt = sk.decrypt(&ct.into()).unwrap();
        let m_: Vec<u8> = pt.into();

        assert_eq!(m_.as_slice(), m.as_bytes())
    }

    #[test]
    fn test_ct_add_pt() {
        let sk = PrivateKey::new(2048).unwrap();
        let pk = sk.public();

        let ct = pk
            .encrypt(&BigUint::from_str("1234").unwrap().into())
            .unwrap();
        let pt: Plaintext = BigUint::from_str("8765").unwrap().into();
        let ct = &ct + &pt;
        let m: BigUint = sk.decrypt(&ct.into()).unwrap().into();
        assert_eq!(m, BigUint::from_str("9999").unwrap())
    }

    #[test]
    fn test_ct_add_ct() {
        let sk = PrivateKey::new(2048).unwrap();
        let pk = sk.public();

        let ct_1 = pk
            .encrypt(&BigUint::from_str("1234").unwrap().into())
            .unwrap();
        let ct_2 = pk
            .encrypt(&BigUint::from_str("8765").unwrap().into())
            .unwrap();
        let ct = &ct_1 + &ct_2;
        let m: BigUint = sk.decrypt(&ct.into()).unwrap().into();
        assert_eq!(m, BigUint::from_str("9999").unwrap())
    }

    #[test]
    fn test_ct_mul_pt() {
        let sk = PrivateKey::new(2048).unwrap();
        let pk = sk.public();

        let ct = pk
            .encrypt(&BigUint::from_str("1234").unwrap().into())
            .unwrap();
        let pt: Plaintext = BigUint::from_str("8765").unwrap().into();
        let ct = &ct * &pt;
        let m: BigUint = sk.decrypt(&ct.into()).unwrap().into();
        assert_eq!(m, BigUint::from_str("10816010").unwrap())
    }
}
