use inspire::pir::{Client, Database, Response};
use num_bigint::BigUint;

fn main() {
    let db = Database::new(
        (0..7776)
            .map(|i| BigUint::new_const(i * 100001).into())
            .collect(),
    );
    println!("Generated DB {0:?}", std::time::SystemTime::now());
    let client = Client::new(vec![6; 5], 2048).unwrap();
    println!("Generated Client {0:?}", std::time::SystemTime::now());

    let query = client.query(vec![1, 2, 3, 4, 5]).unwrap();
    println!("Generated Query {0:?}", std::time::SystemTime::now());
    let response = db.process_fast(query);
    println!("Generated Response {0:?}", std::time::SystemTime::now());
    let response_vec = if let Response::Ok(response_vec) = response {
        response_vec
    } else {
        panic!("test query should be valid")
    };
    assert_eq!(response_vec.len(), 16);
    let r = client.decode(&response_vec).unwrap();
    println!("Decoded Response {0:?}", std::time::SystemTime::now());
    assert_eq!(r.len(), 1);
    let r: BigUint = r[0].clone().into();
    assert_eq!(r, BigUint::new_const(186501865));
}
