//! Private Information Retrieval based on Pallier
//!
//! Simplified scheme:
//!
//! The client encrypts a vector of E numbers, one of which is 1 and the others are 0 (one-hot).
//! The client sends the public key and the one-hot vector to the server.
//! The server homomorphically computes a dot product between the one-hot vector and E database entries.
//! The server sends the resulting ciphertext back.
//! The client decrypts the ciphertext. It is a weighted sum of all entries with weights from the one-hot vector.
//! Hence, it is equal to the entry at the place where the client placed the 1.
//!
//! Recursive scheme:
//!
//! The client sends multiple one-hot vectors.
//! The server computes responses for successive E-tuples of database entries using the first one-hot vector.
//!     This results in one product ciphertext per E-tuple.
//! The server computes products using the next one-hot vector, and these responses as database entries.
//!     To use product ciphertexts as database entries, their representations are decomposed into multiple plaintexts.
//!     Following steps operate on each part of a decomposed ciphertext independently.
//!     This results in one set of product ciphertexts per E² database entries.
//! This repeats until the query vectors are exhausted and only a single set of ciphertexts remains.
//!
//! The client decrypts, recomposes the ciphertexts, decrypts, recomposes, ... according to the number of recusion steps.
//!
//! Client:
//! Query (encrypted):
//!     [0, 1, 0, 0], [0, 0, 1]
//!
//! Server:
//! DB Plaintexts
//! [A, B, C, D, E, F, G, H, I, J, K, L]
//! * dot product with [0, 1, 0, 0]
//!     [ct_B, ct_F, ct_J]
//! * decomposition
//!     [[ct0_B, ct1_B], [ct0_F, ct1_F], [ct0_J, ct1_J]]
//! * dot product with [0, 0, 1]
//!     [[ct_ct0_J, ct_ct1_J]]
//! * (skip decomposition as we are done, send to client)
//!
//! Client:
//! [ct_ct0_J, ct_ct1_J]
//! * decrypt
//! [ct0_J, ct1_J]
//! * recompose
//! [ct_J]
//! * decrypt
//! [J]
//!
//! InsPIRed by recursion (Section 4) of https://doi.org/10.1109/SFCS.1997.646125

use std::{iter::zip, vec};

use num_bigint::BigUint;
use serde::{Deserialize, Serialize};

use crate::pallier::{self, Ciphertext, CiphertextOp, Plaintext, PrivateKey, PublicKey};

#[derive(Debug)]
pub struct Database {
    entries: Vec<Plaintext>,
}

#[derive(thiserror::Error, Debug)]
pub enum QueryError {
    #[error("query coordinates do not fit database size")]
    ShapeMismatch,
    #[error("error during crypto operations")]
    Pallier(#[from] pallier::Error),
}

#[derive(thiserror::Error, Debug, Clone, Serialize, Deserialize)]
pub enum ProcessError {
    #[error("query did not contain selectors")]
    EmptyQuery,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Response {
    /// Recursive ciphertexts encoding the queried row
    Ok(Vec<Ciphertext>),
    /// Query invalid for database
    Err(ProcessError),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Query {
    pk: PublicKey,
    selectors: Vec<Vec<Ciphertext>>,
}

impl Database {
    pub fn new(entries: Vec<Plaintext>) -> Self {
        Self { entries }
    }

    /// Computes ciphertexts encrypting the `i`-th row of input.
    ///
    /// * `one_hot`: a vector of `r` ciphertexts, the `i-th` of which encrypts 1, all others encrypt 0.
    /// * `entries`: a matrix of `r` rows of (up to) `c` plaintexts each, row-major. `c` is the maximum over all row's lengths
    ///     Short rows are treated like appending zeroes.
    ///
    /// Returns Vec of length `c` that decrypts to `entries[i]` (possibly with appended zeroes to reach length `c`)
    fn process_stage<'k, 'i>(
        one_hot: &'i [CiphertextOp<'k>],
        entries: &'i [&[Plaintext]],
    ) -> impl Iterator<Item = CiphertextOp<'k>> + use<'k, 'i> {
        (0 as usize..).map_while(move |column| {
            zip(one_hot, entries)
                .filter_map(|(ct, pts)| pts.get(column).map(|pt| ct * pt))
                .reduce(|acc, eml_prod| acc + &eml_prod)
        })
    }

    /// Recursively selects a row of the database
    ///
    /// To select out of ciphertexts, they are decomposed into plaintexts and rows of these plaintexts are selected.
    /// The result is a list of plaintexts.
    pub fn process(&self, query: Query) -> Response {
        let mut pts: Vec<_> = self.entries.iter().map(|e| vec![e.clone()]).collect();
        let mut cts = vec![];
        for (stage, one_hot) in query.selectors.into_iter().enumerate().rev() {
            let one_hot: Vec<_> = one_hot.into_iter().map(|ct| query.pk.op(ct)).collect();
            cts = pts
                .chunks(one_hot.len())
                .map(|rows| {
                    let rows: Vec<_> = rows.iter().map(Vec::as_slice).collect();
                    Self::process_stage(&one_hot, &rows).collect::<Vec<_>>()
                })
                .collect();
            if stage > 0 {
                pts = cts
                    .iter()
                    .map(|row| row.iter().flat_map(CiphertextOp::decompose).collect())
                    .collect();
            }
        }
        // If the query did not include enough selectors to uniquely identify a row, return the first selected one.
        if let Some(cts) = cts.into_iter().next() {
            Response::Ok(cts.into_iter().map(CiphertextOp::plain).collect())
        } else {
            Response::Err(ProcessError::EmptyQuery)
        }
    }

    /// Same as [`Self::process`] but with computational optimizations.
    pub fn process_fast(&self, query: Query) -> Response {
        use crate::num_bigint_monty::{monty_podpow_prod, MyBigUint, PreparedBase, PreparedMod};

        const WIN_SIZE: usize = 8;

        fn process_stage_fast<'k, 'i>(
            one_hot: &'i [PreparedBase<WIN_SIZE>],
            entries: &'i [&[Plaintext]],
            modulus: &'k PreparedMod,
            pk: &'k PublicKey,
        ) -> impl Iterator<Item = CiphertextOp<'k>> + use<'k, 'i> {
            (0 as usize..).map_while(move |column| {
                let entires_biguint: Vec<Option<MyBigUint>> = entries
                    .iter()
                    .map(|row| row.get(column).map(|pt| (&pt.inner).into()))
                    .collect();
                let filtered_pairs: Vec<(&PreparedBase<WIN_SIZE>, &MyBigUint)> =
                    zip(one_hot, &entires_biguint)
                        .filter_map(|(oh, pt)| pt.as_ref().map(|pt| (oh, pt)))
                        .collect();
                if filtered_pairs.is_empty() {
                    return None;
                }
                let result_raw = monty_podpow_prod(filtered_pairs.as_slice(), &modulus);
                Some(pk.op(Ciphertext { inner: result_raw }))
            })
        }

        let prepared_mod = PreparedMod::new(query.pk.n2());

        let mut pts: Vec<_> = self.entries.iter().map(|e| vec![e.clone()]).collect();
        let mut cts = vec![];
        for (stage, one_hot) in query.selectors.into_iter().enumerate().rev() {
            // Prepare query vector as ct factors, (their values are expoential bases)
            let one_hot: Vec<PreparedBase<WIN_SIZE>> = one_hot
                .into_iter()
                .map(|ct| PreparedBase::new(&ct.inner, &prepared_mod))
                .collect();

            cts = pts
                .chunks(one_hot.len())
                .map(|rows| {
                    let rows: Vec<_> = rows.iter().map(Vec::as_slice).collect();
                    process_stage_fast(&one_hot, &rows, &prepared_mod, &query.pk)
                        .collect::<Vec<_>>()
                })
                .collect();
            if stage > 0 {
                pts = cts
                    .iter()
                    .map(|row| row.iter().flat_map(CiphertextOp::decompose).collect())
                    .collect();
            }
        }
        // If the query did not include enough selectors to uniquely identify a row, return the first selected one.
        if let Some(cts) = cts.into_iter().next() {
            Response::Ok(cts.into_iter().map(CiphertextOp::plain).collect())
        } else {
            Response::Err(ProcessError::EmptyQuery)
        }
    }
}

#[derive(Debug, Serialize, Deserialize)]
pub struct Client {
    sk: PrivateKey,
    db_shape: Vec<usize>,
}

impl Client {
    pub fn new(db_shape: Vec<usize>, bits: usize) -> Result<Self, pallier::Error> {
        Ok(Self {
            sk: PrivateKey::new(bits)?,
            db_shape,
        })
    }

    pub fn query(&self, coordinates: Vec<usize>) -> Result<Query, QueryError> {
        if coordinates.len() != self.db_shape.len() {
            return Err(QueryError::ShapeMismatch);
        }

        let pk = self.sk.public();
        let mut selectors = vec![];
        for (coordinate, size) in zip(coordinates, &self.db_shape) {
            let mut selector = vec![];
            for i in 0..*size {
                selector.push(
                    pk.encrypt(
                        &(if i == coordinate {
                            BigUint::ONE
                        } else {
                            BigUint::ZERO
                        })
                        .into(),
                    )?
                    .plain(),
                );
            }
            selectors.push(selector);
        }

        Ok(Query {
            pk: pk.clone(),
            selectors,
        })
    }

    pub fn decode(&self, response_vec: &[Ciphertext]) -> Result<Vec<Plaintext>, pallier::Error> {
        let pk = self.sk.public();
        let mut pts = vec![];
        for ct in response_vec {
            pts.push(self.sk.decrypt(ct)?);
        }
        for _ in 0..self.db_shape.len() - 1 {
            let mut next_pts = vec![];
            for chunk in pts.as_chunks::<2>().0 {
                next_pts.push(self.sk.decrypt(&pk.compose(chunk).plain())?);
            }
            pts = next_pts;
        }
        Ok(pts)
    }
}

#[cfg(test)]
mod tests {
    use super::{Client, Database, Response};
    use num_bigint::BigUint;

    #[test]
    fn test_1() {
        let db = Database::new(
            (0..120)
                .map(|i| BigUint::new_const(i * 100001).into())
                .collect(),
        );
        let client = Client::new(vec![120], 2048).unwrap();

        let query = client.query(vec![5]).unwrap();
        let response = db.process_fast(query);
        let response_vec = if let Response::Ok(response_vec) = response {
            response_vec
        } else {
            panic!("test query should be valid")
        };
        assert_eq!(response_vec.len(), 1);
        let r = client.decode(&response_vec).unwrap();
        assert_eq!(r.len(), 1);
        let r: BigUint = r[0].clone().into();
        assert_eq!(r, BigUint::new_const(500005));
    }

    #[test]
    fn test_2() {
        let db = Database::new(
            (0..120)
                .map(|i| BigUint::new_const(i * 100001).into())
                .collect(),
        );
        let client = Client::new(vec![10, 12], 2048).unwrap();

        let query = client.query(vec![5, 11]).unwrap();
        let response = db.process_fast(query);
        let response_vec = if let Response::Ok(response_vec) = response {
            response_vec
        } else {
            panic!("test query should be valid")
        };
        assert_eq!(response_vec.len(), 2);
        let r = client.decode(&response_vec).unwrap();
        assert_eq!(r.len(), 1);
        let r: BigUint = r[0].clone().into();
        assert_eq!(r, BigUint::new_const(100001 * (12 * 5 + 11)));
    }

    #[test]
    fn test_5() {
        let db = Database::new(
            (0..7776)
                .map(|i| BigUint::new_const(i * 100001).into())
                .collect(),
        );
        let client = Client::new(vec![6; 5], 2048).unwrap();

        let query = client.query(vec![1, 2, 3, 4, 5]).unwrap();
        let response = db.process_fast(query);
        let response_vec = if let Response::Ok(response_vec) = response {
            response_vec
        } else {
            panic!("test query should be valid")
        };
        assert_eq!(response_vec.len(), 16);
        let r = client.decode(&response_vec).unwrap();
        assert_eq!(r.len(), 1);
        let r: BigUint = r[0].clone().into();
        assert_eq!(r, BigUint::new_const(186501865));
    }
}
