//! Customized code to speed up query processing with Pallier.
//!
//! This code is based on the private [`num_bigint::monty`] module (0.5.1)
//! https://github.com/rust-num/num-bigint/blob/41f0b035d12971c5c7f7501917e31f0f6439c26c/src/biguint/monty.rs.
//! As such, this module is licensed under the MIT license:
//!
//! > Copyright (c) 2014 The Rust Project Developers
//! > Permission is hereby granted, free of charge, to any
//! > person obtaining a copy of this software and associated
//! > documentation files (the "Software"), to deal in the
//! > Software without restriction, including without
//! > limitation the rights to use, copy, modify, merge,
//! > publish, distribute, sublicense, and/or sell copies of
//! > the Software, and to permit persons to whom the Software
//! > is furnished to do so, subject to the following
//! > conditions:
//! >
//! > The above copyright notice and this permission notice
//! > shall be included in all copies or substantial portions
//! > of the Software.
//! >
//! > THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF
//! > ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
//! > TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
//! > PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT
//! > SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
//! > CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
//! > OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
//! > IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
//! > DEALINGS IN THE SOFTWARE.
//!
//!
//! Modifications:
//!  * Precompute montgomery values (we do many modpow with same modulus)
//!  * Precompute window (we do many modpow with same modulus and base)
//!  * Dot product: For ciphertext/plaintext dot products, we amortize squaring

use core::mem;
use core::ops::Shl;
use num_bigint::BigUint as OrigBigUint;
use std::vec;

// use num_bigint::BigUint;
#[derive(Debug, Clone)]
pub struct MyBigUint {
    data: Vec<BigDigit>,
}
impl MyBigUint {
    const ZERO: Self = Self { data: Vec::new() };
    fn one() -> Self {
        Self { data: vec![1] }
    }
}

impl From<&OrigBigUint> for MyBigUint {
    fn from(value: &OrigBigUint) -> Self {
        Self {
            data: value.to_u64_digits(),
        }
    }
}
impl From<&MyBigUint> for OrigBigUint {
    fn from(value: &MyBigUint) -> Self {
        let data: Vec<_> = value
            .data
            .iter()
            .flat_map(|d| [(d & ((1 << 32) - 1)) as u32, (d >> 32) as u32])
            .collect();
        Self::from_slice(&data)
    }
}

pub type BigDigit = u64;
pub type DoubleBigDigit = u128;

struct MontyReducer {
    n0inv: BigDigit,
}

#[derive(Debug)]
pub struct PreparedMod {
    orig: OrigBigUint,
    m: MyBigUint,
    num_words: usize,
    n0inv: BigDigit,
    rr: MyBigUint,
}
impl PreparedMod {
    pub fn new(m: &OrigBigUint) -> Self {
        assert!(m.bit(0));
        let m_own: MyBigUint = m.into();
        let num_words: usize = m_own.data.len();
        let mr = MontyReducer::new(&m_own);

        // rr = 2**(2*_W*len(m)) mod m
        let mut rr_orig = OrigBigUint::ONE;
        rr_orig = (rr_orig.shl(2 * num_words as u64 * u64::from(BigDigit::BITS))) % m;
        let mut rr: MyBigUint = (&rr_orig).into();

        if rr.data.len() < num_words {
            rr.data.resize(num_words, 0);
        }

        Self {
            orig: m.clone(),
            m: m_own,
            num_words,
            n0inv: mr.n0inv,
            rr,
        }
    }
}

#[derive(Debug)]
pub struct PreparedBase<const WIN: usize> {
    powers: Vec<MyBigUint>,
}
impl<const WIN: usize> PreparedBase<WIN> {
    pub fn new(b: &OrigBigUint, m: &PreparedMod) -> Self {
        let reduced_base = b % &m.orig;
        let mut b_own: MyBigUint = (&reduced_base).into();
        if b_own.data.len() < m.num_words {
            b_own.data.resize(m.num_words, 0);
        }

        // powers[i] contains x^i
        let mut one = MyBigUint::one();
        one.data.resize(m.num_words, 0);
        let mut powers = Vec::with_capacity(1 << WIN);
        powers.push(montgomery(&one, &m.rr, &m.m, m.n0inv, m.num_words));
        powers.push(montgomery(&b_own, &m.rr, &m.m, m.n0inv, m.num_words));
        for i in 2..1 << WIN {
            let r = montgomery(&powers[i - 1], &powers[1], &m.m, m.n0inv, m.num_words);
            powers.push(r);
        }

        Self { powers: powers }
    }
}

/// Calculates x ** y mod m using a fixed, 4-bit window.
#[allow(clippy::many_single_char_names)]
pub fn monty_modpow(x: &PreparedBase<4>, y: &MyBigUint, m: &PreparedMod) -> OrigBigUint {
    let n = 4;
    let PreparedBase { powers, .. } = x;
    let PreparedMod {
        orig,
        m,
        num_words,
        n0inv,
        ..
    } = m;
    let num_words = *num_words;
    let n0inv = *n0inv;

    // initialize z = 1 (Montgomery 1)
    let mut z = powers[0].clone();
    z.data.resize(num_words, 0);
    // temporary value
    let mut zz = MyBigUint::ZERO;
    zz.data.resize(num_words, 0);

    // same windowed exponent, but with Montgomery multiplications
    let y = &*y.data;
    for i in (0..y.len()).rev() {
        let mut yi = y[i];
        let mut j = 0;
        while j < BigDigit::BITS {
            if i != y.len() - 1 || j != 0 {
                zz = montgomery(&z, &z, m, n0inv, num_words);
                z = montgomery(&zz, &zz, m, n0inv, num_words);
                zz = montgomery(&z, &z, m, n0inv, num_words);
                z = montgomery(&zz, &zz, m, n0inv, num_words);
            }
            zz = montgomery(
                &z,
                &powers[(yi >> (BigDigit::BITS - n)) as usize],
                m,
                n0inv,
                num_words,
            );
            mem::swap(&mut z, &mut zz);
            yi <<= n;
            j += n;
        }
    }

    // convert to regular number
    let mut one = MyBigUint::one();
    one.data.resize(num_words, 0);
    zz = montgomery(&z, &one, m, n0inv, num_words);
    let mut out: OrigBigUint = (&zz).into();

    // One last reduction, just in case.
    // See golang.org/issue/13907.
    if out >= *orig {
        // Common case is m has high bit set; in that case,
        // since zz is the same length as m, there can be just
        // one multiple of m to remove. Just subtract.
        // We think that the subtract should be sufficient in general,
        // so do that unconditionally, but double-check,
        // in case our beliefs are wrong.
        // The div is not expected to be reached.
        out -= orig;
        if out >= *orig {
            out %= orig;
        }
    }
    out
}

/// Returns Prod_over_i( xs[i] ^ ys[i]) mod m
/// Amortizes squaring for all i
///
/// This function is structured similarly to [`monty_modpow`]
pub fn monty_podpow_prod<const N: usize>(
    x_ys: &[(&PreparedBase<N>, &MyBigUint)],
    m: &PreparedMod,
) -> OrigBigUint {
    let PreparedMod {
        orig,
        m,
        num_words,
        n0inv,
        ..
    } = m;
    let max_exp_len = x_ys.iter().map(|(_x, y)| y.data.len()).max().unwrap_or(0);
    let num_words = *num_words;
    let n0inv = *n0inv;

    // initialize z = 1 (Montgomery 1)
    let mut z = x_ys[0].0.powers[0].clone();
    z.data.resize(num_words, 0);
    // temporary value
    let mut zz = MyBigUint::ZERO;
    zz.data.resize(num_words, 0);

    // same windowed exponent, but with Montgomery multiplications
    let windows_in_digit: u32 = BigDigit::BITS / (N as u32);
    for i in (0..max_exp_len).rev() {
        let mut shift = BigDigit::BITS - N as u32;
        for _ in 0..windows_in_digit {
            // Skip first squaring
            if !(i == max_exp_len - 1 && shift == BigDigit::BITS - N as u32) {
                // z *= 2^n
                for _ in 0..N / 2 {
                    zz = montgomery(&z, &z, m, n0inv, num_words);
                    z = montgomery(&zz, &zz, m, n0inv, num_words);
                }
            }
            for (base, MyBigUint { data }) in x_ys {
                if let Some(digit) = data.get(i) {
                    zz = montgomery(
                        &z,
                        &base.powers[((digit >> shift) & ((1 << N) - 1)) as usize],
                        m,
                        n0inv,
                        num_words,
                    );
                    mem::swap(&mut z, &mut zz);
                }
            }
            shift -= N as u32;
        }
    }

    // convert to regular number
    let mut one = MyBigUint::one();
    one.data.resize(num_words, 0);
    zz = montgomery(&z, &one, m, n0inv, num_words);
    let mut out: OrigBigUint = (&zz).into();

    // One last reduction, just in case.
    // See golang.org/issue/13907.
    if out >= *orig {
        // Common case is m has high bit set; in that case,
        // since zz is the same length as m, there can be just
        // one multiple of m to remove. Just subtract.
        // We think that the subtract should be sufficient in general,
        // so do that unconditionally, but double-check,
        // in case our beliefs are wrong.
        // The div is not expected to be reached.
        out -= orig;
        if out >= *orig {
            out %= orig;
        }
    }
    out
}

// k0 = -m**-1 mod 2**BITS. Algorithm from: Dumas, J.G. "On Newton–Raphson
// Iteration for Multiplicative Inverses Modulo Prime Powers".
fn inv_mod_alt(b: BigDigit) -> BigDigit {
    assert_ne!(b & 1, 0);

    let mut k0 = BigDigit::wrapping_sub(2, b);
    let mut t = b - 1;
    let mut i = 1;
    while i < BigDigit::BITS {
        t = t.wrapping_mul(t);
        k0 = k0.wrapping_mul(t + 1);

        i <<= 1;
    }
    debug_assert_eq!(k0.wrapping_mul(b), 1);
    k0.wrapping_neg()
}

impl MontyReducer {
    fn new(n: &MyBigUint) -> Self {
        let n0inv = inv_mod_alt(n.data[0]);
        MontyReducer { n0inv }
    }
}

/// Computes z mod m = x * y * 2 ** (-n*_W) mod m
/// assuming k = -1/m mod 2**_W
/// See Gueron, "Efficient Software Implementations of Modular Exponentiation".
/// <https://eprint.iacr.org/2011/239.pdf>
/// In the terminology of that paper, this is an "Almost Montgomery Multiplication":
/// x and y are required to satisfy 0 <= z < 2**(n*_W) and then the result
/// z is guaranteed to satisfy 0 <= z < 2**(n*_W), but it may not be < m.
#[allow(clippy::many_single_char_names)]
fn montgomery(x: &MyBigUint, y: &MyBigUint, m: &MyBigUint, k: BigDigit, n: usize) -> MyBigUint {
    // This code assumes x, y, m are all the same length, n.
    // (required by addMulVVW and the for loop).
    // It also assumes that x, y are already reduced mod m,
    // or else the result will not be properly reduced.
    assert!(
        x.data.len() == n && y.data.len() == n && m.data.len() == n,
        "{:?} {:?} {:?} {}",
        x,
        y,
        m,
        n
    );

    let (x, y, m) = (&*x.data, &*y.data, &*m.data);

    let mut z = vec![0; n * 2];

    let mut c: BigDigit = 0;
    for i in 0..n {
        let z = &mut z[i..];
        let c2 = add_mul_vvw(&mut z[..n], x, y[i]); // Full multiplication
        let t = z[0].wrapping_mul(k);
        let c3 = add_mul_vvw(&mut z[..n], m, t);
        let cx = c.wrapping_add(c2);
        let cy = cx.wrapping_add(c3);
        z[n] = cy;
        if cx < c2 || cy < c3 {
            c = 1;
        } else {
            c = 0;
        }
    }

    let data = if c == 0 {
        (&z[n..]).to_vec()
    } else {
        let (first, second) = z.split_at_mut(n);
        sub_vv(first, second, m);
        (first).to_vec()
    };
    MyBigUint { data }
}

#[inline(always)]
fn add_mul_vvw(z: &mut [BigDigit], x: &[BigDigit], y: BigDigit) -> BigDigit {
    let mut c = 0;
    for (zi, xi) in z.iter_mut().zip(x.iter()) {
        let (z1, z0) = mul_add_www(*xi, y, *zi);
        let (c_, zi_) = add_ww(z0, c, 0);
        *zi = zi_;
        c = c_ + z1;
    }

    c
}

/// The resulting carry c is either 0 or 1.
#[inline(always)]
fn sub_vv(z: &mut [BigDigit], x: &[BigDigit], y: &[BigDigit]) -> BigDigit {
    let mut c = 0;
    for (i, (xi, yi)) in x.iter().zip(y.iter()).enumerate().take(z.len()) {
        let zi = xi.wrapping_sub(*yi).wrapping_sub(c);
        z[i] = zi;
        // see "Hacker's Delight", section 2-12 (overflow detection)
        c = ((yi & !xi) | ((yi | !xi) & zi)) >> (BigDigit::BITS - 1)
    }

    c
}

/// z1<<_W + z0 = x+y+c, with c == 0 or 1
#[inline(always)]
fn add_ww(x: BigDigit, y: BigDigit, c: BigDigit) -> (BigDigit, BigDigit) {
    let yc = y.wrapping_add(c);
    let z0 = x.wrapping_add(yc);
    let z1 = if z0 < x || yc < y { 1 } else { 0 };

    (z1, z0)
}

/// z1 << _W + z0 = x * y + c
#[inline(always)]
fn mul_add_www(x: BigDigit, y: BigDigit, c: BigDigit) -> (BigDigit, BigDigit) {
    let z = x as DoubleBigDigit * y as DoubleBigDigit + c as DoubleBigDigit;
    ((z >> BigDigit::BITS) as BigDigit, z as BigDigit)
}

#[cfg(test)]
mod tests {
    use crate::num_bigint_monty::{monty_podpow_prod, MyBigUint};

    use super::{monty_modpow, PreparedBase, PreparedMod};
    use num_bigint::BigUint;
    use std::str::FromStr as _;

    #[test]
    fn test_monty_modpow_1w() {
        let m = BigUint::from_str("590805198505152053").unwrap();
        let a = BigUint::from_str("584714445844312093").unwrap();

        let m = PreparedMod::new(&m);
        let b: PreparedBase<4> = PreparedBase::new(&a, &m);

        assert_eq!(
            monty_modpow(&b, &(&BigUint::new_const(0)).into(), &m),
            BigUint::new_const(1)
        );
        assert_eq!(monty_modpow(&b, &(&BigUint::new_const(1)).into(), &m), a);
        assert_eq!(
            monty_modpow(
                &b,
                &(&BigUint::from_str("738859591702245199").unwrap()).into(),
                &m
            ),
            BigUint::from_str("480589170635983760").unwrap()
        );
    }

    #[test]
    fn test_monty_modpow_2w() {
        let m = BigUint::from_str("304620343062638118521449894188820689793").unwrap();
        let a = BigUint::from_str("141229856186294624665909614868894939363").unwrap();

        let m = PreparedMod::new(&m);
        let b: PreparedBase<4> = PreparedBase::new(&a, &m);

        assert_eq!(
            monty_modpow(&b, &(&BigUint::new_const(0)).into(), &m),
            BigUint::new_const(1)
        );
        assert_eq!(monty_modpow(&b, &(&BigUint::new_const(1)).into(), &m), a);
        assert_eq!(
            monty_modpow(
                &b,
                &(&BigUint::from_str("738859591702245199").unwrap()).into(),
                &m
            ),
            BigUint::from_str("172620527862557325661791643816823890788").unwrap()
        );
        assert_eq!(
            monty_modpow(
                &b,
                &(&BigUint::from_str("267124878743997842367089601437174998343").unwrap()).into(),
                &m
            ),
            BigUint::from_str("130872222120009013401142491713464445832").unwrap()
        );
    }
    #[test]
    fn test_monty_modpow_10w() {
        let m = BigUint::from_str("2928104158551451429784625635583555193113142376767382413532615609307786890578068821266201407186362943612434854975609543119064755320241280667822662102591000103465891183909438735400786398227539877").unwrap();
        let a = BigUint::from_str("1394624209277322765588587692032725580971171614197031944504132156188600250613358824738420160004597586669136917816977566219834950995112907133948703062518692479185725348437788984760422905541442247").unwrap();

        let m = PreparedMod::new(&m);
        let b: PreparedBase<4> = PreparedBase::new(&a, &m);

        assert_eq!(
            monty_modpow(&b, &(&BigUint::new_const(0)).into(), &m),
            BigUint::new_const(1)
        );
        assert_eq!(monty_modpow(&b, &(&BigUint::new_const(1)).into(), &m), a);
        assert_eq!(monty_modpow(&b, &(&BigUint::from_str("267124878743997842367089601437174998343").unwrap()).into(), &m), BigUint::from_str("1879677853191273905118132973963343722005800734804025578541562928674962807624710886186298484831848448720672763873376697779655304139781399225193764411044657329051824987621509916125097063949242868").unwrap());
        assert_eq!(monty_modpow(&b, &(&BigUint::from_str("1299806329851292005908732124351288757505606291513530488968858869976860869682458184184119479260658769700568461141379360655505180116553217299641381935675520984902096545178749489296380955665934583").unwrap()).into(), &m), BigUint::from_str("1606933222895938498579875984253146099922312867994607731337661868063538654388852242848735059018543196859418842167880394197838916902960310573788024367651546852933825042219073943916846651740279136").unwrap());
    }

    #[test]
    fn test_monty_modpow_2x10w() {
        let m = BigUint::from_str("2928104158551451429784625635583555193113142376767382413532615609307786890578068821266201407186362943612434854975609543119064755320241280667822662102591000103465891183909438735400786398227539877").unwrap();

        let b0 = BigUint::from_str("1394624209277322765588587692032725580971171614197031944504132156188600250613358824738420160004597586669136917816977566219834950995112907133948703062518692479185725348437788984760422905541442247").unwrap();
        let b1 = BigUint::from_str("1780889903307906250351982707058370542947776466978126442533548756781568611410899854338098765100855984129097747911674072795576216182249301374619474972365880150155979553337085164097087835437485933").unwrap();

        let e0: MyBigUint = (&BigUint::from_str("320617805556450852846876520458472664465638553201139686520905225186138449042766749773206981789512106581216047683058145347911458622784774408800694709592069140683410268702903289353208395663591379").unwrap()).into();
        let e1: MyBigUint = (&BigUint::from_str("728480817511610272151587628216848521183000527448579450588485036658318026689391181058979178230890131515251414408755911474308062691787560054181649892581977270981056494024695894450651280259139629").unwrap()).into();

        let m = PreparedMod::new(&m);
        let b0: PreparedBase<4> = PreparedBase::new(&b0, &m);
        let b1: PreparedBase<4> = PreparedBase::new(&b1, &m);

        assert_eq!(
            monty_podpow_prod(&[(&b0, &e0),], &m),
            BigUint::from_str("2043715531265273495713006736682609650551544309397215163798178894193656199337718271023707749269496207318635436635749026930241844941624402516232823290260055026676566744481599895915780108814639289").unwrap()
        );

        assert_eq!(
            monty_podpow_prod(&[(&b0, &e0), (&b1, &e1)], &m),
            BigUint::from_str("1391722168584005472159650815187195707651829719061074704346461248670949977176958122847558046310402631444836909998522916296969971848892291590634720929743927438436878965025572367051265034762605280").unwrap()
        );
    }
}
