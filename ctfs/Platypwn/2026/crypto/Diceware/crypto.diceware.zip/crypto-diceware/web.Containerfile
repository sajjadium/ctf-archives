FROM rust:slim-trixie AS builder

WORKDIR /usr/build/inspire
COPY inspire .
RUN cargo build --release --locked -p inspire

WORKDIR /usr/build/wordlists
COPY wordlist_server .
RUN cargo build --release --locked -p wordlist-server

FROM python:3.15.0-trixie

ENV PYTHONUNBUFFERED=1

COPY --from=builder \
    /usr/build/inspire/target/release/inspire \
    /usr/build/wordlists/target/release/wordlist-server \
    /usr/bin


WORKDIR /var/www
RUN chmod 775 . && chgrp www-data .
COPY web/requirements.txt . 
RUN pip3 install --no-cache-dir -r requirements.txt
COPY web/app .

USER www-data
CMD ["gunicorn", "--preload", "-b", "0.0.0.0:8081", "app:app"]
