use std::{
    fs,
    path::PathBuf,
    sync::Mutex,
    time::{Duration, SystemTime},
};

use actix_web::{
    App, HttpResponse, HttpServer, Responder, dev::ResourcePath, guard, http::Method,
    middleware::Logger, post, web,
};
use clap::Parser;
use rand::distr::{Alphanumeric, SampleString};
use tokio::process::Command;

const PIR_CONTENT_REQUEST: &str = "X-Application-Private-Information-Retrieval-Request";
const PIR_CONTENT_RESPONSE: &str = "X-Application-Private-Information-Retrieval-Response";

#[derive(Parser)]
struct Params {
    #[arg(default_value = "127.0.0.1")]
    ip: String,
    #[arg(default_value = "8080")]
    port: u16,
    #[arg(long, default_value = ".")]
    root: String,
    #[arg(long, default_value = ".tmp")]
    tmp: PathBuf,
    #[arg(long, default_value = "30")]
    rate_interval: f64,
    #[arg(long, default_value = "20")]
    rate_burst: u64,
    #[arg(long, default_value = "inspire")]
    inspire_exec_path: PathBuf,
}

#[derive(Debug, Clone)]
struct RateLimit {
    max_tokens: u64,
    token_duration: Duration,
    last_token: SystemTime,
    tokens: u64,
}

impl RateLimit {
    fn new(burst: u64, token_interval: Duration) -> Self {
        Self {
            max_tokens: burst,
            token_duration: token_interval,
            last_token: SystemTime::now(),
            tokens: burst,
        }
    }

    fn take(&mut self) -> Option<u64> {
        let now = SystemTime::now();
        if let Ok(since) = now.duration_since(self.last_token) {
            let gain = since.div_duration_f64(self.token_duration).floor();
            self.tokens += gain as u64;
            if self.tokens >= self.max_tokens {
                self.tokens = self.max_tokens;
                self.last_token = now;
            } else {
                self.last_token += self.token_duration.mul_f64(gain);
            }
        }

        self.tokens = self.tokens.checked_sub(1)?;
        Some(self.tokens)
    }
}

#[derive(Debug, Clone)]
struct PirConfig {
    root: PathBuf,
    tmp: PathBuf,
    exec_path: PathBuf,
}
struct Limiter(Mutex<RateLimit>);

#[post("{filepath}")]
async fn process(
    filepath: web::Path<String>,
    limiter: web::Data<Limiter>,
    app_state: web::Data<PirConfig>,
    body: web::Bytes,
) -> impl Responder {
    let raw_path = app_state.root.join(filepath.path());
    let Ok(db_file) = std::fs::canonicalize(raw_path) else {
        return HttpResponse::NotFound().finish();
    };
    if !db_file.starts_with(&app_state.root) || !db_file.is_file() {
        return HttpResponse::NotFound().finish();
    }
    if limiter.0.lock().unwrap().take().is_none() {
        return HttpResponse::TooManyRequests().finish();
    }
    let process_file_base = Alphanumeric.sample_string(&mut rand::rng(), 8);
    let query_file = app_state.tmp.join(format!("{process_file_base}.query"));
    let response_file = app_state.tmp.join(format!("{process_file_base}.response"));
    let Ok(()) = fs::write(&query_file, body) else {
        return HttpResponse::InternalServerError().body("failed to store query");
    };

    let Ok(mut child) = Command::new(&app_state.exec_path)
        .arg("process")
        .arg(&query_file)
        .arg(&db_file)
        .arg(&response_file)
        .spawn()
    else {
        return HttpResponse::InternalServerError().body("failed to start process");
    };
    let Ok(status) = child.wait().await else {
        return HttpResponse::InternalServerError().body("failed to waiting for process");
    };
    if !status.success() {
        return HttpResponse::InternalServerError().body("process failed");
    }
    let Ok(response_content) = fs::read(&response_file) else {
        return HttpResponse::InternalServerError().body("failed to read response");
    };

    HttpResponse::Ok()
        .append_header(("Content-Type", PIR_CONTENT_RESPONSE))
        .body(response_content)
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    let params = Params::parse();
    let limiter = web::Data::new(Limiter(Mutex::new(RateLimit::new(
        params.rate_burst,
        Duration::from_secs_f64(params.rate_interval),
    ))));
    std::fs::create_dir_all(&params.tmp).expect("create tmp dir");
    let pir_config = PirConfig {
        root: std::fs::canonicalize(&params.root).expect("root path"),
        tmp: std::fs::canonicalize(&params.tmp).expect("tmp path"),
        exec_path: params.inspire_exec_path.clone(),
    };
    env_logger::init_from_env(env_logger::Env::new().default_filter_or("info"));
    HttpServer::new(move || {
        App::new()
            .wrap(Logger::new("%t from %a %r took %T -> %s"))
            .service(
                web::scope("")
                    .guard(
                        guard::All(guard::Method(Method::POST))
                            .and(guard::Header("Content-Type", PIR_CONTENT_REQUEST)),
                    )
                    .app_data(web::Data::new(pir_config.clone()))
                    .app_data(limiter.clone())
                    .wrap(Logger::new("%t %r PIR"))
                    .service(process),
            )
            .service(
                web::scope("").wrap(Logger::new("%t %r Static")).service(
                    actix_files::Files::new("/", &params.root)
                        .redirect_to_slash_directory()
                        .show_files_listing()
                        .use_hidden_files()
                        .use_last_modified(true),
                ),
            )
    })
    .workers(2)
    .bind((params.ip, params.port))?
    .run()
    .await
}
