FROM rust:slim-trixie AS builder

WORKDIR /usr/build/inspire
COPY inspire .
RUN cargo build --release --locked -p inspire

WORKDIR /usr/build/wordlists
COPY wordlist_server .
RUN cargo build --release --locked -p wordlist-server

FROM debian:trixie

COPY --from=builder \
    /usr/build/inspire/target/release/inspire \
    /usr/build/wordlists/target/release/wordlist-server \
    /usr/bin

RUN mkdir /var/www
WORKDIR /var/www
RUN \
    chmod -R 555 . \
    && mkdir tmp \
    && chmod -R 700 tmp \
    && chown www-data tmp
USER www-data

COPY data/* .

CMD ["wordlist-server", "0.0.0.0", "8080", "--root", ".", "--tmp", "tmp", "--rate-interval", "60", "--rate-burst", "20"]
