# CTF "Glass Vault" client kit: the toolchain for building the Veloren v0.18.0
# client. The image holds only the tools; your Veloren clone is mounted into
# it by ctf.sh, which also does the building. See ctf.sh.

# Ubuntu 22.04 (glibc 2.35), so the client you build runs on practically every
# current Linux. Pinned 2026-10-06.
FROM ubuntu:22.04@sha256:5ec03bb3441e8b0bf3b4f9cd4629a1ae763010dc3035bb8da3ae6cf026486401

ARG RUSTUP_VERSION=1.29.1
ARG RUSTUP_SHA256=dda7234360b7f578ca8b0ddcb80145646fa61a67c1720a5abc7051b35c9fcb71
# Must match v0.18.0's `rust-toolchain`; ctf.sh checks it.
ARG RUST_TOOLCHAIN=nightly-2025-09-08

# Build packages for the client: ALSA and udev headers, shaderc's C++ build
# (cmake, python3, g++), git-lfs for the game assets, and lld to link with.
RUN apt-get update \
    && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        ca-certificates curl git git-lfs build-essential pkg-config cmake python3 lld \
        libasound2-dev libudev-dev \
    && rm -rf /var/lib/apt/lists/*

ENV RUSTUP_HOME=/usr/local/rustup CARGO_HOME=/usr/local/cargo
RUN curl -sSfo /tmp/rustup-init \
        "https://static.rust-lang.org/rustup/archive/$RUSTUP_VERSION/x86_64-unknown-linux-gnu/rustup-init" \
    && echo "$RUSTUP_SHA256  /tmp/rustup-init" | sha256sum -c - \
    && chmod +x /tmp/rustup-init \
    && /tmp/rustup-init -y --no-modify-path --profile minimal --default-toolchain none \
    && rm /tmp/rustup-init \
    && /usr/local/cargo/bin/rustup toolchain install "$RUST_TOOLCHAIN" --profile minimal \
    && chmod -R a+rX /usr/local/rustup /usr/local/cargo

# The build runs as your user, who can't write to the image's rustup or cargo
# dirs. So: call the toolchain directly instead of through rustup, and keep
# cargo's download cache in the clone (.ctf/, ignored by git).
# The repo's .cargo/config.toml links with mold through gcc, which Ubuntu
# 22.04's gcc can't do; RUSTFLAGS takes precedence and links with lld instead.
ENV RUST_TOOLCHAIN=$RUST_TOOLCHAIN \
    PATH=/usr/local/rustup/toolchains/${RUST_TOOLCHAIN}-x86_64-unknown-linux-gnu/bin:$PATH \
    CARGO_HOME=/src/.ctf/cargo \
    RUSTFLAGS="-C link-arg=-fuse-ld=lld" \
    HOME=/tmp \
    CTF_KIT_CONTAINER=1
WORKDIR /src
