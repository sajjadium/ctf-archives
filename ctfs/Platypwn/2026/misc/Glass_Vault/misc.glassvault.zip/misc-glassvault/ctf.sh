#!/bin/sh
# CTF "Glass Vault" client kit: build your Veloren v0.18.0 client in Docker,
# then start it.
#
# Put this file and ctf.Dockerfile into your Veloren clone:
#
#     git clone --depth 1 --branch v0.18.0 https://gitlab.com/veloren/veloren.git
#     cd veloren
#     ./ctf.sh            # build, then start the client
#     ./ctf.sh build      # only build
#
# Change any file in the clone and run ./ctf.sh again: only what changed is
# rebuilt. Needs git and Docker; everything else comes in the container.
set -eu

image=veloren-ctf-kit
profile=no_overflow

build() { # inside the container, in the clone
    # A clone made without git-lfs has placeholder files instead of the game's
    # assets (fonts, images, sounds), and the client won't start.
    if head -c 100 assets/voxygen/font/OpenSans-Regular.ttf | grep -q git-lfs; then
        echo "ctf: downloading the game assets (git lfs, about 450 MB)"
        git lfs install --local > /dev/null
        git lfs pull
    fi
    want=$(cat rust-toolchain)
    if [ "$want" != "$RUST_TOOLCHAIN" ]; then
        echo "ctf: ERROR: this clone wants Rust $want, the kit has $RUST_TOOLCHAIN." >&2
        echo "ctf: The challenge needs Veloren v0.18.0 (git checkout v0.18.0)." >&2
        exit 1
    fi
    echo "ctf: building the client (profile $profile; the first build takes a while)"
    cargo build --profile "$profile" --bin veloren-voxygen
}

if [ "${CTF_KIT_CONTAINER:-}" = 1 ]; then
    build
    exit
fi

cd "$(dirname "$0")"
if [ ! -f voxygen/Cargo.toml ] || [ ! -f ctf.Dockerfile ]; then
    echo "ctf: put ctf.sh and ctf.Dockerfile into your Veloren clone and run it there" >&2
    exit 1
fi
mode=${1:-run}
case $mode in
    run | build) ;;
    *) echo "usage: ./ctf.sh [build]" >&2; exit 2 ;;
esac

# Keep the kit's files out of `git status` and `git diff`.
mkdir -p .ctf
if [ -d .git ]; then
    for f in /.ctf/ /ctf.sh /ctf.Dockerfile; do
        grep -qxF "$f" .git/info/exclude 2>/dev/null || echo "$f" >> .git/info/exclude
    done
fi

# The image needs no build context: the clone (with its large target/) is
# mounted instead.
echo "ctf: preparing the build container (the first time takes a few minutes)"
docker build -q -t "$image" - < ctf.Dockerfile > /dev/null
tty=
[ -t 0 ] && tty=-it
# As your own user, so everything written to the clone stays yours.
docker run --rm $tty --user "$(id -u):$(id -g)" -v "$PWD:/src" "$image" sh ./ctf.sh

client=./target/$profile/veloren-voxygen
if [ "$mode" = build ]; then
    echo "ctf: done. Start the client with ./ctf.sh, or: VELOREN_ASSETS=./assets $client"
    exit
fi
echo "ctf: starting the client"
VELOREN_ASSETS=./assets exec "$client"
