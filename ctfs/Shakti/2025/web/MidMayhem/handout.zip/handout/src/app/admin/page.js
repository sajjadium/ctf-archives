
export default function Admin() {
  const flag="flag{dummy}"
  return (
    <div>
        Admin Page <br/><br/>
        Super confidential data:<br/><br/>
        {flag}
    </div>
 
  );
}
