from pathlib import Path


ROOT_DIR = Path(__file__).resolve().absolute().parent.parent.parent
