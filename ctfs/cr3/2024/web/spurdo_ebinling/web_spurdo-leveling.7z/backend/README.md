# spurdo-leveling-backend

## Installing

* `poetry install`

## Running

* `poetry run python3 -m server`

OR

* `poetry run python3 main.py`

## Generating proto stuff

* `poetry run python3 scripts/compile_proto.py`

## Linting

* `poetry run isort .; flake8 .; mypy .`
