
class DropConnectionException(Exception):
    pass
