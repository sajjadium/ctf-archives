# Executes a google sheets formula and returns the result.
# If you don't have API access, just copy and paste into your own file

# censored implementation
def execute_formula(formula):
    print("Copy and paste this formula into a google sheets to run it by hand.")
    print("\n============================\n")
    print(formula)
    print("\n============================\n")
    return "cope"
