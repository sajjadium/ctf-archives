/* This file is auto generated, version 80~20.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#80~20.04.1-Ubuntu SMP Wed May 17 14:58:14 UTC 2023"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "bos03-amd64-038"
#define LINUX_COMPILER "gcc (Ubuntu 9.4.0-1ubuntu1~20.04.1) 9.4.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
