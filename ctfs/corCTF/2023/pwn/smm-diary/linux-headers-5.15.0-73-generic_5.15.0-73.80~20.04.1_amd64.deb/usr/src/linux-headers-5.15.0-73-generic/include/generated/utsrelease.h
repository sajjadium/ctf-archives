#define UTS_RELEASE "5.15.0-73-generic"
#define UTS_UBUNTU_RELEASE_ABI 73
