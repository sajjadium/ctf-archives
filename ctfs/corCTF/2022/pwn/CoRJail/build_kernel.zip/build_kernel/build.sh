KERNEL_VERSION="linux-5.10.127"

# Install requirements
apt update
apt install make gcc flex bison libncurses-dev libelf-dev libssl-dev

# Downlad kernel and copy config
wget https://git.kernel.org/pub/scm/linux/kernel/git/stable/linux.git/snapshot/$KERNEL_VERSION.tar.gz
tar -xzvf $KERNEL_VERSION.tar.gz
cp -v kernel_config $KERNEL_VERSION/.config

# Syscall statistics patch (Based on https://lwn.net/Articles/896474/)
cp -v kernel_patch $KERNEL_VERSION/p
cd $KERNEL_VERSION && patch -p1 < p && rm p

# Compile and install modules
make -j `nproc` KBUILD_BUILD_TIMESTAMP='Thu January 1 00:00:00 UTC 2030'
make modules_install INSTALL_MOD_PATH='.'

cd ../
