/* This file is auto generated, version 117~20.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#117~20.04.1-Ubuntu SMP Tue Apr 30 10:35:57 UTC 2024"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-017"
#define LINUX_COMPILER "gcc (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
