#! /bin/bash

cd /home/awpcode && sudo -u $USER python3 chal.py