const app = require('./app')
const port = 20035
app.listen(port, () => console.log(`The server is listening on localhost:${port}`))
