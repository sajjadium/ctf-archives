#!/bin/sh
/app/chal.py 2>&1