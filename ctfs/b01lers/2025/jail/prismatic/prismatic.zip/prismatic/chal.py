#!/usr/local/bin/python3
import string
import sys

allowed_chars = string.ascii_lowercase + ".[]; "

inp = input("> ")

for c in inp:
	if c not in allowed_chars:
		print(f"Illegal char {c}")
		exit()

sys.stdin.close()
sys.stdout.close()
sys.stderr.close()
exec(inp, {"__builtins__": {k: v for k, v in __builtins__.__dict__.items() if "__" in k}})
