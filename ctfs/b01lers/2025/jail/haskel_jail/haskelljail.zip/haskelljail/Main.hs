import Language.Haskell.Interpreter
import System.IO
import Data.List

eval' :: String -> IO ()
eval' x = do
  ret <- runInterpreter $ setImports ["Prelude", "System.IO"]
    >> runStmt "hSetBuffering stdout NoBuffering"
    >> runStmt x
  case ret of
    Right _ -> return ()
    Left (WontCompile ((GhcError msg):_)) -> putStrLn msg

check :: String -> Bool
check x = and $ map ($ x) [
    not . isInfixOf "readFile",
    not . isInfixOf "flag",
    not . isInfixOf ",",
    not . isInfixOf "(",
    not . isInfixOf "<",
    not . isInfixOf "+",
    not . isInfixOf "*",
    not . isInfixOf "/",
    not . isInfixOf "-",
    not . isInfixOf "&&",
    not . isInfixOf "||",
    not . isInfixOf "[",
    not . isInfixOf "]",
    not . isInfixOf "\"",
    not . isInfixOf "mempty",
    not . isInfixOf "replicate",
    not . isInfixOf "repeat",
    not . isInfixOf "pure",
    not . isInfixOf "return"]

main = do
  putStr "bhci> " >> hFlush stdout
  inp <- getLine
  if check inp then eval' inp else putStrLn "Illegal input."
