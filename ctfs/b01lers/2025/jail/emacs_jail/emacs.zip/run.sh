#!/usr/bin/env bash
script -f /dev/null -qfc 'emacs -q -l /app/init.el && cat /flag.txt'