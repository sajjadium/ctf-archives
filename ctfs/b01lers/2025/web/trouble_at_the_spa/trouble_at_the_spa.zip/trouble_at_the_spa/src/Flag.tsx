export default function Flag() {
    return (
        <section className="text-center pt-24">
            <div className="flex items-center text-5xl font-bold justify-center">
                {'bctf{test_flag}'}
            </div>
        </section>
    )
}
