from sqlalchemy import create_engine, inspect
from sqlalchemy.orm import scoped_session, sessionmaker, relationship
from flask import Flask, redirect, request, render_template, url_for
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from re import match
from secrets import token_hex
from os import getenv

from models import PrivateLinks, Users, Links
from utils import gen_path, statusify

import bcrypt


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///db/links.db"
app.config["TOKEN"] = token_hex(64)
app.secret_key = token_hex(64)
engine = create_engine(app.config["SQLALCHEMY_DATABASE_URI"], echo=False)
SessionFactory = sessionmaker(bind=engine)
Session = scoped_session(SessionFactory)
base_url = getenv("BASE_URL", "http://127.0.0.1:5000/")
ukwargs = {"back_populates": ""}
pkwargs = {"back_populates": ""}
login_manager = LoginManager(app)
login_manager.login_view = "login"

@app.route("/")
def index():
    create_tables()
    return render_template("index.html")

@app.route("/sponsors")
def sponsors():
    return render_template("sponsors.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.route("/creator")
def creator():
    return render_template("creator.html")

@app.route("/create", methods=["GET"])
def create():
    with Session() as session:
        url = request.args.get("url", default=None)
        if url is None \
            or len(url) > 130 \
            or not match(r'^(https?://)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?$', url):
            return statusify(False, "Invalid Url")
        path = gen_path()
        while any([link.path == path for link in session.query(Links).filter_by(path=path).all()]):
            path = gen_path()
        session.add(Links(url=url, path=path))
        session.commit()
        return statusify(True, path)

@app.route("/all", methods=['GET'])
def all():
    with Session() as session:
        links = session.query(Links).all()
        for i in range(len(links)):
            links[i] = str(links[i])
        return statusify(True, links)

@app.route("/<path:path>", methods=['GET'])
def handle_path(path):
    with Session() as session:
        link: Links = session.query(Links).filter_by(path=path).first()
        if link is None:
            return redirect("/")
        return redirect(link.url)

@app.route("/register", methods=['GET', 'POST'])
def register():
    create_tables()
    if request.method == "POST":
        name = request.form["name"]
        password = request.form["password"]
        email = request.form["email"]
        with Session() as session:
            existing_user = session.query(Users).filter_by(name=name).first()
            if existing_user:
                return statusify(False, "User already exists")
            hashed_password = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")
            new_user = Users(name=name, hashed_pw=hashed_password, email=email)
            session.add(new_user)
            session.commit()
        return statusify(True, "Account successfully created.")
    return render_template("register.html")

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == "POST":
        name = request.form["name"]
        password = request.form["password"]

        with Session() as session:
            user = session.query(Users).filter_by(name=name).first()
            if user and bcrypt.checkpw(password.encode("utf-8"), user.hashed_pw.encode("utf-8")):
                login_user(user)
                return statusify(True, "Logged in")
            else:
                return statusify(False, "Invalid Credentials")
    return render_template("login.html")

@app.route("/logout", methods=['GET'])
def logout():
    logout_user()
    return redirect(url_for("login"))

@app.route("/user/create", methods=['GET'])
@login_required
def create_private():
    with Session() as session:
        user:Users = session.query(Users).filter_by(name=current_user.name).first()
        print(user.name)
        url = request.args.get("url", default=None)
        if url is None \
            or len(url) > 130 \
            or not match(r'^(https?://)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:/[^\s]*)?$', url):
            return statusify(False, "Invalid Url")
        path = gen_path()
        while any([link.path == path for link in session.query(PrivateLinks).filter_by(path=path, user_id=user.id).all()]):
            path = gen_path()
        session.add(PrivateLinks(url=url, path=path, user_id=user.id))
        session.commit()
    return statusify(True, "user/" + path)

@app.route("/user/<path:path>", methods=['GET'])
@login_required
def handle_private(path):
    with Session() as session:
        user:Users = session.query(Users).filter_by(name=current_user.name).first()
        link:PrivateLinks = session.query(PrivateLinks).filter_by(path=path, user_id=user.id).first()
        if link is None:
            return redirect("/")
    return redirect(link.url) 

@app.route("/user/all", methods=['GET'])
@login_required
def all_private():
    with Session() as session:
        user:Users = session.query(Users).filter_by(name=current_user.name).first()
        links = session.query(PrivateLinks).filter_by(user_id=user.id).all()
        for i in range(len(links)):
            links[i] = str(links[i])
    return statusify(True, links)

@app.route("/configure", methods=['POST'])
def configure():
    global base_url
    global ukwargs
    global pkwargs
    data = request.get_json()
    if data and data.get("token") == app.config["TOKEN"]: 
        base_url = data.get("base_url")
        app.config["TOKEN"] = data.get("new_token")
        ukwargs = data.get("ukwargs")
        pkwargs = data.get("pkwargs")
    else:
        return statusify(False, "Invalid Params")
    return statusify(True, "Success")

def create_tables():
    inspector = inspect(engine)
    if 'users' not in inspector.get_table_names():
        Users.private_links = relationship("PrivateLinks", **ukwargs)
        Users.__table__.create(engine)
    if 'privatelinks' not in inspector.get_table_names():
        PrivateLinks.users = relationship("Users", **pkwargs)
        PrivateLinks.__table__.create(engine)

@login_manager.user_loader
def load_user(user_id):
    with Session() as session:
        return session.get(Users, int(user_id))

if __name__ == '__main__':
    inspector = inspect(engine)
    if 'links' not in inspector.get_table_names():
        Links.__table__.create(engine)
    app.run(host="0.0.0.0", debug=False)
