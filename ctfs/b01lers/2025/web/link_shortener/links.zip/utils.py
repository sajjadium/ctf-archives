from string import ascii_letters
from random import choice
from typing import Any

def gen_path() -> None:
    return ''.join(choice(ascii_letters) for _ in range(4))

def statusify(success: bool, data: Any) -> dict:
    return {'success': success, 'data': data}