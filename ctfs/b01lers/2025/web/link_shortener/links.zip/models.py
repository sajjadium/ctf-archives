from typing import Optional
from sqlalchemy import ForeignKey, String
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from flask_login import UserMixin

class Base(DeclarativeBase):
    pass

class Links(Base):
    __tablename__ = "links"
    id: Mapped[int] = mapped_column(primary_key=True)
    url: Mapped[str]
    path: Mapped[str]

    def __repr__(self) -> str:
        return f"Link(id={self.id!r}, url={self.url!r}, path={self.path!r})".format(self=self)

class Users(Base, UserMixin):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(30))
    email: Mapped[Optional[str]]
    hashed_pw: Mapped[str]
    
    def __repr__(self) -> str:
        return f"User(id={self.id!r}, name={self.name!r}, email={self.email!r})".format(self=self)
    
class PrivateLinks(Base):
    __tablename__ = "privatelinks"
    id: Mapped[int] = mapped_column(primary_key=True)
    url: Mapped[str]
    path: Mapped[str]

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))

    def __repr__(self) -> str:
        return f"Link(id={self.id!r}, url={self.url!r}, path={self.path!r})".format(self=self)

