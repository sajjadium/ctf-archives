import sqlite3

FLAG = "bctf{tungtungtungtungtungsahua}"
def init_db():
    db = sqlite3.connect("/data/app.db")
    cursor = db.cursor()
    
    # Create users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE
        )
    ''')
    
    # Create secrets table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS secrets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key INTEGER NOT NULL,
            value TEXT NOT NULL
        )
    ''')
    
    # Insert sample data if empty
    cursor.execute('SELECT COUNT(*) FROM users')
    if cursor.fetchone()[0] == 0:
        cursor.executemany('INSERT INTO users (name, email) VALUES (?, ?)', [
            ('alice', 'alice@example.com'),
            ('bob', 'bob@example.com'),
            ('charlie', 'charlie@example.com')
        ])
        
        cursor.executemany('INSERT INTO secrets (key, value) VALUES (?, ?)', [
            ("junk", 'Wrong turn baby'),
            ("flag", FLAG),
            (2, 'Bob secret 1'),
            (3, 'Charlie secret 1')
        ])
    
    db.commit()

if __name__ == "__main__":
    init_db()