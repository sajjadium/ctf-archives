from flask import Flask, jsonify, g
import sqlite3
import os
from pathlib import Path
import traceback
from flask_mysqldb import MySQL
import socket
import random

app = Flask(__name__)
DATABASE = '/data/app.db'
BLACKLIST = ['(', ')', '-', '#', '%', '+', ';']

# You can save some time by going straight down to line 150

# Credit to WolvSec team I take (borrow) this from them in their nearest CTF

def get_db_hostname():
    # use this when running locally with docker compose
    db_hostname = 'realdb'
    try:
        socket.getaddrinfo(db_hostname, 3306)
        return db_hostname
    except:
        # use this for google cloud
        return '127.0.0.1'


app.config['MYSQL_HOST'] = get_db_hostname()
app.config['MYSQL_USER'] = os.environ["MYSQL_USER"]
app.config['MYSQL_PASSWORD'] = os.environ["MYSQL_PASSWORD"]
app.config['MYSQL_DB'] = os.environ["MYSQL_DB"]
mysql = MySQL(app)



def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

    
@app.teardown_appcontext
def close_db(e=None):
    db = g.pop('db', None)
    if db is not None:
        db.close()


def random_status_code():
    return random.randint(200, 500)

@app.errorhandler(404)
def handle_404(e):
    code = random_status_code()
    return f"<h1>💀</h1>", code

@app.errorhandler(405)
def handle_405(e):
    code = random_status_code()
    return f"<h1>💀</h1>", code
        
@app.route('/', methods=["GET"])
def index():
    content = """<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <title>Demo Database Protection Product</title>
                <style>
                    body {
                        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
                        margin: 0;
                        padding: 0;
                        background-color: #f9f9f9;
                        color: #333;
                    }
                    header {
                        background-color: #2d6cdf;
                        color: white;
                        padding: 20px 40px;
                        text-align: center;
                    }
                    main {
                        padding: 40px;
                        max-width: 800px;
                        margin: auto;
                    }
                    section {
                        margin-bottom: 30px;
                    }
                    h2 {
                        color: #2d6cdf;
                        margin-top: 0;
                    }
                    footer {
                        background-color: #eee;
                        text-align: center;
                        padding: 15px;
                        font-size: 0.9em;
                        color: #666;
                        border-top: 1px solid #ccc;
                    }
                </style>
            </head>
            <body>
                <header>
                    <h1>Demo Database Protection Product</h1>
                </header>
                <main>
                    <section>
                        <h2>Overview</h2>
                        <p>
                            Our cutting-edge protection layer monitors and secures your database operations 
                            in real-time. Designed for enterprise-scale applications, it helps prevent 
                            unauthorized access, injection attacks, and sensitive data exposure.
                        </p>
                    </section>
                    <section>
                        <h2>Key Features</h2>
                        <ul>
                            <li>Real-time query inspection and risk scoring</li>
                            <li>Role-based query access control</li>
                            <li>Advanced anomaly detection powered by AI</li>
                            <li>Visual audit trails and query history</li>
                        </ul>
                    </section>
                    <section>
                        <h2>Why Choose Us?</h2>
                        <p>
                            Built with security-first principles, our system seamlessly integrates into 
                            your stack with zero downtime. Whether you're protecting customer data or 
                            internal assets, our tool gives you confidence and control.
                        </p>
                    </section>
                </main>
                <footer>
                    Frontend and Content by chatGPT
                </footer>
            </body>
            </html>
    """
    return content, 200


@app.route('/info/<path:name>', methods=['GET'])
def get_user_info(name):
    if len(name) > 100:
        return jsonify({"Message": "Why the long name? Are you Tung Tung Tung Tung Tung Tung Tung Sahua????"}), 403
    try:
        db = get_db()
        cursor = db.cursor()
    except Exception:
        print(traceback.format_exc())
        return jsonify({"Error": "Something very wrong happened, either retry or contact organizers if issue persists!"}), 500
    
    # Verify that the query is good and does not touch the secrets table
    
    query = f"SELECT * from users WHERE name = '{name}'"
    for item in BLACKLIST:
        if item in query:
            return jsonify({"Message": f"Probably sus"}), 403
    try:
        explain = "EXPLAIN QUERY PLAN " + query
        cursor.execute(explain)
        result = cursor.fetchall()
        if len(result) > 7:
            return jsonify({"Message": "Probably sus"}), 403
        for item in result:
            if "secrets" in item[3]:
                return jsonify({"Message": "I see where you're going..."}), 403
    except Exception as e:
        print(traceback.format_exc())
        return jsonify({"Message": f"Probably sus"}), 403

    # Now let the query through to the real production db
    
    cursor.close()
    
    try:
        cur = mysql.connection.cursor()
        cur.execute(query)
        records = cur.fetchall()[0]
        cur.close()
        return str(records)
    except Exception as e:
        print(traceback.format_exc())
        return jsonify({'Error': "It did not work boss!"}), 400

if __name__ == '__main__':
    if not Path(DATABASE).exists():
        print("Skull setup did not run")
        import sys; sys.exit(1)
    
    app.run(host='0.0.0.0', port=5000)