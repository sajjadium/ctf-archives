#!/bin/sh

# Initialize database if it doesn't exist
if [ ! -f "/data/app.db" ]; then
    python setup.py
    sleep 5
fi

# Start Gunicorn
exec gunicorn --bind 0.0.0.0:5000 --workers 4 app:app