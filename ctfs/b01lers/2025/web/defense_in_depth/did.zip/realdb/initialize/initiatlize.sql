-- Create database and read-only user
CREATE DATABASE IF NOT EXISTS app_db;
CREATE USER IF NOT EXISTS 'b01lers'@'%' IDENTIFIED BY 'redacted';
GRANT SELECT ON app_db.* TO 'b01lers'@'%';
FLUSH PRIVILEGES;

USE app_db;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- Create secrets table
CREATE TABLE IF NOT EXISTS secrets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    `key` VARCHAR(255) NOT NULL,
    value TEXT NOT NULL
) ENGINE=InnoDB;

-- Insert sample data
INSERT IGNORE INTO users (name, email) VALUES
    ('neil', 'freshmen@purdue.eduuu'),
    ('gabe', 'boss@retirement.home'),
    ('kevin', 'frontend@kev.in');

INSERT IGNORE INTO secrets (`key`, value) VALUES
    ('junk', 'Wrong turn baby'),
    ('flag', 'bctf{tungtungtungtungtungsahua}');

-- Verify permissions
SHOW GRANTS FOR 'b01lers'@'%';
