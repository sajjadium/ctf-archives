import Fastify from "fastify";
import fastifyFormBody from "@fastify/formbody";
import fastifyRateLimit from "@fastify/rate-limit";
import fs from "node:fs/promises";
import puppeteer from "puppeteer";
const fastify = Fastify({ logger: true, trustProxy: true });
fastify.register(fastifyFormBody);

function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}

async function visit(url) {
	const initBrowser = puppeteer.launch({
		headless: true,
		args: ["--js-flags=--jitless", "--no-sandbox"],
		acceptInsecureCerts: true,
	});
	const browser = await initBrowser;
	const context = await browser.createBrowserContext();
	try {
		await context.setCookie({
			name: "flag",
			httpOnly: false,
			value: process.env.FLAG ?? "bctf{fake_flag}",
			domain: new URL(url).hostname,
		});

		console.log("Visiting: " + url);
		const page = await context.newPage();
		await page.goto(url, {
			timeout: 5000,
			waitUntil: "networkidle2",
		});
		console.log("Visited: " + url);
		await sleep(5000);
		// Close
		await context.close();
		console.log("Closed...");
	} catch (e) {
		console.error(e);
		await context.close();
	}
}
fastify.get("/", async (req, reply) => {
	reply.type("text/html");
	return (await fs.readFile("index.html"))
		.toString()
		.replace("{msg}", req.query.msg ?? "")
		.replace("{url}", req.query.url ?? "");
});

fastify.register(async function (fastify, options) {
	await fastify.register(fastifyRateLimit, {
		global: true,
		max: 2,
		timeWindow: 60 * 1000,
		keyGenerator(request) {
			return request.headers["x-real-ip"];
		},
	});
	fastify.post("/", async (req, reply) => {
		const url = req?.body?.url;
		if (url === undefined) {
			return reply.redirect(`/?url=${url}&msg=${encodeURIComponent(`No url provided`)}`);
		} else if (/^no-code-[a-f0-9]+\.instancer\.b01lersc\.tf$/.test(new URL(url).hostname)) {
			visit(url);
			return reply.redirect(`/?url=${url}&msg=${encodeURIComponent(`Visiting ${url}`)}`);
		} else {
			return reply.redirect(`/?url=${url}&msg=${encodeURIComponent(`Invalid url ${url}`)}`);
		}
	});
	fastify.setErrorHandler(function (error, req, reply) {
		this.log.error(error);
		return reply.redirect(
			`/?url=${req?.body?.url ?? ""}&msg=${encodeURIComponent(error.message)}`
		);
	});
});

fastify.listen({ port: 8001, host: "0.0.0.0" });
