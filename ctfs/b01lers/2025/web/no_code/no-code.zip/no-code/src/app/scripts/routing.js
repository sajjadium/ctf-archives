function routeLinks() {
	for (let link of document.getElementsByTagName("a")) {
		link.addEventListener("click", async (event) => {
			let url = new URL(event.target.href);
			if (
				new URL(document.baseURI).origin === url.origin &&
				event.target.getAttribute("href")[0] !== "#"
			) {
				event.preventDefault();
				url.searchParams.append("page", url.pathname.slice(1));
				let resp = await fetch("/page" + url.search);
				let data = await resp.json();
				await loadJson(data);
				history.pushState({}, "", event.target.href);
				routeLinks();
				if (url.hash) {
					document.getElementById(url.hash.slice(1))?.scrollIntoView();
				}
			}
		});
	}
}
window.addEventListener("load", routeLinks);
window.addEventListener("popstate", async function (event) {
	let url = new URL(window.location);
	url.searchParams.append("page", url.pathname.slice(1));
	let resp = await fetch("/page" + url.search);
	let data = await resp.json();
	await loadJson(data);
	routeLinks();
	if (url.hash) {
		document.getElementById(url.hash.slice(1))?.scrollIntoView();
	}
});
