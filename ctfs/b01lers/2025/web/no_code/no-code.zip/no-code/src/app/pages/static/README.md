These will be placed in the /static folder.
