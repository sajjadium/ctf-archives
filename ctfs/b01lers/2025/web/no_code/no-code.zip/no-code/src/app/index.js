import Fastify from "fastify";
import fastifyStatic from "@fastify/static";
import fs from "node:fs/promises";
import path from "node:path";

// parse extended qs
function parseQuery(query) {
	query = query.replace(/$\?/, "");
	const params = query.split("&");
	const result = {};
	for (const param of params) {
		const [key, value] = param.split("=").map(decodeURIComponent);
		if (key.includes("[")) {
			const parts = key.split("[").map((part) => part.replace(/]$/, ""));
			let curr = result;
			for (let part of parts.slice(0, -1)) {
				if (curr[part] === undefined) {
					curr[part] = {};
				}
				curr = curr[part];
			}
			curr[parts[parts.length - 1]] = value;
		} else {
			result[key] = value;
		}
	}
	return result;
}

function escapeRegex(string) {
	return string.replace(/[/\-\\^$*+?.()|[\]{}]/g, "\\$&");
}

// templating
function replaceProps(s, props) {
	for (const [key, value] of Object.entries(props)) {
		s = s.replace(new RegExp(`{{${escapeRegex(key)}}}`, "g"), value);
	}
	s = s.replace(/{{\w+}}/g, "");
	return s;
}

// templating
function replaceAllProps(obj, props) {
	if (typeof obj !== "object") {
		return obj;
	}
	if (obj.attributes !== undefined) {
		obj.attributes = Object.fromEntries(
			Array.from(Object.entries(obj.attributes)).map(([key, value]) => [
				key,
				replaceProps(value, props),
			])
		);
	}
	if (obj.text !== undefined) {
		obj.text = replaceProps(obj.text, props);
	}
	if (obj.children !== undefined) {
		obj.children = Array.from(obj.children).map((child) => replaceAllProps(child, props));
	}
	return obj;
}

async function getPage(page, props) {
	const pageDocument = JSON.parse((await fs.readFile(`./pages/${page}.json`)).toString());
	return replaceAllProps(pageDocument, props);
}

const fastify = Fastify({ logger: true, querystringParser: parseQuery });

fastify.register(fastifyStatic, {
	root: path.join(import.meta.dirname, "scripts"),
	prefix: "/scripts/",
});
fastify.register(fastifyStatic, {
	root: path.join(import.meta.dirname, "pages/static"),
	prefix: "/static/",
	decorateReply: false,
});

fastify.get("/:page", async (req, reply) => {
	const page = req.params.page || "index";
	if (!/^\w+$/.test(page)) {
		reply.code(400);
		return { err: "invalid page" };
	}

	reply.header(
		"content-security-policy",
		`require-trusted-types-for 'script'; trusted-types 'none'`
	);
	reply.type("text/html");
	const initial = JSON.stringify(await getPage(page, req.query)).replace(/</g, "\\x3c");
	return (await fs.readFile("index.html")).toString().replace(/\{\{initial\}\}/g, initial);
});

fastify.get("/page", async (req, reply) => {
	let { page, props } = req.query;
	if (page === undefined) {
		reply.code(400);
		return { err: "page not provided" };
	}
	props = props ?? {};

	if (!/^\w+$/.test(page)) {
		reply.code(400);
		return { err: "invalid page" };
	}
	reply.type("application/json");

	return getPage(page, props);
});
fastify.listen({ port: 8000, host: "0.0.0.0" });
