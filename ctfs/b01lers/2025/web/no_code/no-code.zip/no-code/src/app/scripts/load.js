let content = document.getElementById("content");
let oldLinks = [];
async function loadJson(json) {
	let dom = jsonToDom(json);

	// make styles load first
	let promises = [];
	newLinks = [];
	for (let link of dom.querySelectorAll("link")) {
		link.remove();
		promises.push(
			new Promise((resolve, reject) => {
				link.addEventListener("load", resolve);
			})
		);
		document.head.append(link);
		newLinks.push(link);
	}
	await Promise.all(promises);
	for (let link of oldLinks) {
		link.remove();
	}
	oldLinks = newLinks;

	content.replaceChildren(dom);
}
loadJson(initial);
