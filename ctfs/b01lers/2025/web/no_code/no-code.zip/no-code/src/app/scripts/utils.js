function jsonToDom(json) {
	if (typeof json === "string") {
		return document.createTextNode(json);
	}

	const { tag, text, attributes, children } = json;
	const element = document.createElement(tag);
	if (text !== undefined) {
		element.textContent = text;
	}

	if (attributes !== undefined) {
		for (const [key, value] of Object.entries(attributes)) {
			element.setAttribute(key, value);
		}
	}

	if (children !== undefined) {
		for (const childJson of children) {
			element.append(jsonToDom(childJson));
		}
	}

	return element;
}

function domToJson(element) {
	if (element instanceof Comment) {
		return null;
	}

	if (element instanceof Text) {
		return element.textContent;
	}

	const json = {};
	json.tag = element.tagName.toLowerCase();

	json.attributes = {};
	for (const { name, value } of element.attributes) {
		json.attributes[name] = value;
	}

	if (element.childNodes.length == 1 && element.childNodes[0] instanceof Text) {
		json.text = element.textContent;
	} else {
		json.children = Array.from(element.childNodes)
			.map(domToJson)
			.filter((x) => x !== null);
	}

	return json;
}
