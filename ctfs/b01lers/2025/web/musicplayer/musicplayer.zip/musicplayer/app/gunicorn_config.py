workers = 4
bind = ["0.0.0.0:8000"]
enable_stdio_inheritance = True
