#!/bin/sh
. /venv/bin/activate
python3 <<EOF
import sqlite3

conn = sqlite3.connect("/db/musicplayer.db")

conn.execute("""
CREATE TABLE IF NOT EXISTS playlists(
	id INTEGER PRIMARY KEY,
	title TEXT,
	folder TEXT
)""")

conn.execute("""
CREATE TABLE IF NOT EXISTS songs(
	id INTEGER PRIMARY KEY,
	playlist_id INTEGER,
	title TEXT,
	filename TEXT
)""")
EOF

/app/auto_reload.sh &
gunicorn -c /app/gunicorn_config.py app.main:app &
tail -f /dev/null