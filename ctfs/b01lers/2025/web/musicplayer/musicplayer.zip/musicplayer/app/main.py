import shutil
import sqlite3
import tempfile
import uuid
from pathlib import Path

from flask import Flask, g, jsonify, request
from flask.helpers import send_from_directory
from tinytag import TinyTag, UnsupportedFormatError

UPLOAD_DIR = Path("/app/uploads")
DB_PATH = Path("/db/musicplayer.db")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024


def get_conn():
	"""returns sqlite3 connection"""
	try:
		return g.db
	except AttributeError:
		conn = sqlite3.connect(DB_PATH)
		g.db = conn
		return conn


@app.teardown_appcontext
def close_conn(exception):  # noqa: ARG001
	if hasattr(g, "db"):
		g.db.close()


@app.errorhandler(500)
def internal_server_error(e):
	return jsonify({"error": str(e)}), 500


@app.route("/")
def index():
	return app.send_static_file("index.html")


@app.route("/api/playlists/upload", methods=["POST"])
def upload():
	"""returns {error: bool}"""
	conn = get_conn()
	cursor = conn.cursor()

	if "title" not in request.form:
		return jsonify({"error": "Missing title"}), 500
	if "videos" not in request.files:
		return jsonify({"error": "Missing videos"}), 500

	playlist_title = request.form["title"]
	videos = request.files["videos"]

	if not playlist_title:
		return jsonify({"error": "Playlist title is empty"}), 500
	if not videos.filename:
		return jsonify({"error": "Uploaded file does not have a filename"}), 500

	folder = uuid.uuid4().hex

	with conn:
		# create playlist
		cursor.execute("BEGIN TRANSACTION")
		cursor.execute(
			"INSERT INTO playlists(title, folder) VALUES(?, ?)",
			(playlist_title, folder),
		)
		playlist_id = cursor.lastrowid
		playlist_folder = UPLOAD_DIR.joinpath(folder)

		assert isinstance(playlist_id, int)

		# download videos
		with tempfile.NamedTemporaryFile(
			suffix=Path(videos.filename).suffix, delete=False
		) as f:
			videos.save(f)
			f.close()
			try:
				download_videos(cursor, f.name, playlist_folder, playlist_id)
			except shutil.ReadError:
				return jsonify({"error": "Uploaded file is not an archive"}), 500
			finally:
				Path(f.name).unlink()
	# success
	return jsonify({"error": ""})


def download_videos(cursor, archive, playlist_folder: Path, playlist_id: int):
	shutil.unpack_archive(archive, playlist_folder)

	children = list(playlist_folder.iterdir())
	if len(children) == 1 and children[0].is_dir():
		# archive contains a singleton folder
		shutil.copytree(children[0], playlist_folder, dirs_exist_ok=True)
		shutil.rmtree(children[0])

	# load songs into database
	for filename in playlist_folder.iterdir():
		try:
			audio_file = TinyTag.get(filename)
			if not audio_file.title or not audio_file.artist:
				# fix up yt-dlp's default filenames
				title = filename.stem.replace("⧸", "/").replace("⧹", "\\")  # noqa: RUF001
			else:
				title = f"{audio_file.artist} - {audio_file.title}"
		except UnsupportedFormatError:
			title = filename.stem

		cursor.execute(
			"INSERT INTO songs(playlist_id, title, filename) VALUES(?, ?, ?)",
			(playlist_id, title, filename.name),
		)


@app.route("/api/playlists/list")
def list_playlists():
	"""returns list of {id: int, title: str, folder: str} objects"""
	conn = get_conn()
	cursor = conn.cursor()
	with conn:
		res = cursor.execute("SELECT id, title, folder FROM playlists")

		playlists = [
			{
				"id": row[0],
				"title": row[1],
				"folder": row[2],
			}
			for row in res
		]
		return jsonify(playlists)


@app.route("/api/songs/list/<int:playlist_id>")
def list_songs(playlist_id):
	"""returns list of {title: str, filename: str, url: str} objects"""
	conn = get_conn()
	cursor = conn.cursor()
	with conn:
		res = cursor.execute(
			"SELECT title, filename FROM songs WHERE playlist_id = ?", (playlist_id,)
		)

		songs = [{"title": row[0], "filename": row[1]} for row in res]
		return jsonify(songs)


@app.route("/api/playlists/delete/<int:playlist_id>", methods=["POST"])
def delete(playlist_id):
	conn = get_conn()
	cursor = conn.cursor()
	with conn:
		(folder,) = cursor.execute("SELECT folder FROM playlists WHERE id = ?")
		shutil.rmtree(UPLOAD_DIR / folder)

		cursor.execute("DELETE FROM playlists WHERE id = ?", (playlist_id,))
		cursor.execute("DELETE FROM songs where playlist_id = ?", (playlist_id,))
	return jsonify({"error": ""})


@app.route("/api/songs/play/<folder>/<filename>")
def play(folder, filename):
	return send_from_directory(UPLOAD_DIR, Path(folder).joinpath(filename))


if __name__ == "__main__":
	app.run()
