#!/bin/sh
# for development purposes

watchmedo shell-command \
--patterns='*.py' \
--recursive \
--command='pid=$(pgrep -f gunicorn | head -1); kill -s USR2 $pid; kill -s TERM $pid' \
/app