#!/bin/sh
gcc -s -static -O3 -o readflag readflag.c