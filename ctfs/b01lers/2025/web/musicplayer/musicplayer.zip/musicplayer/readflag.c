#include <stdio.h>
#include <stdlib.h>

int main(void) {
	FILE *f = fopen("/flag.txt", "r");

	if (f == NULL) {
		fprintf(stderr, "/flag.txt not found");
	}

	fseek(f, 0, SEEK_END);
	long size = ftell(f);
	fseek(f, 0, SEEK_SET);

	char *buffer = malloc(size + 1);
	fread(buffer, size, 1, f);
	fclose(f);
	buffer[size] = '\0';

	printf("%s", buffer);
}