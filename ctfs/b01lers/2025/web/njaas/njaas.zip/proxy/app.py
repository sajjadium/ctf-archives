from flask import Flask, request, Response, render_template, redirect
from os import environ
from subprocess import CalledProcessError, run
from threading import Lock
from secrets import token_hex
import requests

NEXT_URL = "http://localhost:3000"
PROBLEMATIC_HEADERS = [
    'content-encoding',
    'content-length',
    'transfer-encoding',
    'connection',
    'accept-encoding'
]
STARTED = False
CSRF_TOKEN = token_hex(16)

app = Flask(__name__)
start_lock = Lock()

@app.route('/home', methods=['GET'])
def home():
    return render_template('index.html')

@app.route('/started', methods=['GET'])
def started():
    global STARTED
    if STARTED:
        return Response("Initialized", status=200)
    return Response("Not started yet.", status=428)

@app.route('/start', methods=['POST'])
def start():
    clear_csrf()
    environ['CSRF_TOKEN'] = CSRF_TOKEN
    global STARTED
    if STARTED:
        return Response("Start already initiated", status=428)
    with start_lock:
        if STARTED:
            return Response("Start already initiated", status=428)
        STARTED = True
        try:
            run(['sleep', '3'], check=False) # make sure lock is aquired
            run(['./start.sh'], cwd='../next', check=True)
            return Response("Starting 👍...", status=200)
        except CalledProcessError as e:
            return Response(f"Start Error: {str(e)}", status=500)
        except Exception as e:
            return Response(f"Unexpected Error: {str(e)}", status=500)
        
@app.route('/csrf', methods=['POST'])
def csrf():
    token = request.form.get('token', token_hex(16))[:30].strip().encode("utf-8")
    if len(token) < 20:
        return Response('Insecure CSRF Token.', status=500)
    try:
        clear_csrf()
        environ[token.decode("utf-8", errors="ignore")] = CSRF_TOKEN
        token = int(token, 16)
        return Response('Set valid CSRF Token.', status=200)
    except ValueError:
        return Response('CSRF Token must be hex.', status=500)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def proxy(path: str):
    if not STARTED:
        return redirect('/home')
    target_url = f'{NEXT_URL}/{path}'
    
    if request.query_string:
        target_url += f"?{request.query_string.decode('utf-8')}"

    headers = {
        key: value for (key, value) in request.headers 
        if key.lower() not in PROBLEMATIC_HEADERS
    }

    headers['Accept'] = 'application/json'

    for key, value in environ.items():
        if value == CSRF_TOKEN:
            headers['csrf-token'] = key
            break
    try:
        res = requests.get(
            target_url,
            data=request.get_data(),
            headers=headers,
            cookies=request.cookies,
            allow_redirects=False
        )

        if 'chunked' in res.headers.get('Transfer-Encoding', '').lower():
            def generate():
                for chunk in res.iter_content(chunk_size=8192):
                    yield chunk
            
            response_headers = [
                (k, v) for k, v in res.headers.items()
                if k.lower() not in PROBLEMATIC_HEADERS
            ]
            return Response(generate(), res.status_code, response_headers, direct_passthrough=True)

        if 300 <= res.status_code < 400:
            location = res.headers.get('Location')
            if location and location.startswith(NEXT_URL):
                new_location = location.replace(NEXT_URL, request.host_url.rstrip('/'))
                res.headers['Location'] = new_location

        response = Response(res.content, res.status_code, headers=[(k, v) for k, v in res.headers.items()])
        return response
    except Exception as e:
        return Response(f"Please wait! Your instance will be started shortly :)", status=502)

def clear_csrf() -> None:
    for key, value in environ.items():
        if value == CSRF_TOKEN:
            environ.pop(key, None) 

if __name__ == "__main__":
    app.run("0.0.0.0", port=8003)