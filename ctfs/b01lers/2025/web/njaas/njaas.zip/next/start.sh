#!/bin/bash

npm run start &
sleep 3