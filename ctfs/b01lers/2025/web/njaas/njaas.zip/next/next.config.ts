import type { NextConfig } from "next";

if (process.env.NODE_ENV != 'production') {
  process.exit(1); //just to be safe
}


const nextConfig: NextConfig = {
  /* config options here */
};

export default nextConfig;
