import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

// don't want just anyone getting the flag ⭐️ 
export function middleware(request: NextRequest) {
  return NextResponse.redirect(new URL('/', request.url));
}
 
export const config = {
  matcher: '/admin/:path*'
}