
export default function Flag() {
  return (
    <div>{ "fake{flag}" }</div>
  );
}
