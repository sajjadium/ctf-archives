#!/usr/bin/env python3
import json
from pathlib import Path

DATA_FILE = Path(__file__).with_name("challenge.json")

def main():

    if not DATA_FILE.exists():
        raise FileNotFoundError(
            "Missing challenge.json"
        )

    with open(DATA_FILE, "r") as f:
        data = json.load(f)

    print("=" * 60)
    print("              NVR CTF 2026")
    print("           THE LEAKED SIGNATURE")
    print("=" * 60)

    print("\n[+] Curve:")
    print(data["curve"])

    print("\n[+] Public Key:")
    print("Qx =", data["public_key"]["x"])
    print("Qy =", data["public_key"]["y"])

    print("\n[+] Nonce Leakage:")
    print("Known upper bits:", data["known_nonce_bits"])
    print("Unknown lower bits:", data["unknown_nonce_bits"])

    print("\n[+] Signatures:")

    for i, sig in enumerate(data["signatures"], 1):

        print(f"\nSignature #{i}")
        print("Message:", sig["message"])
        print("z =", sig["z"])
        print("r =", sig["r"])
        print("s =", sig["s"])
        print("leak =", sig["leak"])

    print("\n[+] Encrypted Flag:")
    print(data["encrypted_flag"])

    print("\n" + "=" * 60)
    print("Your mission:")
    print("1. Analyze the ECDSA signatures.")
    print("2. Recover the private key.")
    print("3. Decrypt the encrypted flag.")
    print("=" * 60)


if __name__ == "__main__":
    main()