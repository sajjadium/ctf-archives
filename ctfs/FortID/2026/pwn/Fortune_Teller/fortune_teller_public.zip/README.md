# Fortune Teller

The oracle will answer any question, but it may reveal more than it should.

Connect to the service and recover the flag.

```bash
./fortune
```

Files provided:

- `fortune`
- `chall.c`

Protections: Full RELRO, stack canary, NX, PIE.
