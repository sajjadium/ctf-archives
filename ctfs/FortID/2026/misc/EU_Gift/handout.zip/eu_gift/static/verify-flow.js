const verifyCard = document.querySelector(".verify-card");

if (verifyCard) {
    const statusUrl = verifyCard.dataset.statusUrl;
    const statusNote = document.getElementById("status-note");
    const pollIntervalMs = 5000;

    const updateStatus = async () => {
        try {
            const response = await fetch(statusUrl, {
                cache: "no-store",
                headers: { Accept: "application/json" },
            });
            const data = await response.json();

            if (data.redirectUrl) {
                window.location.assign(data.redirectUrl);
                return;
            }

            if (data.status === "IN_PROGRESS") {
                statusNote.textContent = "Waiting for wallet authentication.";
                window.setTimeout(updateStatus, pollIntervalMs);
                return;
            }

            if (data.description) {
                statusNote.textContent = data.description;
                return;
            }

            statusNote.textContent = "Verification ended unexpectedly.";
        } catch (error) {
            statusNote.textContent = "Could not refresh verification status.";
        }
    };

    window.setTimeout(updateStatus, pollIntervalMs);
}
