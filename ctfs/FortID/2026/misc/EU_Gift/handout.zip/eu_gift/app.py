from __future__ import annotations

import base64
import io
import mimetypes
import os
import re
from pathlib import Path
from typing import Any

import pycountry
import qrcode
import requests
import yaml
from flask import Flask, Response, jsonify, render_template, url_for
from qrcode.image.svg import SvgPathImage


BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.environ.get("CONFIG_PATH", BASE_DIR / "config.yml")).resolve()
COUNTRY_CODE_PATTERN = re.compile(r"[A-Z]{2}")


class VerifierServiceError(RuntimeError):
    pass


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        data = yaml.safe_load(handle)

    if not isinstance(data, dict):
        raise RuntimeError("Configuration root must be a mapping")

    return data


def load_valid_country_codes() -> frozenset[str]:
    codes = {
        country.alpha_2
        for country in pycountry.countries
        if isinstance(country.alpha_2, str) and COUNTRY_CODE_PATTERN.fullmatch(country.alpha_2)
    }

    if not codes:
        raise RuntimeError("No ISO 3166-1 alpha-2 country codes were loaded from pycountry")

    return frozenset(codes)


CONFIG = load_config(CONFIG_PATH)
SITE = CONFIG.get("site", {})
VERIFIER = CONFIG.get("verifier", {})
BLOCKED_COUNTRIES = set(CONFIG.get("blocked_countries", []))
VALID_COUNTRY_CODES = load_valid_country_codes()

flag_image_value = Path(str(CONFIG["flag_image"]))
FLAG_IMAGE = (
    flag_image_value
    if flag_image_value.is_absolute()
    else (CONFIG_PATH.parent / flag_image_value).resolve()
)

app = Flask(__name__)


def verifier_setting(name: str, default: Any = None) -> Any:
    return VERIFIER.get(name, default)


def resolve_verifier_api_key() -> str:
    env_name = verifier_setting("api_key_env")
    if isinstance(env_name, str) and env_name:
        env_value = os.environ.get(env_name)
        if env_value:
            return env_value

    api_key = verifier_setting("api_key")
    if not isinstance(api_key, str) or not api_key:
        raise VerifierServiceError("Verification service API key is not configured.")

    return api_key


def verifier_headers() -> dict[str, str]:
    return {
        "Content-Type": "application/json",
        "X-API-KEY": resolve_verifier_api_key(),
    }


def verifier_url(path: str) -> str:
    base_url = str(verifier_setting("base_url", "https://evs.fortid.com")).rstrip("/")
    return f"{base_url}/{path.lstrip('/')}"


def verifier_request(method: str, path: str, json_body: dict[str, Any] | None = None) -> requests.Response:
    try:
        response = requests.request(
            method=method,
            url=verifier_url(path),
            headers=verifier_headers(),
            json=json_body,
            timeout=(5, 20),
        )
    except requests.RequestException as exc:
        raise VerifierServiceError("Could not reach the verification service.") from exc

    return response


def parse_json_response(response: requests.Response) -> dict[str, Any]:
    try:
        data = response.json()
    except ValueError as exc:
        raise VerifierServiceError("Verification service returned a non-JSON response.") from exc

    if not isinstance(data, dict):
        raise VerifierServiceError("Verification service returned an unexpected response shape.")

    return data


def verifier_error_message(response: requests.Response) -> str:
    try:
        data = response.json()
    except ValueError:
        return response.text.strip() or f"HTTP {response.status_code}"

    for key in ("description", "error", "message"):
        value = data.get(key)
        if isinstance(value, str) and value:
            return value

    return f"HTTP {response.status_code}"


def create_verification_session() -> dict[str, Any]:
    payload = {
        "credentialDescription": verifier_setting("credential_description", []),
        "trustConfig": verifier_setting("trust_config", "trust_all"),
        "protocolConfig": verifier_setting(
            "protocol_config",
            {
                "clientIdScheme": "pre-registered",
                "responseMode": "direct_post.jwt",
            },
        ),
        "authorizationRequestType": verifier_setting("authorization_request_type", "byReference"),
    }

    response = verifier_request(
        "POST",
        str(verifier_setting("initiate_path", "/verification-session/initiate")),
        json_body=payload,
    )

    if response.status_code >= 400:
        app.logger.error(
            "Verifier initiate failed. payload=%s response=%s",
            payload,
            response.text,
        )
        raise VerifierServiceError(
            f"Verification service refused to start a verification session: {verifier_error_message(response)}"
        )

    data = parse_json_response(response)
    if "verificationSessionId" not in data or "authorization_request" not in data:
        raise VerifierServiceError("Verification service did not return a session ID and QR payload.")

    return data


def fetch_verification_session_status(verification_session_id: str) -> dict[str, Any]:
    status_path = str(
        verifier_setting(
            "status_path_template",
            "/verification-session/status/{verification_session_id}",
        )
    ).format(verification_session_id=verification_session_id)
    response = verifier_request("GET", status_path)

    if response.status_code in {404, 410}:
        app.logger.warning(
            "Verifier session expired or missing. session_id=%s status=%s response=%s",
            verification_session_id,
            response.status_code,
            response.text,
        )
        return {
            "verificationSessionStatus": "EXPIRED",
            "description": verifier_error_message(response),
            "http_status": response.status_code,
        }

    if response.status_code >= 400:
        app.logger.error(
            "Verifier status failed. session_id=%s status=%s response=%s",
            verification_session_id,
            response.status_code,
            response.text,
        )
        raise VerifierServiceError(
            f"Verification service status check failed: {verifier_error_message(response)}"
        )

    data = parse_json_response(response)
    data["http_status"] = response.status_code
    return data


def build_flag_data_url(path: Path) -> str:
    mime_type, _ = mimetypes.guess_type(path.name)
    media_type = mime_type or "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{media_type};base64,{encoded}"


def build_qr_svg(data: str) -> str:
    qr = qrcode.QRCode(border=2, box_size=12)
    qr.add_data(data)
    qr.make(fit=True)
    image = qr.make_image(image_factory=SvgPathImage)
    buffer = io.BytesIO()
    image.save(buffer)
    return buffer.getvalue().decode("utf-8")


def normalize_presented_claims(presented_claims: Any) -> dict[str, Any]:
    if not isinstance(presented_claims, dict):
        return {}

    credential_descriptions = verifier_setting("credential_description", [])
    credential_type = ""
    if isinstance(credential_descriptions, list) and credential_descriptions:
        first_description = credential_descriptions[0]
        if isinstance(first_description, dict):
            credential_type = str(first_description.get("credentialType", ""))
    candidates: list[dict[str, Any]] = [presented_claims]

    nested = presented_claims.get(credential_type)
    if isinstance(nested, dict):
        candidates.insert(0, nested)

    if len(presented_claims) == 1:
        only_value = next(iter(presented_claims.values()))
        if isinstance(only_value, dict):
            candidates.insert(0, only_value)

    interesting_keys = {
        "issuing_country",
    }
    for candidate in candidates:
        if any(key in candidate for key in interesting_keys):
            return candidate

    return presented_claims


def read_claim(claims: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in claims:
            return claims[key]
    return None


def normalize_country_value(value: Any) -> list[str]:
    values = value if isinstance(value, list) else [value]
    normalized: list[str] = []
    for item in values:
        if isinstance(item, str) and COUNTRY_CODE_PATTERN.fullmatch(item) and item in VALID_COUNTRY_CODES:
            normalized.append(item)
    return normalized


def evaluate_country_claims(claims: dict[str, Any]) -> tuple[str | None, str]:
    issuing_country = normalize_country_value(read_claim(claims, "issuing_country"))

    if not issuing_country:
        return None, "missing_issuing_country"

    country = issuing_country[0]
    if country in BLOCKED_COUNTRIES:
        return country, "blocked_country"

    return country, "allowed"


def evaluate_claims(presented_claims: Any) -> dict[str, Any]:
    claims = normalize_presented_claims(presented_claims)
    country, country_reason = evaluate_country_claims(claims)

    allowed = country_reason == "allowed"
    reason = country_reason

    return {
        "claims": claims,
        "country": country,
        "issuing_country": read_claim(claims, "issuing_country"),
        "reason": reason,
        "allowed": allowed,
    }


def load_verification_result(verification_session_id: str) -> tuple[dict[str, Any], dict[str, Any] | None]:
    status_data = fetch_verification_session_status(verification_session_id)
    if status_data.get("verificationSessionStatus") != "VERIFICATION_SUCCEEDED":
        return status_data, None

    evaluation = evaluate_claims(status_data.get("presentedClaims"))
    return status_data, evaluation


def unsuccessful_page(message: str, detail: str | None = None, status_code: int = 403) -> tuple[str, int]:
    return (
        render_template(
            "unsuccessful.html",
            message=message,
            detail=detail,
        ),
        status_code,
    )


def error_page(message: str, status_code: int = 502) -> tuple[str, int]:
    return unsuccessful_page("Authentication was unsuccessful.", message, status_code)


def reason_message(reason: str, evaluation: dict[str, Any]) -> tuple[str, str | None]:
    country = evaluation.get("country") or "??"
    if reason == "missing_issuing_country":
        return "Access was not granted.", "The wallet credential did not disclose an issuing country."
    if reason == "blocked_country":
        return "Access was not granted.", f"The issuing country ({country}) is not on the allowlist yet."
    return "Access was not granted.", None


@app.after_request
def add_security_headers(response: Response) -> Response:
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["X-Robots-Tag"] = "noindex, nofollow"
    return response


@app.get("/")
@app.get("/flag")
def index() -> str:
    title = str(SITE.get("title", "Global Flag Access"))
    subtitle = str(
        SITE.get(
            "subtitle",
            "Anyone with the official EUDI wallet can reveal the flag.",
        )
    )

    return render_template(
        "index.html",
        title=title,
        subtitle=subtitle,
    )


@app.post("/flag")
def start_verification() -> str | tuple[str, int]:
    try:
        session_data = create_verification_session()
    except VerifierServiceError as exc:
        app.logger.error("Could not start verification session: %s", exc)
        return error_page(str(exc))

    return render_template(
        "verify.html",
        qr_svg=build_qr_svg(str(session_data["authorization_request"])),
        verification_session_id=str(session_data["verificationSessionId"]),
    )


@app.get("/verification-session/<verification_session_id>/status")
def verification_status(verification_session_id: str) -> Response:
    try:
        status_data, evaluation = load_verification_result(verification_session_id)
    except VerifierServiceError as exc:
        app.logger.error("Could not fetch verification status: %s", exc)
        return jsonify({"status": "SERVICE_ERROR", "description": str(exc)}), 502

    status = str(status_data.get("verificationSessionStatus", "UNKNOWN"))
    http_status = int(status_data.get("http_status", 200))

    if status == "VERIFICATION_SUCCEEDED" and evaluation is not None:
        endpoint = "flag_result" if evaluation["allowed"] else "unsuccessful_result"
        return jsonify(
            {
                "status": status,
                "redirectUrl": url_for(endpoint, verification_session_id=verification_session_id),
            }
        )

    if status == "VERIFICATION_FAILED":
        return jsonify(
            {
                "status": status,
                "redirectUrl": url_for("unsuccessful_result", verification_session_id=verification_session_id),
            }
        )

    if status == "EXPIRED":
        return jsonify(
            {
                "status": status,
                "redirectUrl": url_for("unsuccessful_result", verification_session_id=verification_session_id),
            }
        ), http_status

    return jsonify({"status": "IN_PROGRESS"})


@app.get("/flag/<verification_session_id>")
def flag_result(verification_session_id: str) -> str | tuple[str, int]:
    try:
        status_data, evaluation = load_verification_result(verification_session_id)
    except VerifierServiceError as exc:
        app.logger.error("Could not load verification result: %s", exc)
        return error_page(str(exc))

    if status_data.get("verificationSessionStatus") != "VERIFICATION_SUCCEEDED" or evaluation is None:
        return error_page("Verification has not completed yet.", 409)

    if not evaluation["allowed"]:
        title, detail = reason_message(str(evaluation["reason"]), evaluation)
        return unsuccessful_page(title, detail)

    if not FLAG_IMAGE.is_file():
        app.logger.error("Configured flag image does not exist: %s", FLAG_IMAGE)
        return error_page("Flag image is not configured.", 500)

    return render_template(
        "flag.html",
        image_src=build_flag_data_url(FLAG_IMAGE),
        country=evaluation["country"],
    )


@app.get("/unsuccessful/<verification_session_id>")
def unsuccessful_result(verification_session_id: str) -> tuple[str, int]:
    try:
        status_data, evaluation = load_verification_result(verification_session_id)
    except VerifierServiceError as exc:
        app.logger.error("Could not load unsuccessful result: %s", exc)
        return error_page(str(exc))

    status = str(status_data.get("verificationSessionStatus"))
    if status == "VERIFICATION_SUCCEEDED" and evaluation is not None:
        title, detail = reason_message(str(evaluation["reason"]), evaluation)
        return unsuccessful_page(title, detail)
    if status in {"VERIFICATION_FAILED", "EXPIRED"}:
        description = str(status_data.get("description", "Authentication did not complete successfully."))
        return unsuccessful_page("Authentication was unsuccessful.", description)
    return error_page("Verification has not completed yet.", 409)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)
