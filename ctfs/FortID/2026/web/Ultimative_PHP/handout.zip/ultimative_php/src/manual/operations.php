<section class="manual">
    <p class="eyebrow">Operations manual · revision 4.7</p>
    <h2>One request. Every proof.</h2>
    <p>
        The migration gateway accepts recovery answers, an administrative
        access assertion, a compatibility code, and a portable legacy profile.
        All fields must validate in the same request.
    </p>
    <dl>
        <div><dt>Recovery</dt><dd>Two distinct answers with matching fingerprints</dd></div>
        <div><dt>Access</dt><dd>The protected administrator access level</dd></div>
        <div><dt>Compatibility</dt><dd>A code accepted by both legacy hash formats</dd></div>
        <div><dt>Profile</dt><dd>A Base64url-encoded PHP profile export</dd></div>
    </dl>
    <a class="button secondary" href="/">Return to the gateway</a>
</section>

