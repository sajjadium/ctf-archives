import os
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import urlsplit

from flask import Flask, abort, jsonify, render_template, session

from common import configure, csrf_check, origin, qr_data, required
from fortid import FortID, FortIDError


def authorized(result):
    claims = result.get("presentedClaims")
    return (result.get("verificationSessionStatus") == "VERIFICATION_SUCCEEDED"
            and isinstance(claims, dict)
            and claims.get("admin") is True)


def create_app(config=None, fortid=None):
    app = Flask(__name__)
    cfg = config if config is not None else {
        "origin": origin("VERIFIER_ORIGIN"),
        "issuer_origin": origin("ISSUER_ORIGIN"),
        "secret": required("VERIFIER_SESSION_SECRET"),
        "credential_type": required("FORTID_CREDENTIAL_TYPE"),
        "trust_config": os.environ.get("FORTID_TRUST_CONFIG", "pinned"),
        "flag": (os.environ.get("FLAG", "").strip()
                 or Path(required("FLAG_FILE")).read_text().strip()),
    }
    same_host = urlsplit(cfg["origin"]).hostname == urlsplit(cfg["issuer_origin"]).hostname
    local_test = os.environ.get("ALLOW_HTTP_LOCAL") == "1" and urlsplit(cfg["origin"]).hostname == "localhost"
    if same_host and not local_test:
        raise RuntimeError("Issuer and verifier hostnames must differ")
    trust_mode = cfg.get("trust_config", "pinned")
    if trust_mode != "pinned":
        raise RuntimeError("Only pinned issuer trust is supported")
    cfg["certificate"] = cfg.get("certificate") or Path(required("FORTID_TRUST_ANCHOR_FILE")).read_text()
    if "-----BEGIN CERTIFICATE-----" not in cfg["certificate"]:
        raise RuntimeError("An issuer-exclusive PEM trust anchor is required")
    configure(app, cfg["origin"], "king_verifier", cfg["secret"])
    api = fortid or FortID(origin("FORTID_VERIFIER_BASE_URL"), required("FORTID_VERIFIER_API_KEY"))
    sessions = {}
    lock = threading.Lock()

    @app.after_request
    def csp(response):
        response.headers["Content-Security-Policy"] = (
            "default-src 'none'; script-src 'self'; style-src 'self'; "
            "img-src 'self' data:; connect-src 'self'; base-uri 'none'; "
            "form-action 'self'; frame-ancestors 'none'"
        )
        return response

    @app.get("/")
    def index():
        return render_template("verifier.html", issuer_origin=cfg["issuer_origin"])

    @app.post("/api/login")
    def login():
        csrf_check(cfg["origin"])
        try:
            sid, uri = api.verify(cfg["credential_type"], cfg["certificate"])
            qr = qr_data(uri)
        except FortIDError:
            return jsonify(error="Verification is unavailable. Please try again."), 502
        handle = secrets.token_urlsafe(32)
        now = time.monotonic()
        with lock:
            # Local login retention only; FortID controls protocol expiry.
            for key in list(sessions):
                if now - sessions[key]["created"] > 3600:
                    del sessions[key]
            sessions.pop(session.get("login"), None)
            sessions[handle] = {"sid": sid, "created": now, "status": "IN_PROGRESS",
                                "checked": 0}
        session["login"] = handle
        return jsonify(qr=qr, authorization_request=uri)

    @app.get("/api/login/status")
    def status():
        # No caller-supplied FortID session ID is accepted.
        with lock:
            login = sessions.get(session.get("login"))
            if not login or time.monotonic() - login["created"] > 3600:
                abort(404)
            if login["status"] == "IN_PROGRESS" and time.monotonic() - login["checked"] >= 5:
                try:
                    result = api.status(login["sid"])
                except FortIDError as exc:
                    if exc.status in {404, 410}:
                        login["status"] = "EXPIRED"
                    else:
                        return jsonify(error="Status check unavailable. Please retry."), 502
                else:
                    upstream_status = result.get("verificationSessionStatus")
                    if authorized(result):
                        login["status"] = "AUTHORIZED"
                    elif upstream_status != "IN_PROGRESS":
                        login["status"] = "DENIED"
                login["checked"] = time.monotonic()
            response = {"status": login["status"]}
            if login["status"] == "AUTHORIZED":
                response["flag"] = cfg["flag"]
        return jsonify(response)

    @app.get("/healthz")
    def health():
        return "ok"

    return app
