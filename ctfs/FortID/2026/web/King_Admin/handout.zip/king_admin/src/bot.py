"""Internal worker. Never exposes its browser debugger or accepts target URLs."""
import os
import secrets
import threading

from flask import Flask, abort, jsonify, request
from playwright.sync_api import sync_playwright


def create_app():
    app = Flask(__name__)
    issuer = os.environ["ISSUER_ORIGIN"].rstrip("/")
    secret = os.environ["BOT_SECRET"]
    wait_ms = int(os.environ.get("BOT_WAIT_SECONDS", "30")) * 1000
    if not 1000 <= wait_ms <= 300000:
        raise RuntimeError("BOT_WAIT_SECONDS must be between 1 and 300")
    lock = threading.Lock()
    state = {"status": "IDLE", "running": False}

    def set_status(value):
        with lock:
            state["status"] = value

    def run():
        try:
            with sync_playwright() as p:
                # Keep Chromium's sandbox enabled. See deploy/README.md for
                # host user-namespace/seccomp requirements.
                browser = p.chromium.launch(chromium_sandbox=True)
                context = browser.new_context(service_workers="block")
                auth = {"Authorization": "Bearer " + secret}
                try:
                    response = context.request.post(issuer + "/internal/bot/login",
                                                    headers=auth, max_redirects=0)
                    if response.status != 200:
                        raise RuntimeError("Bot authentication failed")
                    page = context.new_page()
                    page.set_default_timeout(30000)
                    page.goto(issuer + "/admin", wait_until="domcontentloaded")
                    page.locator("#issue").click()
                    page.wait_for_selector("#offer[data-ready='true']", timeout=45000)
                    set_status("WAITING_FOR_SCAN")
                    # The browser never scans or redeems. Closing it does not
                    # invalidate the offer held by FortID.
                    page.wait_for_timeout(wait_ms)
                    set_status("DONE")
                finally:
                    try:
                        context.request.post(issuer + "/internal/bot/logout",
                                             headers=auth, max_redirects=0, timeout=5000)
                    finally:
                        context.close()
                        browser.close()
        except Exception:
            # Do not include console output, page URLs, offers, or cookies.
            app.logger.error("Admin browser run failed")
            set_status("FAILED")
        finally:
            with lock:
                state["running"] = False

    @app.before_request
    def authenticate():
        if request.path != "/healthz" and not secrets.compare_digest(
                request.headers.get("Authorization", ""), "Bearer " + secret):
            abort(403)

    @app.post("/run")
    def start():
        with lock:
            if state["running"]:
                return jsonify(status=state["status"]), 409
            state.update(running=True, status="STARTING")
        threading.Thread(target=run, daemon=True).start()
        return jsonify(status="STARTING"), 202

    @app.get("/status")
    def status():
        with lock:
            return jsonify(status=state["status"])

    @app.get("/healthz")
    def health():
        return "ok"

    return app
