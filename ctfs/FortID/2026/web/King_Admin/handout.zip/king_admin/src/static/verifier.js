const button = document.querySelector('#login');
const statusLine = document.querySelector('#login-status');
let polling;
async function check() {
  try {
    const response = await fetch('/api/login/status');
    if (!response.ok) {
      if (response.status === 404) { clearInterval(polling); button.disabled = false; }
      statusLine.textContent = 'Unable to check this login. Retry or generate a new QR.';
      return;
    }
    const data = await response.json();
    if (data.status === 'IN_PROGRESS') return;
    clearInterval(polling);
    button.disabled = false;
    document.querySelector('#presentation').hidden = true;
    if (data.status === 'AUTHORIZED') {
      statusLine.textContent = 'Welcome, Your Majesty.';
      const flag = document.querySelector('#flag');
      flag.textContent = data.flag;
      flag.hidden = false;
    } else {
      statusLine.textContent = data.status === 'EXPIRED' ? 'This login expired. Generate a new QR.' : 'Entry denied. A valid royal administrator credential is required.';
    }
  } catch { statusLine.textContent = 'Connection interrupted. Retrying…'; }
}
button.addEventListener('click', async () => {
  button.disabled = true;
  clearInterval(polling);
  document.querySelector('#flag').hidden = true;
  document.querySelector('#presentation').hidden = true;
  statusLine.textContent = 'Preparing your login…';
  try {
    const response = await fetch('/api/login', {
      method: 'POST', headers: {'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content}
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    document.querySelector('#login-qr').src = data.qr;
    document.querySelector('#wallet-link').href = data.authorization_request;
    document.querySelector('#presentation').hidden = false;
    statusLine.textContent = 'Scan the QR and approve the presentation in your wallet.';
    polling = setInterval(check, 5500);
  } catch (error) { statusLine.textContent = error.message; button.disabled = false; }
});
