"""FortID production Control API adapter, based on the published guides."""
from urllib.parse import quote, unquote, urlsplit

import requests


class FortIDError(Exception):
    def __init__(self, status=502):
        self.status = status
        super().__init__("FortID request failed")


def wallet_uri(value, scheme):
    if not isinstance(value, str) or not value or len(value) > 16000:
        raise FortIDError()
    # The issuance guide shows an outer URL-encoded URI. Decode only that
    # wrapper, never percent-encoding inside an already valid wallet URI.
    if not value.startswith(scheme + ":"):
        value = unquote(value)
    if urlsplit(value).scheme != scheme:
        raise FortIDError()
    return value


class FortID:
    def __init__(self, base_url, api_key):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def call(self, method, path, body=None):
        try:
            response = requests.request(
                method, self.base_url + path,
                headers={"X-API-KEY": self.api_key}, json=body,
                timeout=(5, 20), allow_redirects=False,
            )
            if response.status_code != 200:
                raise FortIDError(response.status_code)
            result = response.json()
            if not isinstance(result, dict):
                raise FortIDError()
            return result
        except (requests.RequestException, ValueError) as exc:
            raise FortIDError() from exc

    def issue(self, issuer_id, configuration_id, claims):
        result = self.call("POST", f"/control/issuer/{quote(issuer_id, safe='')}/initiate", {
            "credentialData": {
                "credentialConfigurationId": configuration_id,
                "claims": claims,
            },
            "protocolConfig": {"grant_type": "PreAuthorizedCodeWithoutTxCode"},
        })
        if not isinstance(result.get("sessionId"), str) or not result["sessionId"]:
            raise FortIDError()
        # A PIN response indicates a provisioning/API mismatch; fail closed.
        auth = result.get("authCodeOrPreAuth", {})
        if not isinstance(auth, dict) or auth.get("tx_code"):
            raise FortIDError()
        return wallet_uri(result.get("credentialOfferUri"), "openid-credential-offer")

    def verify(self, credential_type, trust_certificate):
        trust_config = "trust_all" if not trust_certificate else [{"type": "x5chain_root", "cert": trust_certificate}]
        result = self.call("POST", "/verification-session/initiate", {
            "credentialDescription": {
                "credentialType": credential_type,
                "credentialFormat": "dc+sd-jwt",
                # `iss` and `vct` are SD-JWT metadata, not claim paths;
                # request only the application claim.
                "disclosurePaths": [["admin"]],
            },
            "trustConfig": trust_config,
            "authorizationRequestType": "byReference",
        })
        sid = result.get("verificationSessionId")
        if not isinstance(sid, str) or not sid or len(sid) > 200:
            raise FortIDError()
        return sid, wallet_uri(result.get("authorization_request"), "openid4vp")

    def status(self, sid):
        return self.call("GET", "/verification-session/status/" + quote(sid, safe=""))
