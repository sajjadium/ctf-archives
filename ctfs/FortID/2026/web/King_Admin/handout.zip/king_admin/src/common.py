"""Shared configuration and HTTP behavior; no production secrets in source."""
import base64
import io
import os
import secrets
from urllib.parse import urlsplit

import qrcode
from qrcode.image.pure import PyPNGImage
from flask import abort, request, session


def required(name):
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"Missing configuration: {name}")
    return value


def origin(name):
    value = required(name).rstrip("/")
    parsed = urlsplit(value)
    if (parsed.scheme not in {"http", "https"} or not parsed.hostname
            or parsed.username or parsed.password or parsed.path
            or parsed.query or parsed.fragment):
        raise RuntimeError(f"{name} must be an HTTP(S) origin without a path")
    if parsed.scheme != "https" and os.environ.get("ALLOW_HTTP_LOCAL") != "1":
        raise RuntimeError(f"{name} requires HTTPS (HTTP is for local tests only)")
    return value


def configure(app, public_origin, cookie_name, secret):
    app.config.update(
        SECRET_KEY=secret,
        MAX_CONTENT_LENGTH=24 * 1024,
        SESSION_COOKIE_NAME=cookie_name,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SECURE=public_origin.startswith("https://"),
        SESSION_COOKIE_SAMESITE="Strict",
        SESSION_COOKIE_DOMAIN=None,
    )

    @app.after_request
    def headers(response):
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["X-Frame-Options"] = "DENY"
        return response

    @app.context_processor
    def csrf_context():
        if "csrf" not in session:
            session["csrf"] = secrets.token_urlsafe(32)
        return {"csrf_token": session["csrf"]}


def csrf_check(public_origin):
    # Origin checking also rejects same-site requests from the other portal.
    request_origin = request.headers.get("Origin")
    if request_origin is None:
        # Some browsers omit Origin on same-origin HTML form POSTs. The
        # Referer still carries the complete origin in that case.
        referer = request.headers.get("Referer", "")
        parsed = urlsplit(referer)
        request_origin = f"{parsed.scheme}://{parsed.netloc}" if parsed.scheme and parsed.netloc else ""
    allowed_internal = os.environ.get("ALLOW_HTTP_LOCAL") == "1" and request_origin == "http://issuer:8000"
    if request_origin != public_origin and not allowed_internal:
        abort(403)
    provided = request.headers.get("X-CSRF-Token") or request.form.get("csrf", "")
    expected = session.get("csrf")
    if not expected or not secrets.compare_digest(provided, expected):
        abort(403)


def qr_data(uri):
    output = io.BytesIO()
    qrcode.make(uri, image_factory=PyPNGImage).save(output)
    return "data:image/png;base64," + base64.b64encode(output.getvalue()).decode()
