const run = document.querySelector('#run-bot');
const statusLine = document.querySelector('#bot-status');
const labels = {
  IDLE: 'Ready when you are.', STARTING: 'The King is on his way…',
  WAITING_FOR_SCAN: 'The King’s credential QR is ready for scanning.',
  DONE: 'The King has left the page. The offer remains available until it expires.',
  FAILED: 'The royal visit failed. Check the setup and try again.'
};
let poll;
async function update() {
  try {
    const response = await fetch('/api/bot/status');
    const data = await response.json();
    statusLine.textContent = data.error || labels[data.status] || 'Waiting…';
    run.disabled = ['STARTING', 'WAITING_FOR_SCAN'].includes(data.status);
    if (!run.disabled) clearInterval(poll);
  } catch { statusLine.textContent = 'Unable to reach the attendant. Please retry.'; run.disabled = false; clearInterval(poll); }
}
run.addEventListener('click', async () => {
  run.disabled = true;
  try {
    const response = await fetch('/api/bot/run', {
      method: 'POST', headers: {'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content}
    });
    const data = await response.json();
    if (!response.ok && response.status !== 409) throw new Error(data.error);
    statusLine.textContent = labels[data.status] || 'Waiting…';
    clearInterval(poll);
    poll = setInterval(update, 2000);
  } catch (error) { statusLine.textContent = error.message; run.disabled = false; }
});
document.querySelector('#user-badge-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const status = document.querySelector('#user-status');
  const button = event.target.querySelector('button');
  button.disabled = true;
  status.textContent = 'Preparing your badge…';
  try {
    const response = await fetch('/api/user/offer', {
      method: 'POST',
      headers: {'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content,
                'Content-Type': 'application/x-www-form-urlencoded'},
      body: new URLSearchParams(new FormData(event.target))
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    document.querySelector('#user-qr').src = data.qr;
    document.querySelector('#user-link').href = data.offer_uri;
    document.querySelector('#user-offer').hidden = false;
    status.textContent = 'Ready. Scan with your wallet to collect.';
  } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
});
