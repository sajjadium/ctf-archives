document.querySelector('#issue').addEventListener('click', async () => {
  const button = document.querySelector('#issue');
  const status = document.querySelector('#issue-status');
  button.disabled = true;
  status.textContent = 'Preparing your credential…';
  try {
    const response = await fetch('/api/admin/offer', {
      method: 'POST', headers: {'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content}
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    document.querySelector('#offer-qr').src = data.qr;
    const offer = document.querySelector('#offer');
    offer.hidden = false;
    offer.dataset.ready = 'true';
    status.textContent = 'Ready. Scan with your wallet to collect.';
  } catch (error) { status.textContent = error.message; button.disabled = false; }
});
