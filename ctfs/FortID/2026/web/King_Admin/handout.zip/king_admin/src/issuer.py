import json
import hashlib
import os
import re
import secrets
import threading
from urllib.parse import urlsplit

import requests
from flask import Flask, abort, jsonify, redirect, render_template, request, session

from common import configure, csrf_check, origin, qr_data, required
from fortid import FortID, FortIDError

HINT_MESSAGES = [
    "Hello, today is a very nice day. Have fun!",
    "A careful look at the page source may reveal something useful.",
    "Small details can make a big difference.",
    "The browser trusts some scripts more than others.",
    "Not every visible element is only decoration.",
    "Read the page carefully before interacting with it.",
    "Sometimes the answer is hidden in plain sight.",
    "The server may know more than the interface shows.",
    "Try to understand how this page is assembled.",
    "A little persistence can unlock unexpected results.",
]


def create_app(config=None, fortid=None):
    app = Flask(__name__)
    cfg = config if config is not None else {
        "origin": origin("ISSUER_ORIGIN"),
        "verifier_origin": origin("VERIFIER_ORIGIN"),
        "secret": required("ISSUER_SESSION_SECRET"),
        "bot_secret": required("BOT_SECRET"),
        "bot_url": os.environ.get("BOT_URL", "http://bot:8000"),
        "issuer_id": required("FORTID_ISSUER_ID"),
        "configuration_id": required("FORTID_CREDENTIAL_CONFIGURATION_ID"),
        "claims": json.loads(os.environ.get("FORTID_EXTRA_CLAIMS", "{}")),
    }
    same_host = urlsplit(cfg["origin"]).hostname == urlsplit(cfg["verifier_origin"]).hostname
    local_test = os.environ.get("ALLOW_HTTP_LOCAL") == "1" and urlsplit(cfg["origin"]).hostname == "localhost"
    if same_host and not local_test:
        raise RuntimeError("Issuer and verifier hostnames must differ")
    if not isinstance(cfg["claims"], dict):
        raise RuntimeError("FORTID_EXTRA_CLAIMS must be a JSON object")
    configure(app, cfg["origin"], "king_issuer", cfg["secret"])
    api = fortid or FortID(origin("FORTID_ISSUER_BASE_URL"), required("FORTID_ISSUER_API_KEY"))
    lock = threading.Lock()
    state = {"announcement": "<p>Welcome, Your Majesty. Your new credential is ready to collect.</p>",
             "admin_tokens": set()}

    def admin():
        with lock:
            valid = session.get("admin_token") in state["admin_tokens"]
        if not valid:
            abort(403)

    def bot_auth():
        if not secrets.compare_digest(request.headers.get("Authorization", ""),
                                      "Bearer " + cfg["bot_secret"]):
            abort(403)

    def bot_call(path):
        try:
            response = requests.request(
                "POST" if path == "/run" else "GET", cfg["bot_url"] + path,
                headers={"Authorization": "Bearer " + cfg["bot_secret"]},
                timeout=(3, 5), allow_redirects=False,
            )
            if response.status_code not in {200, 202, 409}:
                raise ValueError("Unexpected bot response")
            payload = response.json()
            return jsonify(status=payload["status"]), response.status_code
        except (requests.RequestException, ValueError, KeyError):
            return jsonify(error="The royal attendant is unavailable. Please try again."), 503

    @app.get("/")
    def index():
        with lock:
            announcement = state["announcement"]
        return render_template("issuer.html", announcement=announcement,
                               verifier_origin=cfg["verifier_origin"])

    @app.get("/announcement")
    def announcement_page():
        return redirect("/")

    @app.post("/announcement")
    def announcement():
        value = request.form.get("announcement", "")
        if len(value.encode()) > 16000:
            abort(400)
        value = re.sub(r"\s+on[a-z]+\s*=\s*(?:\"[^\"]*\"|'[^']*'|[^\s>]+)", "",
                       value, flags=re.IGNORECASE)
        with lock:
            state["announcement"] = value
        return redirect("/", code=303)

    @app.post("/api/bot/run")
    def run_bot():
        csrf_check(cfg["origin"])
        return bot_call("/run")

    @app.get("/api/bot/status")
    def bot_status():
        return bot_call("/status")

    @app.post("/internal/bot/login")
    def bot_login():
        bot_auth()
        session.clear()
        token = secrets.token_urlsafe(32)
        with lock:
            state["admin_tokens"] = {token}
        session["admin_token"] = token
        return jsonify(ok=True)

    @app.post("/internal/bot/logout")
    def bot_logout():
        bot_auth()
        with lock:
            state["admin_tokens"].clear()
        session.clear()
        return jsonify(ok=True)

    @app.get("/admin")
    def dashboard():
        admin()
        with lock:
            announcement = state["announcement"]
        message = secrets.choice(HINT_MESSAGES)
        hint_script = (
            "const banner=document.createElement('div');"
            f"banner.textContent={json.dumps(message)};"
            "banner.style.cssText='position:fixed;top:0;left:0;right:0;"
            "padding:12px;background:#ffe08a;color:#111;z-index:9999;"
            "text-align:center';document.body.prepend(banner);"
        )
        nonce = hashlib.sha256(hint_script.encode()).hexdigest()[:6]
        response = render_template("admin.html", announcement=announcement,
                                   hint_script=hint_script, csp_nonce=nonce)
        response = app.make_response(response)
        response.headers["Content-Security-Policy"] = (
            f"default-src 'none'; script-src 'self' 'nonce-{nonce}'; "
            "style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
            "connect-src 'self' http://host.docker.internal:9000;"
        )
        return response

    @app.post("/api/admin/offer")
    def offer():
        admin()
        csrf_check(cfg["origin"])
        # Client input never contributes claims, issuer IDs, or API options.
        claims = {**cfg["claims"], "admin": True}
        try:
            uri = api.issue(cfg["issuer_id"], cfg["configuration_id"], claims)
            return jsonify(offer_uri=uri, qr=qr_data(uri))
        except FortIDError:
            return jsonify(error="Credential issuance is unavailable. Please try again."), 502

    @app.post("/api/user/offer")
    def user_offer():
        csrf_check(cfg["origin"])
        first_name = request.form.get("first_name", "").strip()
        last_name = request.form.get("last_name", "").strip()
        if (not first_name or not last_name or len(first_name) > 80 or len(last_name) > 80
                or any(ord(ch) < 32 for ch in first_name + last_name)):
            return jsonify(error="Enter a valid first and last name."), 400
        try:
            # Deliberately hardcoded: request data can never elevate this badge.
            uri = api.issue(cfg["issuer_id"], cfg["configuration_id"], {
                "first_name": first_name,
                "last_name": last_name,
                "admin": False,
            })
            return jsonify(offer_uri=uri, qr=qr_data(uri))
        except FortIDError:
            return jsonify(error="Credential issuance is unavailable. Please try again."), 502

    @app.get("/healthz")
    def health():
        return "ok"

    return app
