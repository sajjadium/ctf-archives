# King Admin

The treasury opens only for a royal administrator.
Use your team's issuer and verifier URLs and the FortID wallet app for Android or iOS.

## Run locally

This archive supplies the service source. Dedicated FortID configuration is
provided by the hosted challenge, not included in this handout. To run a
local instance after obtaining that configuration:

```sh
cp deploy/.env.example deploy/.env
# Edit deploy/.env and set the public origins, FortID identifiers, keys,
# and independent session/Bot secrets.
docker compose --env-file deploy/.env -f deploy/compose.yml up --build
```

The issuer is exposed on the configured issuer port (8081 by default)
and the verifier on the configured verifier port (8082 by default).
Use the hosted challenge URLs when running against the competition
instance; the wallet app and a reachable HTTPS bot origin are required.

The service is available at `http://127.0.0.1:8080`.
