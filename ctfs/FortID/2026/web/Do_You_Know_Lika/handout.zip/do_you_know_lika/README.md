# Do You Know Lika?

The Lika Tourist Board has launched a postcard designer for visitors who think
they know the region. Pick a theme, fill in the postcard data, and let a fresh
print worker process prepare a preview.

Can you print the ranger's secret?

Run the supplied source locally with:

```bash
docker build -t do-you-know-lika -f deploy/Dockerfile .
docker run --rm -p 8080:8080 \
  --read-only \
  --tmpfs /tmp:rw,noexec,nosuid,nodev,size=16m \
  --cap-drop ALL \
  --security-opt no-new-privileges:true \
  --memory 128m --cpus 0.5 --pids-limit 48 \
  -e 'FLAG=FortID{redacted}' \
  do-you-know-lika
```

The service is available at `http://127.0.0.1:8080`.
