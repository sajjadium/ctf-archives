FLAG = b"<REDACTED>"
MASK = bytes.fromhex("<REDACTED>")
