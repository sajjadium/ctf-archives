#include <stdio.h>
#include <string.h>
#include <stdbool.h>

char* levels[2];

int width = 8;
int height = 8;

void ignore_me_init_buffering()
{
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}


void print_field(char** rows){
    printf("\t | ");
    for(int o = 0; o < width; o++){
        printf("%02hhx | ", o);
    }
    printf("\n\n\t -----------------------------------------");
    for(int i = 0; i < height; i++){
        printf("\n%d\t | ", i);
        for(int o = 0; o < width; o++){
            printf("%02hhx | ", rows[i][o]);
        }
    }
    printf("\n");
}

bool has256(char* field, int fieldsize){
    for(int i = 0; i < fieldsize; i++){
        if(field[i] == '\xff'){
            return true;
        }
    }
    return false;
}

int main(int argc, char** argv){


    char* levels[2];
    ignore_me_init_buffering();

    levels[0] = "\x07\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02\x06\x02";    
    levels[1] = "\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80\x01\x02\x04\x08\x10\x20\x40\x80";

    puts("Hey, I made a little game, wanna play? \nYou just need to combine numbers to make 255! \nI wanna build more levels, but for now you just get two :3");
    
    int fieldsize = width*height;
    char* rows[height];
    char field[fieldsize];
    memcpy(field, levels[0], fieldsize);
    for(int i = 0; i<height; i++){
        rows[i] = &field[i*8];
    }

    while(1){
        if(!has256(field, fieldsize)){
            print_field(rows);
            puts("Make your move!");
            puts("Move block in coordinates (format is x, y)");
            printf("==> ");
            int x, y;
            scanf("%d, %d", &x, &y);

            if(!(0<=x && x<width)){
                printf("please select valid x coordinates\n");
                break;
            }
            if(!(0<=y && y<width)){
                printf("please select valid y coordinates\n");
                break;
            }

            printf("selected coordinates are %d, %d\n", x, y);
            puts("move in direction (up, down, left, right)");
            printf("==> ");
            char direction[8];
            scanf("%6s", &direction);

            printf("direction recieved: %s\n", &direction);

            switch(direction[0]){
                case 'u':
                    rows[y-1][x] += rows[y][x];
                    rows[y][x] = 0;
                    break;
                case 'd':
                    rows[y+1][x] += rows[y][x];
                    rows[y][x] = 0;
                    break;
                case 'l':
                    rows[y][x-1] += rows[y][x];
                    rows[y][x] = 0;
                    break;
                case 'r':
                    rows[y][x+1] += rows[y][x];
                    rows[y][x] = 0;
                    break;
                case 'q':
                    return 0;
                default:
                    printf("invalid selection\n");
            }
            
        }else{
            print_field(rows);
            puts("Success! You Progressed to the next level!");
            memcpy(field, levels[1], fieldsize);
        }
    }
}
