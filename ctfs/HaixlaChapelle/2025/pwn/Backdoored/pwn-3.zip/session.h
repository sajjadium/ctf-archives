#ifndef _KVS_SESSION_H
#define _KVS_SESSION_H

struct Session {
    char* username;
};

int session_login         (struct Session *session, const char *username, const char *passwd);
int session_createAccount (struct Session *session, const char *username, const char *passwd);
int session_changePassword(struct Session *session, const char *old_passwd, const char *new_passwd);
int session_changeUsername(struct Session *session, const char *new_username);

#endif
