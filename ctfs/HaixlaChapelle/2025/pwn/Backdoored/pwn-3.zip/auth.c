#include <string.h>
#include <openssl/sha.h>
#include <openssl/rand.h>

#include "auth.h"

/**
 * Generates a SHA-256 hash of salt + password. Assumes that the first
 * KVS_PWD_SALT_LEN bytes of buffer contain the salt. The hash is written
 * to (buffer + KVS_PWD_SALT_LEN). Thus the buffer must be of size
 * KVS_PWD_LEN
 */
static int hashWithSalt(const char* password, unsigned char* buffer) {
    SHA256_CTX ctx;
    if (!SHA256_Init(&ctx)) return -1;
    if (!SHA256_Update(&ctx, buffer, KVS_PWD_SALT_LEN)) return -1;
    if (!SHA256_Update(&ctx, password, strlen(password))) return -1;
    if (!SHA256_Final(buffer + KVS_PWD_SALT_LEN, &ctx)) return -1;
    return 0;
}

int digestPassword(const char* password, unsigned char* buffer) {
    // Generate salt
    if (!RAND_bytes(buffer, KVS_PWD_SALT_LEN)) return -1;

    // digest the password
    if (hashWithSalt(password, buffer)) return -1;

    return 0;
}

int validatePassword(const char* password, const unsigned char* stored_digest) {
    unsigned char new_digest[KVS_PWD_LEN];

    // Copy Salt into new digest, then compute new digest
    memcpy(new_digest, stored_digest, KVS_PWD_SALT_LEN);
    if (hashWithSalt(password, new_digest)) return -1;

    return memcmp(new_digest, stored_digest, KVS_PWD_LEN);
}
