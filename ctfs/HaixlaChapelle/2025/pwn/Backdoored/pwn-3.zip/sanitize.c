#include <regex.h>
#include <string.h>

#include "sanitize.h"

int sanitizeStr(const char* string) {
    // Invalid: NULL or empty
    if (!string || *string == '\0' || strnlen(string, KVS_LEN_VAL) > KVS_LEN_VAL) {
        return 1;
    }

    // Static regex to validate allowed characters
    static int regex_inited = 0;
    static regex_t regex;
    if (!regex_inited) {
        if (regcomp(&regex, "^.?[A-Za-z0-9_-][A-Za-z0-9_ .-]*$", REG_EXTENDED) != 0) {
            return 1;
        }
        regex_inited = 1;
    }

    return regexec(&regex, string, 0, NULL, 0) != 0;
}
