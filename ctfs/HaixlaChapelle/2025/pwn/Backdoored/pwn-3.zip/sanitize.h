#ifndef _KVS_SANITIZE_H
#define _KVS_SANITIZE_H

// In each path, we have a username (and maybe a key)
// This is an generous upper bound
#define KVS_LEN_PATH 228
#define KVS_LEN_VAL  64

int sanitizeStr(const char* string);

#endif
