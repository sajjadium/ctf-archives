#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

#include "session.h"
#include "session_io.h"
#include "sanitize.h"
#include "auth.h"

/**
 * Given a user, validate the username to be valid and return the path to the
 * password file
 */
static int get_path_for_passwd(char* buffer, const char* username) {
    if (sanitizeStr(username) || strlen(username) > KVS_LEN_VAL)
        return -1;
    snprintf(buffer, KVS_LEN_PATH, "./%s/.passwd", username);
    return 0;
}

int session_login(struct Session *session, const char *username, const char *passwd) {
    char filepath[KVS_LEN_PATH];

    // Validate username and get password file path
    if (get_path_for_passwd(filepath, username))
        return KVS_USER_INVALID;

    // Check if file does not exists
    if (access(filepath, F_OK)) {
        return KVS_USER_INVALID;
    }

    // Open the password hash for reading; This should always succeed
    FILE* f = fopen(filepath, "r");
    if (!f)
        return KVS_ERR_INTERNAL;

    // Read the stored password; This should always succeed
    unsigned char stored_digest[KVS_PWD_LEN];
    if (fread(stored_digest, KVS_PWD_LEN, 1, f) != 1) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }        
    fclose(f);

    // Check if password is valid
    if (validatePassword(passwd, stored_digest))
        return KVS_USER_INVALID;
    
    // Create new session
    session->username = malloc(strlen(username)+1);
    strcpy(session->username, username);
    return 0;
}

int session_createAccount(struct Session *session, const char *username, const char *passwd) {
    char filepath[KVS_LEN_PATH];

    // Validate username and get password file path
    if (get_path_for_passwd(filepath, username))
        return KVS_USER_INVALID;

    // Check if file already exists
    if (!access(filepath, F_OK)) {
        return KVS_USER_EXISTS;
    }

    // Create user directories
    char dirpath[KVS_LEN_PATH];
    snprintf(dirpath, KVS_LEN_PATH, "./%s", username);
    mkdir(dirpath, S_IRWXU);
    snprintf(dirpath, KVS_LEN_PATH, "./%s/.snapshots", username);
    mkdir(dirpath, S_IRWXU);

    // Open the password hash for writing; This should always succeed
    FILE* f = fopen(filepath, "w");
    if (!f)
        return KVS_ERR_INTERNAL;

    // Digest Password
    unsigned char stored_digest[KVS_PWD_LEN];
    if (digestPassword(passwd, stored_digest)) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }

    // Store digest
    if (fwrite(stored_digest, KVS_PWD_LEN, 1, f) != 1) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }
    fclose(f);

    // Create new session
    session->username = malloc(strlen(username)+1);
    strcpy(session->username, username);
    return 0;
}

int session_changePassword(struct Session *session, const char *old_passwd, const char *new_passwd) {
    char filepath[KVS_LEN_PATH];

    // Validate username and get password file path
    if (get_path_for_passwd(filepath, session->username))
        return KVS_ERR_INTERNAL;

    // Check if file does not exists
    if (access(filepath, F_OK)) {
        return KVS_ERR_INTERNAL;
    }

    // Open the password hash for reading + writing; This should always succeed
    FILE* f = fopen(filepath, "r+");
    if (!f)
        return KVS_ERR_INTERNAL;

    // Read the stored password; This should always succeed
    unsigned char stored_digest[KVS_PWD_LEN];
    if (fread(stored_digest, KVS_PWD_LEN, 1, f) != 1) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }
        
    // Check if old password is valid
    if (validatePassword(old_passwd, stored_digest)) {
        fclose(f);
        return KVS_USER_INVALID;
    }
        
    // Digest new password
    if (digestPassword(new_passwd, stored_digest)) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }

    // Store digest
    fseek(f, 0, SEEK_SET);
    if (fwrite(stored_digest, KVS_PWD_LEN, 1, f) != 1) {
        fclose(f);
        return KVS_ERR_INTERNAL;
    }
    fclose(f);
    return 0;
}

int session_changeUsername(struct Session *session, const char *new_username) {
    if(sanitizeStr(new_username)) {
        return KVS_USER_INVALID;
    }

    // Get user directories
    char new_dirpath[KVS_LEN_PATH];
    snprintf(new_dirpath, KVS_LEN_PATH, "./%s", new_username);
    char old_dirpath[KVS_LEN_PATH];
    snprintf(old_dirpath, KVS_LEN_PATH, "./%s", session->username);

    // Check if new username is already taken
    if (!access(new_dirpath, F_OK)) {
        return KVS_USER_INVALID;
    }

    // Actually rename the user
    rename(old_dirpath, new_dirpath);

    // Store new username
    free(session->username);
    session->username = malloc(strlen(new_username)+1);
    strcpy(session->username, new_username);
    return 0;
}