#ifndef _KVS_AUTH_H
#define _KVS_AUTH_H

// Salt (16 bytes) + SHA-256 (32 bytes)
#define KVS_PWD_SALT_LEN 16
#define KVS_PWD_LEN (KVS_PWD_SALT_LEN + 32)

int validatePassword(const char* password, const unsigned char* stored_digest);
int digestPassword(const char* password, unsigned char* buffer);

#endif
