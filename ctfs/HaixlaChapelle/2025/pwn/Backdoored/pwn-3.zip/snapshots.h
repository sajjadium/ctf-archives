#ifndef _KVS_SNAPSHOTS_H
#define _KVS_SNAPSHOTS_H

#include "session.h"

int kvs_createSnapshot (const struct Session *session, const char* name);
int kvs_restoreSnapshot(const struct Session *session, const char* name);
int kvs_deleteSnapshot (const struct Session *session, const char* name);
int kvs_clearSnapshots (const struct Session *session);
int kvs_listSnapshots  (const struct Session *session);

#endif
