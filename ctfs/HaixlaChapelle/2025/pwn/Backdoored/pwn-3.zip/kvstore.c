#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>

#include "kvstore.h"
#include "session_io.h"
#include "sanitize.h"

#define MIN(X, Y) (((X) < (Y)) ? (X) : (Y))

static int is_special_key(const char* key) {
    return strcmp(".passwd", key) == 0 || strcmp(".snapshots", key) == 0;
}

/**
 * Given a key, validate the key and return the path of the file the key's
 * value is stored in
 */
static int get_path_for_key(char* buffer, const struct Session *session, const char* key) {
    // Check key is not a reserved key for internal use or is invalid
    if (is_special_key(key) || sanitizeStr(key) || strlen(key) > KVS_LEN_VAL)
        return 1;
    snprintf(buffer, KVS_LEN_PATH, "./%s/%s", session->username, key);
    return 0;
}

/**
 * Set a key. Overwrites the previous value, if any.
 */
int kvs_setKey(const struct Session *session, const char* key) {
    char filepath[KVS_LEN_PATH];

    // Validate key and get key file path
    if (get_path_for_key(filepath, session, key))
        return KVS_KEY_INVALID;

    // Try to read value len from session
    size_t value_len;
    session_readBlobLen(session, &value_len);

    // Delete key if value len is 0
    if (value_len == 0)
        return kvs_deleteKey(session, key);

    // Open the key for writing; This should always succeed
    FILE* f = fopen(filepath, "w");
    if (!f)
        return KVS_ERR_INTERNAL;

    // Write from the session and write to output
    size_t total_read = 0;
    size_t read = 0;
    unsigned char buffer[128];
    while (total_read < value_len) {
        session_readFromBlob(session, MIN(128, value_len - total_read), buffer, &read);
        fwrite(buffer, read, 1, f);
        total_read += read;
    }
    fclose(f);
    return 0;
}

/**
 * Get a key's value. Returns no data if the key does not exist.
 */
int kvs_getKey(const struct Session *session, const char* key) {
    char filepath[KVS_LEN_PATH];

    // Validate key and get key file path
    if (get_path_for_key(filepath, session, key))
        return KVS_KEY_INVALID;

    // If file does not exist, return empty value
    if (access(filepath, F_OK)) {
        session_writeBlobLen(session, 0);
        return 0;
    }

    // Open the key for reading; This should always succeed
    FILE* f = fopen(filepath, "r");
    if (!f)
        return KVS_ERR_INTERNAL;

    // Get length of value
    fseek(f, 0L, SEEK_END);
    long value_len = ftell(f);
    fseek(f, 0L, SEEK_SET);
    session_writeBlobLen(session, value_len);

    // Write from the file to the session
    size_t total_read = 0;
    size_t read = 0, write = 0;
    unsigned char buffer[128];
    while (total_read < value_len) {
        read = fread(buffer, 1, MIN(128, value_len - total_read), f);
        session_writeToBlob(session, read, buffer, &write);
        total_read += read;
    }
    fclose(f);
    return 0;
}

/**
 * Delete a key
 */
int kvs_deleteKey(const struct Session *session, const char* key) {
    char filepath[KVS_LEN_PATH];

    // Validate key and get key file path
    if (get_path_for_key(filepath, session, key))
        return KVS_KEY_INVALID;

    if (unlink(filepath)) {
        return KVS_KEY_INVALID;
    }
    return 0;
}

/**
 * Deletes all keys!
 */
int kvs_clearKeys(const struct Session *session) {
    char filepath[KVS_LEN_PATH];
    snprintf(filepath, KVS_LEN_PATH, "./%s", session->username);

    DIR* d = opendir(filepath);
    struct dirent* entry;
    
    while ((entry = readdir(d)) != NULL) {
        if (entry->d_type == DT_REG && !is_special_key(entry->d_name)) {
            kvs_deleteKey(session, entry->d_name);
        }
    }
    closedir(d);
    return 0;
}

/**
 * Returns all keys
 */
int kvs_listKeys(const struct Session *session) {
    char filepath[KVS_LEN_PATH];
    snprintf(filepath, KVS_LEN_PATH, "./%s", session->username);

    DIR* d = opendir(filepath);
    struct dirent* entry;

    while ((entry = readdir(d)) != NULL) {
        if (entry->d_type == DT_REG && !is_special_key(entry->d_name)) {
            // Write everything but the nullbyte, then write a newline
            session_writeStringN(session, strlen(entry->d_name), entry->d_name);
            session_writeStringN(session, 1, "\n");
        }
    }
    // Write one final nullbyte to terminate the string
    session_writeStringN(session, 1, "");
    closedir(d);
    return 0;
}
