#ifndef _KVS_SESSION_IO_H
#define _KVS_SESSION_IO_H

#include <stdio.h>
#include "session.h"

// Opcodes
#define KVS_CMD_LOGIN   0xa1
#define KVS_CMD_NEWACC  0xa2
#define KVS_CMD_CHGUSER 0xa3
#define KVS_CMD_CHGPASS 0xa4
#define KVS_CMD_EXIT    0xa5

#define KVS_CMD_SETKEY  0xb1
#define KVS_CMD_GETKEY  0xb2
#define KVS_CMD_DELKEY  0xb3
#define KVS_CMD_LSTKEYS 0xb4
#define KVS_CMD_DELKEYS 0xb5

#define KVS_CMD_SETSNP  0xc1
#define KVS_CMD_RSTRSNP 0xc2
#define KVS_CMD_DELSNP  0xc3
#define KVS_CMD_LSTSNPS 0xc4
#define KVS_CMD_DELSNPS 0xc5

// Error Codes
#define KVS_OK           0
#define KVS_CMD_INVALID  4
#define KVS_USER_INVALID 8
#define KVS_USER_EXISTS  9
#define KVS_KEY_INVALID  16
#define KVS_KEY_EXISTS   17
#define KVS_SNAP_INVALID 32
#define KVS_SNAP_EXISTS  33
#define KVS_ERR_INTERNAL 128

int session_readOpcode  (const struct Session *session, unsigned char *opcode);
int session_readBlobLen (const struct Session *session, size_t *len);
int session_writeBlobLen(const struct Session *session, const size_t len);
int session_readFromBlob(const struct Session *session, const size_t len, unsigned char *buffer, size_t *in);
int session_writeToBlob (const struct Session *session, const size_t len, unsigned char *buffer, size_t *out);
int session_readString  (const struct Session *session, const size_t len, char *string);
int session_writeString (const struct Session *session, const char *string);
int session_writeStringN(const struct Session *session, const size_t len, const char *string);
int session_writeStatus (const struct Session *session, const unsigned char status);

#endif
