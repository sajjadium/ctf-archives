#include "sanitize.h"
#include "session.h"
#include "session_io.h"
#include "snapshots.h"
#include "kvstore.h"

int main() {
    char readBufA[KVS_LEN_VAL];
    char readBufB[KVS_LEN_VAL];
    char welcome[] = "Welcome to KVS 0.12.1b. Use the provided client or our SDK to access this service securely.";
    struct Session session;
    int ret = 0;
    unsigned char opcode = 0;

    // Send welcome message
    session_writeString(&session, welcome);

    // Login
    while (1) {
        // Read next command; Error means conenction was closed.
        if (session_readOpcode(&session, &opcode)) {
            return 1;
        }

        // Only allow login/new account/exit
        if(opcode == KVS_CMD_EXIT) return 0;
        if(opcode != KVS_CMD_LOGIN && opcode != KVS_CMD_NEWACC) {
            session_writeStatus(&session, KVS_CMD_INVALID);
            continue;
        }

        // Read username + password
        ret |= session_readString(&session, KVS_LEN_VAL, readBufA);
        ret |= session_readString(&session, KVS_LEN_VAL, readBufB);

        // Invalid string or connection closed
        if (ret)
            return 1;

        // Login/Create account
        if(opcode == KVS_CMD_LOGIN) {
            ret = session_login(&session, readBufA, readBufB);
        } else {
            ret = session_createAccount(&session, readBufA, readBufB);
        }

        // If this did not work, send error code to client, else write 0
        session_writeStatus(&session, ret);

        // It did work
        if (!ret)
            break;
    }

    // We are authenticated now. Entering main loop.
    while (1) {
        // Read next command; Error means conenction was closed.
        if (session_readOpcode(&session, &opcode)) {
            return 1;
        }

        switch (opcode) {
        // Session Commands
        case KVS_CMD_CHGUSER:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = session_changeUsername(&session, readBufA);
            break;

        case KVS_CMD_CHGPASS:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            if (session_readString(&session, KVS_LEN_VAL, readBufB)) return 1;
            ret = session_changePassword(&session, readBufA, readBufB);
            break;

        // Key-Value Store Commands
        case KVS_CMD_SETKEY:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_setKey(&session, readBufA);
            break;

        case KVS_CMD_GETKEY:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_getKey(&session, readBufA);
            break;

        case KVS_CMD_DELKEY:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_deleteKey(&session, readBufA);
            break;

        case KVS_CMD_DELKEYS:
            ret = kvs_clearKeys(&session);
            break;

        case KVS_CMD_LSTKEYS:
            ret = kvs_listKeys(&session);
            break;

        // Snapshot Commands
        case KVS_CMD_SETSNP:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_createSnapshot(&session, readBufA);
            break;

        case KVS_CMD_RSTRSNP:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_restoreSnapshot(&session, readBufA);
            break;

        case KVS_CMD_DELSNP:
            if (session_readString(&session, KVS_LEN_VAL, readBufA)) return 1;
            ret = kvs_deleteSnapshot(&session, readBufA);
            break;

        case KVS_CMD_DELSNPS:
            ret = kvs_clearSnapshots(&session);
            break;

        case KVS_CMD_LSTSNPS:
            ret = kvs_listSnapshots(&session);
            break;

        case KVS_CMD_EXIT:
            return 0;

        default:
            session_writeStatus(&session, KVS_CMD_INVALID);
            return 1;
        }
        session_writeStatus(&session, ret);
    }
}
