from socket import socket, create_connection
import ssl
import struct
import sys

# === Defines ===
KVS_LEN_VAL = 64
KVS_STATUS_CODES = {
    0:   "OK",
    4:   "Invalid Command",
    8:   "Invalid Username or Password",
    9:   "User Already Exists",
    16:  "Invalid Key",
    17:  "Key Already Exists",
    32:  "Invalid Snapshot",
    33:  "Snapshot Already Exists",
    128: "Internal Server Error"
}

# === IO Helper functions ===

def send_opcode(sock: socket, opcode: int):
    sock.send(struct.pack("B", opcode))

def send_string(sock: socket, s: str):
    s_bytes = s.encode()
    if len(s_bytes) > KVS_LEN_VAL - 1:
        raise ValueError("String too long")
    sock.send(s_bytes + b'\x00')

def recv_status(sock: socket) -> int:
    return struct.unpack("B", sock.recv(1))[0]

def recv_string(sock: socket) -> str:
    data = b''
    while True:
        packet = sock.recv(1)
        if not packet:
            raise IOError("Connection closed during read")
        if packet == b'\x00':
            break
        data += packet
    return data.decode()

def send_bin(sock: socket, data: bytes):
    sock.send(struct.pack(">I", len(data)))
    sock.sendall(data)

def recv_bin(sock: socket) -> bytes:
    length_bytes = sock.recv(4)
    if len(length_bytes) < 4:
        raise IOError("Connection closed before receiving length")
    length = struct.unpack(">I", length_bytes)[0]
    data = b''
    while len(data) < length:
        packet = sock.recv(length - len(data))
        if not packet:
            print(length, data)
            raise IOError("Connection closed during binary read")
        data += packet
    return data

# === CMD Helper Functions ===

def cmd_send2str(sock: socket, opcode: int, a: str, b: str) -> int:
    send_opcode(sock, opcode)
    send_string(sock, a)
    send_string(sock, b)
    return recv_status(sock)

def cmd_send1str(sock: socket, opcode: int, a: str) -> int:
    send_opcode(sock, opcode)
    send_string(sock, a)
    return recv_status(sock)

def cmd_lst(sock: socket, opcode: int) -> tuple[int, str]:
    send_opcode(sock, opcode)
    a = recv_string(sock)
    status = recv_status(sock)
    return (status, a)

def cmd_noargs(sock: socket, opcode: int) -> int:
    send_opcode(sock, opcode)
    return recv_status(sock)

def cmd_sendBlob(sock: socket, opcode: int, key: str, value: bytes) -> int:
    send_opcode(sock, opcode)
    send_string(sock, key)
    send_bin(sock, value)
    return recv_status(sock)

def cmd_recvBlob(sock: socket, opcode: int, key: str) -> tuple[int, bytes]:
    send_opcode(sock, opcode)
    send_string(sock, key)
    value = recv_bin(sock)
    return (recv_status(sock), value)

# === Command definitions ===
COMMANDS = {
    # User mangement
    0xA1: {
        "name": "login",
        "inputs":  [{"type": "str", "name": "username"}, {"type": "str", "name": "password"}],
        "outputs": [],
        "func": cmd_send2str
    },
    0xA2: {
        "name": "newaccount",
        "inputs":  [{"type": "str", "name": "username"}, {"type": "str", "name": "password"}],
        "outputs": [],
        "func": cmd_send2str
    },
    0xA3: {
        "name": "renameuser",
        "inputs":  [{"type": "str", "name": "username"}],
        "outputs": [],
        "func": cmd_send1str
    },
    0xA4: {
        "name": "changepassword",
        "inputs":  [{"type": "str", "name": "old_password"}, {"type": "str", "name": "new_password"}],
        "outputs": [],
        "func": cmd_send2str
    },
    0xA5: {
        "name": "exit",
        "inputs":  [],
        "outputs": [],
        "func": cmd_noargs
    },

    # Key-Value Functions 
    0xB1: {
        "name": "setkey",
        "inputs":  [{"type": "str", "name": "key"}, {"type": "str or hex", "name": "value"}],
        "outputs": [],
        "func": cmd_sendBlob
    },
    0xB2: {
        "name": "getkey",
        "inputs":  [{"type": "str", "name": "key"}],
        "outputs": [{"type": "str or hex", "name": "value"}],
        "func": cmd_recvBlob
    },
    0xB3: {
        "name": "deletekey",
        "inputs":  [{"type": "str", "name": "key"}],
        "outputs": [],
        "func": cmd_send1str
    },
    0xB4: {
        "name": "listkeys",
        "inputs":  [],
        "outputs": [{"type": "str", "name": "keys"}],
        "func": cmd_lst
    },
    0xB5: {
        "name": "clearkeys",
        "inputs":  [],
        "outputs": [],
        "func": cmd_noargs
    },

    # Snapshot Functions
    0xC1: {
        "name": "newsnapshot",
        "inputs":  [{"type": "str", "name": "snapshot_name"}],
        "outputs": [],
        "func": cmd_send1str
    },
    0xC2: {
        "name": "restore",
        "inputs":  [{"type": "str", "name": "snapshot_name"}],
        "outputs": [],
        "func": cmd_send1str
    },
    0xC3: {
        "name": "deletesnapshot",
        "inputs":  [{"type": "str", "name": "snapshot_name"}],
        "outputs": [],
        "func": cmd_send1str
    },
    0xC4: {
        "name": "listsnapshots",
        "inputs":  [],
        "outputs": [{"type": "str", "name": "snapshots"}],
        "func": cmd_lst
    },
    0xC5: {
        "name": "delsnapshots",
        "inputs":  [],
        "outputs": [],
        "func": cmd_noargs
    }
}

# === Client Loop ===

def main(host, port):
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        with create_connection((host, port)) as tcp, context.wrap_socket(tcp, server_hostname=host) as sock:
            # Read welcome message
            recv_string(sock) 
            print("Connected to server.")

            while True:
                print("\n=== Available Commands ===")
                for opcode, cmd in COMMANDS.items():
                    arglist = ", ".join(f"{arg['name']}:{arg['type']}" for arg in cmd["inputs"])
                    print(f"  {cmd['name']} (args: [{arglist}])")

                # Read input command
                cmd_input = input("\nEnter command name (or 'exit' to quit): ").strip().lower()

                # Find command
                opcode = None
                for op, meta in COMMANDS.items():
                    if meta["name"] == cmd_input:
                        opcode = op
                        break

                if opcode is None:
                    print("Invalid command.")
                    continue

                if cmd_input == "exit":
                    cmd_noargs(sock, opcode)
                    print("Exiting client.")
                    break

                cmd_meta = COMMANDS[opcode]
                inputs = []

                for inp in cmd_meta["inputs"]:
                    val = input(f"Enter {inp['name']} ({inp['type']}): ")
                    if inp["type"] == "str or hex":
                        # Accept hex (e.g., 0xdeadbeef) or plain string
                        if val.startswith("0x"):
                            val = bytes.fromhex(val[2:])
                        else:
                            val = val.encode()
                    inputs.append(val)

                # Execute command
                try:
                    result = cmd_meta["func"](sock, opcode, *inputs)
                    status_code = result[0] if isinstance(result, tuple) else result
                    print("Status:", KVS_STATUS_CODES.get(status_code, f"Unknown Status Code: {status_code}"))

                    if isinstance(result, tuple) and len(result) > 1:
                        print("Output:", result[1] if len(result) == 2 else result[1:])
                except Exception as e:
                    print("Error executing command:", str(e))
                    break

    except KeyboardInterrupt:
        print("\nInterrupted. Goodbye.")
    except Exception as e:
        print("Connection error:", str(e))



if __name__ == "__main__":
    # Default values
    host = "localhost"
    port = 12345

    # Override with command-line arguments if provided
    if len(sys.argv) > 1:
        host = sys.argv[1]
    if len(sys.argv) > 2:
        port = int(sys.argv[2])

    main(host, port)
