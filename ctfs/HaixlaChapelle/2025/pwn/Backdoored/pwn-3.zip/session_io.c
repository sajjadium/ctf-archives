#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include "session_io.h"

int session_readOpcode(const struct Session *session, unsigned char *opcode) {
    if (fread(opcode, sizeof(unsigned char), 1, stdin) != 1) {
        return -1;
    }
    return 0;
}

// Read a size_t from stdin
int session_readBlobLen(const struct Session *session, size_t *len) {
    unsigned char len_buf[4];
    if (fread(len_buf, 4, 1, stdin) != 1) {
        return -1;
    }
    // big-endian to host ordering
    *len = (len_buf[0] << 24) |
           (len_buf[1] << 16) |
           (len_buf[2] << 8)  |
            len_buf[3];
    return 0;
}

// Write a size_t to stdout
int session_writeBlobLen(const struct Session *session, const size_t len) {
    unsigned char len_buf[4];
    len_buf[0] = (len >> 24) & 0xFF;
    len_buf[1] = (len >> 16) & 0xFF;
    len_buf[2] = (len >> 8)  & 0xFF;
    len_buf[3] = len & 0xFF;
    if (fwrite(&len_buf, 4, 1, stdout) != 1) {
        return -1;
    }
    fflush(stdout);
    return 0;
}

// Read `len` bytes from stdin into buffer, store how many were actually read in *in
int session_readFromBlob(const struct Session *session, const size_t len, unsigned char *buffer, size_t *in) {
    *in = fread(buffer, 1, len, stdin);
    return (*in > 0) ? 0 : -1;
}

// Write `len` bytes from buffer to stdout, store how many were actually written in *out
int session_writeToBlob(const struct Session *session, const size_t len, unsigned char *buffer, size_t *out) {
    *out = fwrite(buffer, 1, len, stdout);
    fflush(stdout);
    return (*out == len) ? 0 : -1;
}

// Read a null-terminated string from stdin into 'string'
int session_readString(const struct Session *session, const size_t len, char *string) {
    size_t i;
    int c;

    for (i = 0; i < len; ++i) {
        c = fgetc(stdin);
        if (c == EOF)
            return -1;

        string[i] = (char)c;

        if (c == 0)
            return 0;
    }
    return 0;
}

// Write a null-terminated string to stdout
int session_writeString(const struct Session *session, const char *string) {
    size_t len = strlen(string) + 1;
    if (fwrite(string, 1, len, stdout) != len) {
        return -1;
    }
    fflush(stdout);
    return 0;
}

// Write `len` bytes of string to stdout
int session_writeStringN(const struct Session *session, const size_t len, const char *string) {
    if (fwrite(string, 1, len, stdout) != len) {
        return -1;
    }
    fflush(stdout);
    return 0;
}

// Write an integer error code to stdout
int session_writeStatus(const struct Session *session, const unsigned char status) {
    if (fwrite(&status, sizeof(unsigned char), 1, stdout) != 1) {
        return -1;
    }
    fflush(stdout);
    return 0;
}
