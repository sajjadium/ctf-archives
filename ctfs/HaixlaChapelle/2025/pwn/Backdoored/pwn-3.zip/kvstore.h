#ifndef _KVSTORE_H
#define _KVSTORE_H

#include "session.h"

int kvs_setKey   (const struct Session *session, const char* key);
int kvs_getKey   (const struct Session *session, const char* key);
int kvs_deleteKey(const struct Session *session, const char* key);
int kvs_clearKeys(const struct Session *session);
int kvs_listKeys (const struct Session *session);

#endif
