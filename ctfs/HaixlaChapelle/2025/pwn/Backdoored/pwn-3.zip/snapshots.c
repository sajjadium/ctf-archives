#define _DEFAULT_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

#include "snapshots.h"
#include "session_io.h"
#include "sanitize.h"

/**
 * Validate the name and return the path of the associated snapshot
 */
static int get_path_for_snapshot(char* buffer, const struct Session *session, const char* name) {
    // Make sure name does not contain special characters
    if (sanitizeStr(name) || strlen(name) > KVS_LEN_VAL) {
        return 1;
    }

    snprintf(buffer, KVS_LEN_PATH, "./%s/.snapshots/%s.tar.gz", session->username, name);
    fprintf(stderr, "get_path_for_snapshot: %s\n", buffer);
    return 0;
}

/**
 * Create a new snapshot with the given name
 */
int kvs_createSnapshot(const struct Session *session, const char* name) {
    char snapshot_path[KVS_LEN_PATH];

    // Validate name and build path to new snapshot archive
    if(get_path_for_snapshot(snapshot_path, session, name)) {
        return KVS_SNAP_INVALID;
    }

    // Check if snapshot exists already; In that case, exit
    if (access(snapshot_path, F_OK) == 0) {
        return KVS_SNAP_EXISTS;
    }

    /* SECURITY: Both snapshot_path and session->username have been sanitized
       Use execve to avoid command injection for extra security */
    char dirpath[KVS_LEN_PATH];
    snprintf(dirpath, sizeof(dirpath), "./%s", session->username);

    pid_t pid = fork();
    if (pid < 0) {
        return KVS_SNAP_INVALID;
    }

    if (pid == 0) {
        /* child */
        char *const argv[] = {
            "tar",
            "--exclude",
            ".passwd",
            "--exclude",
            ".snapshots",
            "-czf",
            snapshot_path,
            dirpath,
            NULL
        };
        execve("/bin/tar", argv, NULL);
        /* If execve returns, it failed */
        perror("execve");
        _exit(127);
    }

    /* parent: wait for child and return error on non-zero exit */
    int status = 0;
    if (waitpid(pid, &status, 0) < 0) {
        return KVS_SNAP_INVALID;
    }
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        return KVS_SNAP_INVALID;
    }
    return 0;
}

/**
 * Restore a snapshot. This overwrites all previous data!
 */
int kvs_restoreSnapshot(const struct Session *session, const char* name) {
    char snapshot_path[KVS_LEN_PATH];

    // Validate name and build path to new snapshot archive
    if(get_path_for_snapshot(snapshot_path, session, name)) {
        return KVS_SNAP_INVALID;
    }

    // Check if snapshot doesn't exists
    if (access(snapshot_path, F_OK) != 0) {
        return KVS_SNAP_INVALID;
    }

    /* SECURITY: snapshot_path has been sanitized
       The tar archive has been created by kvs_createSnapshot() since no
       writes to '.snapshots' are possible. Use execve to avoid shell usage. */
    pid_t pid = fork();
    if (pid < 0) {
        return KVS_SNAP_INVALID;
    }

    if (pid == 0) {
        /* child */
        char *const argv[] = {
            "tar",
            "-xzf",
            snapshot_path,
            NULL
        };
        execve("/bin/tar", argv, NULL);
        perror("execve");
        _exit(127);
    }

    int status = 0;
    if (waitpid(pid, &status, 0) < 0) {
        return KVS_SNAP_INVALID;
    }
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        return KVS_SNAP_INVALID;
    }
    return 0;
}

/**
 * Delete a snapshot
 */
int kvs_deleteSnapshot(const struct Session *session, const char* name) {
    char snapshot_path[KVS_LEN_PATH];

    // Validate name and build path to new snapshot archive
    if(get_path_for_snapshot(snapshot_path, session, name)) {
        return KVS_SNAP_INVALID;
    }

    // Delete Snapshot
    if (unlink(snapshot_path) != 0) {
        return KVS_SNAP_INVALID;
    }
    return 0;
}

int kvs_clearSnapshots(const struct Session *session) {
    char filepath[KVS_LEN_PATH];
    snprintf(filepath, KVS_LEN_PATH, "./%s/.snapshots", session->username);

    DIR* d = opendir(filepath);
    struct dirent* entry;
    
    while ((entry = readdir(d)) != NULL) {
        kvs_deleteSnapshot(session, entry->d_name);
    }
    closedir(d);
    return 0;
}

int kvs_listSnapshots(const struct Session *session) {
    char filepath[KVS_LEN_PATH];
    snprintf(filepath, KVS_LEN_PATH, "./%s", session->username);

    DIR* d = opendir(filepath);
    struct dirent* entry;

    while ((entry = readdir(d)) != NULL) {
        // Skip non .tar.gz files
        if (strcmp(entry->d_name + strlen(entry->d_name) - 7, ".tar.gz") != 0) {
            continue;
        }

        // Write everything but the file ending + nullbyte, then write a newline
        session_writeStringN(session, strlen(entry->d_name)-strlen(".tar.gz"), entry->d_name);
        session_writeStringN(session, 1, "\n");
    }
    // Write one final nullbyte to terminate the string
    session_writeStringN(session, 1, "");
    closedir(d);
    return 0;
}
