#!/bin/sh
set -eu

# Plant the flag...
echo "${FLAG}" > /app/kvs/flag.txt

# Launch the container CMD
exec "$@"
