from pathlib import Path
import uuid
import os

flag_text = os.environ['FLAG'].encode()

pdf_file = Path('/flag.pdf').read_bytes().replace(b'AAAAAAAAAAAAAAAAAAAAAAAAA',flag_text)
Path('/flag.pdf').unlink()

Path(f'/opt/applications/{str(uuid.uuid4())}.pdf').write_bytes(pdf_file)