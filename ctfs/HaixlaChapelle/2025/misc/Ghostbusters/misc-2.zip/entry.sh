#!/bin/sh

python3 setup.py
flask run --host=0.0.0.0