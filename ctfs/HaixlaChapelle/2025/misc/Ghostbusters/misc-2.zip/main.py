from datetime import datetime
from flask import Flask, render_template, request, send_file, redirect
from pathlib import Path
import magic
import subprocess
import tempfile
import uuid
import logging
import re

app = Flask(__name__)
# 10MB should be plenty
app.config['MAX_CONTENT_LENGTH'] = 10 * 1000 * 1000
# path where all applications are saved
application_path = Path("/opt/applications")
# convenient file with all applications combined for easier reading
merged_application_file = Path("/opt/ressources/merged_cur.pdf")

mime = magic.Magic(mime=True)

def has_malicious_content(input_file: Path) -> bool:
    if re.search(br'(/Encrypt)|(/ObjStm)|(/XObjects)|(/FontFile)|(#)', input_file.read_bytes()):
        return True
    return False

class PDFValidationException(Exception):
    pass

def save_pdf_and_check_if_allowed(tmpdir: Path) -> Path:
    f = request.files['file']
    tmp_uuid = str(uuid.uuid4())
    in_file = tmpdir / f"{tmp_uuid}.pdf"
    f.save(in_file)

    # use libmagic to check if it is ••really•• a PDF, and not evil PostScript code
    if mime.from_file(str(in_file)) != "application/pdf":
        raise PDFValidationException("Only PDF files are allowed!")
    
    # I read that fonts and object streams in PDF files can contain malicious code so we just do not allow this at all
    # the applicants will figure it out
    try:
        is_malicious = has_malicious_content(in_file)
    except Exception as e:
        raise PDFValidationException("Failed to parse PDF!") from e
    if is_malicious:
        raise PDFValidationException("No embedded fonts or obfuscated objects allowed!")
    return in_file

@app.route('/')
def index():
    return redirect('/apply')

@app.route('/apply')
def apply():
    return render_template('apply.html')

@app.route('/previewpdf', methods=['POST'])
def preview_pdf():
     with tempfile.TemporaryDirectory() as tmpdirname:
        tempdir = Path(tmpdirname)
        try:
            in_file = save_pdf_and_check_if_allowed(tempdir)
        except PDFValidationException as e:
            logging.exception(e)
            return str(e), 400

        # generate JPEG preview
        out_file =  str(in_file) + '.jpg'
        try:
            subprocess.check_call(["gs",
                                    "-dSAFER",
                                    "-sDEVICE=jpeg",
                                    "-o", out_file,
                                    in_file])
        except subprocess.CalledProcessError:
            return "Processing of the PDF file failed!", 400
        return send_file(out_file)

@app.route('/submitcv', methods=['POST'])
def submit_cv():
    if 'email' not in request.form or 'name' not in request.form or 'file' not in request.files:
        return render_template('apply.html', error="You need to specify your name and email and upload a CV!"), 400
    
    # save PDF for processing with Ghostscript and co
    with tempfile.TemporaryDirectory() as tmpdirname:
        tempdir = Path(tmpdirname)
        try:
            in_file = save_pdf_and_check_if_allowed(tempdir)
        except Exception as e:
            logging.exception(e)
            return render_template('apply.html', error=str(e)), 400

        # save CV with annotated metadata in applications folder for further processing
        out_file =  str(application_path / in_file.name)
        try:
            subprocess.check_call(["gs",
                                    "-dSAFER",
                                    "-sDEVICE=pdfwrite",
                                    "-sEMAIL="+request.form['email'],
                                    "-sNAME="+request.form['name'],
                                    "-sTIMESTAMP="+datetime.now().isoformat(),
                                    "-o", out_file,
                                    "/opt/ressources/pdfmarkinfo.ps",
                                    in_file])
        except subprocess.CalledProcessError:
            return render_template('apply.html', error="Processing of the PDF file failed!"), 400

        # merge with the other applications
        applications = list(str(i.absolute()) for i in application_path.glob('*.pdf'))
        try:
            subprocess.check_call(["gs",
                                    "-dSAFER",
                                    "-sDEVICE=pdfwrite",
                                    f"--permit-file-read={application_path}/",
                                    "-o", str(merged_application_file),
                                    *applications
                                    ])
        except subprocess.CalledProcessError:
            return render_template('apply.html', error="Processing of the PDF file failed weirdly!"), 400

    return render_template('apply.html', success="CV submitted successfully!"), 200