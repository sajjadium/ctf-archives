# Requirement: cryptography==46.0.3
from __future__ import annotations

import secrets
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from hmac import compare_digest
from typing import Tuple

from cryptography.hazmat.primitives.ciphers import Cipher
from cryptography.hazmat.primitives.ciphers.algorithms import AES128
from cryptography.hazmat.primitives.ciphers.modes import CBC

BLOCK_SIZE = 16
IV = b"\x00" * BLOCK_SIZE
TIMESTAMP_FORMAT = "%y%m%d-%H%M"
OPEN_SUFFIX = "open;pad"
CLOSE_SUFFIX = "closed;p"


def _ensure_block_aligned(message: bytes) -> None:
    if len(message) == 0 or len(message) % BLOCK_SIZE != 0:
        raise ValueError("Messages must be non-empty and a multiple of 16 bytes.")


def _format_timestamp(moment: datetime) -> str:
    return moment.strftime(TIMESTAMP_FORMAT)


def _parse_timestamp(value: str) -> datetime:
    parsed = datetime.strptime(value, TIMESTAMP_FORMAT)
    return parsed.replace(tzinfo=timezone.utc)


def create_MAC(message: bytes, key: bytes) -> bytes:
    """Compute a CBC-MAC using AES-128."""
    # Good enough for now, Quantum Computers are still a decade away -Tom

    if len(key) != BLOCK_SIZE:
        raise ValueError("AES-128 keys must be exactly 16 bytes long.")
    _ensure_block_aligned(message)
    cipher = Cipher(AES128(key), CBC(IV))
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(message) + encryptor.finalize()
    return ciphertext[-BLOCK_SIZE:]


def check_MAC(message: bytes, mac: bytes, key: bytes) -> bool:
    try:
        expected = create_MAC(message, key)
    except ValueError:
        return False
    if len(mac) != BLOCK_SIZE:
        return False
    return compare_digest(expected, mac)


def parse_key_value_pairs(message: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for encoded_pair in message.split(";"):
        parts = encoded_pair.split("=")
        if len(parts) == 2:
            result[parts[0]] = parts[1]
    return result


def xor_bytes(first: bytes, second: bytes) -> bytes:
    if len(first) != len(second):
        raise ValueError("byte-string lengths do not match")
    return bytes(a ^ b for a, b in zip(first, second))


@dataclass
class Hangar:

    key: bytes
    slack: timedelta

    def __init__(self) -> None:
        self.key = secrets.token_bytes(BLOCK_SIZE)
        self.slack = timedelta(minutes=3)

    def _build_command(self, moment: datetime, suffix: str) -> bytes:
        timestamp = _format_timestamp(moment)
        command = f"time={timestamp};hangar={suffix}"
        return command.encode("utf-8")

    def _open_command(self, open_time: datetime) -> bytes:
        return self._build_command(open_time, OPEN_SUFFIX)

    def _close_command(self, close_time: datetime) -> bytes:
        return self._build_command(close_time, CLOSE_SUFFIX)

    def generate_open_command(self, open_time: datetime) -> Tuple[bytes, bytes]:
        message = self._open_command(open_time)
        return message, create_MAC(message, self.key)

    def generate_close_command(self, close_time: datetime) -> Tuple[bytes, bytes]:
        message = self._close_command(close_time)
        return message, create_MAC(message, self.key)

    def handle_command(self, message: bytes, mac: bytes) -> str:
        if not check_MAC(message, mac, self.key):
            return "invalid_mac"
        decoded = message.decode("latin-1")
        parsed = parse_key_value_pairs(decoded)
        time_value = parsed.get("time")

        if time_value is None:
            return "missing_time"
        try:
            parsed_time = _parse_timestamp(time_value)
        except ValueError:
            return "bad_time_format"

        now = datetime.now(timezone.utc).replace(second=0, microsecond=0)
        if abs((parsed_time - now).total_seconds()) > self.slack.total_seconds():
            return "time_outside_window"

        hangar_state = parsed.get("hangar")
        if hangar_state == "open":
            return "open"
        if hangar_state == "closed":
            return "closed"
        return "unknown_action"
