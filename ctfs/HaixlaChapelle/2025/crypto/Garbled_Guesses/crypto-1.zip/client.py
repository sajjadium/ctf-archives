from helpers import *
from pwn import *

# Set remote server here!
conn = remote("localhost", 1337)
# conn = process(["python3", "server.py"])

def send_to_server(action: str, payload: Any) -> dict[str, Any]:
    conn.recvuntil(b"> ")
    message = Communications.serialize({'action': action, 'payload': payload})
    conn.sendline(message.encode('utf-8'))
    return Communications.deserialize(conn.recvline().decode('utf-8'))

if __name__ == "__main__":
    attempt = 1
    while True:
        init_response = send_to_server('init-attempt', None)
        print(f"Server sent: {init_response}")
        if not init_response['ok'] or 'bit_length' not in init_response['response']:
            break
        bit_length = init_response['response']['bit_length']
        gc = init_response['response']['circuit']
        ot_init_msg = init_response['response']['ot_init']

        # Get input labels.
        guess = -int(input("Make a guess for the secret: "))
        guess_bits = {f"input-guess-{i}-attempt-{attempt}": (guess >> (bit_length - i - 1)) & 1 for i in range(bit_length)}
        ot_client = ObliviousTransferClient(ot_init_msg, guess_bits)
        ot_response = send_to_server('transfer-inputs', ot_client.encode_choices())
        assert ot_response['ok'], f"Failed: {ot_response}"
        gc.update({key: [val] for key,val in ot_client.decrypt_responses(ot_response['response']).items()})

        # Build the circuit.
        secret_inputs = [InputGate(f"input-secret-{i}", 0, None) for i in range(bit_length)]
        guess_inputs = [InputGate(f"input-guess-{i}-attempt-{attempt}", 1, None) for i in range(bit_length)]
        output_gates = addition_circuit(secret_inputs, guess_inputs, None)
        output_labels = {gate.identifier: gate.evaluate(gc) for gate in output_gates}

        print(send_to_server('finish-attempt', output_labels))

        attempt += 1