import json
import os
import otc
from abc import ABC, abstractmethod
from hashlib import shake_128
from typing import Any, Literal
from oblivious.ristretto import point

# This garbled circuit implementation is based on https://eprint.iacr.org/2014/756.pdf .
class Label:
    __value: bytes

    def __init__(self, value: bytes):
        assert len(value) == 16
        self.__value = value

    @staticmethod
    def from_str(hex: str) -> "Label":
        return Label(bytes.fromhex(hex))

    @staticmethod
    def from_hash(*args: "Label | str") -> "Label":
        def encode(x: Label | str) -> str:
            if isinstance(x, Label):
                return f"l{x.value.hex()}"
            return x.encode('utf8').hex()
        return Label(shake_128("|".join(encode(x) for x in args).encode('utf8')).digest(16))

    @staticmethod
    def random() -> "Label":
        return Label(os.urandom(16))

    @property
    def value(self) -> bytes:
        return self.__value

    @property
    def lsb(self) -> int:
        return self.value[-1] & 1

    def __xor__(self, other):
        assert isinstance(other, Label)
        return Label(bytes([a^b for a,b in zip(self.value, other.value)]))

    def __mul__(self, other):
        assert other in {0, 1}
        if other == 0:
            return Label(bytes([0] * len(self.value)))
        return self

    def __eq__(self, other):
        assert isinstance(other, Label)

        # Should be roughly constant time :)
        total = 0
        for a, b in zip(self.value, other.value):
            total |= a ^ b
        return total == 0

    def __str__(self):
        return self.value.hex()

    def __repr__(self):
        return self.value.hex()

class Gate(ABC):
    __identifier: str

    garble_output_zero_label: Label | None = None
    garble_table_entries: list[Label] | None = None

    eval_outout_label: Label | None = None

    def __init__(self, identifier: str):
        self.__identifier = identifier
        self.__output_label = None

    def garble(self) -> Label:
        if self.garble_output_zero_label is not None:
            return self.garble_output_zero_label
        self.garble0()
        assert self.garble_output_zero_label is not None
        return self.garble_output_zero_label

    @abstractmethod
    def garble0(self) -> None:
        pass

    def collect_garbled_circuit(self, garbled_circuit: dict[str, list[Label]] | None = None) -> dict[str, list[Label]]:
        assert self.garble_output_zero_label

        if garbled_circuit is None:
            garbled_circuit = {}
        if self.identifier in garbled_circuit:
            return garbled_circuit
        if self.garble_table_entries and len(self.garble_table_entries) > 0:
            garbled_circuit[self.identifier] = self.garble_table_entries
        return garbled_circuit

    def evaluate(self, garbled_circuit: dict[str, list[Label]]) -> Label:
        if self.eval_outout_label is not None:
            return self.eval_outout_label
        self.eval_outout_label = self.evaluate0(garbled_circuit.get(self.identifier, []), garbled_circuit)
        return self.eval_outout_label

    @abstractmethod
    def evaluate0(self, gate_table: list[Label], garbled_circuit: dict[str, list[Label]]) -> Label:
        pass

    def decode(self, label: Label, r: Label) -> int:
        assert self.garble_output_zero_label
        if label == self.garble_output_zero_label:
            return 0
        elif label ^ r == self.garble_output_zero_label:
            return 1
        else:
            raise ValueError("Invalid label.")

    @property
    def identifier(self) -> str:
        return self.__identifier


class InputGate(Gate):
    __r: Label
    __party: int

    def __init__(self, identifier: str, party: int, r: Label):
        super().__init__(identifier)
        self.__party = party
        self.__r = r

    def garble0(self) -> None:
        self.garble_output_zero_label = Label.random()

    def evaluate0(self, gate_table: list[Label], garbled_circuit: dict[str, list[Label]]) -> Label:
        return gate_table[0]

    @property
    def output_labels(self) -> tuple[Label, Label]:
        return self.garble_output_zero_label, self.garble_output_zero_label ^ self.__r

    @property
    def party(self) -> int:
        return self.__party


class XorGate(Gate):
    __input_a: Gate
    __input_b: Gate

    def __init__(self, identifier: str, input_a: Gate, input_b: Gate):
        super().__init__(identifier)
        self.__input_a = input_a
        self.__input_b = input_b

    def garble0(self) -> None:
        self.garble_output_zero_label =  self.__input_a.garble() ^ self.__input_b.garble()
        self.garble_table_entries = []

    def collect_garbled_circuit(self, garbled_circuit: dict[str, list[Label]] | None = None) -> dict[str, list[Label]]:
        garbled_circuit = super().collect_garbled_circuit(garbled_circuit)
        garbled_circuit = self.__input_a.collect_garbled_circuit(garbled_circuit)
        garbled_circuit = self.__input_b.collect_garbled_circuit(garbled_circuit)
        return garbled_circuit

    def evaluate0(self, gate_table: list[Label], garbled_circuit: dict[str, list[Label]]) -> Label:
        return self.__input_a.evaluate(garbled_circuit) ^ self.__input_b.evaluate(garbled_circuit)


class AndGate(Gate):
    __input_a: Gate
    __input_b: Gate
    __r: Label

    def __init__(self, identifier: str, input_a: Gate, input_b: Gate, r: Label):
        super().__init__(identifier)
        self.__input_a = input_a
        self.__input_b = input_b
        self.__r = r

    def garble0(self) -> None:
        w_0_a = self.__input_a.garble()
        w_1_a = w_0_a ^ self.__r

        w_0_b = self.__input_b.garble()
        w_1_b = w_0_b ^ self.__r

        p_a = w_0_a.lsb
        p_b = w_0_b.lsb

        j = Label.from_hash(self.identifier, "g")
        j_prime = Label.from_hash(self.identifier, "e")

        t_g = Label.from_hash(w_0_a, j) ^ Label.from_hash(w_1_a, j) ^ self.__r * p_b

        w_0_g = Label.from_hash(w_0_a, j) ^ t_g * p_a

        t_e = Label.from_hash(w_0_b, j_prime) ^ Label.from_hash(w_1_b, j_prime) ^ w_0_a
        w_0_e = Label.from_hash(w_0_b, j_prime) ^ ((t_e ^ w_0_a) * p_b)
        self.garble_table_entries = [t_g, t_e]
        self.garble_output_zero_label = w_0_g ^ w_0_e

    def evaluate0(self, gate_table: list[Label], garbled_circuit: dict[str, list[Label]]) -> Label:
        w_a = self.__input_a.evaluate(garbled_circuit)
        w_b = self.__input_b.evaluate(garbled_circuit)
        t_g, t_e = gate_table

        s_a = w_a.lsb
        s_b = w_b.lsb
        j = Label.from_hash(self.identifier, "g")
        j_prime = Label.from_hash(self.identifier, "e")

        w_g = Label.from_hash(w_a, j) ^ t_g * s_a
        w_e = Label.from_hash(w_b, j_prime) ^ ((t_e ^ w_a) * s_b)
        return w_g ^ w_e

    def collect_garbled_circuit(self, garbled_circuit: dict[str, list[Label]] | None = None) -> dict[str, list[Label]]:
        garbled_circuit = super().collect_garbled_circuit(garbled_circuit)
        garbled_circuit = self.__input_a.collect_garbled_circuit(garbled_circuit)
        garbled_circuit = self.__input_b.collect_garbled_circuit(garbled_circuit)
        return garbled_circuit


def addition_circuit(inputs_a: list[Gate], inputs_b: list[Gate], r: Label) -> list[Gate]:
    c_in: Gate | None = None
    outputs = []
    for i, (a, b) in enumerate(zip(reversed(inputs_a), reversed(inputs_b))):
        s = XorGate(f"{i}-1", a, b)
        c_out = AndGate(f"{i}-2", a, b, r)
        if c_in is not None:
            c_out = XorGate(f"{i}-3", c_out, AndGate(f"{i}-4", c_in, s, r))
            s = XorGate(f"{i}-5", s, c_in)

        outputs.append(s)
        c_in = c_out
    return outputs


def encode_input(input_gates: list[InputGate], input: int) -> dict[str, list[Label]]:
    result = {}
    for gate in reversed(input_gates):
        result[gate.identifier] = [gate.output_labels[input & 1]]
        input >>= 1
    return result


class ObliviousTransferServer:
    to_transfer: dict[str, tuple[Label, Label]] | None
    state: otc.send

    def __init__(self, to_transfer: dict[str, tuple[Label, Label]] | None):
        self.to_transfer = to_transfer
        self.state = otc.send()

    def initial_message(self) -> str:
        return self.state.public.to_base64()

    def encrypt_responses(self, encoded_choices: dict[str, Literal[0, 1]]) -> dict[str, tuple[bytes, bytes]]:
        return { key: self.state.reply(query, self.to_transfer[key][0].value, self.to_transfer[key][1].value) for key,query in encoded_choices.items() }

class ObliviousTransferClient:
    s_public: str
    choices: dict[str, Literal[0, 1]]
    state: otc.receive

    def __init__(self, initial_message: str, choices: dict[str, Literal[0, 1]]):
        self.s_public = point.from_base64(initial_message)
        self.choices = choices
        self.state = otc.receive()

    def encode_choices(self) -> Any:
        return { key: self.state.query(self.s_public, value) for key,value in self.choices.items() }

    def decrypt_responses(self, responses: dict[str, tuple[bytes, bytes]]) -> dict[str, Label]:
        assert self.choices.keys() == responses.keys()
        return { key: Label(self.state.elect(self.s_public, self.choices[key], *reply)) for key,reply in responses.items() }


class Communications:
    def _impl_encode(obj: Any) -> Any:
        if isinstance(obj, point):
            return {"__type__": "point", "value": obj.hex()}
        if isinstance(obj, Label):
            return {"__type__": "Label", "value": obj.value.hex()}
        if isinstance(obj, bytes):
            return {"__type__": "bytes", "value": obj.hex()}
        raise TypeError(
            "Unserializable object {} of type {}".format(obj, type(obj))
        )

    def _impl_decode(obj: Any):
        if isinstance(obj, dict) and obj.get("__type__") == "Label":
            return Label.from_str(obj["value"])
        if isinstance(obj, dict) and obj.get("__type__") == "bytes":
            return bytes.fromhex(obj["value"])
        if isinstance(obj, dict) and obj.get("__type__") == "point":
            return point.fromhex(obj["value"])
        return obj

    def serialize(data: dict[str, Any]) -> str:
        return json.dumps(data, default=Communications._impl_encode)

    def deserialize(data: str) -> dict[str, Any]:
        message = json.loads(data, object_hook=Communications._impl_decode)
        if not isinstance(message, dict):
            raise ValueError("Invalid message format.")
        return message
