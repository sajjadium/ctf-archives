import os
from typing import Any, Literal
from helpers import *

FLAG = os.getenv("FLAG", "flag{flag_for_local_testing}")

class ChallengeServer:
    # General parameters
    bit_length: int
    max_attempts: int
    secret: int

    # The current circuit.
    r: Label | None
    secret_inputs: list[InputGate] | None
    guess_inputs: list[InputGate] | None
    guess_ot: ObliviousTransferServer | None
    outputs: list[Gate] | None

    # Current game state.
    attempt: int
    has_received_input_labels: bool

    def __init__(self, bit_length: int = 128, max_attempts: int = 3):
        # Has to be done per connection.
        self.bit_length = bit_length
        self.max_attempts = max_attempts
        self.secret = int.from_bytes(os.urandom(bit_length//8))

        self.attempt = 1
        self.r = None
        self.secret_inputs = None
        self.guess_inputs = None
        self.guess_ot = None
        self.outputs = None

    def handle_message(self, action: Literal['init-attempt', 'transfer-inputs', 'finish-attempt'], payload: Any) -> dict[str, Any]:
        if self.attempt > self.max_attempts:
            return {'ok': False, 'response': "No more attempts left!" }

        match action:
            case 'init-attempt':
                if self.outputs is not None:
                    return {'ok': False, 'response': 'Attempt is already initialized.'}
                garbled_circuit = self.prepare_attempt()
                ot_init = self.guess_ot.initial_message()
                return {'ok': True, 'response': {
                    'bit_length': self.bit_length,
                    'circuit': garbled_circuit,
                    'ot_init': ot_init
                }}
            case 'transfer-inputs':
                if self.guess_ot is None:
                    return {'ok': False, 'response': "You must initialize the attempt first!"}
                response = self.guess_ot.encrypt_responses(payload)
                self.guess_ot = None # Ensure that the evaluator can get their inputs only once.
                return {'ok': True, 'response': response }
            case 'finish-attempt':
                if self.outputs is None:
                    return {'ok': False, 'response': "You must initialize the attempt first!"}
                
                result = self.finish_computation(payload)
                if not isinstance(result, int):
                    return {'ok': False, 'response': result }

                abs_result = result
                if ((result >> self.bit_length) & 1) == 1:
                    abs_result = (~result + 1) & (2**self.bit_length-1)

                if abs_result == 0:
                    return {'ok': True, 'response': "Wow, you got it!", 'flag': FLAG}
                elif abs_result <= 1024:
                    return {'ok': True, 'response': "Close, but no cigar." }
                else:
                    return {'ok': True, 'response': "Meh." }
        return {'ok': False, 'response': "This should not happen. Did you specify a correct actions?" }

    def prepare_attempt(self) -> dict[str, list[Label]]:
        if self.r is None:
            # Initial setup.
            r = Label.random()
            while r.lsb == 0:
                r = Label.random()
            self.r = r

            self.secret_inputs = [InputGate(f"input-secret-{i}", 0, self.r) for i in range(self.bit_length)]

        # Ensures that the evaluator's wire labels are not re-used.
        self.guess_inputs = [InputGate(f"input-guess-{i}-attempt-{self.attempt}", 0, self.r) for i in range(self.bit_length)]
        self.outputs = addition_circuit(self.secret_inputs, self.guess_inputs, self.r)
        self.has_received_input_labels = False

        garbled_circuit = {}
        for gate in self.outputs:
            gate.garble()
            gate.collect_garbled_circuit(garbled_circuit)
        garbled_circuit.update(encode_input(self.secret_inputs, self.secret))

        self.guess_ot = ObliviousTransferServer({gate.identifier: gate.output_labels for gate in self.guess_inputs})

        return garbled_circuit

    def finish_computation(self, payload: dict[str, Label]) -> int | str:
        result = 0
        for gate in reversed(self.outputs):
            result <<= 1
            try:
                result |= gate.decode(payload[gate.identifier], self.r)
            except ValueError:
                return "You sent an invalid output label!"

        # Reset current computation to ensure that each attempt actually runs only once.
        self.guess_inputs = None
        self.guess_ot = None
        self.outputs = None
        self.attempt += 1
        return result

if __name__ == "__main__":
    server = ChallengeServer()
    print("Try your best...")
    while True:
        try:
            message = Communications.deserialize(input("> "))
            if not 'action' in message or not 'payload' in message:
                print(Communications.serialize({'ok': False, 'response': 'Missing parameters. Check your input!'}))
                break
            response = server.handle_message(message['action'], message['payload'])
            print(Communications.serialize(response))
            if not response['ok']:
                break

        except Exception as err:
            print(Communications.serialize({'ok': False, 'response': f'Internal Exception. Check your input!'}))
            break
