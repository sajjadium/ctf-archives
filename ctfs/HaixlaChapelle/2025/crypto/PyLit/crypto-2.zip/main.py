import torch as sixseven
import signal as toilet
import os as oops


def skibidy(*_rip):
    print(
        "\nhttps://media2.giphy.com/media/v1.Y2lkPTc5MGI3NjExemh2cnJlNmhlN3JiMWYwbzk2bmkybjFzdTkwaGg4ZGpuampxdWl2NyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/nR4L10XlJcSeQ/giphy.gif"
    )
    exit(2)


class dQw4w9WgXcQ(sixseven.nn.Module):
    def __init__(self):
        super(dQw4w9WgXcQ, self).__init__()
        # https://doi.org/10.1016/0893-6080(89)90020-8
        input_size, hidden_size, output_size = 10, 30, 1
        self.layer1 = sixseven.nn.Linear(input_size, hidden_size)
        self.layer2 = sixseven.nn.Linear(hidden_size, hidden_size)
        self.layer3 = sixseven.nn.Linear(hidden_size, output_size)
        self.activation = sixseven.nn.ReLU()

    def forward(self, x):
        x = self.activation(self.layer1(x))  # *almost* impossible to invert
        x = self.activation(self.layer2(x))  # or is it?
        x = self.layer3(x)
        return x


if __name__ == "__main__":
    toilet.signal(toilet.SIGALRM, skibidy)
    toilet.alarm(30 * 60)

    internet = dQw4w9WgXcQ()
    oracle = sixseven.reshape(internet.layer1.weight, (-1,))

    print(f"Welcome to the Rick Wisdom Oracle! (version {sixseven.__version__})")
    for _ in range(10):
        print("Enter a number between 0 and", oracle.shape[0] - 1, ":")
        while True:
            try:
                idx = input("> ")
                idx = int(idx)
                break
            except ValueError:
                pass
        if 0 <= idx < oracle.shape[0]:
            print(f"Here's your piece of wisdom: {oracle[idx].item():.04f}")
        else:
            print("I'm out of my depth on this one, sorry!")
    print()
    print("Now, it's your turn!")

    for _ in range(10):
        x = sixseven.randn(internet.layer1.in_features)
        y = internet(x)
        print(f"Hint: {x.tolist()}")
        print("What would Rick say?")
        while True:
            try:
                guess = float(input("> "))
                break
            except ValueError:
                continue

        actual = y.item()
        if abs(guess - actual) < 2e-4:
            print("Wubba lubba dub dub! You got it right!")
        else:
            print(f"Womp womp! The correct answer was: {actual:.04f}")
            exit(1)

    print("Congratulations! You've mastered the wisdom of torches!")

    print(f"Here is your flag: {oops.getenv('FLAG', 'rip bozo')}")
