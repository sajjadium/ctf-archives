import { chromium } from 'playwright';

import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { writeFile, mkdir, rm, rename } from 'fs/promises';

import express, { Router } from 'express';

const flag = process.env.FLAG || 'flag{test_flag}';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const publicDir = join(__dirname, 'public');
const uploadsDir = join(__dirname, 'uploads');
const safeUploadsDir = join(__dirname, 'safe-uploads');

const app = express();
const route = Router();

app.use("/", express.static(publicDir));
app.use("/uploads", express.static(safeUploadsDir));

route.post('/upload/:filename', express.raw({ type: '*/*', limit: '1kb' }), async (req, res) => {
    await mkdir(uploadsDir, { recursive: true });
    await mkdir(safeUploadsDir, { recursive: true });

    if (!req.body || req.body.length === 0) {
        return res.status(400).send('No file uploaded');
    }

    const uploadName = req.params.filename;
    if (!/^[a-zA-Z0-9._-]+$/.test(uploadName)) {
        return res.status(400).send('Invalid filename');
    }

    const uploadPath = join(uploadsDir, uploadName);
    await writeFile(uploadPath, req.body);

    const isSafe = await validate(uploadName);
    if (isSafe) {
        await rename(uploadPath, join(safeUploadsDir, uploadName));
        res.status(200).send('Upload is network-free and is now available at /uploads/' + uploadName);
    } else {
        await rm(uploadPath);
        res.status(400).send('Do not use those nasty networking features! Your upload has been rejected.');
    }
});

route.post('/visit/:filename', async (req, res) => {
    const uploadName = req.params.filename;
    if (!/^[a-zA-Z0-9._-]+$/.test(uploadName)) {
        return res.status(400).send('Invalid filename');
    }

    (async () => {
        try {
            await visit(uploadName);
        } catch (_) {
            // ignore all errors
        }
    })();

    res.status(200).send('Visiting your upload!');
});

function routeIsInternet(route) {
    const url = new URL(route.request().url());
    
    const internetProtocols = ['http:', 'https:', 'ws:', 'wss:', 'ftp:', 'ftps:'];
    const isInternetProtocol = internetProtocols.includes(url.protocol);
    if (!isInternetProtocol) return false;

    const isInternet = url.hostname !== 'localhost';
    return isInternet;
}

async function visit(uploadName) {
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();

    await context.setOffline(true);
    await context.route('**/*', route => {
        if (!routeIsInternet(route)) {
            route.continue();
            return;
        }

        route.abort();
    });

    await context.exposeFunction('lookAtThisBeautifulFlag', () => flag);

    await context.addInitScript(() => {
        window.RTCPeerConnection = function() {
            throw new Error('WebRTC is disabled. But who needs WebRTC anyway when you can look at this beautiful flag?');
        };

        window.WebSocket = function() {
            throw new Error('WebSocket is disabled. But who needs WebSockets anyway when you can look at this beautiful flag?');
        };

        window.fetch = function() {
            throw new Error('Fetch is disabled. But who needs networking anyway when you can look at this beautiful flag?');
        };
    });

    const page = await context.newPage();
    await page.goto(`file://${join(safeUploadsDir, uploadName)}`);
    await page.waitForLoadState('load');
    await page.waitForTimeout(1000);
    await browser.close();
}

async function validate(uploadName) {
    let doesNotConnectToTheInternet = true;
    let doesNotUseWebRTC = true;
    let doesNotUseWebSocket = true;
    let doesNotUseFetch = true;

    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();

    await context.setOffline(true);
    await context.route('**/*', route => {
        if (!routeIsInternet(route)) {
            route.continue();
            return;
        }

        doesNotConnectToTheInternet = false;
        route.abort();
    });

    await context.exposeFunction('webrtcDetected', () => doesNotUseWebRTC = false);
    await context.exposeFunction('websocketDetected', () => doesNotUseWebSocket = false);
    await context.exposeFunction('fetchDetected', () => doesNotUseFetch = false);

    await context.addInitScript(() => {
        window.RTCPeerConnection = function() {
            window.webrtcDetected();
            throw new Error('WebRTC is disabled. But who needs WebRTC anyway when you can look at this beautiful flag?');
        };

        window.WebSocket = function() {
            window.websocketDetected();
            throw new Error('WebSocket is disabled. But who needs WebSockets anyway when you can look at this beautiful flag?');
        };

        window.fetch = function() {
            window.fetchDetected();
            throw new Error('Fetch is disabled. But who needs networking anyway when you can look at this beautiful flag?');
        };
    });

    const page = await context.newPage();
    await page.goto(`file://${join(uploadsDir, uploadName)}`);
    await page.waitForLoadState('load');
    await page.waitForTimeout(1000);
    await browser.close();

    let isSafe = doesNotConnectToTheInternet && doesNotUseWebRTC && doesNotUseWebSocket && doesNotUseFetch;
    return isSafe;
}

app.use("/", route)
app.listen(3000, () => {
    console.log('Server listening on port 3000');
});