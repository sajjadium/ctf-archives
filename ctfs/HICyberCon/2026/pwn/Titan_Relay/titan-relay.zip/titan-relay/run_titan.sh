#!/bin/bash
if [ "$1" = "work" ]; then
    export HOME=/home/ctf
    export WINEARCH=win64
    export WINEPREFIX=/home/ctf/prefix
    export WINEDEBUG=-all
    export DISPLAY=
    /usr/bin/wine /app/titan_relay.exe
    status=$?
    /usr/bin/wineserver -k >/dev/null 2>&1 || true
    exit "$status"
fi

export HOME=/home/ctf
export WINEARCH=win64
export WINEPREFIX=/home/ctf/prefix
export WINEDEBUG=-all
export DISPLAY=
mkdir -p "$WINEPREFIX"
/usr/bin/wineboot --init >/dev/null 2>&1 || true
/usr/bin/wineserver -k >/dev/null 2>&1 || true
chown -R ctf:ctf /home/ctf
exec socat -T 60 TCP-LISTEN:7260,reuseaddr,fork EXEC:"/app/run_titan.sh work",su=ctf
