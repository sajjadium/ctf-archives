// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

import {Disbursement} from "./Disbursement.sol";

/// @notice Setup -- deploys and funds one fresh, fully self-contained instance
/// of the grant program, records the voucher the player is handed, and exposes
/// isSolved().
///
/// Win condition: the Disbursement reserve ends below 1% of its starting
/// balance. Everything below is constructed fresh per instance; there is no
/// shared state and no cross-instance assumption.
///
/// Setup does NOT sign anything. The committee signature it stores was produced
/// off-chain, before deployment, by the deploy tooling, using a key that exists
/// only transiently there and is discarded after signing. The key is never a
/// contract value and never appears in any handed-out material -- only the
/// resulting signature bytes do.
contract Setup {
    // ----- fixed instance parameters -----
    uint256 public constant RESERVE = 20 ether;
    uint256 public constant VOUCHER_AMOUNT = 1 ether;
    uint256 public constant VOUCHER_NONCE = 0;

    // ----- deployed system -----
    address public immutable player;
    address public immutable committee;
    Disbursement public immutable disbursement;

    // ----- the voucher handed to the player -----
    uint256 public immutable voucherAmount;
    uint256 public immutable voucherNonce;
    bytes public voucherSignature;

    constructor(address _player, address _committee, bytes memory _voucherSig) payable {
        require(msg.value == RESERVE, "setup: wrong reserve");
        require(_player != address(0), "setup: zero player");
        require(_committee != address(0), "setup: zero committee");

        player = _player;
        committee = _committee;

        voucherAmount = VOUCHER_AMOUNT;
        voucherNonce = VOUCHER_NONCE;
        voucherSignature = _voucherSig;

        // Deploy the program and fund its entire reserve in one shot. No ETH is
        // sent to the player here -- the instancer funds the player's own key
        // with gas money separately, same as every other challenge.
        disbursement = new Disbursement{value: RESERVE}(_committee);
    }

    /// @notice Convenience getter so a player can read the whole voucher in one
    /// call rather than three.
    function voucher() external view returns (uint256 amount, uint256 nonce, bytes memory sig) {
        return (voucherAmount, voucherNonce, voucherSignature);
    }

    /// @notice Win check: the reserve has been paid out below 1% of its start.
    function isSolved() external view returns (bool) {
        return address(disbursement).balance < (RESERVE / 100);
    }
}
