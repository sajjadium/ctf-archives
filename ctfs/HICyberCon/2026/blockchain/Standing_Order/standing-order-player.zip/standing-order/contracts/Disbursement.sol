// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title Disbursement
/// @notice Pays out the grant program's ETH reserve against vouchers approved
/// (signed) off-chain by the program committee.
///
/// A voucher is the pair (amount, nonce). The committee signs it off-chain; the
/// holder of a valid (amount, nonce, signature) triple presents it here to be
/// paid. Two redemption paths exist, wired against the SAME signature check:
///
///   acknowledge()  -- intended for small self-serve onboarding credits.
///   disburse()     -- intended for the committee's own, larger approvals.
///
/// The reserve is funded once, at construction, by whoever deploys this
/// contract (the Setup contract in this exercise). There is no token; the
/// reserve is plain ETH.
contract Disbursement {
    /// @notice The off-chain signer whose approval a voucher must carry.
    address public immutable committee;

    /// @notice Each voucher may be redeemed once; keyed by the voucher digest.
    mapping(bytes32 => bool) public voucherUsed;

    event Paid(address indexed recipient, uint256 amount, bytes32 indexed digest);

    constructor(address _committee) payable {
        require(_committee != address(0), "committee: zero");
        committee = _committee;
    }

    // ---------------------------------------------------------------------
    // shared check -- BOTH paths use exactly this, byte for byte
    // ---------------------------------------------------------------------

    /// @dev The voucher digest. Note what is NOT in it: the recipient address,
    /// and which function the voucher is presented through. A voucher names an
    /// amount and a nonce and nothing else.
    function voucherDigest(uint256 amount, uint256 nonce) public pure returns (bytes32) {
        return keccak256(abi.encodePacked(amount, nonce));
    }

    /// @dev Recovers the signer of a 65-byte signature over the eth-signed form
    /// of the voucher digest. Used identically by acknowledge() and disburse().
    function _recoverSigner(bytes32 digest, bytes calldata sig) internal pure returns (address) {
        require(sig.length == 65, "sig: bad length");
        bytes32 ethSigned =
            keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", digest));
        bytes32 r;
        bytes32 s;
        uint8 v;
        assembly {
            r := calldataload(sig.offset)
            s := calldataload(add(sig.offset, 32))
            v := byte(0, calldataload(add(sig.offset, 64)))
        }
        return ecrecover(ethSigned, v, r, s);
    }

    // ---------------------------------------------------------------------
    // path 1: onboarding credits -- mark used BEFORE paying
    // ---------------------------------------------------------------------

    /// @notice Redeem a voucher as an onboarding credit. Ordinary
    /// checks-effects-interactions order: the voucher is marked used before the
    /// ETH is sent.
    function acknowledge(address recipient, uint256 amount, uint256 nonce, bytes calldata sig)
        external
    {
        bytes32 digest = voucherDigest(amount, nonce);
        require(!voucherUsed[digest], "voucher: used");
        require(_recoverSigner(digest, sig) == committee, "voucher: bad signer");

        voucherUsed[digest] = true; // effect, before interaction

        (bool ok,) = recipient.call{value: amount}("");
        require(ok, "pay: failed");
        emit Paid(recipient, amount, digest);
    }

    // ---------------------------------------------------------------------
    // path 2: committee approvals -- mark used AFTER paying
    // ---------------------------------------------------------------------

    /// @notice Redeem a voucher as a committee approval. The signature check is
    /// identical to acknowledge(); only the ordering differs -- the ETH is sent
    /// before the voucher is marked used.
    function disburse(address recipient, uint256 amount, uint256 nonce, bytes calldata sig)
        external
    {
        bytes32 digest = voucherDigest(amount, nonce);
        require(!voucherUsed[digest], "voucher: used");
        require(_recoverSigner(digest, sig) == committee, "voucher: bad signer");

        (bool ok,) = recipient.call{value: amount}(""); // interaction, before effect
        require(ok, "pay: failed");

        voucherUsed[digest] = true;
        emit Paid(recipient, amount, digest);
    }

    /// @notice Lets Setup fund the reserve at construction (and accepts plain
    /// transfers generally).
    receive() external payable {}
}
