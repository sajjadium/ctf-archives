// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/// @title Ledger
/// @notice Settlement ledger for a single case file. The system has been wound
///         down: as part of decommissioning, the operator cleared the working
///         record from contract storage with `prune()`.
///
///         A case file has four fields:
///           - the case reference   (fixed at deployment, `caseReference()`)
///           - the working record   (`configure()`, cleared by `prune()`)
///           - the archive entry    (`seal()`, filed at a derived storage location)
///           - the note             (reported by `unlock()` to the caller it was
///                                   filed for, when that caller guesses wrong)
contract Ledger {
    event Configured(address indexed by);
    event Sealed(address indexed by);
    event Pruned(address indexed by);

    /// Domain strings for the archive location and for the two masks.
    string private constant ARCHIVE_DOMAIN = "hictf.pruned-ledger.archive";
    bytes32 private constant SEAL_DOMAIN = keccak256("hictf.pruned-ledger.seal");
    bytes32 private constant NOTE_DOMAIN = keccak256("hictf.pruned-ledger.note");

    address public immutable operator;
    bytes32 public immutable caseReference;

    bytes32 public record;
    bytes32 private _maskedNote;
    bytes32 private _unlockHash;
    bool public pruned;
    bool public unlocked;

    modifier onlyOperator() {
        require(msg.sender == operator, "ledger: operator only");
        _;
    }

    constructor(bytes32 caseReference_, bytes32 maskedNote, bytes32 unlockHash) {
        operator = msg.sender;
        caseReference = caseReference_;
        _maskedNote = maskedNote;
        _unlockHash = unlockHash;
    }

    /// Settlement funds arrive here from the last relay of the case's trail.
    receive() external payable {}

    function configure(bytes32 newRecord) external onlyOperator {
        require(!pruned, "ledger: pruned");
        record = newRecord;
        emit Configured(msg.sender);
    }

    /// Files the archive entry under a location derived from the record that is
    /// current at the time of sealing. The entry is submitted masked and stored
    /// unmasked. There is deliberately no getter for the archive location.
    function seal(bytes32 maskedEntry) external onlyOperator {
        require(!pruned, "ledger: pruned");
        bytes32 rec = record;
        require(rec != bytes32(0), "ledger: no record");
        bytes32 slot = _archiveSlot(rec);
        bytes32 entry = maskedEntry ^ keccak256(abi.encodePacked(SEAL_DOMAIN, address(this), rec));
        assembly {
            sstore(slot, entry)
        }
        emit Sealed(msg.sender);
    }

    /// Decommissioning step: clears the working record from storage.
    function prune() external onlyOperator {
        record = bytes32(0);
        pruned = true;
        emit Pruned(msg.sender);
    }

    function unlock(bytes32 guess) external {
        if (keccak256(abi.encodePacked(guess)) != _unlockHash) {
            revert(string.concat("wrong guess, the stored value is: ", _note(msg.sender)));
        }
        unlocked = true;
    }

    /// archive location = keccak256(abi.encodePacked(ARCHIVE_DOMAIN, record)) - 1
    /// where `record` is the full 32-byte word (zero padding included).
    function _archiveSlot(bytes32 rec) private pure returns (bytes32) {
        return bytes32(uint256(keccak256(abi.encodePacked(ARCHIVE_DOMAIN, rec))) - 1);
    }

    /// The note's mask is bound to the caller: only the address it was filed for
    /// sees it in clear.
    function _note(address caller) private view returns (string memory) {
        return _trim(_maskedNote ^ keccak256(abi.encodePacked(NOTE_DOMAIN, address(this), caller)));
    }

    /// bytes32 holding left-aligned ASCII, zero padded -> string without the padding.
    function _trim(bytes32 word) private pure returns (string memory) {
        uint256 len = 0;
        while (len < 32 && word[len] != 0) {
            len++;
        }
        bytes memory out = new bytes(len);
        for (uint256 i = 0; i < len; i++) {
            out[i] = word[i];
        }
        return string(out);
    }
}
