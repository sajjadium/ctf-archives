// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/// @title Relay
/// @notice Pass-through hop for settlement funds. Holds whatever it receives
///         until its operator forwards the full balance to the next hop. Every
///         movement is logged against the relay's case tag:
///           - on receipt:  actor = the sender,   value = amount received
///           - on forward:  actor = the next hop, value = amount forwarded
contract Relay {
    event CaseActivity(bytes4 indexed caseTag, address indexed actor, uint256 value);

    bytes4 private immutable _caseTag;
    address private immutable _operator;
    address payable private immutable _next;

    constructor(bytes4 caseTag, address payable nextHop) {
        _caseTag = caseTag;
        _operator = msg.sender;
        _next = nextHop;
    }

    receive() external payable {
        emit CaseActivity(_caseTag, msg.sender, msg.value);
    }

    function forward() external {
        require(msg.sender == _operator, "relay: operator only");
        uint256 amount = address(this).balance;
        require(amount > 0, "relay: nothing to forward");
        emit CaseActivity(_caseTag, _next, amount);
        (bool ok,) = _next.call{value: amount}("");
        require(ok, "relay: forward failed");
    }
}
