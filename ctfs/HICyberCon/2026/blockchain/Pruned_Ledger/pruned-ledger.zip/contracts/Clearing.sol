// SPDX-License-Identifier: MIT
pragma solidity 0.8.24;

/// @title Clearing
/// @notice Untagged clearing account: collects incidental payments and pays the
///         accumulated balance out to a fixed beneficiary when its owner clears it.
contract Clearing {
    event Received(address indexed from, uint256 value);
    event Cleared(address indexed to, uint256 value);

    address public immutable owner;
    address payable public immutable beneficiary;

    constructor(address payable beneficiary_) {
        owner = msg.sender;
        beneficiary = beneficiary_;
    }

    receive() external payable {
        emit Received(msg.sender, msg.value);
    }

    function clear() external {
        require(msg.sender == owner, "clearing: owner only");
        uint256 amount = address(this).balance;
        require(amount > 0, "clearing: nothing to clear");
        emit Cleared(beneficiary, amount);
        (bool ok,) = beneficiary.call{value: amount}("");
        require(ok, "clearing: payout failed");
    }
}
