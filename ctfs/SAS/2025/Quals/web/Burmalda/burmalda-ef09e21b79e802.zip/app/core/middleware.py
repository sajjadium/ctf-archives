import jwt
from aiohttp import web

from repositories.user_repository import UserRepository
from settings import get_app_settings


@web.middleware
async def auth_middleware(request, handler):
    public_paths = [
        '/',
        '/tonconnect-manifest.json',
        '/api/users/wallet_auth',
        '/api/auth',
        '/api/fake_auth',
        '/static/'
    ]
    
    if request.path == '/' or any(request.path.startswith(path) for path in public_paths if path != '/'):
        return await handler(request)

    token = request.cookies.get('auth_token')
    if not token:
        return web.Response(status=401, text='Unauthorized')

    try:
        payload = jwt.decode(token, get_app_settings().JWT_SECRET_KEY, algorithms=[get_app_settings().JWT_ALGORITHM])
        wallet_address = payload.get('wallet_address')
        user_id = payload.get('user_id')
        
        if not wallet_address or not user_id:
            return web.Response(status=400, text='Invalid token payload')
            
        request['user_id'] = user_id
        request['wallet_address'] = wallet_address
        return await handler(request)
    except jwt.ExpiredSignatureError:
        return web.Response(status=401, text='Token has expired')
    except jwt.InvalidTokenError:
        return web.Response(status=401, text='Invalid token')


@web.middleware
async def auth_vip_middleware(request, handler):
    token = request.cookies.get('auth_token')
    if not token:
        return web.Response(status=401, text='Unauthorized')

    try:
        payload = jwt.decode(token, get_app_settings().JWT_SECRET_KEY, algorithms=[get_app_settings().JWT_ALGORITHM])
        wallet_address = payload.get('wallet_address')
        user_id = payload.get('user_id')

        if not wallet_address or not user_id:
            return web.Response(status=400, text='Invalid token payload')

        request['user_id'] = user_id
        request['wallet_address'] = wallet_address

        user = await UserRepository.get_by_id(user_id)
        if not user or not user["is_vip"]:
            return web.Response(status=403, text='Forbidden')

        return await handler(request)

    except jwt.ExpiredSignatureError:
        return web.Response(status=401, text='Token has expired')
    except jwt.InvalidTokenError:
        return web.Response(status=401, text='Invalid token')
