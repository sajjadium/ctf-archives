import jwt
import time
from settings import get_app_settings

def generate_token(wallet_address, user_id):
    settings = get_app_settings()
    payload = {
        'wallet_address': wallet_address,
        'user_id': user_id,
        'exp': int(time.time()) + settings.JWT_EXPIRATION_SECONDS
    }
    token = jwt.encode(
        payload,
        settings.JWT_SECRET_KEY,
        algorithm=settings.JWT_ALGORITHM
    )
    return token

def verify_token(token):
    settings = get_app_settings()
    payload = jwt.decode(
        token,
        settings.JWT_SECRET_KEY,
        algorithms=[settings.JWT_ALGORITHM]
    )
    return payload