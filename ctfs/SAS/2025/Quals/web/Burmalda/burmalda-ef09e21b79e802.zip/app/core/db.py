from databases import Database
from sqlalchemy import MetaData
from sqlalchemy.ext.declarative import declarative_base

from settings import get_app_settings

db_url = (f"postgresql+asyncpg://{get_app_settings().POSTGRES_USER}:{get_app_settings().POSTGRES_PASSWORD}@{get_app_settings().POSTGRES_HOST}"
          f":{get_app_settings().POSTGRES_PORT}/{get_app_settings().POSTGRES_DB}")
database = Database(db_url)

metadata = MetaData()
Base = declarative_base(metadata=metadata)
