import os
from functools import lru_cache
from jinja2 import Template


@lru_cache
def get_templates() -> dict[str, Template]:
    templates = dict()
    for file in os.listdir('templates'):
        if file.endswith('.html'):
            with open(f'templates/{file}') as f:
                templates[file[:-5]] = Template(f.read())

    return templates


@lru_cache
def get_vip_templates() -> dict[str, Template]:
    templates = dict()
    for file in os.listdir('vip_templates'):
        if file.endswith('.html'):
            with open(f'vip_templates/{file}') as f:
                templates[file[:-5]] = Template(f.read())

    return templates
