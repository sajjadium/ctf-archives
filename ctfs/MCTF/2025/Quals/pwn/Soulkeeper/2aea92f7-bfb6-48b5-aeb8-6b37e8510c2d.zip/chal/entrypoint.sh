#!/bin/bash

socat TCP-LISTEN:7331,fork,reuseaddr,bind=0.0.0.0 EXEC:"timeout -s SIGKILL 60 env LD_PRELOAD=/app/libc.so.6 /app/soulkeeper"
