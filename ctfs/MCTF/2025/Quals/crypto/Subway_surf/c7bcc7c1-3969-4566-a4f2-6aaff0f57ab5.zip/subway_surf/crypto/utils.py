from random import randint
from Crypto.Util.number import isPrime

def generate_first_prime(magic_number: int, n=512) -> int:
    while True:
        s = randint(2**n, 2**(n + 1) - 1)
        t = magic_number * s**2 + 1
        p = t // 4
        if isPrime(p) and t % 4 == 0:
            return p
