import pickle
import base64
import redis
from flask import Flask, render_template, jsonify, request, session
from flask_session import Session
from crypto.cipher import EncryptParameters, CheckParameters, flask_secret

app = Flask(__name__)
app.config['SECRET_KEY'] = flask_secret()
app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_REDIS'] = redis.from_url('redis://redis:6379')
app.config['SESSION_PERMANENT'] = False
Session(app)

@app.route('/')
def index():
    encrypt = EncryptParameters()
    ct, known_modules, primes = encrypt.get_ct()
    serialized_primes = base64.b64encode(pickle.dumps(primes)).decode('utf-8')
    session['primes'] = serialized_primes
    serialized_modules = base64.b64encode(pickle.dumps(known_modules)).decode('utf-8')
    session['modules'] = serialized_modules
    return render_template('index.html', ct_string=bytes.hex(ct))

@app.route('/validate_default', methods=['POST'])
def validate_default():
    ct = request.json
    serialized = session.get('primes', [])
    primes = pickle.loads(base64.b64decode(serialized))
    decrypt = CheckParameters(bytes.fromhex(ct['byte_string']), primes)
    result, comment = decrypt.check_params()
    return jsonify({'access': result, 'comment': comment})  

@app.route('/get_known_modules', methods=['GET'])
def get_known_modules():
    serialized = session.get('modules', '')
    known_modules = pickle.loads(base64.b64decode(serialized.encode('utf-8') if isinstance(serialized, str) else serialized))
    return jsonify({'modules': known_modules})

@app.route('/validate_custom', methods=['POST'])
def validate_custom():
    data = request.json
    ct_hex = data['ct_string']
    primes_base64 = data['primes']
    primes = pickle.loads(base64.b64decode(primes_base64))
    decrypt = CheckParameters(bytes.fromhex(ct_hex), primes)
    result, comment = decrypt.check_params()
    return jsonify({'access': result, 'comment': comment})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
