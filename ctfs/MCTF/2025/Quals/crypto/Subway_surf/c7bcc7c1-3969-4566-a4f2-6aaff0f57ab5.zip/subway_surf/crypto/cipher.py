from crypto.utils import generate_first_prime
from crypto.secret import params_data, AES_KEY, IV, FLAG, SECRET_KEY
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Util.number import getStrongPrime
from hashlib import sha256, pbkdf2_hmac
from os import urandom
from re import search


def flask_secret() -> bytes:
    return SECRET_KEY


class EncryptParameters:
    def __init__(self) -> None:
        self.primes = None

    def get_strong_primes(self, magic_number: int) -> list:
        primes = []
        for counter in range(1, 9):
            p = generate_first_prime(magic_number)
            q = getStrongPrime(512)
            primes.append(p)
            primes.append(q)
        
        return primes

    def encrypt(self, key: bytes, iv: bytes, pt: bytes) -> bytes:
        cipher = AES.new(key, AES.MODE_CBC, iv)
        ct = cipher.encrypt(pad(pt, AES.block_size))

        return iv + ct

    def expand_ct(self, complex_ct: bytes, cipher_length: int, key: bytes) -> bytes:
        expanded = bytearray(complex_ct)
        
        while len(expanded) < cipher_length:
            hmac = pbkdf2_hmac('sha256', expanded[-32:], key, 1, 32)
            expanded.extend(hmac)
        
        return bytes(expanded[:cipher_length])

    def mix_with_primes(self, ct: bytes, primes: list, cipher_length: int) -> bytes:
        key = sha256(str(primes).encode()).digest()
        salt = urandom(16)
        length_ct = len(ct).to_bytes(4, 'big')
        complex_ct = length_ct + ct + salt
        expanded_ct = self.expand_ct(complex_ct, cipher_length, key)
        final_ct = bytearray()
        key_cycle = key * (cipher_length // len(key) + 1)

        for i in range(cipher_length):
            final_ct.append(expanded_ct[i] ^ key_cycle[i])
        
        return bytes(final_ct)

    def get_ct(self) -> bytes | list:
        self.primes = self.get_strong_primes(211)
        pt = params_data
        target_length = 1024
        ct = self.encrypt(AES_KEY, IV, pt)
        encoded = self.mix_with_primes(ct, self.primes, target_length)
        known_modules = [self.primes[i] * self.primes[i + 1] for i in range(0, len(self.primes), 2)]

        return encoded, known_modules, self.primes


class CheckParameters:
    def __init__(self, ct: bytes, primes: list) -> bytes:
        self.ct = ct
        self.primes = primes

    def unmix_primes(self) -> tuple:
        key = sha256(str(self.primes).encode()).digest()
        decrypted_data = bytearray()
        key_cycle = key * (len(self.ct) // len(key) + 1)

        for i in range(len(self.ct)):
            decrypted_data.append(self.ct[i] ^ key_cycle[i])
        
        length_ct = int.from_bytes(decrypted_data[:4], 'big')
        pt = decrypted_data[4:4 + length_ct]

        return bytes(pt)

    def check_params(self) -> bool | str:
        ct_with_iv = self.unmix_primes()
        cipher = AES.new(AES_KEY, AES.MODE_CBC, IV)
        decrypted = unpad(cipher.decrypt(ct_with_iv), AES.block_size)
        match = search(r'CARD_BALANCE:(\d{3});', decrypted.decode(errors='ignore'))
        if match:
            balance = int(match.group(1))
        if balance >= 300:
            return True, FLAG
        else:
            return False, "No entry, try again"
