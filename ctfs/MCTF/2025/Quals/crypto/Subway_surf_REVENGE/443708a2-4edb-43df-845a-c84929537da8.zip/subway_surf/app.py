import json
import redis
from flask import Flask, render_template, jsonify, request, session, abort
from flask_session import Session
from crypto.cipher import EncryptParameters, CheckParameters, flask_secret

app = Flask(__name__)
app.config['SECRET_KEY'] = flask_secret()
app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_REDIS'] = redis.from_url('redis://redis:6379')
app.config['SESSION_PERMANENT'] = False
Session(app)

def _validate_primes_schema(obj):
    if not isinstance(obj, (list, tuple)):
        return False
    max_items = 4096
    if len(obj) > max_items:
        return False
    for x in obj:
        if not isinstance(x, int):
            return False
        if x < 2 or x.bit_length() > 16384:
            return False
    return True

@app.route('/')
def index():
    encrypt = EncryptParameters()
    ct, known_modules, primes = encrypt.get_ct()

    session['primes_json'] = json.dumps(primes)
    session['modules_json'] = json.dumps(known_modules)

    return render_template('index.html',
                           ct_string=bytes.hex(ct),
                           )

@app.route('/validate_default', methods=['POST'])
def validate_default():
    data = request.get_json(silent=True) or {}
    if 'byte_string' not in data:
        abort(400)
    ct_hex = data['byte_string']

    try:
        primes = json.loads(session.get('primes_json', '[]'))
    except Exception:
        abort(400)

    if not _validate_primes_schema(primes):
        abort(400)

    decrypt = CheckParameters(bytes.fromhex(ct_hex), primes)
    result, comment = decrypt.check_params()
    return jsonify({'access': result, 'comment': comment})

@app.route('/get_known_modules', methods=['GET'])
def get_known_modules():
    try:
        known_modules = json.loads(session.get('modules_json', '[]'))
    except Exception:
        abort(400)
    return jsonify({'modules': known_modules})

@app.route('/validate_custom', methods=['POST'])
def validate_custom():

    data = request.get_json(silent=True) or {}
    ct_hex = data.get('ct_string')
    if not ct_hex:
        abort(400)

    primes = None

    if primes is None:
        primes_json = data.get('primes_json')
        if not isinstance(primes_json, str):
            abort(400)
        try:
            primes = json.loads(primes_json)
        except Exception:
            abort(400)

    if not _validate_primes_schema(primes):
        abort(400)

    decrypt = CheckParameters(bytes.fromhex(ct_hex), primes)
    result, comment = decrypt.check_params()
    return jsonify({'access': result, 'comment': comment})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
