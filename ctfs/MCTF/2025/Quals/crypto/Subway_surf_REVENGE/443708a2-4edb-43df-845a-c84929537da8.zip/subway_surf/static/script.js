document.addEventListener('DOMContentLoaded', function() {
    const card = document.getElementById('card');
    const validator = document.getElementById('validator');
    
    card.addEventListener('dragstart', function(e) {
        e.dataTransfer.setData('text/plain', 'card');
        setTimeout(() => {
            card.style.opacity = '0.5';
        }, 0);
    });
    
    card.addEventListener('dragend', function() {
        card.style.opacity = '1';
        card.style.transform = 'none';
        validator.classList.remove('active');
    });

    validator.addEventListener('dragover', function(e) {
        e.preventDefault();
    });
    
    validator.addEventListener('dragenter', function(e) {
        e.preventDefault();
        validator.classList.add('active');
    });
    
    validator.addEventListener('dragleave', function() {
        validator.classList.remove('active');
    });
    
    validator.addEventListener('drop', function(e) {
        e.preventDefault();
        
        fetch('/validate_default', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({byte_string: ct_string})
        })
        .then(response => response.json())
        .then(data => {
            if (data.access) {
                showNotification(`Access granted: ${data.comment}`, 'success');
            } else {
                showNotification(`Access denied: ${data.comment}`, 'error');
            }
        });
    });
});