package controllers

import (
	"context"
	"graph/models"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
)

type PersonController struct {
	driver neo4j.DriverWithContext
}

func NewPersonController(driver neo4j.DriverWithContext) *PersonController {
	return &PersonController{driver: driver}
}

func (ctrl *PersonController) GetPerson(c *gin.Context) {
	personID := c.Param("id")

	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())

	query := `MATCH (p:Person {id: $id}) RETURN p`
	result, err := session.Run(context.Background(), query, map[string]interface{}{"id": personID})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	record, err := result.Single(context.Background())
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Person not found"})
		return
	}

	node := record.Values[0].(neo4j.Node)
	person := models.Person{
		ID:   node.Props["id"].(string),
		Name: node.Props["name"].(string),
		Born: int(node.Props["born"].(int64)),
	}
	c.JSON(http.StatusOK, person)
}

func (ctrl *PersonController) GetPersons(c *gin.Context) {
	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())

	query := `MATCH (p:Person) RETURN p ORDER BY p.name`
	result, err := session.Run(context.Background(), query, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	var persons []models.Person
	for result.Next(context.Background()) {
		record := result.Record()
		node := record.Values[0].(neo4j.Node)
		person := models.Person{
			ID:   node.Props["id"].(string),
			Name: node.Props["name"].(string),
			Born: int(node.Props["born"].(int64)),
		}
		persons = append(persons, person)
	}

	if err = result.Err(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, persons)
}
