package controllers

import (
	"context"
	"fmt"
	"graph/models"
	"log"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
)

type MovieController struct {
	driver neo4j.DriverWithContext
}

func NewMovieController(driver neo4j.DriverWithContext) *MovieController {
	return &MovieController{driver: driver}
}

func (ctrl *MovieController) CreateMovie(c *gin.Context) {
	var movie models.Movie
	if err := c.ShouldBindJSON(&movie); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeWrite})
	defer session.Close(context.Background())

	query := `CREATE (m:Movie {id: $id, title: $title, released: $released, tagline: $tagline}) RETURN m`
	result, err := session.Run(context.Background(), query, map[string]interface{}{
		"id":       movie.ID,
		"title":    movie.Title,
		"released": movie.Released,
		"tagline":  movie.Tagline,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	record, err := result.Single(context.Background())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve created movie"})
		return
	}

	node := record.Values[0].(neo4j.Node)
	createdMovie := models.Movie{
		ID:       node.Props["id"].(string),
		Title:    node.Props["title"].(string),
		Released: int(node.Props["released"].(int64)),
		Tagline:  node.Props["tagline"].(string),
	}
	c.JSON(http.StatusCreated, createdMovie)
}

func (ctrl *MovieController) GetMovie(c *gin.Context) {
	movieID := c.Param("id")

	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())

	query := `
		MATCH (m:Movie {id: $id})
		OPTIONAL MATCH (p:Person)-[a:ACTED_IN]->(m)
		OPTIONAL MATCH (d:Person)-[:DIRECTED]->(m)
		RETURN m, COLLECT(DISTINCT {actor: p, roles: a.roles}) AS actors, COLLECT(DISTINCT d) AS directors
	`
	result, err := session.Run(context.Background(), query, map[string]interface{}{"id": movieID})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	record, err := result.Single(context.Background())
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Movie not found"})
		return
	}

	node := record.Values[0].(neo4j.Node)
	movie := models.Movie{
		ID:       node.Props["id"].(string),
		Title:    node.Props["title"].(string),
		Released: int(node.Props["released"].(int64)),
		Tagline:  node.Props["tagline"].(string),
	}

	movieWithRelations := models.MovieWithRelations{
		Movie: movie,
	}

	actorsData := record.Values[1].([]interface{})
	for _, actorData := range actorsData {
		actorMap := actorData.(map[string]interface{})
		if actorMap["actor"] != nil {
			actorNode := actorMap["actor"].(neo4j.Node)
			roles := []string{}
			if actorMap["roles"] != nil {
				for _, role := range actorMap["roles"].([]interface{}) {
					roles = append(roles, role.(string))
				}
			}
			movieWithRelations.Actors = append(movieWithRelations.Actors, models.PersonWithRoles{
				Person: models.Person{
					ID:   actorNode.Props["id"].(string),
					Name: actorNode.Props["name"].(string),
					Born: int(actorNode.Props["born"].(int64)),
				},
				Roles: roles,
			})
		}
	}

	// Extract directors
	directorsData := record.Values[2].([]interface{})
	for _, directorData := range directorsData {
		if directorData != nil {
			directorNode := directorData.(neo4j.Node)
			movieWithRelations.Directors = append(movieWithRelations.Directors, models.Person{
				ID:   directorNode.Props["id"].(string),
				Name: directorNode.Props["name"].(string),
				Born: int(directorNode.Props["born"].(int64)),
			})
		}
	}

	c.JSON(http.StatusOK, movieWithRelations)
}

func (ctrl *MovieController) GetMovies(c *gin.Context) {
	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())

	query := `MATCH (m:Movie) RETURN m ORDER BY m.title`
	result, err := session.Run(context.Background(), query, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	var movies []models.Movie
	for result.Next(context.Background()) {
		record := result.Record()
		node := record.Values[0].(neo4j.Node)
		movie := models.Movie{
			ID:       node.Props["id"].(string),
			Title:    node.Props["title"].(string),
			Released: int(node.Props["released"].(int64)),
			Tagline:  node.Props["tagline"].(string),
		}
		movies = append(movies, movie)
	}

	if err = result.Err(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	c.JSON(http.StatusOK, movies)
}

func (ctrl *MovieController) UpdateMovie(c *gin.Context) {
	movieID := c.Param("id")
	var movie models.Movie
	if err := c.ShouldBindJSON(&movie); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeWrite})
	defer session.Close(context.Background())

	query := `
		MATCH (m:Movie {id: $id})
		SET m.title = $title, m.released = $released, m.tagline = $tagline
		RETURN m
	`
	result, err := session.Run(context.Background(), query, map[string]interface{}{
		"id":       movieID,
		"title":    movie.Title,
		"released": movie.Released,
		"tagline":  movie.Tagline,
	})
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	record, err := result.Single(context.Background())
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "Movie not found or failed to update"})
		return
	}

	node := record.Values[0].(neo4j.Node)
	updatedMovie := models.Movie{
		ID:       node.Props["id"].(string),
		Title:    node.Props["title"].(string),
		Released: int(node.Props["released"].(int64)),
		Tagline:  node.Props["tagline"].(string),
	}
	c.JSON(http.StatusOK, updatedMovie)
}

func (ctrl *MovieController) GetMovieActors(c *gin.Context) {
	title := c.Query("title")
	blocked := ",!@ ;'|&${}<>"
	if strings.ContainsAny(title, blocked) {
		c.JSON(http.StatusForbidden, gin.H{"error": "Forbidden characters!"})
		return
	}
	fmt.Println(title)
	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())
	query := "MATCH (:Movie {title: '" + title + "' })<-[:ACTED_IN]-(actor:Person) RETURN actor"
	fmt.Println(query)
	result, err := session.Run(context.Background(), query, nil)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var results []map[string]interface{}
	for result.Next(context.Background()) {
		record := result.Record()
		row := make(map[string]interface{})
		for _, key := range record.Keys {
			row[key], _ = record.Get(key)
		}
		results = append(results, row)
	}

	if err := result.Err(); err != nil {
		log.Fatal(err)
	}

	// Wrap in your own JSON structure
	response := map[string]interface{}{
		"result": results,
	}
	if err = result.Err(); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}
	c.JSON(http.StatusOK, response)

}
func (ctrl *MovieController) GetGraphData(c *gin.Context) {
	session := ctrl.driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeRead})
	defer session.Close(context.Background())

	query := `
		MATCH (n) OPTIONAL MATCH (n)-[r]->(m)
		RETURN collect(DISTINCT n) AS nodes, collect(DISTINCT {id: id(r), start: id(startNode(r)), end: id(endNode(r)), type: type(r), properties: properties(r)}) AS relationships
	`
	result, err := session.Run(context.Background(), query, nil)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	record, err := result.Single(context.Background())
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to retrieve graph data"})
		return
	}

	// Process nodes
	neo4jNodes := record.Values[0].([]interface{})
	nodes := []map[string]interface{}{}
	for _, n := range neo4jNodes {
		node := n.(neo4j.Node)
		nodeProps := node.Props
		nodeProps["id"] = node.Id
		nodeProps["labels"] = node.Labels
		nodes = append(nodes, nodeProps)
	}

	// Process relationships
	neo4jRelationships := record.Values[1].([]interface{})
	edges := []map[string]interface{}{}
	for _, r := range neo4jRelationships {
		relMap := r.(map[string]interface{})
		// vis.js expects 'from' and 'to' for edges
		relMap["from"] = relMap["start"]
		relMap["to"] = relMap["end"]
		relMap["label"] = relMap["type"] // Use relationship type as label
		edges = append(edges, relMap)
	}

	c.JSON(http.StatusOK, gin.H{
		"nodes": nodes,
		"edges": edges,
	})
}
