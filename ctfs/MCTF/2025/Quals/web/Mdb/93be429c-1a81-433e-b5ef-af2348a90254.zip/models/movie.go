package models

type Movie struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	Released int    `json:"released"`
	Tagline  string `json:"tagline"`
}

type MovieWithRelations struct {
	Movie
	Actors    []PersonWithRoles `json:"actors"`
	Directors []Person          `json:"directors"`
}
