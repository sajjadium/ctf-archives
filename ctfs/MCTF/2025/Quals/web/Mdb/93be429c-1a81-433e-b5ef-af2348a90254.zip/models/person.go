package models

type Person struct {
	ID   string `json:"id"`
	Name string `json:"name"`
	Born int    `json:"born"`
}

type PersonWithRoles struct {
	Person
	Roles []string `json:"roles"`
}
