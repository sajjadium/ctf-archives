const API_BASE_URL = '/api';

let network = null;

async function fetchData(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error("Error fetching data:", error);
        alert("Failed to fetch graph data: " + error.message);
        return null;
    }
}

async function drawGraph() {
    const graphData = await fetchData(`${API_BASE_URL}/graph`);
    if (!graphData) {
        return;
    }
    const nodesData = graphData.nodes.map(node => {
        let label = '';
        let color = '#97C2E4';
        if (node.labels.includes('Movie')) {
            label = node.title || `Movie ID: ${node.id}`;
            color = '#FFCC00';
        } else if (node.labels.includes('Person')) {
            label = node.name || `Person ID: ${node.id}`;
            color = '#7BE141';
        } else {
            label = `ID: ${node.id}`;
        }

        return {
            id: node.id,
            label: label,
            group: node.labels[0],
            color: color,
        };
    });

    const edgesData = graphData.edges.map(edge => {

        return {
            from: edge.from,
            to: edge.to,
            label: edge.type?.replace(/_/g, " ")?.toLowerCase(),
            arrows: 'to',
        };
    });

    const nodes = new vis.DataSet(nodesData);
    const edges = new vis.DataSet(edgesData);

    const data = { nodes, edges };

    const options = {
        nodes: {
            shape: 'dot',
            size: 16,
            font: {
                size: 12,
                color: '#333'
            },
            borderWidth: 2
        },
        edges: {
            width: 2,
            font: {
                align: 'top'
            },
            color: { inherit: 'from' }
        },
        physics: {
            forceAtlas2Based: {
                gravitationalConstant: -26,
                centralGravity: 0.005,
                springLength: 230,
                springConstant: 0.18,
                damping: 0.4
            },
            maxVelocity: 146,
            solver: 'forceAtlas2Based',
            timestep: 0.35,
            stabilization: { iterations: 150 }
        },
        interaction: {
            hover: true,
            tooltipDelay: 200,
            zoomView: true
        }
    };

    const container = document.getElementById('graph-container');
    if (network !== null) {
        network.destroy();
    }

    network = new vis.Network(container, data, options);
    network.on("click", function (params) {
        if (params.nodes.length > 0) {
            const clickedNodeId = params.nodes[0];
            const clickedNode = nodes.get(clickedNodeId);
            console.log("Clicked node:", clickedNode);
        }
    });
}

async function highlightMovies() {
    const res = await fetchData(`${API_BASE_URL}/movies`);
    const movieIds = res.map(m => parseInt(m.id));
    console.log(movieIds)

    network.body.data.edges.forEach(edge => {
        network.body.data.edges.update({ id: edge.id, color: { color: '#ccc' }, width: 1 });
    });
    network.body.data.nodes.forEach(node => {
        if (movieIds.includes(node.id)) {
            network.body.data.nodes.update({ id: node.id, color: { background: '#FFCC00', border: '#E6B800' } });
        } else {
            network.body.data.nodes.update({ id: node.id, color: { background: '#E0E0E0', border: '#BDBDBD' } });
        }
    });
}

async function highlightPersons() {
    const res = await fetchData(`${API_BASE_URL}/persons`);
    const personIds = res.map(p => parseInt(p.id));
    network.body.data.edges.forEach(edge => {
        network.body.data.edges.update({ id: edge.id, color: { color: '#ccc' }, width: 1 });
    });

    network.body.data.nodes.forEach(node => {
        if (personIds.includes(node.id)) {
            network.body.data.nodes.update({ id: node.id, color: { background: '#7BE141', border: '#5EA32F' } });
        } else {
            network.body.data.nodes.update({ id: node.id, color: { background: '#E0E0E0', border: '#BDBDBD' } });
        }
    });

}

async function showMovieActors() {
    const res = await fetchData(`${API_BASE_URL}/movies/getActors?title=Inception`);
    console.log("Movie actors:", res);

    network.body.data.edges.forEach(edge => {
        if (edge.label && edge.label.includes("acted in")) {
            network.body.data.edges.update({ id: edge.id, color: { color: '#0099FF' }, width: 3 });
        } else {
            network.body.data.edges.update({ id: edge.id, color: { color: '#ccc' }, width: 1 });
        }
    });
}


document.getElementById('btn-all').addEventListener('click', highlightMovies);
document.getElementById('btn-actors').addEventListener('click', showMovieActors);
document.getElementById('btn-persons').addEventListener('click', highlightPersons);


document.addEventListener('DOMContentLoaded', () => {
    drawGraph();
    document.getElementById('refreshGraph').addEventListener('click', drawGraph);
});
