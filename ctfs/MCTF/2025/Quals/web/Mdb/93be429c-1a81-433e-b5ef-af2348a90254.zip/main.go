package main

import (
	"context"
	"graph/controllers"
	"graph/database"
	"log"
	"os"
	"time"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"github.com/neo4j/neo4j-go-driver/v5/neo4j"
)

func main() {
	driver, err := database.InitDb(os.Getenv("NEO4J_URI"), os.Getenv("NEO4J_USERNAME"), os.Getenv("NEO4J_PASSWORD"))
	if err != nil {
		log.Fatalf("Could not connect to Neo4j: %v", err)
	}
	defer driver.Close(context.Background())

	// Initialize Gin router
	r := gin.Default()
	r.Use(cors.New(cors.Config{
		AllowOrigins: []string{"*"},
		AllowMethods: []string{"*"},
		AllowHeaders: []string{"*"},
		MaxAge:       12 * time.Hour,
	}))
	movieController := controllers.NewMovieController(driver)
	personController := controllers.NewPersonController(driver)
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"message": "pong"})
	})

	r.POST("/movies", movieController.CreateMovie)
	r.GET("/movies/:id", movieController.GetMovie)
	r.GET("/movies", movieController.GetMovies)
	r.GET("/movies/getActors", movieController.GetMovieActors)
	r.GET("/graph", movieController.GetGraphData)
	r.PUT("/movies/:id", movieController.UpdateMovie)

	r.GET("/persons/:id", personController.GetPerson)
	r.GET("/persons", personController.GetPersons)

	createInitialData(driver)
	log.Println("Initial data created.")

	log.Printf("Server starting on port %s", os.Getenv("PORT"))
	if err := r.Run(":" + os.Getenv("PORT")); err != nil {
		log.Fatalf("Server failed to start: %v", err)
	}
}

func createInitialData(driver neo4j.DriverWithContext) {
	session := driver.NewSession(context.Background(), neo4j.SessionConfig{AccessMode: neo4j.AccessModeWrite})
	defer session.Close(context.Background())

}
