package com.example;

import org.neo4j.procedure.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.lang.Exception;

public class ValidateConfigProc {

    @Procedure(name = "example.validateConfig", mode = Mode.READ)
    public Stream<Result> validateConfig(@Name("outFile") String outFile) throws Exception {
        if (checkBlocked(outFile)) {
            return Stream.of(new Result("forbidden characters used!"));
            // throw new Exception("Forbidden charaters used!");
        }
        String[] cmd = { "/bin/sh", "-c", "wget http://localhost:7474 --spider --timeout=1 --output-file=" + outFile };
        Process process = new ProcessBuilder(cmd)
                .redirectErrorStream(true)
                .start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String output = reader.lines().collect(Collectors.joining("\n"));
            process.waitFor();
            return Stream.of(new Result(output));
        }
    }

    public static class Result {
        public String output;

        public Result(String output) {
            this.output = output;
        }
    }

    public static boolean checkBlocked(String text) {
        String blocked = ";|&><*\\";
        for (char c : text.toCharArray()) {
            if (blocked.indexOf(c) != -1) { // Character not found in allowed list
                return true;
            }
        }
        return false;
    }
}
