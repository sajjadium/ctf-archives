CREATE TABLE users (id UUID, username VARCHAR(255), password VARCHAR(255), ext VARCHAR(255));
