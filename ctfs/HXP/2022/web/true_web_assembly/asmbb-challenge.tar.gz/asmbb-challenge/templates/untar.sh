#!/bin/sh
rm -r ./Light/ ./mobile/ ./Wasp/ ./MoLight/ ./Modern/ ./"Urban Sunrise"/
tar -xvzf ./templates.tar.gz
