#!/bin/bash

cd /home/user || exit
./chal.py