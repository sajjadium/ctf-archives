# Conversationalist

> Just one more message encryption scheme, this one covers everything, I promise.

## Setup Notes

* The server is able to handle multiple connections at a time, so in theory **only 1 remote instance is necessary**.
