# Build

```sh
docker build . -t pincer
```

# Run

```sh
docker run --rm --name pincer -p 8000:8000 pincer
```

# Info

The bot runs every 2 minutes, be patient

We advise you to start a new instance of the challenge once you think you can solve it

Be fast, so you don't miss the bot's very first swap, otherwise, you may not be able to get the flag
