import { LocaleInput } from '@fullcalendar/common';
declare const _default: LocaleInput;
export default _default;
