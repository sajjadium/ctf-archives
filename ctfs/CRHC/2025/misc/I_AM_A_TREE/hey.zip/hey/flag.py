
answer = input("You wanna find FLAG? Y/N\n")

if answer.strip().lower() == 'y':
    print("FLAG IS GONE!!!!!!!!")
elif answer.strip().lower() == 'n':
    print("OK BYE~")
else:
    print("Invalid input. Only Y or N is accepted.")
