Note: The behaviour might be different if it is not run inside docker.

```
chmod +x ./src/run.sh
docker compose up -d
docker compose attach app
```
