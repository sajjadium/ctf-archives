#!/bin/sh

python /app/src/a.pyc
