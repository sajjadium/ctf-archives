#!/bin/sh
flag="<redacted>" /home/pwn/chal