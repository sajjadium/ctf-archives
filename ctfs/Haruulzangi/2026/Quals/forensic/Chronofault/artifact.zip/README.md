<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# CHRONOFAULT

**Category:** Forensics · **Difficulty:** Medium

---

> `// PARITY REGISTRY :: IR CASE 2041-0314`

Somebody walked a projected service token out of the `commons-core` namespace
and pulled the parity OTP secret. Four megabytes left for an off-register host,
and the pairing rotation ran an hour later than it should have.

Our on-call analyst already closed this. He sorted every log by its timestamp,
found the session that touched `/api/v1/ledger/issue` a tenth of a second before
the core accepted a role header, and named a contractor.

The contractor's counterpart filed a chronyc dump in her defence.

The DMZ segment has not reached an NTP server since the firewall change on
2041-03-02. Two of these five hosts have been free-wheeling on their RTC for
twelve days. One of them stamps the log our analyst sorted by.

A timeline is an accusation. Rebuild this one properly, then open the escrow.

---

## Artifacts

```
artifacts/
    edge-waf.log        WAF, DMZ segment
    core-app.jsonl      application and token service, in-cluster
    bastion-auth.log    syslog auth from the jump host, DMZ segment
    k8s-audit.jsonl     API server audit
    netflow.csv         collector flow records
    ntp/                what the NOC had to say about all this

unlock.py               escrow unsealer
vault.sealed            the escrow
```

## The escrow wants three facts

1. the session that actually drove the intrusion
2. the moment the WAF passed the authorization bypass, in **true UTC**, as
   whole epoch seconds
3. the service account the read authenticated as

`unlock.py` will not tell you which one you got wrong, and its deliberately slow
derivation makes guessing impractical.

## Notes

- One host's clock is correct and can be trusted. Work out which, and why.
- Two log sources record the same events. That is your ruler.
- Flag format: `HZ{...}`
