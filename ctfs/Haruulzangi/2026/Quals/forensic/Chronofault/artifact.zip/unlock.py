#!/usr/bin/env python3
"""
PARITY REGISTRY :: incident escrow unsealer

The incident flag is sealed under three facts about the intrusion. Supply them
and the escrow opens. Supply anything else and it does not, and it will not tell
you which part was wrong.

    ./unlock.py <session-id> <bypass-utc-epoch-seconds> <service-account>

  session-id              the session that actually drove the intrusion, exactly
                          as it appears in the WAF log, e.g. SESS-0123abcd

  bypass-utc-epoch-secs   the moment the WAF passed the authorization bypass, in
                          TRUE UTC, as whole seconds since the epoch.

                          Note the word TRUE. The WAF prints its own idea of the
                          time and its own idea of the time is wrong. Whole
                          seconds, so a few milliseconds of measurement error
                          will not cost you the flag.

  service-account         the service account the secret read authenticated as,
                          short name only, e.g. svc-something

Derivation is deliberately slow (PBKDF2-HMAC-SHA256, 2000000 rounds), about a
second and a half per guess. Do the analysis.

Worked example, so the timestamp format is not the puzzle:

    2041-03-14T18:40:00Z  ->  2246899200
    2041-03-14T18:41:07Z  ->  2246899267

    python3 -c "import datetime as d; \
      print(int(d.datetime.fromisoformat('2041-03-14T18:40:00+00:00').timestamp()))"
"""
import sys, os, hashlib

SEALED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vault.sealed")


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        return 2

    sid, ms, acct = sys.argv[1].strip(), sys.argv[2].strip(), sys.argv[3].strip()
    try:
        ms = str(int(ms))
    except ValueError:
        print("[!] the timestamp must be an integer number of seconds")
        return 2

    blob = open(SEALED, "rb").read()
    if blob[:5] != b"HZCF\x01":
        print("[!] escrow blob is corrupt")
        return 1
    digest, sealed = blob[5:13], blob[13:]

    material = f"{sid}|{ms}|{acct}"
    sys.stderr.write("[*] deriving ... ")
    sys.stderr.flush()
    key = hashlib.pbkdf2_hmac("sha256", material.encode(), b"chronofault/hz2026", 2_000_000, 32)
    ks = hashlib.shake_256(key).digest(len(sealed))
    out = bytes(a ^ b for a, b in zip(sealed, ks))
    sys.stderr.write("done\n")

    if hashlib.sha256(out).digest()[:8] == digest:
        print(out.decode())
        return 0

    print("[!] escrow did not open. one or more of the three facts is wrong.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
