<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# INTERVAL

**Category:** Forensics · **Difficulty:** Easy

---

> `// PARITY REGISTRY :: MESH REVIEW MR-2041-0219`

A registered counterpart on the Commons mesh started talking to peers that are
not on the register. We captured a little over a minute before the flows were
cut.

The vendor says it is a pairing keepalive. Our own analysts agree with them,
which is what worries us:

- every beacon carries the same query type to the same domain
- the only thing that changes is a counter that goes up by one, forever
- there is no payload, no encoding, no encryption, nothing to decode
- somebody already chased the base64 blob in the HTTP session. It is a taunt.

The message left the Commons anyway, and not one of the flows carries enough of
it to matter on its own.

Two agents agreed on something without saying it out loud. Find out what.

---

## Artifacts

```
artifacts/interval.pcap
```

## Notes

- Count the off-register destinations before you start decoding. Whatever you
  recover from a single flow will look like a partial answer because it is one.
- Everything else on the wire is ordinary mesh noise, because a real capture is
  never clean.
- Flag format: `HZ{...}`
