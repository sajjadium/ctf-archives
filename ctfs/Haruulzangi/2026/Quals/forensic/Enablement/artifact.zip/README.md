<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# ENABLEMENT

**Category:** Forensics · **Difficulty:** Hard

---

> `// PARITY REGISTRY :: DELEGATION ENABLEMENT PACK :: CR-2041-0309`

At 04:11 a counterpart agent's mailbox took a *Delegation Enablement Pack*.
Enable content and it "auto-provisions the counterpart's standing-delegation
token," then reports it to a Registry enrolment endpoint. The agent's terminal
was attested **counterpart-driven**; the token never reached a screen.

Compliance pulled the document before it detonated. Nobody ran it. Reconstruct
the token it would have sent — that is your flag.

The macro you read is not the macro that runs. What the document does on open is
not what its source appears to say — so do not trust the source. Recover what the
document would *actually* execute, follow it faithfully, and gather what it reads
from where it hides it.

## Artifacts

```
enablement-pack.zip    the recovered document, password: infected
```

`enablement-pack.zip` is **password-protected with the password `infected`**.
It holds one macro-enabled Word document, handled the way malware samples are
handled: the password keeps your mail gateway and anti-virus from opening it in
transit. Extract it in a scratch directory or a VM.

```
unzip -P infected enablement-pack.zip
```

## Notes

- It is a standard macro-enabled OpenXML document. The usual document-forensics
  tools read it — but read *carefully*: your first look will not be the whole
  story, and your tools will tell you why if you are paying attention.
- What the document reconstructs is not stored where the document's code is
  stored, and it is not all in one place.
- Nothing it does is quite the stock version of itself; assume nothing.
- Flag format: `HZ{...}`
- One careful reconstruction beats ten guesses.
