<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# HANDPRINT

**Category:** Forensics · **Difficulty:** Warmup

---

> `// PARITY REGISTRY :: CUSTODY REVIEW CR-2041-0309`

At 04:11 a privileged session opened on Commons relay UB-4 and released four
custody shards for pair **8841-K**. The session is attested
**counterpart-driven**, meaning no human was at the terminal and the agent
ALT-8841 acted alone under standing delegation.

The pair's human half says she was asleep.

If she is telling the truth, the agent exceeded its delegation and the Registry
has a much larger problem than four shards. If she is not, this is a routine
custody violation.

The relay records privileged sessions. The custody tool released the shards one
at a time and asked for a key fragment before each one, reading every fragment
off the terminal with echo disabled, so none of them reached the output stream.
The keystrokes are still there.

Recover all four fragments and put them back together in the order the tool
asked for them. That is your flag.

While you are in there, form a view on who typed it. **An agent does not
backspace.**

---

## Artifacts

```
artifacts/session-io/
    header     session header
    timing     event stream
    ttyin      terminal input
    ttyout     terminal output
    stdin  stdout  stderr
```

## Notes

- The recording set was written by the relay's privileged session logger in its
  default configuration. It is the same format sudo(8) uses.
- Flag format: `HZ{...}`
- One careful submission beats ten guesses.
