// Minimal runner for the counterpart gate.
//   node runner.mjs gate.wasm "HZ{your_candidate_flag_here}"
// Prints whether the candidate satisfies the embedded bytecode check.
import { readFileSync } from 'node:fs';

const [, , wasmPath, candidate] = process.argv;
if (!wasmPath || candidate === undefined) {
  console.error('usage: node runner.mjs <gate.wasm> "<candidate flag>"');
  process.exit(2);
}

const bytes = readFileSync(wasmPath);
const { instance } = await WebAssembly.instantiate(bytes, {});
const { memory, get_input, check } = instance.exports;

const input = Buffer.from(candidate, 'latin1');
const ptr = get_input();
new Uint8Array(memory.buffer).set(input, ptr);

const ok = check(input.length) === 1;
console.log(ok ? 'Correct — that is the flag.' : 'Incorrect.');
process.exit(ok ? 0 : 1);
