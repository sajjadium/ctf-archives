<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# AUTOMATON

**Category:** Reversing · **Difficulty:** Hard

---

> `// PARITY REGISTRY :: COUNTERPART GATE :: NODE UB-4`

A counterpart agent guards its channel with a gate: hand it the right token and
it opens, hand it anything else and it stays shut. The gate does not compare
your token to a stored string — it runs your token through a little machine of
its own and checks the result. The machine, and what it checks against, are all
that ship. Recover the token it will accept. That is your flag.

## Artifacts

```
gate.wasm     the counterpart gate (a WebAssembly module)
run.html      load gate.wasm in a browser and test a candidate
runner.mjs    or test from a terminal: node runner.mjs gate.wasm "HZ{...}"
```

The module exports `get_input()` (address of a 64-byte input buffer) and
`check(len)` (returns 1 for the accepting token, 0 otherwise). It has no
network, no I/O, no side effects — everything it does is inside.

## Notes

- The gate holds a small **bytecode program** and an **interpreter** that runs
  it over your input, plus a sealed result it compares against. The logic you
  need is in the *program*, not in the exported functions.
- The check is a single accept/reject with no partial signal: one byte wrong
  anywhere and it rejects. Guessing does not converge — you have to understand
  the machine and run it backwards.
- Nothing depends on the outside world; there is no anti-debug and no trick.
  The whole answer is deterministically inside `gate.wasm`.
- Flag format: `HZ{...}`
