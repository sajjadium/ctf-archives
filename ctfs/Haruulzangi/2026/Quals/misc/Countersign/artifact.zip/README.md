<img src="logo/hz-logo.png" width="120" align="right" alt="Haruul Zangi">

# COUNTERSIGN

**Category:** Misc · **Difficulty:** Hard

---

> `// PARITY REGISTRY :: COMPLIANCE TAP :: KIOSK-COMMONS-0441`

Every civic kiosk logs one human signature and one counterpart signature for
every action. Compliance taps the kiosk's own internal wiring to prove it:
whatever the human typed, and whatever the counterpart showed back.

This capture is one such tap. A human typed a passphrase on the kiosk's
keypad, and a moment later the counterpart's own e-paper notice display
lit up. Both buses were sniffed at the same time, on the same wire harness.

## Artifacts

```
capture.vcd    the tap: six digital channels, one combined timeline
```

`capture.vcd` is a plain-text [VCD](https://en.wikipedia.org/wiki/Value_change_dump)
(Value Change Dump) file — the same open format tools like
[GTKWave](https://gtkwave.sourceforge.net/) or
[sigrok/PulseView](https://sigrok.org/wiki/PulseView) use for waveform
viewing. It declares six single-bit signals by name, so any VCD-aware tool
will label them for you without guessing:

| Signal      | Bus  | Role                                    |
|-------------|------|------------------------------------------|
| `i2c_sda`   | I2C  | data                                      |
| `i2c_scl`   | I2C  | clock                                     |
| `spi_sclk`  | SPI  | clock                                      |
| `spi_mosi`  | SPI  | data (kiosk → display)                    |
| `spi_cs`    | SPI  | chip select, active low                   |
| `spi_dc`    | SPI  | data/command select (0 = command, 1 = data) |

## The keypad

The keypad reports each keystroke as a single-byte I2C write. Every key is
a plain ASCII byte — letters, digits, or `0x0D` for Enter.

## The display

The display speaks a real, documented e-paper controller command set
(SSD1680-compatible — the public datasheet describes the exact RAM
addressing model this capture uses). It is not simply handed one blob of
pixels: the controller keeps its own RAM address window and X/Y counters,
and the framebuffer arrives in more than one `WRITE_RAM` burst. The order
bytes arrive on the wire is not the order they land in the image — only the
address-window commands say where each burst belongs, and a later write to
the same cells always wins.

The framebuffer itself is not sent in the clear.

## The task

Recover what the human typed. Recover what the counterpart showed back.

Flag format: `HZ{...}`
