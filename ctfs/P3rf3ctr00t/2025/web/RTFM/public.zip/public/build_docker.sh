#!/bin/bash
docker rm -f web-rtfm
docker build -t web-rtfm .
docker run --name=web-rtfm --rm -p 50000:5000 -it web-rtfm