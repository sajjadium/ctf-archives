from flask import Flask, render_template, request, jsonify, session
import requests
import os
import sqlite3
from urllib.parse import urlparse
from functools import wraps
import hashlib

app = Flask(__name__)
app.secret_key = 'PERFECTCTFSECRETKEY'


DB_PATH = 'users.db'


os.makedirs("/opt/manualFiles", exist_ok=True)

def init_db():
    
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password_hash TEXT NOT NULL,
                  is_admin INTEGER DEFAULT 0)''')
    
    
    try:
        c.execute("INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)",
                  ('guest', hashlib.sha256('guest123'.encode()).hexdigest(), 0))
    except sqlite3.IntegrityError:
        pass
    
    conn.commit()
    conn.close()

def get_db_connection():
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def user_exists(username):  
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = c.fetchone()
    conn.close()
    return user is not None

def get_user(username):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = c.fetchone()
    conn.close()
    return user

def create_user(username, password_hash):
    conn = get_db_connection()
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password_hash, is_admin) VALUES (?, ?, ?)",
                  (username, password_hash, 0))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        conn.close()
        return False

def make_user_admin(username):
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("UPDATE users SET is_admin = 1 WHERE username = ?", (username,))
    conn.commit()
    affected = c.rowcount
    conn.close()
    return affected > 0

# Initialize database on startup
init_db()

def makeUserAdmin(username):
    return make_user_admin(username)

def response(msg):
    return jsonify({'message': msg})

blocked_host = ["127.0.0.1", "0.0.0.0", "localhost"]

def isSafeUrl(url):
    for hosts in blocked_host:
        if hosts in url:
            return False
    
    return True

def downloadManual(url):
    safeUrl = isSafeUrl(url)
    if safeUrl:
        try:
            local_filename = url.split("/")[-1]
            if not local_filename:
                local_filename = "manual_file"
            
            r = requests.get(url, timeout=5)
            
            with open(f"/opt/manualFiles/{local_filename}", "wb") as f:
                for chunk in r.iter_content(chunk_size=1024):
                    if chunk:
                        f.write(chunk)
            return True
        except Exception as e:
            print(f"Error downloading: {e}")
            return False
    
    return False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/register', methods=['POST'])
def register():
    data = request.json
    username = data.get('username', '')
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'success': False, 'error': 'Username and password required'}), 400
    
    if user_exists(username):
        return jsonify({'success': False, 'error': 'User already exists'}), 400
    
    if len(password) < 6:
        return jsonify({'success': False, 'error': 'Password must be at least 6 characters'}), 400
    
    # Create new user
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    if create_user(username, password_hash):
        return jsonify({'success': True, 'message': 'User registered successfully'})
    else:
        return jsonify({'success': False, 'error': 'Registration failed'}), 400

@app.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username', '')
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'success': False, 'error': 'Username and password required'}), 400
    
    user = get_user(username)
    
    if not user:
        return jsonify({'success': False, 'error': 'Invalid username or password'}), 401
    
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    
    if user['password_hash'] != password_hash:
        return jsonify({'success': False, 'error': 'Invalid username or password'}), 401
    
    session['username'] = username
    session['is_admin'] = user['is_admin']
    
    return jsonify({
        'success': True, 
        'message': 'Logged in successfully'
    })

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Logged out successfully'})

@app.route('/api/profile', methods=['GET'])
def profile():
    username = session.get('username')
    
    if not username:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401
    
    user = get_user(username)
    
    if not user:
        return jsonify({'success': False, 'error': 'User not found'}), 404
    
    return jsonify({
        'success': True,
        'username': username
    })


@app.route('/addAdmin', methods=['GET'])
def addAdmin():
    username = request.args.get('username')
    
    if not username:
        return response('Invalid username'), 400
    
    result = makeUserAdmin(username)

    if result:
        return response('User updated!')
    return response('Invalid username'), 400

@app.route('/api/download', methods=['POST'])
def download():
    data = request.json
    url = data.get('url', '')
    
    if not url:
        return jsonify({'success': False, 'error': 'URL is required'}), 400
    
    if downloadManual(url):
        filename = url.split("/")[-1] or "manual_file"
        return jsonify({
            'success': True, 
            'message': f'Manual downloaded successfully',
            'filename': filename
        })
    else:
        return jsonify({'success': False, 'error': 'Failed to download manual'}), 400

@app.route('/api/list', methods=['GET'])
def list_files():
    try:
        files = os.listdir("/opt/manualFiles")
        return jsonify({'files': files})
    except:
        return jsonify({'files': []})

@app.route('/api/view/<filename>', methods=['GET'])
def view_file(filename):
    try:
        filepath = f"/opt/manualFiles/{filename}"
        if os.path.exists(filepath) and os.path.isfile(filepath):
            with open(filepath, 'r', errors='ignore') as f:
                content = f.read()
            return jsonify({'content': content})
        else:
            return jsonify({'error': 'File not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/admin/dashboard', methods=['GET'])
def admin_dashboard():
    username = session.get('username')
    
    if not username:
        return jsonify({'success': False, 'error': 'Not logged in'}), 401
    
    user = get_user(username)
    
    if not user:
        return jsonify({'success': False, 'error': 'User not found'}), 404
    
    if not user['is_admin']:
        return jsonify({'success': False, 'error': 'Access denied: Admin only'}), 403
    
    return jsonify({
        'success': True,
        'title': 'Admin Dashboard',
        'FLAG': 'flag\{example_flag_for_testing\}',
        'message': 'Admin panel accessed successfully'
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
