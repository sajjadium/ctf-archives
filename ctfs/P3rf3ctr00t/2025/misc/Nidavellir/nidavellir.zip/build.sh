#!/bin/bash
docker build -t nidavellir .
docker run -it --rm -p 12345:12345 --name nidavellir nidavellir
