from subprocess import Popen,PIPE,DEVNULL
from socketserver import BaseRequestHandler, ThreadingMixIn,TCPServer
from uuid import uuid4

banner = f"""
{'N I D A V E L L I R   -   E C H O   F O R G E':^80}\n
{'-'*80}\n
{'You stand before the Echo Forge of Nidavellir':^80}
{'The dwarves crafted it to test worthiness, not brute force':^80}
{'Whatever you enter here will be echoed back exactly as you typed it':^80}
{'But be warned: the forge accepts only a narrow set of characters':^80}
{'Stray outside its runic limits, and your words will be rejected':^80}
{'-'*80}\n
Forge your command with care...
"""


class Shell:
	def __init__(self):
		self.process = Popen(['/bin/sh'],stdin=PIPE,stdout=PIPE,stderr=DEVNULL,text=True,bufsize=1)

	def run(self, command):
		token = str(uuid4())
		full_command = f'{command}; echo {token}\n'

		self.process.stdin.write(full_command)
		self.process.stdin.flush()

		output_lines = []

		while True:
			line = self.process.stdout.readline()

			if not line:
				break

			if token in line:
				break

			output_lines.append(line.rstrip())

		return "\n".join(output_lines)

	def close(self):
		self.process.terminate()


class ThreadSvc(ThreadingMixIn,TCPServer):
	pass


class Service(BaseRequestHandler):
	def handle(self):
		self.send(banner)
		shell = Shell()
		while True:
			try:
				cmd = self.sanitize(self.receive("\033[1;32m> \033[0m"))
				self.send(shell.run(f'echo {cmd}'))
			except:
				break

	def send(self,string,newline=True):
		if newline: string += '\n'
		self.request.sendall(string.encode())

	def receive(self,prompt):
		self.send(prompt, newline=False)
		return self.request.recv(4096).strip().decode()

	def sanitize(self,string):
		blocklist = [' ','>','`',';','{','/','&','|','\"','$']
		if len(string) > 60:
			self.send('\033[1;31mtoo much input :(\033[0m')
			return ''
		for s in string:
			if s in blocklist:
				string = string.replace(s,'')
				self.send(f'\033[1;31mchar `{s}` is blocked!!\033[0m')
		return string


def main():
	host,port = '0.0.0.0',12345

	with ThreadSvc((host,port),Service) as server:
		print(f'Listening on {host}:{port}.. ')
		server.serve_forever()


if __name__ == '__main__':
	main()
