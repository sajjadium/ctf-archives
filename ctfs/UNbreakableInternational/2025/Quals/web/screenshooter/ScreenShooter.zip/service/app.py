import os
import logging
import subprocess

from flask import Flask, request, jsonify


APP_PORT = os.getenv('APP_PORT', 1234)
SERVICE_PORT = os.getenv('SERVICE_PORT', 5000)

app = Flask(__name__)

@app.route("/screenshot", methods=["GET"])
def screenshot():
    try:
        url = request.args.get("url", f"http://localhost:{APP_PORT}/text/test")
        verbose = request.args.get("verbose", "")

        command = ["wget", "-O-", "-q", url, verbose]
        logging.info(f"Running command: {' '.join(command)}")

        p = subprocess.run(command, shell=False, capture_output=True)
        if not p.stdout and p.returncode != 0:
            return jsonify({"error": "Error getting screenshot"}), 400

        return jsonify({"result": p.stdout.decode()}), 200
    except Exception as e:
        logging.error(e)
        return jsonify({"error": str(e)}), 400


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=SERVICE_PORT, debug=False)
