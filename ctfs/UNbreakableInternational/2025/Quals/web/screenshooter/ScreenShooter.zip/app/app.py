import os
import random
import requests

from flask import Flask, render_template, request, redirect, url_for, session
from urllib.parse import urljoin


APP_PORT = os.getenv('APP_PORT', 1234)
SERVICE_PORT = os.getenv('SERVICE_PORT', 5000)
FONTS = ['Press Start 2P', 'Bangers', 'Rubik Glitch', 'Fredericka the Great', 'Nosifer', 'Monoton']
SCREENSHOT_SERVICE = f'http://127.0.0.1:{SERVICE_PORT}/screenshot'
users = {}

app = Flask(__name__)
app.secret_key = random.randbytes(32)


@app.route('/')
def home():
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    email = request.values.get('email')
    password = request.values.get('password')
    next_url = request.values.get('next', '/dashboard')

    if not email or not password:
        return render_template('login.html')

    if email in users and users[email] == password:
        session['user'] = email
        return redirect(next_url)

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    email = request.values.get('email')
    password = request.values.get('password')

    if not email or not password:
        return render_template('register.html')
    
    if email in users:
        return "User already exists"

    users[email] = password
    return redirect(url_for('login'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))
    
    text = request.values.get('text')
    if text:
        # Call the screenshot service
        url = urljoin(f'http://localhost:{APP_PORT}/', f'/text/{text}')
        result = requests.get(
            SCREENSHOT_SERVICE,
            params={'url': url}
        ).json()

        if 'error' in result:
            return 'Error getting screenshot'
        
        return render_template('preview.html', screenshot=result['result'])

    return render_template('dashboard.html')

@app.route('/text/<string:user_text>')
def text(user_text):
    font = random.choice(FONTS)
    return render_template('text.html', text=user_text, font=font)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=APP_PORT, debug=False)
