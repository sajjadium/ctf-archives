from setuptools import setup, Extension

module = Extension('sandbox', sources=['sandbox.c'])

setup(
    name='LumaCache',
    version='1.0',
    description='A package for LumaCache',
    ext_modules=[module],
)