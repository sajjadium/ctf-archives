#include <python3.12/Python.h>

static int running = 0;

static int audit(const char *event, PyObject *args, void *userData) {
  printf("arg1 = %s\n", event);

  if (!strcmp(event, "builtins.id")) {
    return 0;
  }

  if (!strcmp(event, "cpython.PyInterpreterState_Clear")) {
    return 0;
  }

  if (!strcmp(event, "cpython._PySys_ClearAuditHooks")) {
    return 0;
  }

  if (running) {
    printf("Luma mogged u lol\n");
    printf("Luma mogged u lol\n");
    printf("Luma mogged u lol\n");
    printf("Luma mogged u lol\n");
    exit(1);
  }

  if (!running && !strcmp(event, "exec"))
    running = 1;

  return 0;
}

static PyObject *sandbox(PyObject *self, PyObject *args) {
  PySys_AddAuditHook(audit, NULL);
  return Py_None;
}

static PyMethodDef myMethods[] = {{"sandbox", sandbox, METH_NOARGS, ""},
                                  {NULL, NULL, 0, NULL}};

static struct PyModuleDef myModule = {PyModuleDef_HEAD_INIT, "sandbox",
                                      "Jail Module", -1, myMethods};

PyMODINIT_FUNC PyInit_sandbox(void) { return PyModule_Create(&myModule); }