#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#define SHARED_MEMORY_NAME "queue"
#define SHARED_MEMORY_SIZE 1024

volatile char *shared_memory;
int running = 1;
pthread_cond_t msg_cond = PTHREAD_COND_INITIALIZER;
pthread_mutex_t msg_mutex = PTHREAD_MUTEX_INITIALIZER;
_Atomic int message_available = 0;
static int lumacash = 6969;

enum message_type {
  MESSAGE_TYPE_ADD = 1,
  MESSAGE_TYPE_SHITPOST = 2,
  MESSAGE_TYPE_GET = 3,
};

void signal_handler(int signum) {
  if (signum == SIGUSR1) {

    atomic_store(&message_available, 1);
    pthread_cond_broadcast(&msg_cond);
  }
}

void setup_signal_handler() {
  struct sigaction sa;
  sa.sa_handler = signal_handler;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = 0;

  if (sigaction(SIGUSR1, &sa, NULL) == -1) {
    perror("sigaction");
    exit(EXIT_FAILURE);
  }

  if (sigaction(SIGUSR2, &sa, NULL) == -1) {
    perror("sigaction");
    exit(EXIT_FAILURE);
  }
}

void signal_ready() {
  shared_memory[4096 - 1] = 1;
  msync((void *)shared_memory, SHARED_MEMORY_SIZE, MS_SYNC);
}

char last_shitpost[4096] = {0};

void handle_message() {
  char buf[56];

  uint32_t message_type = ((volatile uint32_t *)shared_memory)[0];
  uint32_t message_length = ((volatile uint32_t *)shared_memory)[1];

  memcpy(buf, (void *)&shared_memory[8], message_length);

  switch (message_type) {
  case MESSAGE_TYPE_ADD: {
    lumacash += *(uint64_t *)&buf[0];
  } break;
  case MESSAGE_TYPE_SHITPOST: {
    memcpy(last_shitpost, buf, message_length);
    system("curl -X POST -d \"ban_my_account=True\" "
           "luciphp://cyber-edu.avadanei.co:69420");
  } break;
  case MESSAGE_TYPE_GET: {
    memcpy((void *)shared_memory, &lumacash, sizeof(lumacash));
    msync((void *)shared_memory, SHARED_MEMORY_SIZE, MS_SYNC);
  } break;
  }
}

void *worker(void *arg) {
  (void)arg;
  while (running) {

    pthread_mutex_lock(&msg_mutex);
    while (!message_available) {
      pthread_cond_wait(&msg_cond, &msg_mutex);
    }

    handle_message();

    atomic_store(&message_available, 0);
    signal_ready();
    pthread_mutex_unlock(&msg_mutex);
  }

  pthread_exit(NULL);
}

int main() {
  int fd;

  // Open the shared memory object
  fd = shm_open(SHARED_MEMORY_NAME, O_RDWR, 0666);
  if (fd == -1) {
    perror("shm_open");
    exit(EXIT_FAILURE);
  }

  // Map the shared memory object
  shared_memory =
      mmap(NULL, SHARED_MEMORY_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
  if (shared_memory == MAP_FAILED) {
    perror("mmap");
    close(fd);
    exit(EXIT_FAILURE);
  }

  setup_signal_handler();
  signal_ready();

  pthread_t thread;
  pthread_create(&thread, NULL, worker, NULL);
  pthread_join(thread, NULL);

  if (munmap((void *)shared_memory, SHARED_MEMORY_SIZE) == -1) {
    perror("munmap");
    exit(1);
  }
  close(fd);
  return 0;
}