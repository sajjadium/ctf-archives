import enum
import time
import json
import mmap
import os
import struct
import signal
import logging
import socket

import sandbox

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

waiting = False


class MessageType(enum.IntEnum):
    ADD = 1
    SHITPOST = 2
    GET = 3


def wait_ready():
    global shared_memory

    while shared_memory[mmap.PAGESIZE - 1] == 0:
        time.sleep(0.1)

    shared_memory[mmap.PAGESIZE - 1] = 0

def post_message(
    chain_pid: int,
    shmem: mmap.mmap,
    type: int,
    code: str,
    input: bytearray = bytearray(),
):
    pid = os.fork()
    if pid == 0:
        compiled = compile(code, "<string>", "exec")
        sandbox.sandbox()

        result = bytearray()

        exec(
            compiled,
            {
                "__builtins__": {
                    "__build_class__": __build_class__,
                    "__name__": __name__,
                    "id": id,
                },
                "input": input,
                "result": result,
            },
            {"__builtins__": {}},
        )

        result = result[:56]
        shmem.seek(0)
        shmem.write(struct.pack("@I", type) + struct.pack("@I", len(result)) + result)

        shmem.close()
        exit(0)
    else:
        pid, status = os.waitpid(pid, 0)
        if os.WIFEXITED(status) and os.WEXITSTATUS(status) == 0:
            global waiting
            waiting = True
            os.kill(chain_pid, signal.SIGUSR1)
            wait_ready()
            print("Message sent and processed")
        else:
            print("Message failed to send")


chain_pid = None

MIRROR_CONTRACT = """
result.extend(input)
"""


def run():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind(("", 8081))
    server_socket.listen(1)
    logger.info("Starting server on port 8081")

    while True:
        client_socket, client_address = server_socket.accept()
        logger.info(f"Connection from {client_address}")

        running = True
        while running:
            data = bytearray()

            while True:
                ch = client_socket.recv(1)
                if ch == b"\n":
                    break
                elif ch == b"":
                    running = False
                    break
                data.extend(ch)

            if data.startswith(b"/balance"):
                post_message(chain_pid, shared_memory, MessageType.GET, code="")
                shared_memory.seek(0)
                shared_memory.flush()
                balance = struct.unpack("@I", shared_memory.read(4))

                response = {"balance": balance}
                client_socket.sendall(json.dumps(response).encode("utf-8") + b"\n")
            elif data.startswith(b"/quit"):
                running = False
            elif data.startswith(b"/add"):
                count = int(data.split(b" ")[1])
                post_message(
                    chain_pid,
                    shared_memory,
                    MessageType.ADD,
                    code=MIRROR_CONTRACT,
                    input=struct.pack("@I", count),
                )
                client_socket.sendall(
                    json.dumps({"gucci": True}).encode("utf-8") + b"\n"
                )
            elif data.startswith(b"/shitpost"):
                shipost_data = bytes.fromhex(data.split(b" ")[1].decode("utf-8"))

                post_message(
                    chain_pid,
                    shared_memory,
                    MessageType.SHITPOST,
                    code=MIRROR_CONTRACT,
                    input=shipost_data,
                )
                client_socket.sendall(
                    json.dumps({"shitpost": "pretty good"}).encode("utf-8") + b"\n"
                )
            elif data.startswith(b"/contract"):
                cmd = data.split(b" ")
                contract_data = bytes.fromhex(cmd[1].decode("utf-8")).decode("utf-8")
                input_data = bytes.fromhex(cmd[2].decode("utf-8"))
                post_message(
                    chain_pid,
                    shared_memory,
                    MessageType.ADD,
                    code=contract_data,
                    input=input_data,
                )
                client_socket.sendall(
                    json.dumps({"gucci": True}).encode("utf-8") + b"\n"
                )

        client_socket.close()


if __name__ == "__main__":
    # Create a shared memory object
    shm_fd = os.open("/dev/shm/queue", os.O_CREAT | os.O_TRUNC | os.O_RDWR)

    # Set the size of the shared memory object
    os.ftruncate(shm_fd, mmap.PAGESIZE)

    # Memory-map the shared memory object
    shared_memory = mmap.mmap(
        shm_fd, mmap.PAGESIZE, mmap.MAP_SHARED, mmap.PROT_WRITE | mmap.PROT_READ
    )

    shared_memory.write(b"\x00" * mmap.PAGESIZE)
    shared_memory.seek(0)
    shared_memory.flush()

    logger.info(os.getpid())

    waiting = True
    chain_pid = os.spawnv(os.P_NOWAIT, "./main", ["./main"])

    wait_ready()
    run()
