import json
import os

from flask import Flask, render_template, request
from markupsafe import escape

app = Flask(__name__)


@app.after_request
def add_headers(response):
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cross-Origin-Resource-Policy"] = "same-site"
    response.headers["Cross-Origin-Opener-Policy"] = "unsafe-none"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self'; "
        "img-src 'self' data:; "
        "base-uri 'none'; "
        "form-action 'self'; "
        "object-src 'none'"
    )
    return response


@app.get("/")
def index():
    mode = (request.args.get("mode", "", type=str) or "").strip().lower()
    if mode not in {"view", "probe"}:
        mode = "view"

    boot = {
        "mode": mode,
        "q": (request.args.get("q", "", type=str) or "")[:256],
        "sid": (request.args.get("sid", "", type=str) or "")[:96],
        "rid": (request.args.get("rid", "", type=str) or "")[:96],
        "note": (request.args.get("note", "", type=str) or "")[:8192],
    }

    boot_attr = escape(json.dumps(boot, separators=(",", ":")))
    return render_template("index.html", boot_attr=boot_attr)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5001")))
