#!/usr/bin/env python3
import sys

# Delete dangerous functions
for x in ["__import__", "exec", "eval", "open",  "compile", "breakpoint", "help"]:
    delattr(__builtins__, x)

c = bytes.fromhex(input('Give me your bytecode (hex): '))

if len(c) > 1000:
    print("nope")
    exit(0)

# must also be a utf-8 valid string
print(f"Your bytecode (decoded): {c.decode()}")

for x in c:
    # both opcode and argument must respect these constraints  
    if x not in \
        (
            0, # CACHE
            1, # BINARY_SLICE
            2, # BUILD_TEMPLATE
            6, # CHECK_EXC_MATCH
            16, # GET_ITER
            26, # MATCH_SEQUENCE
            31, # POP_TOP
            35, # RETURN_VALUE
            42, # UNARY_NOT
            44, # BINARY_OP
            50, # BUILD_STRING
            52, # CALL
            59, # COPY
            70, # FOR_ITER
            84, # LOAD_FAST
            117, # SWAP
        ):
        print("nope")
        exit()

# Make sure nobody interacts after the input
sys.stdin.close()
sys.stdout.close()
sys.stderr.close()
sys.modules.clear()
del sys

A=lambda:0
C=A.__code__.__class__
D=A.__class__

print=lambda x:0
print(D(C(0,0,0,0,0,0,c,(),(),(),'<string>','<string>','...',0,b'',b'',(),()),{"__builtins__": {}})())