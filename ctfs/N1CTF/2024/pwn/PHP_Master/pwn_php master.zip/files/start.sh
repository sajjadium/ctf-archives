#!/bin/bash

/flag.sh

service nginx restart
/opt/php/sbin/php-fpm -c /opt/php/etc/php.ini -y /opt/php/etc/php-fpm.conf
tail -f /var/log/nginx/access.log
