#!/bin/bash

echo $FLAG > /flag
export FLAG=""
FLAG=""

chmod 444 /flag
