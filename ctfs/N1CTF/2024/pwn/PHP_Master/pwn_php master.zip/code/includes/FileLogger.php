<?php
namespace Utils;

class FileLogger {
    public $log_file;
    public $log_filter_prepend;
    public $log_filter_appened;
    public $outputs;

    public function __construct($log_file, $filter_pre, $filter_app) {
        $this->log_file = $log_file;
        $this->log_filter_prepend = $filter_pre;
        $this->log_filter_appened = $filter_app;
        $this->outputs = array(); 
    }

    public function log($data) {
        $this->outputs[] = call_user_func($this->log_filter_prepend, $data);
    }

    public function __destruct() {
        $outputs = call_user_func($this->log_filter_appened, $this->outputs);
        file_put_contents($this->log_file, $outputs); 
    }
}