<?php
namespace DataForm;

class DataFormError {
    public $error_msg;
    public $params;
    public $data_snapshot;

    public function __construct($error_msg, $params, $data_snapshot) {
        $this->error_msg = $error_msg;
        $this->params = $params;
        $this->data_snapshot = $data_snapshot;
    }

    public function getErrors() {
        $emsg = [];
        $emsg["msg"] = sprintf("Error results: %s", $this->error_msg);
        
        if (!empty($this->params)) {
            $emsg["params"] = array_map(fn($v) => base64_encode($v), $this->params);
        }

        if (!empty($this->data_snapshot)) {
            $emsg["data_snapshot"] = DataForm::printable($this->data_snapshot);
        }
        
        return $emsg;
    }
}