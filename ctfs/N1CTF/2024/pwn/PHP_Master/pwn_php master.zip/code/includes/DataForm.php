<?php
namespace DataForm;

class DataForm {
    public $data;
    public $prev_data;
    public $last_error;

    public function __construct() {
        $this->data = [];
        $this->prev_data = [];
        $this->last_error = NULL;
    }

    public function __sleep()
    {
        return array('data');
    }

    public function run() {
        $this->last_error = NULL;
        $this->prev_data = $this->data;
        set_error_handler([$this, "errorMessage"]);
        $changed = false;
        $callback = "";

        if(isset($_POST['callback']) && is_string($_POST['callback'])) {
            $callback = $_POST['callback'];
        }

        if(isset($_POST['action']) && is_string($_POST['action'])) {
            $action = $_POST['action'];
            $data = NULL;
            switch ($action) {
                case "add":
                    $this->add();
                    $changed = true;
                    break;
                case "insert":
                    $this->insert();
                    $changed = true;
                    break;
                case "append":
                    $this->append();
                    $changed = true;
                    break;    
                case "get":
                    $data = $this->get();
                    $data = base64_encode($data);
                    break;
                case "delete":
                    $this->delete();
                    $changed = true;
                    break;
                case "dump":
                    $data = $this->dump();
                    $data = DataForm::printable($data);
                    break;         
                case "clear":
                    $this->clear();
                    $changed = true;
                    break;
                default:
                    $this->last_error = new DataFormError("Invalid action.", NULL, NULL);
            }
        } else {
            $this->last_error = new DataFormError("Invalid action.", NULL, NULL);
        }

        if (!$this->last_error) {
            $msg = [];
            if ($data) {    
                $msg["data"] = $data;
            }
        } else {
            $msg["err"] = $this->last_error->getErrors();
            $changed = false;
        }

        if ($callback != "") {
            $callback = trim($callback);
            echo $callback . "(" . json_encode($msg) . ")";
        } else {
            echo json_encode($msg);
        }

        return $changed;
    }

    function add() {    
        extract(array(
            ...((isset($_POST['content']) && is_string($_POST['content'])) ? ["content" => gzdeflate($_POST['content'])] : []),
        ), EXTR_SKIP);
    
        $this->data[] = array($content);
    }
    
    function insert() {
        extract(array(
            ...((isset($_POST['i']) && is_positive_integer($_POST['i'])) ? ["i" => intval($_POST['i'])] : []),
            ...((isset($_POST['content']) && is_string($_POST['content'])) ? ["content" => gzdeflate($_POST['content'])] : []),
        ), EXTR_SKIP);
    
        if (isset($this->data[$i])) {
            $j = count($this->data[$i]);
            $this->data[$i][$j] = $content;
        } else {
            $this->errorMessage("", "");
        }
    }

    function append() {
        extract(array(
            ...((isset($_POST['i']) && is_positive_integer($_POST['i'])) ? ["i" => intval($_POST['i'])] : []),
            ...((isset($_POST['j']) && is_positive_integer($_POST['j'])) ? ["j" => intval($_POST['j'])] : []),
            ...((isset($_POST['content']) && is_string($_POST['content'])) ? ["content" => ($_POST['content'])] : []),
        ), EXTR_SKIP);
    
        if (isset($this->data[$i][$j])) {
            $this->data[$i][$j] = gzinflate($this->data[$i][$j]); 
            $this->data[$i][$j] .= $content;
            $this->data[$i][$j] = gzdeflate($this->data[$i][$j]);
        } else {
            $this->errorMessage("", "");
        }
    }
    
    function get() {
        extract(array(
            ...((isset($_POST['i']) && is_positive_integer($_POST['i'])) ? ["i" => intval($_POST['i'])] : []),
            ...((isset($_POST['j']) && is_positive_integer($_POST['j'])) ? ["j" => intval($_POST['j'])] : []),
        ), EXTR_SKIP);
    
        if (isset($this->data[$i][$j])) {
            return gzinflate($this->data[$i][$j]);
        } else {
            $this->errorMessage("", "");
        }
    }
    
    function delete() {
        extract(array(
            ...((isset($_POST['i']) && is_positive_integer($_POST['i'])) ? ["i" => intval($_POST['i'])] : []),
        ), EXTR_SKIP);
    
        if (isset($this->data[$i])) {
            unset($this->data[$i]);
            $this->data = array_values($this->data);
        } else {
            $this->errorMessage("", "");
        }
    }
    
    function dump() {
        $result = [];
        
        foreach ($this->data as $index => $values) {
            $result[$index] = array();
            foreach($values as $value) {
                $result[$index][] = gzinflate($value);
            }
        }
    
        return $result;
    }
    
    function clear() {
        $this->data = [];
    }

    static function printable($data) {
        return array_map(fn($v) => array_map(fn($w) => base64_encode($w), $v), $data);
    }

    function errorMessage($err_code, $msg) {
        $action = strval($_POST['action']);
        $emsg = "";
        $params = array();
    
        $emsg = sprintf("Action %s failed.", $action);
    
        if ($action == "add") {
            if (isset($_POST['content']) && is_string($_POST['content'])) {
                $params["content"] = $_POST['content'];
            } else {
                $params["content"] = "Invalid content.";
            }
        } else if ($action == "insert") {
            if (isset($_POST['i']) && is_positive_integer($_POST['i'])) {
                $params["i"] = intval($_POST['i']);
            } else {
                $params["i"] = "Invalid index.";
            }
            
            if (isset($_POST['content']) && is_string($_POST['content'])) {
                $params["content"] = $_POST['content'];
            } else {
                $params["content"] = "Invalid content.";
            }
        } else if ($action == "append") {
            if (isset($_POST['i']) && is_positive_integer($_POST['i'])) {
                $params["i"] = intval($_POST['i']);
            } else {
                $params["i"] = "Invalid index.";
            }
    
            if (isset($_POST['j']) && is_positive_integer($_POST['j'])) {
                $params["j"] = intval($_POST['j']);
            } else {
                $params["j"] = "Invalid index.";
            }

            if (isset($_POST['content']) && is_string($_POST['content'])) {
                $params["content"] = $_POST['content'];
            } else {
                $params["content"] = "Invalid content.";
            }
        } else if ($action == "get") {
            if (isset($_POST['i']) && is_positive_integer($_POST['i'])) {
                $params["i"] = intval($_POST['i']);
            } else {
                $params["i"] = "Invalid index.";
            }
    
            if (isset($_POST['j']) && is_positive_integer($_POST['j'])) {
                $params["j"] = intval($_POST['j']);
            } else {
                $params["j"] = "Invalid index.";
            }
        } else if ($action == "delete") {
            if (isset($_POST['i']) && is_positive_integer($_POST['i'])) {
                $params["i"] = intval($_POST['i']);
            } else {
                $params["i"] = "Invalid index.";
            }
        } else if ($action == "dump" || $action == "clear") {
            // ...
        } else {
            $emsg .= "Unexpected errors occurred.";
        }
        
        if (isset($_POST["_display_data"])) {
            $this->data = $this->prev_data;
            $data_snapshot = $this->dump();
        } else {
            $data_snapshot = NULL;
        }
        
        $this->last_error = new DataFormError($emsg, $params, $data_snapshot);
    }
}