<?php
require 'vendor/autoload.php';
require "utils.php";
use DataForm\DataForm;

session_start();

if (isset($_SESSION['data'])) {
    $data_form = unserialize($_SESSION['data']);
} else {
    $data_form = new DataForm();
}

$index = $_SERVER["REQUEST_URI"];
ob_start();

switch ($index) {
    case "/dataform":
    {
        $changed = $data_form->run();
        if ($changed) {
            $_SESSION['data'] = serialize($data_form);
        }
        break;
    }
    default:
        print("Hello! Feel free to use this space for data storage.");
}

ob_end_flush();


