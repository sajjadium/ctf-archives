<?php

function is_positive_integer($n) {
    $filter_options = array( 
        'options' => array('min_range' => 0) 
    );

    return filter_var($n, FILTER_VALIDATE_INT, $filter_options) !== FALSE;
}