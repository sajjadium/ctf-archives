#!/bin/sh
# This file is based on a CTF challenge image from justCTF 2024 teaser (https://ctftime.org/task/28579).
# The original Author is @tomek7667
# Adapted for use in N1CTF 2024
/usr/bin/supervisord -c /etc/supervisord.conf