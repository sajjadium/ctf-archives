qemu-system-x86_64  \
    -m 256M  \
    -cpu qemu64,+smap,+smep \
    -kernel bzImage    \
    -append "console=ttyS0 quiet panic=-1 kaslr sysctl.kernel.dmesg_restrict=1 sysctl.kernel.kptr_restrict=2"     \
    -initrd rootfs.cpio \
    -drive file=/flag,if=virtio,format=raw,readonly=on \
    -nographic  \
    -no-reboot \
    -monitor /dev/null
