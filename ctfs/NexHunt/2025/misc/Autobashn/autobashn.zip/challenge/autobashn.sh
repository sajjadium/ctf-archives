#!/bin/bash

echo """
           .----------------.
           |                |
           |      /||\      |
           |     /_||_\     |
           | =m==========m= |
           |   /   ||   \   |
           |  /____||____\  |
           |                |
           '----------------'

  Know the limits – even on a Autobashn

"""
read -e -r -p "Autobashn$: " CMD


if [[ ! "$CMD" =~ ^[\(\)\'01\$\<\#\\]+$ ]]; then
    echo >&2 "Invalid command, only (\$\\01<#) characters are allowed."
elif [[ "$CMD" =~ \$[01] ]]; then
    echo >&2 "Bad Boy."
else
    printf -v cmd '%s ' bash -c "\"${CMD}\""
    eval $cmd
fi
