#!/bin/bash

cd /home/user || exit
python3 start_d8.py
