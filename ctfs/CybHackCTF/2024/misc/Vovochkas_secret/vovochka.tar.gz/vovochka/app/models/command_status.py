class Status:
    NOTHING = 1
    CREATING = 2
    READING = 3