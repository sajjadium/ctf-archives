from flask import Flask, jsonify
import requests
import threading
import time
import jwt
import random

app = Flask(__name__)
app.config['SECRET_KEY'] = 'prod_key_is_different_forget_about_it'
app.config['PAYMENTS'] = []

def make_payments():
    time.sleep(5)
    while True:
        for _ in range(20):
            price = random.randint(100, 400)
            response = requests.post("https://bank:5001/payment", 
                json={'price': price}, 
                headers={'Content-Type': 'application/json'},
                cookies={'auth_token': str(generate_jwt('receipt_service'))},
                verify=False)
            if response.status_code == 201:
                app.config['PAYMENTS'].append(response.json())
            time.sleep(1)
        time.sleep(300)
        app.config['PAYMENTS'] = []

def generate_jwt(user_id):
    try:
        payload = {
            'user_id': user_id
        }
        return jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
    except Exception as e:
        return e

@app.route('/current_receipts')
def current_receipts():
    current_payments = app.config['PAYMENTS'][-20:]
    return jsonify(current_payments)


if __name__ == '__main__':
    threading.Thread(target=make_payments).start()
    app.run(host='0.0.0.0', port=5002, debug=False)
