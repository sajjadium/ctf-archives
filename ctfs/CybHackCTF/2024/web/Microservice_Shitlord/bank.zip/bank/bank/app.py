from flask import Flask, request, jsonify, abort
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS, cross_origin
import jwt, uuid, cryptography, os

app = Flask(__name__)
CORS(app, supports_credentials=True)
app.config['SECRET_KEY'] = 'prod_key_is_different_forget_about_it'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////bank.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    payment_id = db.Column(db.String(36), unique=True, nullable=False)
    price = db.Column(db.Float, nullable=False)
    user_id = db.Column(db.Integer, nullable=False)


class BankUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    balance = db.Column(db.Integer, nullable=False, default=0)


with app.app_context():
    db.drop_all()
    db.create_all()


@app.route('/bankuser', methods=['POST'])
def handle_bankuser():
    auth_token = request.cookies.get('auth_token')
    if not auth_token:
        abort(401, description="Unauthorized access: No authentication token found.")
    user_id = decode_auth_token(auth_token)

    if BankUser.query.filter_by(id=user_id).first():
        return '400'
    
    bank_user = BankUser(id=user_id)
    db.session.add(bank_user)
    db.session.commit()
    return '201'


@app.route('/balance', methods=['GET'])
def handle_balance():
    auth_token = request.cookies.get('auth_token')
    if not auth_token:
        abort(401, description="Unauthorized access: No authentication token found.")
    user_id = decode_auth_token(auth_token)
    user = BankUser.query.filter_by(id=user_id).first()
    if user:
        return str(user.balance)
    else:
        return abort(400, description="User already exists")


@app.route('/payment', methods=['POST'])
def handle_payment():
    auth_token = request.cookies.get('auth_token')
    if not auth_token:
        abort(401, description="Unauthorized access: No authentication token found.")
    user_id = decode_auth_token(auth_token)
    price = request.json.get('price')

    #back2back integration with receipts to generate payments
    if user_id == 'receipt_service':
        payment_id = str(uuid.uuid4())
        new_payment = Payment(payment_id=payment_id, price=price, user_id=user_id)
        db.session.add(new_payment)
        db.session.commit()
        return jsonify({'payment_id': payment_id, 'price': price}), 201

    if price == 13370:
        user = BankUser.query.filter_by(id=user_id).first()
        if user.balance >= 13370:
            return jsonify({'flag': os.getenv('FLAG')}), 201
    return jsonify({'error': 'Invalid product or not enough money'}), 400


@app.route('/refund', methods=['GET'])
def handle_refund():
    auth_token = request.cookies.get('auth_token')
    if not auth_token:
        abort(401, description="Unauthorized access: No authentication token found.")
    user_id = decode_auth_token(auth_token)
    payment_id = request.args.get('payment_id')
    payment = Payment.query.filter_by(payment_id=payment_id).first()
    price = payment.price
    if payment:
        user = BankUser.query.filter_by(id=user_id or payment.user_id).first()
        user.balance += price
        db.session.delete(payment)
        db.session.commit()
        return jsonify({'message': 'Refund processed successfully'}), 200
    else:
        return jsonify({'message': 'Payment not found or unauthorized'}), 404


def decode_auth_token(token):
    try:
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])
        return payload['user_id']
    except jwt.InvalidTokenError:
        abort(401, description="Invalid token")


if __name__ == '__main__':
    app.run(debug=False, port=5001, host='0.0.0.0', ssl_context='adhoc')