from flask import Flask, render_template, redirect, request, url_for, flash, make_response, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length, EqualTo
from werkzeug.security import generate_password_hash, check_password_hash
from flask import jsonify
import jwt, requests, cryptography

app = Flask(__name__)
app.config['SECRET_KEY'] = 'prod_key_is_different_forget_about_it'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////user.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    passhash = db.Column(db.String(1000), nullable=False)


with app.app_context():
    db.drop_all()
    db.create_all()


class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')


class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = generate_password_hash(form.password.data)
        new_user = User(username=form.username.data, passhash=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        
        token = generate_jwt(new_user.id)
        create_bank_user(str(token))
        flash('Registration successful! You may now log in.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.passhash, form.password.data):
            login_user(user)

            token = generate_jwt(user.id)
            response = make_response(redirect(url_for('home')))
            response.set_cookie('auth_token', str(token), httponly=True)
            return response
        else:
            flash('Login Unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', form=form)


@app.route('/home')
@login_required
def home():
    auth_token = request.cookies.get('auth_token')
    if not auth_token:
        abort(401, description="Unauthorized access: No authentication token found.")
    
    balance = get_bank_balance(auth_token)
    return render_template('home.html', product_price=13370, balance=balance)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))


def generate_jwt(user_id):
    try:
        payload = {
            'user_id': user_id
        }
        return jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
    except Exception as e:
        return e


def create_bank_user(auth_token):
    url = 'https://bank:5001/bankuser'
    return requests.post(url, cookies={'auth_token': auth_token}, verify=False).text

def get_bank_balance(auth_token):
    url = 'https://bank:5001/balance'
    return requests.get(url, cookies={'auth_token': auth_token}, verify=False).text

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, ssl_context='adhoc', port='5000')
