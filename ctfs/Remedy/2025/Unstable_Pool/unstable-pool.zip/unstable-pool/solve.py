from ctf_solvers.pwn_solver import PwnChallengeSolver

PwnChallengeSolver().start()
