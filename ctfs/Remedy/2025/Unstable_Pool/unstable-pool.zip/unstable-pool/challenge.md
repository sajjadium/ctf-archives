# Unstable Pool

## Author

Klaus Waiß

## Description

Time to test your pool draining skills! Try to steal 90% of the stable coins from the pool.