# Frozen Voting

## Author

duc & patronasxd

## Description

In this system, voting NFTs are equipped with varying levels of voting power, and one particular NFT holds super voting power. After minting, this powerful NFT is fortunately delegated to the player. To solve this challenge, players with a normal NFT must freeze the super voting power NFT.