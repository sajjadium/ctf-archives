# risc4

## Author

kemmio

## Description

Take Risc to Drink Champagne! A crazy zk researcher has gated access to all his assets using a guest program that checks for a secret input, can you guess the secret input?
The flag will be in the format rctf{0xINPUT} 