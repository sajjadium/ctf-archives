# Peer-to-Peer-to-Me

## Author

0xkasper

## Description

Peer-to-peer is nice and all, but I'd prefer to just have it all go to me. Could you help me with that? I'll share the profits with you, say 10%? I've provided your acount with some required tokens.

Unintended solutions or other bugs should be responsibly reported: https://immunefi.com/bug-bounty/livepeer/