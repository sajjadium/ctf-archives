# Not a very LUCKY TOKEN

## Author

0xlyov

## Description

You start with 1 ETH and a questionable token that offers a maybe +5% gain or a definite -10% each time you transfer it. 
There’s a Uniswap pool (ETH / Lucky Token) and a massive vault bursting with tokens.
Your Master Plan? 
- Drain the pool’s ETH until its balance falls below 1 ETH (muahahaha!). 
- Walk away with over 10 ETH in your own pocket, proving you’re the luckiest one around.