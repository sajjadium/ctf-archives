# Rich Man's Bet

## Author

Heuss

## Description

"Power to the people? What a joke... Only the rich deserve power!" That's what the developer of this bridge had in mind when creating it. For him, being rich is proof of intelligence and wisdom. Therefore, for the modest price of 1000 ETH, anyone can become a validator and have a say in the bridge's configuration.
He also truly believes that poor people are stupid—they will never understand the "rules" of this society, and that's why they are poor. To mock them, he even implemented this challenge: anyone who can solve it will take the entire bridge balance with them!
What arrogance... He forgot that there are people out there who don't understand the rules simply because they don't play by them. We call them hackers.