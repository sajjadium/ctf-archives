# Lockdown

## Author

hm-hexens

## Description

“The last audit told us we didn't have enough reentrancy locks, so we put them everywhere. We're safe now, right?”

Goal: Drain the Marketplace contract of all CUSDC and as much USDC as you can.