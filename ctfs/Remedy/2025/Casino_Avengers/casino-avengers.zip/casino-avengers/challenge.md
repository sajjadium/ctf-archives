# Casino Avengers

## Author

ustas.eth

## Description

After numerous attacks by Alice on Bob, he's now planning his revenge. By tracing his stolen funds, Bob has uncovered Alice's latest scheme: a rigged Casino smart contract.
You and Bob have a long history together. While Bob may not be an expert in hacking, he has turned to his most trusted ally - you - for assistance. Although the funds are already locked in the contract and it seems impossible to retrieve them, as a team you are determined to find a way...