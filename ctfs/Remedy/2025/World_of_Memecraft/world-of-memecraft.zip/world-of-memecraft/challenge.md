# World of Memecraft

## Author

0xkasper & patronasxd

## Description

You can just hang outside in the sun all day tossing a ball around, or you can sit at your computer and do something that matters.