# OFAC Executive Order 13337

## Author

kemmio

## Description

The Office of Forgotten Access Control (OFAC) is sanctioning Tornado by introducing changes to the protocol.