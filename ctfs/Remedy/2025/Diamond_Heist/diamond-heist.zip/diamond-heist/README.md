# Diamond Heist

## Author

0xkasper

## Description

Agent, we are in desperate need of your help. The King's diamonds have been stolen by a DAO and are locked in a vault. They are currently voting on a proposal to burn the diamonds forever!

Your mission, should you choose to accept it, is to recover all diamonds and keep them safe until further instructions.

Good luck.

This message will self-destruct in 3.. 2.. 1..