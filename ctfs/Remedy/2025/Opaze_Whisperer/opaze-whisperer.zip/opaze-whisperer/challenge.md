# Opaze Whisperer

## Author

m4k2

## Description

The Opaze Whisperer guards an ancient treasure. Many have tried to approach this mysterious keeper, but none have managed to claim its prized possession. Perhaps you'll be more... persuasive