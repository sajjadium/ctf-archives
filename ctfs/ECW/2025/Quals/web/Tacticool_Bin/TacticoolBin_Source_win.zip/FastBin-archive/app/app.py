from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_caching import Cache
import re
import time
import secrets

app = Flask(__name__)

config = {
	"DEBUG": False,
	"CACHE_TYPE": "SimpleCache",
	"CACHE_DEFAULT_TIMEOUT": 10,
	"SQLALCHEMY_DATABASE_URI": 'sqlite:///users.db',
    "SECRET_KEY": secrets.token_hex(16)
}

app.config.from_mapping(config)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
cache = Cache(app)

# User model
class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(200), nullable=True)
    phone = db.Column(db.String(20), nullable=True)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))
message_list = []

@app.route("/", methods=['GET', 'POST'])
def index():


    #POST logic
	if request.method == 'POST':
		data = request.get_json()
		
		for item in message_list:
			if data.get('title') == item.get('title'):
				return 'Title already in use !', 418

		message_list.append({"title": data.get('title'), "ttl": data.get('ttl'), "creation": int(time.time())})
		
		time.sleep(0.5) # Lil delay on the request for better user experience 💅
		
		cache.set(data.get('title'), data.get('message'), timeout=data.get('ttl'))
		return "Ok"

    #GET logic could be ran every 1~5s instead of everytime a user gets the homepage but eh 
	current_time = int(time.time())
	for item_dict in message_list:
		ttl = item_dict.get('ttl')
		creation = item_dict.get('creation')
		if current_time >= creation + ttl and ttl >= 0:
			#We overwrite it from cache as well
			cache.set(item_dict.get('title'), "Removed", 1)
			message_list.remove(item_dict)
			
    # We want to control what we send to the client, ideally would optimize using only one list but logic is already built another way
	sent_list = []
	for item_dict in message_list:
		ttl = item_dict.get('ttl')
		creation = item_dict.get('creation')
		sent_list.append({"title": item_dict.get('title'), "message": cache.get(item_dict.get('title')), "ttl": item_dict.get('ttl') + item_dict.get('creation')-int(time.time())})

	if current_user.is_authenticated:
		return render_template('index.html', username = current_user.username, data=sent_list)
	else:
		return render_template('index.html', data=sent_list)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        phone = request.form['phone']

        if not re.match(r'^[a-zA-Z0-9_-]+$', username):
            flash('Username can only contain letters, numbers, underscores, and dashes.')
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash('Username already exists')	        
            return redirect(url_for('register'))

        hashed_pw = generate_password_hash(password)
        new_user = User(username=username, password=hashed_pw, email=email, phone=phone)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful. You can now log in.')
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard', username=current_user.username))
        flash('Invalid credentials')
    return render_template('login.html')


def unauthorized():
	if current_user.is_authenticated:
		return current_user.username != request.path.split("/")[-1]
	else:
		return True
	
@app.route('/dashboard/<username>')
#User's page is static, might as well keep it cached forever ¯\_(ツ)_/¯, however, made sure anyone can't just see someone elses profile by path traversal-ing, this would be bad RIGHT ? 
@cache.cached(timeout=0, unless=unauthorized)
@login_required
def dashboard(username):
    
	user = User.query.filter_by(username=username).first()
      
	if not user:
		flash("Stop trying to access other users dashboards or face consequences !")
		return redirect(url_for('errorpage'))

	if user.id != current_user.id:
		flash("You shouldn't access another user's dashboard. =(")
		flash("User " + user.username + " has been alerted.")
		return redirect(url_for('errorpage'))
      
	return render_template('dashboard.html', name=current_user.username, email=current_user.email, phone=current_user.phone)

@app.route('/alert')
@login_required
def errorpage():
	return render_template('error.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


if __name__ == '__main__':
    with app.app_context():
        cache.clear()
		
        message_list = []
        #Rules
        message_list.append({"title": "ABOUT", "ttl": -1337, "creation": 1744813509})
        cache.set("ABOUT", "Use our tool to anonymously emit any messages to everyone.  - - - - - - - - - - - Messages are only kept in cache for the TTL duration, it is safely deleted and overwritten after that. - - - - - - - -   Due to the increased number of users using our tool, user pages etc... are still under developement.", 0)

        message_list.append({"title": "RULES", "ttl": -1337, "creation": 1744813509})
        cache.set("RULES", "Even if there where rules... You probably wouldn't follow them", 0)
        

        db.drop_all()
        db.create_all()
		
        #db base entries (example only) 
		
        hashed_pw = generate_password_hash('ShouldBeSecure')
        new_user = User(username='Fictive_User', password=hashed_pw, email='name@corporation.ctry', phone='+33 6 00 00 00 00')
        db.session.add(new_user)
		
        db.session.commit()



    app.run(host="0.0.0.0", debug=False)
