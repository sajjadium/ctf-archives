
const container = document.getElementById('terrain-container');


const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setSize(container.clientWidth, container.clientHeight);
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(70, container.clientWidth / container.clientHeight, 0.1, 1000);
camera.position.z = 30;
camera.position.y = 10;
camera.lookAt(0, 0, 0);

const size = 80;
const segments = 20;
const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
geometry.rotateX(-Math.PI / 2);


for (let i = 0; i < geometry.attributes.position.count; i++) {
  const y = Math.random() * 4;
  geometry.attributes.position.setY(i, y);
}
geometry.computeVertexNormals();

// Material
const material = new THREE.MeshBasicMaterial({
  color: 0x00ff00,
  wireframe: true,
});


const terrain = new THREE.Mesh(geometry, material);
scene.add(terrain);


const droneGeometry = new THREE.SphereGeometry(0.25, 16, 16);
const droneMaterial1 = new THREE.MeshBasicMaterial({ color: 0xff0000, transparent: true, opacity: 1});
const droneMaterial2 = new THREE.MeshBasicMaterial({ color: 0x00ff00 });
const drone1 = new THREE.Mesh(droneGeometry, droneMaterial1);
const drone2 = new THREE.Mesh(droneGeometry, droneMaterial1);



scene.add(drone1);

drone1.position.set(-6, 10, -9); 
drone2.position.set(10, 7, 9); 
terrain.add(drone1); 
terrain.add(drone2); 



function animate() {
  requestAnimationFrame(animate);

  terrain.rotation.y += 0.002;

  if (droneMaterial1.opacity < -1) {
    droneMaterial1.opacity = 1.25;
  }
  droneMaterial1.opacity -= 0.01



  renderer.render(scene, camera);
}
animate();

