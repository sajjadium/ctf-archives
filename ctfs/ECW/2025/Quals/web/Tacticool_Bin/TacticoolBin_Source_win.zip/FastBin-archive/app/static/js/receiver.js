
function addMessage(title, body, ttl = 0) {
    const messageList = document.getElementById('message-list');
  
    const container = document.createElement('div');
    container.className = 'message-item';
  
    const titleDiv = document.createElement('div');
    titleDiv.className = 'message-title';
    titleDiv.textContent = title;
  
    const ttlDiv = document.createElement('div');
    ttlDiv.className = 'message-ttl';
    ttlDiv.textContent = ttl;
  
    const titleRow = document.createElement('div');
    titleRow.style.display = 'flex';
    titleRow.style.justifyContent = 'space-between';
    titleRow.appendChild(titleDiv);
    titleRow.appendChild(ttlDiv);
  
    const bodyDiv = document.createElement('div');
    bodyDiv.className = 'message-body';
    bodyDiv.textContent = body;
  
    titleRow.addEventListener('click', () => {
      container.classList.toggle('active');
    });
  
    container.appendChild(titleRow);
    container.appendChild(bodyDiv);
    messageList.appendChild(container);
  
    // TTL countdown and auto-deletion
    if (ttl > 0) {
      const interval = setInterval(() => {
        ttl--;
        ttlDiv.textContent = ttl;
  
        if (ttl <= 0) {
          clearInterval(interval);
          container.remove();
        }
      }, 1000);
    }
    else {
      ttlDiv.remove();
    }
  }
  

  
  
  