function sendMessage() {
    // Get the fields
    const titleField = document.getElementById("title");
    const messageField = document.getElementById("message");
    const ttlField = document.getElementById("timeout");

    // Get their values
    const title = titleField.value.trim();
    const message = messageField.value.trim();
    const ttl = ttlField.value.trim();

    // Reset styles
    titleField.style.borderColor = '';
    messageField.style.borderColor = '';
    ttlField.style.borderColor = '';

    let hasError = false;

    // Check title and message
    if (!title) {
      titleField.style.borderColor = 'red';
      hasError = true;
    }

    if (!message) {
      messageField.style.borderColor = 'red';
      hasError = true;
    }

    // Check if ttl is correct
    const ttlNum = parseInt(ttl);
    if (isNaN(ttlNum) || ttlNum < 5 || ttlNum > 600) {
      ttlField.style.borderColor = 'red';
      hasError = true;
    }

    //Check if the title already exists
    const existingTitles = document.querySelectorAll('.message-title');
    for (const t of existingTitles) {
      if (t.textContent.trim() === title) {
        titleField.style.borderColor = 'red';
        hasError = true;
        break;
      }
    }

    if (hasError) {
      return;
    }


    fetch(window.location.pathname, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: title,
          message: message,
          ttl: ttlNum
        })
      })
      .then(response => {
        if (response.ok) {
          addMessage(titleField.value, messageField.value, ttlField.value)
          titleField.value = '';
          messageField.value = '';
          ttlField.value = '';
        } else {
          return response.text().then(text => { throw new Error(text); });
        }
      })
      .catch(error => {
        console.error("Error sending message:", error);
        alert("Failed to send message.");
      });
}
