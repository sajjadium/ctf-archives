#!/bin/bash
export LD_PRELOAD=./mad_lib.so
/bin/bash

