#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

#define MAX_FILE_SIZE 256
#define MAX_NAME_SIZE 64

char filename[MAX_NAME_SIZE];

int parse_touch(char *const argv[]);
int parse_mv(char *const argv[]);
int parse_cat(char *const argv[]);
int parse_echo(char *const argv[]);
int parse_exit(char *const argv[]);
void leak();

typedef int (*orig_execve_type)(const char *filename, char *const argv[], char *const envp[]);


int get_argc(char *const argv[]){
    int argc = 0;
    for (argv; *argv != NULL; argv++) {
        argc++;
    }
    return argc;
}

int get_file_size(const char *filename) {
    FILE *file = fopen(filename, "rb"); 
    if (!file) {
        return -1;
    }
    fseek(file, 0, SEEK_END);
    int size = ftell(file);
    fclose(file);

    return size;
}

bool is_ascii(const char *title) {
    if (title == NULL) return false; 

    for (const char *ptr = title; *ptr != '\0'; ptr++) {
        if (*ptr > 127 || *ptr < 48) {
            return false;
        }
    }
    return true;
}

int get_len(const char *str) {
    int count = 0;
    while (*str) {
        if (*str != '\x0a') {
            count++;
        }
        str++;
    }
    return count;
}

int execve(const char *filename, char *const argv[], char *const envp[]) {
    orig_execve_type orig_execve;
    orig_execve = (orig_execve_type)dlsym(RTLD_NEXT, "execve");

    if(strncmp(filename, "/usr/bin/cat", 12) == 0){
        if(parse_cat(argv))
        {
            return orig_execve(filename, argv, envp);
        }
    }
    if(strncmp(filename, "/usr/bin/touch", 14) == 0){
        if (parse_touch(argv))
        {
            return orig_execve(filename, argv, envp);
        }
    }
    if(strncmp(filename, "/usr/bin/mv", 11) == 0){
        if (parse_mv(argv))
        {
            return orig_execve(filename, argv, envp);
        }
    }
    if (strncmp(filename, "/usr/bin/echo", 13) == 0) {
        if (parse_echo(argv)) {
            return orig_execve(filename, argv, envp);
        }
    }
    if(strncmp(filename, "/usr/bin/exit", 14) == 0) {
        if (parse_exit(argv)) {
            return orig_execve(filename, argv, envp);
        }
    }
    if(strncmp(filename, "/usr/bin/pwd",12) == 0){
        return orig_execve(filename, argv, envp);
    }

    return 0;
    
}

int parse_touch(char *const argv[]){
    int argc = get_argc(argv);
    char *title;
    
    if(argc != 2){
        return 0;
    }
    title = argv[1];
    if(get_len(title) > 0x32){
        return 0;
    }
    if(!is_ascii(title)){
        return 0;
    }
    return 1;
}

int parse_cat(char *const argv[]) {
    int i = 1;
    char data[MAX_FILE_SIZE];
    while (argv[i] != NULL) {
        if(strncmp(argv[i], ".leak", 5) == 0){
            leak();
            return 1;
        }else if (strncmp(argv[i], "/home/mad_user/mad_admin", 24) == 0 && strchr(argv[i],'.') == 0) {
            strncpy(filename, argv[i], MAX_NAME_SIZE-1);
            filename[sizeof(filename) - 1] = '\0';
            int filesize = get_file_size(argv[i]);
            int fd = open(argv[i], O_RDONLY);
            if (fd == -1) {
                return 0;
            }
            read(fd, data, filesize);
            close(fd);
            if(strncmp(data, "MCTF", 4) == 0){
                return 0;
            }
            return 1;
        }
        i++;
    }
    return 0;
}

int parse_mv(char *const argv[]) {
    if (argv[1] == NULL || argv[2] == NULL || strncmp(argv[1], "-", 1) == 0 || strncmp(argv[2], "-", 1)) {
        return 0;
    }
    char *old_title = argv[1];
    char *new_title = argv[2];
    if(get_len(new_title) <= get_len(old_title) || !is_ascii(new_title) || strchr(new_title,'.') == 0){
        return 0;
    }

    return 1;
}


int parse_echo(char *const argv[]) {
    char *buffer[MAX_FILE_SIZE];
    if (argv[1] && strcmp(argv[1], "-ne") == 0 && argv[2]) {
        size_t msg_len = get_len(argv[2]);
        if (msg_len < MAX_FILE_SIZE) {
            return 1;
        }
    }else{
        return 0;
    }
    return 1;
}

int parse_exit(char *const argv[]){
    const char *file_leak = ".leak";
    if (access(file_leak, F_OK) == 0) {
        remove(file_leak);
    }else{
        /*TO CHANGE*/
        __asm__("push $0x1");
        __asm__("push $0x1");
        __asm__("push $0x1");
        __asm__("pop %rdi;");
        __asm__("pop %rsi");
        __asm__("pop %rdx");
        __asm__("pop %r8;");
        __asm__("ret");
    }
    return 1;
}

void leak() {
    FILE *fp = fopen(".leak", "w");
    fprintf(fp, "*execve=%p\n", (void *)execve);
    fclose(fp);
}