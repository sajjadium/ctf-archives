#ifndef _AMSTRAD_H
#define _AMSTRAD_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

#define SCREEN_WIDTH    40
#define SCREEN_HEIGHT   20
#define PROMPT_USER     " > \n"
#define CMD_SIZE        SCREEN_WIDTH + 2

struct color {
    uint8_t r;
    uint8_t g;
    uint8_t b;
} typedef color_t;

struct screen {
    color_t border_color;
    color_t bg_color;
    color_t fg_color;
    char cells[SCREEN_HEIGHT][SCREEN_WIDTH];
} typedef screen_t;

void amstrad_roll(screen_t *screen, char *last_line);
bool amstrad_input_fmt(screen_t *screen, const char* fmt, void* result);

#endif // _AMSTRAD_H
