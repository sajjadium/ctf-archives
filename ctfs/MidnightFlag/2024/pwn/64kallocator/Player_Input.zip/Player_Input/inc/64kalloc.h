#ifndef _64KALLOC_H
#define _64KALLOC_H

#include "amstrad.h"

#define PER_ZONE_REGIONS_COUNT  0x40
#define REGION_SIZE             0x400
#define IN_USE_BIT              (((uint16_t) 1) << 15)

struct a64kcheader {

    uint32_t cookie;
    uint16_t padding;
    uint16_t chunk_size;
    struct a64kcheader *prev;
    struct a64kcheader *next;

} typedef a64kcheader_t;

struct a64krheader {

    void* next_available_chunk;
    uint32_t available_bytes;
    uint32_t cookie;

} typedef a64krheader_t;

struct a64kregion_s {

    a64krheader_t header;
    uint8_t bytes[REGION_SIZE - sizeof(a64krheader_t)];

} typedef a64kregion_t; 

struct a64kzone_s {

    a64kregion_t regions[PER_ZONE_REGIONS_COUNT];
    a64kcheader_t *freelist;

} typedef a64kzone_t;

void amstrad_64kinit();
void amstrad_64khelp(screen_t *screen);
void amstrad_64kalloc(screen_t *screen);
void amstrad_64kfree(screen_t *screen);
void amstrad_64kview(screen_t *screen);
void amstrad_64kedit(screen_t *screen);

#endif // _64KALLOC_H