#include "amstrad.h"
#include "64kalloc.h"

screen_t basic_screen = {0,};

void amstrad_secret() {
    amstrad_roll(&basic_screen, "MCTF{...}");
}

void amstrad_display(screen_t *screen) {

    for (uint8_t i = 0; i < UINT8_MAX; i++) { printf("\n"); }

    for (uint8_t w=0; w < SCREEN_WIDTH+4; w++) {
        printf(
            "\e[48;2;%d;%d;%dm \e[m",
            screen->border_color.r,
            screen->border_color.g,
            screen->border_color.b
        );
    } printf("\n");

    for (uint8_t h=0; h < SCREEN_HEIGHT; h++) {

        printf("\e[48;2;%d;%d;%dm  \e[m", screen->border_color.r, screen->border_color.g, screen->border_color.b);

        printf(
                "\e[48;2;%d;%d;%d;38;2;%d;%d;%dm",
                screen->bg_color.r,
                screen->bg_color.g,
                screen->bg_color.b,
                screen->fg_color.r,
                screen->fg_color.g,
                screen->fg_color.b
        );

        for (uint8_t w=0; w < SCREEN_WIDTH; w++) { printf("%c", screen->cells[h][w]); }
        printf("\e[m");

        printf("\e[48;2;%d;%d;%dm  \e[m", screen->border_color.r, screen->border_color.g, screen->border_color.b);
        printf("\n");
    }

    for (uint8_t w=0; w < SCREEN_WIDTH+4; w++) {
        printf(
            "\e[48;2;%d;%d;%dm \e[m",
            screen->border_color.r,
            screen->border_color.g,
            screen->border_color.b
        );
    } printf("\n");
}

void amstrad_roll(screen_t *screen, char *last_line) {
    
    size_t ll_size = strlen(last_line);

    for (uint8_t h=1; h < SCREEN_HEIGHT; h++) {
        strncpy(screen->cells[h-1], screen->cells[h], SCREEN_WIDTH);
    }

    for (uint8_t w=0; w < SCREEN_WIDTH; w++) { screen->cells[SCREEN_HEIGHT-1][w] = 0x20; }

    if (ll_size > SCREEN_WIDTH) {
        memcpy(screen->cells[SCREEN_HEIGHT-1], last_line, SCREEN_WIDTH);
        screen->cells[SCREEN_HEIGHT-1][SCREEN_WIDTH-1] = '.';
        screen->cells[SCREEN_HEIGHT-1][SCREEN_WIDTH-2] = '.';
        screen->cells[SCREEN_HEIGHT-1][SCREEN_WIDTH-3] = '.';
    }

    else { memcpy(screen->cells[SCREEN_HEIGHT-1], last_line, ll_size); }

    amstrad_display(screen);
}

void amstrad_handle(screen_t *screen, char *cmd) {

    if (!strcmp(cmd, "help")) { amstrad_64khelp(screen); }

    else if (!strcmp(cmd, "64kalloc"))  { amstrad_64kalloc(screen); }
    else if (!strcmp(cmd, "64kfree"))   { amstrad_64kfree(screen); }
    else if (!strcmp(cmd, "64kview"))   { amstrad_64kview(screen); }
    else if (!strcmp(cmd, "64kedit"))   { amstrad_64kedit(screen); }
    else if (!strcmp(cmd, "exit"))      { amstrad_roll(screen, "Shuting down..."); }

    else { amstrad_roll(screen, "Unknown command !"); }
}

bool amstrad_input_cmd(screen_t *screen) {

    char cmd[CMD_SIZE] = {0, };

    printf(PROMPT_USER);

    fgets(cmd, sizeof(cmd), stdin);
    if (!strchr(cmd, '\n')) {
        char c = ' ';
        while (c != '\n') { c = fgetc(stdin); }
    }

    cmd[strcspn(cmd, "\n")] = '\0';
    amstrad_roll(screen, cmd);

    amstrad_handle(screen, cmd);

    return strcmp(cmd, "exit");
}

bool amstrad_input_fmt(screen_t *screen, const char* fmt, void* result) {

    char input[CMD_SIZE] = {0, };

    printf(PROMPT_USER);

    fgets(input, sizeof(input), stdin);
    if (!strchr(input, '\n')) {
        char c = ' ';
        while (c != '\n') { c = fgetc(stdin); }
    }

    input[strcspn(input, "\n")] = '\0';
    amstrad_roll(screen, input);

    if (sscanf(input, fmt, result) == 0) {
        amstrad_roll(screen, " Syntax error !");
        return false;
    }

    else { return true; }
}

int main() {

    amstrad_64kinit();

    basic_screen.border_color.r = 100;
    basic_screen.border_color.g = 100;
    basic_screen.border_color.b = 255;
    
    basic_screen.bg_color.r = 0;
    basic_screen.bg_color.g = 0;
    basic_screen.bg_color.b = 255;

    basic_screen.fg_color.r = 255;
    basic_screen.fg_color.g = 255;
    basic_screen.fg_color.b = 0;

    for (uint8_t h=0; h < SCREEN_HEIGHT; h++) {
        for (uint8_t w=0; w < SCREEN_WIDTH; w++) { basic_screen.cells[h][w] = 0x20; }
    }

    amstrad_roll(&basic_screen, " Amstrad 64K Microcomputer (v0.1)");
    amstrad_roll(&basic_screen, " c 1984 Amstrad Consumer Electronic plc");
    amstrad_roll(&basic_screen, "           and Locomotive Software Ltd.");
    amstrad_roll(&basic_screen, "");
    amstrad_roll(&basic_screen, " BASIC 1.0");
    amstrad_roll(&basic_screen, "");
    amstrad_roll(&basic_screen, " Currently running program: '64kalloc'");
    amstrad_roll(&basic_screen, "");

    while (amstrad_input_cmd(&basic_screen)) { continue; }

    return 0;
}
