#include "64kalloc.h"
#include <sys/mman.h>
#include <unistd.h>

a64kcheader_t freelist_head = {
    .padding = 0,
    .chunk_size = 0,
    .cookie = 0,
    .prev = &freelist_head,
    .next = &freelist_head
};

a64kzone_t *a64kzone = NULL;

void amstrad_64kinit() {

    a64kzone = mmap((void *) 0x100000000, sizeof(a64kzone_t), PROT_READ | PROT_WRITE, MAP_ANON | MAP_PRIVATE, 0, 0);
    memset((void*) a64kzone, 0, sizeof(a64kzone_t));

    a64kzone->freelist = &freelist_head;
}

bool amstrad_64kcheck(screen_t* screen, a64kcheader_t *address) {

    for (uint16_t region_id = 0; region_id < PER_ZONE_REGIONS_COUNT; region_id++) {

        a64kregion_t *region = &a64kzone->regions[region_id];
        if (region->header.cookie) {

            if (address >= ((a64kcheader_t *) &region->bytes) && address < ((a64kcheader_t *) (region + 1))) {
                    
                    if ((address->cookie == region->header.cookie) && (address->chunk_size & IN_USE_BIT)) {
                        return true;
                    }
                    else { break; }
                }
            }

        else { break; }
    }

    amstrad_roll(screen, " Invalid address !");
    return false;
}

void amstrad_64khelp(screen_t *screen) {
    amstrad_roll(screen, "");
    amstrad_roll(screen, "Available commands :");
    amstrad_roll(screen, " - help      (display this helper)");
    amstrad_roll(screen, " - 64kalloc  (alloc a chunk of memory)");
    amstrad_roll(screen, " - 64kfree   (free a chunk of memory)");
    amstrad_roll(screen, " - 64kview   (inspect a memory chunk)");
    amstrad_roll(screen, " - 64kedit   (edit a memory chunk)");
    amstrad_roll(screen, " - exit      (exit this program)");
    amstrad_roll(screen, "");
}

void amstrad_64kalloc(screen_t *screen) {

    uint16_t chunk_size = 0;
    bool is_allocated = false;
    char result[CMD_SIZE] = {0, };

    amstrad_roll(screen, " Chunk size ?");
    if (amstrad_input_fmt(screen, "%hu", &chunk_size)) {

        chunk_size += sizeof(a64kcheader_t);

        if ((chunk_size) > 0x40) { amstrad_roll(screen, " Chunk size is too big ! 2000's Dude..."); }

        else {

            a64kcheader_t *candidate = a64kzone->freelist->next;

            while (candidate != a64kzone->freelist) {

                if (candidate->chunk_size == chunk_size) {

                    candidate->chunk_size |= IN_USE_BIT;
                    
                    candidate->prev->next = candidate->next;
                    candidate->next->prev = candidate->prev;

                    candidate->prev = NULL;
                    candidate->next = NULL;

                    for (uint16_t region_id = 0; region_id < PER_ZONE_REGIONS_COUNT; region_id++) {

                        a64kregion_t *region = &a64kzone->regions[region_id];

                        if (candidate >= ((a64kcheader_t *) &region->bytes) && candidate < ((a64kcheader_t *) (region + 1))) {
                            candidate->cookie = region->header.cookie;
                            break;
                        }
                    }

                    sprintf(result, " Chunk allocated @ %p !", candidate);
                    is_allocated = true;
                    break;
                }
                candidate = candidate->next;
            }

            if (!is_allocated) {
                for (uint16_t region_id = 0; region_id < PER_ZONE_REGIONS_COUNT; region_id++) {

                    a64kregion_t *current = &a64kzone->regions[region_id];

                    if (current->header.cookie == 0) {
                        current->header.next_available_chunk = ((uint8_t*) current) + sizeof(a64krheader_t);
                        current->header.available_bytes = REGION_SIZE - sizeof(a64krheader_t) + 1;
                        current->header.cookie = arc4random();
                    }

                    if (chunk_size <= current->header.available_bytes) {

                        a64kcheader_t *chunk_header = current->header.next_available_chunk;

                        chunk_header->chunk_size = chunk_size | IN_USE_BIT;
                        chunk_header->cookie = current->header.cookie;

                        current->header.next_available_chunk += chunk_size;
                        current->header.available_bytes -= chunk_size;

                        sprintf(result, " Chunk allocated @ %p !", chunk_header);
                        is_allocated = true;
                        break;
                    }
                }
            }

            if (is_allocated) { amstrad_roll(screen, result); } 
            else { amstrad_roll(screen, " Error while trying to allocate"); }
        }
    }
}

void amstrad_64kfree(screen_t *screen) {

    a64kcheader_t *chunk = NULL;
    
    amstrad_roll(screen, " Chunk address ?");
    if (amstrad_input_fmt(screen, "%p", &chunk)) {

        if (amstrad_64kcheck(screen, chunk)) {

            chunk->chunk_size &= (~IN_USE_BIT);

            a64kzone->freelist->prev->next = chunk;
            chunk->prev = a64kzone->freelist->prev;

            a64kzone->freelist->prev = chunk;
            chunk->next = a64kzone->freelist;
        }
    }
}

void amstrad_64kview(screen_t *screen) {

    a64kcheader_t *chunk = NULL;
    
    amstrad_roll(screen, " Chunk address ?");
    if (amstrad_input_fmt(screen, "%p", &chunk)) {
        if (amstrad_64kcheck(screen, chunk)) { amstrad_roll(screen, (char *) chunk + 8); }
    }
}

void amstrad_64kedit(screen_t *screen) {

    a64kcheader_t *chunk = NULL;
    char *data = NULL;
    uint16_t size = 0;

    amstrad_roll(screen, " Chunk address ?");
    if (amstrad_input_fmt(screen, "%p", &chunk)) {

        if (amstrad_64kcheck(screen, chunk)) {

            data = (char *) chunk + 8;
            size = (chunk->chunk_size & (~IN_USE_BIT)) - 8;

            amstrad_roll(screen, " Chunk content ?");

            printf(PROMPT_USER);

            fgets(data, size, stdin);
            if (!strchr(data, '\n')) {
                char c = ' ';
                while (c != '\n') { c = fgetc(stdin); }
            }

            data[strcspn(data, "\n")] = '\0';

            amstrad_roll(screen, data);
        }
    }
}