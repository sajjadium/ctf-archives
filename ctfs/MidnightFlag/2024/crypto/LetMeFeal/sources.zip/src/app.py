import os
import random
from utils.feal_nx import *

seed = random.randint(0, 2**20)

def custom_fbox(α: int, β: int) -> bytes:
	return α ^ β ^ seed

class challenge:
	def __init__(self):
		self.key = os.urandom(16)
		self.feal = Feal_NX(
			rounds=2**8,
			key=self.key,
			Fbox=custom_fbox
		)

		bloc = bytes(list(range(16)))
		assert self.feal.decrypt(self.feal.encrypt(bloc)) == bloc

	def send_flag_enc(self):
		flag = os.getenv('FLAG', 'flag{This1sAFakeFl@g}').encode()
		flag_enc = self.feal.encrypt(flag)
		print(f'Here is the ciphered flag: {flag_enc.hex()}')

	def run(self):
		self.send_flag_enc()

		print(f'The seed is: {seed}')
		print('Encryption oracle starts now: ')
		while 1:
			x = input('x=')
			try:				
				fx = self.feal.encrypt(bytes.fromhex(x))
				print(f'feal(x)={fx.hex()}')
			except:
				print('An error occured !')


challenge().run()