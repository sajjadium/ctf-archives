def split(L_R: int) -> list[int]:
	return (L_R >> 32, L_R & ((1 << 32) - 1))


def join(L: int, R: int, k: int=8) -> int:
	return (L << k) | (R << 0)


def bytes2int(array: list[int]) -> int:
	return (array[0] << 24) | (array[1] << 16) | (array[2] << 8) | (array[3] << 0) 


def int2bytes(x: int, k:int = 4) -> bytes:
	return bytes([(x >> 8 * _) & 0xFF for _ in range(k)])[::-1]

def F(α: int, β: int) -> bytes:
	α0, α1, α2, α3 = int2bytes(α)
	β0, β1, β2, β3 = int2bytes(β)
	f1 = α1^β0					# f1 = α1 ⊕ β0
	f2 = α2^β1					# f2 = α2 ⊕ β1
	f1 = f1^α0					# f1 = f1 ⊕ α0
	f2 = f2^α3					# f2 = f2 ⊕ α3
	f1 = S1(f1,f2)				# f1 = S1(f1, f2)
	f2 = S0(f2,f1)				# f2 = S0(f2, f1)
	f0 = S0(α0,f1)				# f0 = S0(α0, f1)
	f3 = S1(α3,f2)				# f3 = S1(α3, f2) 
	return bytes2int([f0, f1, f2, f3])


def Fk(α: int, β: int) -> bytes:
	α0, α1, α2, α3 = int2bytes(α)
	β0, β1, β2, β3 = int2bytes(β)
	fk1 = α1^α0					# fK1 = α1 ⊕ α0
	fk2 = α2^α3					# fK2 = α2 ⊕ α3
	fk1 = S1(fk1, fk2^β0)		# fK1 = S1 (fK1, fK2 ⊕ β0)
	fk2 = S0(fk2, fk1^β1)		# fK2 = S0 (fK2, fK1 ⊕ β1)
	fk0 = S0(α0, fk1^β2)		# fK0 = S0 (α0, fK1 ⊕ β2)
	fk3 = S1(α3, fk2^β3)		# fK3 = S1 (α3, fK2 ⊕ β3)
	return [fk0, fk1, fk2, fk3]


def S1(X1:int, X2:int):
	return S0(X1,X2,k=1)


def S0(X1, X2, k:int = 0) -> int:
	def rot2(T,bit_block=8):
		return (T << 2)|(T >> (bit_block - 2))
	return rot2((X1 + X2 + k) % 256) % 256