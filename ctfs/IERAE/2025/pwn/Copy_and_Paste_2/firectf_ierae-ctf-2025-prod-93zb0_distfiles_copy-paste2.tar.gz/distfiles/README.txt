This is a revision of last year's “Copy & Paste” problem.
For the solution of last year's problem, please refer to <a>https://github.com/gmo-ierae/ierae-ctf-2024/blob/main/pwn/copy_and_paste/solution/solve.py</a> and <a>https://gmo-cybersecurity.com/blog/ierae-ctf-2024-writeup-pwn/#b</a>.
For the latter page, maybe you need LLM for translation (but rather LLM is enough I guess!).
