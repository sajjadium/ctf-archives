<?php
return [
    'debug' => false,
    'default_module' => 'default',
    'default_controller' => 'Index',
    'default_action' => 'index',
    'module_namespace' => 'App\\Modules',
];