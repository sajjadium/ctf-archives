export const OIDC_HOST =
	process.env.OIDC_HOST || "http://ojiid.127-0-0-1.nip.io:36001";
export const OIDC_CLIENT = process.env.OIDC_CLIENT || "ojimemo";
export const APP_HOST = process.env.APP_HOST || "http://ojimemo.127-0-0-1.nip.io:36000";
