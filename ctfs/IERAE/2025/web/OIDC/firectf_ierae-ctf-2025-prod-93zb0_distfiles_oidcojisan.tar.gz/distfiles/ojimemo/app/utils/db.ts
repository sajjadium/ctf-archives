// user id -> default language map
export const langDB = new Map<string, string>();

export const memoDB = new Map<string, string>();
