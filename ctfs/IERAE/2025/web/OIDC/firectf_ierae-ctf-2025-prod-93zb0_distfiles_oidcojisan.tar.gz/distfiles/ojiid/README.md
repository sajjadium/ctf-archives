# OjiID - Ojisan OIDC Provider

OjiID is an OpenID Connect (OIDC) provider for Ojisan.
