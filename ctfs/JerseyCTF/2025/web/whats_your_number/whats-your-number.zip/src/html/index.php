<?php
require_once('includes/checkAuth.inc');
require_once('includes/checkSource.inc');

checkAuth();
checkSource();

$pageTitle = 'Main Menu';
?>

<!DOCTYPE html>
<html>
  <head>
    <?php require_once('includes/head.inc'); ?>
  </head>
  <body>
    <?php require_once('includes/header.inc'); ?>
    <main>
      <?php require_once('includes/nav.inc'); ?>
      <h3>Select a navigation function.</h3>
    </main>
  </body>
</html>