<?php
require_once('includes/checkAuth.inc');
require_once('includes/db.inc');

$sessionCookie = checkAuth(true, true);

$db = getDb();
$logoutStmt = $db->prepare("UPDATE sessions SET expires=strftime('%s') WHERE token=:token");
$logoutStmt->bindValue(':token', $sessionCookie);
$logoutStmt->execute();
$db->close();
unset($_COOKIE['SESSION']);
setcookie('SESSION', '', time() - 3600);
header('Location: /login.php');
exit();
