<?php
require_once('includes/checkAuth.inc');
require_once('includes/checkSource.inc');

checkAuth();
checkSource();

$pageTitle = 'API Docs';
?>

<!DOCTYPE html>
<html>
  <head>
    <?php require_once('includes/head.inc'); ?>
  </head>
  <body>
    <?php require_once('includes/header.inc'); ?>
    <main>
      <?php require_once('includes/nav.inc'); ?>
      <h3>Available API Functions:</h3>
      <ul>
        <li><pre>getFlag.php</pre></li>
        <li><pre>runCommand.php</pre></li>
      </ul>
    </main>
  </body>
</html>