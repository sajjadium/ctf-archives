<?php
require_once('../includes/checkSource.inc');
require_once('../includes/checkApi.inc');

checkSource();
checkApi();

$command = filter_input(INPUT_GET, 'command');

header('Content-Type: text/plain');
$shell = '/usr/local/bin/run-sandbox';
echo($shell . ' ' . $command);
$handle = popen($shell, 'w');
fwrite($handle, $command);
pclose($handle);
echo(shell_exec($command));
