<?php
require_once('../includes/checkSource.inc');
require_once('../includes/checkApi.inc');

checkSource();
checkApi();

header('Content-Type: text/plain');
echo(getenv('SUPER_SECRET_FLAG'));
