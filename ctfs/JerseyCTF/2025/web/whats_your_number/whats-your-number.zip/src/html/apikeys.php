<?php

require_once('includes/checkAuth.inc');
require_once('includes/checkSource.inc');
require_once('includes/db.inc');

$username = checkAuth();
checkSource();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $key = filter_input(INPUT_POST, 'key', FILTER_SANITIZE_SPECIAL_CHARS);

  if (isset($key) && strlen($key) >= 32) {
    $db = getDb();
    $insertStmt = $db->prepare('INSERT OR REPLACE INTO apikeys VALUES 
    (:key, (SELECT id from users WHERE username=:username), :expires)');
    $insertStmt->bindValue(':username', $username);
    $insertStmt->bindValue(':key', $key);
    $insertStmt->bindValue(':expires', (time() + 60));
    $insertStmt->execute();
    $db->close();
  } else {
    $errorMsg = 'API key must be at least 32 characters.';
  }
}

$dbRo = getDb(true);
$keyStmt = $dbRo->prepare("SELECT users.username, apikeys.apikey, apikeys.expires FROM users, apikeys 
WHERE users.username=:username AND apikeys.user_id=users.id AND apikeys.expires > strftime('%s')");
$keyStmt->bindValue(':username', $username);
$keyResults = $keyStmt->execute();
$keyArr = [];
while ($row = $keyResults->fetchArray(SQLITE3_ASSOC)) {
  array_push($keyArr, $row);
}
$dbRo->close();

$pageTitle = 'API Key Management';
?>
<!DOCTYPE html>
<html>
  <head>
    <?php require_once('includes/head.inc'); ?>
  </head>
  <body>
    <?php require_once('includes/header.inc'); ?>
    <main>
      <?php require_once('includes/nav.inc'); ?>
      <?php
      if (isset($errorMsg)) {
        ?>
        <p class="error"><?= $errorMsg ?></p>
        <?php
      }
      ?>
      <table>
        <tr>
          <th>Username</th>
          <th>API Key</th>
          <th>Expires</th>
        </tr>
        <?php foreach($keyArr as &$key) {
          ?>
        <tr>
            <td><?= htmlspecialchars($key['username']) ?></td>
            <td><?= htmlspecialchars($key['apikey']) ?></td>
            <td><?= htmlspecialchars($key['expires']) ?></td>
        </tr>
        <?php } ?>
      </table>
      <form method="post">
        <div>
          <label for="key">Add Key</label>
          <input name="key" id="key" type="text" minlength="32" required>
        </div>
        <input type="Submit">
      </form>
    </main>
  </body>
</html>
