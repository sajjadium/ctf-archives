<?php
require_once('includes/checkAuth.inc');
require_once('includes/db.inc');
if ($checkAuthResult = checkAuth(false)) {
  header('Location: /');
  exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = filter_input(INPUT_POST, 'username');
  $password = filter_input(INPUT_POST, 'password');

  $dbRo = getDb(true);
  $loginResult = $dbRo->query("SELECT * FROM users WHERE username='{$username}'");
  $loginArr = $loginResult->fetchArray();
  $dbRo->close();
  if ($loginArr[0] == null) {
    $errorMsg = 'Incorrect username or password.';
  } else if (!password_verify($password, $loginArr['password'])) {
    $errorMsg = 'Incorrect username or password.';
  } else {
    $sessionToken = uniqid();
    setcookie('SESSION', $sessionToken, time() + 3600);
    $db = getDb();
    $sessionStmt = $db->prepare("INSERT INTO sessions VALUES (:sessionToken, :loginId, :expires)");
    $sessionStmt->bindValue(':sessionToken', $sessionToken);
    $sessionStmt->bindValue(':loginId', $loginArr['id']);
    $sessionStmt->bindValue(':expires', (time() + 3600));
    $sessionStmt->execute();
    $db->close();
    header('Location: /');
    exit();
  }
}

$pageTitle = 'Login';
?>
<!DOCTYPE html>
<html>
  <head>
    <?php require_once('includes/head.inc'); ?>
  </head>
  <body>
    <?php require_once('includes/header.inc'); ?>
    <main>
      <?php
        if(isset($errorMsg)) {
          ?>
          <p class="error"><?= $errorMsg ?></p>
          <?php
        }
      ?>
      <form method="post">
        <div>
          <label for="username">Username:</label>
          <input type="text" name="username" id="username" required>
        </div>
        <div>
          <label for="password">Password:</label>
          <input type="password" name="password" id="password" required>
        </div>
        <input type="submit" value="Login">
      </form>
    </main>
  </body>
</html>