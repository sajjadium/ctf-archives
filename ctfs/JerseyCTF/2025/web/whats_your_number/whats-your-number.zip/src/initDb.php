#!/usr/bin/env php
<?php

$dbFile = '/var/db/sqlite/db.sqlite';

if (file_exists($dbFile)) {
  unlink($dbFile);
}

$db = new SQLite3($dbFile);

$db->query('CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL
)');

$db->query('CREATE TABLE sessions (
  token TEXT PRIMARY KEY NOT NULL,
  user_id INTEGER NOT NULL,
  expires INTEGER NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
)');

$db->query('CREATE TABLE apikeys (
  apikey TEXT PRIMARY KEY NOT NULL,
  user_id INTEGER NOT NULL,
  expires INTEGER NOT NULL,
  FOREIGN KEY(user_id) REFERENCES users(id)
)');

$db->query("INSERT INTO users VALUES (
  null,
  'admin',
  '" . password_hash('not_the_real_password', PASSWORD_DEFAULT) . "'
)");

$db->close();
