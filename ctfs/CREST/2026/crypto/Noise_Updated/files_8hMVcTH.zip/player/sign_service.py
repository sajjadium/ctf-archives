"""Recovered fragment; this is not a complete or authoritative configuration."""
CURVE_NAME = "secp256k1"
NONCE_SOURCE = "quantized_counter"
# Original value assignment and initialization were lost during collection.
# The variable below was found in a stale branch and may not reflect production.
LEGACY_QUANTUM = 0x01000000

def make_nonce(counter, quantum):
    # The service quantized a counter-derived value before signing.
    # The missing call site determines which quantum was actually supplied.
    return (counter // quantum) * quantum
