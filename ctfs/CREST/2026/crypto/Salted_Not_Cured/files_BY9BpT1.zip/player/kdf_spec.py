# CRY-04: Salted, Not Cured
# Player-facing derivation and vault-format specification.
#
# No password, flag, or generation secret is present in this file.

import hashlib
import struct
from datetime import datetime

SALT_DOMAIN = b"CRY-04/SALTED-NOT-CURED/v1"
SALT_LENGTH = 16
KEY_LENGTH = 32
KDF_NAME = "PBKDF2-HMAC-SHA256"

def derive_salt(created_at: str) -> bytes:
    """Derive the 16-byte salt from the vault creation timestamp."""
    dt = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    timestamp = int(dt.timestamp())
    return hashlib.sha256(
        SALT_DOMAIN + timestamp.to_bytes(8, "big") + b"|salt"
    ).digest()[:SALT_LENGTH]

def derive_key(password: str, created_at: str, iterations: int) -> bytes:
    return hashlib.pbkdf2_hmac(
        "sha256",
        password.encode(),
        derive_salt(created_at),
        iterations,
        KEY_LENGTH,
    )

def parse_vault(blob: bytes):
    """Return iterations, nonce and ciphertext+tag from vault.bin."""
    if blob[:5] != b"SNCV1":
        raise ValueError("bad magic")
    iterations = struct.unpack(">I", blob[5:9])[0]
    nonce_len = blob[9]
    ciphertext_len = struct.unpack(">I", blob[10:14])[0]
    nonce_start = 14
    nonce_end = nonce_start + nonce_len
    ct_end = nonce_end + ciphertext_len
    if ct_end != len(blob):
        raise ValueError("length mismatch")
    return iterations, blob[nonce_start:nonce_end], blob[nonce_end:ct_end]
