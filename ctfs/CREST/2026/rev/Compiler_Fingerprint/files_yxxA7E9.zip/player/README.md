# Compiler Fingerprint

Category: Reverse Engineering
Challenge ID: REV-6

Multiple Ghost Mantis tools were recovered during incident response.

Though they serve different purposes, forensic analysts believe they share a common origin.

Identify the compiler and build fingerprint that links these binaries together.

Flag format: CREST{compiler_version_buildtraits}

## Challenge files

- mantis_alpha
- mantis_beta
- mantis_gamma

Submit one complete flag. Preserve the original challenge files during analysis.
