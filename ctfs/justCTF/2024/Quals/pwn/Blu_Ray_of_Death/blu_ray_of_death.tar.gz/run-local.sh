#!/usr/bin/env bash

set -o errexit -o pipefail -o nounset


# Port to which the task will be exposed
PORT="${1-1337}"

# No spaces here
NAME=zaje-bluray

# Build task docker image
export DOCKER_BUILDKIT=1
if ! docker buildx inspect --builder ${NAME}-builder; then
	docker buildx create --name ${NAME}-builder --buildkitd-flags '--allow-insecure-entitlement security.insecure'
fi
docker buildx build --builder ${NAME}-builder --allow security.insecure --load -t ${NAME} -f docker/Dockerfile .


docker rm -f ${NAME} || true
docker run --rm -it \
	--name=${NAME} \
	--privileged \
	-p "$PORT":1337 \
	${NAME}
