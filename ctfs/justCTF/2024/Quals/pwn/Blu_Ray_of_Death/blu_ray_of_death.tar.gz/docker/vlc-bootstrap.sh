#!/bin/sh

echo 'Send your video file as base64, end with "@" (on a separate line).'
touch /tmp/video.b64
while IFS= read -r line; do
	if [ "$line" = @ ]; then
		break
	fi
	printf '%s' "$line" >>/tmp/video.b64
done
base64 -d </tmp/video.b64 >/tmp/video
rm /tmp/video.b64

printf 'md5sum: '
md5sum /tmp/video

echo "Thanks! 😋"

timeout 30s /cvlc bluray:///tmp/video
