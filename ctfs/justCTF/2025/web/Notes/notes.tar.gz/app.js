const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const crypto = require('node:crypto')
const visit = require('./bot.js')
const SECRET = crypto.randomBytes(24).toString('hex');

const app = express();

const users = [];
const notes = [];

app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", "script-src 'none';");
    next();
});

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

function requireLogin(req, res, next) {
    if (!req.session.userId) return res.redirect('/login');
    next();
}


app.get('/', (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    const user = users.find(u => u.id === req.session.userId);
    const userNotes = notes.filter(note => note.userId === user.id);
    res.render('index', { user, notes: userNotes });
});

app.get('/register', (req, res) => {
    res.render('register');
});

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    if (typeof username != 'string' || typeof password != 'string') {
        res.send("Invalid data!")
        return;
    }
    if (users.find(u => u.username === username)) return res.send('User already exists.');
    const user = { id: crypto.randomUUID(), username, password };
    users.push(user);
    req.session.userId = user.id;
    res.redirect('/');
});

app.get('/login', (req, res) => {
    res.render('login');
});

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (typeof username != 'string' || typeof password != 'string') {
        res.send("Invalid data!")
        return;
    }
    const user = users.find(u => u.username === username);
    if (!user || user.password !== password) {
        return res.send('Invalid username or password.');
    }
    req.session.userId = user.id;
    res.redirect('/');
});

app.get('/logout', (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
});

app.post('/add-note', requireLogin, (req, res) => {
    if (typeof req.body.content != 'string') {
        res.send("Invalid data!")
        return;
    }
    const userNotes = notes.filter(note => note.userId === req.session.userId);
    const nextNumber = userNotes.length + 1;
    const title = `Note ${nextNumber}`;
    const id = crypto.randomUUID();
    notes.push({ id, userId: req.session.userId, title, content: req.body.content });
    res.redirect('/');
});

app.get('/note', (req, res) => {
    const note = notes.find(n => n.id === req.query.id);
    if (!note) return res.send('Note not found.');
    res.render('note', { note });
});

app.get('/share', (req, res) => {
    res.send('Admin will visit your note soon');
    visit(req.query.id);
});

app.get('/search', requireLogin, (req, res) => {
    const query = req.query.search;
    if (typeof query != 'string') {
        res.send("Invalid data!")
        return;
    }
    const results = notes
        .filter(n => n.userId === req.session.userId)
        .filter(n => n.content.includes(query));
    res.render('search', { notes: results, search: query });
});

app.listen(3000, () => console.log('App running on http://localhost:3000'));
