import re, hashlib, hmac, cv2, numpy as np
from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
import pytesseract
from os import environ

TICKET_TEMPLATE = "assets/ticket.jpg"
ALLOWED_PATTERN = re.compile(r'^[A-Z0-9/]+$', re.A | re.I)

def add_text(img, text, pos):
    if not ALLOWED_PATTERN.match(text):
        raise ValueError("Illegal characters used")

    img_pil = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
    draw = ImageDraw.Draw(img_pil)
    font = ImageFont.truetype('assets/comic.ttf', 25)

    while text:
        bbox = font.getbbox(text)
        text_width = bbox[2] - bbox[0]
        if text_width <= 160:
            break
        text = text[:-1]

    draw.text(pos, text, font=font, fill=(0, 0, 0))
    img[:] = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)

def generate_signature(data):
    return hmac.new(environ["SIGNATURE_SECRET_KEY"].encode(), data, hashlib.sha256).digest()

def generate_image_with_signature(img):
    img = Image.fromarray(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))

    img_io = BytesIO()
    img.save(img_io, format="JPEG")
    signature = generate_signature(img_io.getvalue())

    return img_io.getvalue() + signature

def generate_ticket(ticket_number, seat, type):
    img = cv2.imread(TICKET_TEMPLATE)

    add_text(img, str(ticket_number), (825, 297))
    add_text(img, seat, (825, 327))
    add_text(img, type, (825, 357))

    return generate_image_with_signature(img)

def read_lines(img, n):
    it = iter(line.strip() for line in pytesseract.image_to_string(img[297:392, 823:993]).split("\n") if line)
    return [next(it, None) for _ in range(n)]

def parse_ticket_info(img):
    return read_lines(img, 3)

def load_ticket(data):
    if len(data) < 1024 or len(data) > 512_000:
        raise ValueError("This is not a ticket!")

    img_io = BytesIO(data[:-32])
    signature = data[-32:]
    
    if signature != generate_signature(img_io.getvalue()):
        raise ValueError("Invalid signature")
    
    img = Image.open(img_io)
    if img.format != "JPEG" or img.mode != "RGB" or img.size != (1000, 400):
        raise ValueError("Malformed ticket")
    
    gray_img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2GRAY)

    return parse_ticket_info(gray_img)
