#!/usr/bin/env bash

docker build -t blockchain ./