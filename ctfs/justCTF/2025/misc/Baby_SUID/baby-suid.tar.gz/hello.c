#include <stdio.h>

int main(void) {
    printf("Welcome to JustCTF 2025, I’m rooting for you to succeed!\n");
    return 0;
}