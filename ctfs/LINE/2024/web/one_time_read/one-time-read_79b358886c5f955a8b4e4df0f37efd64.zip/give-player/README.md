# How to run

Run command `source ./run.sh`

Then you can access public report page at: `http://127.0.0.1`

Internal addresses (one_time_read_network):
- Internal note: http://msg.line.ctf
- Report page: http://bot.line.ctf