# linectf2024-jalyboy

## How to run it

```shell
docker compose up -d
```

Access http://localhost:10000/