import figlet from "figlet";
import cookie from "cookie";
import { login, addAccount, getSession, clearSession, getLogs } from "./auth";

const server = Bun.serve({
    port: 3002,
    routes: {
        "/login": {
            POST: async (req: Request) => {
                const form = await req.formData();
                const username = form.get("username").toString();
                const password = form.get("password").toString();
                return new Response(login(username, password));
            }
        },
        "/logout": {
            POST: (req: Request) => {
                const cookies = cookie.parse(req.headers.get("Cookie") || "");
                clearSession(cookies["session"] || "");
                return Response.json({ success: true });
            }
        },
        "/info": {
            GET: (req: Request) => {
                const cookies = cookie.parse(req.headers.get("Cookie") || "");
                const account = getSession(cookies["session"] || "");
                return Response.json({ ...account });
            }
        },
        "/logs": {
            GET: () => {
                return Response.json({ logs: getLogs() });
            }
        }
    },
    fetch() {
        const body = figlet.textSync("Bun!");
        return new Response(body);
    },
    error(error) {
        console.error(error);
        return new Response(`Internal Error: ${error.message}`, {
            status: 400,
            headers: {
                "Content-Type": "text/plain",
            },
        });
    },
});

console.log(`Listening on http://localhost:${server.port} ...`);

let adminToken = '';
const renewAdmin = () => {
    if (adminToken) {
        clearSession(adminToken);
    }
    adminToken = login(process.env.ADMIN_USER, process.env.ADMIN_PASS);
    setTimeout(renewAdmin, parseInt(process.env.ADMIN_RENEW) * 1000);
    console.log("Admin renewed")
}

const start = async () => {
    await addAccount(process.env.ADMIN_USER, process.env.ADMIN_PASS, process.env.FLAG || "flag");
    await addAccount(process.env.SPY_USER, process.env.SPY_PASS, "am_a_spy");

    for (let i = 0; i < 10; i++) {
        clearSession(login(process.env.ADMIN_USER, process.env.ADMIN_PASS));
    }

    login(process.env.SPY_USER, process.env.SPY_PASS)
    renewAdmin();
    console.log(`Admin renews session every ${process.env.ADMIN_RENEW} secs...`);
}

start();
