docker compose --file docker-compose-dev.yml down
docker compose --file docker-compose-dev.yml up -d --build
