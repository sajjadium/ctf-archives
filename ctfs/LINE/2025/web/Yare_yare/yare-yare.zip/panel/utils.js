export const serializePayload = (payload) => {
  const serialized =  Object.keys(payload)
        .map(key => `${key}=${payload[key]}`)
        .join(';')

  return btoa(serialized);
}
