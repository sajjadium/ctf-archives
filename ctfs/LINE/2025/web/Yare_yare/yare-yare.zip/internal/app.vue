<template>
  <NavBar/>
  <div id="app" class="container">
    <!-- Header -->
    <header class="header">
      <h1>YaRE - Yet another Regex Editor</h1>
    </header>
    <!-- Main Content -->
    <main class="container">
      <div class="row mw-100">
        <section class="col-12">
          <label>Your regex:</label>
          <pre id="regex">{{ regex }}</pre>
        </section>

        <section class="col-12">
          <label>Text to Match:</label>
          <div class="text-patches">
            <component
              v-for="(patch, index) in patches"
              :is="patch.regex ? 'MatchPatch' : 'TextPatch'"
              :key="index"
              :text="patch.text"
              :selected="matchedIndex === patch.index"
              @click="selectMatch(patch.index)"
              />
          </div>
        </section>

        <section class="row col-12 clipped">
          <section class="col-6 mh-100 overflow-scroll">
            <label>Match results</label>
            <div v-for="(match, index) in matches" :key="index" class="regex-matches">
              <div
                @click="selectMatch(index)"
                class="p-2 my-2 d-flex justify-content-between border border-info-subtle rounded"
                :id="'matched-' + index"
                :class="{ 'bg-info-subtle': (matchedIndex === index) }"
                >
                <pre class="text-primary">{{ match[0] }}</pre>
                <pre class="text-sencondary">{{ match.start }}-{{ match.end }}</pre>
              </div>
            </div>
          </section>

          <section class="col-6 mh-100 overflow-scroll">
            <label>Regex inspect</label>
            <div v-if="matches.length" v-for="(group, index) in groups" :key="index" class="regex-inspect">
              <span>{{ index ? `Group #${index}` : "Pattern" }}: <code>{{ group }}</code></span>
              <pre v-if="matches[matchedIndex][index]" class="text text-success">{{ matches[matchedIndex][index] }}</pre>
              <pre v-if="!matches[matchedIndex][index]" class="text text-danger">No match</pre>
            </div>
          </section>
        </section>
        <!-- TODO: Interactive stuffs -->
        <!-- <section class="col-12"> -->
        <!--   <label>Manual Input</label> -->
        <!--   <form action="/" method="GET"> -->
        <!--     <div class="my-1"> -->
        <!--       <label for="regex-input" class="form-label">Regex</label> -->
        <!--       <textarea id="regex-input" class="form-control" name="regex" aria-label="Regex">{{ regex }}</textarea> -->
        <!--     </div> -->
        <!--     <div class="my-1"> -->
        <!--       <label for="text-input" class="form-label">Text</label> -->
        <!--       <textarea id="text-input" class="form-control" name="text" aria-label="Text" rows="15">{{ text }}</textarea> -->
        <!--     </div> -->
        <!--     <button class="btn btn-primary" type="submit">Submit</button> -->
        <!--   </form> -->
        <!-- </section> -->
      </div>
    </main>
  </div>
</template>

<script setup lang="ts">
    let { data: query } = await useAsyncData('query', () => useQueryParams());
    query = new URLSearchParams(query.value);
    const text = (query.get('text') || '').replaceAll('\r', '');
    let regex = (query.get('regex') || '');
    if (regex.match('[\*\+\{\}]')) {
        // TODO: Use DFA or get ReDoS :kekl:
        regex = '';
    }
    const matches = regex !== '' ? [...text.matchAll(regex)].map(match => ({
        ...match,
        start: match.index,
        end: match.index + match[0].length - 1
    })) : [];

    let stack = [];
    const groups = [regex];
    for (let i = 0; i < regex.length; i++) {
        if (regex[i] === '(') {
            stack.push(groups.length);
            groups.push(i);
        }
        else if (regex[i] == ')') {
            let index = stack.pop()
            groups[index] = regex.slice(groups[index], i + 1);
        }
    }

    let cur = 0;
    const patches = [];
    matches.forEach((match, index) => {
        if (cur < match.start) {
            patches.push({
                text: text.slice(cur, match.start),
                regex: false,
            });
        }
        patches.push({
            text: match[0],
            regex: true,
            index
        })
        cur = match.end + 1;
    })
    if (cur < text.length) {
        patches.push({
            text: text.slice(cur),
            regex: false
        })
    }
</script>

<script lang="ts">
    import TextPatch from '@/components/TextPatch';
    import MatchPatch from '@/components/MatchPatch';
    export default {
        components: {
            TextPatch,
            MatchPatch,
        },
        data() {
            return {
                matchedIndex: 0,
            }
        },
        methods: {
            selectMatch(index) {
                if (index !== undefined) {
                    this.matchedIndex = index;
                    document.getElementById(`matched-${index}`).scrollIntoView({ behavior: 'smooth', block: 'end' });
                }
            }
        }
    };
</script>

<style scoped>
.container {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
    font-family: Arial, sans-serif;
}

section > label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
}

section {
    padding-bottom: 10px;
}

pre {
    margin: 0 !important;
}

.clipped {
    max-height: 50vh;
}

.overflow-scroll {
    scrollbar-width: none;
}

</style>
