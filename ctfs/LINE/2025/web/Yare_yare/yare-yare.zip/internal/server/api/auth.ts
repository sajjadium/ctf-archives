export default defineEventHandler(async (event) => {
    const config = useRuntimeConfig(event);
    const session = getCookie(event, 'session');
    try {
        return await $fetch(`${config.authHost}/info`, {
            headers: {
                Cookie: `session=${session}`
            }
        })
    }
    catch(e) {
        return null;
    }
})
