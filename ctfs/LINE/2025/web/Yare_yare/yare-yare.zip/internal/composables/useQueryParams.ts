export default () => {
    const event = useRequestEvent();
    const url = event?.node.req.url || '';
    let index = url.indexOf('?');
    return url.slice(index);
}
