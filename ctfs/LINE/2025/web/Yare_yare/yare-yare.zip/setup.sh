#!/bin/bash

CHALLENGE_PORT="9002"
FLAG="LINECTF{test}"
BRIDGE_HOST="http:\/\/bridge:3001"
AUTH_HOST="http:\/\/auth:3002"
INTERNAL_HOST="http:\/\/internal:3003"
SPY_USER=super_duper_secret_user69420
SPY_PASS=$(xxd -u -l 32 -c 32 -p /dev/urandom)
ADMIN_USER=$(xxd -u -l 32 -c 32 -p /dev/urandom)
ADMIN_PASS=$(xxd -u -l 32 -c 32 -p /dev/urandom)
ADMIN_RENEW=300 #5 mins

cat .env.example \
| sed "s/<CHALLENGE_PORT>/$CHALLENGE_PORT/" \
| sed "s/<FLAG>/$FLAG/" \
| sed "s/<BRIDGE_HOST>/$BRIDGE_HOST/" \
| sed "s/<AUTH_HOST>/$AUTH_HOST/" \
| sed "s/<INTERNAL_HOST>/$INTERNAL_HOST/" \
| sed "s/<SPY_USER>/$SPY_USER/" \
| sed "s/<SPY_PASS>/$SPY_PASS/" \
| sed "s/<ADMIN_USER>/$ADMIN_USER/" \
| sed "s/<ADMIN_PASS>/$ADMIN_PASS/" \
| sed "s/<ADMIN_RENEW>/$ADMIN_RENEW/" \
> .env

docker compose -p yare-yare down && docker compose -p yare-yare up --build -d
