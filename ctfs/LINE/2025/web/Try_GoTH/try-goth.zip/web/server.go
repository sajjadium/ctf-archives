package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gin-contrib/sessions"
	"github.com/gin-contrib/sessions/cookie"

	"try-goth/config"
	"try-goth/controller"
	"try-goth/middleware"
	"try-goth/model"
	"try-goth/view"
)

func main() {
	r := gin.Default()
	r.Static("/static", "./static")
	r.Use(gin.Logger())

	// Env
	config.Init()

	// cookies
	// TODO: secret into config
	store := cookie.NewStore([]byte(config.GetString("secret")))
	store.Options(
		sessions.Options{
			SameSite: http.SameSiteLaxMode,
			MaxAge: 3600, // 1 hour
			HttpOnly: true,
			Path: "/",
	})
	r.Use(sessions.Sessions("session", store))

	// Database
	model.ConnectDatabase()

	// NO JSON!!!
	r.Use(middleware.TextHTML())
	view.Initialize("templates/*")

	// Routes
	controller.HomeController(r.Group("/"))
	controller.AuthController(r.Group("/auth"))
	controller.GameController(r.Group("/game"))
	controller.ProfileController(r.Group("/profile"))


	r.Run()
}
