package service

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"

	"github.com/gin-gonic/gin"

	"try-goth/config"
	"try-goth/model"
)

type ReportData struct {
	Id uint `json:"id"`
	Url string `json:"url"`
}

func Report(c *gin.Context) (string, error) {
	user, _ := c.Get("user")
	data := ReportData{Id: user.(model.User).ID, Url: c.PostForm("url")}
	blob, err := json.Marshal(data)
	if err != nil {
		return "", err
	}

	var resp *http.Response
	resp, err = http.Post(config.GetString("bot_url") + "/bot/report", "application/json", bytes.NewBuffer(blob))
	if err != nil {
		return "", err
	}

	body, _ := io.ReadAll(resp.Body)
	return string(body), nil
}
