package view

import (
	"html/template"
	"bytes"
	"net/http"
	"log"

	"github.com/gin-gonic/gin"
)

type View struct {
	tempHTML []byte
	Tmpl *template.Template
}

type AlertData struct {
	Type string
	Title string
	Content string
}

var view View

func (v *View) UpdateTempHTML(buf []byte) {
	v.tempHTML = append(buf, view.tempHTML...)
}

func (v *View) FlushTempHTML() []byte {
	if v.tempHTML == nil {
		return []byte{}
	}

	res := v.tempHTML[:]
	v.tempHTML = nil
	return res
}

func (v *View) Debug() []byte {
	return v.tempHTML
}

func Initialize(glob string) {
	view.Tmpl, _ = template.ParseGlob(glob)
}

func Alert(_type string, content string) {
	Add("alert-oob", AlertData{Type: _type, Content: content})
}

func Add(name string, data any) {
	buf := new(bytes.Buffer)

	err := view.Tmpl.ExecuteTemplate(buf, name, data)

	if err != nil {
		log.Printf("[Add] err = %v", err)
	}

	log.Printf("[Add] buf = %v", string(buf.Bytes()[:]))

	view.UpdateTempHTML(buf.Bytes())
}

func Text(c *gin.Context, text string) {
	// Quickly return sth
	c.Data(http.StatusOK, "text/html; charset=utf-8", []byte(text))
}

func Execute(c *gin.Context, name string, data any) {
	// Final template with some oob DOMs
	buf := new(bytes.Buffer)

	err := view.Tmpl.ExecuteTemplate(buf, name, data)

	if err != nil {
		log.Printf("[Execute] err = %v", err)
	}

	view.UpdateTempHTML(buf.Bytes())

	c.Data(http.StatusOK, "text/html; charset=utf-8", view.FlushTempHTML())
}

func Redirect(c *gin.Context, path string) {
	c.Header("HX-Redirect", path)
	c.Data(http.StatusOK, "text/html; charset=utf-8", view.FlushTempHTML())
}
