package config

import (
	"github.com/spf13/viper"
)

var config *viper.Viper

func Init () {
	config = viper.New()
	config.SetEnvPrefix("web")
	config.AutomaticEnv()
}

func Config() *viper.Viper {
	return config
}

func GetString(name string) string {
	value := config.Get(name)
	if value == nil {
		return ""
	}
	return value.(string)
}
