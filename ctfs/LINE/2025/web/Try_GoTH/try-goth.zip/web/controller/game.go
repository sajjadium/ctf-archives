package controller

import (
	"strconv"

	"github.com/gin-gonic/gin"

	"try-goth/middleware"
	"try-goth/service"
	"try-goth/view"
)

func GameController(g *gin.RouterGroup) {
	g.Use(middleware.Authenticated())

	g.GET("/", index)
	g.POST("/start", start)
	g.POST("/click", click)
	g.POST("/flag", flag)
	g.PUT("/difficulty", difficulty)
	g.POST("/reveal-mode", mode("reveal"))
	g.POST("/flag-mode", mode("flag"))
}

// Renders the game dashboard
func index(c *gin.Context) {
	user, _ := c.Get("user")
	view.Execute(c, "game", service.CommonUser(user))
}

// Reads game config, starts game
func start(c *gin.Context) {
	row, _ := strconv.Atoi(c.PostForm("row"))
	col, _ := strconv.Atoi(c.PostForm("col"))
	difficulty, _ := strconv.Atoi(c.PostForm("difficulty"))
	service.Start(row, col, difficulty)
	game := service.GetGame()

	view.Execute(c, "board", game)
}

func click(c * gin.Context) {
	i, _ := strconv.Atoi(c.PostForm("i"))
	j, _ := strconv.Atoi(c.PostForm("j"))
	mode := c.PostForm("mode")

	cell, template, err := service.Click(i, j, mode)
	if err != nil {
		view.Alert("danger", err.Error())
	}

	view.Execute(c, template, cell)
}

func flag(c * gin.Context) {
	i, _ := strconv.Atoi(c.PostForm("i"))
	j, _ := strconv.Atoi(c.PostForm("j"))

	cell, template, err := service.Click(i, j, "flag")
	if err != nil {
		view.Alert("danger", err.Error())
	}

	view.Execute(c, template, cell)
}

func difficulty(c *gin.Context) {
	difficulty, _ := strconv.Atoi(c.PostForm("difficulty"))
	msg := ""
	if difficulty <= 10 {
		msg = "No sweat!"
	} else if difficulty <= 20 {
		msg = "Mid~~~"
	} else if difficulty <= 25 {
		msg = "Hmm"
	} else if difficulty <= 30 {
		msg = "You sure?"
	} else if difficulty <= 35 {
		msg = "U r based"
	} else if difficulty <= 40 {
		msg = "WHO HURT YOU????"
	} else if difficulty == 100 {
		msg = "Ahh, see what you're up to, smartie"
	} else {
		msg = "Get some help..."
	}

	view.Text(c, msg)
}

func mode(m string) gin.HandlerFunc {
	return func(c *gin.Context) {
		if m != "reveal" && m != "flag" {
			view.Alert("danger", "Invalid mode")
			view.Execute(c, "game-buttons-reveal", nil)
			return
		}

		view.Execute(c, "game-buttons-" + m, nil)
	}
}
