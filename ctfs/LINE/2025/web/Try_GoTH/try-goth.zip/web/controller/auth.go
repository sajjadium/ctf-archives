package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/gin-contrib/sessions"

	"try-goth/view"
	"try-goth/service"
	"try-goth/middleware"
)

type FormMessage struct {
	Message, Type string
}

func AuthController(g *gin.RouterGroup) {
	g.POST("/logout", doLogout)

	g.Use(middleware.NotAuthenticated())

	g.GET("/login", login)
	g.POST("/login", doLogin)
	g.GET("/register", register)
	g.POST("/register", doRegister)
}

func login(c *gin.Context) {
	view.Execute(c, "login", nil)
}

func doLogin(c *gin.Context) {
	username := c.PostForm("username")
	password := c.PostForm("password")

	user, err := service.Login(username, password)

	if err != nil {
		view.Execute(c, "login-form", FormMessage{Message: err.Error(), Type: "danger"})
		return
	}

	session := sessions.Default(c)
	session.Set("user", user.UserId)
	session.Save()

	view.Redirect(c, "/")
}

func register(c *gin.Context) {
	view.Execute(c, "register", nil)
}

func doRegister(c *gin.Context) {
	username := c.PostForm("username")
	password := c.PostForm("password")
	token := c.PostForm("token")

	_, err := service.Register(username, password, token)

	if err != nil {
		view.Execute(c, "register-form", FormMessage{Message: err.Error(), Type: "danger"})
		return
	}

	view.Redirect(c, "/auth/login")
}

func doLogout(c *gin.Context) {
	session := sessions.Default(c)
	session.Clear()
	session.Save()
	view.Redirect(c, "/")
}
