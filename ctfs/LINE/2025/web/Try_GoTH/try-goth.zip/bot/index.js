const express = require('express');
const router = require('./visit');

const app = express();
app.use(express.json());

app.use((req, res, next) => {
  if (req.method === 'POST') {
    const { url } = req.body;
    try {
      const u = new URL(url);
      if (!['https:', 'http:'].includes(u.protocol)) {
        return res.status(200).send("Nope");
      }
      if (u.host !== new URL(process.env.BOT_URL).host) {
        return res.status(200).send("This site only plzzz");
      }
      if (!u.searchParams.get('username').includes('bot-')) {
        return res.status(200).send("No");
      }
    } catch (err) {
      return res.status(200).send("Sth wrong");
    }
  }
  next();
});

app.use(router);

app.listen(9001, () => {
  console.log(`Server is running on http://localhost:9001`);
});
