#!/bin/bash

FLAG="LINECTF{cafecafecafecafecafecafecafecafe}" # edit flag here
ADMIN_USERNAME="admin_`openssl rand -hex 16`"
ADMIN_PASSWORD="`openssl rand -hex 16`"

rm .env
echo "FLAG=$FLAG" >> .env # set flag here
echo "ADMIN_USERNAME=$ADMIN_USERNAME" >> .env
echo "ADMIN_PASSWORD=$ADMIN_PASSWORD" >> .env

sudo docker compose down
sudo docker compose up --build -d