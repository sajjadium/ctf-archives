const { createHash, randomBytes } = require('crypto');

const sha = (msg) => createHash('sha256').update(msg).digest('hex');
const rand = (len = 32) => randomBytes(Math.ceil(len / 2)).toString('hex').slice(0, len);

module.exports = {
  sha,
  rand,
}
