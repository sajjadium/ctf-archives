# How to run

# Deploy

1. Run `source ./run.sh` to start/restart containers.