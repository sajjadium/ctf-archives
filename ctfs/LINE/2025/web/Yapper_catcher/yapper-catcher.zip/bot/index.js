const express = require('express');
const bodyParser = require('body-parser');
const puppeteer = require('puppeteer');
const { randomBytes } = require('crypto');
const getQuote = require('./quotes.js');
const checkSecret = require('./secret.js');
const verify = require('./captcha.js');

const app = express();
app.use(bodyParser.urlencoded({ extended: false }))

const visit = async (username) => {
  try {
    console.log("Spreading quote...")
    const browser = await puppeteer.launch({
      headless: "true",
      executablePath: `/usr/bin/google-chrome`,
      args: [
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-setuid-sandbox",
        "--no-sandbox",
        '--ignore-certificate-errors'
      ],
      product: "chrome"
    });

    let page = (await browser.pages())[0];
    const quote = getQuote();

    await page.goto(process.env.SERVER_URL + '/?user=' + username)
    await page.type('input#username', username);
    await page.type('textarea#quote', quote);
    await page.click('button#post-status');
    await page.waitForNavigation();

    console.log(`Quote is at ${page.url()}`)

    await browser.close();

    console.log(`Closed browser`)
  } catch (e) {
    console.error(e);
    try {
      await browser.close();
      console.log(`Closed browser`)
    } catch (e) { }
  }
}

app.use(express.json());

app.post('/bot/flag', async (req, res) => {
  if (checkSecret(req.body)) {
    // If u got here ur definitely deserve the flag lol
    return res.send(process.env.flag);
  }

  return res.send('Check ur math');
});

app.post('/bot/quote', async (req, res) => {
  const { username } = req.body;
  if (!await verify(req.body)) {
    return res.send(`Bot-powered yapper bot? Not on my watch`);
  }
  visit(username);
  return res.send(`Bot is yapping as ${username}`);
})

app.listen(9001, () => {
  console.log(`Server is running on http://localhost:9001`);
});
