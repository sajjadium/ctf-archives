// Ngl ChatGPT can yap hard
const superDuperInspirationalQuotes = [
  "Sometimes, the journey to <flag> is not about reaching the destination, but about discovering who you become along the way.",
  "The <flag> you seek is already within you, waiting to unfold in its perfect timing.",
  "Embrace the mess of <flag>, for within it lies the beauty of your growth.",
  "To find peace in <flag>, you must first find peace within yourself.",
  "The path to <flag> might seem long, but each step brings you closer to a version of yourself you never imagined.",
  "No matter the storm, <flag> will always find a way to shine through.",
  "Every setback in your <flag> journey is simply the universe redirecting you to something greater.",
  "True growth in <flag> comes not from doing, but from being.",
  "Let your <flag> be guided by your heart, and your path will always lead you home.",
  "In the broken pieces of <flag>, you will find the strength to rebuild what is better.",
]
var rr = 0;

const getQuote = () => {
  let quote = superDuperInspirationalQuotes[rr];
  quote = quote.replace('<flag>', process.env.FLAG);
  rr = (rr + 1) % superDuperInspirationalQuotes.length;

  return quote;
}

module.exports = getQuote;
