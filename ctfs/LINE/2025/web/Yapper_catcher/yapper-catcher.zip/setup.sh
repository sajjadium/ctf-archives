#!/bin/bash

CHALLENGE_PORT="9001"
FLAG="LINECTF{test}"
SERVER_PORT="9000"
SERVER_URL="http:\/\/host.docker.internal:$CHALLENGE_PORT"
SERVER_PASSKEY=$(xxd -u -l 32 -c 32 -p /dev/urandom)
SERVER_HMAC_KEY=$(xxd -u -l 32 -c 32 -p /dev/urandom)
SERVER_CAPTCHA_SITEKEY="6LfxY7IqAAAAAAs1fiDSYR2ec0L-YW49IurNQRa5"
DB_URL="mongo:27017"
DB_USER=$(xxd -u -l 16 -c 16 -p /dev/urandom)
DB_PASSWORD=$(xxd -u -l 32 -c 32 -p /dev/urandom)
BOT_CAPTCHA_SECRET="meh"

cat .env.example \
| sed "s/<CHALLENGE_PORT>/$CHALLENGE_PORT/" \
| sed "s/<FLAG>/$FLAG/" \
| sed "s/<SERVER_PORT>/$SERVER_PORT/" \
| sed "s/<SERVER_URL>/$SERVER_URL/" \
| sed "s/<SERVER_PASSKEY>/$SERVER_PASSKEY/" \
| sed "s/<SERVER_CAPTCHA_SITEKEY>/$SERVER_CAPTCHA_SITEKEY/" \
| sed "s/<SERVER_HMAC_KEY>/$SERVER_HMAC_KEY/" \
| sed "s/<DB_URL>/$DB_URL/" \
| sed "s/<DB_USER>/$DB_USER/" \
| sed "s/<DB_PASSWORD>/$DB_PASSWORD/" \
| sed "s/<BOT_CAPTCHA_SECRET>/$BOT_CAPTCHA_SECRET/" \
> .env

docker compose -p yapper-catcher down && docker compose -p yapper-catcher up --build -d
