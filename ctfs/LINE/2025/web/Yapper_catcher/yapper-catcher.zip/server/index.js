const express = require('express');
const bodyParser = require('body-parser');
const { handleSuccess, handleError } = require('./middlewares.js');
const { testDB } = require('./model/index.js');
const router = require('./router/index.js');

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use(express.static('static'))
app.use(handleSuccess)
app.set('views', './views')
app.set('view engine', 'ejs')

app.use(router);

app.use(handleError);

const port = process.env.SERVER_PORT || 3000;
app.listen(port, async () => {
  await testDB();
  console.log(`App is running on :${port}`)
})
