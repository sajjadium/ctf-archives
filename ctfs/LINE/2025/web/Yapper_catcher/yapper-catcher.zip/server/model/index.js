const { testDB } = require('./db.js');
const Status = require('./status.js');

module.exports = {
  testDB,
  Status
}
