exports.getYapper = async (req, res, next) => {
  res.render('yapper', { siteKey: process.env.SERVER_CAPTCHA_SITEKEY });
}
