const { encrypt, decrypt } = require('../utils.js');

exports.testEncryption = async (req, res, next) => {
  const plaintext = req.param('plaintext');
  const key = req.param('key');
  const encrypted = await encrypt(plaintext, key);
  console.log(encrypted);
  const decrypted = await decrypt(encrypted, key);
  console.log(decrypted);

  return res.success({ encrypted, decrypted });
}
