<?php
function isValidHost($host) {
    return is_string($host) === true 
    && mb_check_encoding($host, 'ASCII') === true 
    && strlen($host) > 0 
    && strlen($host) <= 10 
    && preg_match('/^[a-z]+$/', $host) === 1;
}

function isValidPath($path) {
    return is_string($path) === true 
    && mb_check_encoding($path, 'ASCII') === true 
    && strlen($path) <= 10 
    && (strlen($path) === 0 || preg_match('/^[a-z]+$/', $path) === 1);
}

function isValidParams($params) {
    return is_string($params) === true 
    && mb_check_encoding($params, 'ASCII') === true 
    && strlen($params) <= 35 
    && (strlen($params) === 0 || preg_match('/^[0-9a-z?&=\'()[\]{}:+\/]+$/', $params) === 1);
}

function isValidToken($token_header, $token) {
    if (is_string($token_header) === true 
    && is_string($token) === true 
    && mb_check_encoding($token_header, 'ASCII') === true 
    && mb_check_encoding($token, 'ASCII') === true) {
        if (strlen($token_header) === 0 && strlen($token) === 0) return true;
        if (strlen($token_header) > 0 && strlen($token) > 0) {
            if (strlen($token_header) > 15) return false;
            if (strlen($token) < 12 || strlen($token) > 20) return false;
            if (preg_match('/^[a-zA-Z0-9-:]+$/', $token_header) === 1 && preg_match('/^[a-zA-Z0-9-:]+$/', $token) === 1) {
                // check the separator between username and password
                if ($token[strlen($token) - 11] !== ':') return false;

                // check the format of password
                for ($i = 1; $i <= 10; $i++) {
                    $c = $token[strlen($token) - $i];
                    if ($c === '0' || $c === '1' || $c === '2' || $c === '3' || $c === '4' || $c === '5' || $c === '6' || $c === '7' || $c === '8' || $c === '9')
                        continue;
                    return false;
                }
                return true;
            }
            return false;
        }
        return false;
    }
    return false;
}

function get_ip() {
    $res = $_SERVER['REMOTE_ADDR'];
    if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)) {
        $res .= ' - '.$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    return $res;
}

if (isset($_POST['submit'])) {
    if (!isset($_POST['host'])) die('Hostname is required');

    $host = $_POST['host'];
    $path = isset($_POST['path']) ? $_POST['path'] : '';
    $params = isset($_POST['params']) ? $_POST['params'] : '';
    $token_header = isset($_POST['token_header']) ? $_POST['token_header'] : '';
    $token = isset($_POST['token']) ? $_POST['token'] : '';

    if (isValidHost($host) && isValidPath($path) && isValidParams($params) && isValidToken($token_header, $token)) {
        error_log("[".get_ip()."] - [".date("Y/m/d H:m:s")."]: host=".urlencode($host)." - path=".urlencode($path)." - params=".urlencode($params)." - token_header=".urlencode($token_header)." - token=".urlencode($token)."\r\n", 3, "/var/tmp/access.log");
        
        $url = 'http://'.$host.'/'.$path.$params;
        $url = str_replace('../', '', $url);

        $headers = array();
        if (strlen($token_header) > 0 && strlen($token) > 0) array_push($headers, $token_header.$token);
        array_push($headers, 'X-From-Restricted-Proxy: true');

        $opts = [
            'http' => [
                'method' => 'GET',
                'header' => $headers
            ]
        ];
        
        die(file_get_contents($url, false, stream_context_create($opts)));
    } else {
        die('Invalid input');
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
        <title>Restricted Proxy</title>
    </head>
    <body class="d-flex flex-column">
        <div id="page-content">
            <div class="container pt-5">
                <center>
                    <h3>Restricted Proxy</h3>
                    <p>You are allowed to send a HTTP GET request to our internal services through this restricted proxy. Please fill in the information of the service that you would like to access in below form and then click "Access"</p>
                    <form action="/" method="POST">
                        <label for="host" class="form-label">Hostname</label><br>
                        <input type="text" id="host" name="host" class="form-control" placeholder="nginx" style="margin-bottom: 10px"><br>

                        <label for="path" class="form-label">Path</label><br>
                        <input type="text" id="path" name="path" class="form-control" placeholder="homepage" style="margin-bottom: 10px"><br>

                        <label for="params" class="form-label">GET parameters</label><br>
                        <input type="text" id="params" name="params" class="form-control" placeholder="?message=hello" style="margin-bottom: 10px"><br>

                        <label for="token_header" class="form-label">Access credential header name</label><br>
                        <input type="text" id="token_header" name="token_header" class="form-control" placeholder="X-Token:" style="margin-bottom: 10px"><br>

                        <label for="token" class="form-label">Access credential (format: <b>username:password</b>)</label><br>
                        <input type="text" id="token" name="token" class="form-control" placeholder="test:0123456789" style="margin-bottom: 10px"><br>

                        <button type="submit" class="btn btn-primary" name="submit">Access</button>
                    </form>
                </center>
            </div>
        </div>
    </body>
</html>