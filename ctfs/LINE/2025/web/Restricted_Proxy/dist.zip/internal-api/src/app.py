from flask import (
    Flask,
    request,
    Response
)
import os
import subprocess
import json

app = Flask(__name__)

def is_valid_token(token):
    if type(token) != str:
        return False
    if len(token) >= 12 and len(token) <= 20:
        if token[-10:] != os.environ.get('TOKEN'):
            return False
        return True
    return False

@app.route('/homepage', methods=['GET'])
def homepage():
    if 'X-Token' not in request.headers:
        return 'Forbidden'
    
    token = request.headers['X-Token']
    if is_valid_token(token) == False:
        return 'Wrong access token'
    
    username = token[:-11]
    
    return f'Hello <b>{username}</b>, I\'m Internal API.<br><br>Although you can see me from Restricted Proxy, I have some endpoints that you can\'t access. That\'s why the proxy is called <b>Restricted</b>!'
    
@app.route('/get_flag', methods=['GET'])
def get_flag():
    if 'X-From-Restricted-Proxy' in request.headers:
        return 'Forbidden'
    
    cmd = request.args['cmd']
    fmt = request.args['fmt'] # sample format to color character 'f' as red: {'f':'Qg=='}

    if cmd is None or fmt is None:
        return 'Missing parameters'

    try:
        output = subprocess.check_output(["python3", "formatter.py", "--command_from_user", cmd, "--format_of_command", fmt])
        result = json.loads(output.decode())
        if result['error_return_code'] == 0:
            message = 'Invalid command'
            if cmd == '(f)': # flag
                message = open('/flag_here.txt').read()
            elif cmd == '(a)': # about
                message = 'This endpoint returns flag. But wait, how can you reach here?'

            return Response(result['formatted_command'] + ': ' + message, mimetype='text/html')
        else:
            return result['error_message']
    except Exception as e:
        return 'Error occured'

app.run(host='0.0.0.0', port=5000, debug=False)
