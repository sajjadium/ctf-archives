import argparse as builtin_argparse
import json as json_handler

def is_valid_command_from_user(command_from_user):
    if command_from_user is None or type(command_from_user) != str or len(command_from_user) > 3:
        return False
    return True

def is_valid_format_of_command(format_of_command):
    allowed_characters = ["'", '(', ')', '[', ']', '{', '}', ':', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/', '=']
    if format_of_command is None or type(format_of_command) != str or len(format_of_command) > 16 or len(format_of_command) <= 2:
        return False
    format_of_command = format_of_command.lower()
    for single_character in format_of_command:
        if single_character not in allowed_characters:
            return False
    if format_of_command[0] != '{' or format_of_command[-1] != '}':
        return False
    return True

def return_error_detail(error_return_code, error_message):
    print(json_handler.dumps({'error_return_code': error_return_code, 'error_message': error_message}))
    exit(0)

argument_parser = builtin_argparse.ArgumentParser()
argument_parser.add_argument("--command_from_user")
argument_parser.add_argument("--format_of_command")
received_arguments = argument_parser.parse_args()

command_from_user = received_arguments.command_from_user
format_of_command = received_arguments.format_of_command

if is_valid_command_from_user(command_from_user) == False or is_valid_format_of_command(format_of_command) == False:
    return_error_detail(-1, 'Invalid parameters')

formatted_command = ''

try:
    for single_character in command_from_user:
        w = '()abcdefghijklmnopqrstuvwxyz'
        formatted_object = eval(format_of_command)

        if single_character in w and single_character not in w:
            if single_character in formatted_object.keys():
                color_of_current_character_base64 = formatted_object[single_character]
                if type(color_of_current_character_base64) != str:
                    return_error_detail(-1, 'Color must be a base64 string')

                color_of_current_character = ''
                if color_of_current_character_base64 == 'Ug==':
                    color_of_current_character = 'red'
                elif color_of_current_character_base64 == 'Rw==':
                    color_of_current_character = 'green'
                elif color_of_current_character_base64 == 'Qg==':
                    color_of_current_character = 'blue'
                else:
                    return_error_detail(-1, 'Color is not allowed')
            
                formatted_command += f'<span style="color:{color_of_current_character}">{single_character}</span>'
            else:
                formatted_command += single_character
        else:
            return_error_detail(-1, 'Command is not safe')
except Exception as e:
    return_error_detail(-1, 'Formatter error occured')

print(json_handler.dumps({'error_return_code': 0, 'formatted_command': formatted_command}))