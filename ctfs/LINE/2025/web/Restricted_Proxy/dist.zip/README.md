# How to run

# Deploy

1. Change the flag in `./run.sh`.
2. Run `./run.sh` to deploy.
3. If Apache can't start at `restricted-proxy`, please consider to enable `NET_BIND_SERVICE` at `docker-compose.yml`.