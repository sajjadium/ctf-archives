#!/bin/bash

echo "[+] Creating flag file"
echo "LINECTF{cafecafecafecafecafecafecafecafe}" > ./internal-api/flag_here.txt # set flag here

echo "[+] Shutting down running containers"
sudo docker compose down

echo "[+] Starting containers"
sudo docker compose build
sudo docker compose up -d