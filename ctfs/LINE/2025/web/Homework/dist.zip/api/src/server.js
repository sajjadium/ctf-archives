const express = require('express');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/user');
const homeworkRoutes = require('./routes/homework');
const fs = require('fs');

const PORT = 8080;
const HOST = '0.0.0.0';

const app = express();
app.use(morgan('combined'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/user', userRoutes);
app.use('/homework', homeworkRoutes);

app.listen(PORT, HOST, async () => {
    console.log(`Running on http://${HOST}:${PORT}`);
});