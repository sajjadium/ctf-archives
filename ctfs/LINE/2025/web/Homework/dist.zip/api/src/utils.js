const { BASE_SCORE } = require("./consts");

let toDecoratedScore = (realScore) => BASE_SCORE + realScore; // append "1337" at the beginning to make the score looks bigger
let toRealScore = (decoratedScore) => decoratedScore.toString().substring(4); // truncate "1337" at the beginning to get real score

module.exports = {
    toDecoratedScore,
    toRealScore
}