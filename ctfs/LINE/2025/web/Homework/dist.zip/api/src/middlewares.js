const sequelize = require('./sequelize');

let checkAuthz = (allowedRoles) => async (req, res, next) => {
    try {
        let api_key = req.headers['x-api-key'];
        if (!api_key || typeof api_key !== "string") return res.status(500).send("Invalid API Key");
        let users = await sequelize.models.user.findAll({ where: { api_key: api_key } });
        if (!users.length) return res.status(500).send("Wrong API Key");
        if (!allowedRoles.includes(users[0].role)) return res.status(500).send("Insufficient permission");
        next();
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
};

module.exports = {
    checkAuthz
};