const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
    sequelize.define('user', {
        id: {
            allowNull: false,
            autoIncrement: true,
			primaryKey: true,
			type: DataTypes.INTEGER
        },
        username: {
            allowNull: false,
            unique: true,
            type: DataTypes.STRING
        },
        password: {
            allowNull: false,
            type: DataTypes.STRING
        },
        avatar_id: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        role: {
            allowNull: false,
            type: DataTypes.INTEGER
        },
        api_key: {
            allowNull: false,
            type: DataTypes.STRING
        }
    });
};