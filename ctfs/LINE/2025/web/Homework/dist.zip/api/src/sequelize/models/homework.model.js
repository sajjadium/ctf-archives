const { Sequelize } = require('sequelize');

module.exports = (sequelize) => {
    sequelize.define('homework', {
        id: {
			primaryKey: true,
			type: Sequelize.UUID,
            defaultValue: Sequelize.UUIDV4
        },
        uid: {
            allowNull: false,
            type: Sequelize.INTEGER
        },
        title: {
            allowNull: false,
            type: Sequelize.STRING
        },
        content: {
            allowNull: false,
            type: Sequelize.STRING
        },
        score: {
            allowNull: false,
            type: Sequelize.FLOAT
        }
    });
};