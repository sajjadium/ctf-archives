const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(process.env.PG_API_DB, process.env.PG_API_USER, process.env.PG_API_PASSWORD, {
	dialect: 'postgres',
	host: process.env.PG_API_HOST,
	define: {
		timestamps: false
	}
});

const modelDefiners = [
	require('./models/user.model'),
	require('./models/homework.model')
];

for (const modelDefiner of modelDefiners) {
	modelDefiner(sequelize);
}

module.exports = sequelize;