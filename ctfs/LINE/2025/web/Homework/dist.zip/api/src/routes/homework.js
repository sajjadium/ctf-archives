const { checkAuthz } = require('../middlewares');
const sequelize = require('../sequelize');
const { toDecoratedScore, toRealScore } = require("../utils");
const { ROLES, BASE_SCORE } = require("../consts");
const crypto = require('crypto');
const { rateLimit } = require('express-rate-limit');

let routes = require('express').Router();

const limiter = rateLimit({
	windowMs: 1 * 60 * 1000, // 1 minutes
	limit: 3, // Limit each IP to 3 requests per `window` (here, per 1 minutes).
	standardHeaders: 'draft-7', // draft-6: `RateLimit-*` headers; draft-7: combined `RateLimit` header
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers.
});

routes.post('/create', [limiter, checkAuthz([ROLES.Student])], async (req, res) => {
    try {
        let { title, content } = req.body;
        if (!title || !content || typeof title !== "string" || typeof content !== "string" || title.length > 50 || content.length > 41250)
            return res.status(500).send("Invalid data");
        let users = await sequelize.models.user.findAll({ where: { api_key: req.headers['x-api-key'] } });
        let result = await sequelize.models.homework.create({
            uid: users[0].id,
            title: title,
            content: content,
            score: toDecoratedScore(0)
        });
        return res.status(200).send(`Homework ${result.id} created successfully`);
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.get('/list', checkAuthz([ROLES.Student]), async (req, res) => {
    try {
        let users = await sequelize.models.user.findAll({ where: { api_key: req.headers['x-api-key'] } });
        let result = await sequelize.models.homework.findAll({ where: { uid: users[0].id } });
        return res.status(200).send(result);
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.get('/view', checkAuthz([ROLES.Student, ROLES.TeachingAssistant, ROLES.Teacher]), async (req, res) => {
    try {
        let { id } = req.query;
        if (!id || typeof id !== "string") return res.status(500).send("Invalid data");
        let homework = await sequelize.models.homework.findAll({ where: { id: id } });
        if (!homework.length) return res.status(500).send("Homework not found");
        let users = await sequelize.models.user.findAll({ where: { api_key: req.headers['x-api-key'] } });
        if (users[0].id === homework[0].uid || [ROLES.TeachingAssistant, ROLES.Teacher].includes(users[0].role))
            return res.status(200).send(homework[0]);
        return res.status(500).send("Insufficient permission");
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.get('/mark', checkAuthz([ROLES.TeachingAssistant, ROLES.Teacher]), async (req, res) => {
    try {
        let { id, score } = req.query;
        if (!id || !score || typeof id !== "string" || Number.isNaN(score)) return res.status(500).send("Invalid data");
        score = Number(score);
        if (score <= 0 || score > toDecoratedScore(100)) return res.status(500).send("Invalid data");
        await sequelize.models.homework.update({ score: score }, { where: { id: id } });
        return res.status(200).send("Score set successfully");
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.get('/better-list', checkAuthz([ROLES.Teacher]), async (req, res) => {
    try {
        let { id, column } = req.query;
        if (!id || !column || typeof id !== "string" || typeof column !== "string" || column.length > 45) 
            return res.status(500).send("Invalid data");
        let homework = await sequelize.models.homework.findAll({ where: { id: id } });
        if (!homework.length) return res.status(500).send("Homework not found");
        let realScore = toRealScore(homework[0].score);
        let maxLength = crypto.randomInt(7) + 1;
        let minLength = crypto.randomInt(maxLength + 1);
        const [results, _] = await sequelize.query(`SELECT * FROM homework WHERE length(${column})>=${minLength} and length(${column})<=${maxLength} and title!='${process.env.FLAG}' and ${toDecoratedScore(100)}-score>100-${realScore} ORDER BY length(${column})`);
        return res.status(200).send(results);
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

module.exports = routes;