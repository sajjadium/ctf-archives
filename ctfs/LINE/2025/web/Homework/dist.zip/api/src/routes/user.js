const sequelize = require('../sequelize');
const { Op } = require('sequelize');
const crypto = require('crypto');
const { ROLES } = require("../consts");
const { checkAuthz } = require('../middlewares');
const { rateLimit } = require('express-rate-limit');

let routes = require('express').Router();

const limiter = rateLimit({
	windowMs: 1 * 60 * 1000, // 1 minutes
	limit: 3, // Limit each IP to 3 requests per `window` (here, per 1 minutes).
	standardHeaders: 'draft-7', // draft-6: `RateLimit-*` headers; draft-7: combined `RateLimit` header
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers.
});

routes.post('/login', async (req, res) => {
    try {
        let { username, password } = req.body;
        if (!username || !password || typeof username !== "string" || typeof password !== "string")
            return res.status(500).send("Invalid data");
        let users = await sequelize.models.user.findAll({
            where: {
                username: username,
                password: crypto.createHash('md5').update(password).digest("hex")
            }
        });
        if (!users.length) return res.status(500).send("Wrong username or password");
        return res.status(200).send(users[0]);
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.post('/register', limiter, async (req, res) => {
    try {
        let { username, password } = req.body;
        let usernameRegex = /^[a-zA-Z0-9]+$/;
        if (!username || !password || typeof username !== "string" || typeof password !== "string" || username.length > 20 || password.length > 20 || !usernameRegex.test(username))
            return res.status(500).send("Invalid data");
        let users = await sequelize.models.user.findAll({
            where: {
                username: username
            }
        });
        if (users.length) return res.status(500).send("Username exists");
        await sequelize.models.user.create({
            username: username,
            password: crypto.createHash('md5').update(password).digest("hex"),
            avatar_id: crypto.randomInt(3),
            role: ROLES.Student,
            api_key: crypto.randomBytes(10).toString('hex')
        });
        return res.status(200).send("Register successfully");
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

routes.get('/avatar', checkAuthz([ROLES.TeachingAssistant, ROLES.Teacher]), async (req, res) => {
    try {
        let { c1, v1, c2, v2 } = req.query;
        if (!c1 || !v1 || !c2 || !v2)
            return res.status(500).send("Invalid data");
        if (typeof c1 !== "string" || typeof v1 !== "string" || typeof c2 !== "string" || typeof v2 !== "string")
            return res.status(500).send("Invalid data");
        let users = await sequelize.models.user.findAll({
            where: {
                [Op.and]: [
                    {
                        [c1]: {
                            [Op.like]: v1
                        }
                    },
                    {
                        [c2]: {
                            [Op.like]: v2
                        }
                    },
                    {
                        role: {
                            [Op.gt]: 0
                        }
                    }
                ]
            }
        });
        if (!users.length) return res.status(500).send("User not found");
        let avatar_id = users[0].avatar_id;
        if (Number.isInteger(avatar_id) && (0 <= avatar_id && avatar_id <= 2)) 
            return res.sendFile(`/avatars/${avatar_id}.png`, { root: __dirname + '/../' });
        return res.status(500).send("Invalid avatar");
    } catch (err) {
        console.log(err);
        return res.status(500).send("Unknown error");
    }
});

module.exports = routes;