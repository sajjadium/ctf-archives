const ROLES = {
    Student: 0,
    TeachingAssistant: 1,
    Teacher: 2
};

const BASE_SCORE = 1337 * 1000;

module.exports = {
    ROLES,
    BASE_SCORE
};