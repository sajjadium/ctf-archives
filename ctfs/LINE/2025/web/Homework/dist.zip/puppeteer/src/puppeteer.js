const puppeteer = require('puppeteer');
const Redis = require('ioredis');
const crypto = require('crypto');

let processedCount = 0;

async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function visit(id) {
  processedCount++;
  let url = `${process.env.WEB_URL}/view?id=${id}`;
  console.log(`[${processedCount}] bot visits ${url}`);
  try {
    let browser = await puppeteer.launch({
      headless: "true",
      args: [
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-setuid-sandbox",
        "--no-sandbox",
        "--ignore-certificate-errors",
        "--disable-background-networking",
        "--disk-cache-dir=/dev/null",
        "--disable-default-apps",
        "--disable-extensions",
        "--disable-desktop-notifications",
        "--disable-popup-blocking",
        "--disable-sync",
        "--disable-translate",
        "--metrics-recording-only",
        "--mute-audio",
        "--no-first-run",
        "--safebrowsing-disable-auto-update",
        "--no-zygote",
      ],
      ignoreDefaultArgs: ["--hide-scrollbars"],
      product: "chrome"
    });

    // login
    let page = await browser.newPage();
    await page.goto(`${process.env.WEB_URL}/login-register`);
    await page.type('[name="username"]', "teaching_assistant");
    await page.type('[name="password"]', process.env.TEACHING_ASSISTANT_PASSWORD);
    await page.click('[id="loginBtn"]');
    await sleep(1000);
    await page.close();
    
    // visit homework URL
    page = await browser.newPage();
    await page.setExtraHTTPHeaders({'X-API-Key': process.env.TEACHING_ASSISTANT_API_KEY});
    await page.goto(url);
    await sleep(3000);

    // set a random score for the homework
    let score = 1 + crypto.randomInt(100);
    await page.type('[name="score"]', score.toString());
    await page.click('[id="setScoreBtn"]');
    await sleep(1000);
    await page.close();

    // close the browser
    console.log(`[${processedCount}] done visiting`);
    await browser.close();
  } catch (e) {
    console.error(e);
    try { await browser.close() } catch (e) { 
      console.log("[+] close error");
      console.error(e);
    }
  }
};

async function run() {
  let redis = new Redis({
    port: 6379,
    host: "redis",
    username: "default",
    password: process.env.REDIS_PASSWORD,
    db: 0,
  });
  while (true) {
    try {
      let [err, res] = await redis.blpop("id", 0);
      if (res) await visit(res);
    } catch {
      console.log('[+] error while getting a homework ID');
    }
    await sleep(2000);
  }
}

run();