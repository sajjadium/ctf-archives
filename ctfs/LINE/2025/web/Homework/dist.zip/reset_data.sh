#!/bin/bash
read -p "This action will re-generate all credentials and remove postgres data, are you sure? " -n 1 -r
echo    # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "Creating .env file with new credentials"
    FLAG="LINECTF{cafecafecafecafecafecafecafecafe}" # edit flag here
    PG_API_PASSWORD="`openssl rand -hex 16`"
    PG_API_USER="api_user"
    TEACHER_PASSWORD="`openssl rand -hex 16`"
    TEACHER_API_KEY="`openssl rand -hex 5`"
    TEACHING_ASSISTANT_PASSWORD="`openssl rand -hex 16`"
    TEACHING_ASSISTANT_API_KEY="`openssl rand -hex 5`"

    rm .env
    echo "FLAG=$FLAG" >> .env # set flag here
    echo "POSTGRES_PASSWORD=`openssl rand -hex 16`" >> .env
    echo "REDIS_PASSWORD=`openssl rand -hex 16`" >> .env
    echo "TEACHER_PASSWORD=$TEACHER_PASSWORD" >> .env
    echo "TEACHER_API_KEY=$TEACHER_API_KEY" >> .env
    echo "TEACHING_ASSISTANT_PASSWORD=$TEACHING_ASSISTANT_PASSWORD" >> .env
    echo "TEACHING_ASSISTANT_API_KEY=$TEACHING_ASSISTANT_API_KEY" >> .env
    echo "PG_API_USER=$PG_API_USER" >> .env
    echo "PG_API_PASSWORD=$PG_API_PASSWORD" >> .env

    echo "Removing current postgres data"
    sudo rm -rf ./postgres/data

    echo "Creating a new postgres init query"
    rm ./postgres/init.sql
    cp ./postgres/init.sql.template ./postgres/init.sql
    sed -i -e "s/{PG_API_USER}/$PG_API_USER/g" ./postgres/init.sql
    sed -i -e "s/{PG_API_PASSWORD}/$PG_API_PASSWORD/g" ./postgres/init.sql
    sed -i -e "s/{TEACHER_PASSWORD}/$TEACHER_PASSWORD/g" ./postgres/init.sql
    sed -i -e "s/{TEACHER_API_KEY}/$TEACHER_API_KEY/g" ./postgres/init.sql
    sed -i -e "s/{TEACHING_ASSISTANT_PASSWORD}/$TEACHING_ASSISTANT_PASSWORD/g" ./postgres/init.sql
    sed -i -e "s/{TEACHING_ASSISTANT_API_KEY}/$TEACHING_ASSISTANT_API_KEY/g" ./postgres/init.sql
fi