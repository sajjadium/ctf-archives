const express = require('express');
const morgan = require('morgan');
const proxy = require('express-http-proxy');
const session = require('express-session');
const svgCaptcha = require('svg-captcha');
const crypto = require('crypto');
const Redis = require("ioredis");
const bodyParser = require('body-parser');
const fs = require('fs');

const PORT = 8080;
const HOST = '0.0.0.0';
const redis = new Redis({
  port: 6379,
  host: "redis",
  username: "default",
  password: process.env.REDIS_PASSWORD,
  db: 0,
});

function genCaptcha() {
  return svgCaptcha.create({
    size: 8,
    noise: 8,
    width: 300,
    height: 100
  });
}

const app = express();
app.use(session({
  secret: crypto.randomBytes(20).toString("hex"),
  cookie: {}
}));
app.set('view engine', 'ejs');
app.use(morgan('combined'));

app.use('/api', proxy('http://api:8080'));

app.use('/public', express.static('public'));

app.get('/', (req, res) => {
  return res.render('home');
});

app.get('/login-register', (req, res) => {
  return res.render('login-register');
});

app.get('/view', (req, res) => {
  return res.render('view');
});

app.get('/write', (req, res) => {
  return res.render('write');
});

app.get('/captcha', function (req, res) {
  let captcha = genCaptcha();
  req.session.captcha = captcha.text;
  res.type('svg');
  return res.status(200).send(captcha.data);
});

app.get('/report', (req, res) => {
  return res.render('report');
});

app.post('/report', bodyParser.urlencoded({ extended: true }), async (req, res) => {
  try {
    let { id, captcha } = req.body;
    if (!req.session.captcha || typeof captcha !== "string" || req.session.captcha !== captcha) {
      req.session.captcha = genCaptcha().text;
      return res.status(500).send("<script>alert('Wrong captcha'); location.href='/report';</script>");
    }
    let re = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/g;
    if (!id || typeof id !== "string" || !re.test(id)) return res.status(500).send("<script>alert('Invalid data'); location.href='/report';</script>");
    await redis.rpush('id', id);
    return res.status(200).send("<script>alert('Your homework will be reviewed soon'); location.href='/';</script>");
  } catch (err) {
    console.log(err);
    return res.status(500).send("<script>alert('Unknown error'); location.href='/report';</script>");
  }
});

app.listen(PORT, HOST, async () => {
  console.log(`Running on http://${HOST}:${PORT}`);
});