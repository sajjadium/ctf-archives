function isAuthenticated() {
    return localStorage.getItem('apiKey');
}

function saveUserInfo(apiKey, username, role) {
    localStorage.setItem('apiKey', apiKey);
    localStorage.setItem('username', username);
    localStorage.setItem('role', role);
}

function logout() {
    localStorage.clear();
    location.href = '/';
}

const BASE_SCORE = 1337 * 1000;
let toDecoratedScore = (realScore) => BASE_SCORE + realScore; // append "1337" at the beginning to make the score looks bigger
