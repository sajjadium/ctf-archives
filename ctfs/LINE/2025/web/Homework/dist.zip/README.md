# How to run

# Deploy

1. Run `source reset_data.sh` to generate/re-generate credentials.

2. After that, execute `source run.sh` each time you want to start/restart containers. 