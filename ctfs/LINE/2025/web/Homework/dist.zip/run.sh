#!/bin/bash
echo "Shutting down running containers"
sudo docker compose down

echo "Building containers"
sudo docker compose build

echo "Starting containers"
sudo docker compose up -d