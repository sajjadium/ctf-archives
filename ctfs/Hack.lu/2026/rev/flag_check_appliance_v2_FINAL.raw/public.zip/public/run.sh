#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
    printf 'Usage: %s flag{...}\n' "$0" >&2
    exit 2
fi

kernel_args=$(printf '%s' "$1" | od -An -tx1 -v | awk '
    { for (i = 1; i <= NF; i++) {
        printf "%sctf.byte.%d=%s", (n ? " " : ""), n, $i
        n++
    } }
')

qemu-system-x86_64 \
    -machine q35,accel=kvm:tcg -cpu max -m 768M \
    -drive if=pflash,format=raw,readonly=on,file=OVMF_CODE_4M.fd \
    -drive if=pflash,format=raw,file=OVMF_VARS_4M.fd \
    -drive file=flag_check_appliance_v2_FINAL.raw,format=raw,if=virtio \
    -snapshot -nographic -nic none \
    -smbios "type=11,value=io.systemd.boot.kernel-cmdline-extra=$kernel_args"
