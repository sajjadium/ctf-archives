/* SELENE licensing ABI, as far as we got it for v1.0.
   The client ships no symbols. */
#ifndef SELENE_LICENSE_H
#define SELENE_LICENSE_H
#include <stdint.h>

#define IFACE_V102 "ILicense002"

typedef struct ILicense ILicense;

typedef struct {                /* 3 slots, synchronous */
    int         (*QueryVersion)(ILicense*);
    int         (*IsLicensed)(ILicense*);
    const char* (*GetOwner)(ILicense*);
} ILicenseVtbl002;

struct ILicense { const void* vt; };
typedef void* (*CreateInterface_t)(const char* name, int* err);
#endif
