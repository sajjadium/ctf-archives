/* licensefix64. Stands in for the SELENE store client.
   The game is looking for seleneclient64.dll. */
#include <windows.h>
#include <string.h>
#include <stdio.h>
#include "license.h"

static HMODULE g_self;

static int  vm_QueryVersion(ILicense* s){ (void)s; return 2; }
static int  vm_IsLicensed  (ILicense* s){ (void)s; return 1; }
static const char* vm_GetOwner(ILicense* s){ (void)s; return "LUNARIS"; }

static const ILicenseVtbl002 g_vt002 = { vm_QueryVersion, vm_IsLicensed, vm_GetOwner };
static ILicense g_lic002 = { &g_vt002 };

__declspec(dllexport) void* CreateInterface(const char* name, int* err){
    if(name && !strcmp(name, IFACE_V102)){ if(err)*err=0; return &g_lic002; }
    if(err) *err = 1;
    return NULL;
}

/* Point the game's LoadLibraryA at ours. */
static HMODULE (WINAPI *real_LoadLibraryA)(LPCSTR) = LoadLibraryA;

static HMODULE WINAPI my_LoadLibraryA(LPCSTR name){
    if(name && !_stricmp(name, "seleneclient64.dll")) return g_self;
    return real_LoadLibraryA(name);
}

static void hook_iat(HMODULE target){
    ULONG_PTR base = (ULONG_PTR)target;
    IMAGE_DOS_HEADER* dos = (IMAGE_DOS_HEADER*)base;
    IMAGE_NT_HEADERS* nt  = (IMAGE_NT_HEADERS*)(base + dos->e_lfanew);
    DWORD rva = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    if(!rva) return;
    IMAGE_IMPORT_DESCRIPTOR* imp = (IMAGE_IMPORT_DESCRIPTOR*)(base + rva);
    for(; imp->Name; imp++){
        IMAGE_THUNK_DATA* oft = (IMAGE_THUNK_DATA*)(base + imp->OriginalFirstThunk);
        IMAGE_THUNK_DATA* ft  = (IMAGE_THUNK_DATA*)(base + imp->FirstThunk);
        if(!imp->OriginalFirstThunk) oft = ft;
        for(; oft->u1.AddressOfData; oft++, ft++){
            if(oft->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;
            IMAGE_IMPORT_BY_NAME* n = (IMAGE_IMPORT_BY_NAME*)(base + oft->u1.AddressOfData);
            if(strcmp((char*)n->Name, "LoadLibraryA")) continue;
            DWORD old;
            VirtualProtect(&ft->u1.Function, sizeof(void*), PAGE_READWRITE, &old);
            ft->u1.Function = (ULONG_PTR)my_LoadLibraryA;
            VirtualProtect(&ft->u1.Function, sizeof(void*), old, &old);
        }
    }
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r){
    (void)r;
    if(reason == DLL_PROCESS_ATTACH){ g_self = h; hook_iat(GetModuleHandleA(NULL)); }
    return TRUE;
}
