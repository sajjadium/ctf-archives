/* LNR loader. Windows takes this one before the System32 copy, so we are in
   the process early. Forwards the single call the game makes and loads
   whatever winmm.txt lists. */
#include <windows.h>
#include <stdio.h>
#include <string.h>

static HMODULE g_real;

/* Paths go next to this dll. A shortcut can hand us any cwd it likes. */
static HINSTANCE g_self;

static void inject(void){
    char dir[MAX_PATH], list[MAX_PATH], line[MAX_PATH], full[MAX_PATH];
    if(!GetModuleFileNameA(g_self, dir, sizeof dir)) return;
    char* slash = strrchr(dir, '\\');
    if(slash) *slash = 0;
    snprintf(list, sizeof list, "%s\\winmm.txt", dir);

    FILE* f = fopen(list, "r");
    if(!f) return;
    while(fgets(line, sizeof line, f)){
        line[strcspn(line, "\r\n")] = 0;
        if(!line[0]) continue;
        snprintf(full, sizeof full, "%s\\%s", dir, line);
        if(!LoadLibraryA(full)) LoadLibraryA(line);   /* fall back to search path */
    }
    fclose(f);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID r){
    (void)r;
    if(reason == DLL_PROCESS_ATTACH){
        g_self = h;
        char p[MAX_PATH];
        GetSystemDirectoryA(p, sizeof p);
        strcat(p, "\\winmm.dll");
        g_real = LoadLibraryA(p);
        inject();
    }
    return TRUE;
}

__declspec(dllexport) DWORD WINAPI timeGetTime(void){
    static DWORD (WINAPI *fn)(void);
    if(!fn && g_real) fn = (DWORD (WINAPI*)(void))(void*)GetProcAddress(g_real, "timeGetTime");
    return fn ? fn() : 0;
}
