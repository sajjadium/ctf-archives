#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <grp.h>

#define SYS_write 1
#define SYS_close 3
#define SYS_execve 59

#define LOW_PRIV_UID 1000
#define LOW_PRIV_GID 1000

long inline_syscall3(long number, long arg1, long arg2, long arg3) {
    long ret;
    __asm__ __volatile__ (
        "syscall"
        : "=a" (ret)
        : "0" (number), "D" (arg1), "S" (arg2), "d" (arg3)
        : "rcx", "r11", "memory"
    );
    return ret;
}

void die() {
    __asm__ __volatile__ ("ud2");
}

int fd1, fd2;
unsigned char byte1, byte2;

int prepare_flip(int *fd, unsigned char *byte) {
    char file_path[256];
    long long byte_offset = 0;
    int bit_offset = 0;

    printf("  file: ");
    if (scanf("%255s", file_path) != 1) {
        printf("Failed to read file path\n");
        return 1;
    }

    printf("  byte: ");
    if (scanf("%lld", &byte_offset) != 1) {
        printf("Failed to read byte offset\n");
        return 1;
    }

    printf("  bit:  ");
    if (scanf("%d", &bit_offset) != 1) {
        printf("Failed to read bit offset\n");
        return 1;
    }

    if (bit_offset < 0 || bit_offset > 7) {
        fprintf(stderr, "Invalid bit offset (must be 0-7)\n");
        return 1;
    }

    *fd = open(file_path, O_RDWR | O_CLOEXEC);
    if (*fd < 0) {
        printf("Failed to open file: %s\n", file_path);
        perror("open");
        return 1;
    }

    // go to byte_offset
    if (lseek(*fd, byte_offset, SEEK_SET) == -1) {
        printf("Failed to seek to byte offset: %lld\n", byte_offset);
        perror("lseek");
        close(*fd);
        return 1;
    }

    if (read(*fd, byte, 1) != 1) {
        printf("Failed to read byte at offset: %lld\n", byte_offset);
        perror("read");
        close(*fd);
        return 1;
    }

    // go back to byte_offset
    if (lseek(*fd, -1, SEEK_CUR) == -1) {
        printf("Failed to seek back to byte offset: %lld\n", byte_offset);
        perror("lseek back");
        close(*fd);
        return 1;
    }

    *byte ^= (1 << bit_offset);

    return 0;
}

int main(int argc, char *argv[]) {
    // The challenge is served over the container's stdio, which is not a TTY.
    // Disable buffering so prompts without a trailing newline are sent at once.
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("Flip 1:\n");
    if (prepare_flip(&fd1, &byte1) != 0) {
        printf("error: flip 1\n");
        return 1;
    }
    printf("Flip 2:\n");
    if (prepare_flip(&fd2, &byte2) != 0) {
        printf("error: flip 2\n");
        return 1;
    }

    // bye root privs
    if (setgroups(0, NULL) != 0) {
        perror("setgroups");
        return 1;
    }
    if (setresgid(LOW_PRIV_GID, LOW_PRIV_GID, LOW_PRIV_GID) != 0) {
        perror("setresgid");
        return 1;
    }
    if (setresuid(LOW_PRIV_UID, LOW_PRIV_UID, LOW_PRIV_UID) != 0) {
        perror("setresuid");
        return 1;
    }

    char *executable = argv[1];
    char **args = &argv[1];
    char *envp[] = { NULL };

    printf("Flipping & starting %s\n", executable);

    // --- danger zone ---

    if (inline_syscall3(SYS_write, fd1, (long)&byte1, 1) != 1) die();
    if (inline_syscall3(SYS_write, fd2, (long)&byte2, 1) != 1) die();

    if (inline_syscall3(SYS_close, fd1, 0, 0) != 0) die();
    if (inline_syscall3(SYS_close, fd2, 0, 0) != 0) die();

    inline_syscall3(SYS_execve, (long)executable, (long)args, (long)envp);

    die();
    return 1;
}
