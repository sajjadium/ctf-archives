#!/usr/bin/env -S node --permission
// permission jail ------^

(() => {
    require('node:stream/consumers').buffer(process.stdin).then(b => jail(b.toString().trim()));

    function jail(input) {
        // syntax jail ----v
        const forbidden = /[^0-9ABCDEFu!"#$%&'*+,\-./:;<=>?@\\^_{|}~ \n]/;
        if (forbidden.test(input)) {
            console.log('forbidden chars');
            process.exit(1);
        }

        // v-- builtins jail --v
        delete globalThis.eval;
        delete eval;
        const eventEmitterPrototype = Reflect.getPrototypeOf(Reflect.getPrototypeOf(process));
        const safeNextTick = process.nextTick;
        for (const k of Reflect.ownKeys(process)) if (typeof process[k] == 'function') delete process[k];
        delete process.mainModule;
        Object.seal(eventEmitterPrototype);
        Object.defineProperty(process, 'nextTick', {
            value: safeNextTick,
            writable: false,
            configurable: false,
        });
        delete globalThis.process;
        delete process;
        delete globalThis.require;
        delete require;
        delete globalThis.Proxy;
        delete Proxy;
        delete Reflect.getPrototypeOf(async function(){}).constructor;
        Reflect.getPrototypeOf(async function(){}).constructor = function(){};
        delete Reflect.getPrototypeOf(function*(){}).constructor;
        Reflect.getPrototypeOf(function*(){}).constructor = function(){};
        delete Reflect.getPrototypeOf(async function*(){}).constructor;
        Reflect.getPrototypeOf(async function*(){}).constructor = function(){};
        Object.freeze(Object.prototype);

        const f = new Function(`'use strict';(\n${input}\n)`);
        Function = globalThis.Function = Reflect.getPrototypeOf(function(){}).constructor = function(){};

        // let's go!
        queueMicrotask(f);
    }
})();
