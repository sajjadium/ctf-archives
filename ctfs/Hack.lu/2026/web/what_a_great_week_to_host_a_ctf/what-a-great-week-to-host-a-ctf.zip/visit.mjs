import { createInterface } from 'node:readline/promises';
import { stdin, stdout } from 'node:process';
import puppeteer from 'puppeteer';

const FLAG = process.env.FLAG || 'flag{fake}';
const TIMEOUT = Number(process.env.TIMEOUT || 10) * 1000;

const input = createInterface({ input: stdin, output: stdout });
const url = (await input.question('URL: ')).trim();
input.close();

if (!url || !/^https?:\/\//.test(url)) {
  console.log('HTTP(S) URL is required');
  process.exit(1);
}
console.log(`Visiting: ${url}`);

const browser = await puppeteer.launch({
  headless: true,
  pipe: true,
  args: [
    '--disable-extensions',
    '--disable-gpu',
    '--disable-software-rasterizer',
    '--js-flags=--noexpose_wasm,--jitless',
    '--no-sandbox',
  ],
});

try {
  await browser.setCookie({
    name: 'flag',
    value: FLAG,
    // this page really does not and can never exist, do not try to attack any example.com-related infrastructure.
    domain: 'thispagedoesntexist.example.com',
    path: '/',
    secure: true,
  });

  const page = await browser.newPage();
  void page.goto(url).catch(() => {});
  await new Promise(resolve => setTimeout(resolve, TIMEOUT));
} finally {
  console.log('Bye!');
  await browser.close();
}
