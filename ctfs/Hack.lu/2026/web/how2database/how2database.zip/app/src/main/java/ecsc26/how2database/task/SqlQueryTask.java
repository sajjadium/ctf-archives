package ecsc26.how2database.task;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class SqlQueryTask implements Callable<QueryResult>, Serializable {

    private static final long serialVersionUID = 1L;

    private final String sql;

    @Autowired
    @Qualifier("mariadbDataSource")
    private transient DataSource dataSource;

    public SqlQueryTask(String sql) {
        this.sql = sql;
    }

    @Override
    public QueryResult call() {
        try (Connection conn = dataSource.getConnection();
             Statement stmt = conn.createStatement()) {

            boolean hasResultSet = stmt.execute(sql);
            if (hasResultSet) {
                try (ResultSet rs = stmt.getResultSet()) {
                    return QueryResult.ofRows(readRows(rs));
                }
            }
            return QueryResult.ofUpdate(stmt.getUpdateCount());
        } catch (SQLException ex) {
            return QueryResult.ofError(ex.getMessage(), ex.getSQLState(), ex.getErrorCode());
        }
    }

    private static List<Map<String, Object>> readRows(ResultSet rs) throws SQLException {
        ResultSetMetaData meta = rs.getMetaData();
        int cols = meta.getColumnCount();
        List<Map<String, Object>> rows = new ArrayList<>();
        while (rs.next()) {
            Map<String, Object> row = new LinkedHashMap<>();
            for (int i = 1; i <= cols; i++) {
                row.put(meta.getColumnLabel(i), rs.getObject(i));
            }
            rows.add(row);
        }
        return rows;
    }
}
