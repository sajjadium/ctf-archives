package ecsc26.how2database.task;

import org.redisson.api.RExecutorService;
import org.redisson.api.RedissonClient;
import org.redisson.api.WorkerOptions;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;

@Component
public class PlaygroundExecutor {

    public static final String NAME = "playground";

    private final RedissonClient redisson;
    private final AutowireCapableBeanFactory beanFactory;

    public PlaygroundExecutor(RedissonClient redisson, AutowireCapableBeanFactory beanFactory) {
        this.redisson = redisson;
        this.beanFactory = beanFactory;
    }

    @PostConstruct
    void registerWorkers() {
        service().registerWorkers(WorkerOptions.defaults()
                .workers(4)
                .beanFactory(beanFactory));
    }

    public RExecutorService service() {
        return redisson.getExecutorService(NAME);
    }
}
