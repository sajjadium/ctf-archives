package ecsc26.how2database.controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.sql.DataSource;

import org.redisson.api.RExecutorFuture;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ecsc26.how2database.task.ExternalQueryTask;
import ecsc26.how2database.task.PlaygroundExecutor;
import ecsc26.how2database.task.QueryResult;
import ecsc26.how2database.task.SqlQueryTask;
import ecsc26.how2database.task.ExternalQueryTask.ExtDb;

@RestController
public class PlaygroundController {

    private static final long TIMEOUT_SECONDS = 15;

    private final PlaygroundExecutor executor;
    private final DataSource playground;

    public PlaygroundController(PlaygroundExecutor executor,
            @Qualifier("mariadbDataSource") DataSource mariadb) {
        this.executor = executor;
        this.playground = mariadb;
    }

    @PostMapping(value = "/playground/query", consumes = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<Map<String, Object>> query(@RequestBody String sql) {
        return runQueryTask(new SqlQueryTask(sql.strip()));
    }

    @PostMapping(value = "/playground/ext/{id}", consumes = MediaType.TEXT_PLAIN_VALUE)
    public ResponseEntity<Map<String, Object>> extdb(@PathVariable("id") Long id, @RequestBody String query) {
        ExtDb extDb = getExtDbById(id);
        if (extDb == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "external database not found"));
        }

        return runQueryTask(new ExternalQueryTask(extDb, query.strip()));
    }

    private ResponseEntity<Map<String, Object>> runQueryTask(Callable<QueryResult> task) {
        QueryResult result;
        try {
            RExecutorFuture<QueryResult> future = executor.service().submit(task);
            result = future.get(TIMEOUT_SECONDS, TimeUnit.SECONDS);
        } catch (TimeoutException ex) {
            return ResponseEntity.status(HttpStatus.GATEWAY_TIMEOUT)
                    .body(Map.of("error", "query timed out"));
        } catch (ExecutionException ex) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "task execution failed: " + ex.getCause()));
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "interrupted"));
        }

        if (result.error != null) {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("error", result.error);
            body.put("sqlState", result.state);
            body.put("errorCode", result.errorCode);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
        }
        if (result.rows != null) {
            return ResponseEntity.ok(Map.of("rows", result.rows, "rowCount", result.rowCount));
        }
        return ResponseEntity.ok(Map.of("updateCount", result.updateCount));
    }

    private ExtDb getExtDbById(Long id) {
        var sql = "SELECT dialect, host, port, username, password FROM extdb WHERE id = ?";
        try (Connection conn = playground.getConnection();
             var stmt = conn.prepareStatement(sql)) {
            stmt.setLong(1, id);

            boolean hasResultSet = stmt.execute();
            if (!hasResultSet) {
                return null;
            }

            ResultSet rs = stmt.getResultSet();
            if (rs.next()) {
                return new ExtDb(
                    rs.getString("dialect"),
                    rs.getString("host"),
                    rs.getInt("port"),
                    rs.getString("username"),
                    rs.getString("password"));
            } else {
                return null;
            }
        } catch (SQLException ex) {
            return null;
        }
    }
}
