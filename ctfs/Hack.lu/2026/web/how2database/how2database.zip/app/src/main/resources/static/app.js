"use strict";

const $ = (sel) => document.querySelector(sel);

let currentUser = null;
let activeLessonId = null;

// -------------------------------------------------------------------- theme
// Preference is "system" | "light" | "dark" (persisted). The concrete theme
// applied to <html data-theme> is always "light" or "dark"; "system" resolves
// via prefers-color-scheme and tracks OS changes live.
const THEME_KEY = "theme";
const THEME_ORDER = ["system", "light", "dark"];
const THEME_ICON = { system: "🖥️", light: "☀️", dark: "🌙" };
const darkMql = window.matchMedia("(prefers-color-scheme: dark)");

function themePref() {
  const p = localStorage.getItem(THEME_KEY);
  return p === "light" || p === "dark" || p === "system" ? p : "system";
}

function applyTheme(pref) {
  const dark = pref === "dark" || (pref === "system" && darkMql.matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  const btn = $("#themeToggle");
  if (btn) {
    btn.textContent = THEME_ICON[pref];
    btn.title = "Theme: " + pref + " — click to switch";
    btn.setAttribute("aria-label", "Theme: " + pref);
  }
}

function initTheme() {
  applyTheme(themePref());
  // Single button: cycle system -> light -> dark -> system.
  $("#themeToggle").addEventListener("click", () => {
    const next = THEME_ORDER[(THEME_ORDER.indexOf(themePref()) + 1) % THEME_ORDER.length];
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  });
  // React to OS theme changes while in "system" mode.
  darkMql.addEventListener("change", () => {
    if (themePref() === "system") applyTheme("system");
  });
}

// ---------------------------------------------------------------- auth bar
function renderAuth() {
  const el = $("#auth");
  el.innerHTML = "";
  updateRunControls();

  if (currentUser) {
    const who = document.createElement("span");
    who.className = "who";
    who.textContent = "Logged in as " + currentUser;
    const out = document.createElement("button");
    out.textContent = "Logout";
    out.addEventListener("click", logout);
    el.append(who, out);
    return;
  }

  const user = document.createElement("input");
  user.placeholder = "username";
  user.autocomplete = "username";
  const pass = document.createElement("input");
  pass.type = "password";
  pass.placeholder = "password";
  pass.autocomplete = "current-password";
  const btn = document.createElement("button");
  btn.textContent = "Log in";
  const err = document.createElement("span");
  err.className = "err";

  const submit = () => login(user.value, pass.value, err);
  btn.addEventListener("click", submit);
  pass.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });

  el.append(user, pass, btn, err);
}

async function login(username, password, errEl) {
  errEl.textContent = "";
  try {
    const res = await fetch("/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    if (res.ok && data.authenticated) {
      currentUser = data.username;
      renderAuth();
      $("#runHint").textContent = "";
    } else {
      errEl.textContent = data.error || "login failed";
    }
  } catch (e) {
    errEl.textContent = "network error";
  }
}

async function logout() {
  try { await fetch("/logout", { method: "POST" }); } catch (e) { /* ignore */ }
  currentUser = null;
  renderAuth();
}

// Lock the Run button (greyed, not-allowed cursor, tooltip) until logged in.
function updateRunControls() {
  const btn = $("#runBtn");
  if (!btn) return;
  if (currentUser) {
    btn.classList.remove("locked");
    btn.removeAttribute("title");
  } else {
    btn.classList.add("locked");
    btn.title = "log in to run queries";
  }
}

// Restore logged-in state from the session cookie on page load.
async function refreshMe() {
  try {
    const res = await fetch("/me");
    const data = await res.json();
    currentUser = data.authenticated ? data.username : null;
  } catch (e) {
    currentUser = null;
  }
}

// ------------------------------------------------------------- lesson list
async function loadLessons(q) {
  const url = q ? "/lessons?q=" + encodeURIComponent(q) : "/lessons";
  const list = $("#lessonList");
  try {
    const res = await fetch(url);
    const lessons = await res.json();
    list.innerHTML = "";
    if (!lessons.length) {
      const li = document.createElement("li");
      li.className = "muted";
      li.textContent = "No lessons found.";
      list.append(li);
      return;
    }
    for (const lesson of lessons) {
      const li = document.createElement("li");
      li.dataset.id = lesson.id;
      if (lesson.id === activeLessonId) li.classList.add("active");
      const title = document.createElement("strong");
      title.textContent = lesson.title;
      const slug = document.createElement("span");
      slug.className = "slug";
      slug.textContent = lesson.slug;
      li.append(title, slug);
      li.addEventListener("click", () => openLesson(lesson.id));
      list.append(li);
    }
  } catch (e) {
    list.innerHTML = "";
  }
}

// ----------------------------------------------------------- lesson detail
async function openLesson(id) {
  try {
    const res = await fetch("/lessons/" + encodeURIComponent(id));
    if (!res.ok) return;
    const lesson = await res.json();

    activeLessonId = lesson.id;
    document.querySelectorAll("#lessonList li").forEach((li) =>
      li.classList.toggle("active", Number(li.dataset.id) === lesson.id));

    $("#lessonBody").innerHTML = marked.parse(lesson.bodyMarkdown || "");
    $("#lessonBody").querySelectorAll("pre code").forEach((el) => {
      try { hljs.highlightElement(el); } catch (e) { /* ignore */ }
    });
    $("#queryInput").value = lesson.query || "";
    $("#results").innerHTML = "";
    $("#runHint").textContent = "";

    $("#lessonEmpty").hidden = true;
    $("#lessonView").hidden = false;
  } catch (e) { /* ignore */ }
}

// -------------------------------------------------------------- playground
async function runQuery() {
  if (!currentUser) {
    $("#runHint").textContent = "log in to run queries";
    return;
  }
  const sql = $("#queryInput").value;
  const results = $("#results");
  const hint = $("#runHint");
  hint.textContent = "";
  results.innerHTML = "";

  try {
    const res = await fetch("/playground/query", {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: sql,
    });
    const data = await res.json();

    if (res.status === 401) {
      hint.textContent = "Log in to run queries.";
      return;
    }
    if (Array.isArray(data.rows)) {
      renderTable(data.rows, results);
    } else if ("updateCount" in data) {
      msg(results, "ok", "OK — " + data.updateCount + " row(s) affected.");
    } else if (data.error) {
      msg(results, "error", data.error + (data.sqlState ? "  [" + data.sqlState + "]" : ""));
    }
  } catch (e) {
    msg(results, "error", "network error");
  }
}

function renderTable(rows, container) {
  if (!rows.length) { msg(container, "ok", "0 rows."); return; }
  const cols = Object.keys(rows[0]);
  const table = document.createElement("table");
  table.className = "result";

  const thead = document.createElement("thead");
  const hr = document.createElement("tr");
  for (const c of cols) {
    const th = document.createElement("th");
    th.textContent = c;
    hr.append(th);
  }
  thead.append(hr);

  const tbody = document.createElement("tbody");
  for (const row of rows) {
    const tr = document.createElement("tr");
    for (const c of cols) {
      const td = document.createElement("td");
      const v = row[c];
      td.textContent = v === null || v === undefined ? "NULL" : String(v);
      if (v === null || v === undefined) td.className = "muted";
      tr.append(td);
    }
    tbody.append(tr);
  }
  table.append(thead, tbody);
  container.append(table);
}

function msg(container, kind, text) {
  const div = document.createElement("div");
  div.className = "result-msg " + kind;
  div.textContent = text;
  container.append(div);
}

// --------------------------------------------------------------- bootstrap
function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

document.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  await refreshMe();
  renderAuth();
  loadLessons("");
  $("#search").addEventListener("input", debounce((e) => loadLessons(e.target.value.trim()), 200));
  $("#runBtn").addEventListener("click", runQuery);
});
