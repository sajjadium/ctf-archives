package ecsc26.how2database.task;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class QueryResult implements Serializable {

    private static final long serialVersionUID = 1L;

    public List<Map<String, Object>> rows;
    public Integer rowCount;
    public Integer updateCount;
    public String error;
    public String state;
    public Integer errorCode;

    public QueryResult() {
    }

    public static QueryResult ofRows(List<Map<String, Object>> rows) {
        QueryResult r = new QueryResult();
        r.rows = rows;
        r.rowCount = rows.size();
        return r;
    }

    public static QueryResult ofUpdate(int updateCount) {
        QueryResult r = new QueryResult();
        r.updateCount = updateCount;
        return r;
    }

    public static QueryResult ofError(String error, String state, int errorCode) {
        QueryResult r = new QueryResult();
        r.error = error;
        r.state = state;
        r.errorCode = errorCode;
        return r;
    }
}
