package ecsc26.how2database.task;

import java.io.Serializable;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class ExternalQueryTask implements Callable<QueryResult>, Serializable {

    private static final long serialVersionUID = 1L;

    private final ExtDb extDb;
    private final String sql;

    @Autowired
    @Qualifier("mariadbDataSource")
    private transient DataSource playground;

    public ExternalQueryTask(ExtDb extDb, String sql) {
        this.extDb = extDb;
        this.sql = sql;
    }

    @Override
    public QueryResult call() {
        if ("ldap".equals(extDb.getDialect())) {
            var response = queryLdap(extDb, sql);
            return QueryResult.ofRows(List.of(response));
        }

        return QueryResult.ofError("unsupported external database dialect: " + extDb.getDialect(), null, 0);
    }

    private Map<String, Object> queryLdap(ExtDb extDb, String query) {
        var env = new Hashtable<String, String>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, "ldap://" + extDb.getHost() + ":" + extDb.getPort());
        env.put(Context.REFERRAL, "ignore");
        env.put(Context.SECURITY_AUTHENTICATION, "simple");
        env.put(Context.SECURITY_PRINCIPAL, extDb.getUsername()); 
        env.put(Context.SECURITY_CREDENTIALS, extDb.getPassword());
        env.put("com.sun.jndi.ldap.connect.timeout", "2000");
        env.put("com.sun.jndi.ldap.read.timeout", "2000");

        Attributes attrs;
        try {
            DirContext ctx = new InitialDirContext(env);
            attrs = ctx.getAttributes(query);

            Map<String, Object> result = new HashMap<>();
            NamingEnumeration<? extends Attribute> enumeration = attrs.getAll();
            while (enumeration.hasMore()) {
                Attribute attr = enumeration.next();
                List<String> values = new ArrayList<>();

                NamingEnumeration<?> valEnum = attr.getAll();
                while (valEnum.hasMore()) {
                    values.add(valEnum.next().toString());
                }
                result.put(attr.getID(), values.size() == 1 ? values.get(0) : values);
            }

            return result;
        } catch (NamingException e) {
            e.printStackTrace();
            return Map.of("error", "failed to connect to LDAP server");
        }
    }

    public static class ExtDb implements Serializable {

        private static final long serialVersionUID = 1L;

        private String dialect;
        private String host;
        private int port;
        private String username;
        private String password;

        public ExtDb(String dialect, String host, int port, String username, String password) {
            setDialect(dialect);
            setHost(host);
            setPort(port);
            setUsername(username);
            setPassword(password);
        }

        public String getDialect() {
            return dialect;
        }
        void setDialect(String dialect) {
            this.dialect = dialect;
        }
        public String getHost() {
            return host;
        }
        void setHost(String host) {
            Inet4Address address;
            try {
                address = (Inet4Address) InetAddress.getByName(host);
            } catch (Exception e) {
                throw new IllegalArgumentException("invalid IP address");
            }
            if (!address.isSiteLocalAddress() && !address.isLoopbackAddress()) {
                throw new IllegalArgumentException("no public IP address allowed");
            }
            this.host = address.getHostAddress();
        }
        public int getPort() {
            return port;
        }
        void setPort(int port) {
            if (port < 0 || port > 65535) {
                throw new IllegalArgumentException("invalid port number");
            }
            this.port = port;
        }
        public String getUsername() {
            return username;
        }
        void setUsername(String username) {
            if (username != null && username.length() > 32) {
                throw new IllegalArgumentException("username too long");
            }
            this.username = username;
        }
        public String getPassword() {
            return password;
        }
        void setPassword(String password) {
            if (password != null && password.length() > 32) {
                throw new IllegalArgumentException("password too long");
            }
            this.password = password;
        }
    }
}
