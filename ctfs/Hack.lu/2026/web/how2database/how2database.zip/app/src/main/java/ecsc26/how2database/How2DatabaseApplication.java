package ecsc26.how2database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class How2DatabaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(How2DatabaseApplication.class, args);
    }
}
