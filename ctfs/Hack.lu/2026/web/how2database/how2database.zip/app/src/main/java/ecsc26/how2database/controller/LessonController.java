package ecsc26.how2database.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.jooq.DSLContext;
import org.jooq.Field;
import org.jooq.Record;
import org.jooq.Table;
import org.jooq.impl.DSL;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LessonController {

    private static final Table<Record> LESSON = DSL.table("lesson");
    private static final Field<Long> ID = DSL.field("id", Long.class);
    private static final Field<String> SLUG = DSL.field("slug", String.class);
    private static final Field<String> TITLE = DSL.field("title", String.class);
    private static final Field<String> BODY = DSL.field("body_markdown", String.class);
    private static final Field<String> QUERY = DSL.field("query", String.class);

    private final DSLContext dsl;

    public LessonController(DSLContext dsl) {
        this.dsl = dsl;
    }

    @GetMapping("/lessons")
    public List<Map<String, Object>> list(
        @RequestParam(name = "q", required = false) String q,
        @RequestParam(name = "order", required = false) String orderBy) {

        var query = dsl.select(ID, SLUG, TITLE).from(LESSON).where(DSL.noCondition());

        if (q != null && !q.isBlank()) {
            String pattern = "%" + q + "%";
            query = query.and(TITLE.likeIgnoreCase(pattern).or(BODY.likeIgnoreCase(pattern)));
        }

        return query.orderBy(DSL.field(orderBy == null ? "id" : orderBy)).fetchMaps();
    }

    @GetMapping("/lessons/{id}")
    public ResponseEntity<Map<String, Object>> detail(@PathVariable("id") long id) {
        Record r = dsl.select(ID, SLUG, TITLE, BODY, QUERY)
                .from(LESSON)
                .where(ID.eq(id))
                .fetchOne();

        if (r == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "lesson not found"));
        }

        Map<String, Object> body = new LinkedHashMap<>();
        body.put("id", r.get(ID));
        body.put("slug", r.get(SLUG));
        body.put("title", r.get(TITLE));
        body.put("bodyMarkdown", r.get(BODY));
        body.put("query", r.get(QUERY));
        return ResponseEntity.ok(body);
    }
}
