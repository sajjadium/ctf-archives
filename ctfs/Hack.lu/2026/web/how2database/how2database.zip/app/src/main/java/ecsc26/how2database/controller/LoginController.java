package ecsc26.how2database.controller;

import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import ecsc26.how2database.db.User;
import ecsc26.how2database.db.UserRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@RestController
public class LoginController {

    private final UserRepository users;
    private final PasswordEncoder encoder = new BCryptPasswordEncoder();

    public LoginController(UserRepository users) {
        this.users = users;
    }

    public record LoginRequest(String username, String password) {
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody LoginRequest req, HttpSession session) {
        Optional<User> user = req.username() == null
                ? Optional.empty()
                : users.findByUsername(req.username());

        boolean ok = user.isPresent()
                && req.password() != null
                && encoder.matches(req.password(), user.get().getPasswordHash());

        if (ok) {
            session.setAttribute("username", user.get().getUsername());
            return ResponseEntity.ok(Map.of(
                    "authenticated", true,
                    "username", user.get().getUsername()));
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of(
                "authenticated", false,
                "error", "invalid credentials"));
    }

    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.ok(Map.of("authenticated", false));
    }

    @GetMapping("/me")
    public Map<String, Object> me(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        Object username = session == null ? null : session.getAttribute("username");
        if (username != null) {
            return Map.of("authenticated", true, "username", username);
        }
        return Map.of("authenticated", false);
    }
}
