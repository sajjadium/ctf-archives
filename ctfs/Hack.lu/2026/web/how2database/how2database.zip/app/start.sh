#!/usr/bin/env bash
set -e

# Extract host and port from env URLs using sed
targets=(
  $(echo "$SPRING_DATASOURCE_URL" | sed -nE 's#.*://([^:/]+):([0-9]+).*#\1:\2#p')
  $(echo "$SPRING_DATASOURCE_MARIADB_URL" | sed -nE 's#.*://([^:/]+):([0-9]+).*#\1:\2#p')
  $(echo "$REDISSON_ADDRESS" | sed -nE 's#.*://([^:/]+):([0-9]+).*#\1:\2#p')
)

for target in "${targets[@]}"; do
  host="${target%%:*}"
  port="${target##*:}"
  until (echo > /dev/tcp/"$host"/"$port") >/dev/null 2>&1; do
    echo "Waiting for $host:$port to be available..."
    sleep 1
  done
done

exec java -jar /app/app.jar
