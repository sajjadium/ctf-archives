USE how2db;

-- tables
CREATE TABLE IF NOT EXISTS message (
    id   BIGINT       NOT NULL AUTO_INCREMENT,
    text VARCHAR(255),
    PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS country (
    code       CHAR(2)      NOT NULL,
    name       VARCHAR(64)  NOT NULL,
    continent  VARCHAR(32)  NOT NULL,
    population  BIGINT      NOT NULL,
    PRIMARY KEY (code)
);

-- app user
CREATE USER IF NOT EXISTS 'readonly'@'%' IDENTIFIED BY 'readonly';
GRANT SELECT ON how2db.* TO 'readonly'@'%';
FLUSH PRIVILEGES;

-- default data
INSERT INTO message (text) VALUES
    ('Hello from the seed data'),
    ('MariaDB initialised this row'),
    ('The app can only read these');

INSERT INTO country (code, name, continent, population) VALUES
    ('DE', 'Germany',        'Europe',        83200000),
    ('FR', 'France',         'Europe',        67800000),
    ('IS', 'Iceland',        'Europe',          370000),
    ('JP', 'Japan',          'Asia',         125700000),
    ('IN', 'India',          'Asia',        1408000000),
    ('BR', 'Brazil',         'South America', 214300000),
    ('KE', 'Kenya',          'Africa',         53000000),
    ('US', 'United States',  'North America', 331900000);

-- [WIP] external database feature
CREATE TABLE IF NOT EXISTS extdb (
    id       BIGINT       NOT NULL AUTO_INCREMENT,
    dialect  VARCHAR(32)  NOT NULL,
    host     VARCHAR(32)  NOT NULL,
    port     INT          NOT NULL,
    username VARCHAR(32)  NOT NULL,
    password VARCHAR(32)  NOT NULL,
    PRIMARY KEY (id)
);
