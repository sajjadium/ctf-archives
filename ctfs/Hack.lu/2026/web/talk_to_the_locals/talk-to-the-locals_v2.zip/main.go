package main

import (
	"bufio"
	"bytes"
	"embed"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

var won atomic.Bool
var firefox sync.Mutex

//go:embed index.html
var embedFS embed.FS

func main() {
	flag := os.Getenv("FLAG")
	timeout := os.Getenv("TIMEOUT")

	checkIpv6()
	startFlagServer()

	http.Handle("GET /", http.FileServerFS(embedFS))
	http.HandleFunc("POST /visit", func(w http.ResponseWriter, r *http.Request) {
		url := r.FormValue("url")
		log.Printf("visit requested remote=%s url=%q", r.RemoteAddr, url)
		if !strings.HasPrefix(url, "http://") && !strings.HasPrefix(url, "https://") {
			http.Error(w, "invalid url", http.StatusBadRequest)
			return
		}
		firefox.Lock()
		defer firefox.Unlock()
		exec.Command("timeout", timeout, "firefox", "--headless", url).Run()
		http.Redirect(w, r, "/", http.StatusSeeOther)
	})
	http.HandleFunc("GET /flag", func(w http.ResponseWriter, r *http.Request) {
		if !won.Load() {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		fmt.Fprintln(w, flag)
	})

	httpAddr := os.Getenv("CHALLENGE_ADDR")
	if httpAddr == "" {
		httpAddr = ":1337"
	}
	log.Printf("Listening on %s", httpAddr)
	panic(http.ListenAndServe(httpAddr, nil))
}

func checkIpv6() {
	c, err := net.DialTimeout("udp6", "[2001:4860:4860::8888]:53", time.Second)
	if err != nil {
		panic("no IPv6 connectivity")
	}
	c.Close()
}

func startFlagServer() {
	conn, err := net.ListenPacket("udp", "127.0.0.1:6767")
	if err != nil {
		panic(err)
	}
	go func() {
		defer conn.Close()
		buf := make([]byte, 1024)
		for {
			n, addr, err := conn.ReadFrom(buf)
			if err != nil {
				if errors.Is(err, net.ErrClosed) {
					return
				}
				log.Printf("UDP read failed: %v", err)
				continue
			}
			line := getLine(bytes.NewReader(buf[:n]))

			log.Printf("UDP packet from=%s bytes=%d line=%q", addr, n, line)
			if line == "give me the flag bro" {
				won.Store(true)
				log.Printf("won!")
			}
		}
	}()
}

func getLine(r io.Reader) string {
	line, _ := bufio.NewReader(r).ReadString('\n')
	return strings.TrimRight(line, "\n")
}
