#!/usr/bin/env node
const { connect, makeSlug } = require('../src/db');

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin';
const FLAG = process.env.FLAG || 'flag{example_flag}';

const db = connect();

let admin = db.prepare('SELECT * FROM users WHERE username = ?').get(ADMIN_USER);
if (!admin) {
  db.prepare('INSERT INTO users (username, password) VALUES (?,?)').run(ADMIN_USER, ADMIN_PASSWORD);
  admin = db.prepare('SELECT * FROM users WHERE username = ?').get(ADMIN_USER);
  console.log(`  + user @${ADMIN_USER}`);
}

if (db.prepare('SELECT 1 FROM mails WHERE owner_id = ?').get(admin.id)) {
  console.log('  + admin mailbox already seeded, skipping');
} else {
  const add = db.prepare(
    'INSERT INTO mails (slug, owner_id, sender, subject, body, created_at) VALUES (?,?,?,?,?,?)');
  const DAY = 86400000;
  const now = Date.now();
  const seed = [
    [400, 'vault@postbox.local', 'Recovery key', `Keep this somewhere safe:\n\n${FLAG}\n\nDo not forward.`],
    [340, 'hr@postbox.local', 'Welcome to Postbox', 'Your mailbox is ready. Storage: 15 GB.'],
    [12, 'noreply@postbox.local', 'Quarterly report Q3', 'Numbers attached. Review before Friday.'],
    [3, 'ops@postbox.local', 'Scheduled maintenance', 'Brief downtime on Sunday 02:00 UTC.'],
  ];
  for (const [daysAgo, sender, subject, body] of seed) {
    add.run(makeSlug(subject), admin.id, sender, subject, body, now - daysAgo * DAY);
  }
  console.log(`  + ${seed.length} messages for @${ADMIN_USER}`);
}

console.log(`Done.  @${ADMIN_USER}`);
