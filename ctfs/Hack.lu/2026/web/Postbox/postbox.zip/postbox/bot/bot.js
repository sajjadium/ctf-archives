const express = require('express');
const rateLimit = require('express-rate-limit');
const puppeteer = require('puppeteer');

const PORT = parseInt(process.env.PORT || '1337', 10);
const INSTANCE_HOST = process.env.INSTANCE_HOST || '';
const APP_URL = INSTANCE_HOST
  ? `https://${INSTANCE_HOST}`
  : 'http://postbox:3000';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin';
const VISIT_TIMEOUT_MS = parseInt(process.env.VISIT_TIMEOUT_MS || '10000', 10);
const TIMEOUT = parseInt(process.env.TIMEOUT || '30000', 10);
const UBO_XPI = process.env.UBO_XPI || '/opt/ubo.xpi';
const UBO_WARMUP_MS = parseInt(process.env.UBO_WARMUP_MS || '5000', 10);

const app = express();
app.use(express.json({ limit: '8kb' }));
app.set('trust proxy', 1);

const reportLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 2,
  message: { error: 'Too many requests, please try again later.' },
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function visit(url) {
  const browser = await puppeteer.launch({
    browser: 'firefox',
    headless: true,
    extraPrefsFirefox: {
      'network.cookie.cookieBehavior': 4,
      // local testing: let a public probe page reach the private app
      'network.lna.enabled': false,
      'network.lna.blocking': false,
    },
  });
  try {
    await browser.installExtension(UBO_XPI);
    await sleep(UBO_WARMUP_MS);

    const page = await browser.newPage();
    page.on('console', (m) => console.log('[page]', m.text()));

    await page.goto(`${APP_URL}/login`, { timeout: VISIT_TIMEOUT_MS });
    await page.locator('form input[name="username"]').fill(ADMIN_USER);
    await page.locator('form input[name="password"]').fill(ADMIN_PASSWORD);
    await page.click('form button');
    await page.waitForSelector('.list', { timeout: VISIT_TIMEOUT_MS });

    await page.goto(url, { timeout: VISIT_TIMEOUT_MS, waitUntil: 'load' }).catch(() => {});
    await sleep(TIMEOUT);
  } finally {
    await browser.close().catch(() => {});
  }
}

app.post('/report', reportLimiter, async (req, res) => {
  const { url } = req.body || {};
  if (typeof url !== 'string' || !/^https?:\/\/./.test(url)) {
    return res.status(400).json({ error: 'URL must be a string starting with http(s)://' });
  }
  console.log('[bot] visiting:', url);
  try {
    await visit(url);
    res.json({ success: true });
  } catch (err) {
    console.error('[bot] error:', err.message);
    res.status(500).json({ error: 'Failed to visit url!' });
  }
});

app.get(['/', '/report'], (_req, res) => res.sendFile('bot.html', { root: __dirname }));

app.listen(PORT, () => console.log(`[bot] listening on http://127.0.0.1:${PORT}`));
