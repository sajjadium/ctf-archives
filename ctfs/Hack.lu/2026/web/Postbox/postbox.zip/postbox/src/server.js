const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const { connect, makeSlug } = require('./db');

const PORT = parseInt(process.env.PORT || '3000', 10);
const SESSION_MAX_AGE_MS = 1000 * 60 * 60 * 24 * 7;

const db = connect();

const MAIL_SEARCH = `
  SELECT * FROM mails WHERE owner_id = ?
    AND (instr(lower(subject), lower(?)) > 0 OR instr(lower(body), lower(?)) > 0)`;

const queries = {
  insertUser: db.prepare('INSERT INTO users (username, password) VALUES (?,?)'),
  userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
  userById: db.prepare('SELECT id, username FROM users WHERE id = ?'),
  insertMail: db.prepare(
    'INSERT INTO mails (slug, owner_id, sender, subject, body, created_at) VALUES (?,?,?,?,?,?)'),
  mailBySlug: db.prepare('SELECT * FROM mails WHERE slug = ? AND owner_id = ?'),
  deleteMail: db.prepare('DELETE FROM mails WHERE slug = ? AND owner_id = ?'),
  searchNewestFirst: db.prepare(`${MAIL_SEARCH} ORDER BY created_at DESC, id DESC LIMIT 50`),
  searchOldestFirst: db.prepare(`${MAIL_SEARCH} ORDER BY created_at ASC, id ASC LIMIT 50`),
};

const app = express();
app.set('trust proxy', 1);
app.use(express.urlencoded({ extended: false }));
app.use(session({
  name: 'pb.sid',
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, maxAge: SESSION_MAX_AGE_MS },
}));
app.use((_req, res, next) => {
  res.setHeader('Content-Security-Policy', "default-src 'self'; base-uri 'none'; form-action 'self'");
  res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

const currentUser = (req) => (req.session.userId ? queries.userById.get(req.session.userId) : null);

const formatTimestamp = (ms) => new Date(ms).toISOString().slice(0, 16).replace('T', ' ');

const requireLogin = (req, res, next) => {
  req.user = currentUser(req);
  if (!req.user) return res.redirect('/login');
  next();
};

const inboxUrl = (term, sort, openSlug = '') => {
  const params = new URLSearchParams();
  if (term) params.set('q', term);
  if (sort === 'asc') params.set('sort', 'asc');
  if (openSlug) params.set('open', openSlug);
  return `/?${params}`;
};

const deleteUrl = (slug, term, sort) => {
  const params = new URLSearchParams();
  params.set('slug', slug);
  if (term) params.set('q', term);
  if (sort === 'asc') params.set('sort', 'asc');
  return `/delete?${params}`;
};

const listMails = (user, term = '', sort = 'desc') => {
  const search = sort === 'asc' ? queries.searchOldestFirst : queries.searchNewestFirst;
  return search.all(user.id, term, term).map((mail) => ({
    ...mail,
    when: formatTimestamp(mail.created_at),
    href: inboxUrl(term, sort, mail.slug),
    deleteHref: deleteUrl(mail.slug, term, sort),
  }));
};

app.get('/login', (req, res) => {
  if (currentUser(req)) return res.redirect('/');
  res.render('login');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const name = typeof username === 'string' ? username.trim() : '';
  if (!/^[a-zA-Z0-9_]{3,24}$/.test(name)) {
    return res.status(400).render('login',
      { error: 'Username must be 3-24 characters: letters, digits and _' });
  }
  if (typeof password !== 'string' || password.length < 4 || password.length > 128) {
    return res.status(400).render('login', { error: 'Password must be 4-128 characters.' });
  }

  let user = queries.userByName.get(name);
  if (!user) {
    queries.insertUser.run(name, password);
    user = queries.userByName.get(name);
  } else if (user.password !== password) {
    return res.status(401).render('login', { error: 'Invalid username or password.' });
  }

  req.session.userId = user.id;
  res.redirect('/');
});

app.post('/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/login'));
});

app.get('/', requireLogin, (req, res) => {
  const user = req.user;
  const term = String(req.query.q || '');
  const sort = String(req.query.sort || '');
  const requestedSlug = String(req.query.open || '');

  const mails = listMails(user, term, sort);
  const openMail = mails.find((mail) => mail.slug === requestedSlug) || mails[0];

  res.render('mail', {
    username: user.username,
    term,
    mails,
    openSlug: openMail ? openMail.slug : 'none',
  });
});

app.get('/compose', requireLogin, (req, res) => {
  const user = req.user;

  res.render('mail', {
    username: user.username,
    mails: listMails(user),
    compose: true,
    sent: req.query.sent,
  });
});

app.post('/compose', requireLogin, (req, res) => {
  const user = req.user;
  const { to = '', subject = '', body = '' } = req.body || {};

  const recipient = queries.userByName.get(String(to).trim());
  if (!recipient) {
    return res.status(404).render('mail', {
      username: user.username,
      mails: listMails(user),
      compose: true,
      error: 'No such user.',
    });
  }

  const cleanSubject = String(subject).slice(0, 120);
  const cleanBody = String(body).slice(0, 500);
  queries.insertMail.run(
    makeSlug(cleanSubject), recipient.id, user.username, cleanSubject, cleanBody, Date.now());
  res.redirect('/compose?sent=1');
});

app.get('/delete', requireLogin, (req, res) => {
  const slug = String(req.query.slug || '');
  const term = String(req.query.q || '');
  const sort = String(req.query.sort || '');

  queries.deleteMail.run(slug, req.user.id);
  res.redirect(inboxUrl(term, sort));
});

app.get('/msg/:slug/body.html', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.status(401).render('msg', { notice: 'Sign in to read this message.' });
  if (req.params.slug === 'none') return res.render('msg', { notice: 'No message selected.' });

  const mail = queries.mailBySlug.get(req.params.slug, user.id);
  if (!mail) return res.status(404).render('msg', { notice: 'Message not found.' });

  res.render('msg', { mail: { ...mail, when: formatTimestamp(mail.created_at) } });
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).send('server error');
});

app.listen(PORT, () => console.log(`Postbox listening on http://0.0.0.0:${PORT}`));
