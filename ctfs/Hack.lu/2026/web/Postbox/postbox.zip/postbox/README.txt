postbox
=======

```bash
cp .env.example .env
docker compose up
```

then visit
http://localhost:8080
