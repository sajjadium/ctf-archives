#!/usr/bin/env node

const crypto = require('crypto');
const { connect } = require('../src/db');

const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin';
const FLAG = process.env.FLAG || 'flag{example_flag}';

const db = connect();

let admin = db.prepare('SELECT * FROM users WHERE username = ?').get(ADMIN_USER);
if (!admin) {
  db.prepare('INSERT INTO users (username, password) VALUES (?,?)').run(ADMIN_USER, ADMIN_PASSWORD);
  admin = db.prepare('SELECT * FROM users WHERE username = ?').get(ADMIN_USER);
  console.log(`  + user @${ADMIN_USER}`);
}

if (db.prepare('SELECT 1 FROM widgets WHERE owner_id = ?').get(admin.id)) {
  console.log('  + admin already has a widget, skipping');
} else {
  const id = `${ADMIN_USER}-${crypto.randomBytes(6).toString('hex')}`;
  db.prepare('INSERT INTO widgets (id, owner_id, url, note) VALUES (?,?,?,?)')
    .run(id, admin.id, 'https://example.com/', FLAG);
  console.log(`  + widget ${id}`);
}

console.log(`Done.  ${ADMIN_USER} / ${ADMIN_PASSWORD}`);
