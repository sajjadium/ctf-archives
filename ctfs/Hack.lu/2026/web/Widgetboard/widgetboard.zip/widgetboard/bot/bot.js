const express = require('express');
const rateLimit = require('express-rate-limit');
const { webkit } = require('playwright');

const PORT = parseInt(process.env.PORT || '1337', 10);
const INSTANCE_HOST = process.env.INSTANCE_HOST || '';
const APP_URL = INSTANCE_HOST ? `https://${INSTANCE_HOST}` : 'http://widgetboard:3000';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin';
const VISIT_TIMEOUT_MS = parseInt(process.env.VISIT_TIMEOUT_MS || '10000', 10);
const IGNORE_TLS = process.env.IGNORE_TLS === '1';

const app = express();
app.use(express.json({ limit: '8kb', inflate: false }));
app.set('trust proxy', 1);

const reportLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 3,
  message: { error: 'Too many requests, please try again later.' },
});

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function visit(url) {
  const browser = await webkit.launch({ headless: true });
  const context = await browser.newContext({ ignoreHTTPSErrors: IGNORE_TLS });
  try {
    const page = await context.newPage();

    // sign in
    await page.goto(`${APP_URL}/signin`, { timeout: VISIT_TIMEOUT_MS });
    await page.fill('form input[name="username"]', ADMIN_USER);
    await page.fill('form input[name="password"]', ADMIN_PASSWORD);
    await page.click('form button');
    if ((await page.title()) !== `${ADMIN_USER}'s board`) throw new Error('admin login failed');

    // no popups
    context.on('page', () => browser.close().catch(() => {}));
    page.on('console', (msg) => console.log(msg.text()));

    // let it rip
    await page.goto(url, { timeout: VISIT_TIMEOUT_MS, waitUntil: 'load' }).catch(() => {});
    await sleep(30000);
  } finally {
    await browser.close().catch(() => {});
  }
}

app.post('/report', reportLimiter, async (req, res) => {
  const { url } = req.body || {};
  if (typeof url !== 'string' || !/^https?:\/\/./.test(url)) {
    return res.status(400).json({ error: 'URL must be a string starting with http(s)://' });
  }
  console.log('[bot] visiting:', url);
  try {
    await visit(url);
    res.json({ success: true });
  } catch (err) {
    console.error('[bot] error:', err.message);
    res.status(500).json({ error: 'Failed to visit url!' });
  }
});

app.get(['/', '/report'], (_req, res) => res.sendFile('bot.html', { root: __dirname }));

app.listen(PORT, () => console.log(`[bot] listening on http://127.0.0.1:${PORT}`));
