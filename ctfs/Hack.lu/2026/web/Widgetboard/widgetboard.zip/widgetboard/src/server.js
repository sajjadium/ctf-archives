const path = require('path');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const { connect } = require('./db');

const PORT = parseInt(process.env.PORT || '3000', 10);
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const db = connect();

const q = {
  insertUser: db.prepare('INSERT INTO users (username, password) VALUES (?,?)'),
  userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
  userById: db.prepare('SELECT id, username FROM users WHERE id = ?'),
  addWidget: db.prepare('INSERT INTO widgets (id, owner_id, url, note) VALUES (?,?,?,?)'),
  getWidget: db.prepare('SELECT * FROM widgets WHERE id = ?'),
  share: db.prepare('UPDATE widgets SET shared_with = ? WHERE id = ?'),
  listVisible: db.prepare(`
    SELECT w.*, u.username AS owner FROM widgets w
    JOIN users u ON u.id = w.owner_id
    WHERE w.owner_id = ? OR w.shared_with = ?
    ORDER BY w.rowid`),
  suggest: db.prepare(`
    SELECT id FROM widgets
    WHERE (owner_id = ? OR shared_with = ?) AND instr(lower(id), ?) = 1
    ORDER BY id LIMIT 8`),
};

const app = express();
app.set('trust proxy', 1);
app.use(express.urlencoded({ extended: false, inflate: false }));
app.use(session({
  name: 'wb.sid',
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'strict', maxAge: 1000 * 60 * 60 * 24 * 7, path: '' },
}));
app.use((_req, res, next) => {
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  next();
});
app.use(express.static(path.join(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

function currentUser(req) {
  return req.session.userId ? q.userById.get(req.session.userId) : null;
}

const boardView = (user, error) => ({
  title: `${user.username}'s board`,
  username: user.username,
  widgets: q.listVisible.all(user.id, user.username),
  error,
});

app.get('/', (_req, res) => res.render('landing', { title: 'WidgetBoard' }));

app.get('/signin', (req, res) => {
  if (currentUser(req)) return res.redirect('/board');
  res.render('login', { title: 'WidgetBoard' });
});

app.post('/board', (req, res) => {
  const { username, password } = req.body || {};
  const name = typeof username === 'string' ? username.trim() : '';

  if (!/^[a-zA-Z0-9_]{3,24}$/.test(name)) {
    return res.status(400).render('login', { title: 'WidgetBoard', error: 'Username must be 3-24 characters: letters, digits and _' });
  }
  if (typeof password !== 'string' || password.length < 4 || password.length > 128) {
    return res.status(400).render('login', { title: 'WidgetBoard', error: 'Password must be 4-128 characters.' });
  }

  let user = q.userByName.get(name);
  if (!user) {
    q.insertUser.run(name, password);
    user = q.userByName.get(name);
  } else if (user.password !== password) {
    return res.status(401).render('login', { title: 'WidgetBoard', error: 'Invalid username or password.' });
  }
  req.session.userId = user.id;
  res.redirect('/board');
});

app.get('/board', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.redirect('/signin');
  res.render('board', boardView(user));
});

app.post('/logout', (req, res) => req.session.destroy(() => res.redirect('/signin')));

app.post('/widgets/new', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.redirect('/signin');
  if (user.username === ADMIN_USER) {
    return res.status(403).render('board', boardView(user, 'The admin board is read-only.'));
  }
  const { url, note } = req.body || {};
  if (typeof url !== 'string' || !/^https?:\/\//i.test(url)) {
    return res.status(400).render('board', boardView(user, 'A widget must be an http(s) URL.'));
  }
  const id = `${user.username}-${crypto.randomBytes(6).toString('hex')}`;
  q.addWidget.run(id, user.id, url.slice(0, 512), String(note || '').slice(0, 200));
  res.redirect('/board');
});

app.get('/widgets/suggest', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.status(401).end();
  const term = String(req.query.q || '').toLowerCase();
  const hits = q.suggest.all(user.id, user.username, term);
  res.type('text/plain').send(hits.map((w) => w.id).join('\n'));
});

app.post('/widgets/:id/share', (req, res) => {
  const user = currentUser(req);
  if (!user) return res.redirect('/signin');
  const widget = q.getWidget.get(req.params.id);
  if (!widget || widget.owner_id !== user.id) {
    return res.status(404).render('board', boardView(user, 'No such widget on your board.'));
  }
  const targetName = String((req.body || {}).username || '').trim();
  if (targetName === ADMIN_USER) {
    return res.status(403).render('board', boardView(user, 'You cannot share with the admin.'));
  }
  const target = q.userByName.get(targetName);
  if (!target) {
    return res.status(404).render('board', boardView(user, 'No such user.'));
  }
  q.share.run(target.username, widget.id);
  res.redirect('/board');
});

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).send('server error');
});

app.listen(PORT, () => console.log(`WidgetBoard listening on http://127.0.0.1:${PORT}`));
