WidgetBoard
===========

Pin the pages you live in.

```bash
cp .env.example .env
docker compose up --build
```

the board            http://localhost:8080
the admin bot        http://localhost:8080/report

