# Lauschangriff

Corporate might be listening, but it is secured with TLS 1.3 and post-quantum cryptography. So it's all fine, right?

Your instance: `https://<random>.<domain>/` from the scoreboard (self-signed cert, expect the warning).
The monitoring dashboard is at `/monitoring`.

We do like to run a *lean* kernel, though. Ops shipped a small patch to `drivers/char/random.c`
last sprint. Nobody had time to review it.

## Files

- `src/kernel/`: the RNG patch your instance runs (`rng.h`, `random.c.patch`).
- `src/`: the rest of the box, meaning the SprintBoard server, the admin bot and the build scripts.
- `build/`: the prebuilt VM image (`bzImage`, `rootfs.img.zst`). Your instance boots the same one.
- `BUILD.md`: how to run it locally or rebuild it.
