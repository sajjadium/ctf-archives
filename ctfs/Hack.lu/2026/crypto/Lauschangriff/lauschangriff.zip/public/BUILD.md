# Running it locally

You need x86-64 Linux, Docker with Compose, and `openssl`. Run everything from this directory.

```sh
(umask 077; openssl rand -hex 32 > admin-pass)
export ADMIN_PASS_FILE="$PWD/admin-pass" FLAG='flag{local-test}'
docker compose -f src/deploy/docker/docker-compose.yml up -d --build
```

This unpacks `build/rootfs.img.zst` inside the container and boots it with `build/bzImage` in QEMU.
Without hardware acceleration, the boot takes a few minutes. After that, the bot files a ticket
containing `FLAG` every 45 seconds. The board is at <https://127.0.0.1:8443/>. Set `HTTPS_PORT`
if you need a different port.

```sh
curl -k --retry 90 --retry-delay 2 --retry-all-errors \
  -o capture.pcap https://127.0.0.1:8443/monitoring/capture.pcap
docker compose -f src/deploy/docker/docker-compose.yml down
```

To boot the VM without Docker via `src/deploy/run_vm.sh`, install `qemu-system-x86` and `zstd`.
It unpacks `build/rootfs.img.zst` to `build/rootfs.img` on first start. To unpack the image by
hand, run `zstd -d build/rootfs.img.zst`.

## Rebuilding the image

You don't need to. `build/` already holds the exact image the remote instance runs.

```sh
docker build --build-arg JOBS="$(nproc)" --output type=local,dest=build \
  -f src/deploy/docker/build/Dockerfile .
```

The build fetches Debian packages, Go 1.26.0 and Linux 6.18.58, applies `src/kernel/random.c.patch` and compiles the kernel. If the kernel download
fails, run the same command again and it picks up where it stopped.
