#!/bin/bash
# Assemble the ext4 guest image from a Debian rootfs. Run via docker/build/Dockerfile.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
OUT=${OUT:-$ROOT/build}
RD=${ROOTFS_DIR:?Set ROOTFS_DIR to a Debian systemd rootfs (see docker/build/Dockerfile)}
IMG="$OUT/rootfs.img"
SIZE=${SIZE:-1024} # MiB
U="$ROOT/src/deploy/units"
for cmd in go mkfs.ext4 truncate zstd; do
  command -v "$cmd" >/dev/null || { echo "Missing rootfs build dependency: $cmd (use docker/build/Dockerfile)" >&2; exit 1; }
done
mkdir -p "$OUT"
[ "$(id -u)" = 0 ] || { echo "ROOTFS_DIR image assembly requires root; use the default Docker build instead." >&2; exit 1; }
[ -x "$RD/usr/lib/systemd/systemd" ] || [ -x "$RD/lib/systemd/systemd" ] || { echo "ROOTFS_DIR must contain a Debian systemd rootfs." >&2; exit 1; }
install -d "$RD/opt/lauschangriff" "$RD/var/lib/lauschangriff"
(cd "$ROOT/src/server" && CGO_ENABLED=0 GOTOOLCHAIN=local go build -buildvcs=false -ldflags="-s -w" -o "$RD/opt/lauschangriff/server" .)
install -m0755 "$U/provision-cert.sh" "$RD/opt/lauschangriff/provision-cert.sh"
install -m0755 "$U/capture.sh" "$RD/opt/lauschangriff/capture.sh"
install -d "$RD/etc/systemd/system/multi-user.target.wants" "$RD/etc/systemd/network"
for u in cert server capture; do
  install -m0644 "$U/lauschangriff-$u.service" "$RD/etc/systemd/system/"
  ln -sf "../lauschangriff-$u.service" \
    "$RD/etc/systemd/system/multi-user.target.wants/lauschangriff-$u.service"
done
install -m0644 "$U/10-lan.network" "$RD/etc/systemd/network/"
ln -sf /usr/lib/systemd/system/systemd-networkd.service \
  "$RD/etc/systemd/system/multi-user.target.wants/systemd-networkd.service"
rm -f "$IMG"
truncate -s "${SIZE}M" "$IMG"
mkfs.ext4 -q -F -d "$RD" "$IMG"
zstd -19 -T0 -q -f --rm "$IMG" -o "$IMG.zst"
echo "rootfs -> $IMG.zst ($SIZE MiB uncompressed)"
