#!/bin/bash
# Boot the challenge VM. QEMU_ACCEL is passed to qemu -accel (default tcg).
# $OUT/rootfs.img.zst is unpacked to $IMG_DIR/rootfs.img (default $OUT) when that is missing or older.
set -euo pipefail
OUT=${OUT:-$(cd "$(dirname "$0")/../.." && pwd)/build}
HOSTPORT=${HOSTPORT:-8443}
CERT_DIR=${CERT_DIR:-}
QEMU_ACCEL=${QEMU_ACCEL:-tcg}
IMG=${IMG_DIR:-$OUT}/rootfs.img
: "${ADMIN_PASS_FILE:?Set ADMIN_PASS_FILE to a private single-line admin password file}"
command -v qemu-system-x86_64 >/dev/null || { echo "Install qemu-system-x86 (or use Docker Compose)." >&2; exit 1; }
if [ -e "$OUT/rootfs.img.zst" ] && { [ ! -s "$IMG" ] || [ "$OUT/rootfs.img.zst" -nt "$IMG" ]; }; then
  command -v zstd >/dev/null || { echo "Install zstd to unpack $OUT/rootfs.img.zst." >&2; exit 1; }
  zstd -d -q -f --sparse "$OUT/rootfs.img.zst" -o "$IMG.part"
  mv "$IMG.part" "$IMG"
fi
for file in "$OUT/bzImage" "$IMG" "$ADMIN_PASS_FILE"; do
  [ -r "$file" ] && [ -s "$file" ] || { echo "Missing or empty required file: $file" >&2; exit 1; }
done
# Restrict the secret alphabet so its guest EnvironmentFile needs no escaping.
password=$(cat "$ADMIN_PASS_FILE")
[[ "$password" =~ ^[A-Za-z0-9_-]{32,}$ ]] || { echo "Admin password must contain at least 32 letters/digits/_/- (generate with openssl rand -hex 32)." >&2; exit 1; }
unset password
args=(-accel "$QEMU_ACCEL" -cpu max -fw_cfg "name=opt/admin-pass,file=$ADMIN_PASS_FILE")
if [ -n "$CERT_DIR" ] && { [ -e "$CERT_DIR/cert.pem" ] || [ -e "$CERT_DIR/key.pem" ]; }; then
  [ -r "$CERT_DIR/cert.pem" ] && [ -r "$CERT_DIR/key.pem" ] || { echo "CERT_DIR must contain both cert.pem and key.pem." >&2; exit 1; }
  args+=(-fw_cfg "name=opt/cert,file=$CERT_DIR/cert.pem" -fw_cfg "name=opt/key,file=$CERT_DIR/key.pem")
fi
exec qemu-system-x86_64 "${args[@]}" -m 1024 -nographic -no-reboot \
  -kernel "$OUT/bzImage" \
  -drive "file=$IMG,if=virtio,format=raw" -snapshot \
  -append "console=ttyS0 root=/dev/vda rw random.trust_cpu=on vdso=0" \
  -netdev "user,id=n,hostfwd=tcp::$HOSTPORT-:443" -device virtio-net-pci,netdev=n
