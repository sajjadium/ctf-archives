#!/usr/bin/env python3
import base64, json, os, ssl, time, urllib.request as u

def env(k, d): return os.environ.get(k) or d

def admin_password():
    path = os.environ.get("ADMIN_PASS_FILE")
    if path:
        with open(path, encoding="utf-8") as secret:
            password = secret.read().removesuffix("\n")
    else:
        password = os.environ.get("ADMIN_PASS", "")
    if not password or "\n" in password or "\r" in password:
        raise SystemExit("provide a nonempty single-line ADMIN_PASS_FILE or ADMIN_PASS at runtime")
    return password

def ctx():
    c = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    c.minimum_version = ssl.TLSVersion.TLSv1_3
    return c

def file_ticket(base, flag, password):
    creds = f'{env("ADMIN_USER", "scrum-master")}:{password}'.encode()
    body = json.dumps({"Title": "Retro action item", "Body": "onboarding secret: " + flag}).encode()
    req = u.Request(base + "/api/tickets", body, {
        "Content-Type": "application/json",
        "Authorization": "Basic " + base64.b64encode(creds).decode(),
    })
    u.urlopen(req, context=ctx(), timeout=10).close()

if __name__ == "__main__":
    if ssl.OPENSSL_VERSION_INFO < (3, 5):
        raise SystemExit(f"bot needs OpenSSL >= 3.5, have {ssl.OPENSSL_VERSION}")
    base, flag = env("TARGET", "https://localhost:8443"), env("FLAG", "flag{placeholder}")
    password = admin_password()
    every = float(env("INTERVAL", "45"))
    while True:
        try:
            file_ticket(base, flag, password)
        except Exception as e:
            print("bot:", e)
        time.sleep(every)
