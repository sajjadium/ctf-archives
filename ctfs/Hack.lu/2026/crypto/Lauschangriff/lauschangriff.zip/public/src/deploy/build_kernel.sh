#!/bin/bash
# Fetch, patch and build the pinned x86-64 challenge kernel.
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/../.." && pwd)
OUT=${OUT:-$ROOT/build}
DOWNLOAD_CACHE=${DOWNLOAD_CACHE:-$OUT}
DOWNLOAD_RETRIES=${DOWNLOAD_RETRIES:-8}
VERSION=6.18.58
KERNEL_SHA256=069b19f9032c4dac8149ae4b6520c35debca0f42a9f6d52ee55ba6ca9b818013
SRC=${SRC:-$OUT/linux-$VERSION}
for cmd in curl tar xz sha256sum patch make gcc bc bison flex openssl; do
  command -v "$cmd" >/dev/null || { echo "Missing kernel build dependency: $cmd (use docker/build/Dockerfile)" >&2; exit 1; }
done
[[ "$DOWNLOAD_RETRIES" =~ ^[1-9][0-9]*$ ]] || { echo "DOWNLOAD_RETRIES must be a positive integer." >&2; exit 1; }
mkdir -p "$OUT" "$DOWNLOAD_CACHE"

verify_kernel_archive() {
  local path=$1
  [ -f "$path" ] && printf '%s  %s\n' "$KERNEL_SHA256" "$path" | sha256sum --check --status
}

download_kernel_archive() {
  local url=$1 dest=$2 part="$2.part" attempt
  if verify_kernel_archive "$dest"; then
    echo "Using cached, verified $(basename "$dest")"
    return
  fi
  rm -f "$dest"
  for ((attempt = 1; attempt <= DOWNLOAD_RETRIES; attempt++)); do
    echo "Downloading $(basename "$dest") (attempt $attempt/$DOWNLOAD_RETRIES; partial downloads resume)"
    if curl --fail --location --connect-timeout 20 --speed-limit 1024 --speed-time 60 \
        --continue-at - --output "$part" "$url"; then
      if verify_kernel_archive "$part"; then
        mv "$part" "$dest"
        return
      fi
      echo "Downloaded kernel archive failed SHA256 verification; restarting it." >&2
      rm -f "$part"
    elif verify_kernel_archive "$part"; then
      # A reset can arrive after the final byte. Accept only the pinned digest.
      mv "$part" "$dest"
      return
    fi
    if ((attempt < DOWNLOAD_RETRIES)); then
      sleep "$((attempt < 5 ? attempt * 2 : 10))"
    fi
  done
  echo "Could not download $url after $DOWNLOAD_RETRIES attempts. Re-run the same build to resume $part." >&2
  return 1
}

if [ ! -f "$SRC/Makefile" ]; then
  archive="linux-$VERSION.tar.xz"
  download_kernel_archive "https://cdn.kernel.org/pub/linux/kernel/v6.x/$archive" \
    "$DOWNLOAD_CACHE/$archive"
  mkdir -p "$SRC"
  tar -xJf "$DOWNLOAD_CACHE/$archive" --strip-components=1 -C "$SRC"
fi
cp "$ROOT/src/kernel/rng.h" "$SRC/drivers/char/rng.h"
grep -q lausch_get_random "$SRC/drivers/char/random.c" || \
  patch -p1 -d "$SRC" < "$ROOT/src/kernel/random.c.patch"
cd "$SRC"
make defconfig
scripts/config -e DEVTMPFS -e DEVTMPFS_MOUNT -e SERIAL_8250 -e SERIAL_8250_CONSOLE \
  -e TMPFS -e BINFMT_ELF -e NET -e INET -e UNIX -e PROC_FS -e SYSFS \
  -e VIRTIO -e VIRTIO_PCI -e VIRTIO_BLK -e VIRTIO_NET -e EXT4_FS \
  -e FW_CFG_SYSFS -d MODULES -d USB_SUPPORT -d SOUND -d DRM -d WLAN -d BT \
  -d WERROR -d VDSO_GETRANDOM
make olddefconfig
rm -f drivers/char/random.o drivers/char/.random.o.cmd
make -j"${JOBS:-$(nproc)}" bzImage
cp arch/x86/boot/bzImage "$OUT/bzImage"
echo "kernel -> $OUT/bzImage"
