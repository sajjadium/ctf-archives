Drop `cert.pem` and `key.pem` here to serve them instead of the image's built-in
self-signed cert (e.g. a real Let's Encrypt cert). They are handed to the guest via
qemu `fw_cfg` at boot. Leave this directory empty to use the built-in self-signed cert.

Keys placed here are git-ignored.
