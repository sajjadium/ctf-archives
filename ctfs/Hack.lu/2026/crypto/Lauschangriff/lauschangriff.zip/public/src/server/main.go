package main

import (
	"crypto/subtle"
	"crypto/tls"
	"embed"
	"encoding/json"
	"html/template"
	"log"
	"net/http"
	"os"
	"strconv"
	"sync"
	"time"
)

type Ticket struct {
	ID     int       `json:"id"`
	Owner  string    `json:"owner"`
	Title  string    `json:"title"`
	Body   string    `json:"body"`
	Status string    `json:"status"`
	At     time.Time `json:"at"`
}

var (
	mu      sync.Mutex
	tickets []Ticket
	nextID  = 1

	adminUser = env("ADMIN_USER", "scrum-master")
	adminPass = os.Getenv("ADMIN_PASS")
	pcapPath  = env("PCAP_PATH", "/var/lib/lauschangriff/capture.pcap")

	//go:embed web
	web   embed.FS
	pages = template.Must(template.New("").Funcs(template.FuncMap{
		"ago":  ago,
		"size": size,
	}).ParseFS(web, "web/*.html"))
)

func env(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func ago(t time.Time) string {
	if t.IsZero() {
		return "never"
	}
	return time.Since(t).Round(time.Second).String() + " ago"
}

func size(n int64) string {
	const unit = 1024
	if n < unit {
		return strconv.FormatInt(n, 10) + " B"
	}
	f, i := float64(n)/unit, 0
	for f >= unit && i < 2 {
		f /= unit
		i++
	}
	return strconv.FormatFloat(f, 'f', 1, 64) + " " + [...]string{"KiB", "MiB", "GiB"}[i]
}

// Every write carries the credentials itself: there are no sessions to steal.
func authorized(r *http.Request) bool {
	u, p, ok := r.BasicAuth()
	return ok &&
		subtle.ConstantTimeCompare([]byte(u), []byte(adminUser)) == 1 &&
		subtle.ConstantTimeCompare([]byte(p), []byte(adminPass)) == 1
}

func apiTickets(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		w.Header().Set("Allow", http.MethodPost)
		http.Error(w, "tickets are write-only, ask your Scrum Master", http.StatusMethodNotAllowed)
		return
	}
	if !authorized(r) {
		w.Header().Set("WWW-Authenticate", `Basic realm="SprintBoard"`)
		http.Error(w, "auth required", http.StatusUnauthorized)
		return
	}
	var in struct{ Title, Body string }
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 1<<16)).Decode(&in); err != nil {
		http.Error(w, "bad json", http.StatusBadRequest)
		return
	}
	mu.Lock()
	t := Ticket{ID: nextID, Owner: adminUser, Title: in.Title, Body: in.Body, Status: "todo", At: time.Now()}
	nextID++
	tickets = append(tickets, t)
	mu.Unlock()
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(t)
}

func render(w http.ResponseWriter, name string, data any) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := pages.ExecuteTemplate(w, name, data); err != nil {
		log.Printf("render %s: %v", name, err)
	}
}

// "/" and "/monitoring" (the URL in the handout README) show the same page.
func page(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" && r.URL.Path != "/monitoring" {
		http.NotFound(w, r)
		return
	}
	data := struct {
		Ready   bool
		Size    int64
		Updated time.Time
	}{}
	if fi, err := os.Stat(pcapPath); err == nil {
		data.Ready, data.Size, data.Updated = true, fi.Size(), fi.ModTime()
	}
	render(w, "index.html", data)
}

func capture(w http.ResponseWriter, r *http.Request) {
	f, err := os.Open(pcapPath)
	if err != nil {
		http.Error(w, "no capture yet", http.StatusNotFound)
		return
	}
	defer f.Close()
	w.Header().Set("Content-Type", "application/vnd.tcpdump.pcap")
	w.Header().Set("Content-Disposition", `attachment; filename="capture.pcap"`)
	http.ServeContent(w, r, "capture.pcap", time.Now(), f)
}

func main() {
	if adminPass == "" {
		log.Fatal("ADMIN_PASS must be provided at runtime")
	}
	mux := http.NewServeMux()
	mux.HandleFunc("/", page)
	mux.HandleFunc("/api/tickets", apiTickets)
	mux.HandleFunc("/monitoring/capture.pcap", capture)

	cert, err := tls.LoadX509KeyPair(env("TLS_CERT", "cert.pem"), env("TLS_KEY", "key.pem"))
	if err != nil {
		log.Fatal(err)
	}
	tc := &tls.Config{
		Certificates: []tls.Certificate{cert},
		MinVersion:   tls.VersionTLS13,
		CurvePreferences: []tls.CurveID{tls.X25519MLKEM768, tls.X25519},
	}
	srv := &http.Server{Addr: env("ADDR", ":8443"), Handler: mux, TLSConfig: tc}
	log.Printf("listening on %s", srv.Addr)
	log.Fatal(srv.ListenAndServeTLS("", ""))
}
