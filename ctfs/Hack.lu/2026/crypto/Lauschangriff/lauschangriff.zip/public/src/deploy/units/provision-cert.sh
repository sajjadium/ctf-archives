#!/bin/sh
# Provision private runtime credentials through QEMU fw_cfg
set -eu
d=/opt/lauschangriff
fw=/sys/firmware/qemu_fw_cfg/by_name/opt
umask 077
install -d -m0700 /run/lauschangriff
[ -r "$fw/admin-pass/raw" ] || { echo "Missing required opt/admin-pass fw_cfg secret" >&2; exit 1; }
password=$(cat "$fw/admin-pass/raw")
case "$password" in
  ''|*[!A-Za-z0-9_-]*) echo "Invalid admin password format" >&2; exit 1 ;;
esac
[ "${#password}" -ge 32 ] || { echo "Admin password must be at least 32 characters" >&2; exit 1; }
printf 'ADMIN_PASS=%s\n' "$password" > /run/lauschangriff/admin.env
unset password
if [ -r "$fw/cert/raw" ] && [ -r "$fw/key/raw" ]; then
  cat "$fw/cert/raw" > "$d/cert.pem"
  cat "$fw/key/raw" > "$d/key.pem"
else
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 3650 \
    -subj /CN=sprintboard -keyout "$d/key.pem" -out "$d/cert.pem" 2>/dev/null
fi
chmod 600 "$d/key.pem"
