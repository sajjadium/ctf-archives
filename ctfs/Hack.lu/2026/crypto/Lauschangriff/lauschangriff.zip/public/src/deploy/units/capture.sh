#!/bin/sh
# Wait for tcpdump's listening announcement before systemd starts the server.
set -eu
iface=$(ip -o link show | awk -F': ' '$2!="lo"{print $2; exit}')
[ -n "$iface" ] || { echo "No guest capture NIC found" >&2; exit 1; }
log=/run/lauschangriff-capture.log
LC_ALL=C /usr/bin/tcpdump -Z root -i "$iface" -U -w /var/lib/lauschangriff/capture.pcap tcp port 443 2>"$log" &
pid=$!
trap 'kill "$pid" 2>/dev/null || true' EXIT
trap 'exit 0' TERM INT
while ! grep -q 'listening on ' "$log"; do
  kill -0 "$pid" 2>/dev/null || { cat "$log" >&2; exit 1; }
  sleep 0.1
done
cat "$log" >&2
systemd-notify --ready
wait "$pid"
