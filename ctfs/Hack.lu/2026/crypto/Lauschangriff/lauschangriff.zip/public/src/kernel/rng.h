/* rng.h — SprintBoard lean-kernel RNG core. */
#ifndef RNG_H
#define RNG_H

#ifdef __KERNEL__
#include <linux/types.h>
#else
#include <stdint.h>
typedef uint8_t u8;
typedef uint32_t u32;
typedef uint64_t u64;
#endif

typedef unsigned __int128 rng_u128;

#define RNG_BITS 96
#define RNG_MASK ((((rng_u128)1) << RNG_BITS) - 1)

#define RNG_C ((((rng_u128)0x9E3779B97F4A7C15ULL) << 32) | 0xF39CC0DBULL)
#define RNG_K1 40
#define RNG_K2 23

static inline rng_u128 rng_rotl(rng_u128 x, unsigned r)
{
	return ((x << r) | (x >> (RNG_BITS - r))) & RNG_MASK;
}

static inline rng_u128 rng_step(rng_u128 x)
{
	x = (x + RNG_C) & RNG_MASK;
	x ^= rng_rotl(x, RNG_K1);
	x ^= rng_rotl(x, RNG_K2);
	return x & RNG_MASK;
}

static inline void rng_fill(rng_u128 *x, u8 *buf, unsigned long len)
{
	unsigned long i = 0;
	while (i < len) {
		u32 w;
		unsigned long n, j;
		*x = rng_step(*x);
		w = (u32)((*x >> 64) & 0xFFFFFFFFULL);   /* top 32 bits */
		n = len - i < 4 ? len - i : 4;
		for (j = 0; j < n; j++)
			buf[i + j] = (u8)(w >> (24 - 8 * j)); /* big-endian */
		i += 4;
	}
}

#endif /* RNG_H */
