import subprocess
import sys
import tempfile

MAX_PROGRAM_SIZE = 2 << 20

stdin = open(sys.stdin.fileno(), "rb", buffering=0)

print("V67L bytecode length: ", end="", flush=True)
length = int(stdin.readline())
if not 0 <= length <= MAX_PROGRAM_SIZE:
    raise ValueError(f"program must be at most {MAX_PROGRAM_SIZE} bytes")

blob = bytearray(length)
remaining = memoryview(blob)
while remaining:
    received = stdin.readinto(remaining)
    if not received:
        raise EOFError("connection closed before the complete program was received")
    remaining = remaining[received:]

with tempfile.NamedTemporaryFile(suffix=".v67l") as program:
    program.write(blob)
    program.flush()
    subprocess.run(["/v67l", program.name])
