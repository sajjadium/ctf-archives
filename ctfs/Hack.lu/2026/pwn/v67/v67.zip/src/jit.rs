#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
mod x64;

use std::ptr;
use std::sync::{Arc, Mutex};
use std::thread;

use crate::cfg::ControlFlowGraph;
use crate::{Function, Program};

const MAX_NATIVE_CODE: usize = 4 << 20;
const CODE_ALIGNMENT: usize = 16;

pub(crate) struct CodeSection {
    pointer: *mut u8,
    length: usize,
}

impl CodeSection {
    pub(crate) fn entry(&self) -> *mut u8 {
        debug_assert_ne!(self.length, 0);
        self.pointer
    }
}

pub(crate) struct RwxCodeArena {
    page_size: usize,
    pages: Mutex<Vec<CodePage>>,
}

struct CodePage {
    pointer: *mut u8,
    length: usize,
    used: usize,
}

unsafe impl Send for CodePage {}

impl RwxCodeArena {
    pub(crate) fn new() -> Result<Self, String> {
        #[cfg(all(target_arch = "x86_64", target_os = "linux"))]
        let page_size = {
            let result = unsafe { libc::sysconf(libc::_SC_PAGESIZE) };
            usize::try_from(result).map_err(|_| "cannot determine system page size".to_string())?
        };
        #[cfg(not(all(target_arch = "x86_64", target_os = "linux")))]
        let page_size = 4096;

        if !page_size.is_power_of_two() {
            return Err(format!("invalid system page size {page_size}"));
        }

        Ok(Self {
            page_size,
            pages: Mutex::new(Vec::new()),
        })
    }

    #[cfg(all(target_arch = "x86_64", target_os = "linux"))]
    pub(crate) fn allocate(&self, code: &[u8]) -> Result<CodeSection, String> {
        if code.is_empty() || code.len() > MAX_NATIVE_CODE {
            return Err(format!("invalid native code size {}", code.len()));
        }

        let mut pages = self.pages.lock().unwrap();
        let page_index = pages.iter().position(|page| page.can_fit(code.len()));
        let page_index = if let Some(page_index) = page_index {
            page_index
        } else {
            let length = align_up(code.len().max(self.page_size), self.page_size);
            pages.push(CodePage::allocate(length)?);
            pages.len() - 1
        };

        Ok(pages[page_index].write(code))
    }

    #[cfg(not(all(target_arch = "x86_64", target_os = "linux")))]
    pub(crate) fn allocate(&self, _code: &[u8]) -> Result<CodeSection, String> {
        Err("the native JIT is supported only on x86_64 Linux".into())
    }
}

impl CodePage {
    #[cfg(all(target_arch = "x86_64", target_os = "linux"))]
    fn allocate(length: usize) -> Result<Self, String> {
        let mapping = unsafe {
            libc::mmap(
                ptr::null_mut(),
                length,
                libc::PROT_READ | libc::PROT_WRITE | libc::PROT_EXEC,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            )
        };
        if mapping == libc::MAP_FAILED {
            return Err(format!("mmap failed: {}", std::io::Error::last_os_error()));
        }

        Ok(Self {
            pointer: mapping.cast(),
            length,
            used: 0,
        })
    }

    fn can_fit(&self, length: usize) -> bool {
        align_up(self.used, CODE_ALIGNMENT)
            .checked_add(length)
            .is_some_and(|end| end <= self.length)
    }

    fn write(&mut self, code: &[u8]) -> CodeSection {
        debug_assert!(self.can_fit(code.len()));
        let offset = align_up(self.used, CODE_ALIGNMENT);
        let destination = unsafe { self.pointer.add(offset) };
        unsafe { ptr::copy_nonoverlapping(code.as_ptr(), destination, code.len()) };
        self.used = offset + code.len();
        CodeSection {
            pointer: destination,
            length: code.len(),
        }
    }
}

impl Drop for CodePage {
    fn drop(&mut self) {
        #[cfg(target_os = "linux")]
        unsafe {
            libc::munmap(self.pointer.cast(), self.length);
        }
    }
}

fn align_up(value: usize, alignment: usize) -> usize {
    (value + alignment - 1) & !(alignment - 1)
}

pub(crate) fn record_interpreted_invocation(program: &Arc<Program>, function_id: usize) {
    let function = program
        .function(function_id)
        .expect("executing function must exist");
    if !function.record_interpreted_invocation(program.jit_threshold()) {
        return;
    }

    let compiler_program = Arc::clone(program);
    let handle = thread::spawn(move || compile_function(compiler_program, function_id));
    program.track_compiler(handle);
}

fn compile_function(program: Arc<Program>, function_id: usize) {
    let function = program
        .function(function_id)
        .expect("queued JIT function must exist");
    function.begin_compilation();
    let Ok(executable) = compile_native(&program, function_id, function) else {
        function.reject_compilation();
        return;
    };
    function.install_compiled_code(executable);
}

fn compile_native(
    program: &Program,
    function_id: usize,
    function: &Function,
) -> Result<CodeSection, String> {
    let graph = ControlFlowGraph::for_function(function_id, function)?;
    let native_code = generate_native(function, &graph)?;
    program.allocate_jit_code(&native_code)
}

#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
fn generate_native(function: &Function, graph: &ControlFlowGraph) -> Result<Vec<u8>, String> {
    x64::compile(function, graph, MAX_NATIVE_CODE)
}

#[cfg(not(all(target_arch = "x86_64", target_os = "linux")))]
fn generate_native(_function: &Function, _graph: &ControlFlowGraph) -> Result<Vec<u8>, String> {
    Err("the native JIT is supported only on x86_64 Linux".into())
}
