use std::collections::HashSet;

pub const MAGIC: &[u8; 4] = b"V67L";
pub const VERSION: u8 = 1;
pub const MAX_FUNCTIONS: usize = 4096;
pub const MAX_CODE_LEN: usize = 1 << 20;
pub const MAX_REGISTERS: usize = 64;

pub const OP_CONST: u8 = 0x01;
pub const OP_MOV: u8 = 0x02;
pub const OP_ADD: u8 = 0x03;
pub const OP_SUB: u8 = 0x04;
pub const OP_MUL: u8 = 0x05;
pub const OP_DIV: u8 = 0x06;
pub const OP_EQ: u8 = 0x07;
pub const OP_LT: u8 = 0x08;
pub const OP_JMP: u8 = 0x09;
pub const OP_JZ: u8 = 0x0a;
pub const OP_CALL: u8 = 0x0b;
pub const OP_RET: u8 = 0x0c;
pub const OP_PRINT: u8 = 0x0d;
pub const OP_LOAD: u8 = 0x0e;
pub const OP_STORE: u8 = 0x0f;

#[derive(Clone, Debug)]
pub struct ParsedFunction {
    pub arity: u8,
    pub registers: u8,
    pub instructions: Vec<Decoded>,
}

impl ParsedFunction {
    fn code_length(&self) -> usize {
        self.instructions.last().unwrap().end
    }
}

#[derive(Clone, Debug)]
pub struct ParsedProgram {
    pub entry: usize,
    pub functions: Vec<ParsedFunction>,
}

#[derive(Clone, Debug, PartialEq)]
pub enum Instruction {
    Const(u8, i64),
    Mov(u8, u8),
    Add(u8, u8, u8),
    Sub(u8, u8, u8),
    Mul(u8, u8, u8),
    Div(u8, u8, u8),
    Eq(u8, u8, u8),
    Lt(u8, u8, u8),
    Jmp(i32),
    Jz(u8, i32),
    Call {
        function: u16,
        dst: u8,
        args: Vec<u8>,
    },
    Ret(u8),
    Print(u8),
    Load(u8, u8),
    Store(u8, u8),
}

#[derive(Clone, Debug)]
pub struct Decoded {
    pub start: usize,
    pub end: usize,
    pub instruction: Instruction,
}

pub fn parse(bytes: &[u8]) -> Result<ParsedProgram, String> {
    let mut cursor = Cursor::new(bytes);
    if cursor.take(4)? != MAGIC {
        return Err("bad magic (expected V67L)".into());
    }
    let version = cursor.u8()?;
    if version != VERSION {
        return Err(format!("unsupported bytecode version {version}"));
    }
    let function_count = cursor.u16()? as usize;
    let entry = cursor.u16()? as usize;
    if function_count == 0 || function_count > MAX_FUNCTIONS {
        return Err(format!("invalid function count {function_count}"));
    }
    if entry >= function_count {
        return Err(format!("entry function {entry} is out of range"));
    }

    let mut functions = Vec::with_capacity(function_count);
    for index in 0..function_count {
        let arity = cursor.u8()?;
        let registers = cursor.u8()?;
        let code_len = cursor.u32()? as usize;
        if registers as usize > MAX_REGISTERS || arity > registers {
            return Err(format!("function {index} has invalid register metadata"));
        }
        if code_len == 0 || code_len > MAX_CODE_LEN {
            return Err(format!(
                "function {index} has invalid code length {code_len}"
            ));
        }
        let code = cursor.take(code_len)?;
        let instructions =
            decode_all(code, registers).map_err(|error| format!("function {index}: {error}"))?;
        functions.push(ParsedFunction {
            arity,
            registers,
            instructions,
        });
    }
    if !cursor.is_empty() {
        return Err("trailing data after final function".into());
    }

    if functions[entry].arity != 0 {
        return Err("entry function must take zero arguments".into());
    }

    let program = ParsedProgram { entry, functions };
    ProgramValidator::new(&program).validate()?;
    Ok(program)
}

struct ProgramValidator<'a> {
    program: &'a ParsedProgram,
}

impl<'a> ProgramValidator<'a> {
    fn new(program: &'a ParsedProgram) -> Self {
        Self { program }
    }

    fn validate(&self) -> Result<(), String> {
        for (function_id, function) in self.program.functions.iter().enumerate() {
            self.validate_function(function_id, function)?;
        }
        Ok(())
    }

    fn validate_function(
        &self,
        function_id: usize,
        function: &ParsedFunction,
    ) -> Result<(), String> {
        let instruction_starts: HashSet<usize> = function
            .instructions
            .iter()
            .map(|instruction| instruction.start)
            .collect();

        for decoded in &function.instructions {
            match &decoded.instruction {
                Instruction::Call { function, args, .. } => {
                    self.validate_call(function_id, decoded.start, *function, args.len())?
                }
                Instruction::Jmp(relative) | Instruction::Jz(_, relative) => {
                    let target = relative_target(decoded.end, *relative, function.code_length())
                        .map_err(|error| format!("function {function_id}: {error}"))?;
                    if !instruction_starts.contains(&target) {
                        return Err(format!(
                            "function {function_id}: jump at {} lands in the middle of an instruction",
                            decoded.start
                        ));
                    }
                }
                _ => {}
            }
        }

        self.validate_function_end(function_id, function.instructions.last().unwrap())
    }

    fn validate_call(
        &self,
        caller_id: usize,
        bytecode_offset: usize,
        callee_id: u16,
        argument_count: usize,
    ) -> Result<(), String> {
        let callee = self
            .program
            .functions
            .get(callee_id as usize)
            .ok_or_else(|| {
                format!(
                    "function {caller_id}: call at {bytecode_offset} targets missing function {callee_id}"
                )
            })?;
        if argument_count != callee.arity as usize {
            return Err(format!(
                "function {caller_id}: call at {bytecode_offset} passes {argument_count} arguments to function {callee_id}, expected {}",
                callee.arity
            ));
        }
        Ok(())
    }

    fn validate_function_end(&self, function_id: usize, last: &Decoded) -> Result<(), String> {
        match last.instruction {
            Instruction::Ret(_) | Instruction::Jmp(_) => Ok(()),
            Instruction::Jz(_, _) => Err(format!(
                "function {function_id}: conditional jump at {} can fall off the function",
                last.start
            )),
            _ => Err(format!(
                "function {function_id}: execution can fall off the end after byte {}",
                last.start
            )),
        }
    }
}

fn decode_all(code: &[u8], registers: u8) -> Result<Vec<Decoded>, String> {
    let mut result = Vec::new();
    let mut pc = 0;
    while pc < code.len() {
        let decoded = decode_one(code, pc, registers)?;
        pc = decoded.end;
        result.push(decoded);
    }
    Ok(result)
}

pub fn relative_target(end: usize, relative: i32, code_len: usize) -> Result<usize, String> {
    let target = (end as i64)
        .checked_add(relative as i64)
        .ok_or_else(|| "jump target overflow".to_string())?;
    if target < 0 || target >= code_len as i64 {
        return Err(format!("jump target {target} is outside the function"));
    }
    Ok(target as usize)
}

fn decode_one(code: &[u8], start: usize, registers: u8) -> Result<Decoded, String> {
    let mut cursor = Cursor::at(code, start);
    let opcode = cursor.u8()?;
    let instruction = match opcode {
        OP_CONST => Instruction::Const(reg(&mut cursor, registers)?, cursor.i64()?),
        OP_MOV => Instruction::Mov(reg(&mut cursor, registers)?, reg(&mut cursor, registers)?),
        OP_ADD => tri(&mut cursor, registers, Instruction::Add)?,
        OP_SUB => tri(&mut cursor, registers, Instruction::Sub)?,
        OP_MUL => tri(&mut cursor, registers, Instruction::Mul)?,
        OP_DIV => tri(&mut cursor, registers, Instruction::Div)?,
        OP_EQ => tri(&mut cursor, registers, Instruction::Eq)?,
        OP_LT => tri(&mut cursor, registers, Instruction::Lt)?,
        OP_JMP => Instruction::Jmp(cursor.i32()?),
        OP_JZ => Instruction::Jz(reg(&mut cursor, registers)?, cursor.i32()?),
        OP_CALL => {
            let function = cursor.u16()?;
            let dst = reg(&mut cursor, registers)?;
            let count = cursor.u8()? as usize;
            let mut args = Vec::with_capacity(count);
            for _ in 0..count {
                args.push(reg(&mut cursor, registers)?);
            }
            Instruction::Call {
                function,
                dst,
                args,
            }
        }
        OP_RET => Instruction::Ret(reg(&mut cursor, registers)?),
        OP_PRINT => Instruction::Print(reg(&mut cursor, registers)?),
        OP_LOAD => Instruction::Load(reg(&mut cursor, registers)?, reg(&mut cursor, registers)?),
        OP_STORE => Instruction::Store(reg(&mut cursor, registers)?, reg(&mut cursor, registers)?),
        _ => return Err(format!("unknown opcode {opcode:#04x} at byte {start}")),
    };
    Ok(Decoded {
        start,
        end: cursor.position(),
        instruction,
    })
}

fn tri(
    cursor: &mut Cursor<'_>,
    registers: u8,
    constructor: fn(u8, u8, u8) -> Instruction,
) -> Result<Instruction, String> {
    Ok(constructor(
        reg(cursor, registers)?,
        reg(cursor, registers)?,
        reg(cursor, registers)?,
    ))
}

fn reg(cursor: &mut Cursor<'_>, registers: u8) -> Result<u8, String> {
    let register = cursor.u8()?;
    if register >= registers {
        return Err(format!(
            "register r{register} is out of range (function has {registers})"
        ));
    }
    Ok(register)
}

struct Cursor<'a> {
    bytes: &'a [u8],
    position: usize,
}

impl<'a> Cursor<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self::at(bytes, 0)
    }

    fn at(bytes: &'a [u8], position: usize) -> Self {
        Self { bytes, position }
    }

    fn position(&self) -> usize {
        self.position
    }

    fn is_empty(&self) -> bool {
        self.position == self.bytes.len()
    }

    fn take(&mut self, length: usize) -> Result<&'a [u8], String> {
        let start = self.position;
        let end = self
            .position
            .checked_add(length)
            .ok_or("bytecode offset overflow")?;
        let result = self
            .bytes
            .get(self.position..end)
            .ok_or_else(|| format!("truncated bytecode at byte {start}"))?;
        self.position = end;
        Ok(result)
    }

    fn u8(&mut self) -> Result<u8, String> {
        Ok(self.take(1)?[0])
    }

    fn u16(&mut self) -> Result<u16, String> {
        Ok(u16::from_le_bytes(self.take(2)?.try_into().unwrap()))
    }

    fn u32(&mut self) -> Result<u32, String> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }

    fn i32(&mut self) -> Result<i32, String> {
        Ok(i32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }

    fn i64(&mut self) -> Result<i64, String> {
        Ok(i64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
}
