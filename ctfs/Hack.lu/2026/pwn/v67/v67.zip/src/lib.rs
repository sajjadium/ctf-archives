//! V67L is a small register VM with asynchronous hot-function JIT compilation.

mod bytecode;
mod cfg;
mod jit;
mod vm;

use std::cell::UnsafeCell;
use std::fs;
use std::path::Path;
use std::ptr;
use std::sync::atomic::{AtomicU8, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::JoinHandle;

use bytecode::ParsedProgram;

pub use bytecode::{MAGIC, VERSION};

#[derive(Clone, Debug)]
pub struct Config {
    pub jit_threshold: u64,
    pub heap_words: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            jit_threshold: 256,
            heap_words: 1024,
        }
    }
}

const JIT_COLD: u8 = 0;
const JIT_QUEUED: u8 = 1;
const JIT_EMITTING: u8 = 2;
const JIT_READY: u8 = 3;
const JIT_REJECTED: u8 = 4;

#[repr(C)]
pub(crate) struct Function {
    jit_entry: UnsafeCell<*mut u8>,
    fuel: AtomicU64,
    arity: u8,
    registers: u8,
    instruction_count: u64,
    instructions: Vec<bytecode::Decoded>,
    jit_state: AtomicU8,
}

unsafe impl Send for Function {}
unsafe impl Sync for Function {}

impl Function {
    fn from_parsed(function: bytecode::ParsedFunction) -> Self {
        let instruction_count = function.instructions.len() as u64;
        Self {
            fuel: AtomicU64::new(0),
            arity: function.arity,
            registers: function.registers,
            instruction_count,
            instructions: function.instructions,
            jit_state: AtomicU8::new(JIT_COLD),
            jit_entry: UnsafeCell::new(ptr::null_mut()),
        }
    }

    pub(crate) fn arity(&self) -> usize {
        self.arity as usize
    }

    pub(crate) fn register_count(&self) -> u8 {
        self.registers
    }

    pub(crate) fn instructions(&self) -> &[bytecode::Decoded] {
        &self.instructions
    }

    pub(crate) fn code_length(&self) -> usize {
        self.instructions.last().unwrap().end
    }

    pub(crate) fn instruction_index(&self, bytecode_offset: usize) -> usize {
        self.instructions
            .binary_search_by_key(&bytecode_offset, |instruction| instruction.start)
            .expect("validated jump target must exist")
    }

    pub(crate) fn charge_fuel(&self) -> u64 {
        let amount = self.instruction_count;
        let previous = self
            .fuel
            .fetch_update(Ordering::Relaxed, Ordering::Relaxed, |fuel| {
                Some(fuel.saturating_add(amount))
            })
            .expect("fuel update cannot fail");
        previous.saturating_add(amount)
    }

    pub(crate) fn record_interpreted_invocation(&self, threshold: u64) -> bool {
        let fuel = self.charge_fuel();
        if threshold == 0 || self.jit_state.load(Ordering::Acquire) != JIT_COLD {
            return false;
        }
        fuel >= threshold
            && self
                .jit_state
                .compare_exchange(JIT_COLD, JIT_QUEUED, Ordering::AcqRel, Ordering::Acquire)
                .is_ok()
    }

    pub(crate) fn begin_compilation(&self) {
        self.jit_state.store(JIT_EMITTING, Ordering::Release);
    }

    pub(crate) fn reject_compilation(&self) {
        self.jit_state.store(JIT_REJECTED, Ordering::Release);
    }

    pub(crate) fn install_compiled_code(&self, executable: jit::CodeSection) {
        let entry = executable.entry();
        assert!(!entry.is_null(), "compiled code has a null entry");
        unsafe { *self.jit_entry.get() = entry };
        self.jit_state.store(JIT_READY, Ordering::Release);
    }

    pub(crate) fn native_entry(&self) -> Option<*mut u8> {
        if self.jit_state.load(Ordering::Acquire) != JIT_READY {
            return None;
        }
        let entry = unsafe { *self.jit_entry.get() };
        debug_assert!(!entry.is_null());
        Some(entry)
    }
}

pub(crate) struct Program {
    functions: Vec<Function>,
    entry: usize,
    config: Config,
    code_arena: jit::RwxCodeArena,
    compiler_threads: Mutex<Vec<JoinHandle<()>>>,
}

impl Program {
    fn from_parsed(parsed: ParsedProgram, config: Config) -> Result<Arc<Self>, String> {
        if config.heap_words == 0 || config.heap_words > 1 << 24 {
            return Err("heap-words must be between 1 and 16777216".into());
        }
        let functions = parsed
            .functions
            .into_iter()
            .map(Function::from_parsed)
            .collect();

        Ok(Arc::new(Self {
            functions,
            entry: parsed.entry,
            config,
            code_arena: jit::RwxCodeArena::new()?,
            compiler_threads: Mutex::new(Vec::new()),
        }))
    }

    pub(crate) fn function(&self, function_id: usize) -> Option<&Function> {
        self.functions.get(function_id)
    }

    pub(crate) fn entry(&self) -> usize {
        self.entry
    }

    pub(crate) fn jit_threshold(&self) -> u64 {
        self.config.jit_threshold
    }

    pub(crate) fn heap_words(&self) -> usize {
        self.config.heap_words
    }

    pub(crate) fn allocate_jit_code(&self, code: &[u8]) -> Result<jit::CodeSection, String> {
        self.code_arena.allocate(code)
    }

    pub(crate) fn track_compiler(&self, handle: JoinHandle<()>) {
        self.compiler_threads.lock().unwrap().push(handle);
    }

    fn join_compilers(&self) {
        loop {
            let handle = self.compiler_threads.lock().unwrap().pop();
            let Some(handle) = handle else { break };
            let _ = handle.join();
        }
    }
}

pub fn run_file(path: impl AsRef<Path>, config: Config) -> Result<i64, String> {
    let bytes = fs::read(path.as_ref())
        .map_err(|error| format!("cannot read {}: {error}", path.as_ref().display()))?;
    run_bytes(&bytes, config)
}

pub fn run_bytes(bytes: &[u8], config: Config) -> Result<i64, String> {
    let parsed = bytecode::parse(bytes)?;
    let program = Program::from_parsed(parsed, config)?;
    let result = vm::run_entry(Arc::clone(&program));
    program.join_compilers();
    result
}
