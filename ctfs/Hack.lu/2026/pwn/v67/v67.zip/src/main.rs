use std::path::PathBuf;
use std::process::ExitCode;

use clap::Parser;
use v67l::{Config, run_file};

#[derive(Debug, Parser)]
#[command(
    version,
    about = "V67L bytecode VM with asynchronous hot-function JIT compilation"
)]
struct Args {
    /// V67L bytecode file to execute.
    binary: PathBuf,

    /// Per-function fuel that makes a function hot (0 disables the JIT).
    #[arg(long, default_value_t = 256)]
    jit_threshold: u64,

    /// Number of shared i64 heap words.
    #[arg(long, default_value_t = 1024)]
    heap_words: usize,
}

fn main() -> ExitCode {
    let args = Args::parse();
    let config = Config {
        jit_threshold: args.jit_threshold,
        heap_words: args.heap_words,
    };

    match run_file(&args.binary, config) {
        Ok(value) => {
            eprintln!("[v67l] program returned {value}");
            ExitCode::SUCCESS
        }
        Err(error) => {
            eprintln!("v67l: {error}");
            ExitCode::FAILURE
        }
    }
}
