use std::cell::UnsafeCell;
use std::sync::Arc;

use crate::bytecode::MAX_REGISTERS;
use crate::bytecode::{self, Instruction};
use crate::{Program, jit};

#[repr(C)]
pub(crate) struct Runtime {
    program: Arc<Program>,
    heap: UnsafeCell<Vec<i64>>,
}

pub(crate) fn run_entry(program: Arc<Program>) -> Result<i64, String> {
    let entry = program.entry();
    let heap_words = program.heap_words();
    let runtime = Runtime {
        program,
        heap: UnsafeCell::new(vec![0; heap_words]),
    };
    invoke(&runtime, entry, &[])
}

fn invoke(runtime: &Runtime, function_id: usize, arguments: &[i64]) -> Result<i64, String> {
    let function = runtime
        .program
        .function(function_id)
        .ok_or_else(|| format!("function {function_id} does not exist"))?;
    if arguments.len() != function.arity() {
        return Err(format!("function {function_id} called with wrong arity"));
    }

    let mut register_storage = [0_i64; MAX_REGISTERS];
    let registers = &mut register_storage[..function.register_count() as usize];
    registers[..arguments.len()].copy_from_slice(arguments);

    if let Some(entry) = function.native_entry() {
        let compiled: unsafe extern "C" fn(
            registers: *mut i64,
            heap: *mut i64,
            heap_len: usize,
            runtime: *const Runtime,
        ) -> i64 = unsafe { std::mem::transmute(entry) };
        let heap_len = unsafe { (*runtime.heap.get()).len() };
        let heap_pointer = unsafe { (*runtime.heap.get()).as_mut_ptr() };
        return Ok(unsafe { compiled(registers.as_mut_ptr(), heap_pointer, heap_len, runtime) });
    }

    jit::record_interpreted_invocation(&runtime.program, function_id);
    interpret(runtime, function_id, registers)
}

fn interpret(runtime: &Runtime, function_id: usize, registers: &mut [i64]) -> Result<i64, String> {
    let function = runtime
        .program
        .function(function_id)
        .expect("validated function must exist");
    let mut instruction_index = 0;
    loop {
        let decoded = &function.instructions()[instruction_index];
        instruction_index += 1;
        match &decoded.instruction {
            Instruction::Const(dst, value) => registers[*dst as usize] = *value,
            Instruction::Mov(dst, src) => registers[*dst as usize] = registers[*src as usize],
            Instruction::Add(dst, a, b) => {
                registers[*dst as usize] =
                    registers[*a as usize].wrapping_add(registers[*b as usize])
            }
            Instruction::Sub(dst, a, b) => {
                registers[*dst as usize] =
                    registers[*a as usize].wrapping_sub(registers[*b as usize])
            }
            Instruction::Mul(dst, a, b) => {
                registers[*dst as usize] =
                    registers[*a as usize].wrapping_mul(registers[*b as usize])
            }
            Instruction::Div(dst, a, b) => {
                let divisor = registers[*b as usize];
                registers[*dst as usize] = registers[*a as usize]
                    .checked_div(divisor)
                    .ok_or_else(|| format!("function {function_id}: invalid division"))?;
            }
            Instruction::Eq(dst, a, b) => {
                registers[*dst as usize] =
                    i64::from(registers[*a as usize] == registers[*b as usize])
            }
            Instruction::Lt(dst, a, b) => {
                registers[*dst as usize] =
                    i64::from(registers[*a as usize] < registers[*b as usize])
            }
            Instruction::Jmp(relative) => {
                let target =
                    bytecode::relative_target(decoded.end, *relative, function.code_length())?;
                instruction_index = function.instruction_index(target);
            }
            Instruction::Jz(condition, relative) => {
                if registers[*condition as usize] == 0 {
                    let target =
                        bytecode::relative_target(decoded.end, *relative, function.code_length())?;
                    instruction_index = function.instruction_index(target);
                }
            }
            Instruction::Call {
                function: target,
                dst,
                args,
            } => {
                let mut values = [0_i64; MAX_REGISTERS];
                for (index, register) in args.iter().enumerate() {
                    values[index] = registers[*register as usize];
                }
                registers[*dst as usize] =
                    invoke(runtime, *target as usize, &values[..args.len()])?;
            }
            Instruction::Ret(source) => return Ok(registers[*source as usize]),
            Instruction::Print(source) => println!("{}", registers[*source as usize]),
            Instruction::Load(dst, address) => {
                let heap = unsafe { &*runtime.heap.get() };
                let index = heap_index(registers[*address as usize], heap.len())?;
                registers[*dst as usize] = heap[index];
            }
            Instruction::Store(address, source) => {
                let heap = unsafe { &mut *runtime.heap.get() };
                let index = heap_index(registers[*address as usize], heap.len())?;
                heap[index] = registers[*source as usize];
            }
        }
    }
}

pub(crate) unsafe extern "C" fn jit_call(
    runtime: *const Runtime,
    function_id: usize,
    arguments: *const i64,
    argument_count: usize,
) -> i64 {
    let runtime = unsafe { &*runtime };
    let arguments = unsafe { std::slice::from_raw_parts(arguments, argument_count) };
    match invoke(runtime, function_id, arguments) {
        Ok(value) => value,
        Err(_) => jit_exit(),
    }
}

pub(crate) extern "C" fn jit_exit() -> ! {
    unsafe { libc::exit(1) }
}

pub(crate) extern "C" fn jit_print(value: i64) {
    println!("{value}");
}

fn heap_index(value: i64, length: usize) -> Result<usize, String> {
    let index = usize::try_from(value).map_err(|_| format!("negative heap address {value}"))?;
    if index >= length {
        return Err(format!("heap address {index} is out of bounds"));
    }
    Ok(index)
}
