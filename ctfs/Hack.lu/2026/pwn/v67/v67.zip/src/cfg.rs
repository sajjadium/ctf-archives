use std::collections::{BTreeSet, HashMap};

use crate::Function;
use crate::bytecode::{self, Decoded, Instruction};

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq)]
pub(crate) struct BlockId(pub(crate) usize);

#[derive(Clone, Debug)]
pub(crate) struct Operation {
    pub(crate) bytecode_offset: usize,
    pub(crate) instruction: Instruction,
}

#[derive(Clone, Debug)]
pub(crate) enum Terminator {
    Return {
        source: u8,
    },
    Jump {
        target: BlockId,
    },
    BranchZero {
        condition: u8,
        zero: BlockId,
        nonzero: BlockId,
    },
}

#[derive(Clone, Debug)]
pub(crate) struct BasicBlock {
    pub(crate) id: BlockId,
    pub(crate) bytecode_offset: usize,
    pub(crate) operations: Vec<Operation>,
    pub(crate) terminator: Terminator,
}

#[derive(Clone, Debug)]
pub(crate) struct ControlFlowGraph {
    pub(crate) entry: BlockId,
    pub(crate) blocks: Vec<BasicBlock>,
}

impl ControlFlowGraph {
    pub(crate) fn for_function(function_id: usize, function: &Function) -> Result<Self, String> {
        CfgBuilder::new(function_id, function).build()
    }
}

struct CfgBuilder<'a> {
    function_id: usize,
    code_length: usize,
    instructions: &'a [Decoded],
    instruction_indices: HashMap<usize, usize>,
}

impl<'a> CfgBuilder<'a> {
    fn new(function_id: usize, function: &'a Function) -> Self {
        let instructions = function.instructions();
        let instruction_indices = instructions
            .iter()
            .enumerate()
            .map(|(index, instruction)| (instruction.start, index))
            .collect();
        Self {
            function_id,
            code_length: function.code_length(),
            instructions,
            instruction_indices,
        }
    }

    fn build(self) -> Result<ControlFlowGraph, String> {
        let leaders = self.find_block_leaders()?;
        let leader_offsets: Vec<usize> = leaders.into_iter().collect();
        let block_ids: HashMap<usize, BlockId> = leader_offsets
            .iter()
            .enumerate()
            .map(|(id, offset)| (*offset, BlockId(id)))
            .collect();

        let mut blocks = Vec::with_capacity(leader_offsets.len());
        for (block_index, start) in leader_offsets.iter().copied().enumerate() {
            let first_instruction = self.instruction_indices[&start];
            let instruction_end = leader_offsets
                .get(block_index + 1)
                .map(|next| self.instruction_indices[next])
                .unwrap_or(self.instructions.len());
            let next_block = leader_offsets.get(block_index + 1).copied();
            let (operations, terminator) = build_block(
                self.function_id,
                self.code_length,
                &self.instructions[first_instruction..instruction_end],
                next_block,
                &block_ids,
            )?;
            blocks.push(BasicBlock {
                id: BlockId(block_index),
                bytecode_offset: start,
                operations,
                terminator,
            });
        }

        Ok(ControlFlowGraph {
            entry: block_ids[&0],
            blocks,
        })
    }

    fn find_block_leaders(&self) -> Result<BTreeSet<usize>, String> {
        let mut leaders = BTreeSet::from([0]);
        for (index, decoded) in self.instructions.iter().enumerate() {
            if let Instruction::Jmp(relative) | Instruction::Jz(_, relative) = decoded.instruction {
                let target = bytecode::relative_target(decoded.end, relative, self.code_length)
                    .map_err(|error| format!("function {}: {error}", self.function_id))?;
                if !self.instruction_indices.contains_key(&target) {
                    return Err(format!(
                        "function {}: jump at {} lands in the middle of an instruction",
                        self.function_id, decoded.start
                    ));
                }
                leaders.insert(target);
            }

            if is_explicit_terminator(&decoded.instruction)
                && let Some(next) = self.instructions.get(index + 1)
            {
                leaders.insert(next.start);
            }
        }
        Ok(leaders)
    }
}

fn build_block(
    function_id: usize,
    code_length: usize,
    instructions: &[Decoded],
    next_block: Option<usize>,
    block_ids: &HashMap<usize, BlockId>,
) -> Result<(Vec<Operation>, Terminator), String> {
    let (last, prefix) = instructions
        .split_last()
        .ok_or_else(|| format!("function {function_id}: empty basic block"))?;
    let mut operations: Vec<Operation> = prefix.iter().map(to_operation).collect();
    let resolve = |target: usize| {
        block_ids
            .get(&target)
            .copied()
            .ok_or_else(|| format!("CFG target {target} is not a basic-block leader"))
    };

    let terminator = match &last.instruction {
        Instruction::Ret(source) => Terminator::Return { source: *source },
        Instruction::Jmp(relative) => Terminator::Jump {
            target: resolve(
                bytecode::relative_target(last.end, *relative, code_length)
                    .map_err(|error| format!("function {function_id}: {error}"))?,
            )?,
        },
        Instruction::Jz(condition, relative) => {
            let nonzero = next_block.ok_or_else(|| {
                format!(
                    "function {function_id}: conditional jump at {} can fall off the function",
                    last.start
                )
            })?;
            Terminator::BranchZero {
                condition: *condition,
                zero: resolve(
                    bytecode::relative_target(last.end, *relative, code_length)
                        .map_err(|error| format!("function {function_id}: {error}"))?,
                )?,
                nonzero: resolve(nonzero)?,
            }
        }
        _ => {
            operations.push(to_operation(last));
            let target = next_block.ok_or_else(|| {
                format!(
                    "function {function_id}: execution can fall off the end after byte {}",
                    last.start
                )
            })?;
            Terminator::Jump {
                target: resolve(target)?,
            }
        }
    };
    Ok((operations, terminator))
}

fn to_operation(decoded: &Decoded) -> Operation {
    Operation {
        bytecode_offset: decoded.start,
        instruction: decoded.instruction.clone(),
    }
}

fn is_explicit_terminator(instruction: &Instruction) -> bool {
    matches!(
        instruction,
        Instruction::Jmp(_) | Instruction::Jz(_, _) | Instruction::Ret(_)
    )
}
