mod assembler;

use std::collections::HashMap;

use assembler::{Assembler, BinaryOperation, Comparison, Condition};

use crate::Function;
use crate::bytecode::Instruction;
use crate::cfg::{BasicBlock, BlockId, ControlFlowGraph, Operation, Terminator};

struct BlockBranch {
    displacement_at: usize,
    target: BlockId,
}

struct HostCallFrame {
    stack_size: u32,
}

impl HostCallFrame {
    const ALIGNMENT: usize = 16;
    const ALIGNMENT_PADDING: usize = 8;
    const SAVED_REGISTER_FRAME_OFFSET: usize = 24;

    fn new(argument_bytes: usize) -> Self {
        let aligned_end = (argument_bytes + Self::ALIGNMENT_PADDING + Self::ALIGNMENT - 1)
            & !(Self::ALIGNMENT - 1);
        Self {
            stack_size: (aligned_end - Self::ALIGNMENT_PADDING) as u32,
        }
    }

    fn allocate(&self, assembler: &mut Assembler) {
        assembler.subtract_stack(self.stack_size);
    }

    fn release(&self, assembler: &mut Assembler) {
        assembler.add_stack(self.stack_size);
    }

    fn saved_runtime_offset(&self) -> u32 {
        self.stack_size
    }

    fn saved_register_frame_offset(&self) -> u32 {
        self.stack_size + Self::SAVED_REGISTER_FRAME_OFFSET as u32
    }
}

struct CodeGenerator {
    assembler: Assembler,
    block_offsets: HashMap<BlockId, usize>,
    block_branches: Vec<BlockBranch>,
    exit_branches: Vec<usize>,
    maximum_size: usize,
}

pub(super) fn compile(
    function: &Function,
    graph: &ControlFlowGraph,
    maximum_size: usize,
) -> Result<Vec<u8>, String> {
    CodeGenerator::new(maximum_size).generate(function, graph)
}

impl CodeGenerator {
    fn new(maximum_size: usize) -> Self {
        Self {
            assembler: Assembler::new(),
            block_offsets: HashMap::new(),
            block_branches: Vec::new(),
            exit_branches: Vec::new(),
            maximum_size,
        }
    }

    fn generate(
        mut self,
        function: &Function,
        graph: &ControlFlowGraph,
    ) -> Result<Vec<u8>, String> {
        if graph.blocks.first().map(|block| block.id) != Some(graph.entry) {
            return Err("CFG entry block must be emitted first".into());
        }
        self.emit_fuel_prologue(function);
        for block in &graph.blocks {
            self.emit_block(block)?;
            self.check_size()?;
        }

        let exit = self.emit_exit();
        self.resolve_block_branches()?;
        self.resolve_exit_branches(exit)?;
        self.check_size()?;
        Ok(self.assembler.finish())
    }

    fn emit_fuel_prologue(&mut self, function: &Function) {
        self.assembler
            .load_immediate(std::ptr::from_ref(function) as usize as i64);
        self.assembler
            .add_memory_immediate(0, function.instruction_count as u32);
    }

    fn emit_block(&mut self, block: &BasicBlock) -> Result<(), String> {
        if self
            .block_offsets
            .insert(block.id, self.assembler.position())
            .is_some()
        {
            return Err(format!(
                "duplicate CFG block at byte {}",
                block.bytecode_offset
            ));
        }

        for operation in &block.operations {
            self.emit_operation(operation)?;
        }
        self.emit_terminator(&block.terminator);
        Ok(())
    }

    fn emit_operation(&mut self, operation: &Operation) -> Result<(), String> {
        match &operation.instruction {
            Instruction::Const(destination, value) => {
                self.assembler.load_immediate(*value);
                self.store_register(*destination);
            }
            Instruction::Mov(destination, source) => {
                self.load_register(*source);
                self.store_register(*destination);
            }
            Instruction::Add(destination, left, right) => {
                self.emit_binary(BinaryOperation::Add, *destination, *left, *right)
            }
            Instruction::Sub(destination, left, right) => {
                self.emit_binary(BinaryOperation::Subtract, *destination, *left, *right)
            }
            Instruction::Mul(destination, left, right) => {
                self.emit_binary(BinaryOperation::Multiply, *destination, *left, *right)
            }
            Instruction::Div(destination, dividend, divisor) => {
                self.emit_division(*destination, *dividend, *divisor)?
            }
            Instruction::Eq(destination, left, right) => {
                self.emit_comparison(Comparison::Equal, *destination, *left, *right)
            }
            Instruction::Lt(destination, left, right) => {
                self.emit_comparison(Comparison::SignedLess, *destination, *left, *right)
            }
            Instruction::Call {
                function,
                dst,
                args,
            } => self.emit_call(*function as usize, *dst, args),
            Instruction::Print(source) => self.emit_print(*source),
            Instruction::Load(destination, address) => self.emit_load(*destination, *address),
            Instruction::Store(address, source) => self.emit_store(*address, *source),
            Instruction::Jmp(_) | Instruction::Jz(_, _) | Instruction::Ret(_) => {
                return Err(format!(
                    "control instruction at byte {} escaped CFG construction",
                    operation.bytecode_offset
                ));
            }
        }
        Ok(())
    }

    fn emit_terminator(&mut self, terminator: &Terminator) {
        match *terminator {
            Terminator::Return { source } => {
                self.load_register(source);
                self.assembler.ret();
            }
            Terminator::Jump { target } => self.emit_block_jump(target),
            Terminator::BranchZero {
                condition,
                zero,
                nonzero,
            } => {
                self.assembler
                    .compare_register_with_zero(register_offset(condition));
                self.emit_conditional_block_jump(Condition::Equal, zero);
                self.emit_block_jump(nonzero);
            }
        }
    }

    fn emit_binary(&mut self, operation: BinaryOperation, destination: u8, left: u8, right: u8) {
        self.load_register(left);
        self.assembler
            .binary_register(operation, register_offset(right));
        self.store_register(destination);
    }

    fn emit_comparison(&mut self, comparison: Comparison, destination: u8, left: u8, right: u8) {
        self.load_register(left);
        self.assembler.compare_register(register_offset(right));
        self.assembler.materialize_comparison(comparison);
        self.store_register(destination);
    }

    fn emit_division(&mut self, destination: u8, dividend: u8, divisor: u8) -> Result<(), String> {
        self.load_register(dividend);
        self.assembler.load_r10_register(register_offset(divisor));

        self.assembler.test_r10();
        self.branch_to_exit(Condition::Equal);

        self.assembler.compare_r10_with_minus_one();
        let not_minus_one = self.assembler.jump_if(Condition::NotEqual);
        self.assembler.load_r11_minimum_i64();
        self.assembler.compare_rax_with_r11();
        self.branch_to_exit(Condition::Equal);
        self.assembler
            .patch_relative(not_minus_one, self.assembler.position())?;

        self.assembler.preserve_heap_length();
        self.assembler.sign_extend_rax();
        self.assembler.divide_by_r10();
        self.assembler.restore_heap_length();
        self.store_register(destination);
        Ok(())
    }

    fn emit_load(&mut self, destination: u8, address: u8) {
        self.load_register(address);
        self.emit_bounds_check();
        self.assembler.load_heap_word();
        self.store_register(destination);
    }

    fn emit_store(&mut self, address: u8, source: u8) {
        self.load_register(address);
        self.emit_bounds_check();
        self.assembler.load_r10_register(register_offset(source));
        self.assembler.store_r10_heap_word();
    }

    fn emit_bounds_check(&mut self) {
        self.assembler.compare_heap_index();
        self.branch_to_exit(Condition::AboveOrEqual);
    }

    fn emit_print(&mut self, source: u8) {
        self.load_register(source);
        self.assembler.save_vm_context();
        let call_frame = HostCallFrame::new(0);
        call_frame.allocate(&mut self.assembler);
        self.assembler.move_rax_to_rdi();
        self.assembler
            .load_host_function(host_address(crate::vm::jit_print as *const ()));
        self.assembler.call_rax();
        call_frame.release(&mut self.assembler);
        self.assembler.restore_vm_context();
    }

    fn emit_call(&mut self, target: usize, destination: u8, arguments: &[u8]) {
        self.assembler.save_vm_context();

        let argument_bytes = arguments.len() * 8;
        let call_frame = HostCallFrame::new(argument_bytes);
        call_frame.allocate(&mut self.assembler);

        self.assembler
            .load_saved_register_frame(call_frame.saved_register_frame_offset());
        for (index, register) in arguments.iter().enumerate() {
            self.assembler.load_r11_from_r10(register_offset(*register));
            self.assembler.store_r11_on_stack((index * 8) as u32);
        }

        // jit_call(runtime, target, arguments, argument_count)
        self.assembler
            .load_rdi_from_stack(call_frame.saved_runtime_offset());
        self.assembler.load_rsi_immediate(target as u64);
        self.assembler.move_stack_to_rdx();
        self.assembler.load_rcx_immediate(arguments.len() as u32);
        self.assembler
            .load_host_function(host_address(crate::vm::jit_call as *const ()));
        self.assembler.call_rax();

        call_frame.release(&mut self.assembler);
        self.assembler.restore_vm_context();
        self.store_register(destination);
    }

    fn emit_block_jump(&mut self, target: BlockId) {
        let displacement_at = self.assembler.jump();
        self.block_branches.push(BlockBranch {
            displacement_at,
            target,
        });
    }

    fn emit_conditional_block_jump(&mut self, condition: Condition, target: BlockId) {
        let displacement_at = self.assembler.jump_if(condition);
        self.block_branches.push(BlockBranch {
            displacement_at,
            target,
        });
    }

    fn load_register(&mut self, register: u8) {
        self.assembler.load_register(register_offset(register));
    }

    fn store_register(&mut self, register: u8) {
        self.assembler.store_register(register_offset(register));
    }

    fn branch_to_exit(&mut self, condition: Condition) {
        let displacement_at = self.assembler.jump_if(condition);
        self.exit_branches.push(displacement_at);
    }

    fn emit_exit(&mut self) -> usize {
        let exit = self.assembler.position();
        self.assembler.subtract_stack(8);
        self.assembler
            .load_host_function(host_address(crate::vm::jit_exit as *const ()));
        self.assembler.call_rax();
        self.assembler.unreachable();
        exit
    }

    fn resolve_block_branches(&mut self) -> Result<(), String> {
        for branch in &self.block_branches {
            let target = *self
                .block_offsets
                .get(&branch.target)
                .ok_or_else(|| format!("missing native code for CFG block {}", branch.target.0))?;
            self.assembler
                .patch_relative(branch.displacement_at, target)?;
        }
        Ok(())
    }

    fn resolve_exit_branches(&mut self, exit: usize) -> Result<(), String> {
        for displacement_at in &self.exit_branches {
            self.assembler.patch_relative(*displacement_at, exit)?;
        }
        Ok(())
    }

    fn check_size(&self) -> Result<(), String> {
        if self.assembler.position() > self.maximum_size {
            return Err("generated native function is too large".into());
        }
        Ok(())
    }
}

fn register_offset(register: u8) -> i32 {
    i32::from(register) * 8
}

fn host_address(function: *const ()) -> u64 {
    function as usize as u64
}
