#[derive(Clone, Copy)]
pub(super) enum BinaryOperation {
    Add,
    Subtract,
    Multiply,
}

#[derive(Clone, Copy)]
pub(super) enum Condition {
    Equal,
    NotEqual,
    AboveOrEqual,
}

#[derive(Clone, Copy)]
pub(super) enum Comparison {
    Equal,
    SignedLess,
}

impl Comparison {
    fn setcc_opcode(self) -> u8 {
        match self {
            Self::Equal => 0x94,
            Self::SignedLess => 0x9c,
        }
    }
}

impl Condition {
    fn opcode(self) -> u8 {
        match self {
            Self::Equal => 0x84,
            Self::NotEqual => 0x85,
            Self::AboveOrEqual => 0x83,
        }
    }
}

pub(super) struct Assembler {
    code: Vec<u8>,
}

impl Assembler {
    pub(super) fn new() -> Self {
        Self { code: Vec::new() }
    }

    pub(super) fn position(&self) -> usize {
        self.code.len()
    }

    pub(super) fn finish(self) -> Vec<u8> {
        self.code
    }

    pub(super) fn patch_relative(
        &mut self,
        displacement_at: usize,
        target: usize,
    ) -> Result<(), String> {
        let instruction_end = displacement_at + 4;
        let displacement = i32::try_from(target as i64 - instruction_end as i64)
            .map_err(|_| "native branch displacement overflow".to_string())?;
        self.code[displacement_at..instruction_end].copy_from_slice(&displacement.to_le_bytes());
        Ok(())
    }

    pub(super) fn jump(&mut self) -> usize {
        // jmp rel32
        self.byte(0xe9);
        self.relative_placeholder()
    }

    pub(super) fn jump_if(&mut self, condition: Condition) -> usize {
        // jcc rel32 (je, jne, or jae according to `condition`)
        self.bytes(&[0x0f, condition.opcode()]);
        self.relative_placeholder()
    }

    pub(super) fn ret(&mut self) {
        // ret
        self.byte(0xc3);
    }

    pub(super) fn unreachable(&mut self) {
        // ud2
        self.bytes(&[0x0f, 0x0b]);
    }

    pub(super) fn load_immediate(&mut self, value: i64) {
        // movabs rax, value
        self.bytes(&[0x48, 0xb8]);
        self.i64(value);
    }

    pub(super) fn add_memory_immediate(&mut self, offset: i32, value: u32) {
        // add qword ptr [rax + offset], value
        self.bytes(&[0x48, 0x81, 0x80]);
        self.i32(offset);
        self.u32(value);
    }

    pub(super) fn load_register(&mut self, offset: i32) {
        // mov rax, qword ptr [rdi + offset]
        self.bytes(&[0x48, 0x8b, 0x87]);
        self.i32(offset);
    }

    pub(super) fn store_register(&mut self, offset: i32) {
        // mov qword ptr [rdi + offset], rax
        self.bytes(&[0x48, 0x89, 0x87]);
        self.i32(offset);
    }

    pub(super) fn binary_register(&mut self, operation: BinaryOperation, offset: i32) {
        match operation {
            // add rax, qword ptr [rdi + offset]
            BinaryOperation::Add => self.bytes(&[0x48, 0x03, 0x87]),
            // sub rax, qword ptr [rdi + offset]
            BinaryOperation::Subtract => self.bytes(&[0x48, 0x2b, 0x87]),
            // imul rax, qword ptr [rdi + offset]
            BinaryOperation::Multiply => self.bytes(&[0x48, 0x0f, 0xaf, 0x87]),
        }
        self.i32(offset);
    }

    pub(super) fn compare_register(&mut self, offset: i32) {
        // cmp rax, qword ptr [rdi + offset]
        self.bytes(&[0x48, 0x3b, 0x87]);
        self.i32(offset);
    }

    pub(super) fn materialize_comparison(&mut self, comparison: Comparison) {
        // setcc al
        // movzx rax, al
        self.bytes(&[
            0x0f,
            comparison.setcc_opcode(),
            0xc0,
            0x48,
            0x0f,
            0xb6,
            0xc0,
        ]);
    }

    pub(super) fn compare_register_with_zero(&mut self, offset: i32) {
        // cmp qword ptr [rdi + offset], 0
        self.bytes(&[0x48, 0x83, 0xbf]);
        self.i32(offset);
        self.byte(0);
    }

    pub(super) fn compare_heap_index(&mut self) {
        // cmp rax, rdx
        self.bytes(&[0x48, 0x39, 0xd0]);
    }

    pub(super) fn load_heap_word(&mut self) {
        // mov rax, qword ptr [rsi + rax * 8]
        self.bytes(&[0x48, 0x8b, 0x04, 0xc6]);
    }

    pub(super) fn load_r10_register(&mut self, offset: i32) {
        // mov r10, qword ptr [rdi + offset]
        self.bytes(&[0x4c, 0x8b, 0x97]);
        self.i32(offset);
    }

    pub(super) fn store_r10_heap_word(&mut self) {
        // mov qword ptr [rsi + rax * 8], r10
        self.bytes(&[0x4c, 0x89, 0x14, 0xc6]);
    }

    pub(super) fn test_r10(&mut self) {
        // test r10, r10
        self.bytes(&[0x4d, 0x85, 0xd2]);
    }

    pub(super) fn compare_r10_with_minus_one(&mut self) {
        // cmp r10, -1
        self.bytes(&[0x49, 0x83, 0xfa, 0xff]);
    }

    pub(super) fn load_r11_minimum_i64(&mut self) {
        // movabs r11, i64::MIN
        self.bytes(&[0x49, 0xbb]);
        self.i64(i64::MIN);
    }

    pub(super) fn compare_rax_with_r11(&mut self) {
        // cmp rax, r11
        self.bytes(&[0x4c, 0x39, 0xd8]);
    }

    pub(super) fn preserve_heap_length(&mut self) {
        // mov r9, rdx
        self.bytes(&[0x49, 0x89, 0xd1]);
    }

    pub(super) fn sign_extend_rax(&mut self) {
        // cqo
        self.bytes(&[0x48, 0x99]);
    }

    pub(super) fn divide_by_r10(&mut self) {
        // idiv r10
        self.bytes(&[0x49, 0xf7, 0xfa]);
    }

    pub(super) fn restore_heap_length(&mut self) {
        // mov rdx, r9
        self.bytes(&[0x4c, 0x89, 0xca]);
    }

    pub(super) fn save_vm_context(&mut self) {
        // push rdi
        // push rsi
        // push rdx
        // push rcx
        self.bytes(&[0x57, 0x56, 0x52, 0x51]);
    }

    pub(super) fn restore_vm_context(&mut self) {
        // pop rcx
        // pop rdx
        // pop rsi
        // pop rdi
        self.bytes(&[0x59, 0x5a, 0x5e, 0x5f]);
    }

    pub(super) fn move_rax_to_rdi(&mut self) {
        // mov rdi, rax
        self.bytes(&[0x48, 0x89, 0xc7]);
    }

    pub(super) fn load_host_function(&mut self, address: u64) {
        // movabs rax, address
        self.bytes(&[0x48, 0xb8]);
        self.u64(address);
    }

    pub(super) fn call_rax(&mut self) {
        // call rax
        self.bytes(&[0xff, 0xd0]);
    }

    pub(super) fn subtract_stack(&mut self, amount: u32) {
        // sub rsp, amount
        self.bytes(&[0x48, 0x81, 0xec]);
        self.u32(amount);
    }

    pub(super) fn add_stack(&mut self, amount: u32) {
        // add rsp, amount
        self.bytes(&[0x48, 0x81, 0xc4]);
        self.u32(amount);
    }

    pub(super) fn load_saved_register_frame(&mut self, stack_offset: u32) {
        // mov r10, qword ptr [rsp + stack_offset]
        self.bytes(&[0x4c, 0x8b, 0x94, 0x24]);
        self.u32(stack_offset);
    }

    pub(super) fn load_r11_from_r10(&mut self, offset: i32) {
        // mov r11, qword ptr [r10 + offset]
        self.bytes(&[0x4d, 0x8b, 0x9a]);
        self.i32(offset);
    }

    pub(super) fn store_r11_on_stack(&mut self, offset: u32) {
        // mov qword ptr [rsp + offset], r11
        self.bytes(&[0x4c, 0x89, 0x9c, 0x24]);
        self.u32(offset);
    }

    pub(super) fn load_rdi_from_stack(&mut self, offset: u32) {
        // mov rdi, qword ptr [rsp + offset]
        self.bytes(&[0x48, 0x8b, 0xbc, 0x24]);
        self.u32(offset);
    }

    pub(super) fn load_rsi_immediate(&mut self, value: u64) {
        // movabs rsi, value
        self.bytes(&[0x48, 0xbe]);
        self.u64(value);
    }

    pub(super) fn move_stack_to_rdx(&mut self) {
        // mov rdx, rsp
        self.bytes(&[0x48, 0x89, 0xe2]);
    }

    pub(super) fn load_rcx_immediate(&mut self, value: u32) {
        // mov rcx, value
        self.bytes(&[0x48, 0xc7, 0xc1]);
        self.u32(value);
    }

    fn relative_placeholder(&mut self) -> usize {
        let offset = self.position();
        self.i32(0);
        offset
    }

    fn byte(&mut self, value: u8) {
        self.code.push(value);
    }

    fn bytes(&mut self, values: &[u8]) {
        self.code.extend_from_slice(values);
    }

    fn i32(&mut self, value: i32) {
        self.bytes(&value.to_le_bytes());
    }

    fn u32(&mut self, value: u32) {
        self.bytes(&value.to_le_bytes());
    }

    fn i64(&mut self, value: i64) {
        self.bytes(&value.to_le_bytes());
    }

    fn u64(&mut self, value: u64) {
        self.bytes(&value.to_le_bytes());
    }
}
