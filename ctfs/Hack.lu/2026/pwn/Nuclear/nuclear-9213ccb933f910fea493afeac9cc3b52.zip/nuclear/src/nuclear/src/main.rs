use std::io::{ErrorKind, Write};
use std::path::PathBuf;

use clap::Parser;
use vfio_bindings::bindings::vfio::{
    VFIO_PCI_BAR0_REGION_INDEX, VFIO_PCI_BAR2_REGION_INDEX, VFIO_PCI_CONFIG_REGION_INDEX,
    VFIO_PCI_NUM_IRQS, VFIO_PCI_NUM_REGIONS, VFIO_PCI_ROM_REGION_INDEX, VFIO_REGION_INFO_FLAG_READ,
    VFIO_REGION_INFO_FLAG_WRITE, vfio_region_info,
};
use vfio_user::{IrqInfo, Server, ServerBackend, ServerRegion};

mod pci;

const VENDOR_ID: u16 = 0x1002;
const DEVICE_ID: u16 = 0x6780;
const BAR0_SIZE: usize = 0x10000000;
const BAR2_SIZE: usize = 0x40000;

#[derive(Parser)]
struct Cli {
    /// UNIX socket to bind to
    socket: PathBuf,

    /// ROM to serve
    rom: PathBuf,
}

struct Backend {
    pci: pci::PciConfiguration,
    bar2: [u32; BAR2_SIZE / 4],
    rom: Vec<u8>,
}

impl Backend {
    fn rom_size(&self) -> u64 {
        Self::rom_size_of(&self.rom)
    }

    fn rom_size_of(rom: &[u8]) -> u64 {
        rom.len().max(2048).next_power_of_two() as u64
    }

    fn new(rom: Vec<u8>) -> Self {
        let mut pci = pci::PciConfiguration::new(
            VENDOR_ID,
            DEVICE_ID,
            pci::PciClassCode::DisplayController,
            &pci::PciDisplaySubclass::Other as &dyn pci::PciSubclass,
            None,
            pci::PciHeaderType::Device,
            0,
            0,
            0,
        );

        pci.add_pci_bar(pci::PciBarConfiguration::new(
            VFIO_PCI_BAR0_REGION_INDEX as usize,
            BAR0_SIZE as u64,
            pci::PciBarRegionType::Memory32BitRegion,
            pci::PciBarPrefetchable::NotPrefetchable,
        ))
        .expect("Invalid PCI configuration");

        pci.add_pci_bar(pci::PciBarConfiguration::new(
            VFIO_PCI_BAR2_REGION_INDEX as usize,
            BAR2_SIZE as u64,
            pci::PciBarRegionType::Memory32BitRegion,
            pci::PciBarPrefetchable::NotPrefetchable,
        ))
        .expect("Invalid PCI configuration");

        pci.add_pci_bar(pci::PciBarConfiguration::new(
            VFIO_PCI_ROM_REGION_INDEX as usize,
            Self::rom_size_of(&rom),
            pci::PciBarRegionType::Memory32BitRegion,
            pci::PciBarPrefetchable::NotPrefetchable,
        ))
        .expect("Invalid PCI configuration");

        Self {
            pci,
            bar2: [0u32; _],
            rom,
        }
    }

    fn dump(&self) {
        let mut out = Vec::with_capacity(std::mem::size_of_val(&self.bar2));
        for value in self.bar2 {
            out.extend_from_slice(&value.to_le_bytes());
        }
        let mut stdout = std::io::stdout().lock();
        stdout.write_all(&out).expect("failed to dump state");
        stdout.flush().expect("failed to flush output");
    }
}

/// The memory regions exported by this device
fn regions(backend: &Backend) -> Vec<ServerRegion> {
    let mut regions = Vec::with_capacity(VFIO_PCI_NUM_REGIONS as usize);
    for index in 0..VFIO_PCI_NUM_REGIONS {
        let mut region = vfio_region_info {
            argsz: std::mem::size_of::<vfio_region_info>() as u32,
            index,
            ..Default::default()
        };
        match index {
            VFIO_PCI_CONFIG_REGION_INDEX => {
                region.size = (pci::NUM_CONFIGURATION_REGISTERS * 4) as u64;
                region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
            }
            VFIO_PCI_BAR0_REGION_INDEX => {
                region.size = BAR0_SIZE as u64;
                region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
            }
            VFIO_PCI_BAR2_REGION_INDEX => {
                region.size = BAR2_SIZE as u64;
                region.flags = VFIO_REGION_INFO_FLAG_READ | VFIO_REGION_INFO_FLAG_WRITE;
            }
            VFIO_PCI_ROM_REGION_INDEX => {
                region.size = backend.rom_size();
                region.flags = VFIO_REGION_INFO_FLAG_READ;
            }
            _ => {}
        }
        regions.push(ServerRegion {
            region_info: region,
            sparse_areas: Vec::new(),
            mmap_fd: None,
        });
    }
    regions
}

/// Interrupts exposed by this device (none)
fn irqs() -> Vec<IrqInfo> {
    (0..VFIO_PCI_NUM_IRQS)
        .map(|index| IrqInfo {
            index,
            count: 0,
            flags: 0,
        })
        .collect()
}

impl ServerBackend for Backend {
    fn region_read(
        &mut self,
        region: u32,
        offset: u64,
        data: &mut [u8],
    ) -> Result<(), std::io::Error> {
        let len = data.len();
        if region == VFIO_PCI_CONFIG_REGION_INDEX {
            // We need to forward reads to the PCI configuration space.
            // (Writes are much simpler with the PCI template, incidentally).
            let mut register = offset as usize / 4;
            if len > 4 {
                // QEMU will gladly read the entire configuration space at once.
                if !len.is_multiple_of(4) || !offset.is_multiple_of(4) {
                    return Err(ErrorKind::InvalidInput.into());
                }
                let mut current = 0;
                while current < len {
                    let value = self.pci.read_reg(register);
                    data[current..current + 4].copy_from_slice(&value.to_le_bytes());
                    register += 1;
                    current += 4;
                }
            } else {
                // Enforce register boundaries and alignment
                let reg_offset = offset as usize % 4;
                if reg_offset + len > 4 || !reg_offset.is_multiple_of(len) {
                    return Err(ErrorKind::InvalidInput.into());
                }
                let value = self.pci.read_reg(register);
                data.copy_from_slice(&value.to_le_bytes()[reg_offset..reg_offset + len]);
            }
            Ok(())
        } else if region == VFIO_PCI_BAR0_REGION_INDEX {
            // This remains at zero forever
            data.fill(0);
            Ok(())
        } else if region == VFIO_PCI_BAR2_REGION_INDEX {
            // Registers are all zero initially
            let index = offset as usize / 4;
            if len != 4 || !offset.is_multiple_of(4) || index >= self.bar2.len() {
                tracing::warn!(
                    "Invalid read of {:#x} bytes from register at offset {:#x}",
                    len,
                    offset
                );
                data.fill(0);
                return Ok(());
            }
            let value = self.bar2[index];
            tracing::debug!("Read  regs[{index:#06x}] ({offset:#x}) = {value:#010x}");
            data.copy_from_slice(&value.to_le_bytes());
            Ok(())
        } else if region == VFIO_PCI_ROM_REGION_INDEX {
            let begin = (offset as usize).min(self.rom.len());
            let end = begin.saturating_add(len).min(self.rom.len());
            let copy_len = len.min(end - begin);
            data[0..copy_len].copy_from_slice(&self.rom[begin..end]);
            data[copy_len..].fill(0);
            Ok(())
        } else {
            tracing::warn!(
                "Invalid read of {:#x} bytes attempted from region {} at offset {:#x}",
                data.len(),
                region,
                offset
            );
            data.fill(0);
            Ok(())
        }
    }

    fn region_write(
        &mut self,
        region: u32,
        offset: u64,
        data: &[u8],
    ) -> Result<(), std::io::Error> {
        if region == VFIO_PCI_CONFIG_REGION_INDEX {
            self.pci.write_reg(offset as usize / 4, offset % 4, data);
            Ok(())
        } else if region == VFIO_PCI_BAR0_REGION_INDEX {
            Ok(())
        } else if region == VFIO_PCI_BAR2_REGION_INDEX {
            let index = offset as usize / 4;
            let Ok(value) = data.try_into().map(u32::from_le_bytes) else {
                tracing::warn!(
                    "Invalid write of {:#x} bytes to register at offset {:#x}",
                    data.len(),
                    offset
                );
                return Ok(());
            };
            if !offset.is_multiple_of(4) || index >= self.bar2.len() {
                tracing::warn!("Misaligned or out-of-bounds register write at offset {offset:#x}");
                return Ok(());
            }
            tracing::debug!("Write regs[{index:#06x}] ({offset:#x}) = {value:#010x}");
            self.bar2[index] = value;
            Ok(())
        } else {
            tracing::warn!(
                "Invalid write of {:#x} bytes attempted to region {} at offset {:#x}",
                data.len(),
                region,
                offset
            );
            Ok(())
        }
    }

    fn dma_map(
        &mut self,
        _flags: vfio_user::DmaMapFlags,
        _offset: u64,
        _address: u64,
        _size: u64,
        _fd: Option<std::fs::File>,
    ) -> Result<(), std::io::Error> {
        Ok(())
    }

    fn dma_unmap(
        &mut self,
        _flags: vfio_user::DmaUnmapFlags,
        _address: u64,
        _size: u64,
    ) -> Result<(), std::io::Error> {
        Ok(())
    }

    fn reset(&mut self) -> Result<(), std::io::Error> {
        self.bar2.fill(0);
        Ok(())
    }

    fn set_irqs(
        &mut self,
        _index: u32,
        _flags: u32,
        _start: u32,
        _count: u32,
        _fds: Vec<std::fs::File>,
    ) -> Result<(), std::io::Error> {
        Ok(())
    }
}

fn main() {
    tracing_subscriber::fmt()
        .with_writer(std::io::stderr)
        .with_max_level(tracing::Level::DEBUG)
        .init();
    let args = Cli::parse();
    let rom = std::fs::read(args.rom).expect("failed to read ROM");

    let mut backend = Backend::new(rom);
    let server = Server::new(&args.socket, true, irqs(), regions(&backend))
        .expect("failed to create server");
    let result = server.run(&mut backend);
    backend.dump();
    result.expect("server exited with an error");
}
