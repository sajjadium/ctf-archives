#!/bin/bash
set -euo pipefail

# Grab a standard ArchLinux ISO (probably any distro will do, but this one works for sure)
: "${iso:=archlinux-2026.10.01-x86_64.iso}"
if ! [ -e "${iso}" ]; then
    echo "Downloading ArchLinux..."
    wget -O "${iso}" https://fastly.mirror.pkgbuild.com/iso/2026.10.01/"${iso}"
    if [ "$(sha256sum -- "${iso}" | cut -d" " -f1)" != "684ded26c63240ff4a41e8c25ee84ea6da233f557364821f13d12c2b0a9059a5" ]; then
        echo "Hash mismatch, deleting ${iso}..."
        rm -f -- "${iso}"
        exit 1
    fi

    # Patch out the 15 second boot delay for your convenience
    # (This should be offset 1360347175 in this ISO)
    offset="$(grep -obUaF -m 1 'TIMEOUT 150' -- "${iso}" | cut -d: -f1)"
    if [ -n "${offset}" ]; then
        printf 'TIMEOUT 001' | dd of="${iso}" bs=1 seek="${offset}" conv=notrunc status=none
    else
        echo "Failed to rewrite boot timeout, deleting ${iso}..."
        rm -f -- "${iso}"
        exit 1
    fi
fi

# Exit early in `docker build`
[ -n "${prepare:-}" ] && exit 0

# Set up
token="$(od -tx1 -An /dev/urandom | tr -d ' \n' | head -c16 || true)"
work="$(mktemp -d)"
: "${socket:="${work}/nuclear-${token}.sock"}"
: "${rom:="${work}/rom-${token}.bin"}"
: "${tmp:="${work}/rom-${token}.tmp"}"

function cleanup {
    kill %1 || true
    rm -f -- "${tmp}"
    rm -f -- "${socket}"
    rm -f -- "${rom}"
    rm -rf -- "${work}"
}
trap cleanup EXIT

# Read ROM
echo 'Your ROM (from `gzip -c rom.bin | base64`):'
size=0
while IFS= read -r -t 30 line; do
    if [ -z "${line}" ]; then
        break
    fi

    echo "${line}" >> "${tmp}"

    size=$((size + ${#line} + 1))
    if [ "${size}" -gt 65536 ]; then
        echo "Your ROM is too large"
        exit 1
    fi
done
base64 -d "${tmp}" | gunzip -c > "${rom}"

if [ "$(stat -c '%s' -- "${rom}")" -gt 65536 ]; then
    echo "Your ROM is too large"
    exit 1
fi
rm -f -- "${tmp}"

# Spin up the device
./nuclear "${socket}" "${rom}" | xxd -a &
for _ in $(seq 100); do
    if [ -S "${socket}" ]; then
        break
    fi
    sleep 0.05
done
if ! [ -S "${socket}" ]; then
    echo "Device did not come up"
    exit 1
fi


# Now we always want to clean up
set +e

# Run that in QEMU
timeout --foreground 120 qemu-system-x86_64 \
    -enable-kvm \
    -m 1536M \
    -device '{"driver":"vfio-user-pci","socket":{"path":"'"${socket}"'","type":"unix"},"x-no-posted-writes":true}' \
    -serial none -display none -monitor none -nic none -no-reboot \
    -drive if=none,id=flag,file=flag.txt,format=raw,readonly=on \
    -device virtio-blk-pci,drive=flag,serial=flag \
    -cdrom "${iso}"

# Give the device time to dump state back
sleep 3
