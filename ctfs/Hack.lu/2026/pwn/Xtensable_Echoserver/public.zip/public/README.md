# Xtensable Echoserver

`app` contains the source code of the challenge.
You can use west to build it yourself, but this is not required to solve the challenge.

You can start the full deployment the same way we have it running with docker compose.
Or use `./run.sh` to just start the QEMU directly.

## Getting the Flag
The flag is outside of the QEMU.
Use semihosting via simcalls to open and read the flag.
You don't need to escape the QEMU.

## Debugging
Download the Xtensa SDK for DC233C from the zephyr project: https://github.com/zephyrproject-rtos/sdk-ng/releases/download/v1.0.1/toolchain_gnu_linux-x86_64_xtensa-dc233c_zephyr-elf.tar.xz
Then run `./run.sh -s -S` to start QEMU with debugging enabled.
Run gdb from the SDK and connect to the QEMU for debugging.

If an exception occurs in another exception handler zephyr os just stops and the QEMU exits.
So there is also `tools/debug.sh`, which runs the challenge with gdb attached, breaks on the exception handlers, and prints debug info before exiting.
