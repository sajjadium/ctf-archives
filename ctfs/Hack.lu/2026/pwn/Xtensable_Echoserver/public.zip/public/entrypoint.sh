#!/bin/sh
set -eu

CHALL_DIR=/chall
PORT="${PORT:-1024}"

exec "${CHALL_DIR}/ynetd" \
    -p "${PORT}" \
    -u ctf \
    -d "${CHALL_DIR}" \
    -lt 60 \
    -lm 2147483648 \
    -t 120 \
    "./run.sh"
