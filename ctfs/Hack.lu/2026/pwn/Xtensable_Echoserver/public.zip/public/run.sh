#!/bin/sh

exec qemu-system-xtensa \
  -machine sim \
  -nographic \
  -cpu dc233c \
  -semihosting \
  -net none \
  -monitor none \
  -serial none \
  -icount shift=6,align=off,sleep=on \
  -rtc clock=vm \
  -kernel zephyr.elf \
  "$@"
