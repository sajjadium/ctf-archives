# stop at the first fault and dump the exception state
set pagination off
set confirm off

break _DoubleExceptionVector
break _KernelExceptionVector
break z_fatal_error

continue

printf "\n==================== FAULT ====================\n"
printf " vector pc : 0x%08x\n", $pc
printf " exccause  : %d\n", $exccause
printf " epc1      : 0x%08x   <- faulting instruction\n", $epc1
printf " excvaddr  : 0x%08x   <- faulting data address\n", $excvaddr
printf " ps        : 0x%08x   EXCM=%d\n", $ps, ($ps >> 4) & 1
printf "\n a0=%08x a1=%08x a2=%08x a3=%08x\n", $a0, $a1, $a2, $a3
printf " a4=%08x a5=%08x a6=%08x a7=%08x\n", $a4, $a5, $a6, $a7
printf " windowbase=%d windowstart=0x%x\n", $windowbase, $windowstart
printf "===============================================\n\n"
backtrace
