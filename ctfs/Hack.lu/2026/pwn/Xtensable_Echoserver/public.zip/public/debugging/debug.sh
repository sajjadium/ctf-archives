#!/bin/bash
set -u

HERE="$(cd "$(dirname "$0")" && pwd)"
ELF="$HERE/../zephyr.elf"
QEMU="qemu-system-xtensa"
GDB="xtensa-dc233c_zephyr-elf-gdb"
PORT="1234"

[ -x "$QEMU" ] || command -v "$QEMU" >/dev/null 2>&1 || { echo "qemu not found: $QEMU" >&2; exit 1; }
[ -x "$GDB" ] || command -v "$GDB" >/dev/null 2>&1 || { echo "gdb not found: $GDB" >&2; exit 1; }
[ -r "$ELF" ]  || { echo "elf not found: $ELF" >&2; exit 1; }

( sleep 1; "$GDB" -q -batch -ex "target remote :$PORT" -x "$HERE/fault.gdb" "$ELF" ) >&2 &
GPID=$!
trap 'kill $GPID 2>/dev/null' EXIT

QEMU_ARGS=(-machine sim -nographic -cpu dc233c -semihosting -net none -monitor none
           -serial none -icount shift=6,align=off,sleep=on -rtc clock=vm
           -kernel "$ELF" -S -gdb "tcp::$PORT")

"$QEMU" "${QEMU_ARGS[@]}"
