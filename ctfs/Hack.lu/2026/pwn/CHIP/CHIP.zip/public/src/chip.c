#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

#include "display.h"

#define MEMORY_SIZE 4096
#define STACK_SIZE 48
#define FONT_START 0x050
#define PROGRAM_START 0x200

enum State {
    RUNNING, FINISHED, UNRECOGNIZED_INSTRUCTION, STACK_OVERFLOW, STACK_UNDERFLOW
};

static uint8_t display[SCREEN_HEIGHT][SCREEN_WIDTH] = {0};

struct program_state {
    uint16_t stack[STACK_SIZE];
    uint8_t memory[MEMORY_SIZE];
    uint16_t I;
    uint16_t PC;
    uint8_t V[16];
    uint8_t delay_timer;
    uint8_t sound_timer;
    int stack_pointer;
};

static void die(char *str)
{
    perror(str);
    exit(EXIT_FAILURE);
}

static void load_font(struct program_state *state)
{
    uint8_t font[] = {
        0xF0, 0x90, 0x90, 0x90, 0xF0, // 0
        0x20, 0x60, 0x20, 0x20, 0x70, // 1
        0xF0, 0x10, 0xF0, 0x80, 0xF0, // 2
        0xF0, 0x10, 0xF0, 0x10, 0xF0, // 3
        0x90, 0x90, 0xF0, 0x10, 0x10, // 4
        0xF0, 0x80, 0xF0, 0x10, 0xF0, // 5
        0xF0, 0x80, 0xF0, 0x90, 0xF0, // 6
        0xF0, 0x10, 0x20, 0x40, 0x40, // 7
        0xF0, 0x90, 0xF0, 0x90, 0xF0, // 8
        0xF0, 0x90, 0xF0, 0x10, 0xF0, // 9
        0xF0, 0x90, 0xF0, 0x90, 0x90, // A
        0xE0, 0x90, 0xE0, 0x90, 0xE0, // B
        0xF0, 0x80, 0x80, 0x80, 0xF0, // C
        0xE0, 0x90, 0x90, 0x90, 0xE0, // D
        0xF0, 0x80, 0xF0, 0x80, 0xF0, // E
        0xF0, 0x80, 0xF0, 0x80, 0x80  // F
    };

    memcpy(state->memory + FONT_START, font, sizeof(font));
}

static void read_program(struct program_state *state, char *program_path)
{
    FILE *file = fopen(program_path, "r");
    if (file == NULL) {
        die("fopen");
    }

    int size = MEMORY_SIZE - PROGRAM_START;
    if (fread(state->memory + PROGRAM_START, size, 1, file) < size) {
        if (ferror(file)) {
            die("fread");
        }
    }

    fclose(file);
}

static void read_input(struct program_state *state)
{
    int size = MEMORY_SIZE - PROGRAM_START;

    fputs("Enter your CHIP bytecode > ", stdout);
    if (fread(state->memory + PROGRAM_START, size, 1, stdin) < size) {
        if (ferror(stdin)) {
            die("fread");
        }
    }
}

static void unrecognized_instruction(uint16_t instruction)
{
    fprintf(stderr, "Unrecognied instruction: %x\n", instruction);
}

static void clear_screen()
{
    memset(display, 0, SCREEN_WIDTH * SCREEN_HEIGHT);
}

static void draw_sprite(uint8_t base_x, uint8_t base_y, uint8_t N, struct program_state *state)
{
    base_x %= SCREEN_WIDTH;
    base_y %= SCREEN_HEIGHT;

    state->V[0xF] = 0;

    uint8_t x;
    uint8_t y;
    uint8_t current_pixel;
    uint8_t new_pixel;
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < 8; j++) {
            x = base_x + j;
            y = base_y + i;

            // Prevent drawing out of bounds
            if (x >= SCREEN_WIDTH || y >= SCREEN_HEIGHT)
                continue;

            current_pixel = display[y][x];
            new_pixel = (state->memory[state->I + i] >> (7 - j)) & 1;

            if (current_pixel && new_pixel) {
                state->V[0xF] = 1;
                display[y][x] = 0;
            } else if (!current_pixel && new_pixel) {
                display[y][x] = 1;
            }
        }
    }    
}

static enum State execute_instruction(struct program_state *state)
{
    uint16_t instruction = (state->memory[state->PC] << 8) | state->memory[state->PC + 1];
    printf("Instruction: %x\n", instruction);
    state->PC += 2;

    if (state->PC > MEMORY_SIZE)
        return FINISHED;

    // Different instructions might need different splits
    uint8_t X = (instruction & 0xf00) >> 8;
    uint8_t Y = (instruction & 0x0f0) >> 4;
    uint16_t NNN = instruction & 0xfff;
    uint8_t NN = instruction & 0x0ff;
    uint8_t N = instruction & 0x00f;

    uint8_t tmp;
    uint16_t I = state->I;
    switch ((instruction & 0xf000) >> 12) {

    case 0x0:
        switch (NN) {
        case 0xe0:
            clear_screen();
            break;
        case 0xee:
            if (state->stack_pointer > 0) {
                state->stack_pointer--;
                state->PC = state->stack[state->stack_pointer];
            } else {
                return STACK_UNDERFLOW;
            }
            break;
        default:
            unrecognized_instruction(instruction);
            return UNRECOGNIZED_INSTRUCTION;
        }
        break;

    case 0x1:
        state->PC = NNN;
        break;

    case 0x2:
        if (state->stack_pointer < (sizeof(state->stack) / sizeof(state->stack[0]))) {
            state->stack[state->stack_pointer] = state->PC;
            state->stack_pointer++;
            state->PC = NNN;
        } else {
            return STACK_OVERFLOW;
        }
        break;
        
    case 0x3:
        if (state->V[X] == NN)
            state->PC += 2;
        break;

    case 0x4:
        if (state->V[X] != NN)
            state->PC += 2;
        break;

    case 0x5:
        if (state->V[X] == state->V[Y])
            state->PC += 2;
        break;

    case 0x6:
        state->V[X] = NN;
        break;

    case 0x7:
        state->V[X] += NN;
        break;
        
    case 0x8:
        switch (N) {
        case 0x0:
            state->V[X] = state->V[Y];
            break;

        case 0x1:
            state->V[X] |= state->V[Y];
            break;

        case 0x2:
            state->V[X] &= state->V[Y];
            break;

        case 0x3:
            state->V[X] ^= state->V[Y];
            break;

        case 0x4:
            tmp = state->V[X];
            state->V[X] += state->V[Y];
            if (state->V[X] < tmp) // Overflow
                state->V[0xF] = 1;
            else
                state->V[0xF] = 0;
            break;

        case 0x5:
            tmp = state->V[X];
            state->V[X] -= state->V[Y];
            if (state->V[X] > tmp) // Underflow
                state->V[0xF] = 0;
            else
                state->V[0xF] = 1;
            break;

        case 0x6:
            tmp = state->V[X] & 1;
            state->V[X] >>= 1;
            state->V[0xF] = tmp;
            break;

        case 0x7:
            tmp = state->V[Y];
            state->V[X] = state->V[Y] - state->V[X];
            if (state->V[X] > tmp) // Underflow
                state->V[0xF] = 0;
            else
                state->V[0xF] = 1;
            break;

        case 0xe:
            tmp = state->V[X] >> 7;
            state->V[X] <<= 1;
            state->V[0xF] = tmp;
            break;

        default:
            unrecognized_instruction(instruction);
            return UNRECOGNIZED_INSTRUCTION;
        }
        break;

    case 0x9:
        if (state->V[X] != state->V[Y])
            state->PC += 2;
        break;

    case 0xa:
        state->I = NNN;
        break;

    case 0xd:
        draw_sprite(state->V[X], state->V[Y], N, state);
        break;

    case 0xf:
        switch (NN) {
        case 0x1e:
            state->I += (state->V[X] & 0xFFF);
            break;

        case 0x33:
            // Store binary-coded decimal representation of VX at I, I+1, I+2
            state->memory[I] = state->V[X] / 100;
            state->memory[I + 1] = (state->V[X] % 100) / 10;
            state->memory[I + 2] = (state->V[X] % 10);
            break;
            
        case 0x41:
            // custom register printing instruction
            fwrite(&state->V[X], sizeof(state->V[X]), 1, stdout);
            break;
            
        case 0x55:
            for (int i = 0; i <= X; i++) {
                state->memory[I + i] = state->V[i];
            }
            break;

        case 0x65:
            for (int i = 0; i <= X; i++) {
                state->V[i] = state->memory[I + i];
            }
            break;

        default:
            unrecognized_instruction(instruction);
            return UNRECOGNIZED_INSTRUCTION;
        }
        break;

    default:
        unrecognized_instruction(instruction);
        return UNRECOGNIZED_INSTRUCTION;
    }


    return RUNNING;
}

int main(int argc, char* argv[])
{
    setbuf(stdout, 0);
    setbuf(stderr, 0);
    setbuf(stdin, 0);
    puts("Starting CHIP...");
    puts("Remember to run our example program with ./chip fluxlogo.ch8\n");

    struct program_state main_state = { 0 };

    load_font(&main_state);

    if (argc == 2)
        read_program(&main_state, argv[1]);
    else
        read_input(&main_state);

    // Ignore all sdl stuff, it is just flavor 
    sdl_initialize();

    // Main execution loop
    main_state.PC = PROGRAM_START;
    enum State current_state = RUNNING;
    while (!sdl_is_quit()) {
        current_state = execute_instruction(&main_state);
        if (current_state != RUNNING)
            break;

        sdl_update_display(display);
    }

    printf("CHIP exited with %d\n", current_state);

    sdl_cleanup();
    return EXIT_SUCCESS;
}
