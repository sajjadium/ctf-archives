#include <SDL2/SDL.h>
#include <SDL2/SDL_render.h>
#include <stdint.h>
#include <stdbool.h>

#include "display.h"

struct sdl_state {
    SDL_Window *window;
    SDL_Renderer *renderer;
    SDL_Texture *texture;
};

static struct sdl_state state;

static void die_sdl(char *str)
{
    printf("%s SDL_Error: %s\n", str, SDL_GetError());
    exit(EXIT_FAILURE);
}

static void fill_pixel_buffer(uint32_t *pixel_buffer, uint8_t display[SCREEN_HEIGHT][SCREEN_WIDTH])
{
    for (int y = 0; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            if (x <= SCREEN_WIDTH / 2)
                pixel_buffer[y * SCREEN_WIDTH + x] = display[y][x] ? COLOR_ON_LEFT : COLOR_OFF;
            else
                pixel_buffer[y * SCREEN_WIDTH + x] = display[y][x] ? COLOR_ON_RIGHT : COLOR_OFF;
        }
    }
}

void sdl_initialize()
{
    state.window = NULL;
    state.renderer = NULL;
    state.texture = NULL;

    if (SDL_Init(SDL_INIT_VIDEO) < 0)
        die_sdl("SDL_Init");

    state.window = SDL_CreateWindow("C.H.I.P.", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH_PIXELS, SCREEN_HEIGHT_PIXELS, SDL_WINDOW_SHOWN);
    if (state.window == NULL)
        die_sdl("SDL_CreateWindow");

    state.renderer = SDL_CreateRenderer(state.window, -1, SDL_RENDERER_ACCELERATED);
    if (state.renderer == NULL)
        die_sdl("SDL_CreateRenderer");

    state.texture = SDL_CreateTexture(state.renderer, SDL_PIXELFORMAT_RGBA32, SDL_TEXTUREACCESS_STREAMING, SCREEN_WIDTH, SCREEN_HEIGHT);
    if (state.texture == NULL)
        die_sdl("SDL_CreateTexture");

}

void sdl_cleanup()
{
    
    SDL_DestroyTexture(state.texture);
    SDL_DestroyRenderer(state.renderer);
    SDL_DestroyWindow(state.window);

    SDL_Quit();
}

bool sdl_is_quit()
{
    SDL_Event event;
    if (SDL_PollEvent(&event)) {
        // Closing the window
        if (event.type == SDL_QUIT) {
            return true;
        }
    }
    return false;
}

void sdl_update_display(uint8_t display[SCREEN_HEIGHT][SCREEN_WIDTH])
{
    uint32_t pixel_buffer[SCREEN_WIDTH * SCREEN_HEIGHT];

    fill_pixel_buffer(pixel_buffer, display);

    if(SDL_UpdateTexture(state.texture, NULL, pixel_buffer, SCREEN_WIDTH * sizeof(uint32_t)) < 0)
        die_sdl("SDL_Update");

    if(SDL_RenderClear(state.renderer) < 0)
        die_sdl("SDL_RenderClear");

    if(SDL_RenderCopy(state.renderer, state.texture, NULL, NULL) < 0)
        die_sdl("SDL_RenderCopy");

    SDL_RenderPresent(state.renderer);

    SDL_Delay(2);
}
