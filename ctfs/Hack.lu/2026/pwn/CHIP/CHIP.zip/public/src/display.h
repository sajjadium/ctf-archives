#pragma once

#include <stdint.h>

#define SCREEN_WIDTH 64
#define SCREEN_HEIGHT 32
#define SCREEN_WIDTH_PIXELS 640
#define SCREEN_HEIGHT_PIXELS 320
#define COLOR_OFF 0x00000000
#define COLOR_ON_LEFT 0x00FFC800
#define COLOR_ON_RIGHT 0x006DD900

void sdl_initialize();
void sdl_cleanup();
bool sdl_is_quit();
void sdl_update_display(uint8_t display[SCREEN_HEIGHT][SCREEN_WIDTH]);
