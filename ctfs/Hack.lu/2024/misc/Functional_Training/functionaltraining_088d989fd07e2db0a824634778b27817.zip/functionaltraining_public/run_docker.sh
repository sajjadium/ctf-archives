#!/bin/bash
docker rm -f functional_training
docker build -t functional_training .
docker run --name=functional_training --rm -dp 8080:8080 functional_training
