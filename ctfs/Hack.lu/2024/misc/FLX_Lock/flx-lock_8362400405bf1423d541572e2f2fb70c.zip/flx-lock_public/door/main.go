package main

import (
	"bytes"
	"crypto/rand"
	"fmt"
	"math"
	"math/big"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"text/template"

	sprig "github.com/Masterminds/sprig/v3"
)

const (
	MAX_LOG_LEN = 256
)

var client *MqttClient
var doorState = "locked"
var doorCode string

type responseCtx struct {
	DoorState string
	Cmd       string
}

func connect() {
	mqttClient, err := Connect(os.Getenv("BROKER_URL"), handleMessage)
	if err != nil {
		panic(err)
	}
	client = mqttClient
}

func main() {
	if n, err := rand.Int(rand.Reader, big.NewInt(math.MaxInt64)); err != nil {
		panic(err)
	} else {
		doorCode = fmt.Sprintf("%d", n)
	}

	connect()
	subscribe("commands/+")

	keepAlive := make(chan os.Signal, 1)
	signal.Notify(keepAlive, os.Interrupt, syscall.SIGTERM)
	<-keepAlive
}

func handleMessage(topic, text string) {
	fmt.Printf("[%s] <- %s\n", truncStr(topic, MAX_LOG_LEN), truncStr(text, MAX_LOG_LEN))

	if !strings.HasPrefix(topic, "commands/") {
		fmt.Println("not a command")
		return
	}
	cmd := topic[len("commands/"):]

	parts := strings.SplitN(text, " ", 2)
	if len(parts) < 2 {
		fmt.Println("missing clientID")
		return
	}
	clientID := parts[0]
	payload := parts[1]

	response := handleCmd(cmd, payload)

	resTopic := fmt.Sprintf("responses/%s", clientID)
	resCtx := responseCtx{doorState, cmd}
	resBody := render(response, resCtx)
	publish(resTopic, resBody)
}

func handleCmd(cmd, payload string) string {
	switch cmd {
	case "status":
		return "door is {{ .DoorState }}"
	case "unlock":
		success, err := tryUnlock(payload)
		if err != nil {
			return fmt.Sprintf("error: %s", err)
		}
		return success
	default:
		return "unknown command: {{ .Cmd }}"
	}
}

func tryUnlock(code string) (string, error) {
	if doorState == "unlocked" {
		return "already unlocked", nil
	}
	if code != doorCode {
		return "", fmt.Errorf("invalid code: %s", code)
	}

	doorState = "unlocked"
	return "door is now unlocked", nil
}

func publish(topic string, text string) {
	client.Publish(topic, text)
	fmt.Printf("[%s] -> %s\n", truncStr(topic, MAX_LOG_LEN), truncStr(text, MAX_LOG_LEN))
}

func subscribe(topic string) {
	client.Subscribe(topic)
	fmt.Printf("[%s] subscribed\n", truncStr(topic, MAX_LOG_LEN))
}

func render(tpl string, data any) string {
	var buf bytes.Buffer
	parsed, err := template.New("tpl").Funcs(sprig.FuncMap()).Parse(tpl)
	if err != nil {
		return tpl
	}
	err = parsed.Execute(&buf, data)
	if err != nil {
		return tpl
	}
	return buf.String()
}

func truncStr(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return fmt.Sprintf("%s ... (%d)", s[:n], len(s)-n)
}
