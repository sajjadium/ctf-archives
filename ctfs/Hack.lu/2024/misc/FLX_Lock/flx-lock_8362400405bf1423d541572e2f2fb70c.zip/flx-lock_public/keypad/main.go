package main

import (
	"bufio"
	"fmt"
	"os"

	uuid "github.com/fossoreslp/go-uuid-v4"
)

var clientID string
var client *MqttClient
var responses = make(chan string)

func connect() {
	id, err := uuid.NewString()
	if err != nil {
		panic(err)
	}
	clientID = id

	mqttClient, err := Connect(os.Getenv("BROKER_URL"), func(topic, text string) {
		responses <- string(text)
	})
	if err != nil {
		panic(err)
	}
	client = mqttClient
}

func banner() {
	fmt.Println()
	fmt.Println("        +----------------------------------------+     +~~~+~~~+~~~+")
	fmt.Println("  ,----/  ~ FLX-Lock Keypad :: Debug Console ~  /      | 1 | 2 | 3 |")
	fmt.Println(" /    +----------------------------------------+       +~~~+~~~+~~~+")
	fmt.Println("+                                                      | 4 | 5 | 6 |")
	fmt.Println("|       +----------------------------------------+     +~~~+~~~+~~~+")
	fmt.Println("| ,----/  CMDs: //  status  /  unlock  /  quit  /      | 7 | 8 | 9 |")
	fmt.Println("|/    +----------------------------------------+       +~~~+~~~+~~~+")
	fmt.Println("+                                                      | * | 0 | # |")
	fmt.Println("|                                                      +~~~+~~~+~~~+")
}

func readLine(reader *bufio.Reader) string {
	line, err := reader.ReadString('\n')
	if err != nil {
		panic(err)
	}
	return line[:len(line)-1]
}

func main() {
	connect()
	client.Subscribe(fmt.Sprintf("responses/%s", clientID))

	banner()
	r := bufio.NewReader(os.Stdin)
	for {
		fmt.Print("+--> ")
		line := readLine(r)
		switch line {
		case "status":
			send("commands/status", "")
		case "unlock":
			go func() { responses <- "disabled in production build!" }()
		case "quit":
			client.Disconnect()
			return
		default:
			send(fmt.Sprintf("commands/%s", line), "")
		}
		fmt.Printf("+--[ %s ]\n", <-responses)
		fmt.Printf("|\n")
	}
}

func send(topic string, text string) {
	payload := fmt.Sprintf("%s %s", clientID, text)
	client.Publish(topic, payload)
}
