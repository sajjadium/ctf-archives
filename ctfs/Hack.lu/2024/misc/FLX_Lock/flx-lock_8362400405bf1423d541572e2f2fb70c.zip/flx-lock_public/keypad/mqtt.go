package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"sync"
	"time"
)

const (
	CONNECT     byte = 1
	CONNACK     byte = 2
	PUBLISH     byte = 3
	PUBACK      byte = 4
	PUBREC      byte = 5
	PUBREL      byte = 6
	PUBCOMP     byte = 7
	SUBSCRIBE   byte = 8
	SUBACK      byte = 9
	UNSUBSCRIBE byte = 10
	UNSUBACK    byte = 11
	PINGREQ     byte = 12
	PINGRESP    byte = 13
	DISCONNECT  byte = 14
)

type mqttPacket struct {
	type_   byte
	flags   byte
	payload []byte
}

type MsgHandler func(string, string)

type MqttClient struct {
	conn      net.Conn
	connected bool
	mu        sync.Mutex
	incoming  chan mqttPacket
	handler   MsgHandler
}

func Connect(address string, handler MsgHandler) (*MqttClient, error) {
	conn, err := net.Dial("tcp", address)
	if err != nil {
		return nil, err
	}
	c := MqttClient{
		conn:      conn,
		connected: true,
		incoming:  make(chan mqttPacket),
		handler:   handler,
	}

	// listen for incoming packets
	go func(c *MqttClient) {
		for c.connected {
			packet, err := c.recvPacket()
			if err != nil {
				c.mu.Lock()
				isConnected := c.connected
				c.mu.Unlock()
				if !isConnected {
					// connection was closed, stop processing packets
					return
				} else {
					fmt.Printf("Error receiving packet: %s\n", err)
				}
			}

			if packet.type_ == PUBLISH {
				topic, topicLen := decString(packet.payload)
				text := string(packet.payload[topicLen:])
				go c.handler(topic, text)
			} else {
				c.incoming <- *packet
			}
		}
	}(&c)

	// send pings
	go func(c *MqttClient) {
		for c.connected {
			c.Ping()
			time.Sleep(10 * time.Second)
		}
	}(&c)

	err = c.sendConnect()
	if err != nil {
		return nil, err
	}

	return &c, nil
}

func (c *MqttClient) sendConnect() error {
	payload := make([]byte, 12)
	copy(payload[0:6], encString("MQTT"))         // protocol name
	payload[6] = 4                                // protocol level
	payload[7] = 0b00000010                       // connect flags (clean session)
	binary.BigEndian.PutUint16(payload[8:10], 30) // keep alive
	copy(payload[10:12], encString(""))           // client ID

	return c.requestResponse(mqttPacket{CONNECT, 0, payload}, CONNACK)
}

func (c *MqttClient) Publish(topic, text string) error {
	var payload []byte
	payload = append(payload, encString(topic)...)
	payload = append(payload, []byte(text)...)

	dup := byte(0 & 0b1)
	qos := byte(0 & 0b11)
	retain := byte(0 & 0b1)
	flags := (dup << 3) | (qos << 2) | retain

	packet := mqttPacket{PUBLISH, flags, payload}
	return c.sendPacket(packet)
}

func (c *MqttClient) Subscribe(topic string) error {
	payload := make([]byte, 2)
	packetIdentifier := uint16(1)
	binary.BigEndian.PutUint16(payload, packetIdentifier)
	payload = append(payload, encString(topic)...)
	requested_qos := byte(0)
	payload = append(payload, requested_qos)

	packet := mqttPacket{SUBSCRIBE, 0b0010, payload}
	return c.requestResponse(packet, SUBACK)
}

func (c *MqttClient) Ping() error {
	return c.requestResponse(mqttPacket{PINGREQ, 0, []byte{}}, PINGRESP)
}

func (c *MqttClient) Disconnect() error {
	c.mu.Lock()
	c.connected = false
	c.mu.Unlock()
	err := c.sendPacket(mqttPacket{DISCONNECT, 0, []byte{}})
	if err != nil {
		return err
	}
	return c.conn.Close()
}

func (c *MqttClient) requestResponse(req mqttPacket, respType byte) error {
	err := c.sendPacket(req)
	if err != nil {
		return err
	}

	resp := <-c.incoming
	if resp.type_ != respType {
		return fmt.Errorf("Invalid response type: %d", resp.type_)
	}

	return nil
}

func (c *MqttClient) sendPacket(packet mqttPacket) error {
	data := packetHeader(packet)
	data = append(data, packet.payload...)
	_, err := c.conn.Write(data)
	return err
}

func (c *MqttClient) recvPacket() (*mqttPacket, error) {
	buf := []byte{0}
	n, err := c.conn.Read(buf)
	if err != nil {
		return nil, err
	}
	if n != 1 {
		return nil, fmt.Errorf("Not enough header bytes")
	}
	type_ := buf[0] >> 4
	flags := buf[0] & 0xf

	length, err := readVarint(c.conn)
	if err != nil {
		return nil, err
	}

	payload := make([]byte, length)
	pos := 0
	for pos < int(length) {
		n, err = c.conn.Read(payload[pos:])
		if err != nil {
			return nil, err
		}
		pos += n
	}
	packet := mqttPacket{type_, flags, payload}

	return &packet, nil
}

func packetHeader(packet mqttPacket) []byte {
	buf := make([]byte, 1)
	header := (byte(packet.type_&0xf) << 4) | packet.flags
	buf[0] = byte(header)
	remainingLen := len(packet.payload)
	buf = append(buf, encVarint(uint(remainingLen))...)
	return buf
}

func encVarint(n uint) []byte {
	var buf []byte
	for {
		b := n % 0x80
		n /= 0x80
		if n > 0 {
			b |= 0x80
		}
		buf = append(buf, byte(b))
		if n == 0 {
			break
		}
	}
	return buf
}

func readVarint(conn net.Conn) (uint, error) {
	buf := make([]byte, 1)
	var val uint = 0
	var i uint = 0
	for {
		n, err := conn.Read(buf)
		if err != nil {
			return 0, err
		}
		if n != 1 {
			return 0, fmt.Errorf("Not enough bytes")
		}
		val |= uint(buf[0]&0x7f) << i
		if buf[0] <= 0x7f {
			break
		}
		i += 7
	}
	return val, nil
}

func encString(s string) []byte {
	encoded := []byte(s)
	buf := append([]byte{0, 0}, encoded...)
	binary.BigEndian.PutUint16(buf, uint16(len(encoded)))
	return buf
}

func decString(buf []byte) (string, uint) {
	len := binary.BigEndian.Uint16(buf)
	return string(buf[2 : len+2]), uint(len) + 2
}
