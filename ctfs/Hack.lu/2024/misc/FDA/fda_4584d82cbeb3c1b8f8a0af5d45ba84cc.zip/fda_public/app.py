#!/usr/bin/env python3
from flask import Flask, Response, render_template, request, session
from pathlib import Path
from random import randint
from secrets import token_hex, token_urlsafe
from socket import create_connection
from tempfile import TemporaryDirectory

app = Flask(__name__, static_url_path='/static', static_folder='static', template_folder='html')
app.secret_key = token_urlsafe(32)

storage = Path('pdf')
assert storage.is_dir(), 'PDF storage does not exist'

renderer_address = ('127.0.1.1', 1024)

main_tex = Path('tex/main.tex').read_text()
latexmkrc = Path('tex/latexmkrc').read_text()

def write_and_protect(path: Path, content: str | bytes):
    if isinstance(content, (bytes, bytearray, memoryview)):
        path.write_bytes(content)
    else:
        path.write_text(content)
    path.chmod(0o444)

@app.route('/')
def entrypoint():
    return render_template('form.html')

@app.route('/render', methods=['POST'])
def render():
    session['case'] = f'{randint(1337, 2137):05d}'

    bibtex = request.form['sources']
    if not bibtex:
        return render_template('message.html', message='No sources specified.'), 400

    with TemporaryDirectory(prefix='tex.') as temporary:
        temporary = Path(temporary)

        write_and_protect(temporary / 'main.tex', main_tex.replace('01337', session['case']))
        write_and_protect(temporary / '.latexmkrc', latexmkrc) # Not sure which one it picks
        write_and_protect(temporary / 'latexmkrc', latexmkrc)
        write_and_protect(temporary / 'sources.bib', bibtex)

        temporary.chmod(0o777)
        try:
            with create_connection(renderer_address) as ynetd_connection:
                ynetd_connection.settimeout(15)
                ynetd_connection.sendall(f'{temporary.resolve()}\n'.encode())
                status_code = int(ynetd_connection.recv(32).strip())
        except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError, OSError, TimeoutError):
            return render_template('message.html', message='Failed to render PDF.'), 400
        temporary.chmod(0o755)

        if status_code != 0:
            return render_template('message.html', message='Invalid sources specified.'), 400

        session['pdf'] = token_hex(16).lower()
        target = storage / session['pdf']
        try:
            raw_data = (temporary / 'main.pdf').read_bytes()
            if len(raw_data) > 524288:
                return render_template('message.html', message='PDF is too large.'), 400

            target.unlink(missing_ok=True)
            write_and_protect(target, raw_data)
        except:
            return render_template('message.html', message='Failed to save PDF.'), 400

    return render_template('verify.html', pdf='/pdf')

@app.route('/pdf')
def rendered_pdf():
    if 'pdf' not in session:
        return render_template('message.html', message='You have not submitted any sources yet.'), 404
    pdf = storage / session['pdf']
    if pdf.exists():
        return Response(pdf.read_bytes(), mimetype='application/pdf')
    else:
        session.clear()
        return render_template('message.html', message='Your session has expired'), 403

@app.route('/submit', methods=['POST'])
def submitted():
    if 'case' not in session or 'pdf' not in session:
        return render_template('message.html', message='You do not have a pending submission.'), 403
    case = session['case']
    pdf = storage / session['pdf']
    pdf.unlink(missing_ok=True)
    session.clear()
    return render_template('thank-you.html', case=case)


if __name__ == '__main__':
    app.run()
