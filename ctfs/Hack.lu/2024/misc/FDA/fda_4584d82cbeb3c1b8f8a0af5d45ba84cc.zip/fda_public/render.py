#!/usr/bin/env python3
from pathlib import Path
from subprocess import run

if __name__ == '__main__':
    # ynetd kills the environment sadly
    path = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin'
    try:
        directory = Path(input())
        assert directory.exists() and directory.is_dir()
        result = run(['latexmk'], capture_output=True, cwd=directory, env={'PATH': path, 'TMPDIR': f'{directory}'}, timeout=10)
        code = result.returncode
    except Exception as e:
        code = -1
    print(code)
