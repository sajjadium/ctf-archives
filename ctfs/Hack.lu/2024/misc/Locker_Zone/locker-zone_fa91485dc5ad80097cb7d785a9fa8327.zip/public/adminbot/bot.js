const puppeteer = require("puppeteer");




const sleep = ms => new Promise(r => setTimeout(r, ms));

const start = async (hostname, username, password, flag) => {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: 'new',
            args: [
                "--no-sandbox",
                "--disable-dev-shm-usage",
                "--disable-setuid-sandbox",
                "--js-flags=--noexpose_wasm,--jitless",
            ],
        });

        const page = await browser.newPage();


        await page.goto(hostname, { timeout: 7000, waitUntil: 'domcontentloaded' });
        await page.type('input[name="username"]', username);
        await page.type('input[name="password"]', password);

        await page.click('input[name="login"]');
        await sleep(1100);

        await page.evaluate((note) => {
            function submitAddForm(note) {
                var form = document.createElement("form");
                form.setAttribute("method", "post");
                form.setAttribute("action", "/add");
                for (const obj of [{name: "note", value: note}, {name: "date", value: parseInt(Date.now() / 1000)}, {name: "privileged", value: 1}]) {
                    var hiddenField = document.createElement("input");
                    hiddenField.setAttribute("type", "hidden");
                    hiddenField.setAttribute("name", obj.name);
                    hiddenField.setAttribute("value", obj.value);
                    form.appendChild(hiddenField);
                }
                document.body.appendChild(form);
                form.submit();
            }
            submitAddForm(note);

        }, flag);

        await sleep(1000);

        let hashval = await page.evaluate(() => window.location.hash)
        hashval = hashval.replace("#", "");

        await sleep(10_000);
        await page.evaluate((hashval) => {
            function submitDeleteForm(id) {
                var form = document.createElement("form");
                form.setAttribute("method", "post");
                form.setAttribute("action", "/delete");
                var hiddenField = document.createElement("input");
                hiddenField.setAttribute("type", "hidden");
                hiddenField.setAttribute("name", "id");
                hiddenField.setAttribute("value", id);
                form.appendChild(hiddenField);
                document.body.appendChild(form);
                form.submit();
            }
            submitDeleteForm(hashval);
        }, hashval);

        await sleep(2000);

        await browser.close();
    
        browser = null;
    } catch (err) {
        console.error(err);
    } finally {
        if (browser) {
            await browser.close();
        }
    }
};

const FLAG = process.env.FLAG || "flag{test_testflag}";
const GO_HOSTNAME= process.env.GO_HOSTNAME
const USERNAME = "admin"
const PASSWORD = process.env.USER_PW
start(GO_HOSTNAME, USERNAME, PASSWORD, FLAG);