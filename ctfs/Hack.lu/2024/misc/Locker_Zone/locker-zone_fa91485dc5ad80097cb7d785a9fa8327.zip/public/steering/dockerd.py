import docker, secrets, io
from threading import Thread
import time

import docker.errors

client = docker.from_env()

def ensure_images_ready(images):
    for image in images:
        try:
            client.images.get(image)
        except docker.errors.ImageNotFound:
            try:
                client.images.pull(image)
            except Exception as e:
                raise e
        except Exception as e:
            raise e
        

def run_container(image, name, timeout, **kwargs):
    container = client.containers.run(image=image, detach=True, hostname=name,name=name,**kwargs)
    try:
        container.wait(timeout=timeout)
    except Exception as e:
        print(e)
    finally:
        try:
            container.remove(force=True)
        except Exception as e:
            print(e)
def run_container_bg(image,timeout,given_name, **kwargs):
    name = given_name if given_name else "inst-"+secrets.token_urlsafe(20).replace("_","").lower()
    t = Thread(target=run_container, args=(image,name,timeout), kwargs=kwargs)
    t.start()
    return name
def create_net(timeout=None):
    net_name = "net-"+secrets.token_urlsafe(20).replace("_","").lower()
    try:
        client.networks.create(net_name)
    except Exception as e:
        print(e)
    if timeout:
        t = Thread(target=delete_net, args=(net_name,timeout,))
        t.start()
    return net_name
def delete_net(net_name, timeout=None):
    if timeout:
        time.sleep(timeout)
    try:
        client.networks.get(net_name).remove()
    except Exception as e:
        print(e)
def delete_container(container_name):
    try:
        client.containers.get(container_name).remove(force=True)
    except Exception as e:
        print(e)
def create_volume(timeout=None):
    vol_name = "vol-"+secrets.token_urlsafe(20).replace("_","").lower()
    try:
        client.volumes.create(vol_name)
    except Exception as e:
        print(e)
    if timeout:
        t = Thread(target=delete_volume, args=(vol_name,timeout,))
        t.start()
    return vol_name
def delete_volume(vol_name, timeout=None):
    if timeout:
        time.sleep(timeout)
    try:
        client.volumes.get(vol_name).remove(force=True)
    except Exception as e:
        print(e)
def fill_volume_with_tar(volume_name,tar_filename):
    docker_pseudo = io.BytesIO(b'FROM scratch\nLABEL empty=""')
    tmp_name = "tmp-"+secrets.token_urlsafe(20).replace("_","").lower()
    img = client.images.build(fileobj=docker_pseudo, tag=tmp_name)
    cont = client.containers.create(tmp_name, name=tmp_name, volumes={volume_name: {"bind": "/data", "mode": "rw"}}, command="cmd")
    with open(tar_filename, "rb") as f:
        cont.put_archive("/data", f.read())
    cont.remove(force=True)
    try:
        img[0].remove(force=True)
    except Exception as e:
        pass
def join_network(container_name, network_name,alias=None):
    aliases = None if not alias else [alias]
    try:
        client.networks.get(network_name).connect(container_name, aliases=aliases)
    except Exception as e:
        print(e)
def ensure_ext_network_ready(network_name):
    try:
        client.networks.get(network_name)
    except docker.errors.NotFound:
        try:
            client.networks.create(network_name, driver="bridge")
        except Exception as e:
            print(e)
def get_logs(container_name):
    cont = None
    try:
        cont = client.containers.get(container_name)
    except:
        return ""    
    return cont.logs().decode("utf-8")
def get_ip(container_name):
    cont = None
    try:
        cont = client.containers.get(container_name)
    except:
        return ""    
    nets = cont.attrs["NetworkSettings"]["Networks"]
    for net in nets:
        return nets[net]["IPAddress"]
def remove_stack(container_names, network_names, volume_names):
    for container in container_names:
        delete_container(container)
    for network in network_names:
        delete_net(network)
    for volume in volume_names:
        delete_volume(volume)
def get_net_count():
    return max(0,len(client.networks.list()) - 4)
def prune_nets():
    client.networks.prune()