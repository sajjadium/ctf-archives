import requests
import json
import base64
import sys
import secrets


def get_token(base_url, username, password):
    r = requests.post(base_url + "/realms/master/protocol/openid-connect/token", {
        "client_id": "admin-cli",
        "username": username,
        "password": password,
        "grant_type": "password"
    })
    at = r.json()["access_token"]
    userpart = at.split(".")[1]
    userobj = base64.b64decode(
        userpart + "=" * ((4 - len(userpart) % 4) % 4)).decode("utf-8")
    user = json.loads(userobj)
    return at, user["sub"]


def create_realm(base_url, at):
    r = requests.post(base_url + "/admin/realms", json={
        "realm": "notes",
        "enabled": True
    }, headers={"Authorization": "Bearer " + at})
    return r.status_code == 201


def edit_realm(base_url, at):
    r0 = requests.get(base_url + "/admin/realms/notes",
                      headers={"Authorization": "Bearer " + at})
    fields = r0.json()
    fields["registrationAllowed"] = True
    fields["registrationEmailAsUsername"] = False
    r = requests.put(base_url + f"/admin/realms/notes",
                     json=fields, headers={"Authorization": "Bearer " + at})
    return r.status_code == 204


def edit_realm_profile(base_url, at):
    bdy = {"attributes": [{"name": "username", "displayName": "${"+"username}", "validations": {"length": {"min": 3, "max": 255}, "username-prohibited-characters": {}, "up-username-not-idn-homograph": {}}, "permissions": {"view": ["admin", "user"], "edit": ["admin", "user"]}, "multivalued": False}, {"name": "email", "displayName": "${"+"email}", "validations": {"email": {}, "length": {"max": 255}}, "annotations": {}, "permissions": {"view": [], "edit": []}, "multivalued": False}, {"name": "firstName", "displayName": "${"+"firstName}", "validations": {"length": {
        "max": 255}, "person-name-prohibited-characters": {}}, "permissions": {"edit": [], "view": []}, "multivalued": False, "selector": {"scopes": []}, "annotations": {}, "group": None}, {"name": "lastName", "displayName": "${"+"lastName}", "validations": {"length": {"max": 255}, "person-name-prohibited-characters": {}}, "annotations": {}, "permissions": {"view": [], "edit": []}, "selector": {"scopes": []}, "multivalued": False}], "groups": [{"name": "user-metadata", "displayHeader": "User metadata", "displayDescription": "Attributes, which refer to user metadata"}]}
    r = requests.put(base_url + f"/admin/realms/notes/users/profile",
                     json=bdy, headers={"Authorization": "Bearer " + at})
    return r.status_code == 200


def create_client(base_url, at, redir_url, internal_redir):
    fields = {"protocol": "openid-connect", "clientId": "notes", "name": "", "description": "", "publicClient": False, "authorizationServicesEnabled": True, "serviceAccountsEnabled": True, "implicitFlowEnabled": False, "directAccessGrantsEnabled": False, "standardFlowEnabled": True,
              "frontchannelLogout": True, "attributes": {"saml_idp_initiated_sso_url_name": "", "oauth2.device.authorization.grant.enabled": False, "oidc.ciba.grant.enabled": False}, "alwaysDisplayInConsole": False, "rootUrl": "", "baseUrl": "", "redirectUris": [redir_url, internal_redir]}
    r = requests.post(base_url + "/admin/realms/notes/clients",
                      json=fields, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 201
    return r.headers["Location"].split("/")[-1]


def get_client_secret(base_url, at, client_uuid):
    r = requests.get(base_url + f"/admin/realms/notes/clients/{
                     client_uuid}/client-secret", headers={"Authorization": "Bearer " + at})
    assert r.status_code == 200
    return r.json()["value"]


def add_realm_role(base_url, at):
    fields = {"name": "bigboss", "description": "", "attributes": {}}
    r = requests.post(base_url + "/admin/realms/notes/roles",
                      json=fields, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 201


def make_client_scope(base_url, at):
    fields = {"name": "privileged", "description": "", "type": "none", "protocol": "openid-connect", "attributes": {
        "display.on.consent.screen": "true", "consent.screen.text": "", "include.in.token.scope": "false", "gui.order": ""}}
    r = requests.post(base_url + "/admin/realms/notes/client-scopes",
                      json=fields, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 201
    scope_id = r.headers["Location"].split("/")[-1]
    fields_mappers = {"protocol": "openid-connect", "protocolMapper": "oidc-hardcoded-claim-mapper", "name": "privileged", "config": {"claim.name": "privileged", "claim.value": "1", "jsonType.label": "int",
                                                                                                                                      "id.token.claim": "true", "access.token.claim": "true", "lightweight.claim": "false", "userinfo.token.claim": "true", "access.tokenResponse.claim": "false", "introspection.token.claim": "true"}}
    r2 = requests.post(base_url + f"/admin/realms/notes/client-scopes/{
                       scope_id}/protocol-mappers/models", json=fields_mappers, headers={"Authorization": "Bearer " + at})
    assert r2.status_code == 201
    return scope_id


def map_realm_role(base_url, at, scope_id):
    r0 = requests.get(base_url + "/admin/realms/notes/roles/bigboss",
                      headers={"Authorization": "Bearer " + at})
    role_id = r0.json()["id"]
    container_id = r0.json()["containerId"]
    fields = [{"id": role_id, "name": "bigboss", "description": "",
               "composite": False, "clientRole": False, "containerId": container_id}]
    r = requests.post(base_url + f"/admin/realms/notes/client-scopes/{
                      scope_id}/scope-mappings/realm", json=fields, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 204


def map_client_scope(base_url, at, client_uuid, scope_id):
    r = requests.put(base_url + f"/admin/realms/notes/clients/{client_uuid}/default-client-scopes/{
                     scope_id}", {}, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 204


def create_admin_user(base_url, at, new_pw):
    fields = {"attributes": {"locale": ""}, "requiredActions": [], "emailVerified": False,
              "username": "admin", "email": "", "groups": [], "enabled": True}
    r0 = requests.post(base_url + "/admin/realms/notes/users",
                       json=fields, headers={"Authorization": "Bearer " + at})
    assert r0.status_code == 201
    user_uuid = r0.headers["Location"].split("/")[-1]
    r = requests.put(base_url + f"/admin/realms/notes/users/{user_uuid}/reset-password", json={
                     "type": "password", "value": new_pw, "temporary": False}, headers={"Authorization": "Bearer " + at})
    assert r.status_code == 204


def init_kc(base_url, admin_pw, redir_url, internal_redir):
    at, uid = get_token(base_url, "admin", admin_pw)
    assert create_realm(base_url, at)
    assert edit_realm(base_url, at)
    assert edit_realm_profile(base_url, at)
    client_uuid = create_client(base_url, at, redir_url, internal_redir)
    client_secret = get_client_secret(base_url, at, client_uuid)
    add_realm_role(base_url, at)
    scope_id = make_client_scope(base_url, at)
    map_realm_role(base_url, at, scope_id)
    map_client_scope(base_url, at, client_uuid, scope_id)
    new_user_pw = secrets.token_urlsafe(50)
    create_admin_user(base_url, at, new_user_pw)
    return {
        "user_password": new_user_pw,
        "client_secret": client_secret
    }
