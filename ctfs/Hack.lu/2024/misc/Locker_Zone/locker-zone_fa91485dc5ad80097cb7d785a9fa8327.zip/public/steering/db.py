import threading
import sqlite3, time
import dockerd
import multiprocessing
import hafenmeister


lock = multiprocessing.Lock()

def init_db():
    con = sqlite3.connect("/tmp/sessions.db")

    with con:
        con.execute("CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY, sid TEXT, nonce TEXT, created_at INTEGER, network TEXT, kc TEXT, go TEXT, db TEXT, volume2 TEXT, userpw TEXT, adminpw TEXT)")
        con.execute("CREATE TABLE IF NOT EXISTS teams (id INTEGER PRIMARY KEY, teamid TEXT, last_start INTEGER, last_bot INTEGER, queued INTEGER, tar_path TEXT)")
    con.commit()
    con.close()
def get_db():
    return sqlite3.connect("/tmp/sessions.db")


def register_start(teamid):
    con = get_db()

    with con:
        cur = con.execute("SELECT * FROM teams WHERE teamid=?", (teamid,))
        vals = cur.fetchone()
    if not vals:
        con.execute("INSERT INTO teams (teamid, last_start, last_bot, queued, tar_path) VALUES (?,?,?,?,?)", (teamid, int(time.time()),0,int(time.time()),""))
        con.commit()

        return True, ""
    
    if vals[2] != 0 and int(time.time()) - vals[2] < 60*5:
        return False, "You recently started a session. Please wait 5 minutes before starting another."
    if vals[4] != 0:
        return False, "Already in queue. Please wait a bit. Currently high demand. If you wait longer than 10 mins, create ticket"
    else:
        con.execute("UPDATE teams SET last_start=?, queued=? WHERE teamid=?", (int(time.time()), int(time.time()), teamid))
        con.commit()
        return True, ""
def add_tar_path(teamid, tar_path):
    con = get_db()

    with con:
        con.execute("UPDATE teams SET tar_path=? WHERE teamid=?", (tar_path, teamid))
    con.commit()
def pop_queue():
    con = get_db()

    with con:
        lock.acquire()
        currently_running = dockerd.get_net_count()
        if currently_running >= hafenmeister.MAX_PARALLEL:
            lock.release()
            return None
        cur = con.execute("SELECT * FROM teams WHERE queued != 0 ORDER BY queued ASC")
        pending = cur.fetchall()
        if len(pending) == 0:
            lock.release()
            return None
        con.execute("UPDATE teams SET queued=0, tar_path=? WHERE teamid=?", ("",pending[0][1],))
        con.commit()
        lock.release()
        t = threading.Thread(target=hafenmeister.run_keycloak, args=(pending[0][1],pending[0][5],))
        t.start()
    

def register_bot(teamid):
    con = get_db()

    with con:
        cur = con.execute("SELECT * FROM teams WHERE teamid=?", (teamid,))
        vals = cur.fetchone()
    if not vals:
        return False
    if vals[3] != 0 and int(time.time()) - vals[3] < 60:
        return False
    else:
        con.execute("UPDATE teams SET last_bot=? WHERE teamid=?", (int(time.time()), teamid))
        con.commit()
        return True

    
def new_session(sid,nonce, network, kc, go,db, volume2, userpw, adminpw):
    con = get_db()

    nowtime = int(time.time())
    with con:
        con.execute("INSERT INTO sessions (sid, nonce, created_at, network, kc, go, db, volume2, userpw, adminpw) VALUES (?,?,?,?,?,?,?,?,?,?)", (sid,nonce,nowtime, network, kc, go,db, volume2, userpw, adminpw))
    con.commit()

def get_session(sid):
    con = get_db()
    with con:
        cur = con.cursor()
        cur.execute(f"SELECT * FROM sessions WHERE sid=?", (sid,))
        vals = cur.fetchone()
    if vals is None:
        return None
    vals = dict(zip(["id", "sid","nonce", "created_at", "network", "kc", "go", "db", "volume2", "userpw", "adminpw"], vals))
    return vals
def delete_session(sid, nonce,after=None):
    con = get_db()

    if after:
        time.sleep(after)
    old_sess = get_session(sid)
    if old_sess and (after == None or old_sess["nonce"] == nonce):
        try:
            dockerd.remove_stack(
                [old_sess["kc"], old_sess["db"], old_sess["go"]],
                [old_sess["network"]],
                [old_sess["volume2"]])
        except Exception as e:
            pass
    with con:
        con.execute("DELETE FROM sessions WHERE sid=?", (sid,))
    con.commit()
    dockerd.prune_nets()
    pop_queue()

