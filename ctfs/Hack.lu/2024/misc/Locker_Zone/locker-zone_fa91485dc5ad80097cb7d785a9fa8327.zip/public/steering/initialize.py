import dockerd
import hafenmeister
import db

def init_app():
    dockerd.ensure_images_ready([hafenmeister.ALL_IMAGES["keycloak"], hafenmeister.ALL_IMAGES["postgres"], hafenmeister.ALL_IMAGES["goapp"], hafenmeister.ALL_IMAGES["adminbot"]])
    print("All images are ready")
    db.init_db()
    print("DB initialized")
init_app()