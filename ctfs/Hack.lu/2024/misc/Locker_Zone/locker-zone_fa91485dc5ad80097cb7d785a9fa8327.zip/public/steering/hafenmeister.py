import dockerd
import secrets
import time
import requests
import db
import threading
import os
from keycloaker import init_kc
ALL_IMAGES= {"keycloak": "quay.io/keycloak/keycloak:25.0.2@sha256:b55f55ff60e905db4809ac133c6b963b87963ec1b49aae6d218fdd53646cb09e",
             "postgres": "postgres:15.4-alpine@sha256:35ce2187f2f7fb75e8e79493e13743596c21eb3789ff41ece145ae04d06e93a5",
             "goapp": os.getenv("GOAPP_IMAGE"),"adminbot": os.getenv("ADMINBOT_IMAGE")}

TIMEOUT_ALL = int(os.getenv("TIMEOUT",60*15)) # 15 minutes
PUBLIC_HOST = os.getenv("PUBLIC_HOST", ".locker.ctf.test")
MAX_PARALLEL = int(os.getenv("MAX_PARALLEL", 5))

def run_keycloak(sessionid, firmware_tar=None):
    new_net = dockerd.create_net()
    nonce = secrets.token_hex(20)
    t0 = threading.Thread(target=db.delete_session, args=(sessionid,nonce,TIMEOUT_ALL,))
    t0.start()

    master_admin_pw = secrets.token_urlsafe(50)
    postgres_db_passwd = secrets.token_urlsafe(50)
    kc_hostname = "kc-"+secrets.token_urlsafe(20).replace("_","").lower() if os.getenv("FORCE_KC_HOSTNAME", "unset") == "unset" else os.getenv("FORCE_KC_HOSTNAME")
    go_hostname = "go-"+secrets.token_urlsafe(20).replace("_","").lower() if os.getenv("FORCE_GOAPP_HOSTNAME", "unset") == "unset" else os.getenv("FORCE_GOAPP_HOSTNAME")


    db_name = dockerd.run_container_bg(ALL_IMAGES["postgres"], TIMEOUT_ALL, None,network=new_net,environment={"POSTGRES_PASSWORD": postgres_db_passwd,"POSTGRES_USER":"keycloak","POSTGRES_DATABASE":"keycloak"})
    provider_volume = None
    volumes = {}
    if firmware_tar and firmware_tar != "":
        provider_volume = dockerd.create_volume()
        volumes = {provider_volume: {"bind": "/opt/keycloak/providers", "mode": "ro"}}
        dockerd.fill_volume_with_tar(provider_volume, firmware_tar)
        os.unlink(firmware_tar)

    _cont = dockerd.run_container_bg(ALL_IMAGES["keycloak"], TIMEOUT_ALL, kc_hostname,network=new_net,
                                       environment={
                                            "KEYCLOAK_ADMIN":"admin",
                                            "KEYCLOAK_ADMIN_PASSWORD":master_admin_pw,
                                            "PROXY_ADDRESS_FORWARDING":"true",
                                            "VIRTUAL_HOST":f"{kc_hostname}{PUBLIC_HOST}",
                                            "VIRTUAL_PORT":"8080",
                                            "KC_DB_PASSWORD":postgres_db_passwd,
                                            "KC_DB":"postgres",
                                            "KC_DB_SCHEMA":"public",
                                            "KC_DB_URL":f"jdbc:postgresql://{db_name}:5432/keycloak",
                                            "KC_DB_USER":"keycloak",
                                            "KC_HOSTNAME":f"https://{kc_hostname}{PUBLIC_HOST}",
                                            "KC_PROXY_HEADERS": "xforwarded",
                                            "KC_HTTP_ENABLED":"true",
                                            "KC_HOSTNAME_STRICT": "false"
                                       },
                                        labels={
                                           "traefik.enable":"true",
                                           f"traefik.http.routers.{kc_hostname}.rule":"Host(`"+kc_hostname+PUBLIC_HOST+"`)",
                                           f"traefik.http.routers.{kc_hostname}.entrypoints":"websecure" if PUBLIC_HOST == ".locker.zone.re" else "web",
                                           f"traefik.http.routers.{kc_hostname}.service":kc_hostname,
                                           f"traefik.http.services.{kc_hostname}.loadbalancer.server.port":"8080",
                                           "traefik.docker.network":new_net,
                                        },
                                        nano_cpus=int(float(os.getenv("LIMIT_CPU", "0.3")) * 1e9) if os.getenv("LIMIT_CPU", "unset") != "unset" else None,
                                        mem_limit=os.getenv("LIMIT_MEM", "512m") if os.getenv("LIMIT_MEM", "unset") != "unset" else None,
                                       entrypoint=["/bin/sh"],
                                       volumes=volumes,
                                       command=["-c", f'sleep 8\necho -e "features=admin-fine-grained-authz" > /opt/keycloak/conf/keycloak.conf\n/opt/keycloak/bin/kc.sh build\n/opt/keycloak/bin/kc.sh start --log-level=DEBUG\n'],
    )
    print("created keycloak", kc_hostname)
    time.sleep(7)
    worked = False
    for i in range(60 * 5):
        try:
            lgs = dockerd.get_logs(kc_hostname)
            if "Management interface listening on" in lgs:
                worked = True
                break
            else:
                time.sleep(1)
        except Exception as e:
            time.sleep(1)
    if not worked:
        raise Exception("Keycloak did not start")
    print("keycloak started", kc_hostname)
    
    dockerd.join_network("traefik", new_net)
    time.sleep(1)

    new_redirect_uri = f"https://{go_hostname}{PUBLIC_HOST}/callback"
    new_redirect_uri_internal = f"http://{go_hostname}:4444/callback"

    print("running updater")


    new_secrets = init_kc(f"https://{kc_hostname}{PUBLIC_HOST}",master_admin_pw, new_redirect_uri, new_redirect_uri_internal)
    print("updated secrets")

    realm_user_password = new_secrets["user_password"]
    go_name = dockerd.run_container_bg(ALL_IMAGES["goapp"], TIMEOUT_ALL, go_hostname, network=new_net,
                                       environment={
                                             "CALLBACK_URL":new_redirect_uri,
                                             "CALLBACK_URL_INTERNAL":new_redirect_uri_internal,
                                             "CLIENT_ID":"notes",
                                             "CLIENT_SECRET": new_secrets["client_secret"],
                                             "OIDC_PROVIDER_URL":f"https://{kc_hostname}{PUBLIC_HOST}/realms/notes",
                                             "SESSION_KEY":secrets.token_urlsafe(40),
                                             "DB_PATH":"/tmp/db.db"
                                        },
                                         labels={
                                           "traefik.enable":"true",
                                           f"traefik.http.routers.{go_hostname}.rule":"Host(`"+go_hostname+PUBLIC_HOST+"`)",
                                           f"traefik.http.routers.{go_hostname}.entrypoints":"websecure" if PUBLIC_HOST == ".locker.zone.re" else "web",
                                           f"traefik.http.routers.{go_hostname}.service":go_hostname,
                                           f"traefik.http.services.{go_hostname}.loadbalancer.server.port":"4444",
                                           "traefik.docker.network":new_net,
                                        },
    )
    time.sleep(4)
    db.new_session(sessionid,nonce,new_net,kc_hostname,go_name,db_name,provider_volume if provider_volume else "",realm_user_password,master_admin_pw)

    
