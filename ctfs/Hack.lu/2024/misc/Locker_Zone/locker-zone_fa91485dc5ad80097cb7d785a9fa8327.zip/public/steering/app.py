
import dockerd
import hafenmeister
import os
import db
from flask import Flask,render_template, session, redirect, request, flash, send_file
import secrets
import webutils, threading
import tarfile
import re





app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY")
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024


def make_firmware_tar(firmware_path):
    tar_path = "/tmp/" + secrets.token_hex(20)+".tar"
    with tarfile.open(tar_path, "w") as tar:
        tar.add(firmware_path, arcname=os.path.basename(firmware_path))
    return tar_path
    
def run_adminbot(netname, admin_host, userpw):
    container = dockerd.run_container_bg(hafenmeister.ALL_IMAGES["adminbot"], 60*5, None, network=netname,
            environment={"GO_HOSTNAME": f"http://{admin_host}:4444", "USER_PW": userpw, "FLAG": os.environ.get("FLAG", "flag{fakeflag}")}
    )



@app.route("/locker.jpg")
def locker(): return send_file("assets/locker.jpg")

@app.route("/")
def mainRoute():
    if not session or session.get("teamid", None) is None:
        return redirect("/login")
    details = {
        "kc_url": "",
        "go_url": "",
        "started_at": 0,
        "ends_at": 0,
    }
    curr = db.get_session(session["teamid"])
    if curr is not None:
        details["kc_url"] = f'https://{curr["kc"]}{hafenmeister.PUBLIC_HOST}'
        details["go_url"] = f'https://{curr["go"]}{hafenmeister.PUBLIC_HOST}'
        details["started_at"] = curr["created_at"]
        details["ends_at"] = curr["created_at"] + hafenmeister.TIMEOUT_ALL
    return render_template("index.html", details=details)


def check_testing():
    testing_token = request.args.get("testing_token", "")
    if testing_token == os.getenv("TESTING_TOKEN", "") and len(testing_token) > 29:
        return True
    return False


@app.route("/login", methods = ["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    if request.method == "POST":
        team_token = request.form.get("team_token", None)
        captcha_response = request.form.get("cf-turnstile-response", None)
        is_testing = check_testing()
        if not webutils.verify_captcha(captcha_response) and not is_testing:
            return "Invalid captcha", 403
        success, teamid = webutils.verify_hmac(team_token, is_testing)
        if not success:
            return "Invalid team token", 403
        session["teamid"] = teamid
        return redirect("/")

@app.route("/stop", methods=["POST"])
def stop_deployment():
    if not session or session.get("teamid", None) is None:
        return redirect("/login")
    curr = db.get_session(session["teamid"])
    if curr is None:
        flash("No deployment to stop")
    else:
        db.delete_session(session["teamid"], curr["nonce"])
        flash("Deployment stopped")    
    return redirect("/")

@app.route("/start", methods=["POST"])
def start_deployment():
    if not session or session.get("teamid", None) is None:
        return redirect("/login")
    curr = db.get_session(session["teamid"])
    if curr is not None:
        flash("Stop running deployment first")
        return redirect("/")
    captcha_response = request.form.get("cf-turnstile-response", None)
    is_testing = check_testing()
    if not webutils.verify_captcha(captcha_response) and not is_testing:
        return "Invalid captcha", 403
    allowed, msg = db.register_start(session["teamid"])
    if not allowed:
        flash(msg)
        return redirect("/")

    fw_file = request.files.get("firmware", None)
    tar_path = None
    if fw_file:
        if not fw_file.filename.endswith(".jar"):
            flash("Invalid file")
            return redirect("/")
        new_filename = f"/tmp/"+secrets.token_hex(20)+".jar"
        fw_file.save(new_filename)
        tar_path = make_firmware_tar(new_filename)
        os.unlink(new_filename)
        db.add_tar_path(session["teamid"], tar_path)
    
    db.pop_queue()
    flash("Deployment started, please wait some minutes. You are queued...")
    return redirect("/#loading")


@app.route("/bot", methods=["POST"])
def adminbot():
    if not session or session.get("teamid", None) is None:
        return redirect("/login")
    curr = db.get_session(session["teamid"])
    if curr is None:
        flash("No deployment running")
        return redirect("/")
    captcha_response = request.form.get("cf-turnstile-response", None)
    is_testing = check_testing()
    if not webutils.verify_captcha(captcha_response) and not is_testing:
        return "Invalid captcha", 403
    if not db.register_bot(session["teamid"]):
        flash("ratelimited, wait a bit")
        return redirect("/")
    admin_host = curr["go"]
    userpw = curr["userpw"]
    netname = curr["network"]
    t = threading.Thread(target=run_adminbot, args=(netname,admin_host,userpw,))
    t.start()
    flash("Bot started, please wait 1-2 minutes...")
    return redirect("/")
# import initialize
# initialize.init_app()
# app.run(host="0.0.0.0", port=5000, threaded=True)
