import requests, os
import hmac
import hashlib
import base64, secrets

def verify_captcha(response):
    if not response:
        return False
    r = requests.post("https://challenges.cloudflare.com/turnstile/v0/siteverify", data={
        "secret": os.getenv("CAPTCHA_SECRET"),
        "response": response
    })
    return r.json()["success"]

# hmacs the unique team id
def verify_hmac(sig_str, is_testing = False):
    if is_testing:
        return True, sig_str
    try:
        data, signature = sig_str.split(":")
        h = hmac.new(os.getenv("HMAC_SECRET").encode(), data.encode(), hashlib.sha256)
        return hmac.compare_digest(h.hexdigest(), signature), data
    except:
        return False, None