import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Card } from 'primereact/card';
import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import { InputText } from 'primereact/inputtext';
import 'primereact/resources/themes/saga-blue/theme.css';
import { Nullable } from 'primereact/ts-helpers';
import React, { useEffect, useState } from 'react';

declare global {
  interface Window {
      NOTES:any;
  }
}
type NoteItem = {
  date: number;
  note: string;
  created: number;
  id: string;

}

function useOutsideAlerter(ref:any, dispatcher: React.Dispatch<any>) {
  useEffect(() => {
    function handleClickOutside(event:any) {
      if (ref.current && !ref.current.contains(event.target)) {
        dispatcher(null)
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [ref]);
}
export default function App() {


  const [visible, setVisible] = useState(false);
  const [date, setDate] = useState<Nullable<Date>>(new Date());
  const items = window.NOTES as NoteItem[]
  function renderItems(items:NoteItem[], sort_order:number) {
    return items.sort((a,b) => {
      if(sort_order === 1) {
        return b.created - a.created
      } else {
        return a.date - b.date
      }
      
    }).map((item) => {
      return {
        date: Intl.DateTimeFormat("en-US",  {month: "short", day: "2-digit", year: "numeric", weekday: "short"}).format(new Date(item.date * 1000)),
        note: item.note,
        created: Intl.DateTimeFormat("en-US",  {month: "short", day: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit"}).format(new Date(item.created * 1000)),
        id: item.id,
        expired: item.date < Math.floor(Date.now() / 1000),
  
      }
    })
  }
  const [items_rendered, setItemsRendered] = useState<any[]>(renderItems(items, 1))
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const wrapperRef = React.useRef(null);
  const [sortOrder, setSortOrder] = useState<0 | 1 | -1>(1)
  useOutsideAlerter(wrapperRef, setSelectedItem);
  return (
    <>
    <div className='container mb-8'>
    <div className="d-flex justify-content-center p-4">
        <h2 className="m-0">Notes</h2>
    </div>
    <form action="/add" method="post">

    <div className="row justify-content-center">
    <Card title="New Note" className='col-md-6'>
    <span className="d-block mb-2">Note:</span>

    <InputText name="note" required placeholder="Here..." className="mb-4" />
    <span className="d-block mb-2">Date:</span>
    <input type="hidden" name="date" value={date ? Math.floor(date?.getTime() / 1000) : undefined} />
    <Calendar placeholder='Select date...' dateFormat='dd. M yy' locale="en" className="col-sm-5" value={date} onChange={(e) => setDate(e.value)} />
    <div className="float-end mt-6 mb-4 d-block">
    <Button type='submit' className="mt-5 float-end text-center" label="Add" severity="success" />

    </div>

    </Card>
    
    </div>
    </form>
   
    <div className="f-flex justify-content-center">
    <div className="row justify-content-center">
    <Card title="Notes" className='col-md-10 mt-6'>
    <div ref={wrapperRef}>
    <DataTable sortOrder={sortOrder} onSort={(e) => { setSortOrder(sortOrder === 1 ? -1 : 1);setItemsRendered(renderItems(items,sortOrder === 1 ? -1 : 1))}} selectionMode="single" metaKeySelection={false} selection={selectedItem} onSelectionChange={(e) => setSelectedItem(e.value)} dataKey="id" stripedRows value={items_rendered} tableStyle={{ minWidth: '50rem' }}>
    
    <Column className='col-3' sortable field="date" body={(data) => {
      return(
        <div>
        <div className={data.expired ? "text-danger": ""}>{data.date}</div>
        <small className='text-secondary'>Created: {data.created}</small>
        </div>
      )
    }} header={sortOrder === -1 ? 'Due' : 'Created'}></Column>
    <Column align={"left"} field="note" header="Item" className='fs-5' body={(data) => {
      return (
        //@ts-ignore
        <div dangerouslySetInnerHTML={{__html: typeof DOMPurify !== 'undefined' ? DOMPurify.sanitize(data.note) : data.note}}></div>
      )
    }}></Column>
  </DataTable>



    {selectedItem && <div className=''>
      <form action="/delete" method="post">
        <input type="hidden" name="id" value={selectedItem.id!} />
      <button className="mt-5 text-center btn btn-danger btn-md" >Delete</button>

      </form>
    </div>}
    </div>
    </Card>
    </div>
    </div>
    </div>
    

    </>
  );
}
