import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { PrimeReactProvider, addLocale } from 'primereact/api';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'primeflex/primeflex.css';
import Bootstrap_PT from './passthrough/bootstrap';
import App from './App';

const root = createRoot(document.getElementById('root')!);

addLocale("en", {
  firstDayOfWeek: 1,
  dayNames: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
  dayNamesShort: ["Su","Mo","Tu","We","Th","Fr","Sa"],
  dayNamesMin: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
  monthNames: ["Januar","Februar","March","April","May","June","July","August","September","October","November","December"],
  monthNamesShort: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
  today: 'Today',
  clear: 'Delete',
  dateFormat: 'mm/dd/yy',
  weekHeader: 'KW'
})

root.render(
  <StrictMode>
    <PrimeReactProvider value={{ unstyled: false, pt: Bootstrap_PT }}>
      <App />
    </PrimeReactProvider>
  </StrictMode>
);
