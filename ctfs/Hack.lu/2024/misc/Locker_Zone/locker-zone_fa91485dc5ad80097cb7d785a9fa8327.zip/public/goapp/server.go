package main

import (
	"context"
	"encoding/json"
	"fmt"
	"html/template"
	"log"
	"net/http"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"time"

	"git.domain.tld/noteweb/libs"
	"github.com/google/uuid"
	"github.com/joho/godotenv"
)

type templateData struct {
	Notes string
}

func renderTasks(w http.ResponseWriter, tmpl template.Template, notes []libs.Event) error {
	notes_json, err := json.Marshal(notes)
	if err != nil {
		return err
	}
	notes_txt := string(notes_json)
	if notes_txt == "null" {
		notes_txt = "[]"
	}

	notes_tmpl := templateData{Notes: notes_txt}
	err = tmpl.Execute(w, notes_tmpl)
	if err != nil {
		return err
	}
	return nil
}

func main() {
	if _, err := os.Stat(".env"); err == nil {
		err := godotenv.Load()
		if err != nil {
			log.Println("Error loading .env file")
		}
	}
	mux := http.NewServeMux()
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	go func() {
		<-ctx.Done()
		stop()
		<-ctx.Done()
		os.Exit(1)
	}()
	oauth2Config, oauth2ConfigInternal, store, vrfyer, err := libs.MakeProvider(ctx)
	if err != nil {
		log.Fatal(err)
		return
	}
	tmpl := template.Must(template.ParseFiles("build/index.html"))
	db := libs.Connect()
	libs.InitDB(db)

	addHandler := func(w http.ResponseWriter, r *http.Request, sess libs.SessionUser) {
		if r.Method == "POST" {
			r.ParseForm()
			start_date, err := strconv.ParseInt(r.FormValue("date"), 10, 64)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			privileged := int64(0)
			if r.FormValue("privileged") != "" {
				privileged, err = strconv.ParseInt(r.FormValue("privileged"), 10, 64)
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
			}

			new_id := uuid.New().String()
			evnt := libs.Event{
				ID:         new_id,
				Note:       r.FormValue("note"),
				Start:      time.Unix(start_date, 0).Add(time.Hour * 8).Unix(),
				Created:    time.Now().Unix(),
				UserID:     sess.UserID,
				Privileged: privileged,
				Ip:         strings.Split(r.RemoteAddr, ":")[0],
			}
			err = libs.InsertEvent(db, evnt)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}
			http.Redirect(w, r, "/#"+new_id, http.StatusSeeOther)
			return
		} else {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
	}
	deleteHandler := func(w http.ResponseWriter, r *http.Request, sess libs.SessionUser) {
		if r.Method == "POST" {
			r.ParseForm()
			idval := r.FormValue("id")

			err := libs.DeleteEvent(db, sess.UserID, idval)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				return
			}

			http.Redirect(w, r, "/", http.StatusSeeOther)
			return
		} else {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
	}

	indexHandler := func(w http.ResponseWriter, r *http.Request) {

		session, err := store.Get(r, "auth-notes")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		SessionUser := libs.SessionUser{
			UserID:     session.Values["user_id"].(int64),
			Privileged: session.Values["privileged"].(int64),
			Ip:         strings.Split(r.RemoteAddr, ":")[0],
		}

		if r.URL.Path == "/add" {
			addHandler(w, r, SessionUser)
			return
		}
		if r.URL.Path == "/delete" {
			deleteHandler(w, r, SessionUser)
			return
		}
		notes, err := libs.GetEvents(db, SessionUser)
		if err != nil {
			log.Fatal(err)
			return
		}
		if session.Values["privileged"].(int64) == 1 {
			w.Header().Set("Content-Security-Policy", "script-src 'self' 'unsafe-inline'")
		}

		err = renderTasks(w, *tmpl, notes)
		if err != nil {
			log.Fatal(err)
		}
	}
	mux.HandleFunc("/callback", func(w http.ResponseWriter, r *http.Request) {
		libs.CallbackRoute(w, r, oauth2Config, oauth2ConfigInternal, store, vrfyer, db)
	})

	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("build/static"))))
	mux.Handle("/img/", http.StripPrefix("/img/", http.FileServer(http.Dir("build/img"))))
	mux.Handle("/favicon.ico", http.FileServer(http.Dir("build/")))

	mux.Handle("/", libs.AuthHandler(http.HandlerFunc(indexHandler), oauth2Config, oauth2ConfigInternal, store))

	fmt.Println("Starting server at port 4444")
	log.Fatal(http.ListenAndServe(":4444", mux))
}
