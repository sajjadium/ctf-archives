package libs

import (
	"database/sql"
	"os"

	_ "github.com/mattn/go-sqlite3"
)

type Event struct {
	ID         string `json:"id"`
	Start      int64  `json:"date"`
	Note       string `json:"note"`
	Created    int64  `json:"created"`
	UserID     int64  `json:"user_id"`
	Privileged int64  `json:"privileged"`
	Ip         string `json:"ip"`
}
type User struct {
	ID   int64  `json:"id"`
	KCID string `json:"kcid"`
}
type SessionUser struct {
	UserID     int64
	Privileged int64
	Ip         string
}

func Connect() *sql.DB {
	db_path, empty := os.LookupEnv("DB_PATH")
	if !empty {
		db_path = "/data/notes.db"
	}
	db, err := sql.Open("sqlite3", db_path)
	if err != nil {
		panic(err)
	}
	return db
}
func InitDB(db *sql.DB) {
	_, err := db.Exec("CREATE TABLE IF NOT EXISTS notes (id TEXT PRIMARY KEY, date INTEGER, note TEXT, created INTEGER, user_id INTEGER, privileged INTEGER DEFAULT 0, ip TEXT)")
	if err != nil {
		panic(err)
	}
	_, err = db.Exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, kcid TEXT)")
	if err != nil {
		panic(err)
	}
}
func GetUser(db *sql.DB, kcid string) (User, error) {
	var user User
	err := db.QueryRow("SELECT id, kcid FROM users WHERE kcid=?", kcid).Scan(&user.ID, &user.KCID)
	if err != nil {
		return User{}, err
	}
	return user, nil
}
func InsertUser(db *sql.DB, kcid string) (int64, error) {
	stmt, err := db.Prepare("INSERT INTO users(kcid) values(?)")
	if err != nil {
		return 0, err
	}
	res, err := stmt.Exec(kcid)
	if err != nil {
		return 0, err
	}
	id, err := res.LastInsertId()
	if err != nil {
		return 0, err
	}
	return id, nil
}
func InsertEvent(db *sql.DB, event Event) error {
	stmt, err := db.Prepare("INSERT INTO notes(id, date, note, created, user_id, privileged, ip) values(?,?,?,?,?,?,?)")
	if err != nil {
		return err
	}
	_, err = stmt.Exec(event.ID, event.Start, event.Note, event.Created, event.UserID, event.Privileged, event.Ip)
	if err != nil {
		return err
	}
	return nil
}
func DeleteEvent(db *sql.DB, user_id int64, event_id string) error {
	stmt, err := db.Prepare("DELETE FROM notes WHERE id=? AND user_id=?")
	if err != nil {
		return err
	}
	_, err = stmt.Exec(event_id, user_id)
	if err != nil {
		return err
	}
	return nil
}
func GetEvents(db *sql.DB, sess SessionUser) ([]Event, error) {
	rows, err := db.Query("SELECT id, date, note, created, user_id, privileged, ip FROM notes WHERE user_id=?", sess.UserID)
	if err != nil {
		return nil, err
	}
	var events []Event
	for rows.Next() {
		var event Event
		err = rows.Scan(&event.ID, &event.Start, &event.Note, &event.Created, &event.UserID, &event.Privileged, &event.Ip)
		if err != nil {
			return nil, err
		}
		if event.Privileged == 1 && (sess.Privileged == 0 || sess.Ip != event.Ip) {
			event.Note = "🔒 Locked"
		}
		events = append(events, event)
	}
	return events, nil
}
