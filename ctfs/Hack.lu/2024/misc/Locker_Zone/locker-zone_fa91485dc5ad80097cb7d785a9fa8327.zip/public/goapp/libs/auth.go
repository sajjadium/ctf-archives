package libs

import (
	"context"
	"database/sql"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"

	"github.com/coreos/go-oidc/v3/oidc"
	"github.com/google/uuid"
	"github.com/quasoft/memstore"
	"golang.org/x/oauth2"
)

func MakeProvider(ctx context.Context) (oauth2.Config, oauth2.Config, memstore.MemStore, oidc.IDTokenVerifier, error) {

	provider, err := oidc.NewProvider(ctx, os.Getenv("OIDC_PROVIDER_URL"))
	if err != nil {
		return oauth2.Config{}, oauth2.Config{}, memstore.MemStore{}, oidc.IDTokenVerifier{}, err
	}
	var oauth2Config = oauth2.Config{
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("CLIENT_SECRET"),
		RedirectURL:  os.Getenv("CALLBACK_URL"),

		Endpoint: provider.Endpoint(),

		Scopes: []string{oidc.ScopeOpenID, "profile"},
	}
	var oauth2ConfigIntenal = oauth2.Config{
		ClientID:     os.Getenv("CLIENT_ID"),
		ClientSecret: os.Getenv("CLIENT_SECRET"),
		RedirectURL:  os.Getenv("CALLBACK_URL_INTERNAL"),
		Endpoint:     provider.Endpoint(),
		Scopes:       []string{oidc.ScopeOpenID, "profile"},
	}
	var store = memstore.NewMemStore([]byte(os.Getenv("SESSION_KEY")))
	var vrfyer = provider.Verifier(&oidc.Config{ClientID: os.Getenv("CLIENT_ID")})
	return oauth2Config, oauth2ConfigIntenal, *store, *vrfyer, nil
}
func CallbackRoute(w http.ResponseWriter, r *http.Request, oauth2Config oauth2.Config, oauth2ConfigInternal oauth2.Config, store memstore.MemStore, vrfyer oidc.IDTokenVerifier, db *sql.DB) {
	session, err := store.Get(r, "auth-notes")
	session.Options.HttpOnly = true
	session.Options.SameSite = http.SameSiteLaxMode
	session.Options.MaxAge = 60 * 15
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		log.Printf("Failed to get session: %v", err)
		return
	}
	if r.URL.Query().Get("state") != session.Values["state"] {
		http.Error(w, "state did not match", http.StatusBadRequest)
		log.Printf("State did not match")
		return
	}
	myConfig := oauth2Config
	if strings.Count(r.Host, ".") < 2 { // interal host
		myConfig = oauth2ConfigInternal
	}
	oauth2Token, err := myConfig.Exchange(r.Context(), r.URL.Query().Get("code"))
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		log.Printf("Failed to exchange token: %v", err)
		return
	}
	rawIDToken, ok := oauth2Token.Extra("id_token").(string)
	if !ok {
		http.Error(w, "no id_token", http.StatusInternalServerError)
		log.Printf("Failed to get id_token")
		return
	}
	// decode

	idToken, err := vrfyer.Verify(r.Context(), rawIDToken)
	if err != nil {
		http.Error(w, "failed to verify id_token", http.StatusInternalServerError)
		log.Printf("Failed to verify id_token: %v", err)
		return
	}
	kc_id := idToken.Subject
	session.Values["state"] = ""

	curr_user, err := GetUser(db, kc_id)
	if err != nil {
		user_id, err2 := InsertUser(db, kc_id)
		if err2 != nil {
			http.Error(w, err2.Error(), http.StatusInternalServerError)
			log.Printf("Failed to insert user: %v", err2)
			return
		}
		curr_user = User{ID: user_id, KCID: kc_id}
	}

	session.Values["user_id"] = curr_user.ID
	var claims struct {
		Privileged int64 `json:"privileged"`
	}
	if err := idToken.Claims(&claims); err != nil {
		claims.Privileged = 0
	}
	session.Values["privileged"] = claims.Privileged
	fmt.Printf("Privileged: %d\n", claims.Privileged)
	err = session.Save(r, w)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		log.Printf("Failed to save session: %v", err)
		return
	}
	http.Redirect(w, r, "/", http.StatusFound)
}

func AuthHandler(next http.Handler, oauth2Config oauth2.Config, oauth2ConfigInternal oauth2.Config, store memstore.MemStore) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" && r.URL.Path != "/add" && r.URL.Path != "/delete" {
			http.NotFound(w, r)
			return
		}
		session, err := store.Get(r, "auth-notes")
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		if session.Values["user_id"] == nil {
			// Redirect to login page
			state := uuid.New().String()
			session.Values["state"] = state
			err = session.Save(r, w)
			if err != nil {
				http.Error(w, err.Error(), http.StatusInternalServerError)
				log.Printf("Failed to save session: %v", err)
				return
			}
			myConfig := oauth2Config
			if strings.Count(r.Host, ".") < 2 { // interal host
				myConfig = oauth2ConfigInternal
			}
			http.Redirect(w, r, myConfig.AuthCodeURL(state), http.StatusFound)
			return
		}

		next.ServeHTTP(w, r)
	})
}
