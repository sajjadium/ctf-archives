# Challenge
- 1: build with "./build.local.sh"
- 2: copy .env.example to .


### Recommended for local setup: Cloudflare Tunnels
- docker network create proxynet
- Keep MAX_PARALLEL=99
- Set PUBLIC_HOST=.trycloudflare.com
- Create 3 tunnels: 
  - 1: `cloudflared tunnel --url http://localhost:8852`
  - 2: `cloudflared tunnel --url http://localhost:8852`
  - 3: `cloudflared tunnel --url http://localhost:8852`
- Replace the Hostname in `traefik.http.routers.steering.rule` with the first tunnel hostname (like Host(`analysts-worship-ben-maker.trycloudflare.com`))
- Set env FORCE_GOAPP_HOSTNAME to the second tunnel hostname before (.trycloudflare.com) (like `analysts-worship-ben-maker`)
- Set env FORCE_KC_HOSTNAME to the third tunnel hostname before (.trycloudflare.com) (like `analysts-worship-ben-maker`)

- 3: `docker-compose -f docker-compose.local.yml up -d`
Have fun!