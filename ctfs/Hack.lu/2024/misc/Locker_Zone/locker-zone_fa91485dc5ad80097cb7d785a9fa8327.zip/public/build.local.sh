#!/bin/bash
docker build -t git.host/hacklu24/adminbot adminbot/
docker build -t git.host/hacklu24/goapp goapp/
docker build -t git.host/hacklu24/steering steering/
