#!/bin/sh
docker build --output=. -f Dockerfile.qemu .
