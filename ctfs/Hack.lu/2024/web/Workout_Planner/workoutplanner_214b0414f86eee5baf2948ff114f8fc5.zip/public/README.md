# Local Setup

To run this challenge locally:

- `sudo docker compose up`
  - this forwards port 80 to port 80
  - it uses host networking to make testing easier
  - host networking does not work with rootless docker
- Connect to `http://localtest.me` (this domain maps to localhost)
- Subdomains will also work `http://1337abcd.localtest.me`
- have fun!
