const express = require('express');
const workerpool = require('workerpool');

const pool = workerpool.pool(__dirname + '/bot.js');

const app = express();
app.use(express.json());

const BOTKEY = process.env.BOTKEY || "botkey";

app.post('/visit', async (req, res) => {
    const { url, botkey } = req.body;

    if (botkey !== BOTKEY) {
        return res.status(403).json({ error: 'Invalid botkey' });
    }

    if (typeof url !== "string" || !url.match(/^https?:\/\/.*$/)) { 
        return res.status(400).json({ error: 'Invalid URL' });
    }
    pool.exec('visit', [url]);
    return res.json({ success: true });
});

app.listen(4000, () => {
    console.log('Bot running on port 4000');
});