const workerpool = require('workerpool');
const puppeteer = require('puppeteer-core');

const DOMAIN = process.env.DOMAIN || "localtest.me";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin";
const DEBUG = process.env.DEBUG === "true";
const SCHEME = DEBUG ? "http" : "https";
const TIMEOUT = Number(process.env.TIMEOUT) || 30;
const loginUrl = `${SCHEME}://${DOMAIN}/login`;
const loginCheck = "Welcome back";

async function visit(url) {
    let browser;
    try {
        browser = await puppeteer.launch({
            headless: true,
            product: 'firefox',
            executablePath: '/usr/bin/firefox',
            ignoreHTTPSErrors: DEBUG,
        });

        let page = await browser.newPage();
        page.on('console', (msg) => {
            console.log('[Console]', msg.text());
        });
        await page.goto(loginUrl);
        await page.type("#username", "admin");
        await page.type("#password", ADMIN_PASSWORD);
        await Promise.all([
            (await page.$("#submit")).press("Enter"),
            page.waitForNavigation()
        ]);
        const text = await page.content();
        if (!text.includes(loginCheck)) {
            throw Error("Not logged in!");
        }
        await page.close();

        page = await browser.newPage();
        page.on('console', (msg) => {
            console.log('[Console]', msg.text());
        });

        // close the browser after TIMEOUT_SECS seconds
        setTimeout(() => browser.close(), TIMEOUT * 1000);

        console.log(`Visiting URL ${url}`);
        await page.goto(url);
    } catch (error) {
        console.log('Error:', error);
        browser.close();
    }
}

workerpool.worker({ visit });