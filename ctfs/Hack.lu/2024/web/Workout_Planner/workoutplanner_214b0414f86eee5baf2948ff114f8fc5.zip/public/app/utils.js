function secret() {
    return crypto.getRandomValues(Buffer.alloc(16)).toString("hex");
}

function requireLoggedIn(req, res, next) {
    if (req.session.user) {
        next();
    } else {
        res.redirect("/login");
    }
}

function forbidLoggedIn(req, res, next) {
    if (req.session.user) {
        res.redirect("/");
    } else {
        next();
    }
}

module.exports = { secret, requireLoggedIn, forbidLoggedIn };