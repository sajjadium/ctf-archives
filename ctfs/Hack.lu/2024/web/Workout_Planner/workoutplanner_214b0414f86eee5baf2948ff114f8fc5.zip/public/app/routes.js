const express = require('express');
const zxcvbn = require("zxcvbn");
const { rateLimit } = require('express-rate-limit')

const routes = express.Router();

const { DOMAIN, DEBUG, SCHEME, BOTKEY, FLAG_ID } = require("./config");
const { users, plans } = require("./store");
const { secret, requireLoggedIn, forbidLoggedIn } = require("./utils");

routes.get("/", function (req, res) {
    if (req.session.user) {
        const userPlans = Object.entries(plans).filter(([planId, planObj]) => planObj.author === req.session.user);
        res.render("pages/index", { userPlans });
    } else {
        res.render("pages/about", { FLAG_ID });
    }
});

routes.get("/login", forbidLoggedIn, function (req, res) {
    res.render("pages/login");
});

routes.post("/login", forbidLoggedIn, function (req, res) {
    const { username, password } = req.body;
    if (typeof username !== 'string' || typeof password !== 'string') {
        req.session.error = "Invalid username or password";
        res.redirect("/login");
        return;
    }

    if (!(username in users) || users[username].password !== password) {
        req.session.error = "Invalid username or password";
        res.redirect("/login");
        return;
    }

    req.session.user = username;
    req.session.success = `Welcome back, ${username}!`;
    res.redirect("/");
});

routes.get("/register", forbidLoggedIn, function (req, res) {
    res.render("pages/register");
});

routes.post("/register", forbidLoggedIn, function (req, res) {
    const { username, password } = req.body;
    if (typeof username !== 'string' || typeof password !== 'string') {
        req.session.error = "Invalid username or password";
        res.redirect("/register");
        return;
    }
    if (username in users) {
        req.session.error = "User already exists";
        res.redirect("/register");
        return;
    }
    // https://youtu.be/Sm4G6cAHjWM?t=409
    if (!DEBUG && (password.length < 8 || zxcvbn(password).score < 2)) {
        req.session.error = "Password too weak";
        res.redirect("/register");
        return;
    }

    // TODO: Add premium user registration
    users[username] = { password, isPremium: false };

    req.session.user = username;
    req.session.success = `Registered user ${username}`;
    res.redirect("/");
});

routes.get("/logout", requireLoggedIn, function (req, res) {
    req.session.user = null;
    req.session.success = "You are logged out";
    res.redirect("/");
});

const planRegex = new RegExp(`^${SCHEME}://[\\da-f]+\\.${DOMAIN.replaceAll(".", "\\.")}/`);

routes.get("/report", requireLoggedIn, function (req, res) {
    res.render("pages/report", { planRegex: planRegex.source });
});

routes.post("/report", requireLoggedIn, rateLimit({ windowMs: 1 * 60 * 1000, limit: 5, skip: () => DEBUG }), async function (req, res) {
    const { url } = req.body;
    if (typeof url !== 'string' || !planRegex.test(url)) {
        req.session.error = "Invalid URL";
        res.redirect("/report");
        return;
    }

    const botUrl = DEBUG ? "http://127.0.0.1:4000/visit" : "http://bot:4000/visit";
    const botRes = await fetch(botUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url, botkey: BOTKEY })
    });
    if (botRes.ok) {
        req.session.success = "Report sent!";
    } else {
        req.session.error = "Failed to send report";
    }
    res.redirect("/report");
});


routes.post("/plan", requireLoggedIn, function (req, res) {
    const user = req.session.user;
    let { planTitle, plan, isPrivate } = req.body;
    let config = Object.fromEntries(Object.entries(req.body).filter(([k, v]) => k.startsWith("config.")));
    config = new URLSearchParams(config).toString();
    isPrivate = !!isPrivate;
    if (
        typeof planTitle !== 'string' ||
        typeof plan !== 'string' ||
        planTitle.length > 50 ||
        plan.length > 10_000 ||
        // Only premium users can create private plans
        (isPrivate && !users[user].isPremium)
    ) {
        req.session.error = "Invalid plan";
        res.redirect("/");
        return;
    }

    let planId;
    do {
        planId = secret();
    } while (planId in plans);
    plan = plan.replaceAll("\n", "<br>");
    
    plans[planId] = { planTitle, plan, isPrivate, author: user, config };
    res.redirect(`${SCHEME}://${planId}.${DOMAIN}?${config}`);
});

routes.get("/plan/:planId", function (req, res) {
    const { planId } = req.params;
    const query = new URLSearchParams(req.query).toString();
    res.redirect(`${SCHEME}://${planId}.${DOMAIN}?${query}`);
});

routes.get("/plan", function (req, res, next) {
    const planId = req.subdomains[0];
    if (!(planId in plans)) {
        next();
        return;
    }
    const plan = plans[planId];
    if (plan.isPrivate && plan.author !== req.session.user) {
        next();
        return;
    }

    res.render("pages/plan", { ...plans[planId] });
});

module.exports = routes;
