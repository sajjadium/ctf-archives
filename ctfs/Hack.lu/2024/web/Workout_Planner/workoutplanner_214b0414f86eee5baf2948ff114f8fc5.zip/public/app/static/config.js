// TODO: refactor to fetch from API
config = {
    textColor: "black",
    textSize: "12",
    fontFamily: "Arial",
    textAlignment: "left"
}
