const { FLAG, FLAG_ID, ADMIN_PASSWORD } = require("./config");

const users = Object.create(null);
const plans = Object.create(null);

users["admin"] = { password: ADMIN_PASSWORD, isPremium: true };
plans[FLAG_ID] = { planTitle: "New Premium Features!", plan: FLAG, isPrivate: true, author: "admin", config: "" };

module.exports = { users, plans };