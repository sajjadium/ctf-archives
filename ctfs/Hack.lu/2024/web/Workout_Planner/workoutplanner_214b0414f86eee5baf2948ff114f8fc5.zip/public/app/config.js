const { secret } = require("./utils");

const DEBUG = process.env.DEBUG === "true";
const SCHEME = DEBUG ? "http" : "https";

const config = {
    DOMAIN: process.env.DOMAIN,
    DEBUG: DEBUG,
    SCHEME: SCHEME,
    ORIGIN: `${SCHEME}://${process.env.DOMAIN}`,
    ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || "admin",
    FLAG: process.env.FLAG || "flag{fake_flag}",
    FLAG_ID: secret(),
    BOTKEY: process.env.BOTKEY || "botkey",
}
Object.assign(module.exports, config)
