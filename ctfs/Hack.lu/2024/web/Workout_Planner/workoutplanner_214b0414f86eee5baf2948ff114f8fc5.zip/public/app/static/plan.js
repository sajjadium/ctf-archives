function setConfig(key, value) {
    if (typeof key !== "string" || typeof value !== "string") return;
    let current = window;
    const keyParts = key.split('.');
    for (let i = 0; i < keyParts.length; i++) {
        const keyPart = keyParts[i];
        // we got some bug reports
        if (["__proto__", "prototype", "constructor"].includes(keyPart.toLowerCase())) return;
        if (current instanceof Element) return;

        if (i === keyParts.length - 1) {
            current[keyPart] = value;
        } else {    
            current = current[keyPart];
        }
    }
}

function setupPage() {
    if (config.textColor && ["black", "red", "blue", "green", "orange", "purple"].includes(config.textColor)) {
        plan.style.color = config.textColor;
    }
    if (config.textSize && ["12", "14", "16", "18", "20", "22", "24"].includes(config.textSize)) {
        plan.style.textSize = config.textSize
    }
    if (config.fontFamily && ["Arial", "Times New Roman", "Courier New", "Verdana", "Georgia", "Comic Sans MS"].includes(config.fontFamily)) {
        plan.style.fontFamily = config.fontFamily;
    }
    if (config.textAlignment && ["left", "center", "right"].includes(config.textAlignment)) {
        plan.style.textAlignment = config.textAlignment;
    }
}

window.addEventListener("DOMContentLoaded", () => {
    shareButton.onclick = async () => {
        await navigator.clipboard.writeText(window.location.href);
        success.innerText = "Copied link to clipboard!";
    }
    
    let searchParams = new URLSearchParams(window.location.search);
    // TODO: check if user is premium and allow unlimited config options
    if (searchParams.size === 1) {
        searchParams = Object.fromEntries(searchParams.entries());
        const [key, value] = Object.entries(searchParams)[0];
        setConfig(key, value);
    }
    
    setupPage();
});
