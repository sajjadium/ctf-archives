const express = require("express");
const path = require("path");
const session = require("express-session");
const bodyParser = require("body-parser");
const app = express();

const { DOMAIN, ORIGIN, SCHEME } = require("./config");
const routes = require("./routes");
const { plans } = require("./store");
const { secret } = require("./utils");

app.set("view engine", "ejs");
app.set("trust proxy", true);
app.use(session({
    resave: false,
    saveUninitialized: true,
    secret: secret(),
    cookie: { domain: DOMAIN, secure: SCHEME === "https" }
}));
app.use(bodyParser.urlencoded({ extended: false }));

app.use(function (req, res, next) {
    // don't add tracking script for private plans!
    const planId = req.subdomains[0];
    let csp = `default-src 'self'; img-src 'self' data:; frame-src 'none'; object-src 'none'; base-uri 'none';`;
    if (!(planId in plans && plans[planId].isPrivate)) {
        csp += `script-src 'self' cdnjs.cloudflare.com/ajax/libs/analytics.js/2.9.1/analytics.min.js;`;
        res.locals.tracking = true;
    }
    res.setHeader("Content-Security-Policy", csp);
    next();
});

app.use("/static", express.static("static", { fallthrough: false }));

app.use(function (req, res, next) {
    if (req.method === "POST") {
        const { csrf } = req.body;
        if (!csrf || !req.session.csrf || req.session.csrf !== csrf) {
            res.status(403).send("bad csrf");
            return;
        }
    }
    req.session.csrf = secret();
    res.locals.csrf = req.session.csrf;
    next();
});

app.use(function (req, res, next) {
    res.locals.ORIGIN = ORIGIN;
    res.locals.user = req.session.user;
    // Display messages if GET request
    if (req.method === "GET") {
        const { success, error } = req.session;
        req.session.success = null;
        req.session.error = null;
        res.locals.success = success;
        res.locals.error = error;
    }
    next();
});


app.use(routes);


app.use(function (req, res) {
    res.status(404);
    res.render("pages/404");
})

app.listen(3000, function () {
    console.log("Server started on http://localhost:3000");
});