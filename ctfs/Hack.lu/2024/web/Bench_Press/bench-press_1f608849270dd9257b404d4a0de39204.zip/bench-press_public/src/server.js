const { randomBytes, createHmac } = require('node:crypto');
const path = require('node:path');
const express = require('express');
const { engine } = require('express-handlebars');
const session = require('express-session');
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit');
const articles = require('./articles');
const { visit } = require('./bot');

const ADDR = process.env.ADDR ?? '127.0.0.1';
const PORT = Number(process.env.PORT ?? '3000');
const SESSION_SECRET = process.env.SESSION_SECRET ?? 'changeme';
const TOKEN_SECRET = process.env.TOKEN_SECRET ?? 'changeme';
const TOKEN_EXPIRY = Number(process.env.TOKEN_EXPIRY ?? (5 * 60)); // 5min
const FLAG = process.env.FLAG ?? 'flag{fake}';
const CHALLENGE_BASE = process.env.CHALLENGE_BASE ?? 'http://localhost:3000';
const RATE_LIMIT_WINDOW = Number(process.env.RATE_LIMIT_WINDOW ?? '60') * 1000;
const RATE_LIMIT_LIMIT = Number(process.env.RATE_LIMIT_LIMIT ?? '1');

const CSP_BASE = "default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; style-src 'unsafe-inline'; img-src http: https:";
const CSP_INDEX = (nonce) => `${CSP_BASE}; script-src 'nonce-${nonce}'; connect-src 'self'`;
const CSP_SECURE = `${CSP_BASE}; sandbox allow-forms`;

const random = () => randomBytes(16).toString('hex');

const app = express();
app.engine('handlebars', engine({
    helpers: {
        urlencode: (s) => encodeURIComponent(s),
    },
}));
app.set('view engine', 'handlebars');
app.set('views', path.join(__dirname, 'views'));
if ('TRUST_PROXY' in process.env) {
    app.set('trust proxy', 1);
}

app.use(session({
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        name: 'session',
        httpOnly: true,
        sameSite: 'lax',
    },
}));

const users = new Map();
const adminPassword = random();
console.log(`Admin password: ${adminPassword}`);
const admin = {
    username: 'admin',
    password: bcrypt.hashSync(adminPassword, 10),
    admin: true,
};
users.set(admin.username, admin);

app.use((req, res, next) => {
    res.set('content-security-policy', CSP_SECURE);
    res.set('cross-origin-opener-policy', 'same-origin');
    res.set('x-content-type-options', 'nosniff');

    let user;
    if (req.session?.username !== undefined) {
        user = users.get(req.session.username);
    }

    res.locals.nonce = random();
    res.locals.token = generateApiToken(user?.admin ?? false);
    res.locals.title = 'Bench Press';
    next();
});

app.use(express.static(path.join(__dirname, 'static')));

app.get('/', (req, res) => {
    res.set('content-security-policy', CSP_INDEX(res.locals.nonce));
    res.render('index', { articles });
});

app.get('/articles/:slug', (req, res) => {
    const { slug } = req.params;
    const article = articles.find(article => article.slug === slug);
    if (article === undefined) {
        res.redirect('/');
        return;
    }

    let theme = '';
    if (typeof req.query.theme === 'string') {
        theme = req.query.theme;
        if (theme.includes('</')) {
            theme = '*{color:red}';
        }
    }

    res.render('article', {
        article,
        theme,
        title: `${article.title} | Bench Press`,
    });
});

const now = () => Math.floor(Date.now() / 1000);
const hmac = (data) => createHmac('sha256', TOKEN_SECRET).update(data).digest('hex');
const TOKEN_LEN = 30;
const DATA_LEN = 10;
const MAC_LEN = TOKEN_LEN - DATA_LEN;

function generateApiToken(isAdmin) {
    const expiry = now() + TOKEN_EXPIRY;
    const data = Buffer.alloc(5);
    data.writeUInt8(isAdmin ? 1 : 0, 0);
    data.writeUInt32LE(expiry, 1);
    const mac = hmac(data);
    return (data.toString('hex') + mac).slice(0, TOKEN_LEN);
}

function verifyApiToken(token) {
    try {
        if (typeof token !== 'string' || token.length !== TOKEN_LEN) {
            return null;
        }
        const data = Buffer.from(token.slice(0, DATA_LEN), 'hex');
        const mac = token.slice(DATA_LEN);
        const isAdmin = data.readUInt8(0) === 1;
        const expiry = data.readUInt32LE(1);
        if (expiry < now()) {
            return null;
        }
        const expected = hmac(data).slice(0, MAC_LEN);
        if (mac !== expected) {
            return null;
        }
        return { isAdmin, expiry };
    } catch (error) {
        console.error(error);
        return null;
    }
}

app.get('/login', (req, res) => {
    res.render('login', { title: 'Login | Bench Press' });
});

app.post('/login', express.urlencoded({ extended: false }), async (req, res) => {
    const { username, password } = req.body;
    if (typeof username !== 'string' || typeof password !== 'string') {
        res.status(400).send('Bad Request');
        return;
    }
    const user = users.get(username);
    if (user === undefined || !await bcrypt.compare(password, user.password)) {
        res.render('login', {
            title: 'Login | Bench Press',
            error: 'Invalid username or password.',
        });
        return;
    }
    req.session.username = username;
    res.redirect('/');
});

app.get('/api/flag', (req, res) => {
    const token = req.get('x-api-token');
    if (typeof token !== 'string') { 
        res.status(401).send('Unauthorized');
        return;
    }
    const verified = verifyApiToken(token);
    if (verified == null) {
        res.status(401).send('Unauthorized');
        return;
    }
    if (!verified.isAdmin) {
        res.status(403).send('Forbidden');
        return;
    }
    res.send(FLAG);
});

const reportLimit = rateLimit({
    windowMs: RATE_LIMIT_WINDOW,
    limit: RATE_LIMIT_LIMIT,
    message: 'Too many reports. Please try again later.',
    skipFailedRequests: true,
});

app.post('/report', reportLimit, express.urlencoded({ extended: false }), (req, res) => {
    if (typeof req.body !== 'object') {
        res.status(400).send('Missing body');
        return;
    }
    const url = req.body.url;
    if (typeof url !== 'string') {
        res.status(400).send('Missing URL');
        return;
    }
    if (!url.startsWith(`${CHALLENGE_BASE}/`)) {
        res.status(400).send('Invalid URL');
        return;
    }
    visit(url, admin.username, adminPassword);
    res.send('Somebody will take a look soon!');
});

app.listen(PORT, ADDR, () => console.log(`Listening on http://${ADDR}:${PORT}`));
