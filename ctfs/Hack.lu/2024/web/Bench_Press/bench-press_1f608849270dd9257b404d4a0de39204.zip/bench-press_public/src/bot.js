const puppeteer = require('puppeteer-core');

const BOT_TIMEOUT = Number(process.env.BOT_TIMEOUT ?? '30') * 1000;
const CHALLENGE_BASE = process.env.CHALLENGE_BASE ?? 'http://localhost:3000';

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function visit(url, username, password) {
    let browser;
    try {
        if (typeof username !== 'string') {
            console.error('Invalid username');
            return;
        }
        if (typeof password !== 'string') {
            console.error('Invalid password');
            return;
        }

        console.log(`Visiting ${url}`);

        browser = await puppeteer.launch({
            headless: true,
            pipe: true,
            executablePath: '/usr/bin/chromium',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-gpu',
                '--js-flags=--noexpose_wasm,--jitless',
            ],
        });

        const ctx = await browser.createBrowserContext();
        await Promise.race([
            sleep(BOT_TIMEOUT),
            doVisit(ctx, url, username, password),
        ]);
    } catch (error) {
        console.error('Failed to browse:', error);
    } finally {
        if (browser) {
            try {
                await browser.close();
            } catch (error) {
                console.error('Failed to close browser:', error);
            }
        }
    }
}

async function doVisit(ctx, url, username, password) {
    // login
    let page = await ctx.newPage();
    console.log('Navigating to', `${CHALLENGE_BASE}/login`);
    await page.goto(`${CHALLENGE_BASE}/login`);
    await page.evaluate(
        (user, pass) => {
            document.querySelector('input[name="username"]').value = user;
            document.querySelector('input[name="password"]').value = pass;
        },
        username, password,
    );
    await Promise.all([
        page.click('input[type="submit"]'),
        page.waitForNavigation(),
    ]);
    await page.close();

    // visit
    page = await ctx.newPage();
    console.log('Navigating to', url);
    await page.goto(url);
    await sleep(BOT_TIMEOUT);
    await page.close();
}

module.exports = { visit };
