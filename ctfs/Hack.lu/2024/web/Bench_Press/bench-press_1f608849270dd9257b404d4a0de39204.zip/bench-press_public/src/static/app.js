setTimeout(async () => {
  const r = await fetch('api/flag', {
    headers: { 'X-API-Token': t },
  });
  if (r.status === 200) {
    const flag = await r.text();
    document.getElementById('coupon').textContent = flag;
    document.getElementById('coupon-sheet').classList.remove('hidden');
  }
}, 3_000);
