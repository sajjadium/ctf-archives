#!/bin/bash

echo "Please provide your ROM"
echo "Enter file size:"
read  ROM_size

if [[ ! "$ROM_size" =~ ^[0-9]+$ ]] ; then
    echo "Not a Number"
    exit
fi

if [ "$ROM_size" -gt 10485760 ]; then
    echo "Too large!"
    exit
fi

echo "Now send the bytes"

stty_orig=`stty -g`
stty -echo
ROM_file="$(mktemp)"
cleanup() {
    rm -f "$ROM_file"
}
trap cleanup EXIT HUP INT TERM
dd of="$ROM_file" bs=1 count="$ROM_size" # status=none
stty $stty_orig

read

echo "Please provide your config"
echo "Enter file size:"
read config_size

if [[ ! "$config_size" =~ ^[0-9]+$ ]] ; then
    echo "Not a Number"
    exit
fi

if [ "$config_size" -gt 10485760 ]; then
    echo "Too large!"
    exit
fi

echo "Now send the bytes"

stty_orig=`stty -g`
stty -echo
config_file="$(mktemp)"
cleanup() {
    rm -f "$config_file"
}
trap cleanup EXIT HUP INT TERM
dd of="$config_file" bs=1 count="$config_size" # status=none
stty $stty_orig

read

echo "Please provide your ROM_LOAD_ADDR (8 bytes)"
echo "Enter bytes: "

read -n 8 rom_load_addr

echo -e "\nYou entered: $rom_load_addr"

./gbadisasm -c "$config_file" -i "$rom_load_addr" "$ROM_file"
