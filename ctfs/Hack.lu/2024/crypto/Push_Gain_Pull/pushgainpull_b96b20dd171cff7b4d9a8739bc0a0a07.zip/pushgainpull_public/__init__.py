# get the flag
