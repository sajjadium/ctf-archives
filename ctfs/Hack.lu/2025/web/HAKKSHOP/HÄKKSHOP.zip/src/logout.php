<?php

include_once 'inc/required.php';
enforce_auth();
session_destroy();
header('Location: /');
