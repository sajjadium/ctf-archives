<?php include_once 'required.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HÄKKSHOP</title>
    <link href="/style.css" rel="stylesheet" type="text/css" />
    <link href="https://fontlibrary.org/en/face/gnu-unifont" rel="stylesheet" type="text/css" />
</head>
<body>

<header>
    <h1><a href="/">
        <span class="yellow">HÄKK</span><span class="blue">SHOP</span>
    </a></h1>
    <?php if (is_logged_in()) { ?>
        <a href="/settings.php">Settings</a>
        &nbsp;|&nbsp;
        <a href="/logout.php">Logout</a>
    <?php } else { ?>
        <a href="/login.php">Login</a>
        &nbsp;|&nbsp;
        <a href="/register.php">Register</a>
    <?php } ?>
</header>

<main>
<?php foreach ($msgs as $msg) { ?>
    <p class="<?= $msg['type'] ?>"><?= $msg['text'] ?></p>
<?php } ?>
