<?php

include_once 'db.php';
$db = new DB();

$msgs = [];
function show_error(string $error) {
    global $msgs;
    $msgs[] = ['type' => 'error', 'text' => $error];
}
function show_info(string $info) {
    global $msgs;
    $msgs[] = ['type' => 'info', 'text' => $info];
}
function show_success(string $success) {
    global $msgs;
    $msgs[] = ['type' => 'success', 'text' => $success];
}

session_start();

function is_logged_in() {
    return isset($_SESSION['uid']);
}
function enforce_auth() {
    if (!is_logged_in()) {
        header('Location: login.php');
        die();
    }
}
