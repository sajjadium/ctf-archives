<?php

function is_valid_invite($code) {
    global $db;
    $res = $db->select([
        'SELECT' => '*',
        'FROM' => 'invites',
        'WHERE' => ['code' => $code],
    ]);
    return count($res) === 1;
}

function generate_invite() {
    global $db;
    $code = bin2hex(random_bytes(16));
    $db->insert('invites', [
        'code' => $code,
    ]);
    return $code;
}
