<?php

function only_allowed_keys($allowed_keys, $array) {
    return array_filter($array, function($key) { return in_array($key, $allowed_keys, true); }, ARRAY_FILTER_USE_KEY);
}
