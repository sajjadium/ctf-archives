<?php

include_once 'inc/required.php';
include_once 'inc/invites.php';
include_once 'inc/users.php';

if (isset($_REQUEST['username']) && isset($_REQUEST['password']) && isset($_REQUEST['code']) && is_string($_REQUEST['code'])) {
    if (is_valid_invite($_POST['code'])) {
        $username = $_POST['username'];
        if (get_user_by_name($username)) {
            show_error('Username already taken.');
        } else {
            add_tmp_perms('users_add');
            $user = create_user($username, $_POST['password']);
            rm_tmp_perms('users_add');
            if ($user) {
                show_success('Account created successfully.');
                header('Location: login.php');
            } else {
                show_error('Failed to create user.');
            }
        }
    } else {
        show_error('Invalid invite code.');
    }
}
include 'inc/header.php';
?>
<form class="register" method="POST">
    <h2>Register</h2>
    <label for="username">Username</label>
    <input type="text" name="username" id="username" placeholder="Username" autofocus>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" placeholder="Password">
    <label for="code">Invite Code</label>
    <input type="text" name="code" id="code" placeholder="Invite Code">
    <input type="submit" value="Register">
</form>
<?php include 'inc/footer.php'; ?>
