<?php

include_once 'inc/required.php';
include_once 'inc/users.php';
include_once 'inc/perms.php';

enforce_auth();

if (isset($_POST['delete-user'])) {
    $delete_uid = (int) $_REQUEST['uid'];
    if (has_perms('users_delete', 'perms_delete')) {
        delete_user($delete_uid);
        show_success("User $delete_uid has been deleted.");
    } elseif ($delete_uid === $_SESSION['uid']) {
        add_tmp_perms('users_delete', 'perms_delete');
        delete_user($delete_uid);
        show_success($_REQUEST['msg']);
        rm_tmp_perms('users_delete', 'perms_delete');
        header('Location: logout.php');
    } else {
        show_error('You do not have permission to delete users.');
    }
}

include_once 'inc/header.php';
?>
<h2>Hello, <?= $_SESSION['username'] ?>!</h2>
<br>
<form action="?uid=<?= $_SESSION['uid'] ?>&msg=Your+account+has+been+deleted." method="POST">
    <input class="danger" type="submit" name="delete-user" value="Delete my account">
</form>
<?php include 'inc/footer.php'; ?>
