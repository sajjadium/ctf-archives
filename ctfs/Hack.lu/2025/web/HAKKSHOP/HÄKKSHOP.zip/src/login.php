<?php

include_once 'inc/required.php';
include_once 'inc/users.php';

if (isset($_POST['username']) && isset($_POST['password'])) {
    $user = check_user_creds($_POST['username'], $_POST['password']);
    if ($user) {
        $_SESSION['uid'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header('Location: /');
    } else {
        show_error('Invalid username or password.');
    }
}

include 'inc/header.php';
?>
<form class="login" method="POST">
    <h2>Login</h2>
    <label for="username">Username</label>
    <input type="text" name="username" id="username" placeholder="Username" autofocus>
    <label for="password">Password</label>
    <input type="password" name="password" id="password" placeholder="Password">
    <input type="submit" value="Login">
</form>
<?php include 'inc/footer.php'; ?>
