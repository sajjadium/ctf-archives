export default function Toolbar({ name, logo, style, children }) {
  return (
    <section draggable style={style} className="toolbar">
      <div>...</div>
      <div>x</div>
      <div>
        { logo && <img src={logo} alt="Logo" /> }
        { name ?? '' }
      </div>
      <div>{children}</div>
    </section>
  );
}
