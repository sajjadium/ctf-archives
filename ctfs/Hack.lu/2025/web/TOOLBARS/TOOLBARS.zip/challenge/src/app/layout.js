import "./globals.css";

export const metadata = {
  title: "Toolbars",
  description: "Good ol' toolbars, helpful as ever.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="stylesheet" href="/XP.css" />
        <link rel="stylesheet" href="/count.css" />
      </head>
      <body>
        {children}
      </body>
    </html>
  );
}
