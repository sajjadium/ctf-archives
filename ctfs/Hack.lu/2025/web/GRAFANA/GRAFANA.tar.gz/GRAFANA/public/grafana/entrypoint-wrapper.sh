#!/usr/bin/env bash
set -euo pipefail

/run.sh &
GRAFANA_PID=$!

until curl -s http://localhost:3000/api/health > /dev/null 2>&1; do
  echo "Waiting for Grafana to start..."
  sleep 2
done

echo "Grafana started, creating viewer user..."

curl -X POST http://admin:just_guess_this_youll_solve_the_challenge@localhost:3000/api/admin/users \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Viewer",
    "login": "viewer",
    "password": "you_can_try_to_guess_this_too",
    "email": "viewer@localhost",
    "role": "Viewer"
  }'

echo "Viewer user created successfully."

wait $GRAFANA_PID
