import os
import base64
import time
from typing import List, Optional, Tuple

from flask import Flask, request, redirect, url_for, render_template_string, send_from_directory, jsonify, make_response
import secrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from crypto import PRNG

# Read flag from file
def read_flag():
    with open("flag.txt", "r") as f:
        return f.read().strip()

# Initialize Flask app
app = Flask(__name__)
app.config["SECRET_KEY"] = secrets.token_hex(32)  # Generate secure 32-byte secret for Flask
app.config["COUPON_CODE"] = read_flag()

# AES-256 key for encrypting the per-round 80-bit RNG seed in a cookie
_AES_KEY = AESGCM.generate_key(bit_length=256)
_AES = AESGCM(_AES_KEY)
SEED_COOKIE = "seed_state"


def new_seed() -> int:
	return secrets.randbits(80)  # 80-bit seed


def encrypt_seed(seed: int, timestamp: Optional[int] = None) -> str:
	"""Encrypt seed and timestamp into a single AES-GCM encrypted cookie token.
	
	Args:
		seed: 80-bit seed value
		timestamp: Optional Unix timestamp (defaults to current time)
	
	Returns:
		Base64-encoded token containing encrypted seed and timestamp
	"""
	assert 0 <= seed < (1 << 80)
	if timestamp is None:
		timestamp = int(time.time())
	
	# Plaintext: 10 bytes seed + 8 bytes timestamp (64-bit) = 18 bytes
	nonce = secrets.token_bytes(12)
	seed_bytes = seed.to_bytes(10, 'big')
	timestamp_bytes = timestamp.to_bytes(8, 'big')
	pt = seed_bytes + timestamp_bytes
	ct = _AES.encrypt(nonce, pt, None)  # ciphertext || tag
	blob = nonce + ct
	return base64.urlsafe_b64encode(blob).decode('ascii')


def decrypt_seed(token: str) -> Optional[Tuple[int, int]]:
	"""Decrypt seed and timestamp from AES-GCM encrypted cookie token.
	
	Args:
		token: Base64-encoded encrypted token
	
	Returns:
		Tuple of (seed, timestamp) or None if decryption fails
	"""
	try:
		blob = base64.urlsafe_b64decode(token.encode('ascii'))
		if len(blob) < 12 + 16:
			return None
		nonce, ct = blob[:12], blob[12:]
		pt = _AES.decrypt(nonce, ct, None)
		if len(pt) != 18:
			return None
		seed = int.from_bytes(pt[:10], 'big')
		timestamp = int.from_bytes(pt[10:18], 'big')
		return (seed, timestamp)
	except Exception:
		return None


def generate_hues(rng: PRNG, n: int = 10) -> List[int]:
    """Consume 2*n outputs to create n hue values combining two nybbles."""
    hues = [(rng.next() << 4) | rng.next() for _ in range(n)]
    return hues


def compute_target(rng: PRNG) -> int:
    """Consume next 32 nybbles to create 128-bit target."""
    t = 0
    for _ in range(32):
        t <<= 4
        t |= rng.next()
    return t


def render_page(seed: int):
    rng = PRNG(seed)
    hues = generate_hues(rng)
    target = compute_target(rng)
    wheel_numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "A", "B", "C", "D", "E", "F"]  # Hex digits for the wheel
    tmpl = """
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<title>Showroom Raffle</title>
		<style>
			@font-face {
				font-family: 'FuturaPress';
				src: url('{{ url_for('font_futurapress') }}') format('truetype');
				font-weight: normal;
				font-style: normal;
				font-display: swap;
			}
			:root {
				--ikea-blue: #0058a3;
				--ikea-yellow: #ffda1a;
				--concrete: #e6e6e6;
				--shelf: #f8f8f880;
				--ikea-font: "Noto IKEA","Noto Sans","Roboto","Open Sans",system-ui,sans-serif;
			}
			* { box-sizing: border-box; }
			body { margin: 0; font-family: var(--ikea-font) !important; background: var(--concrete) url('{{ url_for('bg_image') }}') center / cover fixed no-repeat; color: #111; }
			header {
				background: var(--ikea-blue);
				color: #fff;
				padding: 10px 16px;
				display: flex;
				align-items: center;
				gap: 12px;
				position: sticky; top: 0; z-index: 10;
			}
			.logo {
				position: relative;
				display: inline-flex;
				/* limit size of img */
				max-height: 50px;
				width: auto;
				padding: 0 0;
				margin: 0;
			}
			.wrap { max-width: 1100px; margin: 0 auto; padding: 16px; }

			/* Ceiling area above the showroom */
			.ceiling {
				height: 140px; /* extra room so bulb glow isn't clipped */
				position: relative;
				overflow: visible;
			}
			/* Ceiling with pendant lights */
			.ceiling { --drop: 80px; }
			/* Bulbs are anchored to the top of the ceiling; stems fill the drop */
			.bulbs { position: absolute; top: 0; left: 0; right: 0; display: flex; justify-content: space-around; padding: 0 40px; }
			.bulb {
				width: 28px; height: calc(var(--drop) + 40px);
				position: relative;
				filter: drop-shadow(0 6px 6px rgba(0,0,0,0.15));
			}
			/* Stems grow to the top of the ceiling (just below header) */
			.bulb .stem { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 3px; height: calc(100% - 40px); background: #9a9a9a; }
			.bulb .glass {
				width: 28px; height: 40px; margin: 0 auto; position: absolute; bottom: 0; left: 0; right: 0;
				/* pear-shaped bulb using elliptical radii */
				border-radius: 48% 48% 38% 38% / 58% 58% 42% 42%;
				background: hsl(0, 100%, 75%);
				color: hsl(0, 100%, 50%);
				box-shadow: 0 0 18px 8px currentColor;
			}
			.bulb .glass::after {
				content: "";
				position: absolute;
				left: 6px; right: 6px; top: 6px; bottom: 10px;
				border-radius: 50% 50% 45% 45% / 55% 55% 45% 45%;
				background: rgba(255,255,255,0.24);
				filter: blur(3px);
				pointer-events: none;
			}
			/* socket/cap sits above the glass */
			.bulb .cap { position: absolute; left: 5px; right: 5px; top: -8px; height: 10px; background: #777; border-radius: 3px; box-shadow: inset 0 -1px 0 #666, inset 0 1px 0 #8a8a8a; }

			/* Showroom floor */
			.showroom { background: rgba(255, 255, 255, 0.5); border-radius: 12px; padding: 16px; margin-top: 16px; box-shadow: 0 6px 18px rgba(0,0,0,0.08); backdrop-filter: blur(2px); }
			.aisle { display: grid; grid-template-columns: 2fr 1fr; gap: 16px; }
			.shelves {
				background: var(--shelf);
				border: 1px solid #e5e5e5;
				border-radius: 8px;
				padding: 12px;
				display: grid;
				grid-template-columns: repeat(3, 1fr);
				gap: 10px;
			}
			.product { background: #fff; border: 1px solid #ececec; border-radius: 8px; padding: 12px; display: grid; grid-template-rows: 1fr auto; gap: 8px; align-content: stretch; }
			.product .thumb { min-height: 100px; display: grid; place-items: center; }
			.product img { max-width: 88px; height: auto; display: block; }
			.product .meta { display: flex; justify-content: space-between; align-items: center; }
			.product .name { font-weight: 700; color: #333; }
			.price { font-weight: 700; color: var(--ikea-blue); }

			/* Raffle area */
			.game { background: #fff; border: 1px solid #ececec; border-radius: 8px; padding: 12px; display: grid; gap: 12px; align-content: start; }
			.wheel-wrap { display: grid; place-items: center; }
			.wheel {
				--ring: conic-gradient(from -90deg, var(--ikea-yellow) 0 25%, #fff 25% 50%, var(--ikea-yellow) 50% 75%, #fff 75% 100%);
				width: 220px; height: 220px; border-radius: 50%;
				background: radial-gradient(circle at 50% 50%, #fff, #f7f7f7 60%, #eaeaea 61% 62%, transparent 63%), var(--ring);
				border: 6px solid var(--ikea-blue);
				position: relative;
				/* expose current spin angle via CSS var (updated by JS) */
				--spin: 0deg;
				animation: slowspin 18s linear infinite;
			}
			@keyframes slowspin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
			.wheel .tick {
				position: absolute; left: 50%; top: 50%; transform-origin: 0 0;
				/* perfect circular markers */
				width: 12px; height: 12px; border-radius: 50%;
				background: var(--ikea-blue);
				border: 2px solid #fff; /* ring for contrast */
				box-shadow: 0 0 0 2px var(--ikea-blue);
			}
			.wheel .label { position: absolute; left: 50%; top: 50%; transform-origin: 0 0; font-weight: 700; color: #333; font-size: 12px; line-height: 1; }
			.wheel .label-inner { display: inline-block; transform-origin: 50% 50%; }
			.pointer { width: 0; height: 0; border-left: 12px solid transparent; border-right: 12px solid transparent; border-bottom: 18px solid var(--ikea-blue); margin-top: 6px; }

			form { display: grid; gap: 8px; }
			input[type=number] { padding: 8px; border: 1px solid #ddd; border-radius: 6px; font-size: 16px; }
			button { padding: 8px 12px; background: var(--ikea-blue); color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: 700; }
			button:hover { filter: brightness(1.05); }

			.msg { padding: 10px 12px; border-radius: 8px; background: #f5f9ff; border: 1px solid #d8e7ff; color: #0b3d91; }
			.msg.ok { background: #5f9b6e91; border: 0px; color: #0f0; backdrop-filter: blur(2px); }
			.msg.err { background: rgba(83, 45, 45, 0.5); border: 0px; color: #f00; backdrop-filter: blur(2px); }
			.hidden { display: none; }
		</style>
	</head>
	<body>
		<header>
			<img src="./logo.png" class="logo"/>
			<div>Make a guess to win a prize!</div>
		</header>
		<div class="ceiling">
			<div class="bulbs">
				{% for h in hues %}
				<div class="bulb" title="Hue {{h}}">
					<div class="stem"></div>
					<div class="glass" style="color: hsl({{h}}, 100%, 50%); background: hsl({{h}}, 100%, 80%);">
						<div class="cap"></div>
					</div>
				</div>
				{% endfor %}
			</div>
		</div>

		<div class="wrap">
			<div class="showroom">
				<div class="aisle">
					<div class="shelves">
						<div class="product">
							<div class="thumb">
								<img src="{{ url_for('light_bulb') }}" alt="Light Bulb" />
							</div>
							<div class="meta"><div class="name">Light Bulb</div><div class="price">€9.99</div></div>
						</div>
						<div class="product">
							<div class="thumb"><img src="{{ url_for('flux_bulb') }}" alt="Flux Bulb" /></div>
							<div class="meta"><div class="name">Flux Bulb</div><div class="price">€14.99</div></div>
						</div>
						<div class="product">
							<div class="thumb"><img src="{{ url_for('hint_bulb') }}" alt="Hint Bulb" /></div>
							<div class="meta"><div class="name">Hint Bulb</div><div class="price">€11.99</div></div>
						</div>
					</div>

					<div class="game">
						<div class="wheel-wrap">
							<div class="pointer"></div>
							<div class="wheel">
								{% for i in range(16) %}
									{% set ang = i * (360/16) %}
									<div class="tick" style="transform: translate(-50%, -50%) rotate({{ang}}deg) translate(90px) rotate(-{{ang}}deg);"></div>
									<div class="label" style="transform: translate(-50%, -50%) rotate({{ang}}deg) translate(70px) rotate(-{{ang}}deg);"><span class="label-inner" style="transform: rotate(calc(-1 * var(--spin)));">{{wheel_numbers[i]}}</span></div>
								{% endfor %}
							</div>
						</div>

									<form id="guess-form" method="post" action="{{ url_for('guess') }}">
										<label for="guess">Your guess (hex, up to 32 digits):</label>
										<input id="guess" name="guess" type="text" inputmode="text" autocomplete="off" spellcheck="false" autocapitalize="off" pattern="[0-9a-fA-F]{1,32}" maxlength="32" placeholder="e.g. DEADBEEF..." required />
							<button type="submit">Try my luck</button>
						</form>
                        
					</div>
				</div>
			</div>
			<br />
			<div id="banner" class="msg hidden"></div>
		</div>
					<script>
						(function(){
							const form = document.getElementById('guess-form');
							const banner = document.getElementById('banner');
							const guessInput = document.getElementById('guess');
							// live sanitize: hex-only, uppercase, clamp to 32 chars
							guessInput.addEventListener('input', () => {
								let v = guessInput.value.replace(/[^0-9a-fA-F]/g, '');
								if (v.length > 32) v = v.slice(0, 32);
								guessInput.value = v.toUpperCase();
							});
							form.addEventListener('submit', async (e) => {
								e.preventDefault();
								const hex = guessInput.value.trim();
								if (!/^[0-9A-F]{1,32}$/.test(hex)) {
									banner.textContent = 'Please enter 1–32 hex digits (0-9, A-F).';
									banner.classList.remove('hidden', 'ok');
									banner.classList.add('err');
									return;
								}
								let decimal = '0';
								try {
									decimal = BigInt('0x' + hex).toString(10);
								} catch (_) {
									banner.textContent = 'Invalid hex value.';
									banner.classList.remove('hidden', 'ok');
									banner.classList.add('err');
									return;
								}
								const body = new URLSearchParams({ guess: decimal }).toString();
								try {
									const res = await fetch(form.action, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body });
									const data = await res.json();
									banner.textContent = data.message || 'Unexpected response';
									banner.classList.remove('hidden', 'ok', 'err');
									banner.classList.add(data.status === 'ok' ? 'ok' : 'err');
								} catch (err) {
									banner.textContent = 'Network error. Please try again later.';
									banner.classList.remove('hidden', 'ok');
									banner.classList.add('err');
								}
							});

							// Keep label text orientation constant while wheel spins
							const wheel = document.querySelector('.wheel');
							function updateSpin(){
								if(!wheel){ return; }
								const tr = getComputedStyle(wheel).transform;
								let deg = 0;
								if (tr && tr !== 'none') {
									try {
										const m = new DOMMatrixReadOnly(tr);
										deg = Math.atan2(m.b, m.a) * (180/Math.PI);
									} catch(_) { /* DOMMatrix may not be available in very old browsers */ }
								}
								wheel.style.setProperty('--spin', deg.toFixed(3) + 'deg');
								requestAnimationFrame(updateSpin);
							}
							requestAnimationFrame(updateSpin);
						})();
					</script>
	</body>
	</html>
	"""
    return render_template_string(
        tmpl,
        hues=hues,
        wheel_numbers=wheel_numbers,
    )


@app.get("/")
def home():
	token = request.cookies.get(SEED_COOKIE)
	seed_tuple = decrypt_seed(token) if token else None
	if seed_tuple is None:
		seed = new_seed()
	else:
		seed = seed_tuple[0]  # Extract seed from tuple
	resp = make_response(render_page(seed))
	# NOTE RNG draw order per page load:
	#   - hues: generate_hues consumes 2 * 10 = 20 nybbles (calls to rng.next())
	#   - target (NOT yet drawn here). We only draw target during /guess to keep state minimal.
	resp.set_cookie(
		SEED_COOKIE,
		encrypt_seed(seed),
		httponly=True,
		secure=False,  # set True behind HTTPS
		samesite='Lax',
		max_age=300,
	)
	return resp


@app.get('/bg.jpg')
def bg_image():
	# Serve the background image from project root
	here = os.path.dirname(os.path.abspath(__file__))
	return send_from_directory(here, os.path.join('images', 'bg.jpg'))


@app.get('/logo.png')
def logo_image():
	# Serve the background image from project root
	here = os.path.dirname(os.path.abspath(__file__))
	return send_from_directory(here, os.path.join('images', 'logo.png'))


@app.get('/futurapress.ttf')
def font_futurapress():
	here = os.path.dirname(os.path.abspath(__file__))
	fonts_dir = os.path.join(here, 'futurapress')
	return send_from_directory(fonts_dir, 'Junior.ttf', mimetype='font/ttf')


@app.get('/light_bulb.png')
def light_bulb():
	here = os.path.dirname(os.path.abspath(__file__))
	return send_from_directory(here, os.path.join('images', 'light_bulb.png'))


@app.get('/flux_bulb.png')
def flux_bulb():
	here = os.path.dirname(os.path.abspath(__file__))
	return send_from_directory(here, os.path.join('images', 'flux_bulb.png'))


@app.get('/hint_bulb.png')
def hint_bulb():
	here = os.path.dirname(os.path.abspath(__file__))
	return send_from_directory(here, os.path.join('images', 'hint_bulb.png'))


@app.post("/guess")
def guess():
	token = request.cookies.get(SEED_COOKIE)
	seed_tuple = decrypt_seed(token) if token else None
	# Always rotate seed after guess
	new_seed_val = new_seed()

	def loss_response():
		resp = make_response(jsonify(status="err", message="You lost the game, please try again next time you visit us!"))
		resp.set_cookie(SEED_COOKIE, encrypt_seed(new_seed_val), httponly=True, secure=False, samesite='Lax', max_age=300)
		return resp

	if seed_tuple is None:
		return loss_response()

	seed, timestamp = seed_tuple
	
	# Check if cookie is older than 30 minutes
	current_time = int(time.time())
	if current_time - timestamp > 1800:  # 1800 seconds = 30 minutes
		return loss_response()

	# Reconstruct RNG state and advance past hue generation exactly like home() did.
	rng = PRNG(seed)
	_ = generate_hues(rng)  # consume 20 draws for hues exactly as in home()
	# Next 32 draws (nybbles) define the 128-bit target
	target = compute_target(rng)

	raw = request.form.get("guess", "").strip()
	if not raw.isdigit():
		return loss_response()
	raw = raw.lstrip('0') or '0'
	try:
		val = int(raw)
	except ValueError:
		return loss_response()
	if not (0 <= val <= (1 << 128) - 1):
		return loss_response()

	if val == target:
		coupon = app.config.get("COUPON_CODE", "No coupon found :(")
		resp = make_response(jsonify(status="ok", message=f"You won, here is your coupon code: {coupon}"))
		resp.set_cookie(SEED_COOKIE, encrypt_seed(new_seed_val), httponly=True, secure=False, samesite='Lax', max_age=300)
		return resp
	else:
		return loss_response()


@app.get("/reset")
def reset():
	resp = make_response(redirect(url_for("home")))
	resp.set_cookie(SEED_COOKIE, '', max_age=0)
	return resp


if __name__ == "__main__":
	# Single instance server for single CTF team
	port = 5000
	host = "0.0.0.0"
	app.run(host=host, port=port, debug=False)

