# Showroom Raffle Server

A tiny Flask webserver that serves an IKEA-like showroom scene which features a spinning raffle wheel, and a numeric guess form (0–9A-F). Guess right to win a coupon :D

## Quick start

```
docker-compose up
```

Open http://127.0.0.1:5000 in your browser.
