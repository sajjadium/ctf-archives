#!/bin/sh
# script to start the worker locally, usefull for debugging

WORKER_PORT="${WORKER_PORT:-9090}"
socat -t5 tcp-listen:$WORKER_PORT,max-children=10,reuseaddr,fork exec:./worker
