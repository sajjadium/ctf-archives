#include <stdint.h>
#include <stddef.h>

#define MAX_FRAME_LEN 255

typedef int (*frame_receive_callback)(uint8_t *buf, size_t n, void*);

typedef struct Com Com_t;

Com_t *com_init(int receive_fd, int send_fd, frame_receive_callback receive_callback, void *user_data);
void com_receive_loop(Com_t *com);
void com_send(uint8_t *buf, size_t n, Com_t *com);

