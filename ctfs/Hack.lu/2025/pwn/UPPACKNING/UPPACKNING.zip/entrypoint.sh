#!/bin/sh

echo "${FLAG:-flag\{**********\}}" > flag
chown ctf:ctf flag
chmod 400 flag

./ynetd -u worker -a 127.0.0.1 -p 9090 ./worker &
./ynetd -u ctf -lm 1073741824 ./main
