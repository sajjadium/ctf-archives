#!/usr/bin/env bash

echo $FLAG > /flag
unset FLAG

chown root:root /flag
chmod 400 /flag

while true; do
  WAYLAND_DISPLAY=/knopp /fönster
done &

dropbear -wFmp 443
