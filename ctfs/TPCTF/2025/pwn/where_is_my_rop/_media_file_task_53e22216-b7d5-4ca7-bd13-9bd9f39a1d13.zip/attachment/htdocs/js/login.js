function hexToBinaryString(hexString) {
    if (hexString.length % 2 !== 0) {
        throw new Error("Invalid hex string");
    }

    let byteArray = [];
    
    for (let i = 0; i < hexString.length; i += 2) {
        let byte = parseInt(hexString.substring(i, i + 2), 16);
        byteArray.push(byte);
    }

    let binaryString = String.fromCharCode.apply(null, byteArray);
    
    return binaryString;
}

function login(params) {
    var id = params.get('id');
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    username = encodeURIComponent(username);
    password = encodeURIComponent(password);
    id = encodeURIComponent(id);
    var xhr = new XMLHttpRequest();
    var url = "/cgi-bin/gen_enc?password=" + password;
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            var response = xhr.responseText;
            var parser = new DOMParser();
            var Doc = parser.parseFromString(response, "text/html");
            var encryptedPassword = Doc.body.textContent;
            password = encryptedPassword
            
            sendLoginRequest(username, password, id);
        }
    }
    xhr.send();
}

function sendLoginRequest(username, password, id) {
    var Authorization_params = username + ":" + password;

    var Authorization =  btoa(Authorization_params);
    var xhr = new XMLHttpRequest();
    var url = "/cgi-bin/login.cgi?login";
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.setRequestHeader("Authorization","Basic " + Authorization);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 400) {
                var responseContainer = document.getElementById("error-message");
                responseContainer.innerHTML = xhr.responseText;
                return;
            }
            var responseContainer = document.getElementById("error-message");
            var redirectUrl = xhr.getResponseHeader("X-Redirect-URL");
            if (redirectUrl) {
                window.location.href = redirectUrl;
            } else if (xhr.status === 200) {
                responseContainer.innerHTML = "Login successful: " + xhr.responseText;
            } else {
                responseContainer.innerHTML = "Login failed with status: " + xhr.status + ", response: " + xhr.responseText;
            }
        }
    };

    xhr.send("id=" + id);
}