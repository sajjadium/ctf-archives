#!/bin/bash
service apache2 start
/usr/local/sbin/basement