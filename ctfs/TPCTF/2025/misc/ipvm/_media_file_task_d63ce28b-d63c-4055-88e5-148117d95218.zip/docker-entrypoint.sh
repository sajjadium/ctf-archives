#!/bin/bash

su ctf -c "fastapi run server.py"
