#!/bin/sh

su ctf -c "$JAVA_HOME/bin/java -jar /app.jar"
