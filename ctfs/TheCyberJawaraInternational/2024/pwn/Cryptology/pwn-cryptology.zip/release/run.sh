#!/bin/bash

cd /home/user && ./cryptology

