#!/bin/sh
set -eu

if [ "$(id -u)" -ne 0 ]; then
  echo "run this script as root" >&2
  exit 1
fi

root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
flag="$root/flag.txt"
if [ ! -f "$flag" ]; then
  echo "missing $flag" >&2
  exit 1
fi
chown root:root "$flag"
chmod 0400 "$flag"
docker compose -f "$root/compose.yaml" up --build -d
