#!/bin/sh
set -eu
export V8ACKUP_CHALLENGE=1
export DB_PATH=/data/store.sqlite
exec /usr/bin/timeout -k 1s 180s /usr/local/bin/d8 \
  --jitless --no-harmony-sharedarraybuffer \
  /opt/v8ackup/service.js
