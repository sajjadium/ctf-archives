(function () {
  const readLine = readline;
  delete globalThis.readline;
  const digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  function decode(line) {
    if (!line || line.length % 4 !== 0) throw new Error("invalid base64");
    const bytes = [];
    for (let i = 0; i < line.length; i += 4) {
      const a = digits.indexOf(line[i]);
      const b = digits.indexOf(line[i + 1]);
      const pad2 = line[i + 2] === "=";
      const pad3 = line[i + 3] === "=";
      const c = pad2 ? 0 : digits.indexOf(line[i + 2]);
      const d = pad3 ? 0 : digits.indexOf(line[i + 3]);
      if (a < 0 || b < 0 || c < 0 || d < 0 || (pad2 && !pad3) ||
          ((pad2 || pad3) && i + 4 !== line.length)) {
        throw new Error("invalid base64");
      }
      bytes.push((a << 2) | (b >> 4));
      if (!pad2) bytes.push(((b << 4) | (c >> 2)) & 255);
      if (!pad3) bytes.push(((c << 6) | d) & 255);
    }
    return decodeURIComponent(bytes.map(x => "%" + x.toString(16).padStart(2, "0")).join(""));
  }

  print("base64 js> ");
  const raw = readLine();
  if (typeof raw === "string" && raw.length <= 65536) {
    const line = raw.endsWith("\r") ? raw.slice(0, -1) : raw;
    try {
      (0, eval)(decode(line));
    } catch (error) {
      print("Error: " + error);
    }
    print("--END--");
  }
})();
