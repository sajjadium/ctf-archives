import json
import math
import sys
import types


_allowed = {4, 23, 34, 50, 82}

def check(obj, seen):
    if id(obj) in seen:
        return

    seen.add(id(obj))

    if type(obj) is types.CodeType:
        assert obj.co_names == ()
        assert set(obj._co_code_adaptive[::2]) <= _allowed
        
        for value in obj.co_consts:
            check(value, seen)

    elif type(obj) in (tuple, list, set, frozenset):
        for value in obj:
            check(value, seen)

    elif type(obj) is dict:
        for key, value in obj.items():
            check(key, seen)
            check(value, seen)

    elif type(obj) is slice:
        check(obj.start, seen)
        check(obj.stop, seen)
        check(obj.step, seen)


def audit(event, args):
    if event == "exec":
        check(args[0], set())

sys.addaudithook(audit)

def one(step):
    if type(step) is not list or len(step) != 1 or type(step[0]) not in (str, int):
        raise ValueError("bad step")
    return step[0]


def slot(path):
    obj = math
    for step in path[:-1]:
        obj = getattr(obj, step) if type(step) is str else obj[one(step)]
    key = one(path[-1])
    return obj, key, obj[key]


pairs = json.loads(input("> "))
assert len(pairs) == 2 and all(
    len(pair) == 2 and all(1 <= len(path) <= 6 for path in pair)
    for pair in pairs
) and sum(len(path) for pair in pairs for path in pair) <= 12

resolved = [(slot(a), slot(b)) for a, b in pairs]
for (x, i, u), (y, j, v) in resolved:
    x[i], y[j] = v, u
