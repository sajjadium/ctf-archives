use std::collections::HashMap;
use std::path::Path;
use std::sync::Mutex;
use tokio::sync::mpsc;

use crate::filesystem::{FileHandle, Filesystem};
use crate::io_uring::{
    CompletionQueueEntry, IoUringKernelHandle, IoUringOp, IoUringUserHandle, io_uring_setup,
};

const IO_URING_CAPACITY: usize = 320;
const INTERNAL_CHANNEL_CAPACITY: usize = 160;

struct Process {
    owner: u16,
    io_uring: IoUringKernelHandle,
}

enum FilesystemOp {
    Create {
        path: *const Path,
        public_read: bool,
        public_write: bool,
    },
    Open {
        path: *const Path,
        write: bool,
    },
    Symlink {
        src: *const Path,
        dst: *const Path,
    },
    Unlink {
        path: *const Path,
    },
}

impl TryFrom<&IoUringOp> for FilesystemOp {
    type Error = ();
    fn try_from(value: &IoUringOp) -> Result<Self, Self::Error> {
        match value {
            IoUringOp::Create {
                path,
                public_read,
                public_write,
            } => Ok(FilesystemOp::Create {
                path: *path,
                public_read: *public_read,
                public_write: *public_write,
            }),
            IoUringOp::Open { path, write } => Ok(FilesystemOp::Open {
                path: *path,
                write: *write,
            }),
            IoUringOp::Symlink { src, dst } => Ok(FilesystemOp::Symlink {
                src: *src,
                dst: *dst,
            }),
            IoUringOp::Unlink { path } => Ok(FilesystemOp::Unlink { path: *path }),
            _ => Err(()),
        }
    }
}

struct FilesystemOpEntry {
    op: FilesystemOp,
    uid: u16,
    pid: usize,
    user_data: u64,
}

enum FileOp {
    Read { offset: usize, buf: *mut [u8] },
    Write { buf: *const [u8] },
    Close,
}

impl TryFrom<&IoUringOp> for (i32, FileOp) {
    type Error = ();
    fn try_from(value: &IoUringOp) -> Result<Self, Self::Error> {
        match value {
            IoUringOp::Read { fd, offset, buf } => Ok((
                *fd,
                FileOp::Read {
                    offset: *offset,
                    buf: *buf,
                },
            )),
            IoUringOp::Write { fd, buf } => Ok((*fd, FileOp::Write { buf: *buf })),
            IoUringOp::Close { fd } => Ok((*fd, FileOp::Close)),
            _ => Err(()),
        }
    }
}

struct FileOpEntry {
    op: FileOp,
    pid: usize,
    user_data: u64,
    handle: Option<FileHandle>,
}

struct OpResult {
    pid: usize,
    user_data: u64,
    res: i32,
}

#[derive(Default)]
pub struct Kernel {
    filesystem: Filesystem,
    fd_map: Mutex<HashMap<(usize, i32), FileHandle>>,
    processes: Vec<Process>,
}

impl Kernel {
    pub fn new() -> Self {
        Default::default()
    }
    pub fn new_process(&mut self, owner: u16) -> IoUringUserHandle {
        let (user_handle, kernel_handle) = io_uring_setup(IO_URING_CAPACITY);
        let process = Process {
            owner,
            io_uring: kernel_handle,
        };
        self.processes.push(process);
        user_handle
    }
    async fn read_io_urings(
        processes: &[Process],
        fd_map: &Mutex<HashMap<(usize, i32), FileHandle>>,
        fs_task_sender: &mpsc::Sender<FilesystemOpEntry>,
        file_task_sender: &mpsc::Sender<FileOpEntry>,
    ) {
        for (pid, process) in processes.iter().enumerate() {
            if let Some(submission) = process.io_uring.pop().await {
                if let Ok(op) = FilesystemOp::try_from(&submission.op) {
                    let _ = fs_task_sender
                        .send(FilesystemOpEntry {
                            op,
                            uid: process.owner,
                            pid,
                            user_data: submission.user_data,
                        })
                        .await;
                } else if let Ok((fd, op)) = <(i32, FileOp)>::try_from(&submission.op) {
                    let handle = {
                        let fd_map = fd_map.lock().unwrap();
                        fd_map.get(&(pid, fd)).cloned()
                    };
                    let _ = file_task_sender
                        .send(FileOpEntry {
                            op,
                            pid,
                            user_data: submission.user_data,
                            handle,
                        })
                        .await;
                }
            }
        }
    }
    async fn write_io_urings(
        processes: &[Process],
        result_sender: &mpsc::Sender<OpResult>,
        result_receiver: &mut mpsc::Receiver<OpResult>,
    ) {
        let Some(result) = result_receiver.recv().await else {
            return;
        };
        let OpResult {
            pid,
            user_data,
            res,
        } = result;
        match processes[pid]
            .io_uring
            .push(CompletionQueueEntry { user_data, res })
            .await
        {
            Ok(_) => {}
            Err(_) => {
                let _ = result_sender
                    .send(OpResult {
                        pid,
                        user_data,
                        res,
                    })
                    .await;
            }
        }
    }
    async fn process_filesystem(
        filesystem: &mut Filesystem,
        fd_map: &Mutex<HashMap<(usize, i32), FileHandle>>,
        fs_task_receiver: &mut mpsc::Receiver<FilesystemOpEntry>,
        result_sender: &mpsc::Sender<OpResult>,
    ) {
        let Some(task) = fs_task_receiver.recv().await else {
            return;
        };
        let res = match task.op {
            FilesystemOp::Create {
                path,
                public_read,
                public_write,
            } => {
                match unsafe { filesystem.create_file(&*path, task.uid, public_read, public_write) }
                {
                    Ok(()) => 0,
                    Err(err) => -(err as i32),
                }
            }
            FilesystemOp::Open { path, write } => {
                match unsafe { filesystem.open(task.uid, &*path, write) } {
                    Ok(handle) => {
                        let mut fd_map = fd_map.lock().unwrap();
                        let new_fd = (0..i32::MAX)
                            .find(|fd| !fd_map.contains_key(&(task.pid, *fd)))
                            .unwrap();
                        fd_map.insert((task.pid, new_fd), handle);
                        new_fd
                    }
                    Err(err) => -(err as i32),
                }
            }
            FilesystemOp::Symlink { src, dst } => {
                match unsafe { filesystem.create_symlink(&*src, &*dst, task.uid) } {
                    Ok(()) => 0,
                    Err(err) => -(err as i32),
                }
            }
            FilesystemOp::Unlink { path } => match unsafe { filesystem.unlink(&*path, task.uid) } {
                Ok(()) => 0,
                Err(err) => -(err as i32),
            },
        };
        let _ = result_sender
            .send(OpResult {
                pid: task.pid,
                user_data: task.user_data,
                res,
            })
            .await;
    }
    async fn process_files(
        file_task_receiver: &mut mpsc::Receiver<FileOpEntry>,
        result_sender: &mpsc::Sender<OpResult>,
    ) {
        let Some(task) = file_task_receiver.recv().await else {
            return;
        };
        let res = match task.handle {
            Some(handle) => match task.op {
                FileOp::Read { offset, buf } => match unsafe { handle.read(offset, &mut *buf) } {
                    Ok(len) => len as i32,
                    Err(err) => -(err as i32),
                },
                FileOp::Write { buf } => match unsafe { handle.write(&*buf) } {
                    Ok(len) => len as i32,
                    Err(err) => -(err as i32),
                },
                FileOp::Close => {
                    handle.close();
                    0
                }
            },
            None => -(crate::filesystem::FsError::InvalidHandle as i32),
        };
        let _ = result_sender
            .send(OpResult {
                pid: task.pid,
                user_data: task.user_data,
                res,
            })
            .await;
    }
    pub async fn run_kernel_thread(mut self) {
        let (result_sender, mut result_receiver) = mpsc::channel(INTERNAL_CHANNEL_CAPACITY);
        let (fs_task_sender, mut fs_task_receiver) = mpsc::channel(INTERNAL_CHANNEL_CAPACITY);
        let (file_task_sender, mut file_task_receiver) = mpsc::channel(INTERNAL_CHANNEL_CAPACITY);
        loop {
            tokio::select! {
                _ = Self::read_io_urings(&self.processes, &self.fd_map, &fs_task_sender, &file_task_sender) => {}
                _ = Self::write_io_urings(&self.processes, &result_sender, &mut result_receiver) => {}
                _ = Self::process_filesystem(&mut self.filesystem, &self.fd_map, &mut fs_task_receiver, &result_sender) => {}
                _ = Self::process_files(&mut file_task_receiver, &result_sender) => {}
            }
        }
    }
}
