use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex, Weak};

const SIZE_LIMIT: usize = 1_024;
const FILE_LIMIT: usize = 1_024;
const FILENAME_LIMIT: usize = 100;

pub enum Object {
    File { contents: Vec<u8> },
    Symlink { target: PathBuf },
}

#[derive(Clone)]
pub struct Inode {
    index: u64,
    owner: u16,
    public_read: bool,
    public_write: bool,
}

pub struct FileHandle {
    index: u64,
    write: bool,
    storage: Weak<Mutex<HashMap<u64, (Object, usize)>>>,
}

#[derive(Default)]
pub struct Filesystem {
    inodes: HashMap<PathBuf, Inode>,
    storage: Arc<Mutex<HashMap<u64, (Object, usize)>>>,
}

pub enum FsError {
    InvalidPath = 1,
    InvalidOp = 2,
    FileNotExist = 3,
    FileExists = 4,
    QuotaReached = 5,
    PermissionError = 6,
    FileBusy = 7,
    LinkCycle = 8,
    InvalidHandle = 9,
}

impl Filesystem {
    fn insert_at_new_index(&mut self, object: Object) -> Result<u64, FsError> {
        let mut storage = self.storage.lock().unwrap();
        if storage.len() >= FILE_LIMIT {
            return Err(FsError::QuotaReached);
        }
        let index = (u64::MIN..=u64::MAX)
            .find(|index| !storage.contains_key(index))
            .unwrap();
        let refcount = 1;
        storage.insert(index, (object, refcount));
        Ok(index)
    }
    pub fn create_file(
        &mut self,
        filename: impl AsRef<Path>,
        owner: u16,
        public_read: bool,
        public_write: bool,
    ) -> Result<(), FsError> {
        let filename = Self::canonicalize_path(filename.as_ref())?;
        if self.resolve_symlink(&filename).is_ok() {
            return Err(FsError::FileExists);
        }
        let file = Object::File {
            contents: Vec::new(),
        };
        let index = self.insert_at_new_index(file)?;
        let inode = Inode {
            index,
            owner,
            public_read,
            public_write,
        };
        self.inodes.insert(filename, inode);
        Ok(())
    }
    pub fn create_symlink(
        &mut self,
        filename: impl AsRef<Path>,
        target: impl AsRef<Path>,
        owner: u16,
    ) -> Result<(), FsError> {
        let filename = Self::canonicalize_path(filename.as_ref())?;
        let target = Self::canonicalize_path(target.as_ref())?;
        if self.resolve_symlink(&filename).is_ok() {
            return Err(FsError::FileExists);
        }
        let symlink = Object::Symlink { target };
        let index = self.insert_at_new_index(symlink)?;
        let inode = Inode {
            index,
            owner,
            public_read: true,
            public_write: true,
        };
        self.inodes.insert(filename, inode);
        Ok(())
    }
    pub fn open(
        &mut self,
        user: u16,
        filename: impl AsRef<Path>,
        write: bool,
    ) -> Result<FileHandle, FsError> {
        let filename = Self::canonicalize_path(filename.as_ref())?;
        let inode = self.resolve_symlink(filename)?;
        if user != inode.owner && ((write && !inode.public_write) || (!write && !inode.public_read))
        {
            return Err(FsError::PermissionError);
        }
        let mut storage = self.storage.lock().unwrap();
        let Some((_, refcount)) = storage.get_mut(&inode.index) else {
            return Err(FsError::FileNotExist);
        };
        *refcount += 1;
        Ok(FileHandle {
            index: inode.index,
            write,
            storage: Arc::downgrade(&self.storage),
        })
    }
    pub fn unlink(&mut self, path: impl AsRef<Path>, user: u16) -> Result<(), FsError> {
        let path = Self::canonicalize_path(path.as_ref())?;
        let Some(inode) = self.inodes.get(&path) else {
            return Err(FsError::FileNotExist);
        };
        if user != inode.owner && !inode.public_write {
            return Err(FsError::PermissionError);
        }
        let inode = self.inodes.remove(&path).unwrap();
        let mut storage = self.storage.lock().unwrap();
        let Some((_, refcount)) = storage.get_mut(&inode.index) else {
            return Err(FsError::FileNotExist);
        };
        *refcount -= 1;
        if *refcount == 0 {
            storage.remove(&inode.index);
        }
        Ok(())
    }
    fn canonicalize_path(path: &Path) -> Result<PathBuf, FsError> {
        use std::path::Component;
        let mut result = PathBuf::from("/");
        for component in path.components() {
            match component {
                Component::Prefix(_) => unreachable!(),
                Component::RootDir => {}
                Component::CurDir => {}
                Component::ParentDir => {
                    if !result.pop() {
                        return Err(FsError::InvalidPath);
                    }
                }
                Component::Normal(name) => {
                    result.push(name);
                }
            }
        }
        (result.as_os_str().len() < FILENAME_LIMIT)
            .then_some(result)
            .ok_or(FsError::InvalidPath)
    }
    fn resolve_symlink(&self, path: impl AsRef<Path>) -> Result<Inode, FsError> {
        let mut seen = HashSet::<PathBuf>::new();
        let mut cur = path.as_ref();
        let storage = self.storage.lock().unwrap();
        loop {
            if !seen.insert(cur.to_owned()) {
                return Err(FsError::LinkCycle);
            }
            let Some(inode) = self.inodes.get(cur) else {
                return Err(FsError::FileNotExist);
            };
            match storage.get(&inode.index) {
                Some((Object::File { .. }, _)) => {
                    return Ok(inode.clone());
                }
                Some((Object::Symlink { target }, _)) => {
                    cur = target;
                }
                None => {
                    return Err(FsError::FileNotExist);
                }
            }
        }
    }
}

impl FileHandle {
    pub fn close(self) {
        drop(self);
    }
    pub fn read(&self, offset: usize, buf: &mut [u8]) -> Result<usize, FsError> {
        if self.write {
            return Err(FsError::InvalidOp);
        }
        let Some(storage) = self.storage.upgrade() else {
            return Ok(0);
        };
        let Ok(storage) = storage.try_lock() else {
            return Err(FsError::FileBusy);
        };
        let Some((Object::File { contents }, _)) = storage.get(&self.index) else {
            return Err(FsError::FileNotExist);
        };
        if buf.len() + offset < contents.len() {
            buf.copy_from_slice(&contents[offset..offset + buf.len()]);
            Ok(buf.len())
        } else if offset >= contents.len() {
            Ok(0)
        } else {
            let len = contents.len() - offset;
            buf[..len].copy_from_slice(&contents[offset..offset + len]);
            Ok(len)
        }
    }
    pub fn write(&self, buf: &[u8]) -> Result<usize, FsError> {
        if !self.write {
            return Err(FsError::InvalidOp);
        }
        if buf.len() > SIZE_LIMIT {
            return Err(FsError::QuotaReached);
        }
        let Some(storage) = self.storage.upgrade() else {
            return Ok(0);
        };
        let Ok(mut storage) = storage.try_lock() else {
            return Err(FsError::FileBusy);
        };
        let Some((Object::File { contents }, _)) = storage.get_mut(&self.index) else {
            return Err(FsError::FileNotExist);
        };
        *contents = buf.to_vec();
        Ok(buf.len())
    }
}

impl Clone for FileHandle {
    fn clone(&self) -> Self {
        let storage = self.storage.upgrade().unwrap();
        let mut storage = storage.lock().unwrap();
        let (_, refcount) = storage.get_mut(&self.index).unwrap();
        *refcount += 1;
        Self {
            index: self.index,
            write: self.write,
            storage: Weak::clone(&self.storage),
        }
    }
}

impl Drop for FileHandle {
    fn drop(&mut self) {
        let Some(storage) = self.storage.upgrade() else {
            return;
        };
        let Ok(mut storage) = storage.try_lock() else {
            return;
        };
        let Some((_, refcount)) = storage.get_mut(&self.index) else {
            return;
        };
        *refcount -= 1;
        if *refcount == 0 {
            storage.remove(&self.index);
        }
    }
}
