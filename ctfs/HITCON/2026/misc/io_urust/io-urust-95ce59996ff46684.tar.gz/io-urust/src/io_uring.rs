use std::path::Path;
use std::sync::Arc;
use tokio::sync::Mutex;

#[derive(Default)]
#[non_exhaustive]
pub enum IoUringOp {
    #[default]
    Nop,
    Create {
        path: *const Path,
        public_read: bool,
        public_write: bool,
    },
    Open {
        path: *const Path,
        write: bool,
    },
    Close {
        fd: i32,
    },
    Symlink {
        src: *const Path,
        dst: *const Path,
    },
    Unlink {
        path: *const Path,
    },
    Read {
        fd: i32,
        offset: usize,
        buf: *mut [u8],
    },
    Write {
        fd: i32,
        buf: *const [u8],
    },
}

unsafe impl Send for IoUringOp {}
unsafe impl Sync for IoUringOp {}

#[derive(Default)]
pub struct SubmissionQueueEntry {
    pub op: IoUringOp,
    pub user_data: u64,
}

#[derive(Default)]
pub struct CompletionQueueEntry {
    pub user_data: u64,
    pub res: i32,
}

struct Uring<T>
where
    T: Default,
{
    head: usize,
    tail: usize,
    capacity: usize,
    mask: usize,
    buf: Box<[T]>,
}

impl<T> Uring<T>
where
    T: Default,
{
    fn new(capacity: usize) -> Self {
        let head = 0;
        let tail = 0;
        let capacity = capacity.next_power_of_two();
        let mask = capacity - 1;
        let buf = std::iter::repeat_with(T::default).take(capacity).collect();
        Self {
            head,
            tail,
            capacity,
            mask,
            buf,
        }
    }
    fn len(&self) -> usize {
        self.tail - self.head
    }
    fn push(&mut self, item: T) -> Result<(), T> {
        if self.len() >= self.capacity {
            return Err(item);
        }
        let idx = self.tail & self.mask;
        self.buf[idx] = item;
        self.tail += 1;
        Ok(())
    }
    fn pop(&mut self) -> Option<T> {
        if self.len() == 0 {
            return None;
        }
        let idx = self.head & self.mask;
        let item = std::mem::take(&mut self.buf[idx]);
        self.head += 1;
        Some(item)
    }
}

struct IoUring {
    sq_uring: Mutex<Uring<SubmissionQueueEntry>>,
    cq_uring: Mutex<Uring<CompletionQueueEntry>>,
}

impl IoUring {
    fn new(capacity: usize) -> Self {
        let sq_uring = Uring::new(capacity);
        let cq_uring = Uring::new(capacity);
        Self {
            sq_uring: Mutex::new(sq_uring),
            cq_uring: Mutex::new(cq_uring),
        }
    }
}

pub struct IoUringUserHandle(Arc<IoUring>);

impl IoUringUserHandle {
    pub async fn push(&self, submission: SubmissionQueueEntry) -> Result<(), SubmissionQueueEntry> {
        let mut sq_uring = self.0.sq_uring.lock().await;
        sq_uring.push(submission)
    }
    pub async fn pop(&self) -> Option<CompletionQueueEntry> {
        let mut cq_uring = self.0.cq_uring.lock().await;
        cq_uring.pop()
    }
}

pub struct IoUringKernelHandle(Arc<IoUring>);

impl IoUringKernelHandle {
    pub async fn push(&self, completion: CompletionQueueEntry) -> Result<(), CompletionQueueEntry> {
        let mut cq_uring = self.0.cq_uring.lock().await;
        cq_uring.push(completion)
    }
    pub async fn pop(&self) -> Option<SubmissionQueueEntry> {
        let mut sq_uring = self.0.sq_uring.lock().await;
        sq_uring.pop()
    }
}

pub fn io_uring_setup(capacity: usize) -> (IoUringUserHandle, IoUringKernelHandle) {
    let uring = Arc::new(IoUring::new(capacity));
    let user_handle = IoUringUserHandle(Arc::clone(&uring));
    let kernel_handle = IoUringKernelHandle(Arc::clone(&uring));
    (user_handle, kernel_handle)
}
