use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicI32, Ordering};
use tokio::time::{Duration, sleep};

use crate::io_uring::{IoUringOp, IoUringUserHandle, SubmissionQueueEntry};
use crate::kernel::Kernel;

pub struct RootUser {
    io_uring: IoUringUserHandle,
    flag: String,
    flag_fd: AtomicI32,
}

impl RootUser {
    const UID: u16 = 0;
    pub fn new_in(kernel: &mut Kernel, flag: String) -> Self {
        let io_uring = kernel.new_process(Self::UID);
        Self {
            io_uring,
            flag,
            flag_fd: AtomicI32::new(-1),
        }
    }
    async fn do_actions(&self) {
        sleep(Duration::from_millis(1000)).await;
        let _ = self
            .io_uring
            .push(SubmissionQueueEntry {
                op: IoUringOp::Create {
                    path: Path::new("/flag.txt"),
                    public_read: false,
                    public_write: false,
                },
                user_data: 0xdeadbeef,
            })
            .await;
        sleep(Duration::from_millis(1000)).await;
        let _ = self
            .io_uring
            .push(SubmissionQueueEntry {
                op: IoUringOp::Open {
                    path: Path::new("/flag.txt"),
                    write: true,
                },
                user_data: 0xfeedcafe,
            })
            .await;
        sleep(Duration::from_millis(1000)).await;
        let flag_fd = self.flag_fd.load(Ordering::SeqCst);
        let _ = self
            .io_uring
            .push(SubmissionQueueEntry {
                op: IoUringOp::Write {
                    fd: flag_fd,
                    buf: self.flag.as_bytes(),
                },
                user_data: 0x13371337,
            })
            .await;
        sleep(Duration::from_millis(1000)).await;
        let flag_fd = self.flag_fd.load(Ordering::SeqCst);
        let _ = self
            .io_uring
            .push(SubmissionQueueEntry {
                op: IoUringOp::Close { fd: flag_fd },
                user_data: 69420,
            })
            .await;
        sleep(Duration::from_millis(1000)).await;
        let _ = self
            .io_uring
            .push(SubmissionQueueEntry {
                op: IoUringOp::Unlink {
                    path: Path::new("/flag.txt"),
                },
                user_data: 67,
            })
            .await;
    }
    async fn handle_results(&self, compromised: &mut bool) {
        let Some(result) = self.io_uring.pop().await else {
            return;
        };
        if result.res < 0 {
            *compromised = true;
            return;
        }
        match result.user_data {
            0x13371337 => {
                if result.res != self.flag.len() as i32 {
                    *compromised = true;
                }
            }
            0xfeedcafe => {
                self.flag_fd.store(result.res, Ordering::SeqCst);
            }
            _ => {}
        }
    }
    pub async fn run(self) {
        let actions = self.do_actions();
        tokio::pin!(actions);
        let mut compromised = false;
        loop {
            tokio::select! {
                _ = &mut actions => {
                    return;
                }
                _ = self.handle_results(&mut compromised) => {}
            }
            if compromised {
                println!("[root] detected threat actor :((");
                return;
            }
        }
    }
}

pub struct RegularUser {
    io_uring: IoUringUserHandle,
    path_alloc: Vec<Box<Path>>,
    buf_alloc: HashMap<u64, Box<[u8]>>,
}

impl RegularUser {
    pub fn new_in(kernel: &mut Kernel, uid: u16) -> Self {
        let io_uring = kernel.new_process(uid);
        Self {
            io_uring,
            path_alloc: Vec::new(),
            buf_alloc: HashMap::new(),
        }
    }
    async fn run_command(&mut self, command: &str) -> Option<SubmissionQueueEntry> {
        let tokens: Vec<&str> = command.split_whitespace().collect();
        let user_data_hex = tokens.first()?;
        let tokens = &tokens[1..];
        let user_data = {
            let mut buf = [0u8; 8];
            hex::decode_to_slice(user_data_hex, &mut buf).ok()?;
            u64::from_be_bytes(buf)
        };
        let op = match tokens {
            ["nop"] => IoUringOp::Nop,
            ["create", path] => {
                let path_box = PathBuf::from(path).into_boxed_path();
                let path = &raw const *path_box;
                self.path_alloc.push(path_box);
                IoUringOp::Create {
                    path,
                    public_read: false,
                    public_write: false,
                }
            }
            ["create", path, mode] => {
                let public_read = mode.contains('r');
                let public_write = mode.contains('w');
                let path_box = PathBuf::from(path).into_boxed_path();
                let path = &raw const *path_box;
                self.path_alloc.push(path_box);
                IoUringOp::Create {
                    path,
                    public_read,
                    public_write,
                }
            }
            ["open", path, "r"] => {
                let path_box = PathBuf::from(path).into_boxed_path();
                let path = &raw const *path_box;
                self.path_alloc.push(path_box);
                IoUringOp::Open { path, write: false }
            }
            ["open", path, "w"] => {
                let path_box = PathBuf::from(path).into_boxed_path();
                let path = &raw const *path_box;
                self.path_alloc.push(path_box);
                IoUringOp::Open { path, write: true }
            }
            ["close", fd] => {
                let fd = fd.parse().ok()?;
                IoUringOp::Close { fd }
            }
            ["symlink", src, dst] => {
                let src_box = PathBuf::from(src).into_boxed_path();
                let src = &raw const *src_box;
                self.path_alloc.push(src_box);
                let dst_box = PathBuf::from(dst).into_boxed_path();
                let dst = &raw const *dst_box;
                self.path_alloc.push(dst_box);
                IoUringOp::Symlink { src, dst }
            }
            ["unlink", path] => {
                let path = PathBuf::from(path).into_boxed_path();
                self.path_alloc.push(path);
                IoUringOp::Unlink {
                    path: &**self.path_alloc.last().unwrap(),
                }
            }
            ["read", fd, offset, len] => {
                if self.buf_alloc.contains_key(&user_data) {
                    return None;
                }
                let fd = fd.parse().ok()?;
                let offset = offset.parse().ok()?;
                let len = len.parse().ok()?;
                let mut buf_box = vec![0u8; len].into_boxed_slice();
                let buf = &raw mut *buf_box;
                self.buf_alloc.insert(user_data, buf_box);
                IoUringOp::Read { fd, offset, buf }
            }
            ["write", fd, buf_hex] => {
                if self.buf_alloc.contains_key(&user_data) {
                    return None;
                }
                let fd = fd.parse().ok()?;
                let buf_box = hex::decode(buf_hex).ok()?.into_boxed_slice();
                let buf = &raw const *buf_box;
                self.buf_alloc.insert(user_data, buf_box);
                IoUringOp::Write { fd, buf }
            }
            ["sleep", ms] => {
                let ms = ms.parse().ok()?;
                sleep(Duration::from_millis(ms)).await;
                return None;
            }
            _ => {
                return None;
            }
        };
        Some(SubmissionQueueEntry { op, user_data })
    }
    async fn handle_results(&self) {
        let Some(result) = self.io_uring.pop().await else {
            return;
        };
        if result.res < 0 {
            println!(
                "[completion] submission {:016x} returned error {}",
                result.user_data, -result.res
            );
        } else if let Some(buf) = self.buf_alloc.get(&result.user_data) {
            let buf = &buf[..(result.res as usize)];
            println!(
                "[completion] submission {:016x} returned bytes {}",
                result.user_data,
                hex::encode(buf)
            );
        } else {
            println!(
                "[completion] submission {:016x} returned code {}",
                result.user_data, result.res
            );
        }
    }
    pub async fn run(mut self) {
        use tokio::io::{AsyncBufReadExt, BufReader};
        let stdin = tokio::io::stdin();
        let mut lines = BufReader::new(stdin).lines();
        loop {
            tokio::select! {
                Ok(Some(command)) = lines.next_line() => {
                    if command.len() < 500 {
                        if let Some(submission) = self.run_command(&command).await {
                            let _ = self.io_uring.push(submission).await;
                        };
                    }
                }
                _ = self.handle_results() => {}
            }
        }
    }
}
