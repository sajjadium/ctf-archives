use io_urust::kernel::Kernel;
use io_urust::users::{RegularUser, RootUser};

#[tokio::main(flavor = "multi_thread", worker_threads = 4)]
async fn main() {
    let Ok(flag) = std::fs::read_to_string("flag.txt") else {
        println!("[error] configuration fail; cannot read flag!");
        return;
    };
    let mut kernel = Kernel::default();
    let root = RootUser::new_in(&mut kernel, flag);
    let user = RegularUser::new_in(&mut kernel, 1000);
    tokio::join!(root.run(), user.run(), kernel.run_kernel_thread());
}
