#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 7 ||
        strcmp(argv[1], "please") != 0 ||
        strcmp(argv[2], "give") != 0 ||
        strcmp(argv[3], "me") != 0 ||
        strcmp(argv[4], "this") != 0 ||
        strcmp(argv[5], "challenge") != 0 ||
        strcmp(argv[6], "flag") != 0) {
        puts("Permission denied.");
        return 1;
    }

    FILE *fp = fopen("/app/flag.txt", "r");
    if (!fp) {
        perror("fopen");
        return 1;
    }

    char buf[256];
    while (fgets(buf, sizeof(buf), fp)) {
        fputs(buf, stdout);
    }

    fclose(fp);
    return 0;
}