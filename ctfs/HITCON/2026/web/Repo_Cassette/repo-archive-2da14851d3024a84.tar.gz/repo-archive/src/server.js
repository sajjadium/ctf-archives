'use strict';

const path = require('node:path');
const express = require('express');
const multer = require('multer');
const { ZodError } = require('zod');
const { readCapture, readLive } = require('./archive');
const { serveFixture } = require('./delivery');
const { createFixture, loadFixture, publicFixture } = require('./store');

const PORT = Number(process.env.PORT || 3000);

const app = express();
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, '..', 'public')));

const importUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 1024 * 1024, files: 1, fields: 2 },
}).single('capture');

app.post('/api/fixtures/live', express.json({ limit: '4kb' }), async (req, res, next) => {
  try {
    const fixture = createFixture(await readLive(req.body?.repository));
    res.status(201).json(publicFixture(fixture));
  } catch (error) {
    next(error);
  }
});

app.post('/api/fixtures', importUpload, async (req, res, next) => {
  try {
    if (!req.file) throw new Error('Cannot archive without a HAR capture');
    const input = {
      ...JSON.parse(req.file.buffer.toString('utf8')),
      repository: req.body.repository,
      entryIndex: req.body.entryIndex,
    };
    const fixture = createFixture(await readCapture(input));
    res.status(201).json(publicFixture(fixture));
  } catch (error) {
    next(error);
  }
});

app.get('/api/fixtures/:id', (req, res, next) => {
  try {
    res.json(publicFixture(loadFixture(req.params.id)));
  } catch (error) {
    next(error);
  }
});

app.get('/view/:id', (req, res, next) => {
  try {
    serveFixture(res, next, loadFixture(req.params.id));
  } catch (error) {
    next(error);
  }
});

app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = (error.status >= 400 && error.status < 500) ? error.status :
    error instanceof ZodError || error instanceof multer.MulterError ||
    error instanceof SyntaxError ||
    error.message === 'Fixture not found' ||
    error.message.startsWith('Cannot archive') ||
    error.message.startsWith('Cannot record') ||
    error.message.startsWith('Duplicate captured') ? 400 : 500;
  res.status(status).json({ error: status === 500 ? 'Internal error' : error.message });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Repo Cassette listening on ${PORT}`);
});
