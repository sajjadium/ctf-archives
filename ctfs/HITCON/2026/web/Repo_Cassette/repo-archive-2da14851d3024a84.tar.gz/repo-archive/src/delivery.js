'use strict';

const fs = require('node:fs');

function serveFixture(res, next, fixture) {
  const bytes = fs.statSync(fixture.archive.bodyFile).size;
  res.set('Content-Length', String(bytes));
  res.sendFile(fixture.archive.bodyFile, {
    headers: fixture.archive.headers,
    acceptRanges: false,
    cacheControl: false,
    lastModified: false,
    etag: false,
  }, (error) => {
    if (error) next(error);
  });
}

module.exports = { serveFixture };
