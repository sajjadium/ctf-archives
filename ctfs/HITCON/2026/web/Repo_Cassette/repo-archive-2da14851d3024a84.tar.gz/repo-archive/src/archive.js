'use strict';

const { createHash } = require('node:crypto');
const jsonpatch = require('fast-json-patch');
const { z } = require('zod');

const MAX_BODY_BYTES = 524288;
const repositorySchema = z.string().min(3).max(256);
const repositoryName = /^[A-Za-z0-9-]+\/[A-Za-z0-9._-]+$/;
const HTTP_TOKEN = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
const reserved = new Set([
  'host',
  'connection',
  'content-length',
  'content-encoding',
  'transfer-encoding',
]);

const headerSchema = z.object({
  name: z.string().min(1).max(128).regex(HTTP_TOKEN),
  value: z.coerce.string().max(2048).refine((value) => !/[\r\n]/.test(value)),
});

const entrySchema = z.object({
  request: z.object({ url: z.string().optional() }).optional(),
  response: z.object({
    headers: z.array(headerSchema).max(64),
    content: z.object({
      text: z.string().min(1).max(Math.ceil(MAX_BODY_BYTES / 3) * 4),
      encoding: z.literal('base64').optional(),
    }),
  }),
});

const captureSchema = z.object({
  repository: repositorySchema,
  entryIndex: z.coerce.number().int().min(0).max(7).default(0),
  log: z.object({ entries: z.array(z.unknown()).min(1).max(8) }),
});

function decodeContent(content) {
  if (!content.encoding) return Buffer.from(content.text, 'utf8');
  if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(content.text)) {
    throw new Error('Cannot archive invalid base64 content');
  }
  return Buffer.from(content.text, 'base64');
}

async function fetchSample(repository) {
  const [owner, ...name] = repository.split('/');
  const repo = name.join('/');
  if (!owner || !repo) throw new Error('Cannot archive repository identifier');

  const { default: ghGot } = await import('gh-got');
  try {
    const response = await ghGot(`repos/${owner}/${repo}`, {
      responseType: 'buffer',
      timeout: { request: 6000 },
      retry: { limit: 0 },
    });
    return { body: Buffer.from(response.body), headers: response.headers };
  } catch {
    throw new Error('Cannot archive GitHub sample');
  }
}

function inspectContent(bytes, repository) {
  if (bytes.length > MAX_BODY_BYTES) throw new Error('Cannot archive oversized content');
  let text;
  try {
    text = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    return null;
  }
  let document;
  try {
    document = JSON.parse(text);
  } catch {
    throw new Error('Cannot archive invalid repository JSON');
  }
  if (!document || typeof document !== 'object' || Array.isArray(document)) {
    throw new Error('Cannot archive a non-repository response');
  }
  if (typeof document.full_name !== 'string' ||
      document.full_name.toLowerCase() !== repository.toLowerCase() || !document.owner ||
      typeof document.owner.avatar_url !== 'string') {
    throw new Error('Cannot archive a response from another repository');
  }
  return document;
}

function mediaType(headers) {
  const value = headers['content-type'];
  return typeof value === 'string'
    ? value.split(',', 1)[0].split(';', 1)[0].trim().toLowerCase()
    : '';
}

function sourceFingerprint(sample, repository) {
  if (!sample) return null;
  const type = mediaType(sample.headers);
  if (!type) return null;
  if (type === 'application/json') {
    try {
      if (!repositoryName.test(repository) || !inspectContent(sample.body, repository)) return null;
    } catch {
      return null;
    }
  }
  return createHash('sha256').update(sample.body).digest('hex');
}

function reconcileHeaders(captured, liveHeaders) {
  const live = new Map(
    Object.entries(liveHeaders)
      .filter(([, value]) => value !== undefined)
      .map(([name, value]) => [name.toLowerCase(), { name, value }]),
  );

  for (const savedName of Object.keys(captured)) {
    const current = live.get(savedName.toLowerCase());
    if (!current) continue;

    delete captured[savedName];
    captured[current.name] = current.value;
  }
}

async function readCapture(input) {
  const parsed = captureSchema.parse(input);
  const { repository } = parsed;
  const capture = input.log.entries[parsed.entryIndex];
  if (!capture) throw new Error('Cannot archive unknown HAR entry');
  const entry = entrySchema.parse(capture);
  const headers = Object.create(null);
  if (Buffer.byteLength(JSON.stringify(capture.response.headers)) > 16384) {
    throw new Error('Cannot archive oversized response headers');
  }

  for (const { name, value } of capture.response.headers) {
    const lower = name.toLowerCase();
    if (reserved.has(lower)) continue;
    headers[name] = value;
  }
  const body = decodeContent(entry.response.content);
  if (body.length > MAX_BODY_BYTES) throw new Error('Cannot archive oversized content');
  let baseline = null;
  let sample;
  try {
    baseline = inspectContent(body, repository);
    sample = await fetchSample(repository);
  } catch {  }
  if (sample) reconcileHeaders(headers, sample.headers);
  let changeCount = null;
  if (baseline && sample) {
    try {
      const current = JSON.parse(sample.body.toString('utf8'));
      if (current && typeof current === 'object' && !Array.isArray(current)) {
        changeCount = jsonpatch.compare(baseline, current).length;
      }
    } catch {}
  }

  return {
    title: repository,
    headers,
    body,
    sourceSha256: sourceFingerprint(sample, repository),
    changeCount,
  };
}

async function readLive(repositoryInput) {
  const repository = repositorySchema.parse(repositoryInput);
  const { body, headers } = await fetchSample(repository);
  const contentType = headers['content-type'];
  if (mediaType(headers) !== 'application/json' || !repositoryName.test(repository) ||
      !inspectContent(body, repository)) {
    throw new Error('Cannot record a non-repository response');
  }
  return {
    title: repository,
    headers: { 'Content-Type': contentType },
    body,
    sourceSha256: createHash('sha256').update(body).digest('hex'),
    changeCount: 0,
  };
}

module.exports = { readCapture, readLive };
