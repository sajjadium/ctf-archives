'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { randomUUID } = require('node:crypto');

const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

function assertId(id) {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(id)) {
    throw new Error('Fixture not found');
  }
}

function manifestPath(id) {
  assertId(id);
  return path.join(DATA_DIR, `${id}.json`);
}

function saveFixture(fixture) {
  const destination = manifestPath(fixture.id);
  const temporary = `${destination}.tmp`;
  fs.writeFileSync(temporary, JSON.stringify(fixture));
  fs.renameSync(temporary, destination);
}

function loadFixture(id) {
  try {
    return JSON.parse(fs.readFileSync(manifestPath(id), 'utf8'));
  } catch (error) {
    if (error.code === 'ENOENT') throw new Error('Fixture not found');
    throw error;
  }
}

function createFixture(capture) {
  const id = randomUUID();
  const bodyFile = path.join(DATA_DIR, `${id}.body`);
  fs.writeFileSync(bodyFile, capture.body);
  const fixture = {
    id,
    title: capture.title,
    archive: { bodyFile, headers: capture.headers },
    sourceSha256: capture.sourceSha256,
    changeCount: capture.changeCount,
  };
  saveFixture(fixture);
  return fixture;
}

function publicFixture(fixture) {
  return {
    id: fixture.id,
    title: fixture.title,
    view: `/view/${fixture.id}`,
    sourceSha256: fixture.sourceSha256,
    changeCount: fixture.changeCount,
  };
}

module.exports = { createFixture, loadFixture, publicFixture };
