'use strict';

const fileInput = document.getElementById('har-file');
const repoInput = document.getElementById('repository');
const entryField = document.getElementById('entry-field');
const entrySelect = document.getElementById('har-entry');
const recordButton = document.getElementById('record-live');
const publishButton = document.getElementById('publish');
const postcardButton = document.getElementById('postcard');
const viewLink = document.getElementById('view-link');
const driftView = document.getElementById('drift');
const resultView = document.getElementById('result');
const resultStatus = document.getElementById('result-status');
const postcardImage = document.getElementById('postcard-image');
const postcardLink = document.getElementById('postcard-link');

let currentHar;
let currentFixture;

function showResult(status, value) {
  resultStatus.textContent = status;
  resultView.textContent = typeof value === 'string' ? value : JSON.stringify(value, null, 2);
}

function showFixture(fixture) {
  currentFixture = fixture;
  postcardImage.hidden = true;
  postcardLink.hidden = true;
  driftView.textContent = fixture.changeCount === null
    ? 'Live comparison unavailable'
    : `${fixture.changeCount} JSON change${fixture.changeCount === 1 ? '' : 's'} from GitHub now`;
  postcardButton.disabled = false;
  viewLink.hidden = false;
  viewLink.href = fixture.view;
  viewLink.textContent = `Open ${fixture.view} ↗`;
}

function render(har) {
  const entries = har?.log?.entries;
  if (!Array.isArray(entries) || entries.length < 1 || entries.length > 8) {
    throw new Error('Import a HAR with 1–8 response entries.');
  }

  currentHar = har;
  entrySelect.replaceChildren(...entries.map((entry, index) => {
    const option = document.createElement('option');
    option.value = String(index);
    option.textContent = `${index + 1}. ${entry?.request?.url || 'Response'}`;
    return option;
  }));
  entryField.hidden = entries.length === 1;
  currentFixture = null;
  postcardImage.hidden = true;
  postcardLink.hidden = true;
  driftView.textContent = 'No sample yet';
  postcardButton.disabled = true;
  viewLink.hidden = true;
  repoInput.value = har.repository || capturedRepository(entries[0]) || repoInput.value;
  showResult('READY', 'HAR capture loaded. Save it or record the current repository profile from GitHub.');
}

function capturedRepository(entry) {
  const url = entry?.request?.url;
  const source = typeof url === 'string'
    ? url.match(/^https:\/\/api\.github\.com\/repos\/([^/]+)\/([^?#]+)(?:[?#]|$)/)
    : null;
  return source ? `${source[1]}/${source[2]}` : null;
}

entrySelect.addEventListener('change', () => {
  const repository = capturedRepository(currentHar?.log?.entries[Number(entrySelect.value)]);
  if (repository) repoInput.value = repository;
});

fileInput.addEventListener('change', async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  try {
    render(JSON.parse(await file.text()));
  } catch (error) {
    showResult('IMPORT ERROR', error.message);
  }
});

publishButton.addEventListener('click', async () => {
  if (!currentHar) return;
  publishButton.disabled = true;
  showResult('SAVING', 'Saving the imported HAR...');
  try {
    const upload = new FormData();
    upload.set('repository', repoInput.value.trim());
    upload.set('entryIndex', entrySelect.value);
    upload.set('capture', new Blob([JSON.stringify(currentHar)], { type: 'application/json' }), 'capture.har');
    const response = await fetch('/api/fixtures', {
      method: 'POST',
      body: upload,
    });
    const result = await response.json();
    if (response.ok) showFixture(result);
    showResult(response.ok ? 'CAPTURE SAVED' : `ERROR ${response.status}`, result);
  } catch (error) {
    showResult('NETWORK ERROR', error.message);
  } finally {
    publishButton.disabled = false;
  }
});

recordButton.addEventListener('click', async () => {
  recordButton.disabled = true;
  showResult('RECORDING', 'Fetching the repository profile from GitHub...');
  try {
    const response = await fetch('/api/fixtures/live', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ repository: repoInput.value.trim() }),
    });
    const result = await response.json();
    if (response.ok) showFixture(result);
    showResult(response.ok ? 'CAPTURE SAVED' : `ERROR ${response.status}`, result);
  } catch (error) {
    showResult('NETWORK ERROR', error.message);
  } finally {
    recordButton.disabled = false;
  }
});

postcardButton.addEventListener('click', async () => {
  if (!currentFixture) return;
  postcardButton.disabled = true;
  postcardImage.hidden = true;
  postcardLink.hidden = true;
  showResult('MAKING POSTCARD', 'Reading the saved repository profile...');
  try {
    const response = await fetch(`/api/postcards/${currentFixture.id}`);
    const result = await response.json();
    if (response.ok) {
      const card = result.card;
      const lines = [card.name, card.description || 'No description', `★ ${card.stars} · @${card.owner}`, result.verified ? 'Portrait archived' : 'Plain archived card', `Postcard ID: ${card.fingerprint}`];
      showResult('POSTCARD READY', lines.join('\n'));
      postcardImage.src = result.image;
      postcardImage.hidden = false;
      postcardLink.href = result.image;
      postcardLink.hidden = false;
    } else {
      showResult(`ERROR ${response.status}`, result);
    }
  } catch (error) {
    showResult('NETWORK ERROR', error.message);
  } finally {
    postcardButton.disabled = false;
  }
});

fetch('/sample-response.har')
  .then((response) => response.json())
  .then(render)
  .catch((error) => showResult('LOAD ERROR', error.message));
