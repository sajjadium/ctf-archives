import json
import re
from base64 import b64encode
from hashlib import sha256
from hmac import compare_digest
from html import escape
from os import environ
from urllib.request import urlopen

import requests
from flask import Flask, Response, jsonify
from urllib3.exceptions import HTTPError as Urllib3HTTPError


app = Flask(__name__)
REPLAY_BASE = environ.get('REPLAY_BASE', 'http://edge:8080').rstrip('/')
ORIGIN_BASE = environ.get('ORIGIN_BASE', 'http://app:3000').rstrip('/')
FIXTURE_ID = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$')
SHA256 = re.compile(r'^[0-9a-f]{64}$')
MAX_REPLAY_BYTES = 262144
MAX_RESPONSE_BYTES = 524288
MAX_AVATAR_BYTES = 524288


def fetch_repository(fixture_id, base):
    chunks = []
    size = 0
    with requests.get(f'{base}/view/{fixture_id}', timeout=5, stream=True) as response:
        response.raise_for_status()
        media_type = response.headers.get('Content-Type', '').split(',', 1)[0]
        media_type = media_type.split(';', 1)[0].strip().lower()
        if media_type != 'application/json':
            raise ValueError('Expected a JSON response')
        for chunk in response.iter_content(chunk_size=8192):
            size += len(chunk)
            if size > MAX_RESPONSE_BYTES:
                raise ValueError('Response is too large')
            chunks.append(chunk)
    repository = json.loads(b''.join(chunks).decode('utf-8'))
    fingerprint = sha256(json.dumps(
        repository, sort_keys=True, separators=(',', ':'), allow_nan=False,
    ).encode('utf-8')).hexdigest()[:12]
    if not isinstance(repository, dict) or not isinstance(repository.get('owner'), dict):
        raise ValueError('Expected repository details')
    if not isinstance(repository.get('full_name'), str):
        raise ValueError('Expected repository name')
    return repository, fingerprint


def matches_source(fixture_id):
    fixture = requests.get(f'{REPLAY_BASE}/api/fixtures/{fixture_id}', timeout=5)
    fixture.raise_for_status()
    expected = fixture.json().get('sourceSha256')
    if not isinstance(expected, str) or not SHA256.fullmatch(expected):
        return False

    with requests.get(f'{REPLAY_BASE}/view/{fixture_id}', timeout=5, stream=True) as replay:
        replay.raise_for_status()
        raw_body = replay.raw.read(MAX_REPLAY_BYTES + 1, decode_content=False)
    return len(raw_body) <= MAX_REPLAY_BYTES and compare_digest(
        sha256(raw_body).hexdigest(), expected,
    )


def card_details(repository, fingerprint):
    owner = repository['owner']
    description = repository.get('description')
    stars = repository.get('stargazers_count')
    return {
        'name': repository['full_name'],
        'description': description if isinstance(description, str) else '',
        'stars': stars if isinstance(stars, int) and stars >= 0 else 0,
        'owner': owner.get('login') if isinstance(owner.get('login'), str) else 'Unknown',
        'fingerprint': fingerprint,
    }


def portrait(url):
    with urlopen(url, timeout=4) as response:
        data = response.read(MAX_AVATAR_BYTES + 1)
        if len(data) > MAX_AVATAR_BYTES:
            raise ValueError('Portrait is too large')
        media_type = response.headers.get_content_type()
    if not media_type.startswith('image/'):
        media_type = 'image/png'
    return f'data:{media_type};base64,{b64encode(data).decode("ascii")}'


def draw_card(details, portrait_url):
    name = escape(details['name'][:48])
    description = escape(details['description'][:96])
    owner = escape(details['owner'][:36])
    fingerprint = escape(details['fingerprint'])
    image = ''
    if portrait_url:
        try:
            image = f'<image x="38" y="40" width="76" height="76" href="{portrait(portrait_url)}"/>'
        except (OSError, ValueError):
            pass
    if not image:
        image = '<circle cx="76" cy="78" r="38" fill="#334032"/>'

    return (
        '<svg xmlns="http://www.w3.org/2000/svg" width="760" height="320" viewBox="0 0 760 320">'
        '<rect width="760" height="320" rx="22" fill="#111611"/>'
        '<rect x="20" y="20" width="720" height="280" rx="14" fill="#1b241b" stroke="#40503e"/>'
        f'{image}'
        '<text x="132" y="68" fill="#91ee6e" font-family="sans-serif" font-size="17">GITHUB REPOSITORY</text>'
        f'<text x="132" y="104" fill="#f0f5ee" font-family="sans-serif" font-size="27" font-weight="bold">{name}</text>'
        f'<text x="40" y="165" fill="#c6d1c2" font-family="sans-serif" font-size="19">{description}</text>'
        f'<text x="40" y="228" fill="#91ee6e" font-family="sans-serif" font-size="17">★ {details["stars"]}  ·  @{owner}</text>'
        f'<text x="40" y="277" fill="#82917f" font-family="monospace" font-size="13">CASSETTE {fingerprint}</text>'
        '</svg>'
    )


def load_card(fixture_id):
    if not FIXTURE_ID.fullmatch(fixture_id):
        raise ValueError('Invalid capture ID')
    repository, fingerprint = fetch_repository(fixture_id, REPLAY_BASE)
    verified = matches_source(fixture_id)
    if verified:
        try:
            origin_repository, _ = fetch_repository(fixture_id, ORIGIN_BASE)
            verified = origin_repository == repository
        except (requests.RequestException, Urllib3HTTPError, ValueError, UnicodeError, TypeError, KeyError):
            verified = False
    return repository, card_details(repository, fingerprint), verified


@app.get('/api/postcards/<fixture_id>')
def postcard(fixture_id):
    try:
        _, details, verified = load_card(fixture_id)
        return jsonify(
            status='ok',
            card=details,
            verified=verified,
            image=f'/api/postcards/{fixture_id}/image.svg',
        )
    except (requests.RequestException, Urllib3HTTPError, ValueError, UnicodeError, TypeError, KeyError):
        return jsonify(status='error', reason='The capture could not be turned into a postcard'), 400


@app.get('/api/postcards/<fixture_id>/image.svg')
def postcard_image(fixture_id):
    try:
        repository, details, verified = load_card(fixture_id)
        portrait_url = repository['owner'].get('avatar_url') if verified else None
        if not isinstance(portrait_url, str):
            portrait_url = None
        return Response(draw_card(details, portrait_url), mimetype='image/svg+xml')
    except (requests.RequestException, Urllib3HTTPError, ValueError, UnicodeError, TypeError, KeyError):
        return jsonify(status='error', reason='The capture could not be turned into a postcard'), 400
