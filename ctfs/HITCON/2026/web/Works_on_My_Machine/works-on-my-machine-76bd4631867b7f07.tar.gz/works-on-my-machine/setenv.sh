args=/run/works-on-my-machine/jvm.args
(umask 077; printf '%s\n' \
    "-DSESSION_SECRET=$(head -c 32 /dev/urandom | base64)" \
    '-Djava.awt.headless=true' \
    '-Dorg.slf4j.simpleLogger.showDateTime=true' > "$args")
CATALINA_OPTS="@$args"
