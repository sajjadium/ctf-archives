# Works on My Machine

Requires rootful Podman on cgroup v2 and a Compose provider.

```sh
podman compose -f compose.yaml up --build -d
```

Open the gateway on port 8080. Visitors preview XHTML; signed-in users save
and publish a PNG homepage at `/<username>`. Remembered users can edit;
administration requires a fresh sign-in.
