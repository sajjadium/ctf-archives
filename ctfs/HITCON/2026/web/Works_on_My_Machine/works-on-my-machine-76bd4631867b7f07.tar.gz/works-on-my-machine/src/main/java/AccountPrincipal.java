import java.io.Serial;
import java.io.Serializable;

record AccountPrincipal(String username, long authVersion) implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
}
