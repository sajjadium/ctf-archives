public final class AppRealm extends org.apache.shiro.realm.AuthenticatingRealm {
    public AppRealm() {
        setAuthenticationTokenClass(org.apache.shiro.authc.UsernamePasswordToken.class);
        setAuthenticationCachingEnabled(false);
        setCredentialsMatcher((token, info) -> {
            if (!(token instanceof org.apache.shiro.authc.UsernamePasswordToken login)
                    || !(info.getCredentials() instanceof Password.Material material)) {
                return false;
            }
            return Password.matches(login.getPassword(), material);
        });
    }

    @Override
    protected org.apache.shiro.authc.AuthenticationInfo doGetAuthenticationInfo(
            org.apache.shiro.authc.AuthenticationToken token) {
        String username = (String) token.getPrincipal();
        Store.Account account = Store.account(username);
        if (account == null) {
            throw new org.apache.shiro.authc.UnknownAccountException();
        }
        if (!account.enabled()) {
            throw new org.apache.shiro.authc.DisabledAccountException();
        }
        return new org.apache.shiro.authc.SimpleAuthenticationInfo(
                new AccountPrincipal(account.username(), account.authVersion()),
                new Password.Material(account.salt(), account.passwordHash()), getName());
    }
}
