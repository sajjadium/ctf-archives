import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;

final class SiteApp {
    private static final int MAX_DRAFT_BYTES = 256 * 1024;
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final Pattern ADMIN_ACTION = Pattern.compile(
            "^/admin/([a-z][a-z0-9_-]{2,23})/(disable|enable|delete|reset)$");
    private static final String STYLE = """
            :root{color-scheme:light;font-family:system-ui,sans-serif;background:#f5f6f8;color:#182332}
            *{box-sizing:border-box}body{margin:0}a{color:#0b5875}button,input,textarea{font:inherit}
            header{background:#142633;color:#fff;padding:1rem max(1.5rem,calc((100vw - 68rem)/2))}
            header a{color:#fff;text-decoration:none}nav{display:flex;align-items:center;gap:1rem}
            nav .brand{font-weight:700;margin-right:auto}nav form{margin:0}
            main{max-width:68rem;margin:2.5rem auto;padding:0 1.5rem}h1{font-size:2.2rem;margin:.3rem 0}
            h2{margin-top:2rem}.lede{color:#526272;max-width:42rem;line-height:1.6}
            .card{background:#fff;border:1px solid #dbe2e8;border-radius:12px;padding:1.5rem;margin:1.5rem 0}
            label{display:block;font-weight:600;margin:1rem 0 .35rem}input:not([type=checkbox]),textarea{width:100%;padding:.7rem;border:1px solid #aebbc6;border-radius:7px}
            textarea{min-height:20rem;font-family:ui-monospace,monospace;line-height:1.45;resize:vertical}
            .actions{display:flex;flex-wrap:wrap;gap:.7rem;margin-top:1rem}button,.button{border:0;border-radius:7px;background:#186784;color:#fff;padding:.7rem 1rem;cursor:pointer;text-decoration:none}
            button.secondary{background:#e5edf1;color:#193442}button.danger{background:#a33232}
            .screen{min-height:13rem;border:12px solid #253a48;border-radius:12px;background:#fff;overflow:auto}
            .screen img{display:block;max-width:100%;height:auto}.hint{color:#607181;font-size:.94rem}
            .error{border-left:4px solid #b63737;background:#fff0f0;padding:.8rem 1rem}
            .success{border-left:4px solid #26754d;background:#eef9f2;padding:.8rem 1rem}
            table{border-collapse:collapse;width:100%}th,td{padding:.65rem;border-bottom:1px solid #dbe2e8;text-align:left;vertical-align:top}
            td form{display:inline-block;margin:.1rem}td button{padding:.4rem .6rem;font-size:.85rem}
            code{word-break:break-all}footer{color:#607181;margin:3rem 0 1rem}
            @media(max-width:700px){table{display:block;overflow-x:auto}header{padding:1rem}nav{flex-wrap:wrap}}
            """;
    private static final String PREVIEW_SCRIPT = """
            <script>
            const button = document.getElementById('preview-button');
            if (button) button.addEventListener('click', async () => {
              const image = document.getElementById('preview-image');
              const status = document.getElementById('preview-status');
              button.disabled = true;
              status.textContent = 'Rendering on my machine…';
              try {
                const response = await fetch('/', {method:'POST',
                  headers:{'Content-Type':'text/html; charset=UTF-8'},
                  body:document.getElementById('source').value});
                if (!response.ok) throw new Error('render failed');
                const url = URL.createObjectURL(await response.blob());
                if (image.dataset.url) URL.revokeObjectURL(image.dataset.url);
                image.dataset.url = url;
                image.src = url;
                status.textContent = 'Preview ready.';
              } catch (_) {
                status.textContent = 'This page could not be rendered.';
              } finally {
                button.disabled = false;
              }
            });
            </script>
            """;

    private SiteApp() {}

    static String path(HttpServletRequest request) {
        String uri = request.getRequestURI();
        return uri.substring(request.getContextPath().length());
    }

    static void get(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        headers(response);
        String path = path(request);
        switch (path) {
            case "/" -> landing(response);
            case "/login" -> loginPage(response, null);
            case "/signup" -> signupPage(response, null);
            case "/me" -> editor(request, response, null);
            case "/admin" -> adminPage(request, response, null);
            default -> {
                if (path.length() > 1 && Store.validUsername(path.substring(1))) {
                    byte[] png = Store.publishedImage(path.substring(1));
                    if (png != null) {
                        response.setContentType("image/png");
                        response.setContentLength(png.length);
                        response.getOutputStream().write(png);
                        return;
                    }
                }
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        }
    }

    static void post(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        headers(response);
        request.setCharacterEncoding(StandardCharsets.UTF_8.name());
        if (!validCsrf(request)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        switch (path(request)) {
            case "/signup" -> signup(request, response);
            case "/login" -> login(request, response);
            case "/logout" -> {
                SecurityUtils.getSubject().logout();
                redirect(request, response, "/");
            }
            case "/me/save" -> save(request, response, false);
            case "/me/publish" -> save(request, response, true);
            case "/me/password" -> changePassword(request, response);
            default -> {
                Matcher action = ADMIN_ACTION.matcher(path(request));
                if (action.matches()) {
                    adminAction(request, response, action.group(1), action.group(2));
                } else {
                    response.sendError(HttpServletResponse.SC_NOT_FOUND);
                }
            }
        }
    }

    private static void landing(HttpServletResponse response) throws IOException {
        StringBuilder body = new StringBuilder("""
                <h1>Build a website. Publish a picture of it.</h1>
                <p class="lede">Write a personal homepage in XHTML and CSS. Preview it here,
                then make the screenshot your public website.</p>
                <div class="card"><label for="source">Your XHTML</label>
                <textarea id="source" spellcheck="false">&lt;html&gt;&lt;body&gt;&lt;h1&gt;Hello, world.&lt;/h1&gt;&lt;p&gt;Works on my machine.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</textarea>
                <div class="actions"><button type="button" id="preview-button">Preview on my machine</button>
                <a class="button" href="/signup">Sign up to publish</a></div></div>
                """);
        previewFrame(body);
        body.append(PREVIEW_SCRIPT);
        page(response, "Build a website", body.toString(), currentAccount());
    }

    private static void signupPage(HttpServletResponse response, String error)
            throws IOException {
        StringBuilder body = new StringBuilder("<h1>Create an account</h1>");
        notice(body, error, false);
        body.append("<div class=\"card\"><form method=\"post\" action=\"/signup\">");
        csrfField(body);
        body.append("""
                <label for="username">Username</label><input id="username" name="username" required
                pattern="[a-z][a-z0-9_-]{2,23}" maxlength="24" autocomplete="username">
                <p class="hint">3–24 lowercase letters, digits, underscores, or hyphens; start with a letter.</p>
                <label for="password">Password</label><input id="password" name="password"
                type="password" minlength="12" maxlength="200" required autocomplete="new-password">
                <div class="actions"><button type="submit">Create account</button></div></form></div>
                """);
        page(response, "Sign up", body.toString(), currentAccount());
    }

    private static void loginPage(HttpServletResponse response, String error)
            throws IOException {
        StringBuilder body = new StringBuilder("<h1>Sign in</h1>");
        notice(body, error, false);
        body.append("<div class=\"card\"><form method=\"post\" action=\"/login\">");
        csrfField(body);
        body.append("""
                <label for="username">Username</label><input id="username" name="username"
                required autocomplete="username">
                <label for="password">Password</label><input id="password" name="password"
                type="password" required autocomplete="current-password">
                <label><input type="checkbox" name="remember" value="yes"> Remember me</label>
                <div class="actions"><button type="submit">Sign in</button></div></form></div>
                """);
        page(response, "Sign in", body.toString(), currentAccount());
    }

    private static void signup(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String username = request.getParameter("username");
        String value = request.getParameter("password");
        if (!Store.validUsername(username) || !validPassword(value)) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            signupPage(response, "Choose an available username and a password of at least 12 characters.");
            return;
        }
        char[] password = value.toCharArray();
        try {
            if (!Store.create(username, password)) {
                response.setStatus(HttpServletResponse.SC_CONFLICT);
                signupPage(response, "That username is unavailable.");
                return;
            }
            signIn(request, response, username, password, false);
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private static void login(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        String username = request.getParameter("username");
        String value = request.getParameter("password");
        if (username == null || !username.matches("[a-z][a-z0-9_-]{2,23}")
                || value == null || value.length() > 200) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            loginPage(response, "Could not sign in.");
            return;
        }
        char[] password = value.toCharArray();
        try {
            signIn(request, response, username, password,
                    "yes".equals(request.getParameter("remember")));
        } finally {
            Arrays.fill(password, '\0');
        }
    }

    private static void signIn(HttpServletRequest request, HttpServletResponse response,
                               String username, char[] password, boolean remember)
            throws IOException {
        Subject subject = SecurityUtils.getSubject();
        UsernamePasswordToken token = new UsernamePasswordToken(username, password, remember);
        try {
            subject.logout();
            subject.login(token);
            Store.Account account = Store.account(username);
            if (account != null && account.admin()) {
                Store.discardInitialPassword();
            }
            redirect(request, response, "/me");
        } catch (AuthenticationException exception) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            loginPage(response, "Could not sign in.");
        } finally {
            token.clear();
        }
    }

    private static void editor(HttpServletRequest request, HttpServletResponse response,
                               String message) throws IOException {
        Store.Account account = requireAccount(request, response, false);
        if (account == null) {
            return;
        }
        StringBuilder body = new StringBuilder("<h1>My page</h1>");
        notice(body, message, false);
        if (account.mustChangePassword()) {
            body.append("<p class=\"error\">Change your temporary password before continuing.</p>");
        }
        passwordForm(body);
        if (!account.admin() && !account.mustChangePassword()) {
            body.append("<p class=\"lede\">Your public homepage is a PNG snapshot. Edits remain private until you publish.</p>");
            if (account.publishedAt() != null) {
                body.append("<p>Published <time>").append(escape(account.publishedAt()))
                        .append("</time>: <a href=\"/").append(account.username())
                        .append("\">/").append(account.username()).append("</a></p>");
            }
            body.append("<div class=\"card\"><form method=\"post\" action=\"/me/save\">");
            csrfField(body);
            body.append("<label for=\"source\">Homepage XHTML</label><textarea id=\"source\" name=\"source\" spellcheck=\"false\">")
                    .append(escape(account.draft())).append("</textarea>");
            body.append("""
                    <div class="actions"><button type="button" id="preview-button" class="secondary">Preview on my machine</button>
                    <button type="submit">Save draft</button>
                    <button type="submit" formaction="/me/publish">Publish screenshot</button></div></form></div>
                    """);
            previewFrame(body);
            body.append(PREVIEW_SCRIPT);
        }
        page(response, "My page", body.toString(), account);
    }

    private static void passwordForm(StringBuilder body) {
        body.append("<div class=\"card\"><h2>Change password</h2><form method=\"post\" action=\"/me/password\">");
        csrfField(body);
        body.append("""
                <label for="current-password">Current password</label>
                <input id="current-password" name="current" type="password" required autocomplete="current-password">
                <label for="new-password">New password</label>
                <input id="new-password" name="new" type="password" minlength="12" maxlength="200"
                required autocomplete="new-password">
                <div class="actions"><button type="submit">Change password</button></div></form></div>
                """);
    }

    private static void save(HttpServletRequest request, HttpServletResponse response,
                             boolean publish) throws IOException {
        Store.Account account = requireAccount(request, response, false);
        if (account == null) {
            return;
        }
        if (account.admin() || account.mustChangePassword()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }
        String source = request.getParameter("source");
        if (source == null || source.getBytes(StandardCharsets.UTF_8).length > MAX_DRAFT_BYTES) {
            response.setStatus(HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE);
            editor(request, response, "The draft is too large.");
            return;
        }
        boolean saved;
        if (publish) {
            if (!Store.saveDraft(account, source)) {
                SecurityUtils.getSubject().logout();
                response.sendError(HttpServletResponse.SC_CONFLICT);
                return;
            }
            byte[] png;
            try {
                png = render(source);
            } catch (Exception exception) {
                response.setStatus(422);
                editor(request, response, "This page could not be rendered. Your previous publication is unchanged.");
                return;
            }
            saved = Store.publish(account, source, png);
        } else {
            saved = Store.saveDraft(account, source);
        }
        if (!saved) {
            SecurityUtils.getSubject().logout();
            response.sendError(HttpServletResponse.SC_CONFLICT);
            return;
        }
        redirect(request, response, "/me");
    }

    private static byte[] render(String source) throws Exception {
        var pages = new com.openhtmltopdf.java2d.api.BufferedImagePageProcessor(
                java.awt.image.BufferedImage.TYPE_INT_RGB, 1.0);
        new com.openhtmltopdf.java2d.api.Java2DRendererBuilder()
                .useEnvironmentFonts(true)
                .withHtmlContent(source, null)
                .toPageProcessor(pages)
                .runFirstPage();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        if (!javax.imageio.ImageIO.write(pages.getPageImages().get(0), "png", output)) {
            throw new IOException("PNG writer is unavailable");
        }
        return output.toByteArray();
    }

    private static void changePassword(HttpServletRequest request,
                                       HttpServletResponse response) throws IOException {
        Store.Account account = requireAccount(request, response, true);
        if (account == null) {
            return;
        }
        String currentValue = request.getParameter("current");
        String newValue = request.getParameter("new");
        if (currentValue == null || currentValue.length() > 200 || !validPassword(newValue)) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            editor(request, response, "Check both password fields.");
            return;
        }
        char[] current = currentValue.toCharArray();
        char[] replacement = newValue.toCharArray();
        try {
            if (!Store.changePassword(account, current, replacement)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                editor(request, response, "The current password is incorrect.");
                return;
            }
        } finally {
            Arrays.fill(current, '\0');
            Arrays.fill(replacement, '\0');
        }
        SecurityUtils.getSubject().logout();
        redirect(request, response, "/login");
    }

    private static void adminPage(HttpServletRequest request, HttpServletResponse response,
                                  String message) throws IOException {
        Store.Account admin = requireAdmin(request, response);
        if (admin == null) {
            return;
        }
        StringBuilder body = new StringBuilder("<h1>Accounts</h1><p class=\"lede\">Manage published homepages and account access.</p>");
        notice(body, message, true);
        body.append("<div class=\"card\"><table><thead><tr><th>Username</th><th>Status</th><th>Created</th><th>Published</th><th>Actions</th></tr></thead><tbody>");
        for (Store.Summary account : Store.listAccounts()) {
            body.append("<tr><td>").append(escape(account.username())).append("</td><td>")
                    .append(account.enabled() ? "Active" : "Disabled")
                    .append(account.role().equals("admin") ? " · admin" : "")
                    .append("</td><td>").append(escape(account.createdAt()))
                    .append("</td><td>").append(account.publishedAt() == null ? "—" : escape(account.publishedAt()))
                    .append("</td><td>");
            if (!account.username().equals(admin.username())) {
                adminButton(body, account.username(), account.enabled() ? "disable" : "enable",
                        account.enabled() ? "Disable" : "Enable", account.enabled());
                adminButton(body, account.username(), "reset", "Reset password", false);
                adminButton(body, account.username(), "delete", "Delete", true);
            }
            body.append("</td></tr>");
        }
        body.append("</tbody></table></div>");
        page(response, "Accounts", body.toString(), admin);
    }

    private static void adminButton(StringBuilder body, String username, String action,
                                    String label, boolean dangerous) {
        body.append("<form method=\"post\" action=\"/admin/").append(username)
                .append('/').append(action).append("\">");
        csrfField(body);
        body.append("<button type=\"submit\"");
        if (dangerous) {
            body.append(" class=\"danger\" onclick=\"return confirm('")
                    .append(action.equals("delete") ? "Delete" : "Disable")
                    .append(" this account?')\"");
        }
        body.append('>').append(label).append("</button></form>");
    }

    private static void adminAction(HttpServletRequest request, HttpServletResponse response,
                                    String username, String action) throws IOException {
        Store.Account admin = requireAdmin(request, response);
        if (admin == null) {
            return;
        }
        boolean changed;
        switch (action) {
            case "disable" -> changed = Store.setEnabled(admin.username(), username, false);
            case "enable" -> changed = Store.setEnabled(admin.username(), username, true);
            case "delete" -> changed = Store.delete(admin.username(), username);
            case "reset" -> {
                String credential = Store.resetPassword(admin.username(), username);
                if (credential == null) {
                    response.sendError(HttpServletResponse.SC_CONFLICT);
                    return;
                }
                StringBuilder body = new StringBuilder("<h1>Temporary credential</h1><p>Give this temporary password to ")
                        .append(escape(username)).append(". It will not be displayed again.</p><div class=\"card\"><code>")
                        .append(escape(credential)).append("</code></div><p>The user must change it after signing in.</p>")
                        .append("<p><a href=\"/admin\">Back to accounts</a></p>");
                page(response, "Temporary password", body.toString(), admin);
                return;
            }
            default -> throw new IllegalArgumentException("Unknown account action");
        }
        if (!changed) {
            response.sendError(HttpServletResponse.SC_CONFLICT);
            return;
        }
        redirect(request, response, "/admin");
    }

    private static Store.Account requireAdmin(HttpServletRequest request,
                                              HttpServletResponse response) throws IOException {
        Store.Account account = requireAccount(request, response, true);
        if (account == null) {
            return null;
        }
        if (!account.admin() || account.mustChangePassword()) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN);
            return null;
        }
        return account;
    }

    private static Store.Account requireAccount(HttpServletRequest request,
                                                HttpServletResponse response,
                                                boolean fullyAuthenticated) throws IOException {
        Subject subject = SecurityUtils.getSubject();
        if (fullyAuthenticated && !subject.isAuthenticated()) {
            redirect(request, response, "/login");
            return null;
        }
        Store.Account account = currentAccount();
        if (account == null) {
            redirect(request, response, "/login");
        }
        return account;
    }

    private static Store.Account currentAccount() {
        Subject subject = SecurityUtils.getSubject();
        if (!subject.isAuthenticated() && !subject.isRemembered()) {
            return null;
        }
        Object principal = subject.getPrincipal();
        if (!(principal instanceof AccountPrincipal identity)) {
            subject.logout();
            return null;
        }
        Store.Account account = Store.account(identity.username());
        if (account == null || !account.enabled()
                || account.authVersion() != identity.authVersion()) {
            subject.logout();
            return null;
        }
        return account;
    }

    private static boolean validPassword(String value) {
        return value != null && value.length() >= 12 && value.length() <= 200;
    }

    private static String csrfToken() {
        Session session = SecurityUtils.getSubject().getSession();
        Object token = session.getAttribute("csrf");
        if (token instanceof String current) {
            return current;
        }
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        String created = java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
        session.setAttribute("csrf", created);
        return created;
    }

    private static boolean validCsrf(HttpServletRequest request) {
        Session session = SecurityUtils.getSubject().getSession(false);
        Object expected = session == null ? null : session.getAttribute("csrf");
        String submitted = request.getParameter("csrf");
        return expected instanceof String value && submitted != null
                && MessageDigest.isEqual(value.getBytes(StandardCharsets.US_ASCII),
                        submitted.getBytes(StandardCharsets.US_ASCII));
    }

    private static void csrfField(StringBuilder body) {
        body.append("<input type=\"hidden\" name=\"csrf\" value=\"")
                .append(csrfToken()).append("\">");
    }

    private static void previewFrame(StringBuilder body) {
        body.append("""
                <h2>Preview</h2><p id="preview-status" class="hint">Nothing rendered yet.</p>
                <div class="screen"><img id="preview-image" alt="Your rendered homepage preview"></div>
                """);
    }

    private static void notice(StringBuilder body, String message, boolean success) {
        if (message != null) {
            body.append("<p class=\"").append(success ? "success" : "error")
                    .append("\">").append(escape(message)).append("</p>");
        }
    }

    private static void page(HttpServletResponse response, String title,
                             String body, Store.Account viewer) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        StringBuilder html = new StringBuilder("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">")
                .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">")
                .append("<title>").append(escape(title)).append(" · Works on My Machine</title><style>")
                .append(STYLE).append("</style></head><body><header><nav>")
                .append("<a class=\"brand\" href=\"/\">Works on My Machine</a>");
        if (viewer == null) {
            html.append("<a href=\"/login\">Sign in</a><a href=\"/signup\">Sign up</a>");
        } else {
            html.append("<a href=\"/me\">My page</a>");
            if (viewer.admin()) {
                html.append("<a href=\"/admin\">Accounts</a>");
            }
            html.append("<form method=\"post\" action=\"/logout\">");
            csrfField(html);
            html.append("<button class=\"secondary\" type=\"submit\">Sign out</button></form>");
        }
        html.append("</nav></header><main>").append(body)
                .append("<footer>A website that works on exactly one machine.</footer></main></body></html>");
        response.getWriter().write(html.toString());
    }

    private static void headers(HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("Referrer-Policy", "no-referrer");
        response.setHeader("Content-Security-Policy", "default-src 'none'; "
                + "style-src 'unsafe-inline'; script-src 'unsafe-inline'; "
                + "connect-src 'self'; img-src 'self' blob: data:; "
                + "form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
    }

    private static void redirect(HttpServletRequest request, HttpServletResponse response,
                                 String destination) {
        response.setStatus(HttpServletResponse.SC_SEE_OTHER);
        response.setHeader("Location", request.getContextPath() + destination);
    }

    private static String escape(String value) {
        if (value == null) {
            return "";
        }
        StringBuilder escaped = new StringBuilder(value.length());
        for (int index = 0; index < value.length(); index++) {
            switch (value.charAt(index)) {
                case '&' -> escaped.append("&amp;");
                case '<' -> escaped.append("&lt;");
                case '>' -> escaped.append("&gt;");
                case '"' -> escaped.append("&quot;");
                case '\'' -> escaped.append("&#39;");
                default -> escaped.append(value.charAt(index));
            }
        }
        return escaped.toString();
    }
}
