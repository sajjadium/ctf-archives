import java.awt.image.BufferedImage;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import javax.imageio.ImageIO;

import com.openhtmltopdf.java2d.api.BufferedImagePageProcessor;
import com.openhtmltopdf.java2d.api.Java2DRendererBuilder;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Main extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        SiteApp.get(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        if (!request.getRequestURI().equals(request.getContextPath() + "/")) {
            SiteApp.post(request, response);
            return;
        }
        response.setContentType("image/png");
        var pages = new BufferedImagePageProcessor(BufferedImage.TYPE_INT_RGB, 1.0);
        try {
            new Java2DRendererBuilder()
                    .useEnvironmentFonts(true)
                    .withHtmlContent(new String(request.getInputStream().readAllBytes(),
                            StandardCharsets.UTF_8), null)
                    .toPageProcessor(pages)
                    .runFirstPage();
            ImageIO.write(pages.getPageImages().get(0), "png", response.getOutputStream());
        } catch (Exception exception) {
            throw new ServletException(exception);
        }
    }
}
