import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Arrays;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

final class Password {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final int ITERATIONS = 210_000;
    private static final int KEY_BITS = 256;

    record Material(byte[] salt, byte[] hash) {}

    private Password() {}

    static Material hash(char[] password) {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return new Material(salt, derive(password, salt));
    }

    static boolean matches(char[] password, Material material) {
        if (password == null || password.length > 200) {
            return false;
        }
        byte[] candidate = derive(password, material.salt());
        try {
            return MessageDigest.isEqual(candidate, material.hash());
        } finally {
            Arrays.fill(candidate, (byte) 0);
        }
    }

    static String temporaryCredential() {
        byte[] bytes = new byte[24];
        RANDOM.nextBytes(bytes);
        return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }

    private static byte[] derive(char[] password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, KEY_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
        } catch (java.security.GeneralSecurityException exception) {
            throw new IllegalStateException("Password hashing is unavailable", exception);
        } finally {
            spec.clearPassword();
        }
    }
}
