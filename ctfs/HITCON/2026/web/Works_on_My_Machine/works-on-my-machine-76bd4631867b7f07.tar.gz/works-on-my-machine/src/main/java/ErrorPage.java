public final class ErrorPage extends jakarta.servlet.http.HttpServlet {
    @Override
    protected void service(jakarta.servlet.http.HttpServletRequest request,
                           jakarta.servlet.http.HttpServletResponse response)
            throws java.io.IOException {
        response.setStatus(500);
        response.setContentType("text/html;charset=UTF-8");
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.getWriter().write("<!doctype html><html lang=\"en\"><meta charset=\"utf-8\">"
                + "<title>Could not render · Works on My Machine</title>"
                + "<h1>That did not work on my machine.</h1>"
                + "<p>Please check your page and try again.</p></html>");
    }
}
