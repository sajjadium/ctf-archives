public final class AppBootstrap implements jakarta.servlet.ServletContextListener {
    @Override
    public void contextInitialized(jakarta.servlet.ServletContextEvent event) {
        Store.initialize();
    }
}
