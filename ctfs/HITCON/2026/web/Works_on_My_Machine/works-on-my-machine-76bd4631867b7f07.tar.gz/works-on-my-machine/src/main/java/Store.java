import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.PosixFilePermissions;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

final class Store {
    private static final Path STATE = Path.of("/var/lib/works-on-my-machine");
    private static final Path DATABASE = STATE.resolve("site.db");
    private static final Path INITIAL_PASSWORD = STATE.resolve("admin.initial-password");
    private static final Pattern USERNAME = Pattern.compile("[a-z][a-z0-9_-]{2,23}");
    private static final Set<String> RESERVED = Set.of(
            "admin", "assets", "error", "login", "logout", "me", "signup");
    private static volatile boolean initialized;

    record Account(String username, byte[] salt, byte[] passwordHash, String role,
                   boolean enabled, boolean mustChangePassword, long authVersion,
                   String draft, String createdAt, String publishedAt) {
        boolean admin() {
            return "admin".equals(role);
        }
    }

    record Summary(String username, String role, boolean enabled,
                   String createdAt, String publishedAt) {}

    private Store() {}

    static boolean validUsername(String username) {
        return username != null && USERNAME.matcher(username).matches()
                && !RESERVED.contains(username);
    }

    static Account account(String username) {
        initialize();
        if (username == null) {
            return null;
        }
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT username, salt, password_hash, role, enabled, must_change, "
                             + "auth_version, draft, created_at, published_at "
                             + "FROM accounts WHERE username = ?")) {
            statement.setString(1, username);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? readAccount(result) : null;
            }
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static boolean create(String username, char[] password) {
        if (!validUsername(username)) {
            return false;
        }
        initialize();
        Password.Material material = Password.hash(password);
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "INSERT INTO accounts(username, salt, password_hash, role) "
                             + "VALUES(?, ?, ?, 'user')")) {
            statement.setString(1, username);
            statement.setBytes(2, material.salt());
            statement.setBytes(3, material.hash());
            return statement.executeUpdate() == 1;
        } catch (SQLException exception) {
            if (exception.getErrorCode() == 19) {
                return false;
            }
            throw storageFailure(exception);
        }
    }

    static byte[] publishedImage(String username) {
        initialize();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT published_png FROM accounts "
                             + "WHERE username = ? AND enabled = 1")) {
            statement.setString(1, username);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? result.getBytes(1) : null;
            }
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static boolean saveDraft(Account owner, String source) {
        initialize();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE accounts SET draft = ? WHERE username = ? "
                             + "AND enabled = 1 AND auth_version = ?")) {
            statement.setString(1, source);
            statement.setString(2, owner.username());
            statement.setLong(3, owner.authVersion());
            return statement.executeUpdate() == 1;
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static boolean publish(Account owner, String source, byte[] png) {
        initialize();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE accounts SET draft = ?, published_png = ?, "
                             + "published_at = CURRENT_TIMESTAMP "
                             + "WHERE username = ? AND enabled = 1 AND auth_version = ?")) {
            statement.setString(1, source);
            statement.setBytes(2, png);
            statement.setString(3, owner.username());
            statement.setLong(4, owner.authVersion());
            return statement.executeUpdate() == 1;
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static synchronized boolean changePassword(Account owner, char[] oldPassword,
                                                char[] newPassword) {
        Account current = account(owner.username());
        if (current == null || !current.enabled()
                || current.authVersion() != owner.authVersion()
                || !Password.matches(oldPassword,
                        new Password.Material(current.salt(), current.passwordHash()))) {
            return false;
        }
        Password.Material material = Password.hash(newPassword);
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE accounts SET salt = ?, password_hash = ?, must_change = 0, "
                             + "auth_version = auth_version + 1 "
                             + "WHERE username = ? AND enabled = 1 AND auth_version = ?")) {
            statement.setBytes(1, material.salt());
            statement.setBytes(2, material.hash());
            statement.setString(3, owner.username());
            statement.setLong(4, owner.authVersion());
            return statement.executeUpdate() == 1;
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static List<Summary> listAccounts() {
        initialize();
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "SELECT username, role, enabled, created_at, published_at "
                             + "FROM accounts ORDER BY username");
             ResultSet result = statement.executeQuery()) {
            List<Summary> accounts = new ArrayList<>();
            while (result.next()) {
                accounts.add(new Summary(result.getString(1), result.getString(2),
                        result.getInt(3) == 1, result.getString(4), result.getString(5)));
            }
            return accounts;
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static synchronized boolean setEnabled(String actor, String username, boolean enabled) {
        initialize();
        if (actor.equals(username)) {
            return false;
        }
        try (Connection connection = connect()) {
            Account target = account(username);
            if (target == null || (!enabled && target.admin() && target.enabled()
                    && activeAdminCount(connection) <= 1)) {
                return false;
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE accounts SET enabled = ?, auth_version = auth_version + 1 "
                            + "WHERE username = ?")) {
                statement.setInt(1, enabled ? 1 : 0);
                statement.setString(2, username);
                return statement.executeUpdate() == 1;
            }
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static synchronized boolean delete(String actor, String username) {
        initialize();
        if (actor.equals(username)) {
            return false;
        }
        try (Connection connection = connect()) {
            Account target = account(username);
            if (target == null || (target.admin() && target.enabled()
                    && activeAdminCount(connection) <= 1)) {
                return false;
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM accounts WHERE username = ?")) {
                statement.setString(1, username);
                return statement.executeUpdate() == 1;
            }
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static synchronized String resetPassword(String actor, String username) {
        initialize();
        if (actor.equals(username)) {
            return null;
        }
        String credential = Password.temporaryCredential();
        Password.Material material = Password.hash(credential.toCharArray());
        try (Connection connection = connect();
             PreparedStatement statement = connection.prepareStatement(
                     "UPDATE accounts SET salt = ?, password_hash = ?, must_change = 1, "
                             + "auth_version = auth_version + 1 WHERE username = ?")) {
            statement.setBytes(1, material.salt());
            statement.setBytes(2, material.hash());
            statement.setString(3, username);
            return statement.executeUpdate() == 1 ? credential : null;
        } catch (SQLException exception) {
            throw storageFailure(exception);
        }
    }

    static void discardInitialPassword() {
        try {
            Files.deleteIfExists(INITIAL_PASSWORD);
        } catch (IOException exception) {
            throw new IllegalStateException("Could not remove initial admin credential", exception);
        }
    }

    static synchronized void initialize() {
        if (initialized) {
            return;
        }
        try {
            Files.createDirectories(STATE);
            try (Connection connection = connect(); Statement statement = connection.createStatement()) {
                statement.execute("PRAGMA journal_mode = WAL");
                statement.execute("CREATE TABLE IF NOT EXISTS accounts ("
                        + "username TEXT PRIMARY KEY COLLATE BINARY, "
                        + "salt BLOB NOT NULL, password_hash BLOB NOT NULL, "
                        + "role TEXT NOT NULL CHECK(role IN ('user', 'admin')), "
                        + "enabled INTEGER NOT NULL DEFAULT 1, "
                        + "must_change INTEGER NOT NULL DEFAULT 0, "
                        + "auth_version INTEGER NOT NULL DEFAULT 1, "
                        + "draft TEXT NOT NULL DEFAULT '', published_png BLOB, "
                        + "created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, "
                        + "published_at TEXT)");
                try (ResultSet result = statement.executeQuery(
                        "SELECT COUNT(*) FROM accounts WHERE role = 'admin'")) {
                    result.next();
                    if (result.getInt(1) == 0) {
                        bootstrapAdmin(connection);
                    }
                }
            }
            initialized = true;
        } catch (IOException | SQLException exception) {
            throw new IllegalStateException("Could not initialize account storage", exception);
        }
    }

    private static void bootstrapAdmin(Connection connection) throws IOException, SQLException {
        String credential;
        if (Files.exists(INITIAL_PASSWORD)) {
            credential = Files.readString(INITIAL_PASSWORD, StandardCharsets.UTF_8).strip();
            if (credential.isEmpty()) {
                throw new IOException("Initial admin credential is empty");
            }
        } else {
            credential = Password.temporaryCredential();
            Files.writeString(INITIAL_PASSWORD, credential + "\n", StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE_NEW, StandardOpenOption.WRITE);
            Files.setPosixFilePermissions(INITIAL_PASSWORD,
                    PosixFilePermissions.fromString("rw-------"));
        }
        Password.Material material = Password.hash(credential.toCharArray());
        try (PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO accounts(username, salt, password_hash, role) "
                        + "VALUES('admin', ?, ?, 'admin')")) {
            statement.setBytes(1, material.salt());
            statement.setBytes(2, material.hash());
            statement.executeUpdate();
        }
    }

    private static int activeAdminCount(Connection connection) throws SQLException {
        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(
                     "SELECT COUNT(*) FROM accounts WHERE role = 'admin' AND enabled = 1")) {
            result.next();
            return result.getInt(1);
        }
    }

    private static Account readAccount(ResultSet result) throws SQLException {
        return new Account(result.getString(1), result.getBytes(2), result.getBytes(3),
                result.getString(4), result.getInt(5) == 1, result.getInt(6) == 1,
                result.getLong(7), result.getString(8), result.getString(9),
                result.getString(10));
    }

    private static Connection connect() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException exception) {
            throw new SQLException("SQLite driver is unavailable", exception);
        }
        Connection connection = DriverManager.getConnection("jdbc:sqlite:" + DATABASE);
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA busy_timeout = 5000");
        }
        return connection;
    }

    private static IllegalStateException storageFailure(SQLException exception) {
        return new IllegalStateException("Account storage failed", exception);
    }
}
