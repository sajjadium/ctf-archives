from sage.all import *
from hashlib import sha256, sha512
from random import SystemRandom
from Crypto.Cipher import AES

rand = SystemRandom()

l, n = 1024, 1044
bits = 16384
O = OctonionAlgebra(ZZ)


def gen(t):
    return O(list(sha512(t.to_bytes(2, "big")).digest()[:8]))


generators = [gen(t) for t in range(l)]

if __name__ == "__main__":
    with open("flag.txt", "rb") as f:
        flag = f.read().strip()

    word = list(range(l))
    word.extend(rand.randrange(l) for _ in range(n - l))
    rand.shuffle(word)
    x = 1
    for i in range(0, n, 6):
        u = 1
        for t in word[i : i + 6]:
            u = generators[t] * u
        for t in word[i + 2 : i + 6]:
            u = u * generators[t]
        x *= u

    x = vector(ZZ, (x / gcd(x)))
    q = 1 << bits
    pivot = next(j for j, z in enumerate(x) if z % 2)
    v = x * inverse_mod(x[pivot], q) % q

    key = b"".join(t.to_bytes(2, "big") for t in word)
    cipher = AES.new(sha256(key).digest(), AES.MODE_CTR)
    ct = cipher.encrypt(flag)
    print(f"v = {v.list()}")
    print(f"{ct = }")
    print(f"nonce = {cipher.nonce}")
