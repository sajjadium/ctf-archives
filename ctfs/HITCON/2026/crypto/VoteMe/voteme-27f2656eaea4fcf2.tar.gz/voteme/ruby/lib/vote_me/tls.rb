require "digest"
require "openssl"
require "securerandom"
require "socket"
require_relative "curve"

module VoteMe
  module TLS
    VERSION = "\x03\x03".b
    CIPHER_SUITE = "\xc0\x30".b
    CHANGE_CIPHER_SPEC = 20
    ALERT = 21
    HANDSHAKE = 22
    APPLICATION_DATA = 23
    CLIENT_HELLO = 1
    SERVER_HELLO = 2
    CERTIFICATE = 11
    SERVER_KEY_EXCHANGE = 12
    SERVER_HELLO_DONE = 14
    CLIENT_KEY_EXCHANGE = 16
    FINISHED = 20
    MAX_PLAINTEXT = 16_384
    MAX_HTTP = 64 * 1024 * 1024

    module_function

    def u24(value)
      [value].pack("N").byteslice(1, 3)
    end

    def read_u24(data, offset = 0)
      ("\0".b + data.byteslice(offset, 3)).unpack1("N")
    end

    def vector8(data)
      raise ArgumentError, "vector too large" if data.bytesize > 255
      [data.bytesize].pack("C") + data
    end

    def extension(type, data)
      [type, data.bytesize].pack("nn") + data
    end

    def handshake(type, body)
      [type].pack("C") + u24(body.bytesize) + body
    end

    def parse_handshake(data)
      raise IOError, "invalid handshake" if data.bytesize < 4
      size = read_u24(data, 1)
      raise IOError, "invalid handshake" unless data.bytesize == size + 4
      [data.getbyte(0), data.byteslice(4, size), data]
    end

    def int_bytes(value, size = nil)
      hex = value.to_s(16)
      hex = "0#{hex}" if hex.length.odd?
      data = [hex].pack("H*")
      size ? data.rjust(size, "\0") : data
    end

    def curve_parameters(public_point = nil)
      output = +"\x01".b
      output << vector8(int_bytes(Curve::P, 32))
      output << vector8(int_bytes(Curve::A, 32))
      output << vector8(int_bytes(Curve::B, 32))
      output << vector8(Curve.encode(Curve::G))
      output << vector8(int_bytes(Curve::ORDER))
      output << vector8(int_bytes(Curve::COFACTOR))
      output << vector8(Curve.encode(public_point)) if public_point
      output
    end

    def parse_server_parameters(data)
      prefix = curve_parameters
      raise IOError, "unsupported parameters" unless data.start_with?(prefix)
      offset = prefix.bytesize
      size = data.getbyte(offset)
      raise IOError, "invalid public key" unless size
      finish = offset + 1 + size
      raise IOError, "invalid public key" if finish > data.bytesize
      point = Curve.decode(data.byteslice(offset + 1, size))
      raise IOError, "invalid public key" unless Curve.subgroup?(point)
      [point, finish]
    end

    def prf(secret, label, seed, size)
      input = label.b + seed
      a = input
      output = +"".b
      while output.bytesize < size
        a = OpenSSL::HMAC.digest("SHA384", secret, a)
        output << OpenSSL::HMAC.digest("SHA384", secret, a + input)
      end
      output.byteslice(0, size)
    end

    def keys(shared, client_random, server_random)
      premaster = int_bytes(shared[0], 32)
      master = prf(premaster, "master secret", client_random + server_random, 48)
      block = prf(master, "key expansion", server_random + client_random, 72)
      [master, block.byteslice(0, 32), block.byteslice(32, 32), block.byteslice(64, 4), block.byteslice(68, 4)]
    end

    def finished(master, label, transcript)
      prf(master, label, Digest::SHA384.digest(transcript), 12)
    end

    def secure_equal(left, right)
      left.bytesize == right.bytesize && OpenSSL.fixed_length_secure_compare(left, right)
    end

    def complete_http?(data)
      marker = data.index("\r\n\r\n".b)
      return false unless marker
      headers = data.byteslice(0, marker + 4)
      match = headers.match(/\r\nContent-Length:\s*(\d+)\r\n/i)
      raise IOError, "missing content length" unless match
      size = marker + 4 + Integer(match[1])
      raise IOError, "message too large" if size > MAX_HTTP
      data.bytesize >= size ? size : false
    end

    class Records
      def initialize(socket)
        @socket = socket
      end

      def read_exact(size)
        output = +"".b
        output << @socket.readpartial(size - output.bytesize) while output.bytesize < size
        output
      end

      def read
        header = read_exact(5)
        type = header.getbyte(0)
        version = header.byteslice(1, 2)
        size = header.byteslice(3, 2).unpack1("n")
        raise IOError, "unsupported version" unless version == VERSION
        raise IOError, "record too large" if size > MAX_PLAINTEXT + 2048
        [type, read_exact(size)]
      end

      def write(type, body)
        data = [type].pack("C") + VERSION + [body.bytesize].pack("n") + body
        offset = 0
        offset += @socket.write(data.byteslice(offset, data.bytesize - offset)) while offset < data.bytesize
      end
    end

    class Handshakes
      def initialize(records)
        @records = records
        @buffer = +"".b
      end

      def read
        loop do
          if @buffer.bytesize >= 4
            size = TLS.read_u24(@buffer, 1)
            if @buffer.bytesize >= size + 4
              raw = @buffer.slice!(0, size + 4)
              return [raw.getbyte(0), raw.byteslice(4, size), raw]
            end
          end
          type, body = @records.read
          raise IOError, "expected handshake" unless type == HANDSHAKE
          @buffer << body
        end
      end
    end

    class CipherState
      attr_reader :sequence

      def initialize(key, fixed_iv)
        @key = key
        @fixed_iv = fixed_iv
        @sequence = 0
      end

      def seal(type, plaintext)
        explicit = [@sequence].pack("Q>")
        cipher = OpenSSL::Cipher.new("aes-256-gcm")
        cipher.encrypt
        cipher.key = @key
        cipher.iv = @fixed_iv + explicit
        cipher.auth_data = [@sequence].pack("Q>") + [type].pack("C") + VERSION + [plaintext.bytesize].pack("n")
        ciphertext = cipher.update(plaintext) + cipher.final
        @sequence += 1
        explicit + ciphertext + cipher.auth_tag(16)
      end

      def open(type, body)
        raise IOError, "invalid ciphertext" if body.bytesize < 24
        explicit = body.byteslice(0, 8)
        ciphertext = body.byteslice(8, body.bytesize - 24)
        tag = body.byteslice(-16, 16)
        raise IOError, "invalid nonce" unless explicit == [@sequence].pack("Q>")
        cipher = OpenSSL::Cipher.new("aes-256-gcm")
        cipher.decrypt
        cipher.key = @key
        cipher.iv = @fixed_iv + explicit
        cipher.auth_tag = tag
        cipher.auth_data = [@sequence].pack("Q>") + [type].pack("C") + VERSION + [ciphertext.bytesize].pack("n")
        plaintext = cipher.update(ciphertext) + cipher.final
        @sequence += 1
        plaintext
      rescue OpenSSL::Cipher::CipherError
        raise IOError, "authentication failed"
      end
    end

    class Session
      def initialize(records, incoming, outgoing)
        @records = records
        @incoming = incoming
        @outgoing = outgoing
      end

      def write_application(data)
        offset = 0
        while offset < data.bytesize
          fragment = data.byteslice(offset, MAX_PLAINTEXT)
          @records.write(APPLICATION_DATA, @outgoing.seal(APPLICATION_DATA, fragment))
          offset += fragment.bytesize
        end
      end

      def read_http
        data = +"".b
        loop do
          type, body = @records.read
          raise IOError, "unexpected record" unless type == APPLICATION_DATA
          data << @incoming.open(type, body)
          size = TLS.complete_http?(data)
          return data.byteslice(0, size) if size
        end
      end
    end

    class Server
      def initialize(source = Random.new)
        @source = source
        @key, @certificate = create_certificate
      end

      def accept(socket)
        records = Records.new(socket)
        handshakes = Handshakes.new(records)
        type, client_body, client_message = handshakes.read
        raise IOError, "expected client hello" unless type == CLIENT_HELLO
        client_random = parse_client_hello(client_body)
        server_random = SecureRandom.bytes(32)
        scalar = Curve.scalar(@source.bytes(Curve::SCALAR_BYTES))
        public_point = Curve.multiply(scalar, Curve::G)
        server_hello = TLS.handshake(SERVER_HELLO, server_hello_body(server_random))
        certificate = TLS.handshake(CERTIFICATE, certificate_body)
        params = TLS.curve_parameters(public_point)
        signature = @key.sign(OpenSSL::Digest::SHA384.new, client_random + server_random + params)
        exchange = TLS.handshake(SERVER_KEY_EXCHANGE, params + "\x05\x01".b + [signature.bytesize].pack("n") + signature)
        done = TLS.handshake(SERVER_HELLO_DONE, "".b)
        [server_hello, certificate, exchange, done].each { |message| records.write(HANDSHAKE, message) }
        transcript = client_message + server_hello + certificate + exchange + done
        type, client_key_body, client_key_message = handshakes.read
        raise IOError, "expected client key exchange" unless type == CLIENT_KEY_EXCHANGE
        client_point = parse_client_key(client_key_body)
        shared = Curve.multiply(scalar, client_point)
        raise IOError, "invalid shared secret" unless shared
        master, client_key, server_key, client_iv, server_iv = TLS.keys(shared, client_random, server_random)
        transcript << client_key_message
        type, body = records.read
        raise IOError, "expected change cipher spec" unless type == CHANGE_CIPHER_SPEC && body == "\x01".b
        incoming = CipherState.new(client_key, client_iv)
        outgoing = CipherState.new(server_key, server_iv)
        type, body = records.read
        raise IOError, "expected finished" unless type == HANDSHAKE
        plaintext = incoming.open(type, body)
        finished_type, finished_body, client_finished = TLS.parse_handshake(plaintext)
        expected = TLS.finished(master, "client finished", transcript)
        raise IOError, "invalid finished" unless finished_type == FINISHED && TLS.secure_equal(finished_body, expected)
        transcript << client_finished
        server_finished = TLS.handshake(FINISHED, TLS.finished(master, "server finished", transcript))
        records.write(CHANGE_CIPHER_SPEC, "\x01".b)
        records.write(HANDSHAKE, outgoing.seal(HANDSHAKE, server_finished))
        session = Session.new(records, incoming, outgoing)
        session.write_application(yield(session.read_http))
      end

      def create_certificate
        key = OpenSSL::PKey::RSA.new(2048)
        name = OpenSSL::X509::Name.parse("/CN=api.voteme.local")
        certificate = OpenSSL::X509::Certificate.new
        certificate.version = 2
        certificate.serial = SecureRandom.random_number(1 << 63) + 1
        certificate.subject = name
        certificate.issuer = name
        certificate.public_key = key.public_key
        certificate.not_before = Time.now - 60
        certificate.not_after = Time.now + 86_400
        certificate.sign(key, OpenSSL::Digest::SHA256.new)
        [key, certificate]
      end

      def parse_client_hello(body)
        raise IOError, "invalid client hello" if body.bytesize < 40 || body.byteslice(0, 2) != VERSION
        random = body.byteslice(2, 32)
        offset = 34
        session_size = body.getbyte(offset)
        offset += 1 + session_size
        suites_size = body.byteslice(offset, 2)&.unpack1("n")
        raise IOError, "invalid client hello" unless suites_size
        offset += 2
        suites = body.byteslice(offset, suites_size)
        offset += suites_size
        compression_size = body.getbyte(offset)
        raise IOError, "invalid client hello" unless compression_size
        offset += 1
        compression = body.byteslice(offset, compression_size)
        offset += compression_size
        extensions_size = body.byteslice(offset, 2)&.unpack1("n")
        raise IOError, "invalid client hello" unless extensions_size && offset + 2 + extensions_size == body.bytesize
        extensions = body.byteslice(offset + 2, extensions_size)
        required = TLS.extension(10, "\x00\x02\xff\x01".b)
        raise IOError, "unsupported client" unless suites&.include?(CIPHER_SUITE) && compression&.include?("\0".b) && extensions.include?(required)
        random
      end

      def server_hello_body(random)
        extensions = TLS.extension(11, "\x01\x00".b)
        VERSION + random + "\x00".b + CIPHER_SUITE + "\x00".b + [extensions.bytesize].pack("n") + extensions
      end

      def certificate_body
        der = @certificate.to_der
        entry = TLS.u24(der.bytesize) + der
        TLS.u24(entry.bytesize) + entry
      end

      def parse_client_key(body)
        raise IOError, "invalid client key" if body.empty? || body.getbyte(0) != body.bytesize - 1
        point = Curve.decode(body.byteslice(1, body.getbyte(0)))
        raise IOError, "invalid client key" unless Curve.subgroup?(point)
        point
      end
    end

    class Client
      def connect(host, port, request)
        socket = TCPSocket.new(host, port)
        exchange(socket, request)
      ensure
        socket&.close
      end

      def exchange(socket, request)
        records = Records.new(socket)
        client_random = SecureRandom.bytes(32)
        client_hello = TLS.handshake(CLIENT_HELLO, client_hello_body(client_random))
        records.write(HANDSHAKE, client_hello)
        handshakes = Handshakes.new(records)
        type, server_body, server_hello = handshakes.read
        raise IOError, "expected server hello" unless type == SERVER_HELLO
        server_random = parse_server_hello(server_body)
        type, certificate_body, certificate_message = handshakes.read
        raise IOError, "expected certificate" unless type == CERTIFICATE
        certificate = parse_certificate(certificate_body)
        type, exchange_body, exchange_message = handshakes.read
        raise IOError, "expected server key exchange" unless type == SERVER_KEY_EXCHANGE
        server_point, params_size = TLS.parse_server_parameters(exchange_body)
        verify_exchange(certificate, exchange_body, params_size, client_random, server_random)
        type, body, done = handshakes.read
        raise IOError, "expected server hello done" unless type == SERVER_HELLO_DONE && body.empty?
        scalar = Curve.scalar(SecureRandom.bytes(Curve::SCALAR_BYTES))
        public_point = Curve.multiply(scalar, Curve::G)
        client_key = TLS.handshake(CLIENT_KEY_EXCHANGE, TLS.vector8(Curve.encode(public_point)))
        records.write(HANDSHAKE, client_key)
        transcript = client_hello + server_hello + certificate_message + exchange_message + done + client_key
        shared = Curve.multiply(scalar, server_point)
        raise IOError, "invalid shared secret" unless shared
        master, client_write_key, server_write_key, client_iv, server_iv = TLS.keys(shared, client_random, server_random)
        outgoing = CipherState.new(client_write_key, client_iv)
        incoming = CipherState.new(server_write_key, server_iv)
        client_finished = TLS.handshake(FINISHED, TLS.finished(master, "client finished", transcript))
        records.write(CHANGE_CIPHER_SPEC, "\x01".b)
        records.write(HANDSHAKE, outgoing.seal(HANDSHAKE, client_finished))
        transcript << client_finished
        type, body = records.read
        raise IOError, "expected change cipher spec" unless type == CHANGE_CIPHER_SPEC && body == "\x01".b
        type, body = records.read
        raise IOError, "expected finished" unless type == HANDSHAKE
        plaintext = incoming.open(type, body)
        finished_type, finished_body, = TLS.parse_handshake(plaintext)
        expected = TLS.finished(master, "server finished", transcript)
        raise IOError, "invalid finished" unless finished_type == FINISHED && TLS.secure_equal(finished_body, expected)
        session = Session.new(records, incoming, outgoing)
        session.write_application(request)
        session.read_http
      end

      def client_hello_body(random)
        groups = TLS.extension(10, "\x00\x02\xff\x01".b)
        formats = TLS.extension(11, "\x01\x00".b)
        algorithms = TLS.extension(13, "\x00\x02\x05\x01".b)
        extensions = groups + formats + algorithms
        VERSION + random + "\x00".b + "\x00\x02".b + CIPHER_SUITE + "\x01\x00".b + [extensions.bytesize].pack("n") + extensions
      end

      def parse_server_hello(body)
        raise IOError, "invalid server hello" if body.bytesize < 40 || body.byteslice(0, 2) != VERSION
        random = body.byteslice(2, 32)
        offset = 34
        session_size = body.getbyte(offset)
        offset += 1 + session_size
        raise IOError, "unsupported server" unless body.byteslice(offset, 2) == CIPHER_SUITE && body.getbyte(offset + 2) == 0
        random
      end

      def parse_certificate(body)
        raise IOError, "invalid certificate" if body.bytesize < 6
        total = TLS.read_u24(body)
        size = TLS.read_u24(body, 3)
        raise IOError, "invalid certificate" unless total + 3 == body.bytesize && size + 6 <= body.bytesize
        certificate = OpenSSL::X509::Certificate.new(body.byteslice(6, size))
        raise IOError, "invalid certificate" unless certificate.verify(certificate.public_key)
        certificate
      end

      def verify_exchange(certificate, body, params_size, client_random, server_random)
        raise IOError, "invalid signature" if params_size + 4 > body.bytesize
        algorithm = body.byteslice(params_size, 2)
        size = body.byteslice(params_size + 2, 2).unpack1("n")
        signature = body.byteslice(params_size + 4, size)
        raise IOError, "invalid signature" unless algorithm == "\x05\x01".b && signature&.bytesize == size
        params = body.byteslice(0, params_size)
        valid = certificate.public_key.verify(OpenSSL::Digest::SHA384.new, signature, client_random + server_random + params)
        raise IOError, "invalid signature" unless valid
      end
    end
  end
end
