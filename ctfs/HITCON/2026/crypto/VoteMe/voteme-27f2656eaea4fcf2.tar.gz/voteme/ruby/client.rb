require "json"
require_relative "lib/vote_me/tls"

module VoteMe
  class Client
    def initialize(host: ENV.fetch("SSL_HOST", "127.0.0.1"), port: Integer(ENV.fetch("SSL_PORT", "8443")))
      @host = host
      @port = port
      @tls = TLS::Client.new
    end

    def candidates
      get("/candidates")
    end

    def status
      get("/status")
    end

    def vote(candidate_id)
      post("/vote", { candidate_id: candidate_id })
    end

    def votes
      get("/votes")
    end

    def get(path)
      exchange("GET", path, nil)
    end

    def post(path, payload)
      exchange("POST", path, JSON.generate(payload))
    end

    def exchange(method, path, body)
      body ||= ""
      request = [
        "#{method} #{path} HTTP/1.1",
        "Host: api.voteme.local",
        "Content-Type: application/json",
        "Content-Length: #{body.bytesize}",
        "Connection: close",
        "",
        body,
      ].join("\r\n")
      response = @tls.connect(@host, @port, request)
      _, content = response.split("\r\n\r\n", 2)
      JSON.parse(content)
    end
  end
end
