module VoteMe
  module Curve
    P = 89025939082434796413600671938588077849057880765442485138379977529032945827841
    A = 1
    B = 0
    ORDER = 1358428025549847357385264159219178433970057909696144578443833691290271744
    COFACTOR = 65_536
    SCALAR_BYTES = 32
    G = [
      41209836325234781044181597304544742925948820810888367894489840040559411336265,
      58717619821656938994285449686691658631929085725700003126366067459102233551806
    ].freeze
    J_INFINITY = [0, 1, 0].freeze

    module_function

    def mod(value)
      value % P
    end

    def double(point)
      x, y, z = point
      return J_INFINITY if z.zero? || y.zero?
      xx = mod(x * x)
      yy = mod(y * y)
      yyyy = mod(yy * yy)
      zz = mod(z * z)
      s = mod(2 * (mod((x + yy) * (x + yy)) - xx - yyyy))
      m = mod(3 * xx + A * mod(zz * zz))
      x3 = mod(m * m - 2 * s)
      y3 = mod(m * (s - x3) - 8 * yyyy)
      z3 = mod(2 * y * z)
      [x3, y3, z3]
    end

    def add(left, right)
      x1, y1, z1 = left
      x2, y2, z2 = right
      return right if z1.zero?
      return left if z2.zero?
      z1z1 = mod(z1 * z1)
      z2z2 = mod(z2 * z2)
      u1 = mod(x1 * z2z2)
      u2 = mod(x2 * z1z1)
      s1 = mod(y1 * z2 * z2z2)
      s2 = mod(y2 * z1 * z1z1)
      h = mod(u2 - u1)
      r = mod(s2 - s1)
      return r.zero? ? double(left) : J_INFINITY if h.zero?
      hh = mod(h * h)
      hhh = mod(h * hh)
      v = mod(u1 * hh)
      x3 = mod(r * r - hhh - 2 * v)
      y3 = mod(r * (v - x3) - s1 * hhh)
      z3 = mod(z1 * z2 * h)
      [x3, y3, z3]
    end

    def projective(point)
      point.nil? ? J_INFINITY : [point[0], point[1], 1]
    end

    def affine(point)
      x, y, z = point
      return nil if z.zero?
      inverse = z.pow(P - 2, P)
      inverse2 = mod(inverse * inverse)
      [mod(x * inverse2), mod(y * inverse2 * inverse)]
    end

    def multiply(scalar, point)
      result = J_INFINITY
      addend = projective(point)
      value = scalar
      until value.zero?
        result = add(result, addend) if value.odd?
        addend = double(addend)
        value >>= 1
      end
      affine(result)
    end

    def valid?(point)
      return false if point.nil?
      x, y = point
      x >= 0 && x < P && y >= 0 && y < P && mod(y * y) == mod(x * x * x + A * x + B)
    end

    def subgroup?(point)
      valid?(point) && multiply(ORDER, point).nil?
    end

    def scalar(data)
      raise ArgumentError, "invalid scalar" unless data.bytesize == SCALAR_BYTES
      value = data.reverse.unpack1("H*").to_i(16) % ORDER
      value.zero? ? 1 : value
    end

    def encode(point)
      raise ArgumentError, "invalid point" unless valid?(point)
      "\x04".b + [point[0].to_s(16).rjust(64, "0")].pack("H*") + [point[1].to_s(16).rjust(64, "0")].pack("H*")
    end

    def decode(data)
      raise ArgumentError, "invalid point" unless data.bytesize == 65 && data.getbyte(0) == 4
      point = [data.byteslice(1, 32).unpack1("H*").to_i(16), data.byteslice(33, 32).unpack1("H*").to_i(16)]
      raise ArgumentError, "invalid point" unless valid?(point)
      point
    end
  end
end
