require "socket"
require_relative "lib/vote_me/tls"

host = ENV.fetch("SSL_HOST", "127.0.0.1")
port = Integer(ENV.fetch("SSL_PORT", "8443"))
api_host = ENV.fetch("API_HOST", "127.0.0.1")
api_port = Integer(ENV.fetch("API_PORT", "8787"))
server = TCPServer.new(host, port)
tls = VoteMe::TLS::Server.new

loop do
  socket = server.accept
  begin
    tls.accept(socket) do |request|
      upstream = TCPSocket.new(api_host, api_port)
      upstream.write(request)
      upstream.read
    ensure
      upstream&.close
    end
  rescue EOFError, IOError, OpenSSL::Cipher::CipherError, ArgumentError
    next
  ensure
    socket.close
  end
end
