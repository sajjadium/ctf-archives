pragma circom 2.0.0;

template Vote() {
    signal input vote;
    signal input electionId;
    signal output ok;

    signal t;
    t <== vote * (vote - 1);
    t * (vote - 2) === 0;

    signal e;
    e <== electionId * electionId;

    ok <== 1;
}

component main {public [electionId]} = Vote();
