require_relative "ruby/client"

class Initializer
  def initialize(client = VoteMe::Client.new)
    @client = client
  end

  def seed(value = ENV.fetch("FLAG", "hitcon{TEST_ME}"))
    encoded = value.bytes.flat_map { |byte| encode(byte) }
    raise "too many votes" unless encoded.length < 1000
    encoded.each { |candidate_id| @client.vote(candidate_id) }
    encoded.length
  end

  def populate(count)
    count.times do |index|
      @client.candidates
      @client.status
      @client.vote((index * 2 + 1) % 3)
    end
  end

  def finish
    @client.votes
  end

  def encode(value)
    digits = Array.new(6, 0)
    5.downto(0) do |index|
      digits[index] = value % 3
      value /= 3
    end
    digits
  end
end

if $PROGRAM_NAME == __FILE__
  initializer = Initializer.new
  used = initializer.seed
  initializer.populate(1000 - used)
  initializer.finish
end
