require "fileutils"
require "socket"
require_relative "initialize"

def wait_for(host, port)
  deadline = Process.clock_gettime(Process::CLOCK_MONOTONIC) + 15
  loop do
    socket = TCPSocket.new(host, port)
    socket.close
    return
  rescue Errno::ECONNREFUSED
    raise if Process.clock_gettime(Process::CLOCK_MONOTONIC) >= deadline
    sleep 0.05
  end
end

def connection_count(path, port)
  filter = "tcp[tcpflags] & tcp-syn != 0 and dst port #{port}"
  IO.popen(["tcpdump", "-nnr", path, filter], err: File::NULL) { |output| output.each_line.count }
end

root = File.expand_path(__dir__)
output = ENV.fetch("OUTPUT", File.join(root, "traffic.pcap"))
api_host = ENV.fetch("API_HOST", "127.0.0.1")
api_port = Integer(ENV.fetch("API_PORT", "8787"))
ssl_host = ENV.fetch("SSL_HOST", "127.0.0.1")
ssl_port = Integer(ENV.fetch("SSL_PORT", "8443"))
api_pid = spawn(
  { "API_HOST" => api_host, "API_PORT" => api_port.to_s },
  "node",
  File.join(root, "app", "server.mjs"),
  out: File::NULL,
  err: File::NULL,
)
gateway_pid = nil
capture_pid = nil

begin
  wait_for(api_host, api_port)
  gateway_pid = spawn(
    { "SSL_HOST" => ssl_host, "SSL_PORT" => ssl_port.to_s, "API_HOST" => api_host, "API_PORT" => api_port.to_s },
    "ruby",
    File.join(root, "ruby", "gateway.rb"),
    out: File::NULL,
    err: File::NULL,
  )
  wait_for(ssl_host, ssl_port)
  initializer = Initializer.new(VoteMe::Client.new(host: ssl_host, port: ssl_port))
  used = initializer.seed
  FileUtils.mkdir_p(File.dirname(output))
  File.delete(output) if File.exist?(output)
  capture_pid = spawn(
    "tcpdump", "-i", "lo", "-U", "-s", "0", "-B", "16384", "-w", output, "tcp", "port", ssl_port.to_s,
    out: File::NULL,
    err: File::NULL,
  )
  sleep 0.5
  initializer.populate(1000 - used)
  result = initializer.finish
  raise "incomplete" unless result.fetch("votes").length == 1000
  sleep 3
ensure
  if capture_pid
    Process.kill("INT", capture_pid)
    Process.wait(capture_pid)
  end
  if gateway_pid
    Process.kill("TERM", gateway_pid)
    Process.wait(gateway_pid)
  end
  Process.kill("TERM", api_pid)
  Process.wait(api_pid)
end

expected = (1000 - used) * 3 + 1
raise "incomplete capture" unless connection_count(output, ssl_port) == expected

puts output
