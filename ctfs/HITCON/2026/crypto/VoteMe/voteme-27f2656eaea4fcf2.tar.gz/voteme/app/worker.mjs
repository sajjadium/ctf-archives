import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { TextDecoder, TextEncoder } from "node:util";
import vm from "node:vm";

const ROOT = dirname(fileURLToPath(import.meta.url));
const BUILD = join(ROOT, "..", "build");
const WASM = join(BUILD, "vote_js", "vote.wasm");
const ZKEY = join(BUILD, "vote_plonk.zkey");
const ELECTION_ID = "1337";
const SNARKJS_BUNDLE = join(
  dirname(fileURLToPath(import.meta.resolve("snarkjs"))),
  "build",
  "snarkjs.js",
);
const RECEIPT_MODULE = fileURLToPath(import.meta.resolve("@lukeed/uuid"));

function requireArtifacts() {
  for (const file of [WASM, ZKEY, SNARKJS_BUNDLE, RECEIPT_MODULE]) {
    if (!existsSync(file)) throw new Error(`missing artifact: ${file}`);
  }
}

function encodeBase64(value) {
  return Buffer.from(value, "binary").toString("base64");
}

async function createJob() {
  const realm = vm.createContext({
    btoa: encodeBase64,
    clearTimeout,
    console,
    setTimeout,
    TextDecoder,
    TextEncoder,
  });

  new vm.Script(readFileSync(SNARKJS_BUNDLE, "utf8"), {
    filename: "snarkjs.js",
  }).runInContext(realm);

  const receiptModule = new vm.SourceTextModule(
    readFileSync(RECEIPT_MODULE, "utf8"),
    { context: realm, identifier: "@lukeed/uuid" },
  );
  await receiptModule.link(() => {
    throw new Error("unexpected import");
  });
  await receiptModule.evaluate();

  realm.wasmSource = readFileSync(WASM);
  realm.zkeySource = readFileSync(ZKEY);
  vm.runInContext(
    `
      globalThis.wasmBytes = new Uint8Array(wasmSource);
      globalThis.zkeyBytes = new Uint8Array(zkeySource);
      globalThis.witnessFile = { type: "mem" };
    `,
    realm,
  );

  return { realm, createReceiptId: receiptModule.namespace.v4 };
}

export async function castBallot(candidateId) {
  requireArtifacts();
  const { realm, createReceiptId } = await createJob();

  await realm.snarkjs.wtns.calculate(
    { vote: String(candidateId), electionId: ELECTION_ID },
    realm.wasmBytes,
    realm.witnessFile,
  );

  const uuid = createReceiptId();
  const { proof, publicSignals } = await realm.snarkjs.plonk.prove(
    realm.zkeyBytes,
    realm.witnessFile.data,
  );

  return {
    uuid,
    proof,
    public_signals: publicSignals,
  };
}
