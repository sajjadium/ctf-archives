import { writeFileSync } from "node:fs";
import { castBallot } from "./worker.mjs";

const ballot = await castBallot(Number(process.argv[2]));
writeFileSync(1, JSON.stringify(ballot));
