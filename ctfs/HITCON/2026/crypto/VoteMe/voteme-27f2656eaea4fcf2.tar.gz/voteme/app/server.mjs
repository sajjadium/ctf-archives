import http from "node:http";
import { execFile } from "node:child_process";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

const ROOT = dirname(fileURLToPath(import.meta.url));
const PROVER = join(ROOT, "proving-job.mjs");
const HOST = process.env.API_HOST ?? "127.0.0.1";
const PORT = Number(process.env.API_PORT ?? "8787");
const CANDIDATES = [
  { id: 0, name: "Me" },
  { id: 1, name: "Myself" },
  { id: 2, name: "I" },
];
const votes = [];
const execFileAsync = promisify(execFile);

async function prove(candidateId) {
  const { stdout } = await execFileAsync(
    process.execPath,
    ["--no-warnings", "--experimental-vm-modules", PROVER, String(candidateId)],
    { maxBuffer: 8 * 1024 * 1024 },
  );
  return JSON.parse(stdout);
}

async function readJson(request) {
  const chunks = [];
  for await (const chunk of request) chunks.push(chunk);
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function send(response, status, payload, headers = {}) {
  const body = JSON.stringify(payload);
  response.writeHead(status, {
    "content-type": "application/json",
    "content-length": Buffer.byteLength(body),
    connection: "close",
    ...headers,
  });
  response.end(body);
}

const server = http.createServer(async (request, response) => {
  try {
    if (request.method === "GET" && request.url === "/candidates") {
      send(response, 200, { candidates: CANDIDATES });
      return;
    }
    if (request.method === "GET" && request.url === "/status") {
      send(response, 200, { accepted: votes.length });
      return;
    }
    if (request.method === "GET" && request.url === "/votes") {
      send(response, 200, { votes });
      return;
    }
    if (request.method === "POST" && request.url === "/vote") {
      const body = await readJson(request);
      const candidateId = Number(body.candidate_id);
      if (!Number.isInteger(candidateId) || !CANDIDATES.some(({ id }) => id === candidateId)) {
        send(response, 422, { error: "invalid candidate" });
        return;
      }
      const ballot = await prove(candidateId);
      votes.push(ballot);
      send(response, 201, { uuid: ballot.uuid }, { "x-request-id": ballot.uuid });
      return;
    }
    send(response, 404, { error: "not found" });
  } catch {
    send(response, 400, { error: "invalid request" });
  }
});

server.listen(PORT, HOST, () => {
  process.stdout.write(`VoteMe listening on ${HOST}:${PORT}\n`);
});
