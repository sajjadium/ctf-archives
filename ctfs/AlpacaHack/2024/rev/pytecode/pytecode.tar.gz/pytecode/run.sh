#!/bin/sh
# Use this script if you cannot run chall.py in your host machine
docker build . -t pytecode
docker run --rm -it pytecode
