#pragma once

#include <lua.h>

void secureFunction(lua_State *L);