#pragma once

#include "lua.h"

#define COWSAY_LIB_NAME "cowsay"

void loadCowsayLib(lua_State *L);

