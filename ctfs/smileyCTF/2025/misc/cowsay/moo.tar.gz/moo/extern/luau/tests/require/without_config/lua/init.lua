return {"result from init.lua"}
