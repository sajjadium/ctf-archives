export const config = {
    "host": "coolctfgames.localhost",
    "visitPath": "/",
    "port": parseInt(process.env.PORT) || 3000,
}
export default config;