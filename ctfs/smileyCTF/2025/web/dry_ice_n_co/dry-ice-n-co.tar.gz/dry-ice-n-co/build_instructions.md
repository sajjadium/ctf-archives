if your testing on docker run
```sh
./gradlew clean bootJar
```
before you build the docker container.