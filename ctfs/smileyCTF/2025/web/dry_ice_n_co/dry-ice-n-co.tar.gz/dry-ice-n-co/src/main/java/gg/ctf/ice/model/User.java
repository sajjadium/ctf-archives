package gg.ctf.ice.model;

public class User {
    public String username;
    public boolean admin;

    public User(String username, boolean admin) {
        this.username = username;
        this.admin = admin;
    }
} 