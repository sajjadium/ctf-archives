<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Chest" tilewidth="32" tileheight="32" tilecount="6" columns="3">
 <image source="../../chest_png.png" width="105" height="90"/>
</tileset>
