int check() {
  return 0;
}

int main(void) {
  return 0;
}
