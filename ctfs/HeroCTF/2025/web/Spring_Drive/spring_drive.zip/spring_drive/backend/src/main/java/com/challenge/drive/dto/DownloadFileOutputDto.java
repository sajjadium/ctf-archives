package com.challenge.drive.dto;

public record DownloadFileOutputDto(
        String base64
) {
}
