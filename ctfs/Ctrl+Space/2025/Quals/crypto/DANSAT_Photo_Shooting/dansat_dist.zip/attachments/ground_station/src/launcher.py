from app import app
from tc_tm_manager import server_accept_loop
import threading
import gunicorn.app.base

class StandaloneApplication(gunicorn.app.base.BaseApplication):
    def load_config(self):
        self.cfg.set("bind", "0.0.0.0:8080")
        self.cfg.set("workers", 4)

    def load(self):
        return app

if __name__ == "__main__":
    threading.Thread(target=server_accept_loop, daemon=True).start()
    StandaloneApplication().run()
