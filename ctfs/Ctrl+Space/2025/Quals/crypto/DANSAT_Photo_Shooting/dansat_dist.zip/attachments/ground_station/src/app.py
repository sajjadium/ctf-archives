from flask import Flask, render_template, request, jsonify, abort, send_file
from io import BytesIO
from datetime import datetime
from tc_tm_manager import send_tc_packet, send_raw_data
import struct
from pymongo import MongoClient

app = Flask(__name__)

client = MongoClient("mongodb://127.0.0.1:27017/")
db = client.spacecraft
tms_collection = db.telemetry

# APID definitions
TC_APID_MAP = {
    1: 'Shoot a photo',
    2: 'Thruster status',
    3: 'Aoc status',
    4: 'Get flag!',
}

TM_APID_MAP = {
    0x04: "PHOTO DATA",
    0x05: "THRUSTER STATUS",
    0x06: "AOC DATA",
    0x07: "FLAG",
    0x08: "FILE DATA"
}


def format_hex_ascii(data: bytes, width=16, max_lines=8):
    """Return list of hexdump lines with fixed 16 hex slots (truncated)."""
    lines = []
    for i in range(0, len(data), width):
        if len(lines) >= max_lines:
            lines.append("... (truncated)")
            break
        chunk = data[i:i+width]

        hex_cols = [f"{b:02X}" for b in chunk]
        # pad missing slots with blanks
        hex_cols += ["  "] * (width - len(chunk))
        hex_part = " ".join(hex_cols)

        ascii_part = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)

        lines.append(f"{hex_part}  {ascii_part}")

    return lines


@app.route('/api/debug', methods=['POST'])
def debug():
    data = request.get_json()
    data_bytes = bytes.fromhex(data['data_bytes'])

    try:
        pkt = send_raw_data(data_bytes)
        return jsonify({
            'success': True,
            'message': 'Packet sent successfully',
            'packet_info': pkt.hex()
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route("/telemetry")
def telemetry():
    # get last 200 packets, newest first
    cursor = (
        tms_collection
        .find({}, {"_id": 0})
        .sort("idx", -1)
        .limit(200)
    )

    packets = []
    for p in cursor:
        packets.append({
            **p,
            "apid_name": TM_APID_MAP.get(p["apid"], "UNKNOWN"),
            # limit to first 8 lines
            "hex_view": format_hex_ascii(bytes(p["data"]))[:8],
            "timestamp": datetime.fromtimestamp(p["timestamp"]).strftime('%Y-%m-%d %H:%M:%S')
        })

    return render_template("telemetry.html", packets=packets)


@app.route("/download/<int:packet_id>")
def download_packet(packet_id):
    # find packet by idx in Mongo
    packet = tms_collection.find_one({"idx": packet_id}, {"_id": 0})
    if packet is None:
        abort(404)

    if isinstance(packet["data"], str):
        data = bytes.fromhex(packet["data"])
    else:
        data = packet["data"]

    return send_file(
        BytesIO(data),
        as_attachment=True,
        download_name=f"packet_{packet_id}.bin",
        mimetype="application/octet-stream"
    )


def get_spacecraft_status():
    packets = list(tms_collection.find({}, {"_id": 0}))

    thruster_packets = [p for p in packets if p.get("apid") == 5]
    if thruster_packets:
        latest_thruster = max(
            thruster_packets, key=lambda p: p.get("timestamp", 0))
        thrusters_status = {
            'status': latest_thruster['data'][0],
            'last_data': datetime.fromtimestamp(
                latest_thruster['timestamp']
            ).strftime('%Y-%m-%d %H:%M:%S')
        }
    else:
        thrusters_status = {
            'status': '0',
            'last_data': '-'
        }

    aoc_packets = [p for p in packets if p.get("apid") == 6]
    if aoc_packets:
        latest_aoc = max(aoc_packets, key=lambda p: p.get("timestamp", 0))
        q0, q1, q2, q3 = struct.unpack(
            "<dddd", latest_aoc['data'][:32]
        )
        aoc_status = {
            'status': 'ACTIVE',
            'orientation': {"q0": q0, "q1": q1, "q2": q2, "q3": q3},
            'last_data': datetime.fromtimestamp(
                latest_aoc['timestamp']
            ).strftime('%Y-%m-%d %H:%M:%S')
        }
    else:
        aoc_status = {
            'status': 'ACTIVE',
            'orientation': {
                'q0': 0.172584, 'q1': 0.802361,
                'q2': 0.354249, 'q3': -0.448173
            },
            'last_data': '-'
        }

    photo_packets = [p for p in packets if p.get("apid") == 4]
    if photo_packets:
        latest_photo = max(photo_packets, key=lambda p: p.get("timestamp", 0))
        last_photo = {
            'timestamp': datetime.fromtimestamp(
                latest_photo['timestamp']
            ).strftime('%Y-%m-%d %H:%M:%S'),
            'id': latest_photo['idx']
        }
    else:
        last_photo = {}

    # Final status
    spacecraft_status = {
        'thrusters': thrusters_status,
        'aoc': aoc_status,
        'last_photo_shoot': last_photo
    }

    return spacecraft_status


@app.route('/')
def home():
    spacecraft_status = get_spacecraft_status()
    return render_template('home.html', status=spacecraft_status)


@app.route('/send-packet')
def send_packet():
    return render_template('send_packet.html', apids=TC_APID_MAP)


@app.route('/api/send-packet', methods=['POST'])
def api_send_packet():
    data = request.get_json()

    apid = int(data['apid'], 0)

    if apid not in TC_APID_MAP.keys():
        return jsonify({'success': False, 'message': 'Not found'}), 404

    data_bytes = bytes.fromhex(data['data_bytes'])

    pkt = send_tc_packet(apid, data_bytes)

    return jsonify({
        'success': True,
        'message': 'Packet sent successfully',
        'packet_info': pkt.hex()
    })
