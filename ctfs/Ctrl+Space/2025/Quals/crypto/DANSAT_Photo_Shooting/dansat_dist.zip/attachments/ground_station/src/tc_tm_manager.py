import socket
from spacepackets.ccsds.spacepacket import SpHeader, CCSDS_HEADER_LEN, SpacePacketHeader, SequenceFlags
import threading
from pymongo import MongoClient
import struct
import time
import hmac, hashlib
import os

with open("key.bin", "rb") as f:
    KEY = f.read(16)

client = MongoClient("mongodb://127.0.0.1:27017/")
db = client.spacecraft
tms_collection = db.telemetry
tms_collection.create_index([("apid", 1), ("timestamp", -1)])

def recvall(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError(
                f"socket closed (wanted {n}, got {len(buf)})"
            )
        buf.extend(chunk)
    return bytes(buf)

def get_next_seq(name):
    result = db.counters.find_one_and_update(
        {"_id": name},
        {"$inc": {"seq": 1}},
        upsert=True,
        return_document=True
    )
    return result["seq"]

def save_tm_packet(timestamp, apid, rowdata):
    idx = get_next_seq("telemetry_idx")
    doc = {
        "idx": idx,
        "timestamp": timestamp,
        "apid": apid,
        "data": rowdata,
    }
    tms_collection.insert_one(doc)

def send_raw_data(data):
    print("sneing raw data", data)
    tc_comm = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    port = os.getenv("TC_COM_PORT", "5000")
    tc_comm.connect(("127.0.0.1", int(port)))

    tc_comm.send(struct.pack("<I", len(data)))
    tc_comm.send(data)

    tc_comm.close()

def send_tc_packet(apid, data):
    tm_conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    port = os.getenv("TC_COM_PORT", "5000")
    tm_conn.connect(("127.0.0.1", int(port)))

    data = data + b"AA"

    hdr = SpHeader.tc(apid=apid, seq_count=0, data_len=0)
    hdr.set_data_len_from_packet_len(CCSDS_HEADER_LEN + len(data))
    pkt = hdr.pack()
    pkt.extend(data)
    
    tag = hmac.new(key=KEY, msg=pkt, digestmod=hashlib.sha256)

    pkt = pkt + tag.digest()
    pkt_len = len(pkt)

    tm_conn.send(struct.pack("<I", pkt_len))
    tm_conn.send(pkt)

    tm_conn.close()

    return pkt

def handle_client(conn, addr):
    # Receive 4 bytes for the number of packets
    num_packets = struct.unpack('<I', recvall(conn, 4))[0]

    data_chunks = {}
    for _ in range(num_packets):
        length = struct.unpack('<I', recvall(conn, 4))[0]
        photo_data = recvall(conn, length)

        hdr = SpacePacketHeader.unpack(photo_data[:6])
        apid = hdr.apid

        chunk = photo_data[6:-2]          # strip hdr + CRC
        data_chunks[hdr.seq_count] = chunk

        if hdr.seq_flags == SequenceFlags.LAST_SEGMENT:
            total_chunks = hdr.seq_count + 1

    # Reassemble
    chunk_numbers = sorted(data_chunks.keys())
    full_data = b"".join([data_chunks[i] for i in chunk_numbers])
    save_tm_packet(int(time.time()), apid, full_data)


def server_accept_loop():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        port = os.getenv("GS_TM_PORT", "5000")        
        s.bind(("0.0.0.0", int(port)))
        s.listen()
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr)).start()