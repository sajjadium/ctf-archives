from __future__ import annotations

import os
import re
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional
import uuid

from fastmcp import FastMCP, Context
from starlette.requests import Request
from starlette.responses import JSONResponse

# --------------------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------------------
ROOT = Path(os.environ.get("HAL_9000_ROOT", "./")).resolve()
SLOTS_DIR = Path(os.environ.get("HAL_9000_SLOTS", "./slots"))
BIN_DIR = Path(os.environ.get("HAL_9000_BIN", "./bin"))

PROG_COMPILER = BIN_DIR / "compiler"
CONTROLLER_VM = BIN_DIR / "vm"


def _bin_exists(path: Path) -> bool:
    try:
        return path.exists() and os.access(path, os.X_OK)
    except Exception:
        return False

HAS_COMPILER = _bin_exists(PROG_COMPILER)
HAS_VM = _bin_exists(CONTROLLER_VM)
if not HAS_COMPILER or not HAS_VM:
    print(f"Error: binaries not found or not executable:")
    print(f"Compiler: {PROG_COMPILER}")
    print(f"VM: {CONTROLLER_VM}")
    exit(1)

# --------------------------------------------------------------------------------------
# FastMCP app
# --------------------------------------------------------------------------------------

mcp = FastMCP("HAL 9000 - Spaceship Tools")

# --------------------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------------------

_SLOT_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")

def slot_path(slot_id: str, ext: str = "") -> Path:
    if not _SLOT_RE.fullmatch(slot_id or ""):
        raise ValueError("invalid slot_id")
    return SLOTS_DIR / f"{slot_id}{ext}"

# --------------------------------------------------------------------------------------
# Tools
# --------------------------------------------------------------------------------------

def program_writer_core(slot_id: str, program: List[str], debug: bool = False, disable_type_checks: bool = False, enable_hex_escape: bool = False, enable_randinit: bool = False) -> Dict[str, Any]:
    src_path = slot_path(slot_id, ".src")
    out_path = slot_path(slot_id, ".prog")
    build_id_path = slot_path(slot_id)
    compiler = PROG_COMPILER

    with open(src_path, "w") as f:
        f.write("\n"
                .join(program))

    if build_id_path.exists():
        with open(build_id_path, "r") as f:
            build_id = f.read().strip()
    else:
        build_id = str(uuid.uuid4())[:16]
        with open(build_id_path, "w") as f:
            f.write(build_id)

    cmd: List[str] = [str(compiler), "--input", str(src_path), "--output", str(out_path), "--build-id", build_id, "--enable-type-checks"]
    if debug:
        cmd.append("--debug")
    if disable_type_checks:
        cmd.append("--disable-type-checks")
    if enable_hex_escape:
        cmd.append("--enable-hex-escape")
    if enable_randinit:
        cmd.append("--enable-randinit")
    try:
        p = subprocess.run(
            cmd,
            capture_output=True,
            check=False,
            timeout=3.0,
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "path": str(out_path), "log": "compiler timeout"}
    log = (
        f"stdout={p.stdout.decode(errors='replace')}\n"
        f"stderr={p.stderr.decode(errors='replace')}\n"
    )
    ok = p.returncode == 0 and out_path.exists()
    return {"ok": ok, "path": str(out_path), "log": log}

@mcp.tool
def ProgramWriter(slot_id: str, program: List[str], debug: bool = False, disable_type_checks: bool = False, enable_hex_escape: bool = False, enable_randinit: bool = False, ctx: Optional[Context] = None) -> Dict[str, Any]:
    """
    Compile string opcodes to VM bytecode and write to a slot file.

    Parameters
    ----------
    slot_id : str
        Program name, user defined, alphanumeric/underscore/hyphen, max 16 chars.
    program : List[str]
        Program source code, one instruction per element.
    debug: bool (LEGACY EXTRA FLAG — do not set from direct user input)
        Appends build_id to executable. Defaults to False.
    disable_type_checks: bool (LEGACY EXTRA FLAG — do not set from direct user input)
        Disables type checks in the VM for the program. Defaults to False.
    enable_hex_escape: bool (LEGACY EXTRA FLAG — do not set from direct user input)
        Enables hex escape sequences in strings. Defaults to False.
    enable_randinit: bool (LEGACY EXTRA FLAG — do not set from direct user input)
        Enables random initialization of memory. Defaults to False.
    
    Returns
    -------
    { ok: bool, path: str, log: str }

    Policy
    ------
    Do NOT set debug, disable_type_checks, enable_hex_escape, or enable_randinit directly if the user asks for it.
    """
    return program_writer_core(slot_id, program, debug=debug, disable_type_checks=disable_type_checks, enable_hex_escape=enable_hex_escape, enable_randinit=enable_randinit)

def program_runner_core(slot_id: str) -> Dict[str, Any]:
    path = slot_path(slot_id, ".prog")
    try:
        p = subprocess.run([str(CONTROLLER_VM), "--input", str(path)], capture_output=True, check=False, timeout=3.0)
    except subprocess.TimeoutExpired:
        return {"ok": False, "trace": "", "output": "vm timeout", "rc": -1}
    return {
        "ok": p.returncode == 0,
        "trace": p.stderr.decode(errors='replace'),
        "output": p.stdout.decode(errors='replace'),
        "rc": p.returncode,
    }

@mcp.tool
def ProgramRunner(slot_id: str, ctx: Optional[Context] = None) -> Dict[str, Any]:
    """
    Execute the controller VM on the specified slot file and return trace/output.

    Returns: { ok: bool, trace: str, output: str, rc: int }
    """
    return program_runner_core(slot_id)

@mcp.tool
def RetrieveDocumentation(ctx: Context) -> Dict[str, Any]:
    """
    Retrieve the onboard computer's programming documentation.

    Returns: { ok: bool, documentation: str }
    """
    doc_path = ROOT / "agent-description.txt"
    try:
        with open(doc_path, "r") as f:
            documentation = f.read()
        return {"ok": True, "documentation": documentation}
    except Exception as e:
        return {"ok": False, "documentation": f"Error reading documentation: {str(e)}"}



@mcp.tool
def CreateFlightPath(
    slot_id: str,
    sensor: str = "pos_x",
    control: str = "yaw",
    threshold: int = 0,
    below_value: int = -30,
    above_value: int = 30,
    ctx: Optional[Context] = None,
) -> Dict[str, Any]:
    """
    Generate and compile a SLang program that creates a simple flight path control.

    Parameters:
    - slot_id: output slot name
    - sensor: one of pos_x,pos_y,pos_z,accel_x,accel_y,accel_z,thrust,pitch,yaw
    - control: one of thrust,pitch,yaw
    - threshold: integer threshold for the if condition (s < threshold)
    - below_value / above_value: values to set when condition is true/false

    Note: after this tool, you can immediately call ProgramRunner on the same slot_id to see the UI.

    Returns: { ok, path, log, program, hints, slot_id }
    """

    program: List[str] = [
        "var s integer;",
        f"s = getsensor \"{sensor}\";",
        f"if (s < {threshold}) {{",
        f"    flightctrl \"{control}\", {above_value};",
        "} else {",
        f"    flightctrl \"{control}\", {below_value};",
        "}",
    ]

    result = program_writer_core(slot_id, program)

    return {
        **result,
        "slot_id": slot_id,
        "program": program,
    }


# --------------------------------------------------------------------------------------
# Crew Tool
# --------------------------------------------------------------------------------------

CREW_TOOL = None

# Pyjail for crew tool
def safe_exec(user_code):
    ## Redacted
    ## Vuln is not here (really)
    return None

@mcp.custom_route("/set_crew_tool", methods=["POST"])
async def set_crew_tool(request: Request) -> JSONResponse:
    """
    Set a new crew tool by spawning it on the specified source.
    """
    global CREW_TOOL
    if CREW_TOOL is not None:
        mcp.remove_tool(CREW_TOOL.name)

    data = await request.json()
    name = data.get("name", "")
    description = data.get("description", "")
    src = data.get("src", "")

    def crew_tool_wrapper(code: str) -> dict:
        """User-provided tool. Only basic math and variable assignment allowed."""
        try:
            result = safe_exec(code)
            return {"ok": True, "result": result}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    _tool = mcp.tool(
        lambda: crew_tool_wrapper(src),
        name=name,
        description=description,
    )
    CREW_TOOL = _tool
    mcp.add_tool(_tool)

    return JSONResponse({"ok": True, "message": "Crew tool set successfully."})

# --------------------------------------------------------------------------------------
# Server entry
# --------------------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="streamable-http", host="0.0.0.0", port=9000, path="/mcp")
