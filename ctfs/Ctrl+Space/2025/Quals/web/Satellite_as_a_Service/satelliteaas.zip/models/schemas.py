from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum

class SatelliteStatus(str, Enum):
    ACTIVE = "ACTIVE"
    MAINTENANCE = "MAINTENANCE"
    OFFLINE = "OFFLINE"
    STANDBY = "STANDBY"

class OrbitType(str, Enum):
    GEO = "GEO"  # Geostationary Orbit
    LEO = "LEO"  # Low Earth Orbit
    MEO = "MEO"  # Medium Earth Orbit
    HEO = "HEO"  # High Earth Orbit

class BaseModel(BaseModel):
    model_config = {'extra': 'allow'} # Allow extra fields by default

class LoginRequest(BaseModel):
    username: str = Field(..., min_length=4, max_length=50)
    password: str = Field(..., min_length=6)

class Token(BaseModel):
    access_token: str
    token_type: str

class UserBase(BaseModel):
    username: str

class User(UserBase):
    satellites: List[int] = []

class UserInDB(UserBase):
    hashed_password: str
    satellites: List[int] = []

class SatelliteBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    status: SatelliteStatus
    orbit: OrbitType

class Satellite(SatelliteBase):
    id: int
    last_contact: str
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    flag: Optional[str] = None  # Sensitive field, only for specific satellites

class SatelliteCreate(SatelliteBase):
    pass

class SatelliteUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=100)
    status: Optional[SatelliteStatus] = None
    orbit: Optional[OrbitType] = None

class SatelliteStatusUpdate(BaseModel):
    status: SatelliteStatus

class DashboardStats(BaseModel):
    total_satellites: int
    active_satellites: int
    maintenance_satellites: int
    offline_satellites: int
    standby_satellites: int
    last_updated: str

class APIResponse(BaseModel):
    message: str
    success: bool = True
    data: Optional[dict] = None

class ErrorResponse(BaseModel):
    detail: str
    error_code: Optional[str] = None
    timestamp: str
