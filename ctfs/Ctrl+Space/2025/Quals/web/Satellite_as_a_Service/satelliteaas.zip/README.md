# 🛰️ Satellite Dashboard - Project Structure

## Overview
This is a secure satellite management system built with FastAPI, featuring JWT authentication, role-based access control, and a modern web interface.

## 👥 Demo Accounts
- **operator1** / operator123 (3 satellites)  
- **operator2** / operator456 (2 satellites)
- **operator3** / operator789 (3 satellite)

## 🚀 Getting Started
### Local Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Run the application: `python src/main.py`
3. Open browser: `http://localhost:8000`
4. Login with demo accounts

### 🐳 Docker 
- Build: `docker compose up --build`
- Access: `http://localhost:8000`
