from typing import Dict, List, Optional
from datetime import datetime
from passlib.context import CryptContext
from models.schemas import UserInDB, Satellite, SatelliteStatus, OrbitType

from utils import admin_password
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class Database:
    def __init__(self):
        self.users: Dict[str, UserInDB] = {}
        self.satellites: Dict[int, Satellite] = {}
        self.next_satellite_id = 1
        self._inizialize_data()
    
    def _inizialize_data(self):
        """Initialize the database with users and satellites"""
        # Users
        self.users = {
            "operator1": UserInDB(
                username="operator1",
                user_id=1,
                hashed_password=pwd_context.hash("operator123"),
                satellites=[1, 2, 3]
            ),
            "operator2": UserInDB(
                username="operator2",
                user_id=2,
                hashed_password=pwd_context.hash("operator456"),
                satellites=[4, 5]
            ),
            "operator3": UserInDB(
                username="operator3",
                user_id=3,
                hashed_password=pwd_context.hash("operator789"),
                satellites=[6, 7, 8]
            ),
            "admin": UserInDB(
                username="admin",
                user_id=99,
                hashed_password=pwd_context.hash(admin_password),
                satellites=[1,2,3,4,5,6,7,8,9]
            )
        }
        
        # Satellites
        now = datetime.utcnow().isoformat() + "Z"
        self.satellites = {
            1: Satellite(
                id=1,
                name="SAT-COMM-01",
                status=SatelliteStatus.ACTIVE,
                orbit=OrbitType.GEO,
                last_contact="2025-09-07T10:30:00Z",
                created_at=now,
                updated_at=now
            ),
            2: Satellite(
                id=2,
                name="SAT-OBS-02",
                status=SatelliteStatus.MAINTENANCE,
                orbit=OrbitType.LEO,
                last_contact="2025-09-07T08:15:00Z",
                created_at=now,
                updated_at=now
            ),
            3: Satellite(
                id=3,
                name="SAT-NAV-03",
                status=SatelliteStatus.ACTIVE,
                orbit=OrbitType.MEO,
                last_contact="2025-09-07T11:45:00Z",
                created_at=now,
                updated_at=now
            ),
            4: Satellite(
                id=4,
                name="SAT-WEATHER-04",
                status=SatelliteStatus.ACTIVE,
                orbit=OrbitType.LEO,
                last_contact="2025-09-07T12:00:00Z",
                created_at=now,
                updated_at=now
            ),
            5: Satellite(
                id=5,
                name="SAT-RESEARCH-05",
                status=SatelliteStatus.OFFLINE,
                orbit=OrbitType.LEO,
                last_contact="2025-09-06T14:30:00Z",
                created_at=now,
                updated_at=now
            ),
            6: Satellite(
                id=6,
                name="SAT-MILITARY-06",
                status=SatelliteStatus.ACTIVE,
                orbit=OrbitType.GEO,
                last_contact="2025-09-07T11:20:00Z",
                created_at=now,
                updated_at=now
            ),
            7: Satellite(
                id=7,
                name="SAT-SCIENCE-07",
                status=SatelliteStatus.ACTIVE,
                orbit=OrbitType.LEO,
                last_contact="2025-09-07T10:50:00Z",
                created_at=now,
                updated_at=now
            ),
            8: Satellite(
                id=8,
                name="SAT-BACKUP-08",
                status=SatelliteStatus.STANDBY,
                orbit=OrbitType.GEO,
                last_contact="2025-09-07T09:30:00Z",
                created_at=now,
                updated_at=now
            ),
            9: Satellite(
                id=9,
                name="SAT-FLAG-1337",
                status=SatelliteStatus.OFFLINE,
                orbit=OrbitType.GEO,
                last_contact="2025-09-07T09:30:00Z",
                created_at=now,
                updated_at=now,
                flag="ctrlspace{idkwhatflagwillthisbe!}"
            )
        }
        self.next_satellite_id = 10
    
    # User operations
    def get_user(self, username: str) -> Optional[UserInDB]:
        return self.users.get(username)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        return pwd_context.verify(plain_password, hashed_password)
    
    # Satellite operations
    def get_satellite(self, satellite_id: int) -> Optional[Satellite]:
        return self.satellites.get(satellite_id)
    
    def get_user_satellites(self, user: UserInDB) -> List[Satellite]:
        return [self.satellites[sat_id] for sat_id in user.satellites if sat_id in self.satellites]
    
    def update_satellite_status(self, satellite_id: int, status: SatelliteStatus) -> bool:
        if satellite_id in self.satellites:
            self.satellites[satellite_id].status = status
            self.satellites[satellite_id].last_contact = datetime.utcnow().isoformat() + "Z"
            self.satellites[satellite_id].updated_at = datetime.utcnow().isoformat() + "Z"
            return True
        return False
    
    def user_owns_satellite(self, user: UserInDB, satellite_id: int) -> bool:
        return satellite_id in user.satellites
    
    def get_dashboard_stats(self, user: UserInDB) -> dict:
        user_satellites = self.get_user_satellites(user)
        stats = {
            "total_satellites": len(user_satellites),
            "active_satellites": len([s for s in user_satellites if s.status == SatelliteStatus.ACTIVE]),
            "maintenance_satellites": len([s for s in user_satellites if s.status == SatelliteStatus.MAINTENANCE]),
            "offline_satellites": len([s for s in user_satellites if s.status == SatelliteStatus.OFFLINE]),
            "standby_satellites": len([s for s in user_satellites if s.status == SatelliteStatus.STANDBY]),
            "last_updated": datetime.utcnow().isoformat() + "Z"
        }
        return stats

# Global database instance
db = Database()
