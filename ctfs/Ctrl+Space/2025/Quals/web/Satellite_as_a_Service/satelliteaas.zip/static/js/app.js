// Global variables
let authToken = localStorage.getItem('authToken');
let currentUser = null;
let refreshInterval = null;

// Check if token is expired by parsing JWT
function isTokenExpired(token) {
    if (!token) return true;
    
    try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const currentTime = Math.floor(Date.now() / 1000);
        return payload.exp < currentTime;
    } catch (error) {
        console.error('Error parsing token:', error);
        return true;
    }
}

// Handle authentication errors (401 responses)
function handleAuthError(response) {
    if (response.status === 401) {
        console.log('Authentication failed - token expired or invalid');
        logout();
        return true;
    }
    return false;
}

// Check token validity before making requests
function checkTokenBeforeRequest() {
    if (!authToken || isTokenExpired(authToken)) {
        console.log('Token is expired or invalid, logging out');
        logout();
        return false;
    }
    return true;
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    if (authToken && !isTokenExpired(authToken)) {
        loadDashboard();
    } else if (authToken) {
        // Token exists but is expired
        console.log('Stored token is expired, clearing');
        logout();
    }
    
    // Set up auto-refresh every 30 seconds
    refreshInterval = setInterval(() => {
        if (authToken && isDashboardVisible() && !isTokenExpired(authToken)) {
            refreshData();
        } else if (authToken && isTokenExpired(authToken)) {
            console.log('Token expired during auto-refresh, logging out');
            logout();
        }
    }, 30000);
});

// Authentication functions
async function login(event) {
    event.preventDefault();
    
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    
    if (!username || !password) {
        showError('Please enter both username and password');
        return;
    }
    
    showLoading(true);
    clearError();
    
    try {
        const response = await fetch('/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        if (response.ok) {
            const data = await response.json();
            localStorage.setItem('authToken', data.access_token);
            authToken = data.access_token;
            clearLoginForm();
            await loadDashboard();
        } else {
            const error = await response.json();
            showError(error.detail || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('Network error. Please try again.');
    } finally {
        showLoading(false);
    }
}

async function logout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    
    // Clear dashboard data
    document.getElementById('satellitesList').innerHTML = '';
    document.getElementById('statsContainer').innerHTML = '';
    
    // Show login form
    showSection('loginSection');
    clearError();
}

function setCredentials(username, password) {
    document.getElementById('username').value = username;
    document.getElementById('password').value = password;
}

// Dashboard functions
async function loadDashboard() {
    if (!checkTokenBeforeRequest()) {
        return;
    }

    showLoading(true);
    
    try {
        const [userResponse, satellitesResponse, statsResponse] = await Promise.all([
            fetch('/auth/me', {
                headers: { 'Authorization': `Bearer ${authToken}` }
            }),
            fetch('/satellites', {
                headers: { 'Authorization': `Bearer ${authToken}` }
            }),
            fetch('/dashboard/stats', {
                headers: { 'Authorization': `Bearer ${authToken}` }
            })
        ]);

        // Check for authentication errors
        if (handleAuthError(userResponse) || handleAuthError(satellitesResponse) || handleAuthError(statsResponse)) {
            return;
        }

        if (userResponse.ok && satellitesResponse.ok) {
            currentUser = await userResponse.json();
            const satellites = await satellitesResponse.json();
            const stats = statsResponse.ok ? await statsResponse.json() : null;
            
            showSection('dashboardSection');
            updateWelcomeMessage(currentUser);
            displaySatellites(satellites);
            if (stats) displayStats(stats);
            updateLastUpdate();
        } else {
            console.error('Failed to load dashboard data');
            logout();
        }
    } catch (error) {
        console.error('Dashboard loading error:', error);
        logout();
    } finally {
        showLoading(false);
    }
}

async function refreshData() {
    if (!checkTokenBeforeRequest()) {
        return;
    }
    
    try {
        const [satellitesResponse, statsResponse] = await Promise.all([
            fetch('/satellites', {
                headers: { 'Authorization': `Bearer ${authToken}` }
            }),
            fetch('/dashboard/stats', {
                headers: { 'Authorization': `Bearer ${authToken}` }
            })
        ]);

        // Check for authentication errors
        if (handleAuthError(satellitesResponse) || handleAuthError(statsResponse)) {
            return;
        }

        if (satellitesResponse.ok) {
            const satellites = await satellitesResponse.json();
            displaySatellites(satellites);
        }
        
        if (statsResponse.ok) {
            const stats = await statsResponse.json();
            displayStats(stats);
        }
        
        updateLastUpdate();
    } catch (error) {
        console.error('Refresh error:', error);
        // Don't auto-logout on network errors during refresh
        // Only logout on authentication errors
    }
}

// Display functions
function displaySatellites(satellites) {
    const container = document.getElementById('satellitesList');
    
    if (!satellites || satellites.length === 0) {
        container.innerHTML = `
            <div class="no-satellites">
                <h3>No satellites assigned</h3>
                <p>Contact your administrator to get satellite access.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = satellites.map(satellite => `
        <div class="satellite-card status-${satellite.status.toLowerCase()}">
            <div class="satellite-header">
                <h3 class="satellite-name">${escapeHtml(satellite.name)}</h3>
                <span class="status-badge ${satellite.status.toLowerCase()}">${satellite.status}</span>
            </div>
            
            <div class="satellite-info">
                <div class="info-item">
                    <span class="info-label">Orbit</span>
                    <span class="info-value">${satellite.orbit}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Satellite ID</span>
                    <span class="info-value">#${satellite.id}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Last Contact</span>
                    <span class="info-value">${formatDateTime(satellite.last_contact)}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Contact Status</span>
                    <span class="info-value ${getContactStatusClass(satellite.last_contact)}">
                        ${getContactStatus(satellite.last_contact)}
                    </span>
                </div>
            </div>
            
            <div class="satellite-actions">
                <button onclick="viewSatelliteDetails(${satellite.id})" class="btn btn-outline btn-sm">
                    Details
                </button>
                <button onclick="updateSatelliteStatus(${satellite.id})" class="btn btn-primary btn-sm">
                    Update Status
                </button>
            </div>
        </div>
    `).join('');
}

function displayStats(stats) {
    const container = document.getElementById('statsContainer');

    container.innerHTML = `
        <div class="stat-card">
            <div class="stat-number stat-total">${stats.total_satellites}</div>
            <div class="stat-label">Total Satellites</div>
        </div>
        <div class="stat-card">
            <div class="stat-number stat-active">${stats.active_satellites}</div>
            <div class="stat-label">Active</div>
        </div>
        <div class="stat-card">
            <div class="stat-number stat-maintenance">${stats.maintenance_satellites}</div>
            <div class="stat-label">Maintenance</div>
        </div>
        <div class="stat-card">
            <div class="stat-number stat-offline">${stats.offline_satellites}</div>
            <div class="stat-label">Offline</div>
        </div>
        <div class="stat-card">
            <div class="stat-number stat-standby">${stats.standby_satellites}</div>
            <div class="stat-label">Standby</div>
        </div>
    `;
}

// Satellite management functions
async function viewSatelliteDetails(satelliteId) {
    if (!checkTokenBeforeRequest()) {
        return;
    }
    
    try {
        const response = await fetch(`/satellites/${satelliteId}`, {
            headers: { 'Authorization': `Bearer ${authToken}` }
        });
        
        if (handleAuthError(response)) {
            return;
        }
        
        if (response.ok) {
            const satellite = await response.json();
            showSatelliteModal(satellite);
        } else {
            showError('Failed to load satellite details');
        }
    } catch (error) {
        console.error('Error loading satellite details:', error);
        showError('Network error loading satellite details');
    }
}

async function updateSatelliteStatus(satelliteId) {
    if (!checkTokenBeforeRequest()) {
        return;
    }
    
    const statuses = ['ACTIVE', 'MAINTENANCE', 'OFFLINE', 'STANDBY'];
    const currentStatus = getCurrentSatelliteStatus(satelliteId);
    
    const newStatus = prompt(
        `Current status: ${currentStatus}\n\nEnter new status (${statuses.join(', ')}):`,
        currentStatus
    );
    
    if (!newStatus || !statuses.includes(newStatus.toUpperCase())) {
        return;
    }
    
    try {
        const response = await fetch(`/satellites/${satelliteId}/status`, {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${authToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ status: newStatus.toUpperCase() })
        });
        
        if (handleAuthError(response)) {
            return;
        }
        
        if (response.ok) {
            await refreshData();
            showSuccess(`Satellite status updated to ${newStatus.toUpperCase()}`);
        } else {
            const error = await response.json();
            showError(error.detail || 'Failed to update satellite status');
        }
    } catch (error) {
        console.error('Error updating satellite status:', error);
        showError('Network error updating satellite status');
    }
}

// Utility functions
function showSection(sectionId) {
    const sections = ['loginSection', 'dashboardSection'];
    sections.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.style.display = id === sectionId ? 'block' : 'none';
        }
    });
}

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = show ? 'flex' : 'none';
    }
}

function showError(message) {
    const errorElement = document.getElementById('loginError');
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
}

function clearError() {
    const errorElement = document.getElementById('loginError');
    if (errorElement) {
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
}

function showSuccess(message) {
    // Create a temporary success message
    const successDiv = document.createElement('div');
    successDiv.className = 'success-message';
    successDiv.textContent = message;
    successDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #d4edda;
        color: #155724;
        padding: 15px 20px;
        border-radius: 8px;
        border: 1px solid #c3e6cb;
        z-index: 10000;
        animation: slideInRight 0.3s ease;
    `;
    
    document.body.appendChild(successDiv);
    
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

function clearLoginForm() {
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
}

function updateWelcomeMessage(user) {
    const element = document.getElementById('welcomeMessage');
    if (element) {
        element.textContent = `Welcome, ${user.username}`;
    }
}

function updateLastUpdate() {
    const element = document.getElementById('lastUpdate');
    if (element) {
        element.textContent = `Last updated: ${new Date().toLocaleTimeString()}`;
    }
}

function isDashboardVisible() {
    const dashboard = document.getElementById('dashboardSection');
    return dashboard && dashboard.style.display !== 'none';
}

function formatDateTime(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch (error) {
        return dateString;
    }
}

function getContactStatus(lastContact) {
    try {
        const lastContactTime = new Date(lastContact);
        const now = new Date();
        const diffMinutes = (now - lastContactTime) / (1000 * 60);
        
        if (diffMinutes < 30) return 'Recent';
        if (diffMinutes < 120) return 'Normal';
        if (diffMinutes < 1440) return 'Delayed';
        return 'Lost Contact';
    } catch (error) {
        return 'Unknown';
    }
}

function getContactStatusClass(lastContact) {
    const status = getContactStatus(lastContact);
    switch (status) {
        case 'Recent': return 'stat-active';
        case 'Normal': return 'stat-standby';
        case 'Delayed': return 'stat-maintenance';
        case 'Lost Contact': return 'stat-offline';
        default: return '';
    }
}

function getCurrentSatelliteStatus(satelliteId) {
    const card = document.querySelector(`[onclick*="${satelliteId}"]`)?.closest('.satellite-card');
    if (card) {
        const badge = card.querySelector('.status-badge');
        return badge ? badge.textContent.trim() : 'UNKNOWN';
    }
    return 'UNKNOWN';
}

function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, function(m) { return map[m]; });
}

function showSatelliteModal(satellite) {
    // Simple modal implementation
    const modal = document.createElement('div');
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
    `;
    
    modal.innerHTML = `
        <div style="background: white; padding: 30px; border-radius: 12px; max-width: 500px; width: 90%;">
            <h2>🛰️ ${escapeHtml(satellite.name)}</h2>
            <div style="margin: 20px 0;">
                <p><strong>ID:</strong> ${satellite.id}</p>
                <p><strong>Status:</strong> <span class="status-badge ${satellite.status.toLowerCase()}">${satellite.status}</span></p>
                <p><strong>Orbit:</strong> ${satellite.orbit}</p>
                <p><strong>Owner ID:</strong> ${satellite.owner_id}</p>
                <p><strong>Last Contact:</strong> ${formatDateTime(satellite.last_contact)}</p>
                <p><strong>Contact Status:</strong> ${getContactStatus(satellite.last_contact)}</p>
                ${satellite.created_at ? `<p><strong>Created:</strong> ${formatDateTime(satellite.created_at)}</p>` : ''}
                ${satellite.updated_at ? `<p><strong>Updated:</strong> ${formatDateTime(satellite.updated_at)}</p>` : ''}
            </div>
            <button onclick="this.parentElement.parentElement.remove()" class="btn btn-primary">Close</button>
        </div>
    `;
    
    modal.onclick = (e) => {
        if (e.target === modal) modal.remove();
    };
    
    document.body.appendChild(modal);
}

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .no-satellites {
        text-align: center;
        padding: 60px 20px;
        color: #666;
        grid-column: 1 / -1;
    }
    
    .no-satellites h3 {
        margin-bottom: 10px;
        color: #333;
    }
`;
document.head.appendChild(style);
