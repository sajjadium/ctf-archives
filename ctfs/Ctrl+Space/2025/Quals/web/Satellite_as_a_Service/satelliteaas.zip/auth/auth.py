from datetime import datetime, timedelta
from typing import Optional
from fastapi import HTTPException, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
import secrets
import json
import pdb
from models.schemas import UserBase, UserInDB
from database.db import db

# JWT Configuration
SECRET_KEY = secrets.token_urlsafe(32)
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

security = HTTPBearer()

def safe_dict_to_obj(d):
    obj = UserBase(username='')
    for k, v in d.items():
        if k.isidentifier(): 
            setattr(obj, k, v)
    return obj

def authenticate_user(username: str, password: str) -> Optional[UserInDB]:
    """Authenticate a user with username and password"""
    user = db.get_user(username)
    if not user or not db.verify_password(password, user.hashed_password):
        return None
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})

    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> UserInDB:
    """Get the current authenticated user from JWT token"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        token = credentials.credentials

        data = safe_dict_to_obj(jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM]))
        # double safe
        data = {k: v for k, v in data if k.isidentifier() and not k.startswith("__")}

        username: str = data['username']
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    
    user = db.get_user(username)
    if user is None:
        raise credentials_exception
    
    return user

def verify_satellite_access(user: UserInDB, satellite_id: int) -> bool:
    """Verify if a user has access to a specific satellite"""
    return db.user_owns_satellite(user, satellite_id)

def require_satellite_access(user: UserInDB, satellite_id: int):
    """Raise an exception if user doesn't have access to satellite"""
    if not verify_satellite_access(user, satellite_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this satellite"
        )
