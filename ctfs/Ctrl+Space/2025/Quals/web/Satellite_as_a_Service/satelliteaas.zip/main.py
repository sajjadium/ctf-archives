#!/usr/bin/env python

from fastapi import FastAPI, status, HTTPException, Depends, Request
from fastapi.responses import RedirectResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from datetime import datetime, timedelta
from typing import List

import logging
import uvicorn
import os

from models.schemas import (
    LoginRequest, Token, User, Satellite, SatelliteStatusUpdate,
    DashboardStats, APIResponse
)

from database.db import db
from auth.auth import (
    authenticate_user, create_access_token, get_current_user,
    require_satellite_access, ACCESS_TOKEN_EXPIRE_MINUTES
)

logging.getLogger().setLevel(10)
app = FastAPI(
    title="Satellite-as-a-Service API", 
    description="Secure satellite management system",
    version="1.0.0"
)

# Get the directory containing this script (src directory)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Mount static files
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

# Setup templates
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))

# API Endpoints
@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.post("/auth/login", response_model=Token)
async def login(login_request: LoginRequest):
    
    req = {k: v for k, v in login_request}
    user = authenticate_user(req["username"], req["password"])
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    req.pop("password")

    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data=req, expires_delta=access_token_expires
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/auth/me", response_model=User)
async def read_users_me(current_user: dict = Depends(get_current_user)):
    return User(
        username=current_user.username,
        user_id=current_user.user_id,
        satellites=current_user.satellites
    )

@app.get("/satellites", response_model=List[Satellite])
async def get_user_satellites_endpoint(current_user: dict = Depends(get_current_user)):
    return db.get_user_satellites(current_user)

@app.get("/satellites/{satellite_id}", response_model=Satellite)
async def get_satellite(satellite_id: int, current_user: dict = Depends(get_current_user)):
    require_satellite_access(current_user, satellite_id)
    
    satellite = db.get_satellite(satellite_id)
    if not satellite:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Satellite not found")
    
    return satellite

@app.put("/satellites/{satellite_id}/status", response_model=APIResponse)
async def update_satellite_status(
    satellite_id: int, 
    status_update: SatelliteStatusUpdate,
    current_user: dict = Depends(get_current_user)
):
    require_satellite_access(current_user, satellite_id)
    
    satellite = db.get_satellite(satellite_id)
    if not satellite:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Satellite not found")
    
    success = db.update_satellite_status(satellite_id, status_update.status)
    if not success:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to update satellite")
    
    return APIResponse(
        message=f"Satellite {satellite_id} status updated to {status_update.status}",
        success=True,
        data={"satellite_id": satellite_id, "new_status": status_update.status}
    )

@app.get("/dashboard/stats", response_model=DashboardStats)
async def get_dashboard_stats(current_user: dict = Depends(get_current_user)):
    stats = db.get_dashboard_stats(current_user)
    return DashboardStats(**stats)

@app.get("/health")
async def health():
    return {
        "status": "healthy", 
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0"
    }

@app.get("/docs-redirect")
async def docs_redirect():
    return RedirectResponse("/docs", status_code=302)

if __name__ == "__main__":
    uvicorn.run(
        app, 
        host="0.0.0.0", 
        port=8000,
        log_level="info",
        reload=True
    )