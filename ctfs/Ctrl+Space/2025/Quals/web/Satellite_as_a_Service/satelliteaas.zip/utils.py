import os

admin_password = os.getenv("ADMIN_PASSWORD", "admin123")