#!/bin/bash
set -e

mkdir -p /app/data
chown -R 1001:1001 /app/data
chmod 755 /app/data

# Switch to challenge user and execute the command
exec "$@"