# PayloadCalcFinal_v1.0

## Challenge Description
Provola Satellite Corporation recently completed a strategic acquisition of all mission-critical assets from the bankrupt SanTeramo Space Agency (STSA), leveraging synergistic opportunities for operational excellence.
The acquisition included all the necessary infrastructure to continue STSA's space missions, including ground control systems, satellite communication networks, and mission management software platforms.
Unfortunately, our comprehensive technical audit revealed that all the software appears to have been developed in the 1800s by a team of two monkeys operating under a strict high-caffeine diet.
To ensure best-in-class security and drive digital transformation initiatives, we had our newly-hired intern architect an innovative solution to interface with the existing "PLDCLC" payload management system.
The intern assured us that his disruptive prototype delivers 100% security compliance and represents a paradigm shift in his personal software development journey, utilizing cutting-edge vibe-coding methodologies.
We believe this scalable solution will provide robust operational continuity for the next two decades of space missions.

## Challenge Details
There are two executables for this challenge.
- `PayloadCalcFinal`: the intern's prototype application, which interacts with the PLDCLC to manage payloads.
- `PLDCLC`: the legacy payload management system.
The source code for the PayloadCalcFinal executable is given. We don't really expect you to look for vulnerabilities in PayloadCalcFinal. Focus your attention on the PLDCLC executable first.