#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>
#include <fcntl.h>

#define BACKEND_EXECUTABLE "./bin/PLDCLC"
#define MAX_INPUT_LENGTH 1024
#define MAX_COMPONENTS 128

// Function prototypes
void print_main_menu(void);
void print_separator(void);
int get_user_choice(void);
int get_integer_input(const char *prompt, int min_val, int max_val);
long get_long_input(const char *prompt, long min_val, long max_val);
double get_double_input(const char *prompt, double min_val, double max_val);
char *get_string_input(const char *prompt, int max_length);
void safe_string_input(char *buffer, size_t buffer_size);
int execute_backend_command(char command);
int communicate_with_backend(const char *data);
void read_payload_file(void);
void create_payload_file(void);
void update_payload_manifest(void);
void check_payload_exists(void);
void check_manifest_exists(void);
void delete_payload_file(void);
void clear_screen(void);
void wait_for_enter(void);
void read_command_prompt(void);
void read_until_newline(char *buffer, size_t buffer_size);

// Global variables for backend communication
int backend_stdin_fd = -1;
int backend_stdout_fd = -1;
pid_t backend_pid = -1;

void print_separator(void)
{
    printf("========================================\n");
}

void wait_for_enter(void)
{
    printf("\nPress Enter to continue...");
    while (getchar() != '\n')
        ;
}

void print_main_menu(void)
{
    print_separator();
    printf("    MISSION PAYLOAD MANAGEMENT SYSTEM\n");
    print_separator();
    printf("1. Create New Mission Payload\n");
    printf("2. Read Mission Payload Data\n");
    printf("3. Update Payload Manifest\n");
    printf("4. Check Payload File Exists\n");
    printf("5. Check Manifest Exists\n");
    printf("6. Delete Payload File\n");
    printf("7. Exit Program\n");
    print_separator();
}

int get_user_choice(void)
{
    char input[10];
    int choice;

    printf("Enter your choice (1-7): ");
    if (fgets(input, sizeof(input), stdin) == NULL)
    {
        return -1;
    }

    // Remove newline if present
    input[strcspn(input, "\n")] = '\0';

    // Validate input is a single digit
    if (strlen(input) != 1 || !isdigit(input[0]))
    {
        return -1;
    }

    choice = input[0] - '0';
    return (choice >= 1 && choice <= 7) ? choice : -1;
}

int get_integer_input(const char *prompt, int min_val, int max_val)
{
    char input[20];
    int value;
    char *endptr;

    while (1)
    {
        printf("%s (%d-%d): ", prompt, min_val, max_val);
        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("Error reading input. Please try again.\n");
            continue;
        }

        // Remove newline
        input[strcspn(input, "\n")] = '\0';

        // Check for empty input
        if (strlen(input) == 0)
        {
            printf("Please enter a valid number.\n");
            continue;
        }

        // Convert to integer
        errno = 0;
        value = strtol(input, &endptr, 10);

        // Check for conversion errors
        if (errno != 0 || *endptr != '\0')
        {
            printf("Invalid number format. Please try again.\n");
            continue;
        }

        // Check range
        if (value < min_val || value > max_val)
        {
            printf("Value must be between %d and %d. Please try again.\n", min_val, max_val);
            continue;
        }

        return value;
    }
}

long get_long_input(const char *prompt, long min_val, long max_val)
{
    char input[30];
    long value;
    char *endptr;

    while (1)
    {
        printf("%s (%ld-%ld): ", prompt, min_val, max_val);
        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("Error reading input. Please try again.\n");
            continue;
        }

        // Remove newline
        input[strcspn(input, "\n")] = '\0';

        // Check for empty input
        if (strlen(input) == 0)
        {
            printf("Please enter a valid number.\n");
            continue;
        }

        // Convert to long
        errno = 0;
        value = strtol(input, &endptr, 10);

        // Check for conversion errors
        if (errno != 0 || *endptr != '\0')
        {
            printf("Invalid number format. Please try again.\n");
            continue;
        }

        // Check range
        if (value < min_val || value > max_val)
        {
            printf("Value must be between %ld and %ld. Please try again.\n", min_val, max_val);
            continue;
        }

        return value;
    }
}

double get_double_input(const char *prompt, double min_val, double max_val)
{
    char input[20];
    double value;
    char *endptr;

    while (1)
    {
        printf("%s (%.2f-%.2f): ", prompt, min_val, max_val);
        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("Error reading input. Please try again.\n");
            continue;
        }

        // Remove newline
        input[strcspn(input, "\n")] = '\0';

        // Check for empty input
        if (strlen(input) == 0)
        {
            printf("Please enter a valid number.\n");
            continue;
        }

        // Convert to double
        errno = 0;
        value = strtod(input, &endptr);

        // Check for conversion errors
        if (errno != 0 || *endptr != '\0')
        {
            printf("Invalid number format. Please try again.\n");
            continue;
        }

        // Check range
        if (value < min_val || value > max_val)
        {
            printf("Value must be between %.2f and %.2f. Please try again.\n", min_val, max_val);
            continue;
        }

        return value;
    }
}

char *get_string_input(const char *prompt, int max_length)
{
    char *buffer = malloc(max_length + 1);
    if (!buffer)
    {
        printf("Memory allocation error!\n");
        return NULL;
    }

    while (1)
    {
        printf("%s (max %d characters): ", prompt, max_length);
        if (fgets(buffer, max_length + 1, stdin) == NULL)
        {
            printf("Error reading input. Please try again.\n");
            continue;
        }

        // Remove newline if present
        buffer[strcspn(buffer, "\n")] = '\0';

        // Check for empty input
        if (strlen(buffer) == 0)
        {
            printf("Input cannot be empty. Please try again.\n");
            continue;
        }

        // Check if input was truncated
        if (strlen(buffer) == (size_t)max_length && buffer[max_length - 1] != '\0')
        {
            printf("Input too long. Please limit to %d characters.\n", max_length);
            // Clear remaining input
            int c;
            while ((c = getchar()) != '\n' && c != EOF)
                ;
            continue;
        }

        return buffer;
    }
}

void safe_string_input(char *buffer, size_t buffer_size)
{
    if (fgets(buffer, buffer_size, stdin) != NULL)
    {
        // Remove newline if present
        buffer[strcspn(buffer, "\n")] = '\0';
    }
}

int start_backend(void)
{
    int stdin_pipe[2], stdout_pipe[2];

    // Create pipes for communication
    if (pipe(stdin_pipe) == -1 || pipe(stdout_pipe) == -1)
    {
        perror("Failed to create pipes");
        return -1;
    }

    // Fork the backend process
    backend_pid = fork();
    if (backend_pid == -1)
    {
        perror("Failed to fork backend process");
        return -1;
    }

    if (backend_pid == 0)
    {
        // Child process - backend
        close(stdin_pipe[1]);  // Close write end of stdin pipe
        close(stdout_pipe[0]); // Close read end of stdout pipe

        // Redirect stdin and stdout
        dup2(stdin_pipe[0], STDIN_FILENO);
        dup2(stdout_pipe[1], STDOUT_FILENO);
        dup2(stdout_pipe[1], STDERR_FILENO);  // Redirect stderr to stdout

        // Close unused pipe ends
        close(stdin_pipe[0]);
        close(stdout_pipe[1]);
        
        // Execute backend directly - no special buffering needed
        execl(BACKEND_EXECUTABLE, "PLDCLC", NULL);
        perror("Failed to execute backend");
        exit(EXIT_FAILURE);
    }

    // Parent process - frontend
    close(stdin_pipe[0]);  // Close read end of stdin pipe
    close(stdout_pipe[1]); // Close write end of stdout pipe

    backend_stdin_fd = stdin_pipe[1];
    backend_stdout_fd = stdout_pipe[0];

    return 0;
}

void stop_backend(void)
{
    if (backend_pid > 0)
    {
        // Send exit command
        if (backend_stdin_fd >= 0)
        {
            write(backend_stdin_fd, "X\n", 2);
            close(backend_stdin_fd);
        }
        if (backend_stdout_fd >= 0)
        {
            close(backend_stdout_fd);
        }

        // Wait for backend to exit
        int status;
        waitpid(backend_pid, &status, 0);
        backend_pid = -1;
    }
}

void read_command_prompt(void)
{
    char buffer[256];
    int i = 0;
    char c;
    
    // Read character by character until newline
    while (i < sizeof(buffer) - 1)
    {
        if (read(backend_stdout_fd, &c, 1) != 1)
        {
            break;
        }
        buffer[i++] = c;
        if (c == '\n')
        {
            break;
        }
    }
    buffer[i] = '\0';

    if (strcmp(buffer, "CMD?\n") == 0)
    {
        return;
    }
    else
    {
        printf("Unexpected prompt from backend: %s", buffer);
    }
}

void read_until_newline(char *buffer, size_t buffer_size)
{
    int i = 0;
    char c;
    
    // Read character by character until newline
    while (i < buffer_size - 1)
    {
        if (read(backend_stdout_fd, &c, 1) != 1)
        {
            break;
        }
        buffer[i++] = c;
        if (c == '\n')
        {
            break;
        }
    }
    buffer[i] = '\0';
}

// Read and classify the next message from backend
typedef enum {
    MSG_SUCCESS,    // "S\n"
    MSG_FAILURE,    // "F\n" 
    MSG_PROMPT,     // "XY?\n" format
    MSG_DATA,       // Other data
    MSG_ERROR       // Read error
} message_type_t;

message_type_t read_next_message(char *buffer, size_t buffer_size)
{
    read_until_newline(buffer, buffer_size);
    
    if (strlen(buffer) == 0) {
        return MSG_ERROR;
    }
    
    if (strcmp(buffer, "S\n") == 0) {
        return MSG_SUCCESS;
    }
    
    if (strcmp(buffer, "F\n") == 0) {
        return MSG_FAILURE;
    }
    
    // Check if it's a prompt (ends with "?\n")
    int len = strlen(buffer);
    if (len >= 3 && buffer[len-2] == '?' && buffer[len-1] == '\n') {
        return MSG_PROMPT;
    }
    
    return MSG_DATA;
}

// Wait for a success response, handling any prompts that come first
int wait_for_success(void)
{
    char buffer[256];
    message_type_t msg_type;
    
    while (1) {
        msg_type = read_next_message(buffer, sizeof(buffer));
        
        switch (msg_type) {
            case MSG_SUCCESS:
                return 1;
            case MSG_FAILURE:
                return 0;
            case MSG_PROMPT:
                // Just ignore prompts while waiting for success
                continue;
            case MSG_DATA:
                // Show unexpected data
                printf("Backend returned unexpected data: %s", buffer);
                continue;
            case MSG_ERROR:
            default:
                return -1;
        }
    }
}

// Wait for a prompt, handling any success/failure messages that come first  
int wait_for_prompt(char *prompt_buffer, size_t buffer_size)
{
    char buffer[256];
    message_type_t msg_type;
    
    while (1) {
        msg_type = read_next_message(buffer, sizeof(buffer));
        
        switch (msg_type) {
            case MSG_PROMPT:
                strncpy(prompt_buffer, buffer, buffer_size - 1);
                prompt_buffer[buffer_size - 1] = '\0';
                return 1;
            case MSG_SUCCESS:
            case MSG_FAILURE:
                // Ignore success/failure while waiting for prompt
                continue;
            case MSG_DATA:
                // Show unexpected data
                printf("Backend returned unexpected data: %s", buffer);
                continue;
            case MSG_ERROR:
            default:
                return -1;
        }
    }
}

int send_to_backend(const char *data)
{
    if (backend_stdin_fd < 0)
    {
        printf("Error: Backend not running\n");
        return -1;
    }

    ssize_t len = strlen(data);
    if (write(backend_stdin_fd, data, len) != len)
    {
        printf("Error: Failed to send data to backend\n");
        return -1;
    }

    return 0;
}

int payload_size(int total_size, float share)
{
    float size;

    size = (float) total_size;
    
    return total_size - (int) ceil(size * (1.0f - share));
}

void check_payload_exists(void)
{
    printf("\nChecking if payload file exists...\n");

    if (send_to_backend("E\n") != 0)
    {
        return;
    }

    int result = wait_for_success();
    if (result == 1)
    {
        printf("✓ Payload file exists\n");
    }
    else if (result == 0)
    {
        printf("✗ Payload file does not exist\n");
    }
    else
    {
        printf("Error checking payload file status\n");
    }

    wait_for_enter();
}

void check_manifest_exists(void)
{
    printf("\nChecking if manifest exists in payload file...\n");

    if (send_to_backend("M\n") != 0)
    {
        return;
    }

    int result = wait_for_success();
    if (result == 1)
    {
        printf("✓ Manifest exists in payload file\n");
    }
    else if (result == 0)
    {
        printf("✗ Manifest does not exist in payload file\n");
    }
    else
    {
        printf("Error checking manifest status\n");
    }

    wait_for_enter();
}

void delete_payload_file(void)
{
    printf("\nDeleting payload file...\n");
    printf("WARNING: This will permanently delete the payload file!\n");
    printf("Are you sure? (y/N): ");

    char confirm[10];
    safe_string_input(confirm, sizeof(confirm));

    if (confirm[0] != 'y' && confirm[0] != 'Y')
    {
        printf("Operation cancelled.\n");
        wait_for_enter();
        return;
    }

    if (send_to_backend("D\n") != 0)
    {
        return;
    }

    int result = wait_for_success();
    if (result == 1)
    {
        printf("✓ Payload file deleted successfully\n");
    }
    else if (result == 0)
    {
        printf("✗ Failed to delete payload file\n");
    }
    else
    {
        printf("Error deleting payload file\n");
    }

    wait_for_enter();
}

void read_payload_file(void)
{
    printf("\nReading payload file contents...\n");

    if (send_to_backend("R\n") != 0)
    {
        return;
    }

    // Read the size first
    ssize_t size = 0;
    if (read(backend_stdout_fd, &size, 4) != 4)
    {
        printf("Error: Failed to read payload size\n");
        wait_for_enter();
        return;
    }

    if (size <= 0)
    {
        printf("Payload file is empty or error occurred\n");
        wait_for_enter();
        return;
    }

    // Read the payload data
    char *buffer = malloc(size + 1);
    if (!buffer)
    {
        printf("Error: Memory allocation failed\n");
        wait_for_enter();
        return;
    }

    ssize_t bytes_read = read(backend_stdout_fd, buffer, size);
    if (bytes_read != size)
    {
        printf("Error: Failed to read complete payload data\n");
        free(buffer);
        wait_for_enter();
        return;
    }

    buffer[size] = '\0';

    printf("Payload file contents (%zd bytes):\n", size);
    print_separator();

    // Display as hex dump for binary data
    for (ssize_t i = 0; i < size; i += 16)
    {
        printf("%08zx: ", i);

        // Hex values
        for (int j = 0; j < 16 && i + j < size; j++)
        {
            printf("%02x ", (unsigned char)buffer[i + j]);
        }

        // Padding for incomplete lines
        for (int j = size - i; j < 16; j++)
        {
            printf("   ");
        }

        printf(" |");

        // ASCII representation
        for (int j = 0; j < 16 && i + j < size; j++)
        {
            char c = buffer[i + j];
            printf("%c", (c >= 32 && c <= 126) ? c : '.');
        }

        printf("|\n");
    }

    free(buffer);

    // Read success/failure response
    if (wait_for_success() != 1)
    {
        printf("Error: Did not receive success confirmation from backend\n");
    }

    wait_for_enter();
}

void create_payload_file(void)
{
    printf("\nCreating new mission payload file...\n");
    print_separator();

    if (send_to_backend("C\n") != 0)
    {
        return;
    }

    // Wait for ML? prompt
    char prompt[20];
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1) {
        printf("Error: Expected ML? prompt\n");
        wait_for_enter();
        return;
    }

    if (strcmp(prompt, "ML?\n") != 0) {
        printf("Error: Expected ML? prompt, got %s", prompt);
        wait_for_enter();
        return;
    }

    // Get mission designation length
    int mission_length = get_integer_input("Enter mission designation length", 1, 1024);
    char length_str[20];
    snprintf(length_str, sizeof(length_str), "%d\n", mission_length);
    send_to_backend(length_str);

    // Wait for success response, then MD? prompt - they come in sequence
    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    // Now wait for MD? prompt 
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1) {
        printf("Error: Expected MD? prompt\n");
        wait_for_enter();
        return;
    }

    if (strcmp(prompt, "MD?\n") != 0) {
        printf("Error: Expected MD? prompt, got %s", prompt);
        wait_for_enter();
        return;
    }

    // Get mission designation
    char *mission_name = get_string_input("Enter mission designation", mission_length + 1);
    if (!mission_name)
    {
        printf("Error getting mission designation\n");
        wait_for_enter();
        return;
    }

    send_to_backend(mission_name);
    free(mission_name);
    
    // Read success response after mission designation
    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    // Wait for LY? prompt
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1) {
        printf("Error: Expected LY? prompt\n");
        wait_for_enter();
        return;
    }

    if (strcmp(prompt, "LY?\n") != 0) {
        printf("Error: Expected LY? prompt, got %s", prompt);
        wait_for_enter();
        return;
    }

    // Get launch year
    printf("Enter launch year: ");
    char year_input[20];
    safe_string_input(year_input, sizeof(year_input));
    
    // Add newline and send directly to backend
    char year_str[30];
    snprintf(year_str, sizeof(year_str), "%s\n", year_input);
    send_to_backend(year_str);

    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }
    
    // Wait for LT? prompt
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1) {
        printf("Error: Expected LT? prompt\n");
        wait_for_enter();
        return;
    }

    if (strcmp(prompt, "LT?\n") != 0) {
        printf("Error: Expected LT? prompt, got %s", prompt);
        wait_for_enter();
        return;
    }

    // Get launch timestamp
    long launch_timestamp = get_long_input("Enter launch timestamp (Unix time)", 0, LONG_MAX);
    char timestamp_str[30];
    snprintf(timestamp_str, sizeof(timestamp_str), "%ld\n", launch_timestamp);
    send_to_backend(timestamp_str);

    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    // Wait for MPC? prompt
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1) {
        printf("Error: Expected MPC? prompt\n");
        wait_for_enter();
        return;
    }

    if (strcmp(prompt, "MPC?\n") != 0) {
        printf("Error: Expected MPC? prompt, got %s", prompt);
        wait_for_enter();
        return;
    }

    // Get maximum payload capacity
    long max_capacity = get_long_input("Enter maximum payload mass capacity (kg)", 1, 1024);
    char capacity_str[30];
    snprintf(capacity_str, sizeof(capacity_str), "%ld\n", max_capacity);
    send_to_backend(capacity_str);

    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    int result = wait_for_success();
    if (result == 1)
    {
        printf("✓ Mission payload file created successfully\n");
    }
    else if (result == 0)
    {
        printf("✗ Failed to create mission payload file\n");
    }
    else
    {
        printf("Error creating mission payload file\n");
    }

    wait_for_enter();
}

void update_payload_manifest(void)
{
    printf("\nUpdating payload manifest...\n");
    print_separator();

    if (send_to_backend("U\n") != 0)
    {
        return;
    }

    // Wait for TC? prompt or F failure response
    char prompt[20];
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1)
    {
        // Check if we got a failure response instead
        read_until_newline(prompt, sizeof(prompt));
        if (strcmp(prompt, "F\n") == 0)
        {
            printf("✗ Payload file must exist before updating manifest\n");
        }
        else
        {
            printf("Error: Expected TC? prompt or F response\n");
        }
        wait_for_enter();
        return;
    }

    // Get total component capacity
    int total_capacity = get_integer_input("Enter total component capacity (kg)", 1, 1000);
    char capacity_str[20];
    snprintf(capacity_str, sizeof(capacity_str), "%d\n", total_capacity);
    send_to_backend(capacity_str);
    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    // Wait for NC? prompt
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1)
    {
        printf("Error: Expected NC? prompt\n");
        wait_for_enter();
        return;
    }

    // Get number of components
    int num_components = get_integer_input("Enter number of mission components", 1, MAX_COMPONENTS);
    char num_str[20];
    snprintf(num_str, sizeof(num_str), "%d\n", num_components);
    send_to_backend(num_str);
    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    // Get component shares
    double component_shares[MAX_COMPONENTS];
    double total_share = 0.0f;
    for (int i = 0; i < num_components; i++)
    {
        // Wait for CS prompt
        if (wait_for_prompt(prompt, sizeof(prompt)) != 1)
        {
            printf("Error: Expected CS%d? prompt\n", i + 1);
            wait_for_enter();
            return;
        }

        char share_prompt[100];
        snprintf(share_prompt, sizeof(share_prompt), "Enter component %d share percentage (0.0-1.0)", i + 1);
        double max_remaining = 1.0f - total_share;
        if (max_remaining < 0.01f)
            max_remaining = 0.01f;

        double share = get_double_input(share_prompt, 0.0f, max_remaining);
        component_shares[i] = share;
        total_share += share;

        char share_str[20];
        snprintf(share_str, sizeof(share_str), "%.8f\n", share);
        send_to_backend(share_str);
        if (wait_for_success() != 1)
        {
            wait_for_enter();
            return;
        }

        printf("Component %d size will be: %d kg\n", i + 1, payload_size(total_capacity, share));
    }

    // Get component data
    for (int i = 0; i < num_components; i++)
    {
        // Wait for CD prompt
        if (wait_for_prompt(prompt, sizeof(prompt)) != 1)
        {
            printf("Error: Expected CD%d? prompt\n", i + 1);
            wait_for_enter();
            return;
        }

        // Calculate the exact size this component should have
        int component_size = payload_size(total_capacity, component_shares[i]);
        int hex_string_length = component_size * 2;
        
        printf("\nEnter component %d telemetry data:\n", i + 1);
        printf("Enter data as hex string (e.g., 414243 for ABC)\n");
        printf("Component needs exactly %d bytes (%d hex characters):\n", component_size, hex_string_length);

        // Allocate buffer for hex string input
        char *hex_input = malloc(hex_string_length + 10); // Extra space for safety
        if (!hex_input)
        {
            printf("Memory allocation error!\n");
            return;
        }

        while (1)
        {
            printf("Hex string (up to %d chars, or 'end' to finish early): ", hex_string_length);
            safe_string_input(hex_input, hex_string_length + 10);

            if (strcmp(hex_input, "end") == 0)
            {
                // Send end marker (0xff) and break
                char end_marker = (char)0xff;
                write(backend_stdin_fd, &end_marker, 1);
                break;
            }

            // Validate hex string length and characters
            int input_len = strlen(hex_input);
            if (input_len == 0)
            {
                printf("Input cannot be empty. Use 'end' to finish early.\n");
                continue;
            }

            if (input_len % 2 != 0)
            {
                printf("Hex string must have even number of characters (pairs of hex digits)\n");
                continue;
            }

            // Validate all characters are hex
            int valid_hex = 1;
            for (int j = 0; j < input_len; j++)
            {
                if (!isxdigit(hex_input[j]))
                {
                    valid_hex = 0;
                    break;
                }
            }

            if (!valid_hex)
            {
                printf("Invalid hex string. Use only 0-9 and A-F characters\n");
                continue;
            }

            // Convert hex string to bytes and send (up to component_size bytes)
            int bytes_to_send = input_len / 2;
            if (bytes_to_send > component_size)
            {
                printf("Warning: Truncating to %d bytes (component size limit)\n", component_size);
                bytes_to_send = component_size;
            }

            for (int j = 0; j < bytes_to_send; j++)
            {
                char hex_byte[3] = {hex_input[j*2], hex_input[j*2+1], '\0'};
                unsigned int byte_val;
                sscanf(hex_byte, "%x", &byte_val);
                char byte = (char)byte_val;
                write(backend_stdin_fd, &byte, 1);
            }

            // Send end marker
            char end_marker = (char)0xff;
            write(backend_stdin_fd, &end_marker, 1);
            printf("Sent %d bytes + terminator\n", bytes_to_send);
            break;
        }

        free(hex_input);
        if (wait_for_success() != 1)
        {
            wait_for_enter();
            return;
        }
    }

    // Read remaining capacity (skip any success signals and read RC:<number>)
    {
        char rc_buf[100];
        // Loop until we get the RC line
        do {
            read_until_newline(rc_buf, sizeof(rc_buf));
        } while (strncmp(rc_buf, "RC:", 3) != 0);
        // Print numeric part including newline
        printf("Remaining capacity: %s", rc_buf + 3);
    }

    // Wait for user signature prompt (US?)
    if (wait_for_prompt(prompt, sizeof(prompt)) != 1)
    {
        printf("Error: Expected US? prompt\n");
        wait_for_enter();
        return;
    }

    // Get user signature as hex string
    printf("Enter user signature as hex (max 128 hex chars = 64 bytes): ");
    char hex_input[130];
    safe_string_input(hex_input, sizeof(hex_input));
    
    // Convert hex to bytes and send as complete signature
    int hex_len = strlen(hex_input);
    if (hex_len > 0 && hex_len % 2 == 0) {
        char signature[72]; // 64 bytes + newline + null terminator
        int sig_len = hex_len / 2;
        for (int i = 0; i < hex_len; i += 2) {
            char hex_byte[3] = {hex_input[i], hex_input[i+1], '\0'};
            unsigned int byte_val;
            sscanf(hex_byte, "%x", &byte_val);
            signature[i/2] = (char)byte_val;
        }
        signature[sig_len] = '\0';
        // Send complete signature with newline
        write(backend_stdin_fd, signature, sig_len);
    } else {
        write(backend_stdin_fd, "\n", 1);
    }
    
    if (wait_for_success() != 1)
    {
        wait_for_enter();
        return;
    }

    int result = wait_for_success();
    if (result == 1)
    {
        printf("✓ Payload manifest updated successfully\n");
    }
    else if (result == 0)
    {
        printf("✗ Failed to update payload manifest\n");
    }
    else
    {
        printf("Error updating payload manifest\n");
    }

    wait_for_enter();
}

int main(void)
{
    // Disable buffering
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    alarm(120);

    int choice;

    printf("Starting Mission Payload Management System...\n");

    // Start the backend process
    if (start_backend() != 0)
    {
        printf("Failed to start backend process\n");
        return EXIT_FAILURE;
    }

    // Read the initial CMD? prompt from backend
    read_command_prompt();

    while (1)
    {
        print_main_menu();
        choice = get_user_choice();

        if (choice == -1)
        {
            printf("Invalid choice. Please enter a number between 1 and 7.\n");
            wait_for_enter();
            continue;
        }

        switch (choice)
        {
        case 1:
            create_payload_file();
            break;
        case 2:
            read_payload_file();
            break;
        case 3:
            update_payload_manifest();
            break;
        case 4:
            check_payload_exists();
            break;
        case 5:
            check_manifest_exists();
            break;
        case 6:
            delete_payload_file();
            break;
        case 7:
            printf("\nExiting Mission Payload Management System...\n");
            stop_backend();
            return EXIT_SUCCESS;
        default:
            printf("Invalid choice.\n");
            wait_for_enter();
            break;
        }

        // Read the CMD? prompt for the next iteration
        read_command_prompt();
    }

    return EXIT_SUCCESS;
}