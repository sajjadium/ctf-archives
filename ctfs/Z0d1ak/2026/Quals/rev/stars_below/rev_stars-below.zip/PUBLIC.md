# Stars Below

**Category:** Reverse Engineering

**Difficulty:** Extreme
**Author:** afish

The drowned observatory still charts a sky. Eight fragments remember the name
of its last pilot; the relay remembers everything else.

Bring the fragments home in the right wake. Recover the pilot's ticket. Ask
the stars below what they saw.

You are given one stripped Linux x86-64 executable. It requires SDL2. A
display-free verifier is available as:

```text
./stars_below --headless ROUTE CALLSIGN TICKET
```

The attachment targets glibc on a conventional 4 KiB-page x86-64 Linux host.
Run it without `LD_BIND_NOW`, `LD_AUDIT`, or `LD_PRELOAD` overrides.
