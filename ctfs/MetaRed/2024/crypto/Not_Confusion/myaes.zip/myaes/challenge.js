const customAES = require('./myaes.js');
const crypto = require("crypto");

const key = crypto.randomBytes(16);
const plaintext = Buffer.from('Hello, World!!!!');

const encrypted = customAES.encrypt(plaintext, key);
console.log('Encrypted1:', encrypted.toString('hex'));
const decrypted = customAES.decrypt(encrypted, key);
console.log('Decrypted1:', decrypted.toString());


const fs = require('fs');
const flag = fs.readFileSync('flag.txt');
const plaintext2 = Buffer.from(flag);

var encrypted2 = customAES.encrypt(plaintext2, key);
console.log('Encrypted2:', encrypted2.toString('hex'));
