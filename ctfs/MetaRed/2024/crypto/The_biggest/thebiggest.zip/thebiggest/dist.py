import sys
from flag import flag
from Crypto.Cipher import AES
from Crypto.Util.number import long_to_bytes, bytes_to_long
sys.set_int_max_str_digits(2147483646)

def encrypt(flag, key):
    cipher = AES.new(key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(flag)
    return (cipher.nonce, ciphertext, tag)

n = ((((((42 * 17 + 50 ** 2) * 1000) // 3) * 7 + sum(range(1, 101))) * 123) + -786759022)
p = (1 << n) - 1
p = str(p).encode() # I have a lot of time, but you?
key = p[1000000:1000032]

nonce, ciphertext, tag = encrypt(flag, key)
print("nonce:", long_to_bytes(bytes_to_long(nonce)).hex())
print("ciphertext:", ciphertext.hex())
print("tag:", tag.hex())
