from flask import Flask, render_template, make_response,request
from bot import *
from urllib.parse import urlparse
import os

app = Flask(__name__)


@app.route('/')
def index():
    # Get query param from url
    query = request.args.get('query')

    return render_template('index.html', search=query)


@app.route("/report", methods=["POST", "GET"])
def report():
    if request.method == "GET":
        return render_template('report.html')
    if request.method == "POST":
        bot = Bot()
        url = request.form.get('url')
        if url:
            try:
                parsed_url = urlparse(url)
            except Exception:
                return render_template('report.html', error='Invalid URL')
            if parsed_url.scheme not in ["http", "https"]:
                return render_template('report.html', error='Invalid scheme')
            # Timeout 3 seconds:
            bot.driver.set_page_load_timeout(3)
            bot.visit(url)
            bot.close()
            return render_template('report.html', info=f'Visited {url}')            
        else:
            return render_template('report.html', error='Url parameter is missing')            
if __name__ == '__main__':
    app.run(port=8080)
