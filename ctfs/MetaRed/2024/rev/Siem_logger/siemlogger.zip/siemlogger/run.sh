docker build -t ctf-siemlogger .
docker run -it --rm -p 5000:5000 ctf-siemlogger