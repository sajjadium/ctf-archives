#!/bin/bash

docker build -t googler deploy 
docker run --rm -p 8080:8080 -it googler
