from flask import Flask, request, render_template, redirect, url_for
import requests
from urllib.parse import urlparse
import os 
import threading

app = Flask(__name__)

def is_valid_url(url):
    """
    Checks if the provided URL is valid.
    """
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc, result.hostname])
    except ValueError:
        return False
    
@app.route('/', methods=['GET', 'POST'])
def index():
    """
    Main page with a form to input the URL.
    """
    return render_template('index.html')

@app.route('/visit-url', methods=['POST'])
def visit_url():
    """
    I'll give you the flag if you went through Google. Don't start or end at Google
    """
    url = request.form.get('url')
    if not is_valid_url(url):
        return render_template('result.html', error='Invalid URL', url=url)

    try:
        session = requests.Session()
        session.max_redirects = 4
        response = session.get(url, timeout=4, allow_redirects=True)

        # Dont start in Google
        if "google.com" in urlparse(url).hostname:
            return render_template('result.html', error='Error 1: You cannot start in Google', url=url)
    
        # Dont end in Google
        if "google.com" in urlparse(response.url).hostname:
            return render_template('result.html', error='Error 2: You cannot finish at Google', url=url)

        # Check if went through Google
        through_google = False
        for i in response.history[1:]:
            if "google.com" == urlparse(i.url).hostname:
                through_google = True
                break
        
        if not through_google:
            return render_template('result.html', error='Error 3: You did not go through Google', url=url)

        return render_template('result.html', status_code=response.status_code, content=response.text, url=url)
            
    except requests.exceptions.RequestException as e:
        return render_template('result.html', error=str(e), url=url)



app2 = Flask(__name__)
flag = os.environ.get('FLAG', 'flag{this_is_a_fake_flag}')

@app2.route('/flag')
def index_app2():
    return flag

def run_app1():
    app.run(port=8080, host="0.0.0.0")

def run_app2():
    app2.run(port=8081, host="127.0.0.1")


if __name__ == '__main__':
    t1 = threading.Thread(target=run_app1)
    t2 = threading.Thread(target=run_app2)

    t1.start()
    t2.start()
    
    t1.join()
    t2.join()