import uvicorn
import torch
import json
import os
from fastapi import FastAPI, File, UploadFile
from PIL import Image
from torchvision import transforms
from torchvision.models import shufflenet_v2_x1_0, ShuffleNet_V2_X1_0_Weights

feature_extractor = shufflenet_v2_x1_0(weights=ShuffleNet_V2_X1_0_Weights.IMAGENET1K_V1)
feature_extractor.fc = torch.nn.Identity()
feature_extractor.eval()

weights = ShuffleNet_V2_X1_0_Weights.IMAGENET1K_V1
transform = transforms.Compose([
    transforms.ToTensor(),
])

if not os.path.exists("embedding.json"):
    user_image = Image.open("user_image.jpg").convert("RGB")
    user_image = transform(user_image).unsqueeze(0)
    with torch.no_grad():
        user_embedding = feature_extractor(user_image)[0]

    with open("embedding.json", "w") as f:
        json.dump(user_embedding.tolist(), f)
    
user_embedding = json.load(open("embedding.json", "r"))
user_embedding = torch.tensor(user_embedding, dtype=torch.float32)
user_embedding = user_embedding.unsqueeze(0)
    
app = FastAPI()

@app.post("/signin/")
async def signin(file: UploadFile = File(...)):
    submit_image = Image.open(file.file).convert("RGB")
    submit_image = transform(submit_image).unsqueeze(0)
    with torch.no_grad():
        submit_embedding = feature_extractor(submit_image)[0]
    diff = torch.mean((user_embedding - submit_embedding) ** 2)
    result = {
        "status": "L3HCTF{test_flag}" if diff.item() < 5e-6 else "failure"
    }
    return result

@app.get("/")
async def root():
    return {"message": "Welcome to the Face Recognition API!"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)