# start
```shell
docker build  -t "library" .  
```

```shell
docker run --rm -d -p 9999:9999/tcp -e 'FLAG=flag{test}' library
```
