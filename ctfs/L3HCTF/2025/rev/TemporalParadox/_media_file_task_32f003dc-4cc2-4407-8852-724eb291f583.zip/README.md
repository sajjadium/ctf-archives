# Temporal Paradox

flag 形式为 L3HCTF{sha1(query string)}
