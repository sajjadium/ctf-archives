import express from "express";
import crypto, { randomUUID } from "crypto";
import session from "express-session";
import DOMPurify from "isomorphic-dompurify";
import { ADMIN_TOKEN, bot } from "./bot";

declare module "express-session" {
  interface SessionData {
    userId: string;
    isAdmin: boolean;
  }
}

const app = express();
const secret = crypto.randomBytes(32).toString("hex");

const cspMiddleware = (
  req: express.Request,
  res: express.Response,
  next: express.NextFunction
) => {
  const nonce = crypto.randomBytes(16).toString("hex");
  res.setHeader(
    "Content-Security-Policy",
    `script-src 'self' 'nonce-${nonce}' 'unsafe-eval' https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js; base-uri 'none'; object-src 'none';`
  );
  next();
};

app.use(cspMiddleware);
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(
  session({
    secret: secret,
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false },
  })
);
app.set("view engine", "ejs");

type Note = {
  id: string;
  userId: string;
  content: string;
};

const notes: Note[] = [];

app.get("/", (req, res) => {
  if (req.session && !req.session.userId) {
    req.session.userId = randomUUID();
    if (req.query.token === ADMIN_TOKEN) {
      req.session.isAdmin = true;
      console.log("Admin logged in");
    } else {
      req.session.isAdmin = false;
    }
  }

  const userId = req.session ? req.session.userId : null;
  const userNotes = notes.filter((n) => n.userId === userId);
  const userNotesWithName = userNotes.map((n, i) => {
    return { ...n, name: `Note ${i + 1}` };
  });
  res.render("index", { notes: userNotesWithName, cspNonce: res.locals.nonce });
});

app.get("/note/:id", (req, res) => {
  const note = notes.find((n) => n.id === req.params.id);
  if (!note) {
    res.redirect("/redirect?url=/");
    return;
  }

  if (note.userId !== req.session.userId && req.session.isAdmin !== true) {
    res.status(403).send("Forbidden");
    return;
  }

  const content = Buffer.from(note.content, "base64").toString("ascii");
  res.render("note", { note: { ...note, content } });
});

app.post("/create", async (req, res) => {
  let { content } = req.body;
  const userId = req.session ? req.session.userId : null;
  if (!userId) {
    res.status(401).send("Unauthorized");
    return;
  }
  if (!content) {
    res.status(400).send("Bad request");
    return;
  }
  const clean = DOMPurify.sanitize(content, {
    ADD_ATTR: ["data-*"],
  });
  const b64 = Buffer.from(clean).toString("base64");
  notes.push({ id: randomUUID(), userId, content: b64 });
  res.redirect("/");
});

app.get("/report/:id", async (req, res) => {
  const note = notes.find((n) => n.id === req.params.id);
  if (!note) {
    res.redirect("/redirect?url=/");
    return;
  }
  try {
    await bot(note.id);
    res.send("Reported");
  } catch (e) {
    res.send("Failed to report");
  }
});

app.get("/redirect", (req, res) => {
  const url = req.query.url;
  if (!url) {
    res.send(`
      <html>
    <head>
        <meta http-equiv="refresh" content="3;url=https://google.com/" />
    </head>
    <body>
        <h1>Not found</h1>
        <h1>Redirecting in 3 seconds...</h1>
    </body>
    </html>`);
  }
  res.redirect(301, url as string);
});

app.listen(3000, () => {
  console.log("Server is running on port 3000");
});
