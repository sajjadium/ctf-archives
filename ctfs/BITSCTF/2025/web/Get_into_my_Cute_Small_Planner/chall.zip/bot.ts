import puppeteer from "puppeteer";
const APP_URL = "http://localhost:3000";

const FLAG = process.env.FLAG || "flag{fake_flag}";
export const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "strong_admin_token";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export const bot = async (id: string) => {
  try {
    const url = `${APP_URL}/note/${id}`;

    const browser = await puppeteer.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-dev-shm-usage"],
      executablePath: "/usr/bin/google-chrome",
    });
    const page = await browser.newPage();

    await page.goto(`${APP_URL}?token=${ADMIN_TOKEN}`, { timeout: 5000 });

    await page.type("textarea", FLAG);
    await page.click("button");
    await sleep(1000);

    await page.goto(url, { timeout: 5000 });
    await sleep(5000);
    await page.close();
    await browser.close();
    console.log(`Done: ${url}`);
  } catch (e) {
    console.error(e);
  }
};
