<?php
$TEST_FILEPATH = "./dummy_report.pdf";

if (isset($_POST["service"]) && isset($_POST["dst_path"]) && isset($_POST["username"]) && isset($_POST["password"])) {
    $shareDomain = $_POST["service"];
    $dstPath = $_POST["dst_path"];
    $shareLogin = $_POST["username"];
    $sharePwd = substr($_POST["password"], 100);
    $timestamp = date(DATE_ATOM);
    
    $vals = [
        'service' => base64_encode($shareDomain),
        'username' => base64_encode($shareLogin),
        'command' => "put \"$TEST_FILEPATH\" \"$dstPath-$timestamp\"",
        'password' => $sharePwd
    ];
    
    $descriptors = [
        0 => ["pipe", "r"],  
        1 => ["pipe", "w"],  
        2 => ["pipe", "w"]   
    ];
    
    $process = proc_open("/usr/local/bin/smbSendReport", $descriptors, $pipes);
    
    if (is_resource($process)) {
        foreach ($vals as $val) {
            fwrite($pipes[0], "$val\n");
        }
	
	// for debug
	//$stdout = stream_get_contents($pipes[1]);
	//var_dump($stdout);
        
        $exitCode = proc_close($process);
    
        if ($exitCode !== 0) {
            $success = false;
            $result = "An error occured";

        } else {
            $success = true;
            $result = "File uploaded sucessfully";
        }

    } else {
        $success = false;
        $result = "An error occured";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="static/bootstrap.css">
    <link rel="stylesheet" href="static/stylesheet.css">
    <title>expect</title>
</head>

<body>
    <div class="align-middle">
        <div class="container my-5 px-4">
            <h3 class="py-5">Configuration</h3>
            <p>This functionality is still under testing, normally clients shoudl fill the SMB configuration form below and any generated reports should be sent directly to their servers. There aren't any reports generation functionality here yet, we are using a dummy file for testing.</p>
            <form method='post' class="submit">
		    <div class="my-3 <? if(isset($success)) echo $success? 'success' : 'error'; ?>"><? echo $result ?? ''; ?></div>
		    <div class="my-2">
		    	<label>Host and path names : </label><input class="mx-5" type="text" name="service" placeholder="//example.com/SHARE"><br>
		    </div>
		    <div class="my-2">
		    	<label>Destination path of the report : </label><input class="mx-5" type="text" name="dst_path" placeholder="/path/to/dirctory"><br>
		    </div>
		    <div class="my-2">
		    	<label>Username : </label><input class="mx-5" type="text" name="username" placeholder="username"><br>
		    </div>
		    <div class="my-2">
		    	<label>Password : </label><input class="mx-5" type="text" name="password" placeholder="******"><br>
		    </div>
		    <div class="my-2">
            		<button type='submit'>Submit</button>
		    </div>
            </form>
        </div>
    </div>
</body>

</html>
