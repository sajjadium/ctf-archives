#!/bin/bash
# Initialize DB and run gunicorn

python -c "from app import app, db, init_db; app.app_context().push(); init_db()"

echo "Starting Gunicorn..."
exec gunicorn -w 4 -b 0.0.0.0:8000 app:app
