#!/bin/bash
mkdir -p /var/log/redis
redis-server /etc/redis/redis.conf
