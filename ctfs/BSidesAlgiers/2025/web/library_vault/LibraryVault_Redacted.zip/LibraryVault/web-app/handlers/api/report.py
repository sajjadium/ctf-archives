import threading
import subprocess
import os
import sys
from handlers.base import BaseHandler
from utils.util import rand_search
from urllib.parse import quote

def run_bot(url):
    
    bot_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', '..', 'utils', 'bot.py'))
    python_exe = sys.executable or 'python3'
    
    log_path = os.path.join('/tmp', 'bot_report.log')
    try:
        with open(log_path, 'ab') as logf:
            proc = subprocess.Popen(
                [python_exe, bot_path, url],
                stdout=logf,
                stderr=logf,
                stdin=subprocess.DEVNULL
            )
            proc.wait()
    except Exception as e:
        
        try:
            with open(log_path, 'ab') as logf:
                logf.write(f"run_bot error: {e}\n".encode())
        except Exception:
            pass

class ReportHandler(BaseHandler):
    
    async def post(self):
        url = f'http://127.0.0.1:1337/search?query={quote("I BELEIVE IT DOESNT WORK")}'
        threading.Thread(target=run_bot, args=(url,)).start()
        self.write({"status": "success", "message": "Thanks for your report! We will review it shortly."})
