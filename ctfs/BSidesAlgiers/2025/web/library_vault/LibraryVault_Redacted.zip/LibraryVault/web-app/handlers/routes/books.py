from handlers.base import BaseHandler
from db.connection import get_connection

class BooksHandler(BaseHandler):
    async def get(self):
        async with get_connection() as conn:
            async with conn.execute("SELECT title, author, year FROM books WHERE verified = 1 ORDER BY RANDOM() LIMIT 20") as cursor:
                books = await cursor.fetchall()
                books = [{"title": row[0], "author": row[1], "year": row[2]} for row in books]
        self.render("books.html", books=books)
