from handlers.base import BaseHandler
from db.connection import get_connection
from db.utils import insert_search
import time
class SearchHandler(BaseHandler):
    async def get(self):
        query = self.get_argument("query", default=None)
        if not query:
            self.render("search.html", search = None, verified_only = False, results=[])
            return
        
        await insert_search(query)
            
        verified_only = self.get_argument("verified_only", default=False)
        
        words = query.split()
        placeholders = " OR ".join(["LOWER(title) LIKE ? OR LOWER(author) LIKE ?"] * len(words))
        values = []
        for word in words:
            values.extend([f"%{word.lower()}%", f"%{word.lower()}%"])
        values = tuple(values)
        
        if verified_only:
            sql_query = f"SELECT title, author, year FROM books WHERE verified = 1 AND ({placeholders})"
        else:
            sql_query = f"SELECT title, author, year FROM books WHERE ({placeholders})"  
                                
        async with get_connection() as conn:
            async with conn.execute(sql_query, values) as cursor:
                results = await cursor.fetchall()
                results = [{"title": row[0], "author": row[1], "year": row[2]} for row in results]
        self.render("search.html", search = query, verified_only=verified_only, results=results)
        
        

        
