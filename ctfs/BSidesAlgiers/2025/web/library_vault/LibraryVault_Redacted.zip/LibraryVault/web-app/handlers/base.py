import tornado.web

class BaseHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Credentials", "true")
        self.set_header(
            "Access-Control-Allow-Headers",
            "Content-Type"
        )
        self.set_header(
            "Access-Control-Allow-Methods",
            "GET, POST, OPTIONS"
        )

    def options(self, *args, **kwargs):
        self.set_status(204)
        self.finish()

    def get_current_user(self):
        return self.get_secure_cookie("username")

    def is_admin(self):
        return self.current_user == b"admin"
