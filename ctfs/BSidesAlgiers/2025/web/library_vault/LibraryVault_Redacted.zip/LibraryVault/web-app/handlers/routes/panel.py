from handlers.base import BaseHandler
import tornado.web
from tornado.httpclient import AsyncHTTPClient, HTTPError
import os
import subprocess
from dotenv import load_dotenv, set_key
from tornado.escape import xhtml_escape

ENVIRON_FILE = '.env'

class PanelHandler(BaseHandler):
    @tornado.web.authenticated
    async def get(self):
        if not self.is_admin():
            self.set_status(403)
            self.render("error.html", error="You are not authorized to access this page.")
            return
        
        
        load_dotenv(ENVIRON_FILE)
        backup_server = os.getenv("BACKUP_SERVER", "")
        archive_path = os.getenv("ARCHIVE_PATH", "")
        
        self.render("panel.html", error=None, result="", backup_server=backup_server, archive_path=archive_path)
     
    @tornado.web.authenticated   
    async def post(self):
        if not self.is_admin():
            self.set_status(403)
            self.render("error.html", error="You are not authorized to access this page.")
            return

        
        action = self.get_argument("action", default="")
        
        if action == "reset_config":
            try:
                
                backup_server = "backup.libraryvault.local"
                archive_path = "/tmp/archives"
                
                # Clear the entire file and write only default values
                with open(ENVIRON_FILE, 'w') as f:
                    f.write(f"BACKUP_SERVER={backup_server}\n")
                    f.write(f"ARCHIVE_PATH={archive_path}\n")
                
                # Reload environment variables
                load_dotenv(ENVIRON_FILE, override=True)
                
                self.render("panel.html", error=None, result="Configuration reset to defaults.", 
                           backup_server=backup_server, archive_path=archive_path)
                return
            except Exception as e:
                self.render("panel.html", error=f"Reset Error: {str(e)}", result="",
                           backup_server="", archive_path="")
                return
        
        if action == "update_config":
            backup_server = self.get_argument("backup_server", default="")
            archive_path = self.get_argument("archive_path", default="")
            
            if not backup_server or not archive_path:
                self.render("panel.html", error="Missing configuration parameters", result="", 
                           backup_server=backup_server, archive_path=archive_path)
                return

            
            #blacklisted_words = ['python']
            #for blacklist in blacklisted_words:
            #    if blacklist in backup_server.lower() or blacklist in archive_path.lower():
            #        self.render("panel.html", error="Forbidden word detected in configuration", result="",
            #                   backup_server=backup_server, archive_path=archive_path)
            #        return

            
            try:
                
                if not os.path.exists(ENVIRON_FILE):
                    with open(ENVIRON_FILE, 'w') as f:
                        f.write("")
                
                set_key(ENVIRON_FILE, "BACKUP_SERVER", backup_server)
                set_key(ENVIRON_FILE, "ARCHIVE_PATH", archive_path)
                
                
                load_dotenv(ENVIRON_FILE, override=True)
                
                self.render("panel.html", error=None, result="Configuration updated successfully.", 
                           backup_server=backup_server, archive_path=archive_path)
                return
                
            except Exception as e:
                self.render("panel.html", error=f"System Error: {str(e)}", result="",
                           backup_server=backup_server, archive_path=archive_path)
                return

        if action == "run_backup":
            load_dotenv(ENVIRON_FILE)
            backup_server = os.getenv("BACKUP_SERVER", "")
            archive_path = os.getenv("ARCHIVE_PATH", "")
            
            # Prepare environment variables for the subprocess
            env = os.environ.copy()
            env["BACKUP_SERVER"] = backup_server
            env["ARCHIVE_PATH"] = archive_path
            
            # Execute backup script with environment variables loaded
            try:
                result = subprocess.run(
                    ["/usr/local/bin/python3", "/app/utils/backup_catalog.py"],
                    env=env,
                    capture_output=True,
                    text=True,
                    timeout=30
                )
                output = result.stdout if result.returncode == 0 else result.stderr
                self.render("panel.html", error=None, result=output, 
                           backup_server=backup_server, archive_path=archive_path)
            except Exception as e:
                self.render("panel.html", error=f"Backup Error: {str(e)}", result="",
                           backup_server=backup_server, archive_path=archive_path)
            return
            
        self.render("panel.html", error="Invalid action", result="", backup_server="", archive_path="")
        
        
        

        
        
