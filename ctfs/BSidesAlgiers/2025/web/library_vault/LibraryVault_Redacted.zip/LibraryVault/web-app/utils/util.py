import random
import string

def rand_search(length):
    """Generate a random search query"""
    words = [
        "python", "javascript", "history", "science", "fiction", "mystery",
        "romance", "thriller", "fantasy", "biography", "poetry", "drama",
        "adventure", "horror", "classic", "modern", "ancient", "medieval"
    ]
    return " ".join(random.choices(words, k=length))

def rand_string(length):
    """Generate a random string"""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))
