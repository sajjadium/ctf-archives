from handlers.base import BaseHandler

class NotFoundHandler(BaseHandler):
    def prepare(self):
        self.set_status(404)
        self.render("error.html", error="Page not found.")
        
