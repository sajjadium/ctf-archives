"""Bot runner used by the report endpoint.

This module prefers Selenium if available; otherwise it falls back to Playwright.
It also ensures the local `config.py` in `web-app` is importable regardless of cwd.
"""
import os
import sys
import time
import traceback

# Make sure the web-app package root is importable so config.py can be loaded
HERE = os.path.dirname(__file__)
WEBAPP_ROOT = os.path.normpath(os.path.join(HERE, '..'))
if WEBAPP_ROOT not in sys.path:
    sys.path.insert(0, WEBAPP_ROOT)

from config import ADMIN_PASS



class BaseBot:
    def visit(self, url: str):
        raise NotImplementedError()

    def close(self):
        pass


def _selenium_bot():
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.options import Options
        from selenium.webdriver.chrome.service import Service
    except Exception:
        return None

    class SeleniumBot(BaseBot):
        def __init__(self):
            chrome_options = Options()
            # Headless mode
            chrome_options.add_argument("--headless=new")
            # Disable GPU and enable sandbox safety
            chrome_options.add_argument("--disable-gpu")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            # Resource saving
            chrome_options.add_argument("--disable-extensions")
            chrome_options.add_argument("--disable-sync")
            chrome_options.add_argument("--disable-plugins-discovery")
            chrome_options.add_argument("--disable-component-update")
            chrome_options.add_argument("--disable-default-apps")
            chrome_options.add_argument("--disable-features=VizDisplayCompositor")
            # Reduce memory footprint
            
            chrome_options.add_argument("--renderer-process-limit=10")
            # Disable images to reduce bandwidth/memory
            prefs = {"profile.managed_default_content_settings.images": 2}
            chrome_options.add_experimental_option("prefs", prefs)
            chrome_options.add_argument("--disable-infobars")
            chrome_options.add_argument("--window-size=800,600")
            
            service = None
            try:
                # Try preinstalled chromedriver first
                cd_path = os.environ.get("BOT_CHROMEDRIVER_PATH") or "/usr/local/bin/chromedriver"
                if os.path.isfile(cd_path):
                    print(f"[+] Using chromedriver at {cd_path}")
                    service = Service(cd_path)
                    self.driver = webdriver.Chrome(service=service, options=chrome_options)
                else:
                    print(f"[*] Chromedriver not at {cd_path}, attempting fallback...")
                    raise FileNotFoundError(f"Chromedriver not found at {cd_path}")
            except Exception as e:
                print(f"[*] Preinstalled chromedriver failed ({e}), using webdriver-manager...")
                try:
                    from webdriver_manager.chrome import ChromeDriverManager
                    service = Service(ChromeDriverManager().install())
                    self.driver = webdriver.Chrome(service=service, options=chrome_options)
                except Exception as e2:
                    print(f"[-] webdriver-manager also failed ({e2}), trying auto-discovery...")
                    self.driver = webdriver.Chrome(options=chrome_options)

        def visit(self, url: str):
            # Longer timeout for resource-constrained environments
            self.driver.set_page_load_timeout(10)
            try:
                # Navigate to login
                login_url = 'http://127.0.0.1:1337/login'
                print(f"[+] Navigating to login: {login_url}")
                self.driver.get(login_url)
                time.sleep(2)
                
                # Fill login form
                print("[+] Logging in as admin...")
                username = self.driver.find_element("name", "username")
                password = self.driver.find_element("name", "password")
                username.send_keys("admin")
                password.send_keys(ADMIN_PASS)
                
                submit = self.driver.find_element("name", "submit")
                submit.click()
                time.sleep(2)
                
                # Navigate to target URL
                print(f"[+] Navigating to: {url}")
                self.driver.get(url)
                time.sleep(1)
                print(f"[+] Page title: {self.driver.title}")
            except Exception as e:
                print(f"[-] Bot navigation error: {e}")
                traceback.print_exc()

        def close(self):
            try:
                self.driver.quit()
            except Exception:
                pass

    return SeleniumBot


def _playwright_bot():
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return None

    class PlaywrightBot(BaseBot):
        def __init__(self):
            self._playwright = sync_playwright().start()
            self.browser = self._playwright.chromium.launch(headless=True)
            self.context = self.browser.new_context(viewport={"width": 1920, "height": 1080})
            self.page = self.context.new_page()

        def visit(self, url: str):
            self.page.set_default_navigation_timeout(15000)
            try:
                self.page.goto('http://127.0.0.1:1337/login')
                time.sleep(1)
                self.page.fill('input[name="username"]', 'admin')
                self.page.fill('input[name="password"]', ADMIN_PASS)
                try:
                    self.page.click('button[name="submit"]')
                except Exception:
                    try:
                        self.page.click('input[name="submit"]')
                    except Exception:
                        pass
                time.sleep(2)
                self.page.goto(url)
                time.sleep(1)
            except Exception as e:
                print(f"Bot navigation error: {e}")

        def close(self):
            try:
                self.context.close()
                self.browser.close()
            except Exception:
                pass

    return PlaywrightBot


def get_bot_class():
    BotClass = _selenium_bot()
    if BotClass is not None:
        return BotClass
    BotClass = _playwright_bot()
    if BotClass is not None:
        return BotClass
    return None


if __name__ == '__main__':
    try:
        url = sys.argv[1]
    except Exception:
        print('Usage: bot.py <url>')
        sys.exit(2)

    BotClass = get_bot_class()
    if BotClass is None:
        print('No browser automation backend available (selenium or playwright).')
        sys.exit(1)

    bot = BotClass()
    try:
        bot.visit(url)
    except Exception:
        traceback.print_exc()
    finally:
        try:
            bot.close()
        except Exception:
            pass