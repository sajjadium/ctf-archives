import aiosqlite
import json
from contextlib import asynccontextmanager
from config import ADMIN_PASS

DATABASE = "/tmp/library.db"

@asynccontextmanager
async def get_connection():
    conn = await aiosqlite.connect(DATABASE)
    try:
        yield conn
    finally:
        await conn.close()

async def create_tables():
    async with get_connection() as conn:
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS books (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                author TEXT NOT NULL,
                year INTEGER,
                verified INTEGER DEFAULT 0
            )
        """)
        await conn.execute("""
            CREATE TABLE IF NOT EXISTS searches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await conn.commit()

async def fill_tables():
    async with get_connection() as conn:
        
        async with conn.execute("SELECT * FROM users WHERE username='admin'") as cursor:
            if not await cursor.fetchone():
                from db.utils import hash_password
                await conn.execute("INSERT INTO users (username, password) VALUES (?, ?)", 
                                 ("admin", hash_password(ADMIN_PASS)))
        
        
        async with conn.execute("SELECT COUNT(*) FROM books") as cursor:
            count = (await cursor.fetchone())[0]
            if count == 0:
                
                with open("db/books.json", "r") as f:
                    books_data = json.load(f)
                    for book in books_data:
                        await conn.execute(
                            "INSERT INTO books (title, author, year, verified) VALUES (?, ?, ?, ?)",
                            (book["title"], book["author"], book.get("year"), book.get("verified", 1))
                        )
        
        await conn.commit()
