from handlers.base import BaseHandler
from db.utils import insert_user, login_user

class LoginHandler(BaseHandler):
    def get(self):
        self.render("login.html", error=None)

    async def post(self):
        username = self.get_argument("username", default=None)
        password = self.get_argument("password", default=None)
        if not username or not password:
            self.render("login.html", error="Username and password are required.")
            return
        if await login_user(username, password):
            self.set_secure_cookie("username", username, httponly=False)
            self.redirect("/books")
        else:
            self.render("login.html", error="Invalid username or password.")

class RegisterHandler(BaseHandler):
    def get(self):
        self.render("register.html", error=None)

    async def post(self):
        username = self.get_argument("username", default=None)
        password = self.get_argument("password", default=None)
        if not username or not password:
            self.render("register.html", error="Username and password are required.")
            return
        if username == "admin":
            self.render("register.html", error="Username is not allowed.")
            return
        if await insert_user(username, password):
            self.set_secure_cookie("username", username, httponly=True)
            self.redirect("/books")
        else:
            self.render("register.html", error="Username already exists.")

class LogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("username")
        self.redirect("/")
