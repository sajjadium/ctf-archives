from handlers.base import BaseHandler
from db.connection import get_connection
from db.utils import insert_book

class ApiBooksHandler(BaseHandler):
    async def get(self):
        async with get_connection() as conn:
            async with conn.execute("SELECT title, author, year FROM books WHERE verified = 1 ORDER BY RANDOM() LIMIT 10") as cursor:
                books = await cursor.fetchall()
                books = [{"title": row[0], "author": row[1], "year": row[2]} for row in books]
        self.write({"books": books})
    
    async def post(self):
        title = self.get_argument("title", default=None)
        author = self.get_argument("author", default=None)
        year = self.get_argument("year", default=None)
        if not title or not author:
            self.set_status(400)
            self.write({"error": "Title and author are required."})
            return
        if await insert_book(title, author, year, verified=False):
            self.write({"status": "success", "message": "Book submitted for review."})
        else:
            self.set_status(500)
            self.write({"error": "Failed to submit book."})
