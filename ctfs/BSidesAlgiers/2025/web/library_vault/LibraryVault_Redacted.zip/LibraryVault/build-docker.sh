#!/bin/bash
docker rm -f library_vault
docker build --tag=library_vault .
docker run --name=library_vault --rm -p1337:1337 -it library_vault
