const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const path = require('path');

const app = express();
const PORT = 3000;
const FLAG = process.env.FLAG || 'shellmates{fake_flag}';

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SECRET || 'supersecretsecret',
    resave: false,
    saveUninitialized: false
}));

// Constants
const COUPONS = {
    'WELCOME': 100,
    'BSIDESALGIERS': 200,
    'SALES2025': 300
};

const ITEMS = {
    'flag': { name: 'CTF Flag', price: '9999' },
    'sticker': { name: 'Hacker Sticker', price: '10' },
    'hoodie': { name: 'Black Hoodie', price: '50' }
};

let db;

// Middleware to load user
const loadUser = async (req, res, next) => {
    if (req.session.userId && db) {
        try {
            req.user = await db.get('SELECT * FROM users WHERE id = ?', [req.session.userId]);
        } catch (err) {
            console.error("DB Error:", err);
        }
    }
    next();
};

app.use(loadUser);

// --- Routes ---

app.get('/', async (req, res) => {
    if (!req.user) return res.redirect('/login');
    
    const inventory = await db.all('SELECT item FROM inventory WHERE user_id = ?', [req.user.id]);
    const inventoryItems = inventory.map(i => i.item);

    res.render('index', { 
        user: req.user, 
        coupons: COUPONS, 
        items: ITEMS,
        inventory: inventoryItems
    });
});

app.get('/coupon-info', async (req, res) => {
    const code = req.query.code || '';
    const query = `
        SELECT coupon_code 
        FROM redemptions 
        WHERE coupon_code = '${code.toUpperCase()}'
    `;

    try {
        const rows = await roDb.all(query);
        res.json({ success: true, rows });
    } catch (e) {
        res.json({ success: false, error: e.message });
    }
});

app.get('/login', (req, res) => res.render('login'));
app.get('/register', (req, res) => res.render('register'));

app.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if(!username || !password) return res.render('register', { error: 'Missing fields' });
    try {
        await db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
        res.redirect('/login');
    } catch (e) {
        res.render('register', { error: 'Username already exists' });
    }
});

app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
    if (user) {
        req.session.userId = user.id;
        res.redirect('/');
    } else {
        res.render('login', { error: 'Invalid credentials' });
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/login');
});

// Helper to update user in DB
async function updateUserInDb(user) {
    await db.run('UPDATE users SET balance = ? WHERE id = ?', [user.balance, user.id]);
}

app.post('/redeem', async (req, res) => {
    if (!req.user) return res.status(403).json({ error: 'Not authorized' });

    let coupons = req.body.coupons;
    
    if (!Array.isArray(coupons)) {
        coupons = [coupons];
    }

    coupons.forEach(async (couponCode) => {
        if (COUPONS[couponCode]) {
            const redeemed = await db.get(
                'SELECT * FROM redemptions WHERE user_id = ? AND coupon_code = ?', 
                [req.user.id, couponCode]
            );
            if (!redeemed) {
                req.user.balance += COUPONS[couponCode];
                try {
                    await db.run('INSERT INTO redemptions (user_id, coupon_code) VALUES (?, ?)', [req.user.id, couponCode]);
                    await updateUserInDb(req.user); 
                } catch (err) {
                }
            }
        }
    });

    res.json({ success: true, message: 'Coupon Redeemed Sucessfully' });
});

app.post('/buy', async (req, res) => {
    if (!req.user) return res.status(403).json({ error: 'Not authorized' });
    
    const { item } = req.body;
    const product = ITEMS[item];

    if (!product) return res.json({ success: false, message: 'Item not found' });

    const price = parseInt(product.price);

    if (req.user.balance >= price) {
        req.user.balance -= price;
        await updateUserInDb(req.user);
        if (item !== 'flag') {
             await db.run('INSERT INTO inventory (user_id, item) VALUES (?, ?)', [req.user.id, item]);
        }

        if (item === 'flag') {
            return res.json({ success: true, message: `Congrats! Here is your flag: ${FLAG}` });
        }
        return res.json({ success: true, message: `You bought a ${product.name}` });
    } else {
        return res.json({ success: false, message: 'Insufficient funds' });
    }
});

app.post('/sell', async (req, res) => {
    if (!req.user) return res.status(403).json({ error: 'Not authorized' });
    
    const { item } = req.body;
    if(ITEMS[item] && item !== 'flag') {
        const hasItem = await db.get('SELECT id FROM inventory WHERE user_id = ? AND item = ?', [req.user.id, item]);
        
        if (hasItem) {
            const price = parseInt(ITEMS[item].price);
            req.user.balance += Math.floor(price / 2); 

            await db.run('DELETE FROM inventory WHERE id = ?', [hasItem.id]);
            await updateUserInDb(req.user);
            
            return res.json({ success: true, message: 'Item sold' });
        } else {
            return res.json({ success: false, message: 'You do not own this item' });
        }
    }
    res.json({ success: false, message: 'Cannot sell this item' });
});

(async () => {
    try {
        const DB_FILENAME = 'database.sqlite';

        db = await open({
            filename: DB_FILENAME,
            driver: sqlite3.Database
        });

        await db.exec(`
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT,
                balance INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS redemptions (
                user_id INTEGER,
                coupon_code TEXT,
                PRIMARY KEY (user_id, coupon_code)
            );
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                item TEXT
            );
        `);
        console.log('Database tables initialized');

        roDb = await open({
            filename: DB_FILENAME,
            driver: sqlite3.Database,
            mode: sqlite3.OPEN_READONLY
        });
        console.log('Read-Only connection established');
        app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
    } catch (err) {
        console.error('Failed to initialize database:', err);
    }
})();