#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

struct state {
    uint8_t s[256];
    uint8_t i;
    uint8_t j;
};


// Our reverse engineer managed to create this pseudo code to explain what the stager was doing before it crashed

int main(int argc, char **argv) {
    (void)argc;
    const char *state_path = "state";
    const char *zip_source = "config.zip"; 

    struct state ctx;
    if (load_state(state_path, &ctx) != 0) {
        return 1;
    }

    size_t zip_len = 0;
    uint8_t *zip_buf = load(zip_source, &zip_len);



    char cmd[256];
    snprintf(cmd, sizeof(cmd), "unzip \"/tmp/config.zip\" >/dev/null 2>&1"); //the zip was downloaded in stage 1 from the C2
    system(cmd);

    memset(zip_buf, 0, 30);
    

    size_t enc_len = 0;

    uint8_t *enc = load("config.bin", &enc_len);


    unlink("config.bin");
    unlink("/tmp/config.zip");
    unlink(zip_source);


    // the stager crashed here and we managed to recover a core dump

    if (decrypt(&ctx, enc, enc_len) != 0) {
        free(enc);
        free(zip_buf);
        return 1;
    }

    startInfoStealer(enc, enc_len);

    memset(enc, 0, enc_len);
    free(enc);
    free(zip_buf);
    return 0;

}
