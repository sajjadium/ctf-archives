# beginner/RTFM source

Developed with Bun, but should be possible in Node with some basic tweaks.
Can be ran with Docker
