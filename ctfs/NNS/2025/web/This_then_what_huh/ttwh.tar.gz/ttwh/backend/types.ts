export type Vector2 = {
    x: number;
    y: number;
};