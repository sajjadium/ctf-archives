package no.nnsctf.agebarrier.controller.model

data class ProductClaimResponseView(val content: String)
