package no.nnsctf.agebarrier.controller.model

data class ProductClaimRequest(val token: String)
