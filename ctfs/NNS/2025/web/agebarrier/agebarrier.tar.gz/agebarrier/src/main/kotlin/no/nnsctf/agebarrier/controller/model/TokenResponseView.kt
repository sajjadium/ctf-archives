package no.nnsctf.agebarrier.controller.model

data class TokenResponseView(val token: String)
