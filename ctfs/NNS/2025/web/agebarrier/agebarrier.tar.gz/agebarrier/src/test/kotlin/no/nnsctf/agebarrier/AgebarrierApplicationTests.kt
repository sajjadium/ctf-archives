package no.nnsctf.agebarrier

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AgebarrierApplicationTests {

    @Test
    fun contextLoads() {
    }

}
