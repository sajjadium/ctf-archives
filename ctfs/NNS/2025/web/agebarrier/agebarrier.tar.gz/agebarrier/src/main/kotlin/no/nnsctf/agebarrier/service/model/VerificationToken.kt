package no.nnsctf.agebarrier.service.model

import java.time.LocalDate

data class VerificationToken(
    val date: LocalDate
)
