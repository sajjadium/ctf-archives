# Guardrails
## Running locally
1. Install rust
2. Run `cargo run`
3. The API should now run on `http://localhost:8000`
