# Setting up
```sh
npm i

```
Then update the backend url found in `src/api.ts`

# Running the server
```sh
npm run dev
```