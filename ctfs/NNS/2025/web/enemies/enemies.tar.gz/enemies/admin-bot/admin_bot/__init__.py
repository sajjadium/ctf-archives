# This needs to be here or python refuses to see the __main__ file
# Thanks python.
