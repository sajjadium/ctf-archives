# Setup
```sh
pip install poetry
poetry install
```
# Running the backend
```sh
poetry run python3 -m admin_bot
```

# Resetting the database
```sh
rm app.sqlite
```
