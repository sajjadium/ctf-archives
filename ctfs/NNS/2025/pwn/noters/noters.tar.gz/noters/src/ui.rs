pub mod cli;
pub mod io;

pub use crate::{MenuError, NoteError, PartialNote, Result};
