var express = require('express')
var cookieParser = require('cookie-parser')
const { randomBytes, createHmac } = require('node:crypto');

const winMessages = [
    `Ha! My %serverChoice% crushed your pathetic %userChoice%! Try harder next time!`,
    `Too easy! My %serverChoice% obliterates your weak %userChoice%!`,
    `Boom! Another win for me! Your %userChoice% never stood a chance!`,
    `Oof, that was embarrassing! My %serverChoice% dominates!`,
    `You really thought %userChoice% could beat %serverChoice%? That's adorable, %username%!`,
];

const loseMessages = [
    `What?! Your %userChoice% beat my %serverChoice%? Must be a glitch...`,
    `Fine, you got this round... but don't get cocky, %username%!`,
    `Lucky win! Enjoy it while it lasts!`,
    `I demand a rematch! No way your %userChoice% should've beaten my %serverChoice%!`,
    `Ugh, I let you win... yeah, that's it. Next time, you're toast!`,
    `Noooo! Your %userChoice% actually beat my %serverChoice%?! This must be some kind of sorcery, %username%!`

];

const drawMessages = [
    `A tie? Lame! My %serverChoice% and your %userChoice% cancel out!`,
    `We both chose %serverChoice%... What are the odds? Too bad for you, %username%!`,
    `No winners, no losers, just disappointment! Let's settle this!`,
    `A tie? I don't like sharing the spotlight, %username%!`
];

const choices = ["web", "misc", "crypto"];
const results = {
    web: {
        web: "draw",
        misc: "loss",
        crypto: "win"
    },
    misc: {
        web: "win",
        misc: "draw",
        crypto: "loss"
    },
    crypto: {
        web: "loss",
        misc: "win",
        crypto: "draw"
    }
}


var DB = {};

var app = express();
app.use(cookieParser());


app.use('', express.static('./public'));

app.get('/start', (req, res) => {
    var gameId = crypto.randomUUID();
    DB[gameId] = {
        serverSecret: randomBytes(32).toString('hex'),
        round: 0,
        wins: 0,
        usedClientSeeds: {}
    }
    res.cookie("gameId", gameId);
    res.json({success: true});
})


app.get('/play', (req, res) => {
    var gameId = req.cookies.gameId;
    if(!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-5][0-9a-f]{3}-[089ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(gameId)) {
        res.json({"message": "Wrong gameId"})
        return;
    }
    if(!DB[gameId]) {
        res.json({"message": "Game ended, start new one"})
        return;
    }
    if(DB[gameId].round == 100) {
        var message = "You need 100 wins to get the flag!"
        if(DB[gameId].wins == 100) {
            message = "Congrats, here is your flag: " + process.env["FLAG"];
        }
        res.json({message, round: 100})
        delete DB[gameId];
        return;
    }
    var { clientSeed, username, userChoice } = req.query;
    if(typeof clientSeed != "string" || clientSeed.length != 32) {
        res.json({"message": "invalid client seed"})
        return;
    }

    if(DB[gameId].usedClientSeeds[clientSeed]) {
        res.json({"message": "reused client seed"})
        return;
    }
    DB[gameId].usedClientSeeds[clientSeed] = true;

    if(!choices.includes(userChoice)) {
        res.json({"message": "invalid choice"});
        return;
    }
    const serverChoice = choices[createHmac('sha256', clientSeed).update(DB[gameId].serverSecret).digest()[0] % 3]; // seems like server likes web little bit more

    var result = results[userChoice][serverChoice];
    var data = {
        serverChoice,
        userChoice,
        username
    }
    var round = DB[gameId].round;
    if(result == "loss") {
        res.json({"message": winMessages[round % winMessages.length].replaceAll(/%(\w+)%/g, (_, name) => data[name]), result, round});
    } else if(result == "draw") {
        res.json({"message": drawMessages[round % drawMessages.length].replaceAll(/%(\w+)%/g, (_, name) => data[name]), result, round});
    } else if(result == "win") {
        res.json({"message": loseMessages[round % loseMessages.length].replaceAll(/%(\w+)%/g, (_, name) => data[name]), result, round});
        DB[gameId].wins++
    }
    DB[gameId].round++;

})
  
app.listen(8081)