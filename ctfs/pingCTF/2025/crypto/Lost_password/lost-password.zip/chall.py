from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from secrets import token_bytes
from binascii import hexlify
import hashlib
import os

KEY = token_bytes(32)
IV = token_bytes(16)
BLOCK_SIZE = 16

def xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

def hash(data):
    padded = pad(data, BLOCK_SIZE)
    cipher = AES.new(KEY, AES.MODE_CBC, IV)
    h = cipher.decrypt(padded)
    out = b"\x00"*32
    
    for block in [h[i:i+BLOCK_SIZE] for i in range(0, len(h), BLOCK_SIZE)]:
        out = xor(out, hashlib.sha256(block).digest())
    return out
    

target = hash(token_bytes(32))
print(f"I have lost my password, all I got is this hash: {hexlify(target).decode('utf-8')}")
print("Can you help me recover it? I will reward you with a flag!")
while True:
    password = bytes(input("Enter password: "), "utf-8")
    hashed = hash(password)
    if target == hashed:
        print("Thank you!")
        print(f"Here is your flag: {os.environ['FLAG']}")
        break
    print("This is not my password, hashes dont match!")
    print(f"Provided password hash: {str(hexlify(hashed).decode('utf-8'))}")
