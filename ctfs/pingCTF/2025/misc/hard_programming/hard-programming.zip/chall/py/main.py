#!/usr/bin/env python3
import http.server
import logging
import io
import sys
import subprocess


def eval2(expression):
    old_stdout = sys.stdout
    sys.stdout = io.StringIO()
    try:
        output = subprocess.check_output(["python3", "-c", expression])
        output = output.decode()
    finally:
        sys.stdout = old_stdout
    return output

class HTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        # Read and decode the request body
        body = self.rfile.read(content_length).decode('utf-8')
        try:
            # Evaluate the expression from the request body using a restricted environment
            result = eval2(body)
            result_str = str(result)
        except Exception as e:
            logging.error(f"Error evaluating expression: {e}")
            result_str = "Error evaluating expression."
        # Send a 200 OK response with the evaluated result
        self.send_response(200)
        self.end_headers()
        self.wfile.write(result_str.encode('utf-8'))

if __name__ == '__main__':
    server_address = ('', 80)
    httpd = http.server.HTTPServer(server_address, HTTPRequestHandler)
    httpd.serve_forever()
