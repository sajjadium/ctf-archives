package main

import (
	"fmt"
	"io"
	"log/slog"
	"math/rand"
	"net/http"
	"os"
	"strings"

	"github.com/lmittmann/tint"
)

var flag string

func init() {
	w := os.Stderr
	logger := slog.New(
		tint.NewHandler(w, &tint.Options{
			ReplaceAttr: func(groups []string, a slog.Attr) slog.Attr {
				if a.Key == slog.TimeKey && len(groups) == 0 {
					return slog.Attr{}
				}
				return a
			},
		}),
	)
	slog.SetDefault(logger)
	flag = os.Getenv("FLAG")
	if flag == "" {
		panic("no FLAG env")
	}
}

func get(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	fmt.Fprint(w, `
		<!DOCTYPE html>
		<html>
		<head>
			<title>Submit Form</title>
		</head>
		<body>
			<h1>Submit Form</h1>
			<div>Provide a code that will print $JS_VAL after being executed by js, and $PY_VAL after being executed by python</div>
			<div>The values are randomly generated on the backend during the execution</div>
			<br />
			<form action="/submit" method="post">
				<label for="content">Content:</label><br>
				<textarea id="content" name="content" rows="10" cols="50"></textarea><br><br>
				<input type="submit" value="Submit">
			</form>
		</body>
		</html>
	`)
}

func randomInt(min, max int) int {
	return min + rand.Intn(max-min+1)
}

func runPythonCode(code string) (string, error) {
	resp, err := http.Post("http://py", "text/plain", strings.NewReader(code))
	if err != nil {
		return "", fmt.Errorf("error making POST request: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error reading response: %w", err)
	}

	return strings.TrimSpace(string(body)), nil
}

func runJsCode(code string) (string, error) {
	resp, err := http.Post("http://js", "text/plain", strings.NewReader(code))
	if err != nil {
		return "", fmt.Errorf("error making POST request: %w", err)
	}
	defer resp.Body.Close()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("error reading response: %w", err)
	}

	return strings.TrimSpace(string(body)), nil
}

func submit(w http.ResponseWriter, req *http.Request) {
	if req.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	if err := req.ParseForm(); err != nil {
		http.Error(w, "Failed to parse form", http.StatusBadRequest)
		return
	}

	// check for invalid content
	content := req.FormValue("content")
	if content == "" || len(content) > 100 {
		http.Error(w, "invalid content 1", http.StatusBadRequest)
		return
	}
	for _, r := range content {
		// allow space from unreadable chars, but nothing more
		if r != 10 && (r < 32 || r > 126) {
			slog.Info("character failed", "rune int (run chr(r) in python to see which character is forbidden)", r)
			http.Error(w, "invalid content 2", http.StatusBadRequest)
			return
		}
	}
	jsVal := fmt.Sprintf("%d", randomInt(100000, 999999))
	pyVal := fmt.Sprintf("%d", randomInt(100000, 999999))
	content = strings.ReplaceAll(content, "$JS_VAL", jsVal)
	content = strings.ReplaceAll(content, "$PY_VAL", pyVal)
	slog.Info(
		"Received content",
		"js val", jsVal,
		"py val", pyVal,
		"content", content,
	)

	// run in python
	pyOut, err := runPythonCode(content)
	if err != nil {
		slog.Warn("something fishy's going on python", "err", err)
		http.Error(w, "read the question more carefully", http.StatusBadRequest)
		return
	}
	if pyOut != pyVal {
		slog.Warn("python executed but val is not right", "out", pyOut)
		http.Error(w, "read the question more carefully", http.StatusBadRequest)
		return
	}
	slog.Info("ok python passed", "content", content)

	// run in js
	jsOut, err := runJsCode(content)
	if err != nil {
		slog.Warn("something fishy's going on js", "err", err)
		http.Error(w, "read the question more carefully", http.StatusBadRequest)
		return
	}
	if jsOut != jsVal {
		slog.Warn("js executed but val is not right", "out", jsOut)
		http.Error(w, "read the question more carefully", http.StatusBadRequest)
		return
	}
	slog.Info("ok js passed", "content", content)

	slog.Info("winner winner chicken dinner", "content", content)
	fmt.Fprint(w, flag)
}

func main() {
	http.HandleFunc("/", get)
	http.HandleFunc("/submit", submit)
	slog.Info("starting listening on :8111")
	err := http.ListenAndServe(":8111", nil)
	if err != nil {
		panic(err)
	}
}
