import sqlite3
from time import sleep

from selenium import webdriver


def get_my_key():
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM api_keys")
    key = cursor.fetchone()
    conn.close()
    return key[1]


def approve_keyboard(keyboard_id):
    options = webdriver.ChromeOptions()
    options.add_argument('--headless')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-gpu')
    options.add_argument('--disable-extensions')
    driver = webdriver.Chrome(options=options)
    driver.get(f'http://localhost:5000/keyboard/{keyboard_id}')
    driver.add_cookie({'name': 'auth', 'value': get_my_key()})
    driver.refresh()
    sleep(3)
    driver.find_element('id', 'approve_btn').click()
    sleep(6)
    driver.close()

