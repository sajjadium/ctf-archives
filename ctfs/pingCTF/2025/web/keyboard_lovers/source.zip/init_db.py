import sqlite3
import os
from random import SystemRandom

if __name__ == '__main__':
    print("Initializing database...")
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("DROP TABLE IF EXISTS keyboards")
    cursor.execute("DROP TABLE IF EXISTS ratings")
    cursor.execute("DROP TABLE IF EXISTS api_keys")
    cursor.execute("CREATE TABLE keyboards (id INTEGER PRIMARY KEY, name TEXT, brand TEXT, description "
                   "TEXT, approved BOOLEAN DEFAULT FALSE)")
    cursor.execute("INSERT INTO keyboards (name, brand, description, approved) VALUES ('Ducky One 2 Mini', 'Ducky', "
                   "'<b>ideal for gaming</i> 60% keyboard', TRUE)")
    cursor.execute(
        "INSERT INTO keyboards (name, brand, description, approved) VALUES ('Anne Pro 2', 'Obins', '<i>blazingly fast</i> 60% keyboard', "
        "TRUE)")
    cursor.execute(
        "INSERT INTO keyboards (name, brand, description, approved) VALUES ('Keychron K6', 'Keychron', "
        "'65% keyboard', TRUE)")
    cursor.execute(
        f"INSERT INTO keyboards (name, brand, description) VALUES ('PINGboard', 'PING', '{os.getenv('PINGCTF_FLAG')}')")
    print(f"Storing flag: {os.getenv('PINGCTF_FLAG')}")
    cursor.execute("CREATE TABLE ratings (id INTEGER PRIMARY KEY, keyboard_id INTEGER, rating INTEGER) ")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (1, 5)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (1, 4)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (2, 5)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (2, 2)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (3, 1)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (3, 3)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (4, 5)")
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (4, 5)")
    cursor.execute("CREATE TABLE api_keys (id INTEGER PRIMARY KEY, key TEXT)")
    cursor.execute("INSERT INTO api_keys (key) VALUES (?)", (str(SystemRandom().randint(int(1e80), int(9e80))),))
    conn.commit()
    conn.close()
    print("Database initialized.")
