from flask import Flask, render_template, request, redirect
import sqlite3

import agent

app = Flask(__name__)


def calc_rating(ratings, keyboard_id):
    keyboard_ratings = [rating[2] for rating in ratings if rating[1] == keyboard_id]
    keyboard_rating = sum(keyboard_ratings) / len(keyboard_ratings) if len(keyboard_ratings) > 0 else 0
    keyboard_rating = int(keyboard_rating)
    return keyboard_rating


def is_admin(cookie):
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM api_keys WHERE key = ?", (cookie,))
    key = cursor.fetchone()
    return key is not None


@app.get('/')
def list_keyboards():
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM keyboards WHERE APPROVED = TRUE")
    keyboards = cursor.fetchall()
    ratings = cursor.execute("SELECT * FROM ratings").fetchall()
    results = list()
    for keyboard in keyboards:
        keyboard_id = keyboard[0]
        results.append({
            'id': keyboard[0],
            'name': keyboard[1],
            'brand': keyboard[2],
            'description': keyboard[3],
            'rating': calc_rating(ratings, keyboard_id)
        })
    conn.close()
    return render_template('index.html', keyboards=results)


@app.get('/keyboard/<int:keyboard_id>')
def get_keyboard(keyboard_id):
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM keyboards WHERE ID = ?", (keyboard_id,))
    keyboard = cursor.fetchone()
    if keyboard is None:
        return "Keyboard not found", 404
    cursor.execute("SELECT * FROM ratings WHERE KEYBOARD_ID = ?", (keyboard_id,))
    ratings = cursor.fetchall()
    result = {
        'id': keyboard[0],
        'name': keyboard[1],
        'brand': keyboard[2],
        'description': keyboard[3],
        'rating': calc_rating(ratings, keyboard_id),
        'approved': keyboard[4],
    }
    if not result['approved'] and not is_admin(request.cookies.get('auth')):
        return "Keyboard not found", 404
    conn.close()
    return render_template('rate.html', keyboard=result, sudo=is_admin(request.cookies.get('auth')))


@app.post('/keyboard/<int:keyboard_id>')
def rate_keyboard(keyboard_id):
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO ratings (keyboard_id, rating) VALUES (?, ?)",
                   (keyboard_id, int(request.form['rating'])))
    conn.commit()
    conn.close()
    return redirect(f'/keyboard/{keyboard_id}')


@app.get('/submit')
def submit_keyboard_form():
    return render_template('submit.html')


@app.post('/submit')
def submit_keyboard():
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO keyboards (name, brand, description) VALUES (?, ?, ?)",
                   (request.form['name'], request.form['brand'], request.form['description']))
    conn.commit()
    conn.close()
    new_id = cursor.lastrowid
    agent.approve_keyboard(new_id)
    return redirect('/?submitted')


@app.post('/keyboard/<int:keyboard_id>/approve')
def approve_keyboard(keyboard_id):
    if not is_admin(request.cookies.get('auth')) or keyboard_id == 4:
        return redirect('/', 403)
    conn = sqlite3.connect('database.sqlite')
    cursor = conn.cursor()
    cursor.execute("UPDATE keyboards SET approved = TRUE WHERE ID = ?", (keyboard_id,))
    conn.commit()
    conn.close()
    return redirect('/?approved')


@app.after_request
def add_header(response):
    response.headers['CONTENT-SECURITY-POLICY'] = "default-src 'none';"\
                                                  " script-src https://*.googleapis.com 'sha256-FlG9O9q1cgn5OYucapSvUz43B/tZq3UVDljeyRiVWvs='; " \
                                                  "style-src https://cdn.jsdelivr.net https://*.googleapis.com 'unsafe-inline'; "\
                                                  "img-src 'self'; " \
                                                  "connect-src 'self';" \
                                                  "font-src https://fonts.gstatic.com; " \
                                                  "form-action 'self'; block-all-mixed-content; " \
                                                  "upgrade-insecure-requests; "
    return response


if __name__ == '__main__':
    print("Starting server...")
    app.run()
