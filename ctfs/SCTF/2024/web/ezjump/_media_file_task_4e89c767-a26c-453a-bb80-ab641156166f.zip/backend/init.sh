#!/bin/bash

python /app/app.py