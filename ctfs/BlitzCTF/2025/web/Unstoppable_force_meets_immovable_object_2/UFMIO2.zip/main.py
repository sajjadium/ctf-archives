from flask import Flask, redirect, render_template, request, url_for
from secret import FLAG

app = Flask(__name__)


def complex_custom_hash(data_string):
    if not isinstance(data_string, str):
        raise TypeError("Input must be a string.")

    data_bytes = data_string.encode("utf-8")

    P = 2**61 - 1
    B = 101

    hash_val = 0

    for byte_val in data_bytes:
        hash_val = (hash_val * B + byte_val) % P

    length_mix = (len(data_bytes) * 123456789) % P
    hash_val = (hash_val + length_mix) % P

    chunk_size = 40
    num_chunks = 64 // chunk_size

    folded_hash = 0
    temp_hash = hash_val

    for _ in range(num_chunks):
        chunk = temp_hash & ((1 << chunk_size) - 1)
        folded_hash = (folded_hash + chunk) % (1 << chunk_size)
        temp_hash >>= chunk_size

    final_small_hash = folded_hash

    scrambled_hash = 0
    for _ in range(3):
        scrambled_hash = (
            final_small_hash ^ (final_small_hash >> 7) ^ (final_small_hash << 3)
        ) & ((1 << chunk_size) - 1)
        final_small_hash = scrambled_hash

    return f"{scrambled_hash:04x}"


@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username != password and complex_custom_hash(
            password
        ) == complex_custom_hash(username):
            return FLAG
        return redirect(url_for("home"))

    url_for("static", filename="style.css")
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0")
