from flask import Flask, redirect, render_template, request, url_for
from secret import FLAG

app = Flask(__name__)

NOT_PASSWORD = "P@ssword@123"


def immovable_object(data, block_size=32):
    if len(data) % block_size != 0:
        data += b"\0" * (block_size - (len(data) % block_size))

    h = 0
    for i in range(0, len(data), block_size):
        block = int.from_bytes(data[i : i + block_size], "big")
        h ^= block

    return h


@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        password = request.form["password"]
        unstopabble_force = immovable_object(password.encode("utf-8"))
        if password != NOT_PASSWORD and unstopabble_force == immovable_object(
            NOT_PASSWORD.encode()
        ):
            return FLAG
        return redirect(url_for("home"))

    url_for("static", filename="style.css")
    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=False, host="0.0.0.0")
