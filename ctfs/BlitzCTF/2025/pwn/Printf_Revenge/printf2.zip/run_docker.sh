#!/bin/bash

sudo docker build -t printf2 .
sudo docker run -d -p 1337:1337 --rm -it printf 2
