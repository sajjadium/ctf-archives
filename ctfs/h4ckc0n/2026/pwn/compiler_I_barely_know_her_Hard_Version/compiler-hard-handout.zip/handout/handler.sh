#!/usr/bin/env bash
set -u

CHAL_DIR="${CHAL_DIR:-/opt/chal}"
CLANG="${CLANG:-/usr/lib/llvm/22/bin/clang}"
DSLC="${DSLC:-$CHAL_DIR/dslc}"
MAX_SRC_BYTES="${MAX_SRC_BYTES:-65536}"
UPLOAD_TIMEOUT="${UPLOAD_TIMEOUT:-30}"
COMPILE_TIMEOUT="${COMPILE_TIMEOUT:-30}"
RUN_TIMEOUT="${RUN_TIMEOUT:-5}"

say(){ printf '%s\n' "$*"; }
WORK="$(mktemp -d /tmp/chal.XXXXXX)" || { say "server error"; exit 1; }
cleanup(){ rm -rf "$WORK"; }
trap cleanup EXIT
cd "$WORK" || exit 1

say "== optimizing compiler :: HARD =="
say "Send your .dsl program, then a line with __EOF__ (max ${MAX_SRC_BYTES} bytes):"

: > prog.dsl
bytes=0
while IFS= read -r -t "$UPLOAD_TIMEOUT" line; do
    [ "$line" = "__EOF__" ] && break
    printf '%s\n' "$line" >> prog.dsl
    bytes=$((bytes + ${#line} + 1))
    if [ "$bytes" -gt "$MAX_SRC_BYTES" ]; then say "error: source too large"; exit 0; fi
done
[ -s prog.dsl ] || { say "error: empty source"; exit 0; }

cp "$CHAL_DIR/runtime.o"    "$WORK/runtime.o"
cp "$CHAL_DIR/compilerIBarelyKnowHerHard.so" "$WORK/compilerIBarelyKnowHerHard.so"
cp "$CHAL_DIR/dslc"         "$WORK/dslc" 2>/dev/null || true
cp "$CHAL_DIR/flag.txt"     "$WORK/flag.txt" 2>/dev/null || true

say "== compiling =="
if ! python3 "$DSLC" prog.dsl -o prog.ll 2> dslc.log; then
    say "== dslc failed =="; head -c 4000 dslc.log; exit 0
fi
(
    ulimit -t 40
    ulimit -v 2000000
    ulimit -f 100000
    ulimit -u "${COMPILE_NPROC:-16384}"
    exec timeout "$COMPILE_TIMEOUT" "$CLANG" -O1 \
        -fpass-plugin=./compilerIBarelyKnowHerHard.so \
        -fstack-protector-strong -fPIE -pie -fcf-protection=none \
        -Wl,--dynamic-linker="$CHAL_DIR/ld-linux-x86-64.so.2" \
        -Wl,-rpath,"$CHAL_DIR" \
        prog.ll runtime.o -o prog 2>&1
)
rc=$?
if [ "$rc" -ne 0 ] || [ ! -x prog ]; then say "error: compilation failed (rc=$rc)"; exit 0; fi

say "== running =="
NETNS=""
if command -v unshare >/dev/null 2>&1 && unshare -rn true 2>/dev/null; then NETNS="unshare -rn"; fi
(
    ulimit -t "$RUN_TIMEOUT"
    ulimit -v 500000
    ulimit -u "${RUN_NPROC:-16384}"
    exec timeout "$RUN_TIMEOUT" $NETNS ./prog
) 2>&1
say "== done =="
exit 0
