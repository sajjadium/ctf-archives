#ifndef HARD_RUNTIME_H
#define HARD_RUNTIME_H

void *rt_alloc(long long nelems);
void  rt_resize(void *desc, void *olddata, long long nelems);
void  rt_register(void (*fn)(void));
void  rt_print(long long v);
void  rt_finish(void);
void  rt_oob(void);
#endif
