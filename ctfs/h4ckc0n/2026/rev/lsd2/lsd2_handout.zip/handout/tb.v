`timescale 1ns/1ps
// Testbench for chall_net.v (modules `core` and `mix`).
//
//   $ verilator --binary --timing -j 0 -O3 -Wno-fatal --top-module tb -o sim tb.v chall_net.v   (~1 min to build)
//   $ obj_dir/sim +FLAG=<24 chars> +PX=<x> +PY=<y>   print the six levels of one pixel (~0.2 s)
//   $ obj_dir/sim +FLAG=<24 chars>                   render out.ppm (1024x1024; ~40 hours)
//
module tb;
    localparam N = 1024;

    reg         clk = 0, rst = 1;
    reg  [9:0]  px = 0, py = 0;
    reg  [31:0] chunk = 0;
    wire [7:0]  q;
    wire        done;
    core u_core (.clk(clk), .rst(rst), .px(px), .py(py), .chunk(chunk), .q(q), .done(done));

    reg  [7:0]  l0, l1, l2, l3, l4, l5;
    wire [7:0]  r, g, b;
    mix u_mix (.q0(l0), .q1(l1), .q2(l2), .q3(l3), .q4(l4), .q5(l5), .r(r), .g(g), .b(b));

    always #5 clk = ~clk;

    reg [191:0] flag;
    reg [7:0]   lv [0:6*N*N-1];
    integer     k, x, y, i, fd, sx, sy;

    task level(input integer kk, input integer xx, input integer yy, output [7:0] out);
        begin
            chunk = flag[191 - 32*kk -: 32];
            px = xx; py = yy;
            rst = 1; @(posedge clk); #1 rst = 0;
            @(posedge clk); while (!done) @(posedge clk);
            #1 out = q;
        end
    endtask

    initial begin
        flag = "d4rk{dummy_flag_xyz}c0de";
        if ($value$plusargs("FLAG=%s", flag)) ;
        if ($value$plusargs("PX=%d", sx) && $value$plusargs("PY=%d", sy)) begin
            for (k = 0; k < 6; k = k + 1) begin
                level(k, sx, sy, l0);
                $display("pixel (%0d,%0d) chunk %0d: level %0d", sx, sy, k, l0);
            end
            $finish;
        end
        for (k = 0; k < 6; k = k + 1)
            for (y = 0; y < N; y = y + 1)
                for (x = 0; x < N; x = x + 1)
                    level(k, x, y, lv[k*N*N + y*N + x]);
        fd = $fopen("out.ppm", "wb");
        $fwrite(fd, "P6\n%0d %0d\n255\n", N, N);
        for (i = 0; i < N*N; i = i + 1) begin
            l0 = lv[i];         l1 = lv[N*N + i];   l2 = lv[2*N*N + i];
            l3 = lv[3*N*N + i]; l4 = lv[4*N*N + i]; l5 = lv[5*N*N + i];
            #1 $fwrite(fd, "%c%c%c", r, g, b);
        end
        $fclose(fd);
        $finish;
    end
endmodule
