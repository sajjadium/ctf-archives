from dataclasses import dataclass, field
from typing import Dict, List


@dataclass
class User:
    username: str
    password: str
    email_visible: str
    email_delivery: str
    active: bool = False
    staff: bool = False


class DB:
    def __init__(self) -> None:
        self.users: Dict[str, User] = {}
        self.mails: List[dict] = []

    def add_user(self, u: User) -> None:
        self.users[u.username] = u

    def get_user(self, username: str):
        return self.users.get(username)

    def find_by_email(self, email_visible: str):
        for u in self.users.values():
            if u.email_visible == email_visible:
                return u
        return None

    def add_mail(self, mail: dict) -> None:
        self.mails.append(mail)

    def inbox_for(self, delivery_addr: str):
        return [m for m in self.mails if m.get("to") == delivery_addr]


db = DB()
