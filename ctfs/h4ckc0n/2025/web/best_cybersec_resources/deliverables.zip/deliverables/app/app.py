import os
import secrets
import re
from flask import Flask, render_template, request, redirect, url_for, session, make_response, abort, flash
from .models import User, db
from .utils import allowed_domain, is_staff
from .mailer import send_mail

APP_SECRET = os.environ.get("APP_SECRET", secrets.token_hex(16))
FLAG = os.environ.get("FLAG")
BASE_DOMAIN = "d4rkc0de.in"


def create_app():
    app = Flask(__name__)
    app.secret_key = APP_SECRET

    @app.after_request
    def set_headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "no-referrer"
        resp.headers["Permissions-Policy"] = "geolocation=()"
        return resp

    def require_login():
        if not session.get("user"):
            abort(403)

    def get_current_user():
        uname = session.get("user")
        if not uname:
            return None
        return db.get_user(uname)

    def get_csrf():
        tok = session.get("csrf")
        if not tok:
            tok = secrets.token_urlsafe(16)
            session["csrf"] = tok
        return tok

    def check_csrf():
        tok = request.form.get("csrf")
        if not tok or tok != session.get("csrf"):
            abort(400)

    @app.route("/")
    def home():
        return render_template("index.html", base_domain=BASE_DOMAIN)

    @app.route("/about")
    def about():
        return render_template("about.html")

    @app.route("/register", methods=["GET", "POST"])
    def register():
        if request.method == "GET":
            return render_template("register.html", csrf=get_csrf(), base_domain=BASE_DOMAIN)

        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        email = request.form.get("email", "").strip()

        if not username or not password or not email:
            flash("Something went wrong")
            return redirect(url_for("register"))

        if not allowed_domain(email):
            flash("Something went wrong")
            return redirect(url_for("register"))

        staff = is_staff(email)

        u = User(username=username, password=password, email_visible=email,
                 email_delivery="", active=False, staff=staff)
        db.add_user(u)

        confirm_link = url_for("confirm", user=username, _external=True)
        delivery = send_mail(email, "Welcome to d4rkc0de",
                             f"Click here to confirm: {confirm_link}")
        u.email_delivery = delivery

        flash("Okay")
        return redirect(url_for("login"))

    @app.route("/confirm")
    def confirm():
        user = request.args.get("user")
        u = db.get_user(user or "")
        if not u:
            abort(404)
        u.active = True
        flash("Okay")
        return redirect(url_for("login"))

    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "GET":
            return render_template("login.html", csrf=get_csrf())
        check_csrf()
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        u = db.get_user(username or "")
        if not u or u.password != password or not u.active:
            flash("Something went wrong")
            return redirect(url_for("login"))
        session["user"] = u.username
        flash("Okay")
        return redirect(url_for("profile"))

    @app.route("/logout")
    def logout():
        session.clear()
        return redirect(url_for("home"))

    @app.route("/profile")
    def profile():
        require_login()
        u = get_current_user()
        return render_template("profile.html", u=u)

    @app.route("/admin")
    def admin():
        require_login()
        u = get_current_user()
        if not (u and u.staff):
            abort(403)
        return render_template("admin.html")

    @app.route("/admin/rotate-ci-token", methods=["POST"])
    def rotate_ci_token():
        require_login()
        u = get_current_user()
        if not (u and u.staff):
            abort(403)
        check_csrf()
        return render_template("pwned.html", flag=FLAG)

    @app.route("/inbox")
    def inbox():
        to = request.args.get("to", "").strip()
        msgs = db.inbox_for(to)
        return render_template("inbox.html", msgs=msgs, to=to)

    return app


app = create_app()
