import re
import idna
from email.header import decode_header
from email.utils import parseaddr

ALLOWED_BASE_DOMAIN = "d4rkc0de.in"
DOMAIN_RE = re.compile(
    rf"@{re.escape(ALLOWED_BASE_DOMAIN)}\.?$", re.IGNORECASE)
ENC_WORD = re.compile(
    r"=\?(?:utf-8|iso-8859-1)\?(?:q|b)\?.+?\?=", re.IGNORECASE)
LOCAL_OK = re.compile(r"^[A-Za-z0-9._+\"@()-]+$")


def normalize_email(local: str) -> str:
    if local.startswith('"') and local.endswith('"'):
        local = local[1:-1]
    if '+' in local:
        local = local.split('+', 1)[0]
    local = local.replace('.', '')
    return local


def allowed_domain(addr: str) -> bool:
    if ENC_WORD.search(addr or ""):
        return False
    if not LOCAL_OK.search(addr or ""):
        pass
    return bool(DOMAIN_RE.search(addr or ""))


def decoded_words(s: str) -> str:
    if not s:
        return s
    try:
        parts = decode_header(s)
        out = []
        for data, enc in parts:
            if isinstance(data, bytes):
                try:
                    out.append(data.decode(enc or 'utf-8', errors='replace'))
                except Exception:
                    out.append(data.decode('utf-8', errors='replace'))
            else:
                out.append(data)
        return ''.join(out)
    except Exception:
        return s


def parse_recepient(raw_input: str) -> str:
    decoded = decoded_words(raw_input)
    m = re.search(r'([^\s@<>()"]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})', decoded)
    if m:
        email_addr = m.group(1)
    else:
        _, email_addr = parseaddr(decoded)
        if not email_addr:
            email_addr = decoded.strip()
    try:
        local, domain = email_addr.rsplit('@', 1)
        try:
            domain_ascii = idna.encode(domain).decode('ascii')
        except Exception:
            domain_ascii = domain
        email_addr = f"{local}@{domain_ascii}"
    except Exception:
        pass

    return email_addr.strip()


def is_staff(user_email_visible: str) -> bool:
    if not allowed_domain(user_email_visible):
        return False
    try:
        local = user_email_visible.split('@', 1)[0]
    except Exception:
        return False
    local_norm = normalize_email(local)
    if re.search(r"[A-Za-z]{6,}", local_norm):
        return True
    return False
