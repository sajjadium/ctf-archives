from flask import Flask, render_template, request, make_response, render_template_string, redirect, url_for
app = Flask(__name__)
import cipherutil

db = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def check():
    user = request.form.get('username')
    if user != "admin":
        resp = make_response(render_template('home.html', username=user))
        resp.set_cookie("user", user, path='/')
        resp.set_cookie("check", cipherutil.encrypt(user), path='/')
        return resp
    else:
        return redirect("/")

@app.route('/post', methods=['POST'])
def post():
    if cipherutil.encrypt(request.cookies.get('user')) == request.cookies.get('check'):
        #db[f"{request.cookies.get('check')}"] = request.form.get('input')
        print(request.form.get('input'))
        if isgood(request.form.get('input')):
            db[f"{request.cookies.get('check')}"] = request.form.get('input')
            return render_template('home.html', username=request.cookies.get('user'),resp="SUCCESS")
        else:
            return render_template('home.html', username=request.cookies.get('user'),resp="FAILURE")
    else:
        return redirect("/")

@app.route('/get/<post>', methods=['GET'])
def get(post):
    print(request.cookies.get('user'), cipherutil.encrypt("admin"), request.cookies.get('check'))
    if request.cookies.get('user') == "admin" and cipherutil.encrypt("admin") == request.cookies.get('check'):
        template = f"{db.get(post)}"
        return render_template_string(template)
    else:
        return render_template_string("ADMIN ACCESS REQUIRED")

def isgood(message):
    BANNED = [", ", ".", "_", "[", "]","\\", "x", "flag.txt"]
    for x in BANNED:
        if x in message:
            return False
    return True

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7070)