<?php
function sanitize_content($s) {
    $deny = [
        '/<\?php/i',
        '/\beval\b/i',
        '/\bassert\b/i',
        '/\bsystem\b/i',
        '/\bexec\b/i',
        '/shell_exec/i',
        '/\bpassthru\b/i',
        '/\bpopen\b/i',
        '/\bproc_open\b/i',
        '/base64_decode/i',
        '/call_user_func/i',
        '/preg_replace.*e/i',
        '/curl_init/i',
        '/fsockopen/i',
        '/\$\s*_GET\b/',
        '/\$\s*_POST\b/',
        '/\$\s*_REQUEST\b/',
        '/\$\s*_GLOBALS\b/'
    ];
    foreach ($deny as $rx) {
        if (preg_match($rx, $s)) {
            return $rx;
        }
    }
    return false;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = basename($_POST['filename'] ?? '');
    $content  = $_POST['content'] ?? '';

    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

    if (strlen($filename) < 3 || strlen($filename) > 64) {
        http_response_code(400);
        die("Invalid filename length");
    }

    if ($ext !== 'tpl') {
        http_response_code(400);
        die("Unsupported file type");
    }

    $hit = sanitize_content($content);
    if ($hit !== false) {
        http_response_code(406);
        die("Content rejected");
    }

    $ok = file_put_contents(__DIR__ . "/templates/" . $filename, $content, LOCK_EX);
    if ($ok === false) {
        http_response_code(500);
        die("Save failed");
    }

    header("Location: index.php");
    exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Template Manager</title>
  <style>
    body { font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif; padding: 24px; background: #fafafa; }
    textarea { width: 100%; height: 360px; font-family: ui-monospace, Menlo, Consolas, monospace; }
    .muted { color: #666; }
    .card { max-width: 920px; margin: 0 auto; border: 1px solid #ddd; padding: 16px; border-radius: 10px; background: #fff; box-shadow: 0 2px 6px rgba(0,0,0,.05); }
    input[type=text] { width: 240px; }
    button { margin-top: 12px; padding: 8px 14px; border: none; background: #007bff; color: #fff; border-radius: 6px; cursor: pointer; }
    button:hover { background: #0056b3; }
  </style>
</head>
<body>
  <div class="card">
    <h2>Edit Template</h2>
    <form method="POST">
      <div>
        <label>Filename: </label>
        <input type="text" name="filename" value="page.tpl" />
      </div>
      <div>
        <textarea name="content"><h1>Welcome</h1>
<p class="muted">Start editing your page here.</p></textarea>
      </div>
      <button type="submit">Save Template</button>
    </form>
  </div>
</body>
</html>
