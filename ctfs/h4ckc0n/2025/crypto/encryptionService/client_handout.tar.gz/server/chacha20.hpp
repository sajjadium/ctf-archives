#pragma once

#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* 32-bit word built from two 16-bit halves (little-endian: lo first). */
struct u32 {
    uint16_t lo, hi;
};

/* ---------- 32-bit ops using only 16-bit arithmetic ---------- */

static inline void u32_set(u32 &x, uint16_t lo, uint16_t hi){ x.lo=lo; x.hi=hi; }

static inline u32 u32_from_le4(const uint8_t *p){
    u32 r;
    r.lo = (uint16_t)p[0] | ((uint16_t)p[1] << 8);
    r.hi = (uint16_t)p[2] | ((uint16_t)p[3] << 8);
    return r;
}

static inline void u32_to_le4(const u32 &x, uint8_t *p){
    p[0] = (uint8_t)(x.lo & 0xFF);
    p[1] = (uint8_t)(x.lo >> 8);
    p[2] = (uint8_t)(x.hi & 0xFF);
    p[3] = (uint8_t)(x.hi >> 8);
}

static inline void u32_add(u32 &a, const u32 &b){
    uint32_t t = (uint32_t)a.lo + b.lo;        // uses 32-bit temp if available; safe on 16-bit too
    a.lo = (uint16_t)(t & 0xFFFF);
    a.hi = (uint16_t)(a.hi + b.hi + (uint16_t)(t >> 16));
}

static inline void u32_xor(u32 &a, const u32 &b){
    a.lo ^= b.lo; a.hi ^= b.hi;
}

/* 32-bit rotate-left implemented with 16-bit shifts only */
static inline void u32_rotl(u32 &x, unsigned r){
    r &= 31;
    if (r == 0) return;

    uint16_t lo = x.lo, hi = x.hi;
    if (r == 16){
        x.lo = hi; x.hi = lo;
        return;
    }
    if (r < 16){
        uint16_t new_lo = (uint16_t)((lo << r) | (hi >> (16 - r)));
        uint16_t new_hi = (uint16_t)((hi << r) | (lo >> (16 - r)));
        x.lo = new_lo; x.hi = new_hi;
    } else { /* r > 16 */
        unsigned s = r - 16;
        uint16_t new_lo = (uint16_t)((hi << s) | (lo >> (16 - s)));
        uint16_t new_hi = (uint16_t)((lo << s) | (hi >> (16 - s)));
        x.lo = new_lo; x.hi = new_hi;
    }
}

/* x += y; z ^= x; z <<<= r */
static inline void qr_step(u32 x[16], int a, int b, int c, int d, unsigned r){
    u32_add(x[a], x[b]);
    u32_xor(x[d], x[a]);
    u32_rotl(x[d], r);
}

/* ---------- ChaCha20 core (32-bit words emulated) ---------- */

struct ChaCha20Block {
    u32 state[16]; /* 4 constants | 8 key | 1 counter | 3 nonce  (IETF layout) */

    /* constants "expand 32-byte k" in little-endian 32-bit words */
    static u32 C0(){ static const uint8_t s[4] = { 'e','x','p','a' }; return u32_from_le4(s); }
    static u32 C1(){ static const uint8_t s[4] = { 'n','d',' ','3' }; return u32_from_le4(s); }
    static u32 C2(){ static const uint8_t s[4] = { '2','-','b','y' }; return u32_from_le4(s); }
    static u32 C3(){ static const uint8_t s[4] = { 't','e',' ','k' }; return u32_from_le4(s); }

    /* IETF variant: 32-byte key, 12-byte nonce, 32-bit counter */
    ChaCha20Block(const uint8_t key[32], const uint8_t nonce96[12], uint32_t counter = 0){
        state[0]  = C0(); state[1]  = C1(); state[2]  = C2(); state[3]  = C3();
        state[4]  = u32_from_le4(key +  0);
        state[5]  = u32_from_le4(key +  4);
        state[6]  = u32_from_le4(key +  8);
        state[7]  = u32_from_le4(key + 12);
        state[8]  = u32_from_le4(key + 16);
        state[9]  = u32_from_le4(key + 20);
        state[10] = u32_from_le4(key + 24);
        state[11] = u32_from_le4(key + 28);
        /* counter (little-endian 32-bit) */
        state[12].lo = (uint16_t)(counter & 0xFFFF);
        state[12].hi = (uint16_t)(counter >> 16);
        /* 96-bit nonce */
        state[13] = u32_from_le4(nonce96 + 0);
        state[14] = u32_from_le4(nonce96 + 4);
        state[15] = u32_from_le4(nonce96 + 8);
    }

    /* one 64-byte block -> result[64] */
    void next(uint8_t out[64]){
        u32 x[16];
        for (int i = 0; i < 16; ++i){ x[i] = state[i]; }

        /* 20 rounds = 10 double rounds */
        for (int i = 0; i < 10; ++i){
            /* column rounds */
            qr_step(x, 0, 4,  8,12,16);
            qr_step(x, 1, 5,  9,13,12);
            qr_step(x, 2, 6, 10,14, 8);
            qr_step(x, 3, 7, 11,15, 7);
            /* diagonal rounds */
            qr_step(x, 0, 5, 10,15,16);
            qr_step(x, 1, 6, 11,12,12);
            qr_step(x, 2, 7,  8,13, 8);
            qr_step(x, 3, 4,  9,14, 7);
        }

        /* add original state */
        for (int i = 0; i < 16; ++i){
            u32_add(x[i], state[i]);
        }

        /* serialize little-endian */
        for (int i = 0; i < 16; ++i){
            u32_to_le4(x[i], out + 4*i);
        }

        /* increment 32-bit counter state[12] */
        uint32_t t = (uint32_t)state[12].lo + 1u;
        state[12].lo = (uint16_t)(t & 0xFFFF);
    }
};