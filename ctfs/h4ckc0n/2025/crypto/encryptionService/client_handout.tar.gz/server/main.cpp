#include <iostream>
#include <vector>
#include <iterator>
#include <fstream>
#include "chacha20.hpp"

#ifdef _WIN32
#include <io.h>
#include <fcntl.h>
#endif

struct ChaCha20 {
    ChaCha20Block core;
    uint8_t buf[64];
    size_t pos;

    ChaCha20(const uint8_t key[32], const uint8_t nonce96[12], uint32_t counter = 0)
        : core(key, nonce96, counter), pos(64) {}

    void crypt(uint8_t *bytes, size_t n) {
        for (size_t i = 0; i < n; ++i) {
            if (pos >= 64) {
                core.next(buf);
                pos = 0;
            }
            bytes[i] ^= buf[pos++];
        }
    }

    uint32_t get_counter() const {
    return (static_cast<uint32_t>(core.state[12].hi) << 16) |
            static_cast<uint32_t>(core.state[12].lo);
}
};

uint32_t read_counter(const std::string& filename) {
    std::ifstream fin(filename, std::ios::in);
    uint32_t counter = 0;
    if (fin) fin >> counter;
    return counter;
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cin >> std::noskipws;

#ifdef _WIN32
    _setmode(_fileno(stdin), O_BINARY);
    _setmode(_fileno(stdout), O_BINARY);
#endif

    uint8_t key[32];
    for (int i = 0; i < 32; i++) key[i] = i;

    uint8_t nonce[12];
    {
        std::ifstream fin("nonce.txt", std::ios::binary);
        if (!fin.read(reinterpret_cast<char*>(nonce), sizeof(nonce))) {
            std::cerr << "Error: nonce.txt missing or invalid\n";
            return 1;
        }
    }

    uint32_t counter = read_counter("counter.txt");
    ChaCha20 enc(key, nonce, counter);

    std::vector<uint8_t> data(
        std::istreambuf_iterator<char>(std::cin),
        {}
    );

    if (!data.empty()) {
        enc.crypt(data.data(), data.size());

        // --- Directly fetch updated counter from ChaCha20 ---
        uint32_t updated_counter = enc.get_counter();

        std::ofstream fout("counter.txt", std::ios::trunc);
        if (fout) fout << updated_counter;
    }

    std::cout.write(reinterpret_cast<char*>(data.data()), data.size());
    std::cout.flush();

    return 0;
}
