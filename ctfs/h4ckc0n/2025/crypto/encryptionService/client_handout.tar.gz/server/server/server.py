# server.py
from flask import Flask, request, send_file
import os
import io

app = Flask(__name__)

# Example static secrets for CTF (in practice: random per container)
HERE = os.path.dirname(__file__)              # /app/server
APP_ROOT = os.path.abspath(os.path.join(HERE, ".."))  # /app

TOOL_PATH = os.path.join(APP_ROOT, "chacha20_tool")   # /app/chacha20_tool
import struct
import subprocess
with open(os.path.join(HERE, 'nonce.txt'), 'wb') as f1:
    f1.write(os.urandom(12))
with open(os.path.join(HERE, 'counter.txt'), 'w') as f2:
    f2.write("1")
def encrypt_png_body(png_bytes):
    header = png_bytes[:8]  # PNG signature
    out = bytearray(header)
    offset = 8
    COUNTER = 1
    

        
    while offset < len(png_bytes):
        # Read chunk length + type
        length = struct.unpack(">I", png_bytes[offset:offset+4])[0]
        ctype = png_bytes[offset+4:offset+8]
        data_start = offset + 8
        data_end = data_start + length
        crc_start = data_end
        crc_end = crc_start + 4

        chunk_data = png_bytes[data_start:data_end]
        crc = png_bytes[crc_start:crc_end]
        
        COUNTER = int(COUNTER)
        if ctype == b"IDAT":
            # Encrypt chunk data only
            result = subprocess.run(
                [TOOL_PATH],
                input=chunk_data,
		cwd=HERE,
                capture_output=True
            )
            enc_data = result.stdout
            
            import zlib
            new_crc = struct.pack(">I", zlib.crc32(ctype + enc_data) & 0xffffffff)

            out += struct.pack(">I", len(enc_data))
            out += ctype
            out += enc_data
            out += new_crc
        else:
            # Leave other chunks as is
            out += png_bytes[offset:crc_end]

            

        offset = crc_end
    
    return out

@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        return "No file uploaded", 400

    f = request.files["file"]
    file_bytes = f.read()

    # Encrypt file
    encrypted_bytes = encrypt_png_body(file_bytes)

    # Return encrypted file for download
    return send_file(
        io.BytesIO(encrypted_bytes),
        as_attachment=True,
        download_name="encrypted.png",
        mimetype="image/png"
    )

@app.route("/get_flag", methods=["GET"])
def get_flag():
    flag_path = os.path.join(os.path.dirname(__file__), "..", "flag.png")
    with open(flag_path, "rb") as f:
        flag_bytes = f.read()

    encrypted_bytes = encrypt_png_body(flag_bytes)

    return send_file(
        io.BytesIO(encrypted_bytes),
        as_attachment=True,
        download_name="flag_enc.png",
        mimetype="image/png"
    )


@app.route("/more_details/<path:filename>", methods=["GET"])
def more_details(filename):
    """Expose nonce.txt or counter.txt content safely."""
    allowed = {"nonce.txt", "counter.txt"}
    if filename not in allowed:
        abort(403, "Access denied")

    filepath = os.path.join(HERE, filename)
    if not os.path.exists(filepath):
        abort(404, "File not found")

    return send_file(filepath, as_attachment=False)
if __name__ == "__main__":
    # Run inside container on port 5000
    app.run(host="0.0.0.0", port=5000)

