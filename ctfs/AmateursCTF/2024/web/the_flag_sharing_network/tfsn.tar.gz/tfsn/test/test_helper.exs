ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(Tfsn.Repo, :manual)
