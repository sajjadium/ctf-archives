defmodule TfsnWeb.FeedHTML do
  use TfsnWeb, :html

  embed_templates "feed_html/*"
end
