defmodule Tfsn.Mailer do
  use Swoosh.Mailer, otp_app: :tfsn
end
