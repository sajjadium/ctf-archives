mod entrypoint;
pub mod processor;

use borsh::{
  BorshDeserialize,
  BorshSerialize,
  to_vec,
};

use solana_program::{
  instruction::{
    AccountMeta,
    Instruction,
  },
  system_program,
  pubkey::Pubkey,
};



#[derive(BorshSerialize, BorshDeserialize)]
pub enum ChallengeInstruction {
    Initialize { config_bump: u8, item0_bump: u8, item1_bump: u8, treasury_bump: u8},
    InitializeUser { user_bump: u8, user_id: u32},
    Deposit { user_bump: u8, amount: u64},
    Buy {user_bump: u8, config_bump: u8, item_bump: u8, item_id: u64, treasury_bump: u8, holding_bump: u8},
    UpdateOwner {config_bump: u8, new_owner: Pubkey},
}

pub fn initialize(program: Pubkey, owner: Pubkey, config: Pubkey, item0: Pubkey, item1: Pubkey, treasury: Pubkey, config_bump: u8, item0_bump: u8, item1_bump: u8, treasury_bump: u8) -> Instruction {
  Instruction {
        program_id: program,
        accounts: vec![
        AccountMeta::new(owner, true),
        AccountMeta::new(config, false),
        AccountMeta::new(item0, false),
        AccountMeta::new(item1, false),
        AccountMeta::new(treasury, false),
        AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&ChallengeInstruction::Initialize {config_bump, item0_bump, item1_bump, treasury_bump}).unwrap(),
    }
}

pub fn initialize_user(program: Pubkey, user: Pubkey, user_config: Pubkey, user_bump: u8, user_id: u32) -> Instruction {
  Instruction {
        program_id: program,
        accounts: vec![
        AccountMeta::new(user, true),
        AccountMeta::new(user_config, false),
        AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&ChallengeInstruction::InitializeUser {user_bump, user_id}).unwrap(),
    }
}

pub fn deposit(program: Pubkey, user: Pubkey, user_config: Pubkey, user_bump: u8, amount: u64) -> Instruction {
  Instruction {
        program_id: program,
        accounts: vec![
        AccountMeta::new(user, true),
        AccountMeta::new(user_config, false),
        AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&ChallengeInstruction::Deposit {user_bump, amount}).unwrap(),
    }
}

pub fn buy(program: Pubkey, user: Pubkey, user_config: Pubkey, system_config: Pubkey, treasury: Pubkey, holding: Pubkey, item: Pubkey, user_bump: u8, config_bump: u8, item_bump: u8, item_id: u64, treasury_bump: u8, holding_bump: u8) -> Instruction {
  Instruction {
        program_id: program,
        accounts: vec![
        AccountMeta::new(user, true),
        AccountMeta::new(user_config, false),
        AccountMeta::new(system_config, false),
        AccountMeta::new(treasury, false),
        AccountMeta::new(holding, false),
        AccountMeta::new(item, false),
        AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&ChallengeInstruction::Buy {user_bump, config_bump, item_bump, item_id, treasury_bump, holding_bump}).unwrap(),
    }
}

pub fn update_owner(program: Pubkey, owner: Pubkey, system_config: Pubkey, config_bump: u8, new_owner: Pubkey) -> Instruction {
  Instruction {
        program_id: program,
        accounts: vec![
        AccountMeta::new(owner, true),
        AccountMeta::new(system_config, false),
        AccountMeta::new_readonly(system_program::id(), false),
        ],
        data: to_vec(&ChallengeInstruction::UpdateOwner {config_bump, new_owner}).unwrap(),
    }
}