use solana_program::{
    account_info::{next_account_info, AccountInfo},
    entrypoint::ProgramResult,
    program::{invoke, invoke_signed},
    program_error::ProgramError,
    pubkey::Pubkey,
    rent::Rent,
    system_instruction,
};

use borsh::{BorshDeserialize, BorshSerialize};
// Structs to use to write in PDAs
#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Config {
    pub owner: Pubkey,
    pub treasury: Pubkey,
    shop_item_count: u64,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct User {
    id: u32,
    authority: Pubkey,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Item {
    name: String,
    index: u64,
    cost: u64,
    stock: u64,
}

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Holding {
    owner: Pubkey,
    item: Pubkey,
    quantity: u64,
}

pub const ACCOUNT_SIZE: usize = 256;
// Initialize market
pub fn initialize(program: &Pubkey, accounts: &[AccountInfo], config_bump: u8, item0_bump: u8, item1_bump: u8, treasury_bump: u8) -> ProgramResult {
    // expected accounts
    let account_iter = &mut accounts.iter();
    let owner = next_account_info(account_iter)?;
    let config = next_account_info(account_iter)?;
    let item0 = next_account_info(account_iter)?;
    let item1 = next_account_info(account_iter)?;
    let treasury = next_account_info(account_iter)?;

    // Owner is signer of the transaction (NoobMaster!)
    assert!(owner.is_signer);
    // Use highest bump to avoid re-initializing and ensure this function is called only once.
    // let (owner_pda, owner_expected_bump) = Pubkey::find_program_address(&[b"OWNER"], program);
    let (config_pda, config_expected_bump) = Pubkey::find_program_address(&[b"CONFIG"], program);
    let (item0_pda, item0_expected_bump) = Pubkey::find_program_address(&[b"RUBBERDUCK"], program);
    let (item1_pda, item1_expected_bump) = Pubkey::find_program_address(&[b"SHELL"], program);
    let (treasury_pda, treasury_expected_bump) = Pubkey::find_program_address(&[b"VAULT"], program);

    // Confirm provided vs expected match
    // if (*owner.key != owner_pda) || (owner_bump != owner_expected_bump) {
    //     return Err(ProgramError::InvalidAccountData);
    // }

    if (*config.key != config_pda) || (config_bump != config_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }

    if (*item0.key != item0_pda) || (item0_bump != item0_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }

    if (*item1.key != item1_pda) || (item1_bump != item1_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }

    if (*treasury.key != treasury_pda) || (treasury_bump != treasury_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }
    // Create PDAs
    invoke_signed(
        &system_instruction::create_account(
            owner.key,
            &config_pda,
            Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
            ACCOUNT_SIZE as u64,
            &program
        ),
        &[owner.clone(), config.clone()],
        &[&[b"CONFIG", &[config_bump]]],
    )?;

    invoke_signed(
        &system_instruction::create_account(
            owner.key,
            &item0_pda,
            Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
            ACCOUNT_SIZE as u64,
            &program
        ),
        &[owner.clone(), item0.clone()],
        &[&[b"RUBBERDUCK", &[item0_bump]]],
    )?;

    invoke_signed(
        &system_instruction::create_account(
            owner.key,
            &item1_pda,
            Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
            ACCOUNT_SIZE as u64,
            &program
        ),
        &[owner.clone(), item1.clone()],
        &[&[b"SHELL", &[item1_bump]]],
    )?;

    invoke_signed(
        &system_instruction::create_account(
            owner.key,
            &treasury_pda,
            Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
            ACCOUNT_SIZE as u64,
            &program
        ),
        &[owner.clone(), treasury.clone()],
        &[&[b"VAULT", &[treasury_bump]]],
    )?;
    // Write intial data to PDAs
    let config_data = Config {
        owner: *owner.key,
        treasury: *treasury.key,
        shop_item_count: 2,
    };

    let item0_data = Item {
        name: "Rubber Ducky".to_string(),
        index: 1337,
        cost: 2_000_000_000, // 2 SOL
        stock: 1337,
    };

    let item1_data = Item {
        name: "Shell".to_string(),
        index: 4919,
        cost: 5_000_000_000, // 5 SOL
        stock: 1,
    };
    // Write data to PDAs
    config_data.serialize(&mut &mut (*config.data).borrow_mut()[..]).unwrap();
    item0_data.serialize(&mut &mut (*item0.data).borrow_mut()[..]).unwrap();
    item1_data.serialize(&mut &mut (*item1.data).borrow_mut()[..]).unwrap();

    Ok(())
}
// Create users
pub fn initialize_user(program: &Pubkey, accounts: &[AccountInfo], user_bump: u8, user_id: u32) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let user_config = next_account_info(account_iter)?;
    // you must be signer (cannot create accounts for anyone else)
    assert!(user.is_signer);
    // Unique for each user
    let (user_config_pda, user_config_bump) = Pubkey::find_program_address(&[user.key.as_ref(), b"USER"], program);
    
    if (*user_config.key != user_config_pda) || (user_bump != user_config_bump) {
        return Err(ProgramError::InvalidAccountData);
    }
    // Will fail if account has already been created
    invoke_signed(
            &system_instruction::create_account(
            user.key,
            &user_config_pda,
            Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
           ACCOUNT_SIZE as u64,
           &program,
        ),
        &[user.clone(), user_config.clone()],
        &[&[user.key.as_ref(), b"USER", &[user_config_bump]]],
        )?;

    let user_config_data = User {
        id: user_id,
        authority: *user.key,
    };

    user_config_data.serialize(&mut &mut (*user_config.data).borrow_mut()[..]).unwrap();
    Ok(())
}

pub fn deposit(program: &Pubkey, accounts: &[AccountInfo], user_bump: u8, amount: u64) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let user_config = next_account_info(account_iter)?;
    assert!(user.is_signer);

    let (user_config_pda, user_config_bump) = Pubkey::find_program_address(&[user.key.as_ref(), b"USER"], program);
    
    if (*user_config.key != user_config_pda) || (user_bump != user_config_bump) {
        return Err(ProgramError::InvalidAccountData);
    }

    // transfer the specificed amount to the User's PDA
    invoke(
        &system_instruction::transfer(
          &user.key,
          &user_config_pda,
          amount,
        ),
        &[user.clone(), user_config.clone()],
      )?;
    Ok(())
}

pub fn buy(program: &Pubkey, accounts: &[AccountInfo], user_bump: u8, config_bump: u8, item_bump: u8, item_id: u64, treasury_bump: u8, holding_bump: u8) -> ProgramResult {
    let account_iter = &mut accounts.iter();
    let user = next_account_info(account_iter)?;
    let user_config = next_account_info(account_iter)?;
    let system_config = next_account_info(account_iter)?;
    let treasury = next_account_info(account_iter)?;
    let holding = next_account_info(account_iter)?;
    let item = next_account_info(account_iter)?;
    assert!(user.is_signer);

    let (user_config_pda, user_config_bump) = Pubkey::find_program_address(&[user.key.as_ref(), b"USER"], program);
    let (holding_pda, holding_expected_bump) = Pubkey::find_program_address(&[user.key.as_ref(), b"HOLDING", item.key.as_ref()], program);
    let (system_config_pda, system_expected_bump) = Pubkey::find_program_address(&[b"CONFIG"], program);
    let (treasury_pda, treasury_expected_bump) = Pubkey::find_program_address(&[b"VAULT"], program);
    
    if (*treasury.key != treasury_pda) || (treasury_bump != treasury_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }
    if (*system_config.key != system_config_pda) || (config_bump != system_expected_bump) {
        return Err(ProgramError::InvalidAccountData);
    }
    
    if (*user_config.key != user_config_pda) || (user_bump != user_config_bump) {
        return Err(ProgramError::InvalidAccountData);
    }
    if (item_id == 0) {
        let (item0_pda, item0_expected_bump) = Pubkey::find_program_address(&[b"RUBBERDUCK"], program);
        if (*item.key != item0_pda) || (item_bump != item0_expected_bump) {
            return Err(ProgramError::InvalidAccountData);
        }
    }
    else {
        let (item1_pda, item1_expected_bump) = Pubkey::find_program_address(&[b"SHELL"], program);
    }
    if *item.owner != *program {
          return Err(ProgramError::IllegalOwner);
      }
    let item_data = &mut Item::deserialize(&mut &(*item.data).borrow_mut()[..])?; 
    assert!(item_data.stock > 0);
    assert!(item_data.index == item_id);
    assert!(user_config.lamports() - Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE) >= item_data.cost);
    // Move lamports directly since both are PDAs
    **user_config.try_borrow_mut_lamports()? -= item_data.cost;
    **treasury.try_borrow_mut_lamports()? += item_data.cost;
    // Create PDA if does not exist
    if holding.data_is_empty() {
        invoke_signed(
            &system_instruction::create_account(
                user.key,
                &holding_pda,
                Rent::minimum_balance(&Rent::default(), ACCOUNT_SIZE),
                ACCOUNT_SIZE as u64,
                &program
            ),
            &[user.clone(), holding.clone()],
            &[&[user.key.as_ref(), b"HOLDING", item.key.as_ref(),  &[holding_bump]]],
        )?;
        let holding_data = Holding {
          owner: *user.key,
          item: *item.key,
          quantity: 1,
          };
      holding_data.serialize(&mut &mut (*holding.data).borrow_mut()[..]).unwrap();

    }
    else {
        let holding_data = &mut Holding::deserialize(&mut &(*holding.data).borrow_mut()[..])?; 
        holding_data.owner = *user.key;
        holding_data.item = *item.key;
        holding_data.quantity += 1;
        holding_data.serialize(&mut &mut (*holding.data).borrow_mut()[..]).unwrap();
    }

    item_data.stock -= 1;
    item_data.serialize(&mut &mut (*item.data).borrow_mut()[..]).unwrap();
    
    Ok(())
}

pub fn update_owner(program: &Pubkey, accounts: &[AccountInfo], config_bump: u8, new_owner: Pubkey) -> ProgramResult {
      let account_iter = &mut accounts.iter();
      let owner = next_account_info(account_iter)?;
      let system_config = next_account_info(account_iter)?;
      assert!(owner.is_signer);

      // verify the account is our PDA
      if system_config.owner != program {
          return Err(ProgramError::IllegalOwner);
      }

      let mut config_data = Config::deserialize(&mut &(*system_config.data).borrow()[..])?;

      // only the current owner may change the owner
      if config_data.owner != *owner.key {
          return Err(ProgramError::InvalidAccountData);
      }

      config_data.owner = new_owner;
      config_data.serialize(&mut &mut (*system_config.data).borrow_mut()[..]).unwrap();
      Ok(())
  }
