#![cfg(not(feature = "no-entrypoint"))]
use solana_program::{
    account_info::AccountInfo,
    entrypoint,
    entrypoint::ProgramResult,
    pubkey::Pubkey,
};
use borsh::{BorshDeserialize, BorshSerialize};

use crate::processor:: {
  initialize,
  initialize_user,
  deposit,
  buy,
  update_owner,
};

entrypoint!(process_instruction);

#[derive(BorshSerialize, BorshDeserialize)]
pub enum ChallengeInstruction {
    Initialize { config_bump: u8, item0_bump: u8, item1_bump: u8, treasury_bump: u8},
    InitializeUser { user_bump: u8, user_id: u32},
    Deposit { user_bump: u8, amount: u64},
    Buy {user_bump: u8, config_bump: u8, item_bump: u8, item_id: u64, treasury_bump: u8, holding_bump: u8},
    UpdateOwner {config_bump: u8, new_owner: Pubkey},
}

pub fn process_instruction(program: &Pubkey, accounts: &[AccountInfo], mut data: &[u8]) -> ProgramResult {
	match ChallengeInstruction::deserialize(&mut data)? {
		ChallengeInstruction::Initialize { config_bump, item0_bump, item1_bump, treasury_bump } => initialize(program, accounts, config_bump, item0_bump, item1_bump, treasury_bump),
		ChallengeInstruction::InitializeUser { user_bump, user_id } => initialize_user(program, accounts, user_bump, user_id),
		ChallengeInstruction::Deposit { user_bump, amount } => deposit(program, accounts, user_bump, amount),
		ChallengeInstruction::Buy { user_bump, config_bump, item_bump, item_id, treasury_bump, holding_bump } => buy(program, accounts, user_bump, config_bump, item_bump, item_id, treasury_bump, holding_bump), 
		ChallengeInstruction::UpdateOwner { config_bump, new_owner } => update_owner(program, accounts, config_bump, new_owner),
	
	}
}
