use std::fs;
use std::io::Write;
use std::error::Error;
use std::net::{TcpListener, TcpStream};

use sol_ctf_framework::ChallengeBuilder;

use solana_program_test::tokio;

use solana_sdk::{
    pubkey::Pubkey,
    account::Account,
    signature::{Keypair, Signer},
    system_program,
};

use market::{
    initialize,
    initialize_user,
    deposit,
    buy,
    update_owner,
};

use borsh::{
  BorshDeserialize,
  BorshSerialize,
};

#[repr(C)]
#[derive(BorshSerialize, BorshDeserialize)]
pub struct Config {
    pub owner: Pubkey,
    pub treasury: Pubkey,
    shop_item_count: u64,
}


#[tokio::main]
async fn main() -> Result<(), Box<dyn Error>> {
    let listener = TcpListener::bind("0.0.0.0:1337")?;

    println!("starting server at port 1337!");

    for stream in listener.incoming() {
        let stream = stream.unwrap();

        tokio::spawn(async {
            if let Err(err) = handle_connection(stream).await {
                println!("error: {:?}", err);
            }
        });
    }
    Ok(())
}


async fn handle_connection(mut socket: TcpStream) -> Result<(), Box<dyn Error>> {
    let mut builder = ChallengeBuilder::try_from(socket.try_clone().unwrap()).unwrap();
    
    // Load challenge
    let program_key = Pubkey::new_unique().to_bytes().into(); // Reverted back to Pubkey
    let program_pubkey = builder.add_program(&"./chall.so", Some(Some(program_key)).expect("Duplicate pubkey supplied"));
    let program_pubkey: Pubkey = Pubkey::from(program_pubkey.unwrap().to_bytes());
    // Load solve
    let solve_pubkey = match builder.input_program() {
        Ok(pubkey) => pubkey,
        Err(e) => {
            writeln!(socket, "Error: cannot add solve program -> {e}")?;
            return Ok(());
        }
    };

    let owner  = Keypair::new();
    builder
        .builder
        .add_account(
            owner.pubkey().to_bytes().into(), 
            Account::new(50_000_000_000, 0, &system_program::ID.to_bytes().into()) // 50 SOL for NoobMaster, damn im RICH!
        );
    

    let user = Keypair::new();
    builder
        .builder
        .add_account(
            user.pubkey().to_bytes().into(),
            Account::new(5_500_000_000, 0, &system_program::ID.to_bytes().into()) // 5.5 SOL for you LOL
        );
    
    let (config_pda, config_bump) = Pubkey::find_program_address(&[b"CONFIG"], &program_pubkey);
    let (item0_pda, item0_bump) = Pubkey::find_program_address(&[b"RUBBERDUCK"], &program_pubkey);
    let (item1_pda, item1_bump) = Pubkey::find_program_address(&[b"SHELL"], &program_pubkey);
    let (treasury_pda, treasury_bump) = Pubkey::find_program_address(&[b"VAULT"], &program_pubkey);
    
    let mut challenge = builder.build().await;

    // Initialize config
    challenge.run_ixs_full(
        &[initialize(program_pubkey, owner.pubkey(), config_pda, item0_pda, item1_pda, treasury_pda, config_bump, item0_bump, item1_bump, treasury_bump)],
        &[&owner],
        &owner.pubkey(),
    ).await.ok();

    
    writeln!(socket, "program: {}", program_pubkey)?;
    writeln!(socket, "user: {}", user.pubkey())?;

    let ixs = challenge.read_instruction(solve_pubkey).unwrap();
    // writeln!(socket, "solver key: {}", solve_pubkey)?;
    
    challenge.run_ixs_full(
        &[ixs],
        &[&user],
        &user.pubkey().to_bytes().into(),
    ).await.ok();

    writeln!(socket, "Done");

    let config_data = challenge.ctx.banks_client.get_account(config_pda).await.unwrap().unwrap();
    let mut data: &[u8] = &config_data.data;

    let current_owner = Config::deserialize(&mut data).unwrap().owner;
    
    writeln!(socket, "Current owner: {}", current_owner)?;

    if current_owner == user.pubkey() {
        let flag = fs::read_to_string("flag.txt").unwrap();
        writeln!(socket, "Did you just steal the market from ME?? I SHALL BE BACK!: {}", flag)?; // NoobMaster is MAD?!

    }

    Ok(())

}