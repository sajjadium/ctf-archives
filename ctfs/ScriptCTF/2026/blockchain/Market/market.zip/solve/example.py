from pwn import *
from solders.pubkey import Pubkey as PublicKey
from solders.system_program import ID
import base58
from borsh_construct import CStruct, U8, U32, U64
import os

os.system('cargo build-sbf')
r = remote('127.0.0.1',1337)
solve = open('target/deploy/solve.so', 'rb').read()

r.recvuntil(b'program pubkey: ')
r.sendline(b'5PjDJaGfSPJj4tFzMRCiuuAasKg5n8dJKXKenhuwyexx') # Enter pubkey
r.recvuntil(b'program len: ')
r.sendline(str(len(solve)).encode())
r.send(solve)
r.recvuntil(b'program: ')
program = PublicKey(base58.b58decode(r.recvline().strip().decode()))
r.recvuntil(b'user: ')
user = PublicKey(base58.b58decode(r.recvline().strip().decode()))

input_payload = "" # your input payload to be sent to YOUR solver contract
r.send(b'3') # Number of accounts
print(program)
r.sendline(b'x ' + str(program).encode())
r.sendline(b'ws ' + str(user).encode()) # signer
r.sendline(b'x ' + str(ID).encode())
r.sendline(str(len(input_payload)).encode())
r.send(input_payload)

r.interactive()