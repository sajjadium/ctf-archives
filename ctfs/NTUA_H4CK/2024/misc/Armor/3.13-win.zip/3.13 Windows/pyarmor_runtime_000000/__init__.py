# Pyarmor 9.0.6 (trial), 000000, 2024-12-03T00:01:12.240121
from .pyarmor_runtime import __pyarmor__
