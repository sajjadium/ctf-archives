#!/bin/bash
apache2-foreground