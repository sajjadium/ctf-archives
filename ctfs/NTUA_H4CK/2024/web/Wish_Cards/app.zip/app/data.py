wishes = [
    "A Christmas filled with love, joy, and peace.",
    "May your Christmas be bright with happiness and filled with the warmth of loved ones.",
    "Wishing you a Christmas that brings you joy, laughter, and a heart full of wonder.",
    "May this Christmas be a time of reflection, gratitude, and the fulfillment of your dreams.",
    "Sending you warm wishes for a Christmas filled with magic, miracles, and unforgettable memories.",
    "May the spirit of Christmas bring you hope, peace, and a renewed sense of purpose.",
    "Wishing you a Christmas that is as special as you are, filled with love and happiness.",
    "May the joy of Christmas fill your heart and home with warmth and light.",
    "Sending you Christmas wishes for a year filled with love, laughter, and prosperity.",
    "May the magic of Christmas bring you joy, peace, and a heart full of wonder."
]
cards = ['beach.png' , 'colors.png' , 'frosty.png'  , 'green.png' , 'present.png', 'real.png' , 'red.png',  'stars.png']