const nextConfig = {};

export default nextConfig;
