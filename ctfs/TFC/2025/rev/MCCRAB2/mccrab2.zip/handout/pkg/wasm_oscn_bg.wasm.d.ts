/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const check_flag: (a: number, b: number) => [number, number];
export const encrypt: (a: number, b: number, c: number, d: number) => [number, number];
export const hex_encode: (a: number, b: number) => [number, number];
export const hex_decode: (a: number, b: number) => [number, number];
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_start: () => void;
