Welcome to the second `LD_PRELOAD` challenge!

This time, we provide the `Makefile` and a bit of a .c file, but you need to
figure out the function we're overriding yourself!

Hint: Run the challenge using `ltrace` - can you see what's going on?
