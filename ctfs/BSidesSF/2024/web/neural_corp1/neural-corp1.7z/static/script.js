function submitLinks() {
    // Add your JavaScript logic for link submission here
    // For the sake of this example, let's just display an alert
    alert("Thank you for joining the revolution!");
}
