FLAG=EnXp{mY_d3eP3sT_D4rK35t_s3cR3t}

## Instructions

- add and update the `.env` file with the flag before using the app. See `.env.example`.