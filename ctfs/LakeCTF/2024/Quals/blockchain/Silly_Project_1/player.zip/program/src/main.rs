#![no_main]
sp1_zkvm::entrypoint!(main);

use sp1_zkvm::lib::secp256k1::Secp256k1Point;
use sp1_zkvm::lib::utils::AffinePoint;

pub fn main() {
    let nullifier = sp1_zkvm::io::read::<u32>();
    sp1_zkvm::io::commit(&nullifier);
    let x = sp1_zkvm::io::read::<[u32; 8]>();
    let mut y = Secp256k1Point::new(Secp256k1Point::GENERATOR);
    y.mul_assign(&x).unwrap();
    sp1_zkvm::io::commit(&y.limbs_ref());
}
