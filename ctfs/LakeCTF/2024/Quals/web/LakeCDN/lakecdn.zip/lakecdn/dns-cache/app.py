#!/usr/bin/env python3
import random
import sys
import logging
from base64 import urlsafe_b64decode
from ipaddress import ip_address

from dnslib import QTYPE, RCODE, RR, A, DNSRecord
from flask import Flask, Response, request
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from redis import Redis
from werkzeug.middleware.proxy_fix import ProxyFix

# https://www.iana.org/domains/root/servers
ROOT_SERVERS = [
    "198.41.0.4",
    "170.247.170.2",
    "192.33.4.12",
    "199.7.91.13",
    "192.203.230.10",
    "192.5.5.241",
    "192.112.36.4",
    "198.97.190.53",
    "192.36.148.17",
    "192.58.128.30",
    "193.0.14.129",
    "199.7.83.42",
    "202.12.27.33",
]

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("DNS")

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=0)
limiter = Limiter(get_remote_address, app=app, storage_uri="redis://redis:6379",
  storage_options={"socket_connect_timeout": 30},
  strategy="fixed-window")

redis = Redis(host="redis", port=6379, db=0)


@app.route("/dns-query", methods=["GET"], defaults={"client_ip": None})
@app.route("/dns-query/<client_ip>", methods=["GET"])
def dns_query_get(client_ip):
    dns = request.args.get("dns")
    if dns is None:
        return "Invalid request", 400

    if client_ip is not None and ip_address(request.remote_addr).is_private:
        request.client_ip = client_ip
    else:
        limiter.limit("4 / 15 seconds")
        request.client_ip = request.remote_addr

    query = urlsafe_b64decode(dns + "==")
    return Response(process_dns_query(query), mimetype="application/dns-message")


@app.route("/dns-query", methods=["POST"], defaults={"client_ip": None})
@app.route("/dns-query/<client_ip>", methods=["POST"])
def dns_query_post(client_ip):
    if client_ip is not None and ip_address(request.remote_addr).is_private:
        request.client_ip = client_ip
    else:
        request.client_ip = request.remote_addr

    return Response(process_dns_query(request.data), mimetype="application/dns-message")


def random_root_server():
    return random.choice(ROOT_SERVERS)


def cache_key(fqdn: str):
    return "dns_" + request.client_ip.encode().hex() + "_" + fqdn.encode().hex()


def resolve_cached(fqdn: str, resolver: str, max_depth=10):
    cached_value = redis.get(cache_key(fqdn))
    if cached_value == b"NXDOMAIN":
        log.info(f"Cache miss for {fqdn}")
        return None
    elif cached_value:
        log.info(f"Cache hit for {fqdn}")
        return cached_value.decode()
    else:
        log.info(f"Cache miss for {fqdn}")
        return recursively_resolve(fqdn, random_root_server(), max_depth)


def recursively_resolve(fqdn: str, resolver: str, max_depth=10):
    log.info(f"Recursively resolving {fqdn} from {resolver}")
    if max_depth == 0:
        log.info(f"Max depth reached for {fqdn}")
        return None

    query = DNSRecord.question(fqdn)
    res = DNSRecord.parse(query.send(resolver, timeout=3))

    if res.header.id != query.header.id:
        log.info(f"DNS spoofing attempt detected for {fqdn}")
        return None

    if res.header.rcode == RCODE.NXDOMAIN:
        redis.set(cache_key(fqdn), "NXDOMAIN", ex=60)
        return None

    answer = None
    for rr in res.rr:
        if rr.rtype == QTYPE.A:
            res_fqdn = str(rr.rname)
            res_ip = str(rr.rdata)
            redis.set(cache_key(res_fqdn), res_ip, ex=60)

            if res_fqdn == fqdn:
                answer = res_ip
    
    if answer is None:
        log.info(f"No answer found for {fqdn}, checking for CNAME")
        for rr in res.rr:
            if rr.rtype == QTYPE.CNAME and str(rr.rname) == fqdn:
                res_cname = str(rr.rdata)
                answer = resolve_cached(res_cname, resolver, max_depth - 1)
                redis.set(cache_key(fqdn), answer, ex=60)
                break

    if answer:
        log.info(f"Received answer for {fqdn} from {resolver}")
        return answer
    else:
        ns = next(str(x.rdata) for x in res.auth if x.rtype == QTYPE.NS)
        ns_ip = next(
            (str(x.rdata) for x in res.ar if x.rtype == QTYPE.A and str(x.rname) == ns),
            None,
        )
        if ns_ip is None:
            ns_ip = resolve_cached(ns, random_root_server(), max_depth - 1)
        log.info(f"Recursively resolving {fqdn} from {ns_ip} ({ns})")
        return recursively_resolve(fqdn, ns_ip, max_depth - 1)


def process_dns_query(query_bytes: bytes):
    query = DNSRecord.parse(query_bytes)

    answer = query.reply()

    if (question := next(iter(query.questions), None)) and question.qtype == QTYPE.A:
        fqdn = str(question.qname)
        try:
            ip = resolve_cached(fqdn, random_root_server())
        except Exception as e:
            print(e, file=sys.stderr, flush=True)
            ip = None
        
        if ip:
            answer.add_answer(
                RR(rname=question.qname, rtype=QTYPE.A, ttl=0, rdata=A(ip))
            )

    return bytes(answer.pack())


if __name__ == "__main__":
    app.run(debug=True, port=80, host="0.0.0.0")
