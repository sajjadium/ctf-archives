#!/bin/bash

if [ -n "$BUILD_ONLY" ]; then
    exit 0
fi

CLIENT_IP=$1
PACKAGE_NAME=$2

atd
echo "halt" | at now +10seconds

DNS_IP=$(dig +short dns-cache | head -n 1)

homer --upstream "http://$DNS_IP/dns-query/$CLIENT_IP" &
echo "nameserver 127.0.0.1" > /etc/resolv.conf

yarn add "$PACKAGE_NAME" --ignore-optional --prod
