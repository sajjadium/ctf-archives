import os
import shutil
import sys
import time
from datetime import datetime, timedelta
import docker

DATA_DIR = "/data"

def cleanup_old_folders():
    cutoff = datetime.now() - timedelta(minutes=2)
    cutoff_timestamp = cutoff.timestamp()

    for folder in os.listdir(DATA_DIR):
        folder_path = os.path.join(DATA_DIR, folder)
        if os.path.isdir(folder_path):
            folder_time = os.path.getmtime(folder_path)
            if folder_time < cutoff_timestamp:
                try:
                    shutil.rmtree(folder_path)
                except Exception as e:
                    print(f"Error deleting {folder_path}: {e}", file=sys.stderr, flush=True)

def cleanup_docker_containers():
    client = docker.from_env()
    cutoff = datetime.now() - timedelta(seconds=10)

    try:
        containers = client.containers.list(all=True, filters={"label": "downloader"})
        for container in containers:
            created_at = datetime.strptime(container.attrs['Created'].replace("T", ' ').split('.')[0], "%Y-%m-%d %H:%M:%S")
            if created_at < cutoff:
                try:
                    container.remove(force=True)
                except Exception as e:
                    print(f"Error removing container {container.id}: {e}", file=sys.stderr, flush=True)
    except Exception as e:
        print(f"Error cleaning up Docker containers: {e}", file=sys.stderr, flush=True)

def main():
    while True:
        cleanup_old_folders()
        cleanup_docker_containers()
        time.sleep(10)

if __name__ == "__main__":
    main()
