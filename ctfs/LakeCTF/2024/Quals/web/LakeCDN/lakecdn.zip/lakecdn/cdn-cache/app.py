#!/usr/bin/env python3
import os
import sys
from pathlib import Path

import docker
from flask import Flask, request, send_from_directory
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.middleware.proxy_fix import ProxyFix

DATA_DIR = Path("/data")
FREE_PACKAGES = ["async", "chalk", "lodash", "react", "underscore"]

docker_client = docker.from_env()

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=0)

limiter = Limiter(get_remote_address, app=app, storage_uri="redis://redis:6379",
  storage_options={"socket_connect_timeout": 30},
  strategy="fixed-window")

def package_folder(package: str):
    return request.remote_addr + "_" + package


def cache_package(package: str):
    folder_name = package_folder(package)
    folder_path = DATA_DIR / folder_name
    folder_path.mkdir()

    mount = docker.types.Mount(
        target="/root/node_modules", source="lakecdn_cdn_data", type="volume"
    )
    mount["VolumeOptions"] = {"Subpath": folder_name}
    container = docker_client.containers.run(
        "lakecdn-downloader",
        [request.remote_addr, package],
        mounts=[mount],
        remove=True,
        network="lakecdn_dns",
        platform="linux/amd64",
        environment=dict(os.environ),
        labels=["downloader"],
    )
    print(container.decode(), file=sys.stderr, flush=True)

    # Delete folder if caching failed
    if not any(folder_path.iterdir()):
        folder_path.rmdir()


@app.route("/cdn/<path:param>")
def cdn_get(param):
    package, file = param.split("/", 1)
    
    if package not in FREE_PACKAGES:
        return "Not available in free tier", 402

    path = DATA_DIR / package_folder(package)
    if not path.exists():
        with limiter.limit("1 / 30 seconds"):
            cache_package(package)
    
    return send_from_directory(path / package, file)


if __name__ == "__main__":
    app.run(debug=True, port=80, host="0.0.0.0")
