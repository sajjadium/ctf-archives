#!/bin/bash

python clean.py &
gunicorn -w 16 app:app -b 0.0.0.0:80 --timeout 10
