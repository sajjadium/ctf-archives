# Installation
I recommend you use pnpm but you can also use npm / yarn
```sh
pnpm install
# or
npm install
```

then you can use:
```sh
pnpm dev
# or
npm run dev
```
to recompile typescript everytime you change a file

and you can launch the project using:
```sh
node .
```
