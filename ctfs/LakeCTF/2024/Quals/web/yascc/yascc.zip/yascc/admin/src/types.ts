export interface AdminTask {
    id: number,
    post_id: string,
    type: "report",
    handled: number,
}