#!/bin/bash

adb push com.termux.tar.gz /data/local/tmp
adb shell "su 0 sh -c 'cd /data/data && tar xvf /data/local/tmp/com.termux.tar.gz'"

adb push service1_handout /data/local/tmp/service1
adb push minijail0 /data/local/tmp
adb push minijailpreload.so /data/local/tmp
adb push exploit /data/local/tmp

adb shell su 0 'sh -c "chown root /data/local/tmp/service1 && chmod 700 /data/local/tmp/service1 && /data/local/tmp/service1"' &

