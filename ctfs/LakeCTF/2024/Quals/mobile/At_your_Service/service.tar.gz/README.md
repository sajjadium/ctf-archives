# Building

Build the dockers:
```
cp service1_handout service1
docker compose build
```

In `build` you find everything to build both the service and your exploit. (This cursed way of building avoids having to download the AOSP)
Simply run: `make`

Use the client.cc as a starting point to build your exploit.

# Debugging

To debug the challenge first download termux.tar.gz from: https://drive.google.com/file/d/1Y4n4HH1X7PfF2mfm6YJvE1G_TUhckMrZ/view?usp=sharing 

It contains a termux app directory with debugging tools installed.

Start the challenge docker. 
```
docker run --rm --name emu --device /dev/kvm -it -v .:/mnt mobile-atyourservice-chall /bin/bash
```

Inside of the challenge docker start the emulator:
```
emulator @pixel -no-window -no-audio
```

Wait until the emulator prints "boot completed" (takes a while)

Open another shell in the container and once the emulator has booted run the setup_debug.sh script.
```
docker exec -it emu /bin/bash
cd /mnt
./setup_debug.sh
```

Afterwards debug using:
```
adb shell
su
PATH=$PATH:/data/data/com.termux/files/usr/bin
gdb -p $(pgrep service1)
```

