#!/bin/bash

emulator @pixel -no-window -no-audio > /dev/null 2>&1 &
echo "starting emulator.."

while true; do
    device_list=$(adb devices | grep -w "device")
    
    if [[ -n "$device_list" ]]; then
        echo "ADB device is connected."
        break  # Exit the loop when a device is found
    else
        echo "No ADB device connected. Checking again..."
        sleep 5  # Wait for 5 seconds before checking again
    fi
done

echo "setting up service"
adb push /service1 /data/local/tmp
adb push /minijail0 /data/local/tmp
adb push /minijailpreload.so /data/local/tmp
adb shell su 0 'sh -c "chown root /data/local/tmp/minijail0 && chmod 700 /data/local/tmp/minijail0 "'
adb shell su 0 'sh -c "chown root /data/local/tmp/minijailpreload.so && chmod 700 /data/local/tmp/minijailpreload.so "'
adb shell su 0 'sh -c "chown root /data/local/tmp/service1 && chmod 700 /data/local/tmp/service1 && /data/local/tmp/service1"' &

echo "uploading and throwing exploit"
adb push /player/exploit /data/local/tmp
#adb shell su nobody 'sh -c "/bin/sh"'
adb shell su 0 'sh -c "cd /data/local/tmp && ./minijail0 -u nobody -g nobody -- ./exploit"'
