from pwn import *
import hashlib
import re
import base64


def pow_solver(prefix, difficulty):
    zeros = '0' * difficulty
    def is_valid(digest):
        bits = ''.join(bin(i)[2:].zfill(8) for i in digest)
        return bits[:difficulty] == zeros
    i = 0
    while True:
        i += 1
        s = prefix + str(i)
        if is_valid(hashlib.sha256(s.encode()).digest()):
            return str(i)

import sys
print(sys.argv)
if len(sys.argv) < 3:
    host = "127.0.0.1"
    port = "9035"
else:
    host = sys.argv[1]
    port = int(sys.argv[2])

r = remote(host, port)

recv_data = r.recvuntil(b">").decode()
prefix = re.findall(r'\[\*\] prefix: ([0-9A-Za-z]+)\n', recv_data)[0]
difficulty = int(re.findall(r'\[\*\] difficulty: ([0-9]+)\n', recv_data)[0])
print("difficulty;", difficulty)
print("prefix:", prefix)
answer = pow_solver(prefix, difficulty)
print("answer:", answer)
r.sendline(answer.encode())
r.recvuntil(b"base64")
r.recvuntil(b" >")
# TODO
r.interactive()
