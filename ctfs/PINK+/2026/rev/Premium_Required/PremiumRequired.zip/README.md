# Premium Required
My friend loved this **flaggy** song on Spotify, however, his premium expired and the song got taken down, he still has the premium download from the song though!!

### Good luck, you will need it!