lmao, still trying?
