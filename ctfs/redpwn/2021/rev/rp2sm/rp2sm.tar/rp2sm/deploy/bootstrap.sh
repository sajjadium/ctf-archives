#!/bin/sh
exec bin/chall
