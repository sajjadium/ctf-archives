#!/bin/bash

cd /ctf && python3 discrepancy.py