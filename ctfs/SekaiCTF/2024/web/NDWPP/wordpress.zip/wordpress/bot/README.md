The bot use configuration from https://github.com/dimasma0305/CTF-XSS-BOT/tree/main
