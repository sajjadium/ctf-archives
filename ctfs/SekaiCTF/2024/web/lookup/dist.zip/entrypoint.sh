#!/bin/bash

set -m

nginx -g "daemon off;" &

cd /app
java -cp /app/commons-scxml2-2.0-SNAPSHOT.jar ./src/Main.java

fg %1
