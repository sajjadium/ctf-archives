import com.sun.net.httpserver.HttpServer;

import javax.naming.InitialContext;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        var port = Integer.parseInt(System.getenv().getOrDefault("PORT", "8000"));
        var server = HttpServer.create(new java.net.InetSocketAddress(port), 0);
        server.createContext("/", req -> {
            var code = 200;
            var response = switch (req.getRequestURI().getPath()) {
                case "/lookup" -> {
                    try {
                        var param = req.getRequestURI().getQuery();
                        yield new InitialContext().lookup(param).toString();
                    } catch (Throwable e) {
                        e.printStackTrace();
                        yield ":(";
                    }
                }
                default -> {
                    code = 404;
                    yield "Not found";
                }
            };
            req.sendResponseHeaders(code, 0);
            var os = req.getResponseBody();
            os.write(response.getBytes());
            os.close();
        });
        server.start();
        System.out.printf("Server listening on :%s\n", port);
    }

}
