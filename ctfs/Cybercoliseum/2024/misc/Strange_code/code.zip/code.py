kassth wmos dw z

wptqfw fcgh64 eu p64



i = "u09gfxnbs000wp83crixznixznujurqqvt8zvn80l0patrq9"

i = d64.p64giecgi(h).rhgqrh()

g = "ecqktoww!\p"

rhj r(h, g=0.2):

    jqf f mp h:

        svkbw(g, gbg='', jnivl=vfxi)

        z.goigd(g)



t(e+s)
