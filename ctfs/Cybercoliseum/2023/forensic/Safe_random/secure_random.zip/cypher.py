import random
import time


random.seed(int(time.time()))

FLAG = b"CODEBY{?????????????????}"

random = random.randbytes(len(FLAG))

enc = bytes(i ^ j for i, j in zip(FLAG, random))

with open("data.enc", "wb") as f:
    f.write(enc)
