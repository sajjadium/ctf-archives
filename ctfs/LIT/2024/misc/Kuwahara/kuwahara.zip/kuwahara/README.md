# Kuwahara

In this problem, you are given a noisy image and an encoded image that goes along with it. Try and decode it!

Some resources:

- <https://github.com/yoch/pykuwahara/blob/main/src/pykuwahara/kuwahara.py>
- <https://en.wikipedia.org/wiki/Kuwahara_filter>
- <https://www.youtube.com/watch?v=LDhN-JK3U9g>
