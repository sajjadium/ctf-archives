#!/bin/sh
cat <<EOF
<head>
	<meta charset="UTF-8"/>
	<title>$1</title>
	<link rel="stylesheet" href="/$KEY/css/style.css"/>
</head>
EOF
