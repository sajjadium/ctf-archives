#!/bin/sh
printf "%s" "$KEY"
