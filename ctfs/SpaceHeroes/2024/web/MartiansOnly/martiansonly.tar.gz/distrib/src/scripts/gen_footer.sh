#!/bin/sh
cat <<EOF
<footer>
	<span>MartiansOnly © 2069</span><span><a href="https://astonsafetysigns.co.uk/wp-content/uploads/2020/11/sec09-1.jpg">Privacy Policy</a></span>
</footer>
EOF
