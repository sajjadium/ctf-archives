#!/bin/sh
cat <<EOF
<header>
	<nav>
		<a href="/$KEY/" id="logo"><img src="/$KEY/assets/img/logo.gif" style="height:2em"></a>
		<a href="/$KEY/browse/">See hot martian singles in YOUR galactic neighborhood</a>
		<div style="flex-grow: 1"></div>
		<a href="/$KEY/profile/">Profile</a>
	</nav>
</header>
EOF
