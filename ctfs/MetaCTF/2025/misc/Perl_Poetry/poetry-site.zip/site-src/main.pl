#!/usr/bin/perl

use strict;
use warnings;

use CGI qw/ :standard /;
use Data::Dumper;
use File::Spec;
use HTTP::Daemon;
use HTTP::Response;
use HTTP::Status;
use POSIX qw/ WNOHANG /;

use constant HOSTNAME => qx{hostname};

my $LOCAL_DIR = './public/';

my %O = (
    'listen-host' => '0.0.0.0',
    'listen-port' => 3000,
    'listen-clients' => 5,
    'listen-max-req-per-child' => 100,
);

my $d = HTTP::Daemon->new(
    LocalAddr => $O{'listen-host'},
    LocalPort => $O{'listen-port'},
    Reuse => 1,
) or die "Cannot start server: $!";

print "Server started at ", $d->url, "\n";

my %chld;

if ($O{'listen-clients'}) {
    $SIG{CHLD} = sub {
        while ((my $kid = waitpid(-1, WNOHANG)) > 0) {
            delete $chld{$kid};
        }
    };
}

while (1) {
    if ($O{'listen-clients'}) {
        for (scalar(keys %chld) .. $O{'listen-clients'} - 1) {
            my $pid = fork;

            if (!defined $pid) { # Whoopsies need more resources! owo
                die "Can't fork for http child $_: $!";
            }
            if ($pid) {
                $chld{$pid} = 1;
            }
            else {
                $_ = 'DEFAULT' for @SIG{qw/ INT TERM CHLD/};
                http_child($d);
                exit;
            }
        }

        sleep 1;
    }
    else {
        http_child($d);
    }
}

sub http_child {
    my $d = shift;

    my $i;

    while (++$i < $O{'listen-max-req-per-child'}) {
        my $c = $d->accept or last;
        my $r = $c->get_request(1) or last;
        $c->autoflush(1);

        print sprintf("[%s] %s %s\n", $c->peerhost, $r->method, $r->uri->as_string);

        my %FORM = $r->uri->query_form();

        if ($r->method eq 'GET') {
            my $path = CGI::unescape($r->uri->path);
            $path =~ s!^/!!;
            $path ||= 'index.html';
            my $abs_path = File::Spec->catfile($LOCAL_DIR, $path);

            if ($path =~ m!\.\.\/!) {
                _http_error($c, RC_FORBIDDEN);
            }
	    elsif ($path =~ /\|.*\|/) {
                _http_error($c, RC_FORBIDDEN);
            }
            else {
                open(my $fh, $abs_path) or do {
                    _http_error($c, RC_INTERNAL_SERVER_ERROR);
                    next;
                };
                binmode $fh;
                my $content = do { local $/; <$fh> };
                close $fh;
		
		my $type = "text/html; charset=UTF-8";
		$type = "text/css" if $abs_path =~ /\.css$/;
                my $resp = HTTP::Response->new(RC_OK);
                $resp->header('Content-Type' => $type);
                $resp->content($content);
                $c->send_response($resp);
            }
        }
        else {
            _http_error($c, RC_METHOD_NOT_ALLOWED);
        }
        $c->close();
        undef $c;
    }
}

sub _http_error {
    my ($c, $code, $message) = @_;

    $c->send_error($code, $message);
}
