window.onload = function() {
    document.getElementById('word-form')?.addEventListener('submit', (e) => {
        e.preventDefault();
        const word = e.target.word.value.toLowerCase().trim();
        if (word.match(/^[a-z]+$/)) {
            const data = { word };
            const encodedData = btoa(JSON.stringify(data));
            console.log(data, encodedData)
            window.location.href = `/?data=${encodedData}`;
        } else {
            document.getElementById('info').innerText = 'latin letters only'
        }
    });

    updateClock();
    setInterval(updateClock, 5000);
}

function updateClock() {
    fetch('/time')
        .then(response => response.json())
        .then(data => {
            document.getElementById('time').innerText = data.time;
        })
        .catch(error => {
            console.error('Error fetching time:', error);
        });
}