keyboard = [['Q','W','E','R','T','Y','U','I','O','P'],
            ['A','S','D','F','G','H','J','K','L'],
            ['Z','X','C','V','B','N','M']];

stage = 1;
maxStages = 7;
let data;
let inProgress = true;
window.onload = function() {       
    data = JSON.parse(atob(new URLSearchParams(window.location.search).get('data')))
    let {word} = data;
    for (let i = 0; i < word.length; i++) {
        document.getElementById('word-display').innerHTML += '<span class="letter-box not-guessed" id="letter-box-' + i + '"> </span>';
    }
    for (let row of keyboard) {
        let rowDiv = document.createElement('div');
        rowDiv.className = 'keyboard-row';
        for (let letter of row) {
            let button = document.createElement('button');
            button.innerText = letter;
            button.className = 'letter-button';
            button.id = 'button-' + letter;
            button.onclick = function() { handleGuess(letter, word); };
            rowDiv.appendChild(button);
        }
        document.getElementById('letter-buttons').appendChild(rowDiv);
    }
    
    this.addEventListener('keydown', function(event) {
        let letter = event.key.toUpperCase();
        if (letter.length === 1 && letter >= 'A' && letter <= 'Z') {
            let button = document.getElementById('button-' + letter);
            if (button && !button.disabled) {
                button.click();
            }
        }
    });
    
    updateClock();
    setInterval(updateClock, 5000);
}

handleGuess = function(letter, word) {
    if (stage >= maxStages || !inProgress) return;
    document.getElementById('button-' + letter).disabled = true;
    if (word.includes(letter.toLowerCase())) {
        for (let i = 0; i < word.length; i++) {
            if (word[i] === letter.toLowerCase()) {
                document.getElementById('letter-box-' + i).innerText = letter;
                document.getElementById('letter-box-' + i).classList.remove('not-guessed');
            }
        }
        if ([...document.getElementById('word-display').children].every(box => !box.classList.contains('not-guessed'))) {
            // win
            inProgress = false;
            document.getElementById('info').innerText = 'you won!';
        }
    } else {
        stage++;
        document.getElementById('hangman-image').src = 'images/stage' + stage + '.png';
        document.getElementById('info').innerText = `you have ${maxStages - stage}/6 chances`;
        if (stage >= maxStages) {
            // lose
            inProgress = false;
            document.getElementById('info').innerText = `you lost! the word was "${word}"`;
        }
    }
}

function updateClock() {
    fetch('/time')
        .then(response => response.json())
        .then(data => {
            document.getElementById('time').innerText = data.time;
        })
        .catch(error => {
            console.error('Error fetching time:', error);
        });
}