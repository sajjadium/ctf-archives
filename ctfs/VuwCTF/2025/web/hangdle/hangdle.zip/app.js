var createError = require('http-errors');
var express = require('express');
var path = require('path');
const { execSync } = require('child_process');
var _ = require('lodash');
const morgan = require('morgan');
const { cwd } = require('process');
var app = express();

var games = []

const timeDefaults = {
  encoding: 'utf8',
  timeout: 500,
  cwd: '/tmp',
  input: '',
  env: {TZ: "Pacific/Auckland"},
  shell: "/bin/sh",
  killSignal: 'SIGTERM',
  maxBuffer: 1024 * 1024,
  windowsHide: true
}

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  try {
    const data = JSON.parse(atob(req.query.data || 'e30='));
  
    saveGameData(data);
    
    if (data.word) {
      res.render('game', {title: 'hangdle'})
    } else {
      res.render('index', {title: 'hangdle'})
    }
  } catch (error) {
    res.status(400).render('index', {title: 'hangdle'});
  }
  
})

app.get('/time', (req, res) => {  
  try {
    let result;

    var execOptions = {};
    execOptions.encoding = 'utf8';
    execOptions.timeout = 5000;    

    result = execSync('date +%H:%M', {
      cwd: execOptions.cwd,
      input: execOptions.input,
      stdio: execOptions.stdio,
      env: execOptions.env,
      shell: execOptions.shell,
      uid: execOptions.uid,
      gid: execOptions.gid,
      timeout: execOptions.timeout,
      killSignal: execOptions.killSignal,
      maxBuffer: execOptions.maxBuffer,
      encoding: execOptions.encoding,
      windowsHide: execOptions.windowsHide
    });
    res.json({ time: result.trim() });
  } catch (error) {
    console.error('Error getting time:', error);
    res.status(500).json({ error: 'Failed to get time' });
  }
})

app.get('/words', (req, res) => {
  let count = {};
  const words = _.map(games, 'word');
  for (let item of words) {
    count[item] = (count[item] || 0) + 1;
  }
  
  const sortedWords = _.chain(count)
    .toPairs()
    .sortBy(1)
    .reverse()
    .value();

  res.render('words', {title: 'words', words: sortedWords });
})

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('index');
});

function saveGameData(data) {
  games.push(_.merge({}, data));
}

module.exports = app;