#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import hmac
import json
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

DOMAIN = b"HERBARIUM/v2\x00"


def is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


@dataclass(frozen=True, slots=True)
class QuadraticField:
    q: int
    delta: int

    def __post_init__(self) -> None:
        if self.q < 3 or self.q % 2 == 0 or not is_prime(self.q):
            raise ValueError("q must be an odd prime")
        delta = self.delta % self.q
        if delta == 0 or pow(delta, (self.q - 1) // 2, self.q) != self.q - 1:
            raise ValueError("delta must be a quadratic non-residue")
        object.__setattr__(self, "delta", delta)

    @property
    def zero(self) -> int:
        return 0

    @property
    def one(self) -> int:
        return 1

    @property
    def order(self) -> int:
        return self.q * self.q

    def element(self, a: int, b: int = 0) -> int:
        return (a % self.q) + self.q * (b % self.q)

    def components(self, value: int) -> tuple[int, int]:
        value %= self.order
        return value % self.q, value // self.q

    def add(self, left: int, right: int) -> int:
        a, b = self.components(left)
        c, d = self.components(right)
        return self.element(a + c, b + d)

    def sub(self, left: int, right: int) -> int:
        a, b = self.components(left)
        c, d = self.components(right)
        return self.element(a - c, b - d)

    def neg(self, value: int) -> int:
        a, b = self.components(value)
        return self.element(-a, -b)

    def mul(self, left: int, right: int) -> int:
        a, b = self.components(left)
        c, d = self.components(right)
        return self.element(a * c + self.delta * b * d, a * d + b * c)

    def inv(self, value: int) -> int:
        a, b = self.components(value)
        denominator = (a * a - self.delta * b * b) % self.q
        if denominator == 0:
            raise ZeroDivisionError("zero has no inverse")
        inverse = pow(denominator, -1, self.q)
        return self.element(a * inverse, -b * inverse)

    def pow(self, value: int, exponent: int) -> int:
        if exponent < 0:
            value = self.inv(value)
            exponent = -exponent
        result = self.one
        base = value % self.order
        while exponent:
            if exponent & 1:
                result = self.mul(result, base)
            base = self.mul(base, base)
            exponent >>= 1
        return result

    def conjugate(self, value: int) -> int:
        a, b = self.components(value)
        return self.element(a, -b)

    def poly_eval(self, coefficients: Sequence[int], value: int) -> int:
        result = self.zero
        for coefficient in reversed(coefficients):
            result = self.add(self.mul(result, value), coefficient)
        return result


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def normalize_gamma(field: QuadraticField, gamma: Sequence[int]) -> list[int]:
    coefficients = [int(value) % field.q for value in gamma]
    while coefficients and coefficients[-1] == 0:
        coefficients.pop()
    if len(coefficients) < 2:
        raise ValueError("gamma must have positive degree")
    return coefficients


def support_from_pairs(
    field: QuadraticField,
    pairs: Sequence[Sequence[int]],
    signs: Sequence[int],
) -> list[int]:
    if len(pairs) != len(signs):
        raise ValueError("one sign is required for every pair")
    support: list[int] = []
    for pair, sign in zip(pairs, signs, strict=True):
        if len(pair) != 2 or sign not in (-1, 1):
            raise ValueError("invalid conjugate-pair choice")
        a, b = int(pair[0]), int(pair[1])
        if b % field.q == 0:
            raise ValueError("a conjugate pair must have a nonzero u component")
        support.append(field.element(a, sign * b))
    if len(set(support)) != len(support):
        raise ValueError("support coordinates must be distinct")
    return support


def goppa_value(
    field: QuadraticField, coordinate: int, gamma: Sequence[int]
) -> int:
    coefficients = [field.element(value) for value in normalize_gamma(field, gamma)]
    value = field.poly_eval(coefficients, coordinate)
    if value == field.zero:
        raise ValueError("support contains a root of gamma")
    return field.pow(value, field.q - 1)


def parity_check_extension(
    field: QuadraticField,
    support: Sequence[int],
    gamma: Sequence[int],
) -> list[list[int]]:
    coefficients = normalize_gamma(field, gamma)
    degree = (len(coefficients) - 1) * (field.q - 1)
    parity = [[field.zero] * len(support) for _ in range(degree)]
    for column, coordinate in enumerate(support):
        weight = field.inv(goppa_value(field, coordinate, coefficients))
        power = field.one
        for row in range(degree):
            parity[row][column] = field.mul(power, weight)
            power = field.mul(power, coordinate)
    return parity


def expand_parity(
    field: QuadraticField, parity: Sequence[Sequence[int]]
) -> list[list[int]]:
    real: list[list[int]] = []
    imaginary: list[list[int]] = []
    for row in parity:
        real_row: list[int] = []
        imaginary_row: list[int] = []
        for value in row:
            a, b = field.components(value)
            real_row.append(a)
            imaginary_row.append(b)
        real.append(real_row)
        imaginary.append(imaginary_row)
    return real + imaginary


def rref(matrix: Sequence[Sequence[int]], q: int) -> tuple[list[list[int]], list[int]]:
    reduced = [[int(value) % q for value in row] for row in matrix]
    if not reduced:
        return [], []
    width = len(reduced[0])
    if any(len(row) != width for row in reduced):
        raise ValueError("matrix rows must have equal length")
    pivots: list[int] = []
    pivot_row = 0
    for column in range(width):
        selected = next(
            (row for row in range(pivot_row, len(reduced)) if reduced[row][column]),
            None,
        )
        if selected is None:
            continue
        reduced[pivot_row], reduced[selected] = reduced[selected], reduced[pivot_row]
        inverse = pow(reduced[pivot_row][column], -1, q)
        reduced[pivot_row] = [(value * inverse) % q for value in reduced[pivot_row]]
        for row in range(len(reduced)):
            if row == pivot_row:
                continue
            factor = reduced[row][column]
            if factor:
                reduced[row] = [
                    (value - factor * pivot_value) % q
                    for value, pivot_value in zip(
                        reduced[row], reduced[pivot_row], strict=True
                    )
                ]
        pivots.append(column)
        pivot_row += 1
        if pivot_row == len(reduced):
            break
    return reduced, pivots


def nullspace(matrix: Sequence[Sequence[int]], q: int) -> list[list[int]]:
    if not matrix:
        raise ValueError("a parity-check matrix is required")
    reduced, pivots = rref(matrix, q)
    width = len(reduced[0])
    pivot_set = set(pivots)
    free_columns = [column for column in range(width) if column not in pivot_set]
    basis: list[list[int]] = []
    for free_column in free_columns:
        vector = [0] * width
        vector[free_column] = 1
        for row, pivot_column in enumerate(pivots):
            vector[pivot_column] = -reduced[row][free_column] % q
        basis.append(vector)
    return basis


def scramble_rows(
    matrix: Sequence[Sequence[int]], q: int, rng: random.Random
) -> list[list[int]]:
    result = [[int(value) % q for value in row] for row in matrix]
    for _ in range(max(32, len(result) * 8)):
        operation = rng.randrange(3)
        row = rng.randrange(len(result))
        if operation == 0 and len(result) > 1:
            other = rng.randrange(len(result) - 1)
            if other >= row:
                other += 1
            result[row], result[other] = result[other], result[row]
        elif operation == 1:
            scale = rng.randrange(1, q)
            result[row] = [(scale * value) % q for value in result[row]]
        elif len(result) > 1:
            other = rng.randrange(len(result) - 1)
            if other >= row:
                other += 1
            scale = rng.randrange(1, q)
            result[row] = [
                (value + scale * other_value) % q
                for value, other_value in zip(result[row], result[other], strict=True)
            ]
    return result


def construct_generator(
    field: QuadraticField,
    pairs: Sequence[Sequence[int]],
    signs: Sequence[int],
    gamma: Sequence[int],
    rng: random.Random,
) -> list[list[int]]:
    support = support_from_pairs(field, pairs, signs)
    parity = expand_parity(field, parity_check_extension(field, support, gamma))
    return scramble_rows(nullspace(parity, field.q), field.q, rng)


def encode(messages: Sequence[Sequence[int]], generator: Sequence[Sequence[int]], q: int) -> list[list[int]]:
    if not generator:
        raise ValueError("generator must not be empty")
    dimension = len(generator)
    length = len(generator[0])
    words: list[list[int]] = []
    for message in messages:
        if len(message) != dimension:
            raise ValueError("message length does not match code dimension")
        word = [0] * length
        for coefficient, row in zip(message, generator, strict=True):
            for column, value in enumerate(row):
                word[column] = (word[column] + int(coefficient) * int(value)) % q
        words.append(word)
    return words


def message_bytes(messages: Sequence[Sequence[int]], q: int) -> bytes:
    rows = [list(map(int, row)) for row in messages]
    if not rows or not rows[0] or any(len(row) != len(rows[0]) for row in rows):
        raise ValueError("messages must form a nonempty rectangular matrix")
    width = max(1, (q.bit_length() + 7) // 8)
    header = (
        int(q).to_bytes(4, "big")
        + len(rows).to_bytes(4, "big")
        + len(rows[0]).to_bytes(4, "big")
        + bytes([width])
    )
    body = bytearray()
    for row in rows:
        for value in row:
            if not 0 <= value < q:
                raise ValueError("message entry is outside the base field")
            body.extend(value.to_bytes(width, "big"))
    return header + bytes(body)


def derive_delay_base(
    messages: Sequence[Sequence[int]],
    q: int,
    instance_id: str,
    modulus: int,
) -> int:
    if not instance_id or not instance_id.isascii():
        raise ValueError("instance identifier must be nonempty ASCII")
    if modulus < 15 or modulus % 2 == 0:
        raise ValueError("delay modulus must be an odd composite-sized integer")
    width = (modulus.bit_length() + 7) // 8
    material = (
        DOMAIN
        + b"delay-base\x00"
        + instance_id.encode("ascii")
        + modulus.to_bytes(width, "big")
        + message_bytes(messages, q)
    )
    counter = 0
    while True:
        digest = hashlib.shake_256(
            material + counter.to_bytes(8, "big")
        ).digest(width + 16)
        candidate = 2 + int.from_bytes(digest, "big") % (modulus - 3)
        if math.gcd(candidate, modulus) == 1:
            base = pow(candidate, 2, modulus)
            if base not in (0, 1):
                return base
        counter += 1


def evaluate_delay(
    base: int,
    modulus: int,
    squarings: int,
    *,
    start_value: int | None = None,
    completed_squarings: int = 0,
) -> int:
    if not 1 < base < modulus or math.gcd(base, modulus) != 1:
        raise ValueError("delay base must be a nontrivial unit modulo the modulus")
    if not 0 <= completed_squarings <= squarings:
        raise ValueError("completed squaring count is outside the requested range")
    if start_value is None:
        if completed_squarings != 0:
            raise ValueError("a resumed evaluation requires an intermediate value")
        value = base
    else:
        if not 0 < start_value < modulus:
            raise ValueError("intermediate value is outside the modulus")
        value = int(start_value)
    for _ in range(completed_squarings, squarings):
        value = pow(value, 2, modulus)
    return value


def derive_archive_key(
    messages: Sequence[Sequence[int]],
    q: int,
    instance_id: str,
    modulus: int,
    squarings: int,
    delay_output: int,
) -> bytes:
    if not 0 <= delay_output < modulus:
        raise ValueError("delay output is outside the modulus")
    width = (modulus.bit_length() + 7) // 8
    return hashlib.sha256(
        DOMAIN
        + b"archive-key\x00"
        + instance_id.encode("ascii")
        + int(squarings).to_bytes(8, "big")
        + modulus.to_bytes(width, "big")
        + delay_output.to_bytes(width, "big")
        + message_bytes(messages, q)
    ).digest()

def open_flag(sealed: dict[str, str], key: bytes, aad: bytes) -> bytes:
    nonce = bytes.fromhex(sealed["nonce"])
    ciphertext = bytes.fromhex(sealed["ciphertext"])
    supplied_tag = bytes.fromhex(sealed["tag"])
    expected_tag = hmac.new(
        key, DOMAIN + b"tag\x00" + aad + nonce + ciphertext, hashlib.sha256
    ).digest()[:16]
    if not hmac.compare_digest(supplied_tag, expected_tag):
        raise ValueError("payload authentication failed")
    stream = hashlib.shake_256(DOMAIN + b"stream\x00" + key + nonce).digest(
        len(ciphertext)
    )
    return bytes(
        value ^ mask for value, mask in zip(ciphertext, stream, strict=True)
    )


def validate_instance(instance: dict[str, Any]) -> None:
    required = {
        "format",
        "profile",
        "field",
        "goppa",
        "dimensions",
        "support_pairs",
        "generator",
        "received",
        "delay",
        "instance_id",
        "integrity",
        "sealed_flag",
    }
    if set(instance) != required or instance["format"] != "HERBARIUM-2":
        raise ValueError("unsupported or malformed instance")
    core_keys = (
        "format",
        "profile",
        "field",
        "goppa",
        "dimensions",
        "support_pairs",
        "generator",
        "received",
        "delay",
    )
    core = {key: instance[key] for key in core_keys}
    digest = hashlib.sha256(canonical_json(core)).hexdigest()
    if instance["integrity"] != digest or instance["instance_id"] != digest[:24]:
        raise ValueError("instance integrity check failed")
    q = int(instance["field"]["q"])
    field = QuadraticField(q, int(instance["field"]["delta"]))
    gamma = normalize_gamma(field, instance["goppa"]["gamma"])
    dimensions = instance["dimensions"]
    n = int(dimensions["n"])
    k = int(dimensions["k"])
    ell = int(dimensions["ell"])
    degree = (len(gamma) - 1) * (q - 1)
    if int(dimensions["r"]) != degree or int(instance["goppa"]["exponent"]) != q - 1:
        raise ValueError("inconsistent Goppa parameters")
    if len(instance["support_pairs"]) != n:
        raise ValueError("invalid support-pair count")
    generator = instance["generator"]
    received = instance["received"]
    if len(generator) != k or any(len(row) != n for row in generator):
        raise ValueError("invalid generator dimensions")
    if len(received) != ell or any(len(row) != n for row in received):
        raise ValueError("invalid received-word dimensions")
    delay = instance["delay"]
    if not isinstance(delay, dict) or set(delay) != {
        "scheme", "modulus", "modulus_bits", "squarings"
    }:
        raise ValueError("malformed delay parameters")
    if delay["scheme"] != "RSW-QR-1":
        raise ValueError("unsupported delay scheme")
    modulus_hex = delay["modulus"]
    if not isinstance(modulus_hex, str) or not modulus_hex or modulus_hex.lower() != modulus_hex:
        raise ValueError("delay modulus must be canonical lowercase hexadecimal")
    modulus = int(modulus_hex, 16)
    if format(modulus, "x") != modulus_hex:
        raise ValueError("delay modulus is not canonically encoded")
    modulus_bits = int(delay["modulus_bits"])
    squarings = int(delay["squarings"])
    if modulus < 15 or modulus % 2 == 0 or modulus.bit_length() != modulus_bits:
        raise ValueError("invalid delay modulus")
    if modulus_bits < 64 or modulus_bits % 2 or not 0 < squarings < 1 << 63:
        raise ValueError("invalid delay work factor")

def load_instance(path: str | Path) -> dict[str, Any]:
    instance = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(instance, dict):
        raise ValueError("instance root must be an object")
    validate_instance(instance)
    return instance


def decrypt_with_messages(
    instance: dict[str, Any], messages: Sequence[Sequence[int]]
) -> bytes:
    validate_instance(instance)
    delay = instance["delay"]
    modulus = int(delay["modulus"], 16)
    squarings = int(delay["squarings"])
    q = int(instance["field"]["q"])
    base = derive_delay_base(messages, q, instance["instance_id"], modulus)
    output = evaluate_delay(base, modulus, squarings)
    key = derive_archive_key(
        messages, q, instance["instance_id"], modulus, squarings, output
    )
    aad = f"HERBARIUM/{instance['instance_id']}".encode("ascii")
    return open_flag(instance["sealed_flag"], key, aad)


def main() -> None:
    parser = argparse.ArgumentParser(description="Inspect a HERBARIUM instance")
    parser.add_argument("instance", type=Path, nargs="?", default=Path("instance.json"))
    args = parser.parse_args()
    instance = load_instance(args.instance)
    dimensions = instance["dimensions"]
    gamma = instance["goppa"]["gamma"]
    print(f"HERBARIUM instance {instance['instance_id']}")
    print(
        f"GF({instance['field']['q']}^2), gamma={gamma}, "
        f"[n,k]=[{dimensions['n']},{dimensions['k']}], "
        f"ell={dimensions['ell']}, t={dimensions['t']}"
    )
    delay = instance["delay"]
    print(
        f"delay={delay['squarings']} sequential squarings "
        f"modulo a {delay['modulus_bits']}-bit integer"
    )
    print("Recover the message matrix and call decrypt_with_messages().")


if __name__ == "__main__":
    main()
