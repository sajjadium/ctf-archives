#!/bin/sh
set -eu

flag_value="${FLAG:-}"
if [ -z "$flag_value" ]; then
  flag_value='v8ctf{local_test_flag}'
fi
umask 077
printf '%s\n' "$flag_value" > /flag
chown root:root /flag
chmod 0444 /flag
rm -f /tmp/allow-flag
unset FLAG flag_value

exec runuser -u ctf -- env -i \
  HOME=/home/ctf \
  PATH=/opt/challenge/bin:/usr/local/bin:/usr/bin:/bin \
  LD_PRELOAD=/opt/challenge/lib/libv8ctf-execlp-shim.so \
  CHROME_BIN="${CHROME_BIN:-/opt/chrome/chrome-linux64/chrome}" \
  BOT_PORT="${BOT_PORT:-1337}" \
  BOT_TIMEOUT="${BOT_TIMEOUT:-25}" \
  PYTHONUNBUFFERED=1 \
  python3 /srv/challenge/server.py
