#define _GNU_SOURCE

#include <errno.h>
#include <stdarg.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>

__attribute__((force_align_arg_pointer))
int execlp(const char *file, const char *arg, ...) {
  if (strcmp(file, "man") == 0 && strcmp(arg, "man") == 0) {
    char *const argv[] = {(char *)arg, NULL};
    return execvp(file, argv);
  }

  char *argv[65];
  size_t count = 0;
  argv[count++] = (char *)arg;

  va_list arguments;
  va_start(arguments, arg);
  while (count < 64) {
    char *next = va_arg(arguments, char *);
    argv[count++] = next;
    if (next == NULL) break;
  }
  va_end(arguments);

  if (argv[count - 1] != NULL) {
    errno = E2BIG;
    return -1;
  }
  return execvp(file, argv);
}
