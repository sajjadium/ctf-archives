#!/usr/bin/env python3

import html
import json
import os
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


CHROME = os.environ.get(
    "CHROME_BIN", "/opt/chrome/chrome-linux64/chrome")
PORT = int(os.environ.get("BOT_PORT", "1337"))
TIMEOUT = float(os.environ.get("BOT_TIMEOUT", "25"))
FLAG = Path("/flag")
ALLOW_FLAG = Path("/tmp/allow-flag")
BOT_LOCK = threading.Lock()
MAX_PROXY_RESPONSE = 8 * 1024 * 1024

CHROME_FLAGS = (
    "--headless=new",
    "--no-sandbox",
    "--disable-gpu",
    "--disable-background-networking",
    "--disable-component-update",
    "--disable-default-apps",
    "--disable-extensions",
    "--disable-sync",
    "--disable-crash-reporter",
    "--disable-features=SpareRendererForSitePerProcess",
    "--renderer-process-limit=1",
    "--metrics-recording-only",
    "--no-first-run",
    "--noerrdialogs",
    "--enable-logging=stderr",
    "--log-level=0",
    "--js-flags=--expose-gc --allow-natives-syntax --turbolev "
    "--max-old-space-size=8192 --min-semi-space-size=64 "
    "--max-semi-space-size=64 --single-threaded --single-threaded-gc",
)


def valid_url(candidate):
    if not isinstance(candidate, str) or len(candidate) > 2048:
        return False
    try:
        parsed = urllib.parse.urlsplit(candidate)
    except ValueError:
        return False
    return (
        parsed.scheme in ("http", "https")
        and bool(parsed.hostname)
        and parsed.username is None
        and parsed.password is None
    )


def stop_process_group(process):
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=2)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            pass


class LoopbackProxy(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, upstream_origin):
        self.upstream_origin = upstream_origin
        super().__init__(address, ProxyHandler)


class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        target = urllib.parse.urljoin(self.server.upstream_origin, self.path)
        request = urllib.request.Request(
            target, headers={"User-Agent": "v8ctf-loopback-mirror/1"})
        try:
            response = urllib.request.urlopen(request, timeout=10)
        except urllib.error.HTTPError as error:
            response = error
        except (OSError, urllib.error.URLError):
            self.send_error(HTTPStatus.BAD_GATEWAY)
            return
        try:
            body = response.read(MAX_PROXY_RESPONSE + 1)
            if len(body) > MAX_PROXY_RESPONSE:
                self.send_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
                return
            self.send_response(response.status)
            content_type = response.headers.get("Content-Type")
            if content_type:
                self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        finally:
            response.close()

    def log_message(self, format_string, *arguments):
        pass


def visit(url):
    parsed = urllib.parse.urlsplit(url)
    upstream_origin = urllib.parse.urlunsplit(
        (parsed.scheme, parsed.netloc, "", "", ""))
    proxy = LoopbackProxy(("127.0.0.1", 0), upstream_origin)
    proxy_thread = threading.Thread(target=proxy.serve_forever, daemon=True)
    proxy_thread.start()
    browser_url = urllib.parse.urlunsplit((
        "http",
        f"127.0.0.1:{proxy.server_address[1]}",
        parsed.path or "/",
        parsed.query,
        parsed.fragment,
    ))
    profile = tempfile.mkdtemp(prefix="v8ctf-profile-", dir="/dev/shm")
    command = [
        CHROME, *CHROME_FLAGS, f"--user-data-dir={profile}", browser_url]
    environment = os.environ.copy()
    environment["PATH"] = "/opt/challenge/bin:/usr/local/bin:/usr/bin:/bin"
    process = None
    status = "timeout"
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=environment,
            start_new_session=True,
        )
        deadline = time.monotonic() + TIMEOUT
        while time.monotonic() < deadline:
            if ALLOW_FLAG.is_file():
                status = "revealed"
                break
            if process.poll() is not None:
                status = "exited"
                break
            time.sleep(0.1)
    finally:
        if process is not None:
            stop_process_group(process)
        proxy.shutdown()
        proxy.server_close()
        proxy_thread.join(timeout=2)
        shutil.rmtree(profile, ignore_errors=True)
    return status


class Handler(BaseHTTPRequestHandler):
    server_version = "v8ctf-url-bot/1"

    def send_bytes(self, status, body, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, status, value):
        body = json.dumps(value, separators=(",", ":")).encode()
        self.send_bytes(status, body, "application/json")

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        if path == "/healthz":
            self.send_json(HTTPStatus.OK, {"ok": True})
            return
        if path == "/flag":
            if not ALLOW_FLAG.is_file():
                self.send_json(
                    HTTPStatus.NOT_FOUND,
                    {"ok": False, "error": "flag is not public"},
                )
                return
            try:
                body = FLAG.read_bytes()
            except FileNotFoundError:
                self.send_json(
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                    {"ok": False, "error": "flag is unavailable"},
                )
                return
            self.send_bytes(HTTPStatus.OK, body, "text/plain; charset=utf-8")
            return
        if path != "/":
            self.send_json(HTTPStatus.NOT_FOUND, {"ok": False})
            return
        page = """<!doctype html>
<meta charset=utf-8>
<title>v8ctf URL bot</title>
<h1>v8ctf URL bot</h1>
<form method=post action=/submit>
  <label>URL <input name=url size=80 required></label>
  <button>Visit</button>
</form>
<p>The bot runs the pinned vulnerable Chromium build for one visit.</p>
""".encode()
        self.send_bytes(HTTPStatus.OK, page, "text/html; charset=utf-8")

    def do_POST(self):
        if urllib.parse.urlsplit(self.path).path != "/submit":
            self.send_json(HTTPStatus.NOT_FOUND, {"ok": False})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = -1
        if length < 0 or length > 8192:
            self.send_json(
                HTTPStatus.REQUEST_ENTITY_TOO_LARGE,
                {"ok": False, "error": "invalid request size"},
            )
            return
        raw = self.rfile.read(length)
        content_type = self.headers.get("Content-Type", "")
        try:
            if content_type.startswith("application/json"):
                url = json.loads(raw.decode()).get("url")
            else:
                values = urllib.parse.parse_qs(
                    raw.decode(), keep_blank_values=True)
                url = values.get("url", [None])[0]
        except (UnicodeDecodeError, ValueError, AttributeError):
            url = None
        if not valid_url(url):
            self.send_json(
                HTTPStatus.BAD_REQUEST,
                {"ok": False, "error": "expected an http(s) URL"},
            )
            return
        if not BOT_LOCK.acquire(blocking=False):
            self.send_json(
                HTTPStatus.TOO_MANY_REQUESTS,
                {"ok": False, "error": "bot is busy"},
            )
            return
        try:
            status = visit(url)
        finally:
            BOT_LOCK.release()
        self.send_json(
            HTTPStatus.OK,
            {"ok": status == "revealed", "status": status},
        )

    def log_message(self, format_string, *arguments):
        message = format_string % arguments
        print(f"{self.client_address[0]} {html.escape(message)}", flush=True)


if __name__ == "__main__":
    if not Path(CHROME).is_file():
        raise SystemExit(f"missing Chromium binary: {CHROME}")
    server = ThreadingHTTPServer(("0.0.0.0", PORT), Handler)
    print(f"v8ctf URL bot listening on 0.0.0.0:{PORT}", flush=True)
    server.serve_forever()
