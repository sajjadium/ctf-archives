#include <fcntl.h>
#include <unistd.h>

int main(void) {
  int fd = open("/tmp/allow-flag", O_WRONLY | O_CREAT | O_CLOEXEC, 0644);
  if (fd < 0) return 1;
  return close(fd) == 0 ? 0 : 1;
}
