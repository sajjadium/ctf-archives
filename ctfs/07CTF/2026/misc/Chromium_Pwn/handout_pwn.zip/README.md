# pwn-07ctf

Build and run:

```sh
FLAG='v8ctf{example}' docker compose up --build
```

The service listens on HTTP port `1337`.
