import os
from pathlib import Path
import json
import hmac
import re

from flask import Flask, request, jsonify, Response

app = Flask(__name__)

_SECRET = Path("/run/endless/flag").read_text()
_API_KEY = os.environ["API_KEY"]
_INBOX = [_SECRET]

_RANGE_RE = re.compile(r"^bytes=(\d+)-$")
_ERROR_HTML = b"<body><div>The given range exceeds the response size</div></body>"


def _partial(body: bytes, mimetype: str, start: int):
    total = len(body)
    chunk = body[start:]

    response = Response(chunk, status=206, mimetype=mimetype)
    response.headers["Accept-Ranges"] = "bytes"
    response.headers["Content-Range"] = f"bytes {start}-{total - 1}/{total}"
    response.headers["Content-Length"] = str(len(chunk))
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response


@app.route("/")
def index():
    return "", 204


@app.route("/messages/search")
def search():
    if not hmac.compare_digest(request.args.get("key", ""), _API_KEY):
        return jsonify({"error": "Unauthorized"}), 401

    q = request.args.get("q", "")
    results = [m for m in _INBOX if m.startswith(q)]
    data = json.dumps({"results": results}).encode()

    range_header = request.headers.get("Range")

    if not range_header:
        response = Response(
            data,
            status=200,
            mimetype="application/json",
        )
        response.headers["Accept-Ranges"] = "bytes"
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        return response

    match = _RANGE_RE.fullmatch(range_header.strip())

    if not match:
        padding = b" "
        return _partial(
            padding + _ERROR_HTML,
            "text/html",
            0,
        )

    start = int(match.group(1))

    if start < len(data):
        return _partial(
            data,
            "application/json",
            start,
        )

    error_document = (b" " * start) + _ERROR_HTML

    return _partial(
        error_document,
        "text/html",
        start,
    )


_ALLOWED_HOSTS = {"api", "localhost", "127.0.0.1"}


@app.before_request
def guard():
    if request.method == "OPTIONS":
        return "", 405

    if request.host.split(":")[0] not in _ALLOWED_HOSTS:
        return "", 403