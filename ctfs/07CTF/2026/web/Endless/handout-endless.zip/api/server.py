import hashlib
import http.client
import secrets
import socket
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


_SEED = secrets.token_bytes(32)
_UPSTREAM_SOCKET = "/run/endless/api.sock"


class UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, unix_path, timeout=10):
        super().__init__("localhost", timeout=timeout)
        self.unix_path = unix_path

    def connect(self):
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(self.timeout)
        sock.connect(self.unix_path)
        self.sock = sock


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _schedule(self):
        url = urllib.parse.urlsplit(self.path)
        query = urllib.parse.parse_qs(url.query, keep_blank_values=True)

        range_header = self.headers.get("Range", "")
        range_start = ""
        if range_header.lower().startswith("bytes="):
            raw_start = range_header[6:].split("-", 1)[0].strip()
            try:
                range_start = str(int(raw_start, 10))
            except ValueError:
                range_start = raw_start

        value = "\0".join((
            query.get("key", [""])[0],
            query.get("q", [""])[0],
            range_start,
        )).encode()
        digest = hashlib.blake2s(value, key=_SEED, digest_size=2).digest()
        time.sleep(int.from_bytes(digest, "big") % 64 / 1000)

    def _forward(self):
        self._schedule()

        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else None
        headers = dict(self.headers)
        headers["Connection"] = "close"

        upstream = UnixHTTPConnection(_UPSTREAM_SOCKET, timeout=10)
        try:
            upstream.request(self.command, self.path, body=body, headers=headers)
            response = upstream.getresponse()
            data = response.read()
            response_headers = [
                (name, value)
                for name, value in response.getheaders()
                if name.lower() not in {"connection", "transfer-encoding", "content-length"}
            ]

            self.send_response(response.status, response.reason)
            for name, value in response_headers:
                self.send_header(name, value)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Connection", "close")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(data)
        except (FileNotFoundError, ConnectionRefusedError, OSError):
            self.send_response(503, "Service Unavailable")
            self.send_header("Content-Length", "0")
            self.send_header("Connection", "close")
            self.end_headers()
        finally:
            upstream.close()
            self.close_connection = True

    do_GET = _forward
    do_HEAD = _forward
    do_POST = _forward
    do_OPTIONS = _forward

    def log_message(self, format, *args):
        pass


ThreadingHTTPServer(("127.0.0.1", 9090), Handler).serve_forever()
