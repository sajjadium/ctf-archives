# Endless

## Build

```sh
docker build -t web-endless-07ctf .
```

## Run

```sh
docker run --rm \
  -p 3000:3000 \
  -e FLAG='07CTF{example}' \
  --name web-endless-07ctf \
  web-endless-07ctf
```

Only port 3000 is externally exposed.

- Application: `GET /`
- Bot submission: `POST /submit` with form field `url` (JSON `{ "url": "..." }` is also accepted)

`ADMIN_TOKEN` and `API_KEY` are generated inside the container on every start.
