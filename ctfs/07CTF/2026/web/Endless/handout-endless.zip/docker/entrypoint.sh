#!/bin/sh
set -eu

: "${FLAG:?FLAG must be set}"

# Consume the platform-provided FLAG before starting Supervisor so it is not
# inherited by the proxy, bot launcher, or Chrome child process.
install -d -m 0700 -o app -g app /run/endless
umask 077
printf '%s' "$FLAG" > /run/endless/flag
chown app:app /run/endless/flag
chmod 0400 /run/endless/flag
rm -f /run/endless/api.sock
unset FLAG

# Runtime-only secrets shared only by the processes that need them.
ADMIN_TOKEN="$(node -e "process.stdout.write(require('crypto').randomBytes(32).toString('hex'))")"
API_KEY="$(node -e "process.stdout.write(require('crypto').randomBytes(8).toString('hex'))")"
export ADMIN_TOKEN API_KEY

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/endless.conf
