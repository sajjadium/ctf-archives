# Description

I hate CSRF tokens, who even is using form element these days?