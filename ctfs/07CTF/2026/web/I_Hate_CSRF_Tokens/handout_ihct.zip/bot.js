const puppeteer = require("puppeteer");

async function visit(url) {
  const browser = await puppeteer.launch({
    args: [
        "--no-sandbox",
        "--headless"
    ],
    executablePath: "/usr/bin/google-chrome",
  });

  try {
    const page = await browser.newPage();

    await page.goto(url,
      { timeout: 5000 }
    );

    await new Promise((resolve) => setTimeout(resolve, 5000));
    
    await page.close();
    await browser.close();

  } catch (e) {
    console.log(e);
    await browser.close();
  }
}

module.exports = { visit };
