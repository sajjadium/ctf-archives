const express = require("express");
const path = require("path");
const fs = require("fs");
const { visit } = require("./bot");
const app = express();

const FLAG = process.env.FLAG || "07CTF{DUMMY_FLAG}";
let is_under_construction = true;

app.use(express.json());
app.use((req, res, next) => {
  res.setHeader("Content-Security-Policy", "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; ");
  next();
});
app.get("/", (req, res) => {
  const indexPath = path.join(__dirname, "/static/index.html");
  let html = fs.readFileSync(indexPath, "utf8");

  const injected = req.query.html || "";
  html = html.replace("</body>", `${injected}</body>`);

  res.send(html);
});

app.post("/config", (req, res) => {
    const ip = req.ip.replace(/^::ffff:/, "");
    const allowed = ip === "127.0.0.1" || ip === "::1" || ip === "localhost";

    if (!allowed) {
        return res.status(403).send("localhost only");
    }

    if (req.hostname !== "localhost" && req.hostname !== "127.0.0.1") {
        return res.status(403).send("localhost only");
    }

    if (typeof req.body.config === "boolean") {
        is_under_construction = req.body.config;
    }

    res.json({
        ok: true,
        under_construction: is_under_construction,
    });
});

app.get("/flag", (req, res) => {
  if (is_under_construction) {
    return res.status(503).send("Site is still under construction.");
  }
  res.type("text/plain").send(FLAG);
});

app.get("/bot", (req, res) => {
  visit(req.query.visit);
  res.send("ok");
});

app.listen(3001, () => {
  console.log("Server listening on http://localhost:3001");
});