from flask import Flask, request, render_template, make_response, redirect, url_for, session, jsonify, flash
import os
import uuid
from functools import wraps
from datetime import datetime
import logging
from gunicorn.app.base import BaseApplication
                
                                
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
app = Flask(__name__)
app.secret_key = 'REDACTED'

       
FLAG = os.environ.get("FLAG", "flag{not_set}")

                   
users = {
    "admin": {
        "password": os.environ.get("ADMIN_PASSWORD", "report_to_admin_if_this_works"),
        "name": f"admin",
        "role": "admin",
        "is_seller": True,
        "cart": [],
        "balance": 999999999
    },
    FLAG: {
        "password": FLAG,
        "name": FLAG,
        "role": "user",
        "cart": [],
        "is_seller": False,
        "balance": 1000
    }
}
logger.info("Challenge users initialized")
products = {
    str(uuid.uuid4()):{
            'title': "BAYC",
            'description': "The Bored Ape Yacht Club is a collection of 10,000 unique Bored Ape NFTs— unique digital collectibles living on the Ethereum blockchain.",
            'price': 100,
            'image_url':  '/static/images/bored.png',
            'category': "BAYC",
            'seller': "admin",
            'seller_name': "admin",
            'created_at': datetime.now().isoformat(),
            'status': 'pending'  
        }}  

                  
def generate_uuid():
    return str(uuid.uuid4())

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def seller_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            flash('Please login first', 'error')
            return redirect(url_for('login'))
        if not session.get('is_seller'):
            flash('Seller access required', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

        
@app.route('/')
def index():
    featured_products = []
                                                       
    for pid, product in products.items():
        if product['seller'] == 'admin':
            featured_products.append({**product, 'id': pid})
    return render_template('index.html', products=featured_products[:6])

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        name = request.form.get('name', '').strip()
        
        if not username or not password or not name:
            flash('All fields are required', 'error')
            return render_template('register.html')
        
        if username in users:
            flash('Username already exists', 'error')
            return render_template('register.html')
        
        if len(username) < 3 or len(password) < 6:
            flash('Username must be 3+ chars, password 6+ chars', 'error')
            return render_template('register.html')
        
        users[username] = {
            'password': password,
            'name': name,
            'role': 'user',
            'cart': [],
            'balance': 1000                                  
        }
        
        flash('Registration successful! Please login.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    print("here")
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        user = users.get(username)
        if user and user['password'] == password:
            session['username'] = username
            session['is_seller'] = user.get('is_seller', False)
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        
        flash('Invalid credentials', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
                                                                  
                                   
                       
                                     
                         
    user = users.get(session['username'], None)
    if not user:
        return "User not found", 404
    my_products = []
    if session.get('is_seller', False):
        users[session['username']]['is_seller'] = True
        for pid, product in products.items():
            if product['seller'] == session['username']:
                my_products.append({**product, 'id': pid})
    
    return render_template('dashboard.html', user=user, products=my_products)

@app.route('/upgrade-seller', methods=['POST'])
@login_required
def upgrade_seller():
    flash('This is disabled temporarily!', 'info')
    return redirect(url_for('dashboard'))
    if session.get('is_seller'):
        flash('You are already a seller!', 'info')
    else:
        session['is_seller'] = True
        users[session['username']]['is_seller'] = True
        flash('Congratulations! You are now a seller!', 'success')
    

@app.route('/create-product', methods=['GET', 'POST'])
@seller_required
def create_product():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        description = request.form.get('description', '').strip()
        price = request.form.get('price', '0')
        image_url = request.form.get('image_url', '').strip()
        category = request.form.get('category', 'art')
        
        try:
            price = float(price)
        except:
            price = 0.0
        
        if not title:
            flash('Title is required', 'error')
            return render_template('create_product.html')
        
        product_id = generate_uuid()
        products[product_id] = {
            'title': title,
            'description': description,
            'price': price,
            'image_url': image_url or '/static/images/default_nft.png',
            'category': category,
            'seller': session['username'],
            'seller_name': session['username'],
            'created_at': datetime.now().isoformat(),
            'status': 'pending'                               
        }
        
        flash(f'Product created! Share this link: /product/{product_id}', 'success')
                                                                                
                              
        return redirect(url_for('dashboard'))
    
    return render_template('create_product.html')

@app.route('/product/<product_id>')
def view_product(product_id):
                                                 
                          
    product = products.get(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('index'))
    
    seller = users.get(product['seller'], {})
    return render_template('product.html', product=product, product_id=product_id, seller_name=product['seller'])

@app.route('/add-to-cart/<product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    product = products.get(product_id)
    if not product:
        flash('Product not found', 'error')
        return redirect(url_for('index'))
    
    user = users[session['username']]
    if product_id not in user['cart']:
        user['cart'].append(product_id)
        flash(f'Added "{product["title"]}" to cart!', 'success')
    else:
        flash('Product already in cart', 'info')
    
    return redirect(url_for('view_product', product_id=product_id))

@app.route('/cart')
@login_required
def cart():
    user = users[session['username']]
    cart_items = []
    total = 0
    
    for pid in user['cart']:
        product = products.get(pid)
        if product:
            cart_items.append({**product, 'id': pid})
            total += product['price']
    
    return render_template('cart.html', items=cart_items, total=total)

@app.route('/remove-from-cart/<product_id>', methods=['POST'])
@login_required
def remove_from_cart(product_id):
    user = users[session['username']]
    if product_id in user['cart']:
        user['cart'].remove(product_id)
        flash('Removed from cart', 'success')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    user = users[session['username']]
    if not user['cart']:
        flash('Cart is empty', 'error')
        return redirect(url_for('cart'))
    
    total = sum(products[pid]['price'] for pid in user['cart'] if pid in products)
    
    if user['balance'] < total:
        flash('Insufficient balance', 'error')
        return redirect(url_for('cart'))
    
    user['balance'] -= total
    purchased = len(user['cart'])
    user['cart'] = []
    
    flash(f'Successfully purchased {purchased} NFT(s)!', 'success')
    return redirect(url_for('dashboard'))

                                         
@app.route('/note')
def note():
    content = request.args.get('content', '')
    
    html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Secure Note</title>
        <link rel="stylesheet" href="/static/css/style.css">
    </head>
    <body>
        <h1>Your Note</h1>
        <div class="container">
            <div class="user-content">
                {content}
            </div>
        </div>
    </body>
    </html>
    """
    
    resp = make_response(html)
    resp.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'unsafe-inline' 'self'; "
    resp.headers['Cross-Origin-Opener-Policy'] = "same-origin"
    return resp

@app.route('/health')
def health():
    return jsonify({'status': 'healthy'})

@app.route('/flag')
def internal_secret():
    if request.headers.get('X-Internal-Listener') != '1':
        return jsonify({'error': 'not found'}), 404
    return jsonify({'secret_key': app.secret_key})

                
@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

@app.after_request
def add_security_headers(response):
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; style-src 'unsafe-inline' 'self';"
    response.headers['Cross-Origin-Opener-Policy'] = "same-origin"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Cache-Control'] = 'no-store'
    return response

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

