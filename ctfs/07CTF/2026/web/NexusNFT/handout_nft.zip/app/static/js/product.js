function copyLink() {
    navigator.clipboard.writeText(window.location.href);
    alert('Link copied to clipboard!');
}

function shareTwitter() {
    const text = encodeURIComponent('Check out this amazing NFT on NexusNFT! {{ product.title }}');
    const url = encodeURIComponent(window.location.href);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
}

function buyNow() {
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '{{ url_for("add_to_cart", product_id=product_id) }}';
    document.body.appendChild(form);
    form.submit();
}