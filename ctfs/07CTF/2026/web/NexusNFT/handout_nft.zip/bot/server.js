const express = require('express');
const puppeteer = require('puppeteer-core');
const crypto = require('crypto');
const path = require('path');

const app = express();
app.set('trust proxy', 'loopback');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));


const PORT = process.env.PORT || 3000;
const APP_URL = process.env.APP_URL || 'https://nft-app:5000';
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || process.env.FLAG;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || process.env.FLAG;
const POW_DIFFICULTY = parseInt(process.env.POW_DIFFICULTY) || 4; 
const VISIT_TIMEOUT = 8000;
const EXTERNAL_DWELL_MS = parseInt(process.env.EXTERNAL_DWELL_MS) || 20000;


const urlQueue = [];
let isProcessing = false;
let queueStats = {
    processed: 0,
    pending: 0
};


const challenges = new Map();


function generateChallenge() {
    const challenge = crypto.randomBytes(16).toString('hex');
    const timestamp = Date.now();
    challenges.set(challenge, timestamp);

    
    for (const [key, time] of challenges) {
        if (Date.now() - time > 300000) {
            challenges.delete(key);
        }
    }

    return { challenge, difficulty: POW_DIFFICULTY };
}


function verifyPoW(challenge, nonce) {
    if (!challenges.has(challenge)) {
        return false;
    }

    const hash = crypto.createHash('sha256')
        .update(challenge + nonce)
        .digest('hex');

    const target = '0'.repeat(POW_DIFFICULTY);
    if (hash.startsWith(target)) {
        challenges.delete(challenge);
        return true;
    }

    return false;
}


function isValidUrl(urlString) {
    try {
        const url = new URL(urlString);
        return url.protocol === 'http:' || url.protocol === 'https:';
    } catch {
        return false;
    }
}


async function processQueue() {
    if (isProcessing || urlQueue.length === 0) {
        return;
    }

    isProcessing = true;

    while (urlQueue.length > 0) {
        const item = urlQueue.shift();
        queueStats.pending = urlQueue.length;

        console.log(`[Bot] Visiting: ${item.url}`);

        try {
            await visitUrl(item.url);
            queueStats.processed++;
            console.log(`[Bot] Successfully visited: ${item.url}`);
        } catch (error) {
            console.error(`[Bot] Error visiting ${item.url}:`, error.message);
        }
    }

    isProcessing = false;
}


async function visitUrl(url) {
    const browser = await puppeteer.launch({
        headless: true,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || undefined,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--disable-dev-shm-usage',
            '--disable-extensions',
            '--disable-default-apps',
            '--disable-background-networking',
            '--disable-component-update',
            '--disable-sync',
            '--disable-breakpad',
            '--mute-audio',
            '--no-first-run',
            '--no-default-browser-check',
            '--ignore-certificate-errors',
            '--disable-features=Translate,MediaRouter,OptimizationHints',
            '--host-resolver-rules=MAP nft-app 127.0.0.1',
        ]
    });

    try {
        const page = await browser.newPage();
        
        await page.setViewport({ width: 1920, height: 1080 });
        
        console.log('[Bot] Logging in as admin...');
        await page.goto(`${APP_URL}/login`, { waitUntil: 'domcontentloaded', timeout: 10000 });

        await page.type('#username', ADMIN_USERNAME);
        await page.type('#password', ADMIN_PASSWORD);
        await page.click('button[type="submit"]');

        await page.waitForNavigation({ waitUntil: 'domcontentloaded', timeout: 10000 });
        console.log('[Bot] Logged in successfully');

        
        console.log(`[Bot] Navigating to: ${url}`);
        await page.goto(url, { waitUntil: 'domcontentloaded', timeout: VISIT_TIMEOUT });

        const sameAppOrigin = new URL(url).origin === APP_URL;
        const dwellTime = sameAppOrigin ? 3500 : EXTERNAL_DWELL_MS;
        await new Promise(resolve => setTimeout(resolve, dwellTime));
        console.log('[Bot] Done, closing browser');
    } finally {
        await browser.close();
    }
}




app.get('/api/challenge', (req, res) => {
    const pow = generateChallenge();
    res.json({
        success: true,
        challenge: pow.challenge,
        difficulty: pow.difficulty,
        message: `Find a nonce where SHA256(challenge + nonce) starts with ${pow.difficulty} zeros`
    });
});


app.post('/api/submit', (req, res) => {
    const { url, challenge, nonce } = req.body;

    
    if (!url || !challenge || nonce === undefined) {
        return res.status(400).json({
            success: false,
            error: 'Missing required fields: url, challenge, nonce'
        });
    }

    
    if (!verifyPoW(challenge, nonce.toString())) {
        return res.status(400).json({
            success: false,
            error: 'Invalid proof of work solution'
        });
    }

    
    if (!isValidUrl(url)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid URL. Must be http:// or https://'
        });
    }

    
    urlQueue.push({
        url,
        timestamp: Date.now()
    });

    queueStats.pending = urlQueue.length;

    
    processQueue();

    res.json({
        success: true,
        message: 'URL added to queue',
        position: urlQueue.length,
        estimatedWait: `${urlQueue.length * 90} seconds`
    });
});


app.get('/api/status', (req, res) => {
    let queueStats = {
        processed: 0,
        failed: 0,
        pending: urlQueue.length
    };
    res.json({
        success: true,
        queue: {
            pending: urlQueue.length,
            processing: isProcessing,
            stats: queueStats
        }
    });
});


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.get('/health', (req, res) => {
    res.json({ status: 'healthy' });
});


app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Admin Bot] Server running on port ${PORT}`);
    console.log(`[Admin Bot] PoW difficulty: ${POW_DIFFICULTY}`);
    console.log(`[Admin Bot] Target app: ${APP_URL}`);
});
