' INERT TRAINING ARTIFACT — comments only; does not execute instructions.
' Claimed task name: OneDriveUpdate
' Intended target recorded in related state: %APPDATA%\Microsoft\OneDrive\RuntimeBroker.exe
' The file is placed in the Startup directory to model persistence evidence.
