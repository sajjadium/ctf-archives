Shared documents folder.
