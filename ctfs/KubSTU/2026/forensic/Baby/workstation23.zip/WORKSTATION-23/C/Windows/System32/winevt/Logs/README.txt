Synthetic event-log placeholder. This lab deliberately contains no real Windows event log files.
