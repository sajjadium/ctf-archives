import hashlib

# Lab's in-house 256-bit curve ("capy256k1"): short Weierstrass, a = 0,
# fast-reduction prime of special form (p = 2^255 + c, p % 4 == 3).
P = 57896044618658097711785492504343953979118230518391900345462709972065690059899
A = 0
B = 7

# order of the base curve y^2 = x^3 + 7
N = 57896044618658097711785492504343953979550547337311152687033934213882653856908

GX = 3
GY = 20342682870605337930692784318752486361945022912389756560963932742755071196870


class Point:
    def __init__(self, x=None, y=None):
        self.x = x
        self.y = y

    @property
    def infinity(self):
        return self.x is None or self.y is None

    def __eq__(self, other):
        if not isinstance(other, Point):
            return False

        if self.infinity and other.infinity:
            return True

        if self.infinity or other.infinity:
            return False

        return self.x == other.x and self.y == other.y

    def __neg__(self):
        if self.infinity:
            return Point()

        return Point(self.x, (-self.y) % P)

    def __add__(self, other):
        if self.infinity:
            return Point(other.x, other.y)

        if other.infinity:
            return Point(self.x, self.y)

        if self.x == other.x and (self.y + other.y) % P == 0:
            return Point()

        if self == other:
            if self.y == 0:
                return Point()

            slope = (
                (3 * self.x * self.x + A)
                * pow(2 * self.y, -1, P)
            ) % P

        else:
            slope = (
                (other.y - self.y)
                * pow((other.x - self.x) % P, -1, P)
            ) % P

        x3 = (slope * slope - self.x - other.x) % P
        y3 = (slope * (self.x - x3) - self.y) % P

        return Point(x3, y3)

    def __rmul__(self, scalar):
        if scalar < 0:
            return (-scalar) * (-self)

        result = Point()
        current = Point(self.x, self.y)

        while scalar:
            if scalar & 1:
                result = result + current

            current = current + current
            scalar >>= 1

        return result

    def __repr__(self):
        if self.infinity:
            return "Point(infinity)"

        return f"Point({self.x}, {self.y})"


G = Point(GX, GY)


def encode_point(point):
    if point.infinity:
        return b"\x00"

    return (
        point.x.to_bytes(32, "big")
        + point.y.to_bytes(32, "big")
    )


def probe(secret, point):
    # diagnostic readout: the result of the scalar operation on the point
    return secret * point


def public_key(secret):
    return secret * G


def derive_key(secret):
    raw = secret.to_bytes(32, "big")
    return hashlib.sha256(b"capy256k1:" + raw).digest()


def xor_stream(data, key):
    result = bytearray()
    counter = 0

    while len(result) < len(data):
        block = hashlib.sha256(
            key + counter.to_bytes(4, "big")
        ).digest()

        take = min(len(block), len(data) - len(result))
        offset = len(result)

        for i in range(take):
            result.append(data[offset + i] ^ block[i])

        counter += 1

    return bytes(result)


def encrypt_flag(secret, flag):
    key = derive_key(secret)
    return xor_stream(flag.encode(), key)


def decrypt_flag(secret, ciphertext):
    key = derive_key(secret)
    return xor_stream(ciphertext, key).decode()
