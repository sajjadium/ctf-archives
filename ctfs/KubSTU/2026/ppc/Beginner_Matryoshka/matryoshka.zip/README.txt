Layer 1 of 10.
The comment of the archive you just opened is the password for level02.zip; `unzip -z` prints it.
