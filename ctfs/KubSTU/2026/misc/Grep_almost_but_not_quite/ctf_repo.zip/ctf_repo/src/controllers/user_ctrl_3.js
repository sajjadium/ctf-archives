console.log('Init user component 3');
