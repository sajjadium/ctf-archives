console.log('Init payment component 4');
