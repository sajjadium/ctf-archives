console.log('Init user component 2');
