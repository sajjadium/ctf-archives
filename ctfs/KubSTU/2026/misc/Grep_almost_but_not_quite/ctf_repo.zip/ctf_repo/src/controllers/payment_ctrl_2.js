console.log('Init payment component 2');
