console.log('Init auth component 3');
