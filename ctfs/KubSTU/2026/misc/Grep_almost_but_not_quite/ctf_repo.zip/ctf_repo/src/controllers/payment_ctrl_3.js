console.log('Init payment component 3');
