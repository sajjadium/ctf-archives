console.log('Init auth component 2');
