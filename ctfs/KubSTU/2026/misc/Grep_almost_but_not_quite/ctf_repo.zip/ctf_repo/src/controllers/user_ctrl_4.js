console.log('Init user component 4');
