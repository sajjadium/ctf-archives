console.log('Init auth component 1');
