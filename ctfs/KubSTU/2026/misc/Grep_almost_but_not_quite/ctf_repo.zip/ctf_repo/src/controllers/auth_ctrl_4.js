console.log('Init auth component 4');
