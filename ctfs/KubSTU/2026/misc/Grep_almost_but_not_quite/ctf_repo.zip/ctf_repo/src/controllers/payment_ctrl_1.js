console.log('Init payment component 1');
