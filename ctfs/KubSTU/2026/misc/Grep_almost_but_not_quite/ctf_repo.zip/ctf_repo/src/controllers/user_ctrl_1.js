console.log('Init user component 1');
