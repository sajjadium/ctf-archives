const FLAG = process.env.NEXT_PUBLIC_FLAG || "watctf{not_the_flag}";
export { FLAG };
