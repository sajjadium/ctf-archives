use solana_program::{
    account_info::AccountInfo,
    entrypoint::ProgramResult,
    msg,
    pubkey::Pubkey,
};

pub fn process_instruction(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    _instruction_data: &[u8],
) -> ProgramResult {
    msg!("Vault Heist Exploit Starting...");
    
    // TODO: Implement your exploit here
    // Available accounts:
    // accounts[0]: User account (writable, signer)
    // accounts[1]: Vault program
    // accounts[2]: Vault PDA
    // accounts[3]: Admin pubkey (read-only, NOT a signer!)
    
    msg!("Exploit implementation goes here...");
    
    Ok(())
}
