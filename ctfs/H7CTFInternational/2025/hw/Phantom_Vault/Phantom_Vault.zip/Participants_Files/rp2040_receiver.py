"""
╔═══════════════════════════════════════════════════════════════════╗
║  CRYPTOMAX VAULT GATE - RECOVERY TOOL v1.2 (PARTIAL)             ║
║  Bitcoin Wallet Forensic Analysis System                          ║
║  H7CTF 2025 - Hardware Forensics Category                         ║
╚═══════════════════════════════════════════════════════════════════╝

EVIDENCE TAG: #PHANTOM-VAULT-2025-10-18
RECOVERED FROM: Silent Circuit hideout, Terminal 7, Laptop 3

FORENSIC NOTES:
This Python script was found on the criminals' analysis workstation.
It appears to be their attempt at decoding the Keymaster transmissions.
The code is INCOMPLETE and contains INTENTIONAL BUGS planted by them
as red herrings.

Your mission: Debug, enhance, and complete this recovery tool to
extract the Bitcoin master seed from the captured transmissions.

WARNING: The criminals got close but never finished. They were missing
critical pieces of the decryption algorithm.

- Agent Rodriguez, Cyber Crimes Division
"""

from machine import Pin
import time
import sys


D0_PIN = 0  
D1_PIN = 1 
D2_PIN = 2  
D3_PIN = 3  
D4_PIN = 4 
D5_PIN = 5  


SYNC_PATTERN = 0x3F    
END_PATTERN = 0x00      
SAMPLE_DELAY_US = 100  


data_pins = [
    Pin(D0_PIN, Pin.IN, Pin.PULL_DOWN),
    Pin(D1_PIN, Pin.IN, Pin.PULL_DOWN),
    Pin(D2_PIN, Pin.IN, Pin.PULL_DOWN),
    Pin(D3_PIN, Pin.IN, Pin.PULL_DOWN),
    Pin(D4_PIN, Pin.IN, Pin.PULL_DOWN),
    Pin(D5_PIN, Pin.IN, Pin.PULL_DOWN)
]


received_data = []
segments = [[] for _ in range(6)]

def read_byte():
    """Read 6 bits from parallel bus"""
    time.sleep_us(SAMPLE_DELAY_US)
    
    byte_value = 0
    for bit_pos in range(6):
        if data_pins[bit_pos].value():
            byte_value |= (1 << bit_pos)
    
    return byte_value

def verify_parity(data):
    """Verify even parity on lower 5 bits"""
    # Extract lower 5 bits
    lower_bits = data & 0x1F
    
    # Calculate parity
    parity = 0
    temp = lower_bits
    while temp:
        parity ^= (temp & 1)
        temp >>= 1
    
    # Check against bit 5
    expected_parity = (data >> 5) & 1
    
    return parity == expected_parity

def simple_decrypt(encrypted_byte):
    """
    Basic decryption function
    WARNING: This is incomplete! The transmitter uses multi-layer encryption.
    Participants need to reverse engineer the full decryption algorithm.
    """
    # This only removes the first XOR layer
    XOR_KEY = 0x2A
    decrypted = encrypted_byte ^ XOR_KEY
    return decrypted & 0x3F

def wait_for_sync():
    """Wait for sync pattern to start receiving"""
    print("Waiting for sync pattern...")
    
    while True:
        byte_val = read_byte()
        if byte_val == SYNC_PATTERN:
            print("SYNC detected! Starting reception...")
            return True
        time.sleep_ms(10)

def receive_transmission():
    """Main reception loop"""
    global received_data, segments
    
    received_data = []
    current_segment = None
    segment_data = []
    
    print("\n=== Starting Reception ===")
    
    while True:
        byte_val = read_byte()
        
        # Check for end pattern
        if byte_val == END_PATTERN:
            # Save last segment if exists
            if current_segment is not None and segment_data:
                segments[current_segment] = segment_data
            print("END pattern detected. Transmission complete.")
            break
        
        # Check for sync pattern (ignore, already synced)
        if byte_val == SYNC_PATTERN:
            time.sleep_ms(50)
            continue
        
        # Check if this is a segment marker
        # Marker format: [segment_index (3 bits)] [position (3 bits)]
        segment_index = (byte_val >> 3) & 0x07
        position = byte_val & 0x07
        
        # If high bits suggest this is a marker
        if segment_index < 6 and byte_val > 0x07:
            # Save previous segment
            if current_segment is not None and segment_data:
                segments[current_segment] = segment_data
            
            # Start new segment
            current_segment = segment_index
            segment_data = []
            print(f"Segment {segment_index} marker detected (position: {position})")
        else:
            # This is data - verify parity and store
            if verify_parity(byte_val):
                segment_data.append(byte_val)
                received_data.append(byte_val)
            else:
                print(f"WARNING: Parity error on byte 0x{byte_val:02X}")
        
        time.sleep_ms(50)

def reconstruct_flag():
    """
    Attempt to reconstruct the flag from segments
    NOTE: This function is intentionally incomplete!
    Participants must figure out:
    1. The correct segment ordering
    2. The complete decryption algorithm
    3. How to properly decode the flag characters
    """
    print("\n=== Attempting Flag Reconstruction ===")
    
    # Placeholder for flag reconstruction
    flag_parts = []
    
    for seg_num in range(6):
        print(f"\nSegment {seg_num}:")
        if seg_num < len(segments) and segments[seg_num]:
            print(f"  Received {len(segments[seg_num])} bytes")
            
            # Try simple decryption (incomplete!)
            decrypted = []
            for byte_val in segments[seg_num]:
                dec = simple_decrypt(byte_val)
                decrypted.append(dec)
                print(f"  0x{byte_val:02X} -> 0x{dec:02X} ({chr(dec) if 32 <= dec < 127 else '?'})")
            
            flag_parts.append(decrypted)
        else:
            print("  No data received for this segment!")
    
    print("\n" + "="*50)
    print("HINT: The decryption is not complete!")
    print("You need to reverse engineer the full encryption scheme.")
    print("Look at the ESP32 transmitter code carefully...")
    print("="*50)
    
    return flag_parts

def dump_raw_data():
    """Dump all received data in hex format for analysis"""
    print("\n=== Raw Data Dump ===")
    print(f"Total bytes received: {len(received_data)}")
    
    for i, byte_val in enumerate(received_data):
        if i % 8 == 0:
            print(f"\n{i:04d}: ", end="")
        print(f"0x{byte_val:02X} ", end="")
    
    print("\n")

def main():
    """Main program loop"""
    print("="*50)
    print("RP2040 Receiver - Signal Heist Challenge")
    print("H7CTF 2025")
    print("="*50)
    print("\nInitializing receiver...")
    print(f"Monitoring pins GP{D0_PIN} through GP{D5_PIN}")
    
    time.sleep(1)
    
    try:
        # Wait for sync
        wait_for_sync()
        time.sleep_ms(50)
        
        # Receive transmission
        receive_transmission()
        
        # Dump raw data for analysis
        dump_raw_data()
        
        # Attempt to reconstruct flag
        reconstruct_flag()
        
        print("\n" + "="*50)
        print("Reception complete!")
        print("Analyze the data and decrypt the flag.")
        print("="*50)
        
    except KeyboardInterrupt:
        print("\nReception interrupted by user.")
    except Exception as e:
        print(f"\nError: {e}")
        sys.print_exception(e)

# Auto-start on boot
if __name__ == "__main__":
    main()

"""
CHALLENGE NOTES:

This receiver code is intentionally incomplete.
Good luck!
"""
