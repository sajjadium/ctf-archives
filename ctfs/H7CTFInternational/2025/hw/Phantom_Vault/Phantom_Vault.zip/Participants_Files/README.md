# 🔐 The Phantom Vault - Hardware Wallet Key Recovery

## Challenge Overview
**Category:** Hardware Forensics / Cryptocurrency  
**Difficulty:** Hard  
**Points:** 500  
**Flag Format:** `H7CTF{...}`

## 🕵️ The Heist

**CLASSIFIED - OPERATION: PHANTOM VAULT**

Three months ago, the notorious "Silent Circuit" syndicate infiltrated CryptoMax Corporation's cold storage facility and stole $50 million in Bitcoin. But here's the twist: CryptoMax didn't store their private keys digitally. 

They built a **physical hardware key transmission system** - a secure circuit where an ESP32 "Keymaster" transmits encrypted key fragments to an RP2040 "Vault Gate" through a 6-wire parallel interface. The complete Bitcoin recovery seed only exists when properly reconstructed from these encrypted fragments.

## 🚨 Your Mission

You're a forensic specialist hired by CryptoMax's insurance company. Law enforcement recovered a prototype circuit board from the criminals' hideout with both chips intact. The syndicate had extracted the source code but **couldn't break the encryption** before being caught.

**Your Task:** Analyze the recovered hardware, reverse engineer the secure transmission protocol, break the multi-layer encryption, and recover the master Bitcoin recovery seed (the flag). $50 million depends on it.

## 📦 Evidence Package

This is a **digital forensics** challenge - no physical hardware required. You've been provided with:

1. **`esp32_transmitter.ino`** - Keymaster firmware extracted from the ESP32 chip
2. **`rp2040_receiver.py`** - Partial recovery tool found on criminals' laptop  



## 🎯 Investigation Objectives

1. **🔌 Analyze the Security Circuit:** Study the PCB layout and understand the hardware key architecture
2. **📡 Reverse the Transmission Protocol:** Decode the 6-bit parallel communication system
3. **🔓 Break the Encryption:** The recovery seed is XOR-encrypted with multiple layers
4. **🧩 Reconstruct the Sequence:** Key fragments are transmitted in scrambled order
5. **💰 Recover the Seed:** Extract the complete Bitcoin recovery phrase


## 🔬 Forensic Analysis Setup (Optional)

If you want to simulate the physical hardware in your lab:
1. Flash `esp32_transmitter.ino` to an ESP32 development board
2. Load `rp2040_receiver.py` onto an RP2040/Pico
3. Wire the 6 GPIO pins
4. Power both devices and capture the transmission

**Note:** Physical testing is NOT required - all information can be extracted through code analysis.

## 🏆 Mission Success

Recover the Bitcoin master seed and submit in format: `H7CTF{...}`

The crypto world is watching. Good luck, Agent. 💼🔐

## Author
Hardware Security Team - H7CTF 2025

---
*"In hardware we trust, but verify the signals."*
