use eyre::{eyre, Context};
use revm::{
    primitives::{
        alloy_primitives::U64, Address, Bytes, B256, U256,
    },
};
use serde::{de::DeserializeOwned, Deserialize};
use serde_json::{json, Value};

pub struct MiniRpcClient {
    client: ureq::Agent,
    rpc_url: String,
}

impl MiniRpcClient {
    pub fn new<T: Into<String>>(rpc_url: T) -> Self {
        MiniRpcClient {
            rpc_url: rpc_url.into(),
            client: ureq::Agent::new(),
        }
    }

    fn format_block_tag(block_number: u64) -> Value {
        json!(format!("0x{:x}", block_number))
    }

    fn make_request(id: u64, method: &str, params: &Value) -> Value {
        json!({
            "id": id,
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        })
    }

    fn handle_response<T: DeserializeOwned>(mut response: Value) -> eyre::Result<T> {
        if let Some(error) = response.get("error") {
            eyre::bail!("rpc error: {error}");
        } else if response.get("result").is_some() {
            let value = response["result"].take();
            return serde_json::from_value(value).context("fail to deserialize result");
        } else {
            eyre::bail!("rpc response missing result")
        }
    }

    fn do_request<T: DeserializeOwned>(&self, method: &str, params: Value) -> eyre::Result<T> {
        let request = Self::make_request(1, method, &params);

        let response = self
            .client
            .post(&self.rpc_url)
            .send_json(request)
            .context("fail to send request")?
            .into_json::<Value>()
            .context("fail to read response")?;

        tracing::trace!(
            method,
            params = format_args!("{}", params),
            "response: {response}",
        );

        Self::handle_response(response)
    }

    pub(crate) fn get_storage_at(
        &self,
        address: &Address,
        index: &U256,
        block_number: u64,
    ) -> eyre::Result<U256> {
        let response = self.do_request::<U256>(
            "eth_getStorageAt",
            json!([
                address.to_string(),
                index.to_string(),
                Self::format_block_tag(block_number),
            ]),
        )?;

        Ok(response)
    }

    pub(crate) fn get_account_basic(
        &self,
        address: &Address,
        block_number: u64,
    ) -> eyre::Result<(U256, u64, Bytes)> {
        let requests = json!([
            Self::make_request(
                1,
                "eth_getBalance",
                &json!([address.to_string(), Self::format_block_tag(block_number)]),
            ),
            Self::make_request(
                2,
                "eth_getTransactionCount",
                &json!([address.to_string(), Self::format_block_tag(block_number)]),
            ),
            Self::make_request(
                3,
                "eth_getCode",
                &json!([address.to_string(), Self::format_block_tag(block_number)]),
            ),
        ]);

        let mut response = self
            .client
            .post(&self.rpc_url)
            .send_json(requests)
            .context("fail to send request")?
            .into_json::<Value>()?;

        tracing::trace!(
            account = address.to_string(),
            "get account basic info. response: {response}"
        );

        let results = response
            .as_array_mut()
            .ok_or(eyre!("expect array response"))?;

        if results.len() != 3 {
            eyre::bail!("expect 3 responses, got {}", results.len());
        }

        let balance =
            Self::handle_response::<U256>(results[0].take()).context("fail to parse balance")?;
        let nonce =
            Self::handle_response::<U64>(results[1].take()).context("fail to parse nonce")?;
        let code =
            Self::handle_response::<Bytes>(results[2].take()).context("fail to parse code")?;

        Ok((balance, nonce.as_limbs()[0], code))
    }
}

#[derive(Debug, Deserialize)]
struct Block {
    pub _hash: Option<B256>,
}
