mod rpc;

use crate::rpc::MiniRpcClient;
use revm::interpreter::{
    CallContext, CallInputs, CallScheme, Contract, CreateInputs, Gas, Host, InstructionResult,
    Interpreter, SelfDestructResult,
};
use revm::precompile::Bytes;
use revm::primitives::{address, hex, keccak256, Address, Bytecode, CancunSpec, Env, B256, U256};
use std::collections::HashMap;
use std::fs;

pub struct Account {
    balance: U256,
    code: Bytecode,
    storage: HashMap<U256, U256>,
}

pub struct FastHost {
    env: Env,
    account: HashMap<Address, Account>,
    rpc: MiniRpcClient,
    block_number: u64,
}

impl Host for FastHost {
    fn step(&mut self, _interpreter: &mut Interpreter) -> InstructionResult {
        InstructionResult::Continue
    }

    fn step_end(
        &mut self,
        _interpreter: &mut Interpreter,
        _ret: InstructionResult,
    ) -> InstructionResult {
        InstructionResult::Continue
    }

    fn env(&mut self) -> &mut Env {
        &mut self.env
    }

    fn load_account(&mut self, _address: Address) -> Option<(bool, bool)> {
        Some((true, true))
    }

    fn block_hash(&mut self, _number: U256) -> Option<B256> {
        Some(B256::default())
    }

    fn balance(&mut self, address: Address) -> Option<(U256, bool)> {
        self.cache_account(address);
        return Some((self.account.get(&address).unwrap().balance, true));
    }

    fn code(&mut self, address: Address) -> Option<(Bytecode, bool)> {
        self.cache_account(address);
        return Some((self.account.get(&address).unwrap().code.clone(), true));
    }

    fn code_hash(&mut self, address: Address) -> Option<(B256, bool)> {
        self.cache_account(address);
        return Some((
            keccak256(self.account.get(&address).unwrap().code.bytes()),
            true,
        ));
    }

    fn sload(&mut self, address: Address, index: U256) -> Option<(U256, bool)> {
        self.cache_slot(address, index);
        return Some((
            self.account
                .get(&address)
                .unwrap()
                .storage
                .get(&index)
                .cloned()
                .unwrap_or(U256::ZERO),
            true,
        ));
    }

    fn sstore(
        &mut self,
        address: Address,
        index: U256,
        value: U256,
    ) -> Option<(U256, U256, U256, bool)> {
        self.cache_account(address);
        let account = self.account.get_mut(&address).unwrap();
        let old = account.storage.get(&index).cloned().unwrap_or(U256::ZERO);
        account.storage.insert(index, value);
        Some((old, old, value, true))
    }

    fn tload(&mut self, _address: Address, _index: U256) -> U256 {
        panic!("no tload thank you!")
    }

    fn tstore(&mut self, _address: Address, _index: U256, _value: U256) {
        panic!("no tstore thank you!")
    }

    fn log(&mut self, _address: Address, _topics: Vec<B256>, _data: Bytes) {}

    fn selfdestruct(&mut self, _address: Address, _target: Address) -> Option<SelfDestructResult> {
        panic!("no selfdestruct thank you!")
    }

    fn create(
        &mut self,
        _inputs: &mut CreateInputs,
    ) -> (InstructionResult, Option<Address>, Gas, Bytes) {
        panic!("no create thank you!")
    }

    fn call(&mut self, input: &mut CallInputs) -> (InstructionResult, Gas, Bytes) {
        // preload relevant accounts into memory
        self.cache_account(input.context.address);
        self.cache_account(input.context.caller);
        self.cache_account(input.context.code_address);

        let gas = Gas::new(input.gas_limit);
        let code = self
            .code(input.context.code_address)
            .map(|(code, _)| code)
            .unwrap_or_default();
        let code_hash = keccak256(&code.bytecode);

        if input.context.apparent_value > self.balance(input.context.caller).unwrap().0 {
            return (InstructionResult::Revert, gas, Bytes::default());
        }

        // update balances
        self.account
            .get_mut(&input.context.address)
            .unwrap()
            .balance += input.context.apparent_value;
        self.account.get_mut(&input.context.caller).unwrap().balance -=
            input.context.apparent_value;

        // run the call
        let call = Contract::new_with_context(
            input.input.clone(),
            code,
            code_hash,
            &CallContext {
                address: input.context.address,
                caller: input.context.caller,
                code_address: input.context.code_address,
                apparent_value: input.context.apparent_value,
                scheme: CallScheme::Call,
            },
        );
        let mut interp =
            Interpreter::new_with_memory_limit(Box::new(call), gas.limit(), false, MEM_LIMIT);
        interp.run::<FastHost, CancunSpec>(self);

        // return the result of the call
        (interp.instruction_result, interp.gas, interp.return_value())
    }
}

impl FastHost {
    pub fn new(rpc: String, block_number: u64) -> Self {
        Self {
            env: Default::default(),
            account: Default::default(),
            rpc: MiniRpcClient::new(rpc),
            block_number,
        }
    }

    // preload account into memory from rpc
    fn cache_account(&mut self, address: Address) {
        if self.account.contains_key(&address) {
            return;
        }
        let account = self.rpc.get_account_basic(&address, self.block_number);
        if let Ok((balance, _nonce, code)) = account {
            self.account.insert(
                address,
                Account {
                    balance,
                    code: Bytecode::new_raw(code),
                    storage: HashMap::new(),
                },
            );
        } else {
            panic!("cache_account: something wrong")
        }
    }

    // preload storage into memory from rpc
    fn cache_slot(&mut self, address: Address, index: U256) {
        if self
            .account
            .get(&address)
            .map(|account| account.storage.contains_key(&index))
            .unwrap_or(false)
        {
            return;
        }
        self.cache_account(address);
        let slot = self.rpc.get_storage_at(&address, &index, self.block_number);
        if let Ok(slot) = slot {
            if let Some(account) = self.account.get_mut(&address) {
                account.storage.insert(index, slot);
            } else {
                unreachable!("account should be cached");
            }
        } else {
            panic!("cache_slot: something wrong")
        }
    }
}

fn run(host: &mut FastHost, from: Address, to: Address, data: Bytes, value: U256) {
    // get the code for the target contract
    let code = host.code(to).map(|(code, _)| code).unwrap_or_default();
    let code_hash = keccak256(&code.bytecode);
    let call = Contract::new_with_context(
        data,
        code,
        code_hash,
        &CallContext {
            address: to,
            caller: from,
            code_address: to,
            apparent_value: value,
            scheme: CallScheme::Call,
        },
    );

    let mut interp = Interpreter::new_with_memory_limit(Box::new(call), MAX_GAS, false, MEM_LIMIT);

    // run the call
    interp.run_inspect::<FastHost, CancunSpec>(host);

    // print the result and return value of the call
    println!("Exploit Result: {:?}", interp.instruction_result);
    println!("Exploit Returns: {:?}", hex::encode(interp.return_value()));
}

// Just two random addresses, nothing fancy
pub const EXP_ADDRESS: Address = address!("B795fF089Fb1511d933643c23Cdb1Cd901392796");
pub const EXP_CALLER: Address = address!("4e7aCe35581bFb77E8d1F6Bebd6A46Af35D3C946");
pub const MEM_LIMIT: u64 = 500 * 1024; // 500KB
pub const MAX_GAS: u64 = 140000000u64; // 140M

fn main() {
    // read the exploit bytecode from the Exploit.bin file
    let exp = fs::read_to_string("./Exploit.bin").unwrap();
    let exp = Bytecode::new_raw(Bytes::from(hex::decode(exp).unwrap()));

    // read the RPC URL from the environment variable
    let rpc_url = std::env::var("RPC_URL").expect("No RPC URL");

    // fork to block 20801320
    let mut host = FastHost::new(rpc_url.to_string(), 20801320);

    // set the code for the exploit contract
    host.account.insert(
        EXP_ADDRESS,
        Account {
            balance: U256::from(0),
            code: exp,
            storage: HashMap::new(),
        },
    );

    // run the exploit
    run(
        &mut host,
        EXP_CALLER,
        EXP_ADDRESS,
        Bytes::from(hex!("63d9b770")), // calls `exploit()`
        U256::from(0),
    );

    // print the final balance of the exploit contract
    let final_balance =
        host.account.get(&EXP_ADDRESS).unwrap().balance / U256::from(1_000_000_000_000_000_000u128);
    println!("Final Balance: {:?}ETH", final_balance);

    // write the final balance to the Score file
    fs::write("Score", format!("{:?}", final_balance)).expect("failed to write score to file");
}
