# Teragas Light Client

### Build

```
cargo build --release
```

### Run
Light client forks Ethereum at block 20801320 then runs the function `exploit()` in `Exploit.bin`. The more ETHs you steal, the more you win.

```
echo 6080 > Exploit.bin
RPC_URL=[YOUR ETH ARCHIVE NODE RPC] ./target/release/light-client 
```