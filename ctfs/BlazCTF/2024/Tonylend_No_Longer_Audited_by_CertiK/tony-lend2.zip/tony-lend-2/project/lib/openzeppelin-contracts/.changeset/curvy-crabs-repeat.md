---
'openzeppelin-solidity': minor
---

`RSA`: Library to verify signatures according to RFC 8017 Signature Verification Operation
