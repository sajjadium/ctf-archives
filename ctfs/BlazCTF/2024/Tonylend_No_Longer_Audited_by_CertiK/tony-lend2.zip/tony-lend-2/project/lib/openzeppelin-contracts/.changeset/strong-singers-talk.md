---
'openzeppelin-solidity': minor
---

`Errors`: New library of common custom errors.
