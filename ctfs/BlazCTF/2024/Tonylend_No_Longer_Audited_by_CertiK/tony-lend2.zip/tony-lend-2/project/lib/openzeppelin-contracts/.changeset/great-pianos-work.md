---
'openzeppelin-solidity': minor
---

`Heap`: A data structure that implements a heap-based priority queue.
