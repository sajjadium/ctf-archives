---
'openzeppelin-solidity': minor
---

`Comparator`: A library of comparator functions, useful for customizing the behavior of the Heap structure.
