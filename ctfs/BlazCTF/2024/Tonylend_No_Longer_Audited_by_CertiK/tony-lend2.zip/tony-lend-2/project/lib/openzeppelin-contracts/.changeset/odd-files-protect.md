---
'openzeppelin-solidity': minor
---

`Hashes`: A library with commonly used hash functions.
