---
'openzeppelin-solidity': minor
---

`Strings`: Added a utility function for converting an address to checksummed string.
