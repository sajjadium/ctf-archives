---
'openzeppelin-solidity': minor
---

`P256`: Library for verification and public key recovery of P256 (aka secp256r1) signatures.
