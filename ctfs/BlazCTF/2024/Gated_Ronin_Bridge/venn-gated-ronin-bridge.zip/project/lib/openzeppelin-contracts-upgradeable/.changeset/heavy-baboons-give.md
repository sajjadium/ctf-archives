---
'openzeppelin-solidity': minor
---

`Packing`: Added a new utility for packing, extracting and replacing bytesXX values.
