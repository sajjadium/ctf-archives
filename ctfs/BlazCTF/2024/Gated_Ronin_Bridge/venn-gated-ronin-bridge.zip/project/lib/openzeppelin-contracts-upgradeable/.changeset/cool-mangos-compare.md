---
'openzeppelin-solidity': minor
---

`Math`: add an `invMod` function to get the modular multiplicative inverse of a number in Z/nZ.
