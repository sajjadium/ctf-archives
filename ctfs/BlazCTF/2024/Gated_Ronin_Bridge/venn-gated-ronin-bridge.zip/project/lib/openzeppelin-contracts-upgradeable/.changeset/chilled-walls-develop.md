---
'openzeppelin-solidity': minor
---

`Clones`: Add version of `clone` and `cloneDeterministic` that support sending value at creation.
