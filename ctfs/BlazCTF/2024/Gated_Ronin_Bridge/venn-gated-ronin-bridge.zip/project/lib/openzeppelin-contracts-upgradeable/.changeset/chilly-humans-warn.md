---
'openzeppelin-solidity': patch
---

`ProxyAdmin`: Fixed documentation for `UPGRADE_INTERFACE_VERSION` getter.
