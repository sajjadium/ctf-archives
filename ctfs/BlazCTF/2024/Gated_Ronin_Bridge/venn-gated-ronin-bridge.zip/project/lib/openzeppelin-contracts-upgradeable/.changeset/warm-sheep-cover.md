---
'openzeppelin-solidity': minor
---

`MerkleTree`: A data structure that allows inserting elements into a merkle tree and updating its root hash.
