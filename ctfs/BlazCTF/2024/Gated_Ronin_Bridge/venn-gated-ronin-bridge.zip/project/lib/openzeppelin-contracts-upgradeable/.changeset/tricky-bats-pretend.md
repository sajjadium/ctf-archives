---
'openzeppelin-solidity': minor
---

`ERC1363Utils`: Add helper similar to the existing `ERC721Utils` and `ERC1155Utils`
