---
'openzeppelin-solidity': minor
---

`AccessManager`: Allow the `onlyAuthorized` modifier to restrict functions added to the manager.
