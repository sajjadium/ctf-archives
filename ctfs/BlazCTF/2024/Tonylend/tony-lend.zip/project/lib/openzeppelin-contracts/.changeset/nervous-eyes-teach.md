---
'openzeppelin-solidity': minor
---

`Create2`: Bubbles up returndata from a deployed contract that reverted during construction.
