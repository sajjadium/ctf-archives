---
'openzeppelin-solidity': minor
---

`StorageSlot`: Add primitives for operating on the transient storage space using a typed-slot representation.
