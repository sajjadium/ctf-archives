---
'openzeppelin-solidity': minor
---

`GovernorCountingFractional`: Add a governor counting module that allows distributing voting power amongst 3 options (For, Against, Abstain).
