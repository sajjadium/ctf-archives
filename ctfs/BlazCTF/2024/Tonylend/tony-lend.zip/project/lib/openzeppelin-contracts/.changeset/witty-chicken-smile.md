---
'openzeppelin-solidity': minor
---

`ReentrancyGuardTransient`: Added a variant of `ReentrancyGuard` that uses transient storage.
