fn main() {
    revmc_build::emit();
}
