#!/bin/sh
cd /src
node /src/app.js