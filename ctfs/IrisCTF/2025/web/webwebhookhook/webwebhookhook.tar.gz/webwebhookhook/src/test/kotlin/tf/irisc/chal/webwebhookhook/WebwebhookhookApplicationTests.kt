package tf.irisc.chal.webwebhookhook

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WebwebhookhookApplicationTests {

    @Test
    fun contextLoads() {
    }

}
