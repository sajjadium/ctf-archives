#ifndef BASE64_H
#define BASE64_H

#include <stdlib.h>
#include <string.h>

char* base64_encode(char* plain);

#endif //BASE64_H
