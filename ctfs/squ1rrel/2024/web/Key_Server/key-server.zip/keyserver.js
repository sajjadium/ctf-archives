const express = require('express');
const fs = require('fs');

const publicKey = fs.readFileSync('jwtRS256.key.pub', 'utf8');
const app = express();

app.get('/', (req, res) => {
    res.send(publicKey);
});

app.listen(3000, () => {
    console.log('Listening on port 3000');
});