const jwt = require("jsonwebtoken");
const express = require("express");
const cookieParser = require('cookie-parser')

const app = express();
app.use(cookieParser());

const verifyToken = async (req, res, next) => {
    const token = req.cookies["token"];
    if (!token) {
        return res.status(401).send("Token cookie missing");
    }

    const { header } = jwt.decode(token, { complete: true });
    if (!header?.issuer || !header?.alg) {
        return res.status(401).send("Headers missing");
    }

    let issuer;
    try {
        issuer = new URL(header.issuer);
    } catch (e) {
        return res.status(401).send("Failed to parse URL");
    }

    if (!issuer.host.startsWith("10.")) {
        return res.status(401).send("Invalid IP address");
    }

    // fetch public key from local key server
    let publicKey;
    try {
        publicKey = await (await fetch(header.issuer)).text();
    } catch (e) {
        return res.status(401).send("Failed to get public key");
    }

    try {
        const verified = jwt.verify(token, publicKey, { algorithms: ["RS256"] });
        if (!verified) {
            return res.status(401).send("Invalid token");
        }
        
        if (verified.user === "admin") {
            return next();
        } else {
            res.status(401).send("Not admin!");
        }
    } catch (e) {
        res.status(401).send("Verification error");
    }
};

app.get("/", (req, res) => {
    res.send(`website undergoing renovations<br />
    <a href="/admin">admin dashboard</a>`);
});

app.get("/admin", verifyToken, (req, res) => {
    res.send(process.env.FLAG);
});

app.listen(3000, () => {
    console.log("Server running on port 3000");
});