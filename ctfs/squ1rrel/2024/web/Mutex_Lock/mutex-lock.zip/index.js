const express = require("express");
const path = require("path");

const app = express();

// mutecies?
let mutexes = {};

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "/index.html"));
});

app.put("/mutex/:name", (req, res) => {
    const { name } = req.params;
    if (mutexes[name] == undefined) {
        const uuid = crypto.randomUUID();
        mutexes[name] = uuid;
        return res.status(200).send("Acquired! Password to release: " + uuid);
    } else {
        return res.status(409).send("Mutex already acquired");
    }
});

app.delete("/mutex/:name", (req, res) => {
    const { name } = req.params;
    const pwd = req.query.pwd;
    if (mutexes[name] == undefined) {
        return res.status(404).send("Mutex not found");
    }

    if (mutexes[name] == pwd) {
        delete mutexes[name];
        return res.status(200).send("Mutex released.");
    } else {
        return res.status(403).send("Invalid password -- do you control this mutex?");
    }
});

app.listen(3000, () => {
    console.log('Server is running!');
});