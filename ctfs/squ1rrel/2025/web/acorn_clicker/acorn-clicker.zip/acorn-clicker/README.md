# Acorn Clicker
Click acorns. Buy squirrels. Profit.

Author: Kyle