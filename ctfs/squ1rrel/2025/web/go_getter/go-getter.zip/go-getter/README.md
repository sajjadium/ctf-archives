# Go Getter

There's a joke to be made here about Python eating the GOpher. I'll cook on it and get back to you.

Author: Kyle