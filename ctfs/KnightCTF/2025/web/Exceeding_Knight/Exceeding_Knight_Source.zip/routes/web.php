<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
use App\Http\Controllers\CalculatorController;
use App\Http\Controllers\UnitConversionController;
use App\Http\Controllers\StringManipulationController;
use App\Http\Controllers\ProfileController;

Route::get('/calculator', [CalculatorController::class, 'index']);
Route::post('/calculator', [CalculatorController::class, 'calculate']); // Handle form submission

Route::get('/convert', [UnitConversionController::class, 'index']);
Route::post('/convert', [UnitConversionController::class, 'convert']);

Route::get('/character-count', [StringManipulationController::class, 'characterCountIndex']);
Route::post('/character-count', [StringManipulationController::class, 'characterCount']);

Route::get('/reverse-string', [StringManipulationController::class, 'reverseStringIndex']);
Route::post('/reverse-string', [StringManipulationController::class, 'reverseString']);

Route::post('/profile', [ProfileController::class, 'index']);
Route::get('/profile/error', [ProfileController::class, 'triggerError']); // Error-triggering route

Route::get('/', function () {
    return view('welcome');
});
