<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

class Handler extends ExceptionHandler {
    protected $dontReport = [];
    protected $dontFlash = ['current_password', 'password', 'password_confirmation'];

    public function register() {
        $this->reportable(function (Throwable $e) {
            //
        });
    }

    public function render($request, Throwable $e) {
        // for debugging
        if (str_contains($e->getMessage(), 'set in the .env file')) {
            $envContent = file_get_contents(base_path('.env'));
            $e = new \Exception($e->getMessage() . "\n\n" .
                "You set a limit on .env and for better debugging here is the content of .env:\n\n" . $envContent);
        }

        return parent::render($request, $e);
    }
}
