<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UnitConversionController extends Controller {
    public function index() {
        return view('convert', ['result' => null]);
    }

    public function convert(Request $request) {
        $request->validate([
            'value' => 'required|numeric',
            'unit_from' => 'required|in:meters,kilometers',
            'unit_to' => 'required|in:meters,kilometers',
        ]);

        $value = $request->input('value');
        $unitFrom = $request->input('unit_from');
        $unitTo = $request->input('unit_to');
        $limit = env('MAX_CALC_LIMIT', 100000); 

        try {
            if ($value > $limit) {
                throw new \Exception("You have hit the conversion limit set in the .env file.");
            }

            if ($unitFrom === $unitTo) {
                $result = $value;
            } elseif ($unitFrom === 'meters' && $unitTo === 'kilometers') {
                $result = $value / 1000;
            } elseif ($unitFrom === 'kilometers' && $unitTo === 'meters') {
                $result = $value * 1000;
            } else {
                throw new \Exception("Invalid unit conversion.");
            }

            return view('convert', ['result' => $result, 'error' => null]);
        } catch (\Exception $e) {
            return view('convert', ['result' => null, 'error' => $e->getMessage()]);
        }
    }
}
