<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class StringManipulationController extends Controller {
    public function characterCountIndex() {
        return view('character-count', ['result' => null]);
    }

    public function characterCount(Request $request) {
        $request->validate(['string' => 'required|string']);
        $string = $request->input('string');
        $result = strlen($string);

        return view('character-count', ['result' => $result]);
    }

    public function reverseStringIndex() {
        return view('reverse-string', ['result' => null]);
    }

    public function reverseString(Request $request) {
        $request->validate(['string' => 'required|string']);

        $input = $request->input('string');
        $limit = env('MAX_CALC_LIMIT', 100000); 

        try {
            if (strlen($input) > $limit) {
                throw new \Exception("You have hit the string limit set in the .env file.");
            }

            $reversed = strrev($input);
            return view('reverse-string', ['result' => $reversed, 'error' => null]);
        } catch (\Exception $e) {
            return view('reverse-string', ['result' => null, 'error' => $e->getMessage()]);
        }
    }
}
