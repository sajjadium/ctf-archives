<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unit Conversion</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .conversion-container {
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #444;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
        }

        input,
        select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }

        button {
            background-color: #28a745;
            color: white;
            font-size: 16px;
            font-weight: bold;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #218838;
        }

        .result {
            margin-top: 20px;
            text-align: center;
            font-size: 18px;
            color: #0069d9;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="conversion-container">
        <h1>Unit Conversion</h1>
        <form method="POST" action="/convert">
            <?php echo csrf_field(); ?>
            <div>
                <label for="value">Value:</label>
                <input type="number" name="value" id="value" required>
            </div>
            <div>
                <label for="unit_from">From:</label>
                <select name="unit_from" id="unit_from" required>
                    <option value="meters">Meters</option>
                    <option value="kilometers">Kilometers</option>
                </select>
            </div>
            <div>
                <label for="unit_to">To:</label>
                <select name="unit_to" id="unit_to" required>
                    <option value="meters">Meters</option>
                    <option value="kilometers">Kilometers</option>
                </select>
            </div>
            <button type="submit">Convert</button>
        </form>

        <?php if(!is_null($result)): ?>
            <p class="result">Result: <?php echo e($result); ?></p>
        <?php endif; ?>
    </div>
</body>

</html>
<?php /**PATH /opt/lampp/htdocs/KnightDev/resources/views/convert.blade.php ENDPATH**/ ?>