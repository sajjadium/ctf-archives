<!DOCTYPE html>
<html>
<head>
    <title>Character Counter</title>
</head>
<body>
    <h1>Character Counter</h1>
    <form method="POST" action="/character-count">
        @csrf
        <label for="string">String:</label>
        <input type="text" name="string" id="string" required>
        <br><br>
        <button type="submit">Count Characters</button>
    </form>

    @if(!is_null($result))
        <h2>Result: {{ $result }} characters</h2>
    @endif
</body>
</html>
