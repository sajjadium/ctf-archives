<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
</head>
<body>
    <h1>Profile Page</h1>
    <p>Welcome to the user profile page.</p>
    <a href="/profile/error">Simulate Error</a>
</body>
</html>
