<!DOCTYPE html>
<html>
<head>
    <title>Reverse String</title>
</head>
<body>
    <h1>Reverse String</h1>
    <form method="POST" action="/reverse-string">
        @csrf
        <label for="string">String:</label>
        <input type="text" name="string" id="string" required>
        <br><br>
        <button type="submit">Reverse</button>
    </form>

    @if(!is_null($result))
        <h2>Reversed String: {{ $result }}</h2>
    @endif
</body>
</html>
