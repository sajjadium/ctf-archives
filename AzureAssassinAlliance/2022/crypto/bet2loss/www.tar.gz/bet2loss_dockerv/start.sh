#!/bin/sh
/usr/local/bin/node /app/bin/www
